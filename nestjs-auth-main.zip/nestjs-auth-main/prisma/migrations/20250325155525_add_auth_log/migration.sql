-- AlterTable
ALTER TABLE `authlog` ADD COLUMN `comments` VARCHAR(191) NULL;
