-- AlterTable
ALTER TABLE `user` ADD COLUMN `isVerified` BOOLEAN NOT NULL DEFAULT false,
    MODIFY `emailVerifiedAt` DATETIME(3) NULL;
