/** @type {import('next').NextConfig} */
const nextConfig = {
  // For Static Export
  // output: 'export',
  trailingSlash: true,
  reactStrictMode: false,
  images: {
    unoptimized: true,
  },
  env: {
    // serverUrl: 'http://3.108.121.124:4001/',
    serverUrl: 'http://127.0.0.1:4001/',
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
  //trailingSlash: false,
  // distDir: 'out',
};

export default nextConfig;
