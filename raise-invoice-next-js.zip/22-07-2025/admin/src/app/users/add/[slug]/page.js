"use client";

import { Breadcrumb } from "react-bootstrap";
// import AddUser from "@/components/Users/AddUser";
import { useParams } from 'next/navigation';
import dynamic from 'next/dynamic';

export default function Page() {
  const { slug } = useParams();
  let AlterUser = '';
  switch (slug) {
    case 'admin':
      AlterUser = dynamic(() => import("../../../../components/Users/AlterAdminUser"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
    case 'client':
      AlterUser = dynamic(() => import("../../../../components/Users/AlterClientUser"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
    default:
      AlterUser = dynamic(() => import("../../../../components/Users/AlterUser"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
  }
  const capitalizeFirstLetter = (string) => {
    return string.replace(/^./, string[0].toUpperCase())
  }
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">Add {capitalizeFirstLetter(slug)}</h3>

        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex align-items-center text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item href={`/users/list/${slug}`}>
            <span className="fw-medium">{capitalizeFirstLetter(slug)} List</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item active>
            <span className="fw-medium">Add {capitalizeFirstLetter(slug)}</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div>

      <AlterUser slug={slug} uuid="" />
    </>
  );
}
