"use client";
   
import { Breadcrumb } from "react-bootstrap";
// import UsersListTable from "@/components/Users/UsersListTable";
import { useParams } from 'next/navigation';
import dynamic from 'next/dynamic';

export default function Page() {
  const { slug } = useParams();
  let UserListTable = '';
  switch(slug){
    case 'admin':
      UserListTable = dynamic(() => import("../../../../components/Users/AdminsListTable"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
    case 'client':
      UserListTable = dynamic(() => import("../../../../components/Users/ClientsListTable"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
    default:
      UserListTable = dynamic(() => import("../../../../components/Users/UsersListTable"), {
        ssr: false,
        loading: () => <p>Loading...</p>,
      });
      break;
  }
  const capitalizeFirstLetter = (string) => {
    return string.replace(/^./, string[0].toUpperCase())
  }
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">{capitalizeFirstLetter(slug)} List</h3>
 
        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex align-items-center text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item active>
            <span className="fw-medium">{capitalizeFirstLetter(slug)} List</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div>

      <UserListTable slug={slug} />
    </>
  );
}
