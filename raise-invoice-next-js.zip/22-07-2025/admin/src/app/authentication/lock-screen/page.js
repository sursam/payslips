import LockScreen from "@/components/Authentication/LockScreen";

export default function Page() {
  return (
    <>
      <LockScreen />
    </>
  );
}
