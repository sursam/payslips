"use client";
import SignInForm from "@/components/Authentication/SignInForm";
// import Navbar from "@/components/FrontPages/Common/Navbar";
// import ContactUs from "@/components/FrontPages/Common/ContactUs";
// import KeyFeatures from "@/components/FrontPages/Common/KeyFeatures";
// import OurTeamSlider from "@/components/FrontPages/Common/OurTeamSlider";
// import Testimonials from "@/components/FrontPages/Common/Testimonials";
// import Widget from "@/components/FrontPages/Common/Widget";
// import FaqContent from "@/components/FrontPages/Faq/FaqContent";
// import HeroBanner from "@/components/FrontPages/Home/HeroBanner";
// import Cta from "@/components/FrontPages/Common/Cta";
// import Footer from "@/components/FrontPages/Common/Footer";
import { useRouter } from 'next/navigation';
import { useEffect } from "react";

export default function Home() {
  const router = useRouter();
  const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
  useEffect(() => {
    if (authToken) {
      router.push('/dashboard/')
    }else{
      router.push('/authentication/sign-in/')
    }
  }, []);

  return (
    <>
      {/* {!authToken ? 
        <SignInForm />
      : ''} */}
      {/* <div className="fp-wrapper">

        <Navbar />

        <HeroBanner />

        <KeyFeatures />

        <Widget />

        <Testimonials />

        <OurTeamSlider />

        <FaqContent />

        <ContactUs />

        <Cta />

        <Footer />

      </div> */}
    </>
  );
}
