"use client";

import { Breadcrumb } from "react-bootstrap";
import AlterSubscription from "@/components/Users/Clients/AlterSubscription";
import { useParams } from 'next/navigation';

export default function Page() {
  const { uuid } = useParams();
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">Add Subscription</h3>
 
        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
        <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item href="/users/list/client">
            <span className="text-secondary fw-medium hover">Client List</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item href={`/client/${uuid}/subscriptions`}>
            <span className="text-secondary fw-medium hover">Subscriptions</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item active>
            <span className="fw-medium">Add Subscription</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div> 

      <AlterSubscription uuid={uuid} />
    </>
  );
}
