"use client";

import { Card, Table, Form, OverlayTrigger, Dropdown, Tooltip } from "react-bootstrap";
import SearchForm from "./SearchForm";
// import Pagination from "./Pagination";
import {useState, useEffect} from 'react';
import apiConnection from "../../../utils/apiConnection";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import Link from "next/link";
import { can } from "../../../utils/helper";
import moment from 'moment';
import { saveAs } from 'file-saver';

const Contacts = () => {
  const [enquiryList, setEnquiryList] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);
    
  const getEnquiryList = async (searchText = '') => {
    try {
        const response = await apiConnection.post('get-enquiry-list', {searchText: searchText});
        console.log(response?.data?.data)
        setEnquiryList(response?.data?.data);
    } catch (error) {
        console.log('error', error);
    }
  };
  const handleDelete = async (e, uuid) => {
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
              try {
                  const response = await apiConnection.post('delete-enquiry', { uuid: uuid })
                  if(response?.data?.status){
                      toast.success("Enquiry deleted successfully")
                      const updatedEnquiryList = enquiryList.filter((item) => item.uuid !== uuid);
                      setEnquiryList(updatedEnquiryList);
                  }
              } catch (error) {
                  console.error('Error deleting enquiry data:', error);
              }
          }
        },
        {
          label: 'No'
        }
      ]
    });
  }
  const handleCheck = (item) => {
    if (checkedItems.includes(item)) {
      setCheckedItems(checkedItems.filter((i) => i !== item));
    } else {
      setCheckedItems([...checkedItems, item]);
    }
  };

  const handleCheckAll = () => {
    if (checkedItems.length === enquiryList.length) {
      setCheckedItems([]);
    } else {
      const enquiryIds = enquiryList.map(object => object.id);
      setCheckedItems(enquiryIds);
    }
  };

  const isAllChecked = checkedItems.length === enquiryList.length;

  const handleMarkAsRead = async () => {
    if (!checkedItems.length) {
      toast.error("Select enquiries first to mark as read");
    } else {
      try {
        const response = await apiConnection.post('mark-enquiry-read', { enquiryIds: checkedItems });
        if(response?.data?.status){
          setCheckedItems([]);
          getEnquiryList();
          toast.success(response?.data?.message)
        }
      } catch (error) {
        console.error('Error changing status:', error);
      }
    }    
  };

  useEffect(() => {
    getEnquiryList()
  }, 
  [])

  const handleExport = async () => {
    try {
      const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
      let data = { type: 'contact-enquiries', searchText: '' };
      const response = await fetch(process.env.serverUrl + 'export-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + authToken
        },
        body: JSON.stringify(data),
      });
      // console.log(response)
      if (response.statusText == "OK") {
        const blob = await response.blob();
        saveAs(blob, 'enquiries-list.xlsx');
      } else {
        console.error('Failed to export data');
      }
    } catch (error) {
      console.error('Error exporting data:', error);
    }
  };

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-0">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 p-4">
            <SearchForm getEnquiryList={getEnquiryList} />
            <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
              <button onClick={() => handleExport()} className="btn btn-warning py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3">
                <span className="py-sm-1 d-block">
                  <i className="ri-export-fill d-none d-sm-inline-block"></i>{" "}
                  <span>Export to Excel</span>
                </span>
              </button>
            
              {/* <div className="text-end">
                <Form.Select
                  className="month-select form-control"
                  aria-label="Default select example"
                >
                  <option defaultValue="0">All</option>
                  <option defaultValue="1">Active</option>
                  <option defaultValue="2">Deactive</option>
                </Form.Select>
              </div> */}
              <OverlayTrigger
                placement="top"
                overlay={<Tooltip id="tooltip-top">More Option</Tooltip>}
              >
                <Dropdown className="action-opt">
                  <Dropdown.Toggle
                    variant="secondary"
                    id="dropdown-basic"
                    className="bg-transparent p-0"
                  >
                    <i className="material-symbols-outlined">more_vert</i>
                  </Dropdown.Toggle>

                  <Dropdown.Menu className="bg-white border box-shadow">
                    <Dropdown.Item href="#" onClick={handleMarkAsRead}>
                      <i className="material-symbols-outlined">
                      notification_multiple
                      </i>
                      Mark As Read
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </OverlayTrigger>
            </div>
          </div>

          <div className="default-table-area style-two">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th scope="col">
                      <OverlayTrigger
                          placement="top"
                          overlay={<Tooltip id="tooltip-top">Check All</Tooltip>}
                        >
                        <Form className="check-form">
                          <Form.Check
                            type="checkbox"
                            id="default-checkbox"
                            title="Check All"
                            checked={isAllChecked}
                            onChange={handleCheckAll}
                          />
                        </Form>
                      </OverlayTrigger>
                    </th>
                    <th scope="col">User</th>
                    <th scope="col">Email</th>
                    {/* <th scope="col">Phone</th> */}
                    <th scope="col">Location</th>
                    <th scope="col">Company</th>
                    <th scope="col">Enquiry Date</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {enquiryList.length ?
                    enquiryList.map((value, i) => (
                      <tr key={i} className={value.isSeen ? 'seen' : 'unseen'}>
                        <td>
                          <Form className="check-form">
                            <Form.Check
                              type="checkbox"
                              id={`checkbox-${ value.id }`}
                              value={ value.id }
                              checked={checkedItems.includes(value.id)}
                              onChange={() => handleCheck(value.id)}
                            />
                          </Form>
                        </td>
                        <td>{value.name}</td>
                        <td><a href={`mailto:${value.email}`}>{value.email}</a></td>
                        {/* <td><a href={`tel:${value.phone}`}>{value.phone}</a></td> */}
                        <td>{value.country?.name}</td>
                        <td>{value.companyName}</td>
                        <td>
                          {moment(value.createdAt).format('DD-MM-YYYY hh:mm A')}
                        </td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            {can(['view-enquiry']) ?
                              <Link
                                href={`/contacts/view/${value.uuid}`}
                                className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                title="View Enquiry"
                              >
                                <i className="material-symbols-outlined fs-16 text-primary">visibility</i>
                              </Link>
                            : ''}
                            {can(['delete-enquiry']) ?
                              <button className="ps-0 border-0 bg-transparent lh-1 position-relative top-2" onClick={e => handleDelete(e, value.uuid)} title="Delete Enquiry">
                                <span className="material-symbols-outlined fs-16 text-danger">
                                  delete
                                </span>
                              </button>
                            : ''}
                          </div>
                        </td>
                      </tr>
                    )) 
                  : <tr key="0"><td colSpan={6} className="text-center">No enquiries are available</td></tr> }
                  
                </tbody>
              </Table>

              {/* Pagination */}
              {/* <Pagination /> */}
            </div>
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default Contacts;
