"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ToastContainer, toast } from "react-toastify";
import Select from 'react-select';
import DOMPurify from 'dompurify';

import dynamic from 'next/dynamic';
const CustomEditor = dynamic(() => import('../../Ckeditor/custom-editor'), { ssr: false });


const AlterBlock = ({ uuid }) => {
  const router = useRouter();
  const [sanitizedHTML, setSanitizedHTML] = useState('');
  const [section_type, setSectionType] = useState('');
  const [faqList, setFaqList] = useState([]);
  const [pageList, setPageList] = useState([]);
  const uuids = uuid;

  var [state, setState] = useState({
    id: null,
    title: '',
    subtitle: '',
    description: '',
    faq_ids: [],
    testimonial_ids: []
  });
  var { title, subtitle, description, faq_ids, testimonial_ids } = state;

  // const handleChange = (event) => {
  //   const { name, value } = event.target;
  //   setState(prevState => ({
  //     ...prevState,
  //     [name]: value,
  //   }));
  //   trigger(name);
  // };

  const handleChange = (event) => {
    const { name, value, options } = event.target;

    if (options) {
      const selectedValues = Array.from(options)
        .filter(option => option.selected)
        .map(option => option.value);
      setState(prevState => ({
        ...prevState,
        [name]: selectedValues,
      }));
    } else {
      setState(prevState => ({
        ...prevState,
        [name]: value,
      }));
    }

    trigger(name);
  };

  const handleChangeSelectSection = (event) => {
    const selectedValue = event.target.value;
    setSectionType(selectedValue);
  };

  const handleChangeEditor = (name, value) => {
    const cleanHTML = DOMPurify.sanitize(value);
    setSanitizedHTML(cleanHTML);
  };

  var validationSchema = Yup.object().shape({
    section_type: Yup.number().required('Section type is required')
    // title: Yup.string()
    //   .required('Title is required'),
    // subtitle: Yup.string()
    //   .required('sub title is required'),
    // description: Yup.string()
    //   .required('Description is required')
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {
    clearErrors()
    reset(state)
  }
  const cancelForm = () => {
    router.push(`/page/block/${uuid}/list/`)
  }
  const onSubmit = async (formData) => {
    formData.page_id = uuids;
    formData.template = sanitizedHTML;
    // console.log(formData); return;

    try {
      const response = await apiConnection.post('save-block', formData)
      if (response.status === 200) {
        resetForm();
        toast.success(response.data.message);
        router.push(`/page/block/${uuid}/list`);
      }
    } catch (error) {
      if (error?.response?.status === 400) {
        toast.error(error?.response?.data?.message);
      } else if (error?.response?.status === 422) {
        toast.error(error?.response?.data?.message);
      } else {
        toast.error(error?.response?.data?.message);
      }
    }
  };

  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      id: null,
      title: '',
      subtitle: '',
      description: '',
      faq_ids: [],
      testimonial_ids: []
    }));
  }

  const getFaqList = async () => {
    try {
      const response = await apiConnection.post('get-faq-list');
      console.log(response?.data?.data)
      setFaqList(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };

  const getsetPageList = async () => {
    try {
      const response = await apiConnection.post('get-testimonial-list');
      console.log(response?.data?.data)
      setPageList(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };

  const sectionTypeList = [
    { id: 1, text: 'Faq Section' },
    { id: 2, text: 'Testimonial Section' },
    { id: 3, text: 'Content Section' },
  ];

  useEffect(() => {
    getFaqList();
    getsetPageList();
    // const menuTitle = `<div class="card mb-3"> 
    //   <div class="card-body"> 
    //     <h4 class="card-title">Card title</h4> 
    //     <p class="card-text">Some example text. Some example text.</p> 
    //     <a href="#" class="card-link btn btn-danger">Card link</a> 
    //     <a href="#" class="card-link btn btn-primary">Another link</a>
    //   </div>
    // </div>`;
    // const menuTitle = `<div class="col-xxl-4 col-xl-5 col-lg-5 col-12"><div class="bg-white border-0 rounded-3 mb-4 card"><div class="p-4 card-body"><div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-30"><h3 class="mb-0">Top Performer</h3><select aria-label="Default select example" class="month-select form-control p-0 h-auto border-0 form-select"><option>Select</option><option>This Month</option><option>Last Month</option><option>Last Year</option></select></div><ul class="ps-0 mb-0 list-unstyled border-top pt-3"><li class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-3"><div class="d-flex align-items-center"><div class="flex-shrink-0"><img alt="user" loading="lazy" width="44" height="44" decoding="async" data-nimg="1" class="wh-44 rounded-circle" style="color:transparent" src="/images/user-6.jpg"></div><div class="flex-grow-1 ms-2 position-relative top-2"><h6 class="mb-0 fw-medium">Alex Davis</h6><span>alex@trezo.com</span></div></div><a class="wh-35 d-inline-block border text-center lh-35 rounded-circle text-decoration-none hover-bg" href="#"><i class="ri-arrow-right-up-line fs-18"></i></a></li><li class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-3"><div class="d-flex align-items-center"><div class="flex-shrink-0"><img alt="user" loading="lazy" width="44" height="44" decoding="async" data-nimg="1" class="wh-44 rounded-circle" style="color:transparent" src="/images/user-7.jpg"></div><div class="flex-grow-1 ms-2 position-relative top-2"><h6 class="mb-0 fw-medium">Laura Martinez</h6><span>laura@trezo.com</span></div></div><a class="wh-35 d-inline-block border text-center lh-35 rounded-circle text-decoration-none hover-bg" href="#"><i class="ri-arrow-right-up-line fs-18"></i></a></li><li class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-3"><div class="d-flex align-items-center"><div class="flex-shrink-0"><img alt="user" loading="lazy" width="44" height="44" decoding="async" data-nimg="1" class="wh-44 rounded-circle" style="color:transparent" src="/images/user-8.jpg"></div><div class="flex-grow-1 ms-2 position-relative top-2"><h6 class="mb-0 fw-medium">Mark Thompson</h6><span>mark@trezo.com</span></div></div><a class="wh-35 d-inline-block border text-center lh-35 rounded-circle text-decoration-none hover-bg" href="#"><i class="ri-arrow-right-up-line fs-18"></i></a></li><li class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-3"><div class="d-flex align-items-center"><div class="flex-shrink-0"><img alt="user" loading="lazy" width="44" height="44" decoding="async" data-nimg="1" class="wh-44 rounded-circle" style="color:transparent" src="/images/user-9.jpg"></div><div class="flex-grow-1 ms-2 position-relative top-2"><h6 class="mb-0 fw-medium">Rachel White</h6><span>rachel@trezo.com</span></div></div><a class="wh-35 d-inline-block border text-center lh-35 rounded-circle text-decoration-none hover-bg" href="#"><i class="ri-arrow-right-up-line fs-18"></i></a></li><li class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-3"><div class="d-flex align-items-center"><div class="flex-shrink-0"><img alt="user" loading="lazy" width="44" height="44" decoding="async" data-nimg="1" class="wh-44 rounded-circle" style="color:transparent" src="/images/user-10.jpg"></div><div class="flex-grow-1 ms-2 position-relative top-2"><h6 class="mb-0 fw-medium">Kevin Lee</h6><span>kevin@trezo.com</span></div></div><a class="wh-35 d-inline-block border text-center lh-35 rounded-circle text-decoration-none hover-bg" href="#"><i class="ri-arrow-right-up-line fs-18"></i></a></li></ul><div class="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap"><span class="fs-12 fw-medium">Items per page: <!-- -->5</span><div class="d-flex align-items-center"><span class="fs-12 fw-medium me-2">1<!-- --> -<!-- --> <!-- -->5<!-- --> of<!-- --> <!-- -->7</span><nav aria-label="Page navigation example"><ul class="pagination mb-0 justify-content-center"><li class="page-item"><button class="page-link icon" disabled="" aria-label="Previous"><span class="material-symbols-outlined">keyboard_arrow_left</span></button></li><li class="page-item"><button class="page-link icon" aria-label="Next"><span class="material-symbols-outlined">keyboard_arrow_right</span></button></li></ul></nav></div></div></div></div></div>`;
    // const cleanHTML = DOMPurify.sanitize(menuTitle);
    // setSanitizedHTML(cleanHTML);
  },
    [])

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col lg={12}>
            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="">
                <Row>

                  <Col sm={12} lg={12}>

                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Section Type</label>
                      <Form.Control
                        as="select"
                        {...register('section_type', { onChange: handleChangeSelectSection })}
                        className={`form-control ${errors.section_type ? 'is-invalid' : (title ? 'is-valid' : '')}`}
                        value={section_type}
                      >
                        <option value="">Select Section Type</option>
                        {sectionTypeList.map(faq => (
                          <option key={faq.id} value={faq.id}>
                            {faq.text}
                          </option>
                        ))}
                      </Form.Control>
                      <div className="invalid-feedback">{errors.section_type?.message?.toString()}</div>
                    </Form.Group>
                    {section_type !== '3' && (
                      <div>
                        <Form.Group className="mb-4">
                          <label className="label text-secondary">Title</label>
                          <Form.Control
                            type="text"
                            {...register('title', { onChange: handleChange })}
                            value={title ?? ''}
                            className={`form-control ${errors.title ? 'is-invalid' : (title ? 'is-valid' : '')}`}
                            placeholder="Enter block title"
                          />
                          <div className="invalid-feedback">{errors.title?.message?.toString()}</div>
                        </Form.Group>
                        <Form.Group className="mb-4">
                          <label className="label text-secondary">Subtitle</label>
                          <Form.Control
                            type="text"
                            {...register('subtitle', { onChange: handleChange })}
                            value={subtitle ?? ''}
                            className={`form-control ${errors.subtitle ? 'is-invalid' : (subtitle ? 'is-valid' : '')}`}
                            placeholder="Enter block subtitle"
                          />
                          <div className="invalid-feedback">{errors.subtitle?.message?.toString()}</div>
                        </Form.Group>
                        <Form.Group className="mb-4">
                          <label className="label text-secondary">Description</label>
                          <Form.Control
                            type="text"
                            {...register('description', { onChange: handleChange })}
                            value={description ?? ''}
                            className={`form-control ${errors.description ? 'is-invalid' : (description ? 'is-valid' : '')}`}
                            placeholder="Enter block description"
                          />
                          <div className="invalid-feedback">{errors.description?.message?.toString()}</div>
                        </Form.Group>
                      </div>
                    )}
                  </Col>

                  {section_type === '1' && (
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Select FAQs</label>
                      <Form.Control
                        as="select"
                        multiple
                        {...register('faq_ids', { onChange: handleChange })}
                        className="form-control"
                        value={faq_ids}
                        style={{ height: "120px" }}
                      >
                        {faqList.map(faq => (
                          <option key={faq?.id} value={faq?.id}>
                            {faq?.question}
                          </option>
                        ))}
                      </Form.Control>
                    </Form.Group>
                  )}
                  {section_type === '2' && (
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Select Testimonials</label>
                      <Form.Control
                        as="select"
                        multiple
                        {...register('testimonial_ids', { onChange: handleChange })}
                        className="form-control"
                        value={testimonial_ids}
                        style={{ height: "120px" }}
                      >
                        {pageList.map(testimonial => (
                          <option key={testimonial?.id} value={testimonial?.id}>
                            {testimonial?.name}
                          </option>
                        ))}
                      </Form.Control>
                    </Form.Group>
                  )}
                  {section_type === '3' && (
                    <Col sm={12} lg={12} className="mb-4">
                      <label className="label text-secondary">Content Section</label>
                      <CustomEditor
                        name='description'
                        className=""
                        value={sanitizedHTML}
                        placeholder="Type here...."
                        data={sanitizedHTML}
                        handleChangeEditor={handleChangeEditor}
                      />
                    </Col>
                  )}

                  {/* Display the Content */}
                  {/* <div className="preview">
                    <div dangerouslySetInnerHTML={{ __html: sanitizedHTML }} className="content" />
                  </div> */}

                  <Col sm={12} lg={12}>
                    <div className="d-flex flex-wrap gap-3">
                      <button className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white" type="button" onClick={cancelForm}>
                        Cancel
                      </button>
                      <button className="btn btn-primary py-2 px-4 fw-medium fs-16" type="submit" onClick={submitForm}>
                        {" "}
                        <i className="ri-add-line text-white fw-medium"></i> {uuid ? 'Update ' : 'Add '}
                        Block
                      </button>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default AlterBlock;
