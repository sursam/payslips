"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";

const ViewTestimonial = ({ uuid }) => {
  var [state, setState] = useState({
    name: '',
    designation: '',
    company: '',
    message: '',
  });
  var { name, designation, company, message } = state;

  const getTestimonialDetails = async () => {
    try {
      const faqResponse = await apiConnection.post('get-testimonial-details', { uuid: uuid })
      if (faqResponse?.data?.status) {
        let faqData = faqResponse?.data?.data;

        setState(prevState => ({
          ...prevState,
          name: faqData?.name,
          designation: faqData?.designation,
          company: faqData?.company,
          message: faqData?.message
        }));
      }
    } catch (error) {
      console.log('error', error);
    }
  };
  useEffect(() => {
    getTestimonialDetails()
  },
    [])

  return (
    <>
      <Row>
        <Col lg={8}>
          <Card className="bg-white border-0 rounded-3 mb-4">
            <Card.Body className="p-4">
              <Row>
                <Col sm={12} lg={12}>
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">name</label>
                    <div>{name}</div>
                  </Form.Group>
                </Col>
                <Col sm={12} lg={12}>
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">
                      message
                    </label>
                    <div>
                      {message}
                    </div>
                  </Form.Group>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={4}>
          <Card className="bg-white border-0 rounded-3 mb-4">
            <Card.Body className="p-4">
              <Form.Group className="mb-4">
                <label className="label text-secondary">
                  designation
                </label>
                <div>
                  {designation}
                </div>
              </Form.Group>
              <Form.Group className="mb-4">
                <label className="label text-secondary">
                  company
                </label>
                <div>
                  {company}
                </div>
              </Form.Group>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  );
};

export default ViewTestimonial;
