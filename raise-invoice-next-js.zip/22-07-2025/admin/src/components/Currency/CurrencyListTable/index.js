"use client";

import { Card, Table } from "react-bootstrap";
import SearchForm from "./SearchForm";
import Pagination from "../../Pagination";
import { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import Switch from "react-switch";
import Link from "next/link";

const CurrencyListTable = () => {
  const [searchText, setSearchText] = useState('');
  const [currencyList, setCurrencyList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [defaultCurrency, setDefaultCurrency] = useState('');
  const [status, setStatus] = useState('');
  const limit = 25;

  const getCurrencyList = async (searchText = '', status= '', page = 1) => {
    try {
      const response = await apiConnection.post('get-currency-list', { searchText, status, page, limit });
      setCurrencyList(response?.data?.data);
      setTotalPages(response?.data?.totalPages);
      setTotalCount(response?.data?.totalCount);
    } catch (error) {
      console.log('error', error);
    }
  };
  const getDefaultCurrency = async () => {
    try {
      const response = await apiConnection.post('get-currency-info', { isDefault: 1 });
      setDefaultCurrency(response?.data?.data ? response?.data?.data.currency_name : '');
    } catch (error) {
      console.log('error', error);
    }
  };
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };
  const handleStatusChange = (checked, id) => {
    confirmAlert({
      title: 'Confirm to change',
      message: 'Are you sure to do this?',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
            try {
              const response = await apiConnection.post('save-currency', { id: id, status: checked })
              if(response?.data?.status){
                getCurrencyList(searchText, status);
                toast.success(response?.data?.message)
              }
            } catch (error) {
              console.error('Error changing status:', error);
            }
          }
        },
        {
          label: 'No'
        }
      ]
    });
  }
  const handleDefaultCurrency = (e) => {
    confirmAlert({
      title: 'Confirm to change',
      message: 'Are you sure to do this?',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
            try {
              const response = await apiConnection.post('set-default-currency', { id: e.target.value })
              if(response?.data?.status){
                getCurrencyList(searchText, status);
                getDefaultCurrency();
                toast.success(response?.data?.message)
              }
            } catch (error) {
              console.error('Error setting default currency:', error);
            }
          }
        },
        {
          label: 'No'
        }
      ]
    });
  }
  useEffect(() => {
    getCurrencyList(searchText, status, currentPage)
    getDefaultCurrency()
  },
    [searchText, status, currentPage])
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
            <SearchForm 
              searchText={searchText}
              setSearchText={setSearchText} 
              setCurrentPage={setCurrentPage} 
              status={status}  
              setStatus={setStatus} 
            />
            <div><label className="form-control">Default Currency: <strong>{defaultCurrency}</strong></label></div>
          </div>

          <div className="default-table-area ">
            <div className="table-responsive">
              <Table className="table align-middle">
                <thead>
                  <tr>
                    <th scope="col">Sl No.</th>
                    <th scope="col">Name</th>
                    <th scope="col">Code</th>
                    <th scope="col">Symbol</th>
                    <th scope="col">Is Default?</th>
                    <th scope="col">Status</th>
                    <th scope="col" width="5%">Exchange Rates</th>
                  </tr>
                </thead>
                <tbody>
                  {currencyList.length ?
                    currencyList.map((value, i) => (
                      <tr key={i}>                                               
                        <td>{i + (limit * currentPage) - limit + 1}</td>
                        <td>{ value?.currency_name }</td>
                        <td>{ value?.currency_code }</td>
                        <td>{ value?.symbol }</td>
                        <td>
                          {value?.status ? 
                            <label htmlFor={`radio${i}`} className="custom-radio" title={value?.isDefault != 1 ? "Set Default Currency" : "Default Currency"}>
                              <input
                                type="radio"
                                className="form-check-input"
                                name="gender"
                                id={`radio${i}`}
                                value={value?.id}
                                checked={value?.isDefault == 1}
                                onChange={handleDefaultCurrency}                                
                              />
                              <div className="radio-content"></div>
                            </label>
                            : ''}
                        </td>
                        <td>
                          {!value?.isDefault ?
                            <Switch 
                              onChange={e => handleStatusChange(e, value?.id)} 
                              checked={value?.status} 
                              uncheckedIcon=""
                              checkedIcon=""
                              
                            />
                          : <span className="material-symbols-outlined text-success">check</span>}
                        </td>
                        <td>
                          {value?.status ? 
                            <Link
                              href={`/currencies/exchange-rates/${value.currency_code.toLowerCase()}`}
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                              title="Exchange Rates"
                            >
                              <span className="material-symbols-outlined">price_change</span>
                            </Link>
                          : ''}
                        </td>
                      </tr>
                    )) : <tr key="0"><td colSpan={7} className="text-center">No currencies are available</td></tr>}
                </tbody>
              </Table>
            </div>

            {/* Pagination */}
            <Pagination currentPage={currentPage} totalPages={totalPages} totalCount={totalCount} onPageChange={handlePageChange} limit={limit} />
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default CurrencyListTable;
