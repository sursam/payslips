"use client";

import { Form } from "react-bootstrap";
import { useState } from 'react';

const SearchForm = ({searchText, setSearchText, setCurrentPage, status, setStatus}) => {
  const [isShowClear, setIsShowClear] = useState(false);
  const handleSearchInput = (searchText = '') => {
    setSearchText(searchText);
    setCurrentPage(1);
    if(searchText != ''){
      setIsShowClear(true);
    }else{
      setIsShowClear(false);
    }
  }
  const handleFilterStatus = (value = '') => {
    setStatus(value);
    setCurrentPage(1);
    if(value != ''){
      setIsShowClear(true);
    }else{
      setIsShowClear(false);
    }
  }
  const handleClearFilter = () => {
    setSearchText('');
    setStatus('');
    setCurrentPage(1);
    setIsShowClear(false);
  }
  return (
    <>
      <Form className="position-relative table-src-form">
        <div className="d-flex justify-content-between align-items-center gap-3">
          <div className="position-relative">
            <Form.Control type="text" placeholder="Search here" onChange={(e) => handleSearchInput(e.target.value)} value={searchText}/>
            <span className="material-symbols-outlined position-absolute top-50 start-0 translate-middle-y">
              search
            </span>
          </div>
          <div className="position-relative">
            <select className="form-control form-select" aria-label=".form-select-lg" onChange={(e) => handleFilterStatus(e.target.value)} value={status}>
              <option value="">Filter by status</option>
              <option value="1">Active</option>
              <option value="0">InActive</option>
            </select>
            <span className="material-symbols-outlined position-absolute top-50 start-0 translate-middle-y">
              filter_alt
            </span>
          </div>
          {isShowClear ? 
            <button variant="primary" className="btn btn-warning text-white fw-semibold px-2 clear-btn-warning" onClick={handleClearFilter}>
              <span className="material-symbols-outlined align-middle">cancel</span> Clear
            </button>
          : ''}
        </div>
      </Form>
    </>
  );
};

export default SearchForm;
