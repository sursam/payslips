"use client";

import { Card, Table, Form } from "react-bootstrap";
import { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import Select from 'react-select';
import { useRouter, useParams } from 'next/navigation';

const ExchangeRatesTable = () => {
  const { slug } = useParams();
  const router = useRouter();
  const [currencyList, setCurrencyList] = useState([]);
  const [selectedCurrency, setSelectedCurrency] = useState('');
  const [isRateEdited, setIsRateEdited] = useState(false);

  const getCurrencyList = async (status= '') => {
    try {
      const response = await apiConnection.post('get-currency-list', { status });
      // console.log(response?.data?.data.length)
      setCurrencyList(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };
  const getSelectedCurrency = async () => {
    try {
      const response = await apiConnection.post('get-currency-info', { currency_code: slug.toUpperCase() });
      setSelectedCurrency(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };
  const handleCurrencyList = (data) => {
    router.push(`/currencies/exchange-rates/${data.value.toLowerCase()}`);
  }
  const handleExchangeRate = async (e, currency_to) => {
    try {
      if(isRateEdited){
        const response = await apiConnection.post('save-exchange-rate', { currency_from: selectedCurrency.id, currency_to: currency_to, exchange_rate: e.target.value });
        if(response?.data?.status){
          setIsRateEdited(false);
          toast.success(response?.data?.message)
        }
      }
    } catch (error) {
      console.log('error', error);
    }
  };
  useEffect(() => {
    getCurrencyList(1)
    getSelectedCurrency()
  },
    [])
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
            <Form className="position-relative table-src-form">            
              <Form.Group className="d-flex justify-content-between align-items-center gap-2">
                <label className="label text-secondary mb-0 fs-16 text-gray-light">Currency:</label>
                <Select 
                  instanceId="currency"
                  id="currency"
                  className="current-select"
                  options={currencyList} 
                  value={currencyList.find(({ value }) => value === selectedCurrency.currency_code)}
                  onChange={handleCurrencyList}
                  placeholder="Select Currency"
                />
              </Form.Group>
            </Form>
          </div>

          <div className="default-table-area ">
            <div className="table-responsive">
              <Table className="table align-middle table-src-form">
                <thead>
                  <tr>
                    <th scope="col">Sl No.</th>
                    <th scope="col">Name</th>
                    <th scope="col">
                      Exchange Rates - {`1.00 ${ selectedCurrency.currency_code }`}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currencyList.length ?
                    currencyList.map((value, i) => (
                      (value?.currency_code != selectedCurrency.currency_code) ?
                        <tr key={i}>                                               
                          <td>{i + 1}</td>
                          <td>{`${ value?.currency_code } - ${ value?.currency_name }`}</td>
                          <td> 
                            <div className="d-flex align-items-center flex-wrap gap-2">
                              <span className="align-middle">
                                { value?.symbol }
                              </span>
                              <Form.Control type="number" placeholder="Exchange Rate" className="px-3" onBlur={e => handleExchangeRate(e, value?.id)} onChange={() => setIsRateEdited(true)} defaultValue={value?.exchange_rates?.find(elem => elem.currency_from == selectedCurrency.id)?.exchange_rate} />
                            </div> 
                          </td>
                        </tr>
                      : ''
                    )) : <tr key="0"><td colSpan={3} className="text-center">No currencies are available</td></tr>}
                </tbody>
              </Table>
            </div>
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default ExchangeRatesTable;
