"use client";

import React, { useState } from "react";
import { Card, Form, Table, Button } from "react-bootstrap";
import Image from "next/image";

const recentLeadsData = [
  {
    customerImg: "/images/user-11.jpg",
    customerName: "08-04-2025",
    email: "david@trezo.com",
    source: "Premium",
    status: "Active",
  },
  {
    customerImg: "/images/user-12.jpg",
    customerName: "07-04-2025",
    email: "sara@trezo.com",
    source: "New",
    status: "Active",
  },
  {
    customerImg: "/images/user-13.jpg",
    customerName: "08-04-2025",
    email: "micheal@trezo.com",
    source: "Premium",
    status: "Active",
  }
];

const SubscriptionTransaction = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedItems, setSelectedItems] = useState([]);
  const [isSelectAll, setIsSelectAll] = useState(false);

  const pageSize = 5;
  const totalPages = Math.ceil(recentLeadsData.length / pageSize);
  const startIdx = (currentPage - 1) * pageSize;
  const currentItems = recentLeadsData.slice(startIdx, startIdx + pageSize);

  const handlePrevPage = () => setCurrentPage((prev) => Math.max(prev - 1, 1));
  const handleNextPage = () =>
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));

  const handleSelectAll = (event) => {
    setIsSelectAll(event.target.checked);
    if (event.target.checked) {
      setSelectedItems(currentItems.map((item) => item.email));
    } else {
      setSelectedItems([]);
    }
  };

  const handleSelectItem = (email) => {
    if (selectedItems.includes(email)) {
      setSelectedItems(selectedItems.filter((item) => item !== email));
    } else {
      setSelectedItems([...selectedItems, email]);
    }
  };

  return (
    <Card className="bg-white border-0 rounded-3 mb-4">
      <Card.Body className="p-0">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 p-4">
          <h3 className="mb-0">Subscription Transactions</h3>

          <Form.Select
            className="month-select form-control p-0 h-auto border-0"
            aria-label="Default select example"
          >
            <option defaultValue="0">Select</option>
            <option defaultValue="1">Today</option>
            <option defaultValue="2">Last Weekly</option>
            <option defaultValue="3">Last Monthly</option>
            <option defaultValue="4">Last Yearly</option>
          </Form.Select>
        </div>

        <div className="default-table-area style-two recent-leads">
          <div className="table-responsive">
            <Table className="align-middle">
              <thead>
                <tr>
                  <th scope="col">Transaction Id</th>
                  <th scope="col">Date</th>
                  <th scope="col">Plan</th>
                  <th scope="col">Client</th>
                  <th scope="col">Amount</th>
                </tr>
              </thead>

              <tbody>
                {currentItems.map((item, i) => (
                  <tr key={i}>
                    <td>
                      <div className="d-flex align-items-center">
                        {/* <Image
                          src={item.customerImg}
                          className="wh-44 rounded-circle"
                          alt="user"
                          width={44}
                          height={44}
                        /> */}
                        <div className="ms-2">
                          <h6 className="fw-medium fs-14 mb-0">
                            {item.email}
                          </h6>
                        </div>
                      </div>
                    </td>
                    <td>{item.customerName}</td>
                    <td>{item.source}</td>
                    <td>
                      <span
                        className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${item.status}`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td>
                      120.00
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>

          <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap p-4">
            <span className="fs-12 fw-medium">
              Showing {startIdx + 1} -{" "}
              {Math.min(startIdx + pageSize, recentLeadsData.length)} of{" "}
              {recentLeadsData.length} Results
            </span>

            <nav aria-label="Page navigation example">
              <ul className="pagination mb-0 justify-content-center">
                <li className="page-item">
                  <Button
                    className="page-link icon"
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                  >
                    <span className="material-symbols-outlined">
                      keyboard_arrow_left
                    </span>
                  </Button>
                </li>
                <li className="page-item">
                  <Button
                    className="page-link icon"
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages}
                  >
                    <span className="material-symbols-outlined">
                      keyboard_arrow_right
                    </span>
                  </Button>
                </li>
              </ul>
            </nav>
          </div>
        </div>

      </Card.Body>
    </Card>
  );
};

export default SubscriptionTransaction;
