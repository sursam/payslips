"use client";

import { Row, Col, Form } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from 'next/navigation';
import { useState, useEffect } from "react";
import { v4 as uuid } from "uuid";
import { ToastContainer, toast } from "react-toastify";
import apiConnection from "../../../utils/apiConnection";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
// import bcrypt from 'bcryptjs';

const SignInForm = () => {
  const router = useRouter();
  var [state, setState] = useState({
    email: '',
    password: '',    
  });
  var { email, password } = state;
  const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
  var deviceId = (typeof localStorage !== 'undefined') ? localStorage.getItem("device-id") : null;
  
  useEffect(() => {
    if (authToken) {
        router.push('/dashboard/')
    }
  }, []);

  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
  };

  const validationSchema = Yup.object().shape({
    email: Yup.string().required('Email is required'),
    password: Yup.string().required('Password is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {    
    clearErrors() 
    reset(state)
  }

  const onSubmit = async (formData) => {
    // const hashedPassword = bcrypt.hashSync(formData.password, process.env.hashedkey)

    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;

    if (reg.test(email) === false) {
        toast.error('Email should be proper!');
    } else {
        if(!deviceId){
          deviceId = uuid();
          localStorage.setItem("device-id", deviceId)
        }
        
        const payload = {
          "email": formData.email,
          "password": formData.password,
          "deviceType": 2, //1-App, 2-web
          "deviceId": deviceId
        }

        try {
            const response = await apiConnection.post('login', payload)
            if (response.status === 200) {                
                toast.success(response.data.message);
                console.log(response.data.data.user.webLogin)
                localStorage.setItem("auth-token", response.data.data.user.webLogin)                  
                // const { cookies } = import('next/headers')
                // const cookieStore = await cookies();
                // cookieStore.set("auth-token", response.data.data.user.webLogin);   
                // console.log(response.data.data.user.webLogin);
                router.push('/dashboard')
                resetForm();
                window.location.reload()
            }
        } catch (error) {
            if (error?.response?.status === 400) {
                toast.error(error?.response?.data?.message);
            } else if (error?.response?.status === 422) {
                toast.error(error?.response?.data?.message);
            } else {
                toast.error(error?.response?.data?.message);
            }

        }
    }
  }; 
  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      email: '',
      password: '',
    }));
  }
  // const handleLogin = async () => {

  //   let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;

  //   if (reg.test(email) === false) {

  //       toast.error('Email should be proper!');
  //   }
  //   else if (email === "" || password === "") {
  //       toast.error("Please enter all the fields")
  //   } else {
  //       const payload = {
  //           "email": email,
  //           "password": password,
  //           "deviceType": 2, //1-App, 2-web
  //           "deviceId": unique_id
  //       }

  //       try {
  //           const response = await apiConnection.post('login', payload)
  //           if (response.status === 200) {                    
  //               toast.success(response.data.message);
  //               localStorage.setItem("invoice-token", response.data.data.user.webLogin)
  //               router.push('/dashboard')
  //               // window.location.reload()
  //           }
  //       } catch (error) {
  //           if (error?.response?.status === 400) {
  //               toast.error(error?.response?.data?.message);
  //           } else if (error?.response?.status === 422) {
  //               toast.error(error?.response?.data?.message);
  //           } else {
  //               toast.error(error?.response?.data?.message);
  //           }

  //       }
  //   }
  // }
  return (
    <>
      {!authToken ?
        <div className="auth-main-content m-auto m-1230 px-3">
          <ToastContainer position="top-right" autoClose={3000} />
          <Row className="align-items-center">
            <Col lg={6} className="d-none d-lg-block">
              <Image
                src="/images/login-page.png"
                className="rounded-3"
                alt="login"
                width={646}
                height={804}
              />
            </Col>

            <Col lg={6}>
              <div className="mw-480 ms-lg-auto">
                <div className="d-inline-block mb-4">
                  <Image
                    src="/images/logo.svg"
                    className="for-light-logo"
                    alt="login"
                    width={100}
                    height={26}
                  />
                  <Image
                    src="/images/white-logo.svg"
                    className="for-dark-logo"
                    alt="login"
                    width={100}
                    height={26}
                  />
                </div>

                <h3 className="fs-28 mb-2">Welcome back to RaiseInvoice!</h3>
                <p className="fw-medium fs-16 mb-4">
                  Sign In with your account credentials
                </p>
                {/* <div className="row justify-content-center">
                  <div className="col-lg-4 col-sm-4">
                    <a
                      href="https://www.google.com/"
                      target="_blank"
                      className="btn btn-outline-secondary bg-transparent w-100 py-2 hover-bg mb-4"
                      style={{
                        borderColor: "#D6DAE1",
                      }}
                    >
                      <Image
                        src="/images/google.svg"
                        alt="google"
                        width={25}
                        height={25}
                      />
                    </a>
                  </div>

                  <div className="col-lg-4 col-sm-4">
                    <a
                      href="https://www.facebook.com/"
                      target="_blank"
                      className="btn btn-outline-secondary bg-transparent w-100 py-2 hover-bg mb-4"
                      style={{
                        borderColor: "#D6DAE1",
                      }}
                    >
                      <Image
                        src="/images/facebook2.svg"
                        alt="facebook2"
                        width={25}
                        height={25}
                      />
                    </a>
                  </div>

                  <div className="col-lg-4 col-sm-4">
                    <a
                      href="https://www.apple.com/"
                      target="_blank"
                      className="btn btn-outline-secondary bg-transparent w-100 py-2 hover-bg mb-4"
                      style={{
                        borderColor: "#D6DAE1",
                      }}
                    >
                      <Image
                        src="/images/apple.svg"
                        alt="apple"
                        width={25}
                        height={25}
                      />
                    </a>
                  </div>
                </div> */}

                <Form onSubmit={handleSubmit(onSubmit)}>
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">Email Address</label>
                    <Form.Control
                      type="email"
                      className={`h-55 ${errors.email ? 'is-invalid' : ''}`}
                      placeholder="example@raiseinvoice.com"
                      {...register('email', {onChange: handleChange})}
                      value={email}
                      autoComplete="off"
                    />
                    <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <label className="label text-secondary">Password</label>
                    <Form.Control
                      type="password"
                      className={`h-55 ${errors.password ? 'is-invalid' : ''}`}
                      placeholder="Type password"
                      {...register('password', {onChange: handleChange})}
                      value={password}
                      autoComplete="off"
                    />
                    <div className="invalid-feedback">{errors.password?.message?.toString()}</div>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Link href='/authentication/forgot-password/' className="fw-medium text-primary text-decoration-none">
                      Forgot Password?
                    </Link>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <button
                      type="submit"
                      className="btn btn-primary fw-medium py-2 px-3 w-100"
                      onClick={submitForm}
                    >
                      <div className="d-flex align-items-center justify-content-center py-1">
                        <span className="material-symbols-outlined fs-20 text-white me-2">
                          login
                        </span>
                        <span>Sign In</span>
                      </div>
                    </button>
                  </Form.Group>

                  {/* <Form.Group>
                    <p>
                      Don’t have an account.{" "}
                      <Link
                        href="/authentication/sign-up/"
                        className="fw-medium text-primary text-decoration-none"
                      >
                        Sign Up
                      </Link>
                    </p>
                  </Form.Group> */}
                </Form>
              </div>
            </Col>
          </Row>
        </div>
      : ''}
    </>
  );
};

export default SignInForm;
