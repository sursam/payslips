// auth.js
import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import type { NextAuthOptions } from "next-auth";

export const authOptions: NextAuthOptions = {
// const handler =  NextAuth({
  providers: [
    Credentials({
      name: 'Credentials',
      credentials: {
        email: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
        device_type: { label: 'Device Type', type: 'number' },
      },
      async authorize(credentials) {        
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}email-login`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email_id: credentials.email,
            password: credentials.password,
            device_type: credentials.device_type,
          }),
        });
        const response = await res.json();
        console.log('user', response.data.user);

        if (res.ok && response?.data?.user) {
            const user = response.data.user;
            return user;
            // return {
            //   uuid: user.uuid,
            //   name: user.name,
            //   email: user.email,
            //   isVerified: user.isVerified,
            //   accessToken: user.accessToken
            // }; 
        }
        return null;
      },
    }),
  ],
  pages: {
    signIn: '/sign-in', // Custom sign-in page path
  },
  callbacks: {
    //   authorized({ auth, request: { nextUrl } }) {
    //     console.log('auth', auth);
    //     const isLoggedIn = !!auth?.user;
    //     const isOnLoginPage = nextUrl.pathname === "/sign-in";

    //     if (isOnLoginPage) {
    //       if (isLoggedIn) {
    //         return Response.redirect(new URL("/dashboard", nextUrl)); // Redirect logged-in users from login page
    //       }
    //       return true;
    //     } else if (!isLoggedIn) {
    //       return false; // Redirect unauthenticated users to login page
    //     }
    //     return true;
    //   },
      async jwt({ token, user }) {
        // console.log('token, user, account', token, user, account);
        if (user) {
          token.accessToken = user.accessToken;
          token.uuid = user.uuid;
          token.isVerified = user.isVerified;
        }
        return token
      },
      async session({ session, token, user }) {
        // console.log('session, token, user', session, token, user);
        session.accessToken = token.accessToken;
        session.user.uuid = token.uuid;
        session.user.isVerified = token.isVerified;
        return session
      }
    },
    session: {
      strategy: 'jwt',
    },
};
const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }