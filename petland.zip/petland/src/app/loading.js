export default function Loading() { 
  return (
    <>
      <div className="preloader" id="preloader">
        <div className="preloader">
          <div className="waviy position-relative">
            <span className="d-inline-block">P</span>
            <span className="d-inline-block">E</span>
            <span className="d-inline-block">T</span>
            <span className="d-inline-block">&nbsp;&nbsp;</span>
            <span className="d-inline-block">L</span>
            <span className="d-inline-block">A</span>
            <span className="d-inline-block">N</span>
            <span className="d-inline-block">D</span>
          </div>
        </div>
      </div>
    </>
  )
}