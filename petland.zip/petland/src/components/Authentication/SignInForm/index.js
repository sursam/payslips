"use client";

import { useState } from "react";
import { Row, Col, Form, Spinner } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { signIn } from "next-auth/react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const SignInForm = () => {
  const { data: session, status } = useSession();
  console.log('session => ', session);
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  var [state, setState] = useState({
    email: '',
    password: '',    
  });
  var { email, password } = state;
  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
  };

  const validationSchema = Yup.object().shape({
    email: Yup.string()
        .required('Email is required')
        .email('Invalid email format'),
    password: Yup.string().required('Password is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors }, setError, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {    
    clearErrors() 
    reset(state)
  }

  const onSubmit = async (formData) => {
    setLoading(true);
    const email = formData.email;
    const password = formData.password;
    const device_type = 1;
    try {
      const response = await signIn("credentials", { email, password, device_type, redirect: false, });
      if(response.ok){
        // console.log('response ====>', response);
        router.push('/dashboard/')
      }else if(response.status == 401){
        setError("password", { type: "server", message: "Invalid credentials" });
        setLoading(false);
      }
      // resetForm();
    } catch (error) {
      console.error("Authentication error:", error);
      setLoading(false);
      // throw error;
    }
  }; 
  // const resetForm = () => {
  //   clearErrors();
  //   setState(prevState => ({
  //     ...prevState,
  //     email: '',
  //     password: '',
  //   }));
  // }
  return (
    <>
      <div className="auth-main-content m-auto m-1230 px-3">
        <Row className="align-items-center">
          <Col lg={6} className="d-none d-lg-block">
            <Image
              src="/images/login.png"
              className="rounded-3"
              alt="login"
              width={646}
              height={804}
            />
          </Col>

          <Col lg={6}>
            <div className="mw-480 ms-lg-auto">
              <div className="d-inline-block mb-4">
                <Image
                  src="/images/logo.png"
                  className="rounded-3 for-light-logo"
                  alt="login"
                  width={123}
                  height={70}
                />
                <Image
                  src="/images/logo_dark.png"
                  className="rounded-3 for-dark-logo"
                  alt="login"
                  width={123}
                  height={70}
                />
              </div>

              <h3 className="fs-28 mb-2">Welcome to Pet Land!</h3>
              <p className="fw-medium fs-16 mb-4">
                Sign In with social account or enter your details
              </p>

              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-4">
                  <label className="label text-secondary">Email Address</label>
                  <Form.Control
                    type="email"
                    className={`h-55 ${errors.email ? 'is-invalid' : ''}`}
                    placeholder="example@raiseinvoice.com"
                    {...register('email', {onChange: handleChange})}
                    value={email}
                    autoComplete="off"
                  />
                  <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                </Form.Group>

                <Form.Group className="mb-4">
                  <label className="label text-secondary">Password</label>
                  <Form.Control
                    type="password"
                    className={`h-55 ${errors.password ? 'is-invalid' : ''}`}
                    placeholder="Type password"
                    {...register('password', {onChange: handleChange})}
                    value={password}
                    autoComplete="off"
                  />
                  <div className="invalid-feedback">{errors.password?.message?.toString()}</div>
                </Form.Group>

                <Form.Group className="mb-4">
                  <Link href='/forgot-password/' className="fw-medium text-primary text-decoration-none">
                    Forgot Password?
                  </Link>
                </Form.Group>

                <Form.Group className="mb-4">
                  <button
                    type="submit"
                    className="btn btn-primary fw-medium py-2 px-3 w-100"
                    onClick={submitForm}
                    disabled={loading}
                  >
                    <div className="d-flex align-items-center justify-content-center py-1">
                      {loading ? (
                        <>
                          <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                          <span className="ms-2">Please Wait...</span>
                        </>
                      ) : (
                        <>
                          <span className="material-symbols-outlined fs-20 text-white me-2">
                            login
                          </span>
                          <span>Sign In</span>
                        </>
                      )}
                    </div>
                  </button>
                </Form.Group>
              </Form>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default SignInForm;
