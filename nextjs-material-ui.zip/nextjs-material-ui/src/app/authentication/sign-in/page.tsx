import * as React from "react";
 
import SignInForm from "@/components/Authentication/SignInForm";

export default function Page() {
  return (
    <>
      <SignInForm />
    </>
  );
}
