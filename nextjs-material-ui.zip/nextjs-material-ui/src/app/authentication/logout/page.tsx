import * as React from "react";
 
import LogoutContent from "@/components/Authentication/LogoutContent";

export default function Page() {
  return (
    <>
      <LogoutContent />
    </>
  );
}
