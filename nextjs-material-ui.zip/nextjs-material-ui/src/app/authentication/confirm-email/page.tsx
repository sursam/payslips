import * as React from "react";
 
import ConfirmEmailForm from "@/components/Authentication/ConfirmEmailForm";

export default function Page() {
  return (
    <>
      <ConfirmEmailForm />
    </>
  );
}
