import * as React from "react";
 
import LockScreenForm from "@/components/Authentication/LockScreenForm";

export default function Page() {
  return (
    <>
      <LockScreenForm />
    </>
  );
}
