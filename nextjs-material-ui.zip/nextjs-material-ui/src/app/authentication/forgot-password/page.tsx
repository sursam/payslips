import * as React from "react";
 
import ForgotPasswordForm from "@/components/Authentication/ForgotPasswordForm";

export default function Page() {
  return (
    <>
      <ForgotPasswordForm />
    </>
  );
}
