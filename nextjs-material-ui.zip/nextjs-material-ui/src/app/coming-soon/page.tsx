import * as React from "react"; 
import ComingSoonContent from "@/components/ComingSoon/ComingSoonContent";

export default function Page() {
  return (
    <>
      <ComingSoonContent />
    </>
  );
}
