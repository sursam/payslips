"use client";

import React, { useEffect, useState } from "react";
import { ApexOptions } from "apexcharts";
import dynamic from "next/dynamic";
import {
  Card,
  Box,
  Typography,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import Image from "next/image";
import Button from "@mui/material/Button";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

// Dynamically import react-apexcharts with Next.js dynamic import
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

const MarketPriceStatistics: React.FC = () => {
  // Dropdown 1
  const [anchorEl1, setAnchorEl1] = React.useState<null | HTMLElement>(null);
  const open1 = Boolean(anchorEl1);
  const handleClick1 = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl1(event.currentTarget);
  };
  const handleClose1 = () => {
    setAnchorEl1(null);
  };

  // Dropdown 2
  const [anchorEl2, setAnchorEl2] = React.useState<null | HTMLElement>(null);
  const open2 = Boolean(anchorEl2);
  const handleClick2 = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl2(event.currentTarget);
  };
  const handleClose2 = () => {
    setAnchorEl2(null);
  };

  // Chart
  const [isChartLoaded, setChartLoaded] = useState(false);

  useEffect(() => {
    setChartLoaded(true);
  }, []);

  const series = [
    {
      name: "Price",
      data: [
        {
          x: new Date(1538778600000),
          y: [6629.81, 6650.5, 6623.04, 6633.33],
        },
        {
          x: new Date(1538780400000),
          y: [6632.01, 6643.59, 6620, 6630.11],
        },
        {
          x: new Date(1538782200000),
          y: [6630.71, 6648.95, 6623.34, 6635.65],
        },
        {
          x: new Date(1538784000000),
          y: [6635.65, 6651, 6629.67, 6638.24],
        },
        {
          x: new Date(1538785800000),
          y: [6638.24, 6640, 6620, 6624.47],
        },
        {
          x: new Date(1538787600000),
          y: [6624.53, 6636.03, 6621.68, 6624.31],
        },
        {
          x: new Date(1538789400000),
          y: [6624.61, 6632.2, 6617, 6626.02],
        },
        {
          x: new Date(1538791200000),
          y: [6627, 6627.62, 6584.22, 6603.02],
        },
        {
          x: new Date(1538793000000),
          y: [6605, 6608.03, 6598.95, 6604.01],
        },
        {
          x: new Date(1538794800000),
          y: [6604.5, 6614.4, 6602.26, 6608.02],
        },
        {
          x: new Date(1538796600000),
          y: [6608.02, 6610.68, 6601.99, 6608.91],
        },
        {
          x: new Date(1538798400000),
          y: [6608.91, 6618.99, 6608.01, 6612],
        },
        {
          x: new Date(1538800200000),
          y: [6612, 6615.13, 6605.09, 6612],
        },
        {
          x: new Date(1538802000000),
          y: [6612, 6624.12, 6608.43, 6622.95],
        },
        {
          x: new Date(1538803800000),
          y: [6623.91, 6623.91, 6615, 6615.67],
        },
        {
          x: new Date(1538805600000),
          y: [6618.69, 6618.74, 6610, 6610.4],
        },
        {
          x: new Date(1538807400000),
          y: [6611, 6622.78, 6610.4, 6614.9],
        },
        {
          x: new Date(1538809200000),
          y: [6614.9, 6626.2, 6613.33, 6623.45],
        },
        {
          x: new Date(1538811000000),
          y: [6623.48, 6627, 6618.38, 6620.35],
        },
        {
          x: new Date(1538812800000),
          y: [6619.43, 6620.35, 6610.05, 6615.53],
        },
        {
          x: new Date(1538814600000),
          y: [6615.53, 6617.93, 6610, 6615.19],
        },
        {
          x: new Date(1538816400000),
          y: [6615.19, 6621.6, 6608.2, 6620],
        },
        {
          x: new Date(1538818200000),
          y: [6619.54, 6625.17, 6614.15, 6620],
        },
        {
          x: new Date(1538820000000),
          y: [6620.33, 6634.15, 6617.24, 6624.61],
        },
        {
          x: new Date(1538821800000),
          y: [6625.95, 6626, 6611.66, 6617.58],
        },
        {
          x: new Date(1538823600000),
          y: [6619, 6625.97, 6595.27, 6598.86],
        },
        {
          x: new Date(1538825400000),
          y: [6598.86, 6598.88, 6570, 6587.16],
        },
        {
          x: new Date(1538827200000),
          y: [6588.86, 6600, 6580, 6593.4],
        },
        {
          x: new Date(1538829000000),
          y: [6593.99, 6598.89, 6585, 6587.81],
        },
        {
          x: new Date(1538830800000),
          y: [6587.81, 6592.73, 6567.14, 6578],
        },
        {
          x: new Date(1538832600000),
          y: [6578.35, 6581.72, 6567.39, 6579],
        },
        {
          x: new Date(1538834400000),
          y: [6579.38, 6580.92, 6566.77, 6575.96],
        },
        {
          x: new Date(1538836200000),
          y: [6575.96, 6589, 6571.77, 6588.92],
        },
        {
          x: new Date(1538838000000),
          y: [6588.92, 6594, 6577.55, 6589.22],
        },
        {
          x: new Date(1538839800000),
          y: [6589.3, 6598.89, 6589.1, 6596.08],
        },
        {
          x: new Date(1538841600000),
          y: [6597.5, 6600, 6588.39, 6596.25],
        },
        {
          x: new Date(1538843400000),
          y: [6598.03, 6600, 6588.73, 6595.97],
        },
        {
          x: new Date(1538845200000),
          y: [6595.97, 6602.01, 6588.17, 6602],
        },
        {
          x: new Date(1538847000000),
          y: [6602, 6607, 6596.51, 6599.95],
        },
        {
          x: new Date(1538848800000),
          y: [6600.63, 6601.21, 6590.39, 6591.02],
        },
        {
          x: new Date(1538850600000),
          y: [6591.02, 6603.08, 6591, 6591],
        },
        {
          x: new Date(1538852400000),
          y: [6591, 6601.32, 6585, 6592],
        },
        {
          x: new Date(1538854200000),
          y: [6593.13, 6596.01, 6590, 6593.34],
        },
        {
          x: new Date(1538856000000),
          y: [6593.34, 6604.76, 6582.63, 6593.86],
        },
        {
          x: new Date(1538857800000),
          y: [6593.86, 6604.28, 6586.57, 6600.01],
        },
        {
          x: new Date(1538859600000),
          y: [6601.81, 6603.21, 6592.78, 6596.25],
        },
        {
          x: new Date(1538861400000),
          y: [6596.25, 6604.2, 6590, 6602.99],
        },
        {
          x: new Date(1538863200000),
          y: [6602.99, 6606, 6584.99, 6587.81],
        },
        {
          x: new Date(1538865000000),
          y: [6587.81, 6595, 6583.27, 6591.96],
        },
        {
          x: new Date(1538866800000),
          y: [6591.97, 6596.07, 6585, 6588.39],
        },
        {
          x: new Date(1538868600000),
          y: [6587.6, 6598.21, 6587.6, 6594.27],
        },
        {
          x: new Date(1538870400000),
          y: [6596.44, 6601, 6590, 6596.55],
        },
        {
          x: new Date(1538872200000),
          y: [6598.91, 6605, 6596.61, 6600.02],
        },
        {
          x: new Date(1538874000000),
          y: [6600.55, 6605, 6589.14, 6593.01],
        },
        {
          x: new Date(1538875800000),
          y: [6593.15, 6605, 6592, 6603.06],
        },
        {
          x: new Date(1538877600000),
          y: [6603.07, 6604.5, 6599.09, 6603.89],
        },
        {
          x: new Date(1538879400000),
          y: [6604.44, 6604.44, 6600, 6603.5],
        },
        {
          x: new Date(1538881200000),
          y: [6603.5, 6603.99, 6597.5, 6603.86],
        },
        {
          x: new Date(1538883000000),
          y: [6603.85, 6605, 6600, 6604.07],
        },
        {
          x: new Date(1538884800000),
          y: [6604.98, 6606, 6604.07, 6606],
        },
      ],
    },
  ];

  const options: ApexOptions = {
    chart: {
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      candlestick: {
        colors: {
          upward: "#EE3E08",
          downward: "#4936F5",
        },
        wick: {
          useFillColor: true,
        },
      },
    },
    xaxis: {
      type: "datetime",
      axisTicks: {
        show: false,
        color: "#ECEEF2",
      },
      axisBorder: {
        show: false,
        color: "#ECEEF2",
      },
      labels: {
        show: true,
        style: {
          colors: "#8695AA",
          fontSize: "12px",
        },
      },
    },
    yaxis: {
      tooltip: {
        enabled: true,
      },
      labels: {
        show: true,
        style: {
          colors: "#64748B",
          fontSize: "12px",
        },
      },
      axisBorder: {
        show: false,
        color: "#ECEEF2",
      },
      axisTicks: {
        show: false,
        color: "#ECEEF2",
      },
    },
    grid: {
      show: true,
      borderColor: "#ECEEF2",
    },
  };

  return (
    <>
      <Card
        sx={{
          position: "relative",
          boxShadow: "none",
          borderRadius: "7px",
          mb: "25px",
        }}
        className="rmui-card border"
      >
        <Box
          sx={{
            display: { md: "flex" },
            alignItems: "center",
            justifyContent: "space-between",
            paddingX: { xs: "15px", sm: "20px", lg: "25px" },
            paddingY: { xs: "15px" },
          }}
          className="border-bottom"
        >
          <Typography
            variant="h3"
            sx={{
              fontSize: { xs: "16px", lg: "15px", xl: "18px" },
              fontWeight: 700,
              mb: { xs: "10px", md: "0" },
            }}
            className="text-black"
          >
            Market Price Statistics
          </Typography>

          <Box
            sx={{
              display: { md: "flex" },
              alignItems: "center",
              gap: "15px",
            }}
          >
            <Box
              className="statistics-buttons-list"
              sx={{
                mb: { xs: "10px", md: "0" },
              }}
            >
              <Button variant="outlined">1H</Button>
              <Button variant="outlined">24H</Button>
              <Button variant="outlined">1W</Button>
              <Button variant="outlined">1M</Button>
              <Button variant="outlined">1Y</Button>
            </Box>

            <Box>
              <IconButton
                onClick={handleClick1}
                size="small"
                aria-controls={open1 ? "dropdown-menu-1" : undefined}
                aria-haspopup="true"
                aria-expanded={open1 ? "true" : undefined}
                sx={{
                  borderRadius: "0px",
                  padding: "1px 2px",
                  fontSize: "14px",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                  }}
                >
                  <Image
                    src="/images/cryptocurrencies/big-bitcoin.svg"
                    alt="bitcoin"
                    width={24}
                    height={24}
                  />

                  <Typography
                    component="span"
                    sx={{
                      display: "block",
                      fontWeight: "600",
                    }}
                  >
                    Bitcoin
                  </Typography>

                  <KeyboardArrowDownIcon sx={{ fontSize: "25px" }} />
                </Box>
              </IconButton>

              <Menu
                anchorEl={anchorEl1}
                id="dropdown-menu-1"
                open={open1}
                onClose={handleClose1}
                onClick={handleClose1}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: "visible",
                    boxShadow: "0 4px 45px #0000001a",
                    mt: 0,
                  },
                }}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
              >
                <MenuItem
                  sx={{
                    fontWeight: "500",
                    gap: "5px",
                  }}
                  className="text-black"
                >
                  <Image
                    src="/images/cryptocurrencies/ethereum.svg"
                    alt="ethereum"
                    width={22}
                    height={22}
                  />

                  <Box>
                    Ethereum{" "}
                    <Typography
                      component="span"
                      sx={{ fontWeight: "400" }}
                      className="text-body"
                    >
                      (ETH)
                    </Typography>
                  </Box>
                </MenuItem>

                <MenuItem
                  sx={{
                    fontWeight: "500",
                    gap: "5px",
                  }}
                  className="text-black"
                >
                  <Image
                    src="/images/cryptocurrencies/bitcoin.svg"
                    alt="bitcoin"
                    width={22}
                    height={22}
                  />

                  <Box>
                    Bitcoin{" "}
                    <Typography
                      component="span"
                      sx={{ fontWeight: "400" }}
                      className="text-body"
                    >
                      (BTC)
                    </Typography>
                  </Box>
                </MenuItem>

                <MenuItem
                  sx={{
                    fontWeight: "500",
                    gap: "5px",
                  }}
                  className="text-black"
                >
                  <Image
                    src="/images/cryptocurrencies/solana.svg"
                    alt="solana"
                    width={22}
                    height={22}
                  />

                  <Box>
                    Solana{" "}
                    <Typography
                      component="span"
                      sx={{ fontWeight: "400" }}
                      className="text-body"
                    >
                      (SOL)
                    </Typography>
                  </Box>
                </MenuItem>

                <MenuItem
                  sx={{
                    fontWeight: "500",
                    gap: "5px",
                  }}
                  className="text-black"
                >
                  <Image
                    src="/images/cryptocurrencies/cardano.png"
                    alt="cardano"
                    width={22}
                    height={22}
                  />

                  <Box>
                    Cardano{" "}
                    <Typography
                      component="span"
                      sx={{ fontWeight: "400" }}
                      className="text-body"
                    >
                      (ADA)
                    </Typography>
                  </Box>
                </MenuItem>

                <MenuItem
                  sx={{
                    fontWeight: "500",
                    gap: "5px",
                  }}
                  className="text-black"
                >
                  <Image
                    src="/images/cryptocurrencies/binance.svg"
                    alt="binance"
                    width={22}
                    height={22}
                  />

                  <Box>
                    Binance{" "}
                    <Typography
                      component="span"
                      sx={{ fontWeight: "400" }}
                      className="text-body"
                    >
                      (BNB)
                    </Typography>
                  </Box>
                </MenuItem>
              </Menu>
            </Box>
          </Box>
        </Box>

        <Box
          sx={{
            padding: { xs: "18px", sm: "20px", lg: "25px" },
          }}
        >
          <Box
            sx={{
              display: { sm: "flex" },
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                mb: { xs: "10px", sm: "0" },
              }}
            >
              <Image
                src="/images/cryptocurrencies/big-bitcoin.svg"
                alt="bitcoin"
                width={48}
                height={48}
              />

              <Box>
                <Typography
                  component="span"
                  sx={{
                    display: "block",
                    textTransform: "uppercase",
                    fontWeight: "500",
                  }}
                >
                  Bitcoin{" "}
                  <Typography
                    component="span"
                    sx={{ fontWeight: "400" }}
                    className="text-body"
                  >
                    (BTC)
                  </Typography>
                </Typography>

                <Typography
                  component="h4"
                  sx={{
                    fontWeight: "600",
                    fontSize: "20px",
                    mt: "5px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                  }}
                >
                  $27,500
                  <Typography
                    component="span"
                    sx={{
                      color: "#1E8308",
                      fontWeight: "500",
                      fontSize: "14px",
                      display: "flex",
                      alignItems: "center",
                      gap: "2px",
                    }}
                  >
                    <i
                      className="bx bx-trending-up"
                      style={{ fontSize: "20px" }}
                    ></i>
                    +2.3%
                  </Typography>
                </Typography>
              </Box>
            </Box>

            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: { xs: "20px", sm: "25px", md: "30px", lg: "40px" },
                mb: { xs: "10px", sm: "0" },
              }}
            >
              <Box
                className="text-black"
                sx={{
                  fontWeight: "600",
                }}
              >
                <Typography
                  component="span"
                  sx={{ fontWeight: "400", display: "block" }}
                  className="text-body"
                >
                  Closing Price
                </Typography>
                $27,200
              </Box>

              <Box
                className="text-black"
                sx={{
                  fontWeight: "600",
                }}
              >
                <Typography
                  component="span"
                  sx={{ fontWeight: "400", display: "block" }}
                  className="text-body"
                >
                  24h Volume
                </Typography>
                $35B
              </Box>
            </Box>

            <Box>
              <IconButton
                onClick={handleClick2}
                size="small"
                aria-controls={open2 ? "dropdown-menu-2" : undefined}
                aria-haspopup="true"
                aria-expanded={open2 ? "true" : undefined}
                sx={{
                  borderRadius: "0px",
                  padding: "1px 2px",
                  fontSize: "14px",
                }}
              >
                <MoreVertIcon sx={{ fontSize: "25px" }} />
              </IconButton>

              <Menu
                anchorEl={anchorEl2}
                id="dropdown-menu-2"
                open={open2}
                onClose={handleClose2}
                onClick={handleClose2}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: "visible",
                    boxShadow: "0 4px 45px #0000001a",
                    width: "150px",
                    mt: 0,
                  },
                }}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
              >
                <MenuItem>View</MenuItem>
                <MenuItem>Block</MenuItem>
                <MenuItem>Delete</MenuItem>
                <MenuItem>Report</MenuItem>
              </Menu>
            </Box>
          </Box>

          <div
            style={{
              marginTop: "15px",
              marginLeft: "-15px",
              marginBottom: "-15px",
            }}
          >
            {isChartLoaded && (
              <Chart
                options={options}
                series={series}
                type="candlestick"
                height={319}
                width={"100%"}
              />
            )}
          </div>
        </Box>
      </Card>
    </>
  );
};

export default MarketPriceStatistics;
