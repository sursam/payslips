<?php

return [
    'SITE_PROFILE_IMAGE_UPLOAD_PATH'            => 'profile/',
    'SITE_BANNER_UPLOAD_PATH'                   => 'banner/',
    'SITE_GALLERY_UPLOAD_PATH'                   => 'gallery/',
    'SITE_TRUCK_IMG_UPLOAD_PATH'                => 'user_truck/',
    'SITE_NEWS_UPLOAD_PATH'                     => 'news/',
    'SITE_CMS_UPLOAD_PATH'                      => 'cms/',
    'SITE_CATEGORY_UPLOAD_PATH'                 => 'category/',
    'SITE_PRODUCT_UPLOAD_PATH'                  => 'product/',
    'SITE_DESTINATION_UPLOAD_PATH'                  => 'destination/',
    'SITE_SubDestination_UPLOAD_PATH'                  => 'sub_destination/',
    'SITE_ACTIVITY_UPLOAD_PATH'                  => 'activity/',
    'SITE_COUPON_UPLOAD_PATH'                  => 'coupons/',
    'SITE_ADMINISTRATION_UPLOAD_PATH'                  => 'administration/',
    'SITE_AMENITIE_UPLOAD_PATH'                  => 'amenitie/',
    'SITE_PROPERTY_UPLOAD_PATH'                  => 'property/',
    'SITE_APP_INTRO_UPLOAD_PATH'                  => 'appintro/',
    'SITE_CMS_UPLOAD_PATH'                  => 'cms/',
    'SITE_DASHBOARD_BANNER_UPLOAD_PATH'                  => 'dashboard_banner/',
    'SITE_TRUCK_TYPE_UPLOAD_PATH'                  => 'truck_type/',
    'SITE_HOMEPAGE_BANNER_UPLOAD_PATH'                  => 'homepage_banner/',
    'SITE_SERVICE_UPLOAD_PATH'                  => 'service/',
    'CATCH_ERROR_MSG'                           => "Can you check the parameters",
    'DEFAULT_DISTANCE_BETWEEN_USER_AND_JOBS'    => 48.28, // In Kilometer
    'SITE_CHALLAN_IMAGE_UPLOAD_PATH'            => 'challan/',
    'SITE_SIGNATURE_IMAGE_UPLOAD_PATH'            => 'signature/',
];
