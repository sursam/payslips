<?php
return [
        'type' => ['General','Haul-Off'],
        'tags' => ['{{username}}','{{link}}']
    ]
?>
