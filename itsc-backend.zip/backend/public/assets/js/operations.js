$.ajaxSetup({
    headers: {
        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
    },
});

$("form.formSubmit").on("submit", function (e) {
    // alert('ok');
    e.preventDefault();
    var $this = $(this);
    var formActionUrl = $this.prop("action");


    const submitButton = this.querySelector('button[type="submit"]');
    //submitButton.setAttribute("data-kt-indicator", "on");
    //submitButton.disabled = true;

    if ($($this).hasClass("fileUpload")) {
        var fd = new FormData(document.getElementById($($this).attr("id")));
    } else {
        var fd = $($this).serialize();
    }
    let commonOption = {
        type: "post",
        url: formActionUrl,
        data: fd,
        dataType: "json",
    };
    if ($($this).hasClass("fileUpload")) {
        commonOption["cache"] = false;
        commonOption["processData"] = false;
        commonOption["contentType"] = false;
    }
    $.ajax({
        ...commonOption,
        success: function (response) {
            console.log('in success' + response);
            
            if (response.status === true) {

                if (response.url) {

                    toastr.success(response.message);
                    setTimeout(() => {
                        $(location).attr("href", response.url);
                    }, 1500);
                } else {
                    toastr.success(response.message);
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                }
            } else {
                console.log("here" + response);
                
                toastr.error(response.message);
            }
        },
        error: function (response) {
            console.log('in error' + response);
            let responseJSON = response.responseJSON;
            console.log(responseJSON);
            
            $(".err_message").removeClass("d-block").hide();
            $("form .form-control").removeClass("is-invalid");
            $.each(responseJSON.errors, function (index, valueMessage) {
                toastr.warning(valueMessage);
                $(`#${index}`).addClass("is-invalid");
                // $(`#${index}`).after(
                //     `<p class='d-block text-danger err_message'> ${valueMessage}</p>`
                // );
            });
        },
    });
});

$(".table").on("click", ".forceLogout", function (e) {

    const actionUrl = baseUrl + "/admin/user/force-logout";
    var $this = $(this);
    var uuid = $this.data("uuid");
    Swal.fire({
        title: "Are you sure you want to Logout?",
        text: "You wont be able to revert this action!!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Logout it!",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "get",
                url: actionUrl,
                data: { uuid: uuid},
                cache: false,
                dataType: "json",
                beforeSend: function () {},
                success: function (response) {
                    if (response.status) {
                        // Swal.fire({
                        //     icon: "success",
                        //     title: "Deleted Successfully",
                        //     showConfirmButton: false,
                        //     timer: 1500,
                        // });
                        toastr.success("Log out Successfully");
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        // Swal.fire({
                        //     icon: "error",
                        //     title: "We are facing some technical issue now",
                        //     showConfirmButton: false,
                        //     timer: 2000,
                        // });
                        toastr.error("We are facing some technical issue now");
                    }
                },
                error: function (response) {
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "We are facing some technical issue now. Please try again after some time",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.error(
                        "We are facing some technical issue now. Please try again after some time"
                    );
                },
            });
        }
    });
});

$(".table").on("click", ".deleteData", function (e) {
    const actionUrl = baseUrl + "/ajax/delete/data";
    var $this = $(this);
    var uuid = $this.data("uuid");
    var find = $this.data("table");
    Swal.fire({
        title: "Are you sure you want to delete it?",
        text: "You wont be able to revert this action!!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "delete",
                url: actionUrl,
                data: { uuid: uuid, find: find },
                cache: false,
                dataType: "json",
                beforeSend: function () {},
                success: function (response) {
                    if (response.status) {
                        // Swal.fire({
                        //     icon: "success",
                        //     title: "Deleted Successfully",
                        //     showConfirmButton: false,
                        //     timer: 1500,
                        // });
                        toastr.success("Deleted Successfully");
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        // Swal.fire({
                        //     icon: "error",
                        //     title: "We are facing some technical issue now",
                        //     showConfirmButton: false,
                        //     timer: 2000,
                        // });
                        toastr.error("We are facing some technical issue now");
                    }
                },
                error: function (response) {
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "We are facing some technical issue now. Please try again after some time",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.error(
                        "We are facing some technical issue now. Please try again after some time"
                    );
                },
            });
        }
    });
});

$(".table").on("click", ".isVerified", function (e) {
    e.preventDefault();
    const uuid = $(this).attr("data-uuid");
    const find = $(this).attr("data-table");
    const action = baseUrl + "/ajax/status/change";
    Swal.fire({
        title: "Are you sure you want to change it?",
        text: "The status will be changed",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Change it!",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: action,
                method: "POST",
                data: {
                    status: this.value == 0 ? 1 : 0,
                    uuid: uuid,
                    find: find,
                },
                async: false,
                success: function (data) {
                    // Swal.fire({
                    //     icon: "success",
                    //     title: "Status Changed Successfully",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.success("Status Changed Successfully");
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                },
                error: function (response) {
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "We are facing some technical issue now. Please try again after some time",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.error(
                        "We are facing some technical issue now. Please try again after some time"
                    );
                },
            });
        }
    });
});

     $(document).on('click', '.deleteDatarole', function (e) {
        deleteDataNOtTable($(this));
    });
    function deleteDataNOtTable(selector) {
    var $this = selector;
    var uuid = $this.data('uuid');
    var find = 'roles';
    var message = $this.data('message') ?? 'test message';
    Swal.fire({
        title: 'Are you sure you want to delete it?',
        text: 'You wont be able to revert this action!!',
        icon: 'warning',
        width: '350px',
        allowOutsideClick: false,
        showCancelButton: true,
        confirmButtonColor: '#1D9300',
        cancelButtonColor: '#F90F0F',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "delete",
                url: baseUrl + 'ajax/deleteData',
                data: { 'uuid': uuid, 'find': find },
                cache: false,
                dataType: "json",
                beforeSend: function () {

                },
                success: function (response) {
                    if (response.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Deleted Successfully',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        location.reload();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'We are facing some technical issue now.',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                },
                error: function (response) {
                    Swal.fire({
                        icon: 'error',
                        title: 'We are facing some technical issue now. Please try again after some time',
                        showConfirmButton: false,
                        timer: 1500
                    })
                }
                /* ,
                complete: function(response){
                    location.reload();
                } */
            });
        }
    });
}

$(".table").on("click", ".isReady", function (e) {
    e.preventDefault();
    const uuid = $(this).attr("data-uuid");
    const find = $(this).attr("data-table");
    const action = baseUrl + "/ajax/approvedstatus/change";
    Swal.fire({
        title: "Are you sure you want to change it?",
        text: "",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Change it!",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: action,
                method: "POST",
                data: {
                    status: this.value == 0 ? 1 : 0,
                    uuid: uuid,
                    find: find,
                },
                async: false,
                success: function (data) {

                    toastr.success("Successfully");
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                },
                error: function (response) {
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "We are facing some technical issue now. Please try again after some time",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.error(
                        "We are facing some technical issue now. Please try again after some time"
                    );
                },
            });
        }
    });
});



$(".table").on("click", ".isApproved", function (e) {
    e.preventDefault();
    const uuid = $(this).attr("data-uuid");
    const stat = $(this).attr("data-stat");
    const action = baseUrl + "/ajax/approved-status/change";
    Swal.fire({
        title: "Are you sure you want to change it?",
        text: "",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Change it!",
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: action,
                method: "POST",
                data: {
                    uuid: uuid,
                    stat: stat,
                },
                async: false,
                success: function (data) {

                    toastr.success("Successfully");
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                },
                error: function (response) {
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "We are facing some technical issue now. Please try again after some time",
                    //     showConfirmButton: false,
                    //     timer: 1500,
                    // });
                    toastr.error(
                        "We are facing some technical issue now. Please try again after some time"
                    );
                },
            });
        }
    });
});
