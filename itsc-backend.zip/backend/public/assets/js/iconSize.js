document.addEventListener('DOMContentLoaded', () => {
    let resizeImage = (file, desiredWidth, desiredHeight) => {
        return new Promise(resolve => {
            let reader = new FileReader();

            reader.readAsDataURL(file);

            reader.onload = (e) => {
                let img = new Image();
                img.src = e.target.result;
                img.onload = function () {
                    let canvas = document.createElement('canvas');
                    let ctx = canvas.getContext('2d');

                    // Set the desired width and height to 24px
                    canvas.width = desiredWidth;
                    canvas.height = desiredHeight;

                    // Draw the image onto the canvas
                    ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, canvas.width, canvas.height);
                    let dataurl = canvas.toDataURL(file.type);
                    resolve(dataurl);
                };
            };
        });
    };

    let uploadImage = (e) => {
        e.stopPropagation();
        e.preventDefault();
        let file = e.target.files[0] || e.dataTransfer.files[0];

        // Set both desired width and height to 24px
        let desiredWidth = 24;  // Width in pixels
        let desiredHeight = 24; // Height in pixels

        resizeImage(file, desiredWidth, desiredHeight).then(response => {
            document.getElementById('output').src = response;
        });
    };

    document.getElementById('fileInput').addEventListener('change', uploadImage);
});
