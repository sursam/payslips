

function formatDate(date) {
    return date.toISOString().split('T')[0];
}
const today = new Date();

document.getElementById('to_date_booking_checking').value = formatDate(today);
const fromDate = new Date();
fromDate.setDate(today.getDate() - 15);
document.getElementById('from_date_booking_checking').value = formatDate(fromDate);
document.getElementById('from_date_booking_checking').addEventListener('change', function () {
    const fromDateValue = new Date(this.value);
    const toDateInput = document.getElementById('to_date_booking_checking');
    toDateInput.value = '';
    toDateInput.min = this.value;
});

document.getElementById('to_date').value = formatDate(today);
const fromDate1 = new Date();
fromDate1.setDate(today.getDate() - 5);
document.getElementById('from_date').value = formatDate(fromDate1);
document.getElementById('from_date').addEventListener('change', function () {
    const fromDateValue1 = new Date(this.value);
    const toDateInput1 = document.getElementById('to_date');
    toDateInput1.value = '';
    toDateInput1.min = this.value;
});


let chartRoot;
function initializeChartForBookingCheckin(data) {

    const chartDiv = document.getElementById("chartdiv");
    while (chartDiv.firstChild) {
        chartDiv.removeChild(chartDiv.firstChild);
    }

    if (chartRoot) {
        chartRoot.dispose();
    }

    am5.ready(function () {
        chartRoot = am5.Root.new("chartdiv");
        chartRoot.setThemes([
            am5themes_Animated.new(chartRoot)
        ]);

        var chart = chartRoot.container.children.push(am5xy.XYChart.new(chartRoot, {
            panX: false,
            panY: false,
            paddingLeft: 0,
            wheelX: "panX",
            wheelY: "zoomX",
            layout: chartRoot.verticalLayout
        }));

        var legend = chart.children.push(
            am5.Legend.new(chartRoot, {
                centerX: am5.p50,
                x: am5.p50
            })
        );

        var xRenderer = am5xy.AxisRendererX.new(chartRoot, {
            cellStartLocation: 0.1,
            cellEndLocation: 0.9,
            minorGridEnabled: true
        });

        var xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(chartRoot, {
            categoryField: "date",
            renderer: xRenderer,
            tooltip: am5.Tooltip.new(chartRoot, {})
        }));

        xRenderer.grid.template.setAll({
            location: 1
        });

        xAxis.data.setAll(data); // Set data for xAxis

        var yAxis = chart.yAxes.push(am5xy.ValueAxis.new(chartRoot, {
            renderer: am5xy.AxisRendererY.new(chartRoot, {
                strokeOpacity: 0.1
            })
        }));

        // Add series
        function makeSeries(name, fieldName) {
            var series = chart.series.push(am5xy.ColumnSeries.new(chartRoot, {
                name: name,
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: fieldName,
                categoryXField: "date"
            }));

            series.columns.template.setAll({
                tooltipText: "{name}, {categoryX}:{valueY}",
                width: am5.percent(90),
                tooltipY: 0,
                strokeOpacity: 0
            });

            series.data.setAll(data); // Set data for the series

            // Make stuff animate on load
            series.appear();

            series.bullets.push(function () {
                return am5.Bullet.new(chartRoot, {
                    locationY: 0,
                    sprite: am5.Label.new(chartRoot, {
                        text: "{valueY}",
                        fill: chartRoot.interfaceColors.get("alternativeText"),
                        centerY: 0,
                        centerX: am5.p50,
                        populateText: true
                    })
                });
            });

            legend.data.push(series);
        }

        makeSeries("Booking Checkin", "booking_checkin_count");
        makeSeries("Check In", "checkin_count");
        makeSeries("Booking Checkout", "booking_checkout_count");
        makeSeries("Check Out", "checkout_count");
    });
}


let chartRoot1; // Declare chartRoot1 at the top level

function initializeChartForIncomeExpance(data1) {
    const chartDiv1 = document.getElementById("chartdiv1");

    // Clear previous chart
    while (chartDiv1.firstChild) {
        chartDiv1.removeChild(chartDiv1.firstChild);
    }

    // Dispose of the existing chart if it exists
    if (chartRoot1) {
        chartRoot1.dispose();
        chartRoot1 = null; // Clear reference
    }

    am5.ready(function() {
        // Use the top-level chartRoot1
        chartRoot1 = am5.Root.new("chartdiv1");

        // Set themes
        chartRoot1.setThemes([
            am5themes_Animated.new(chartRoot1)
        ]);

        // Create chart
        var chart = chartRoot1.container.children.push(am5xy.XYChart.new(chartRoot1, {
            panX: true,
            panY: true,
            wheelX: "panX",
            wheelY: "zoomY",
            paddingLeft: 0,
            layout: chartRoot1.verticalLayout
        }));

        // Create axes
        var yAxis = chart.yAxes.push(am5xy.CategoryAxis.new(chartRoot1, {
            categoryField: "date",
            renderer: am5xy.AxisRendererY.new(chartRoot1, {
                inversed: true,
                cellStartLocation: 0.1,
                cellEndLocation: 0.9,
                minorGridEnabled: true
            })
        }));

        yAxis.data.setAll(data1);

        var xAxis = chart.xAxes.push(am5xy.ValueAxis.new(chartRoot1, {
            renderer: am5xy.AxisRendererX.new(chartRoot1, {
                strokeOpacity: 0.1,
                minGridDistance: 50
            }),
            min: 0
        }));

        // Function to create series
        function createSeries(field, name) {
            var series = chart.series.push(am5xy.ColumnSeries.new(chartRoot1, {
                name: name,
                xAxis: xAxis,
                yAxis: yAxis,
                valueXField: field,
                categoryYField: "date",
                sequencedInterpolation: true,
                tooltip: am5.Tooltip.new(chartRoot1, {
                    pointerOrientation: "horizontal",
                    labelText: "[bold]{name}[/]\n{categoryY}: {valueX}"
                })
            }));

            series.columns.template.setAll({
                height: am5.p100,
                strokeOpacity: 0
            });

            series.bullets.push(function() {
                return am5.Bullet.new(chartRoot1, {
                    locationX: 1,
                    locationY: 0.5,
                    sprite: am5.Label.new(chartRoot1, {
                        centerY: am5.p50,
                        text: "{valueX}",
                        populateText: true
                    })
                });
            });

            series.bullets.push(function() {
                return am5.Bullet.new(chartRoot1, {
                    locationX: 1,
                    locationY: 0.5,
                    sprite: am5.Label.new(chartRoot1, {
                        centerX: am5.p100,
                        centerY: am5.p50,
                        text: "{name}",
                        fill: am5.color(0xffffff),
                        populateText: true
                    })
                });
            });

            series.data.setAll(data1);
            series.appear();
        }

        // Create series for income and expenses
        createSeries("income", "Income");
        createSeries("expenses", "Expenses");

        // Add legend
        var legend = chart.children.push(am5.Legend.new(chartRoot1, {
            centerX: am5.p50,
            x: am5.p50
        }));

        legend.data.setAll(chart.series.values);

        // Add cursor
        var cursor = chart.set("cursor", am5xy.XYCursor.new(chartRoot1, {
            behavior: "zoomXY"
        }));

        // Animate chart on load
        chart.appear(1000, 100);
    });
}







