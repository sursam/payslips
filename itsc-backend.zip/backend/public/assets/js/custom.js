// Stellar Nav
jQuery(document).ready(function($) {
    jQuery('.stellarnav').stellarNav({
        theme: 'light',
        breakpoint: 575,
        position: 'right',
        // phoneBtn: '18009997788',
        // locationBtn: 'https://www.google.com/maps'
    });
});

// Sticky Header Script
var header = document.querySelector('.header');
onScroll = () => {
  var scrolledPage = Math.round(window.pageYOffset);
  if(scrolledPage > 60) {
    header.classList.add('sticky');
  } else {
    header.classList.remove('sticky');
  }
}
document.addEventListener('scroll', onScroll); 

//
window.addEventListener('load', function() {
    const boxes = document.querySelectorAll('.product-box .tham');
    let maxHeight = 0;

    // Reset heights
    boxes.forEach(box => {
        box.style.height = 'auto'; // Reset height to auto to get natural height
    });

    // Find the maximum height
    boxes.forEach(box => {
        maxHeight = Math.max(maxHeight, box.offsetHeight);
    });

    // Set all boxes to the maximum height
    boxes.forEach(box => {
        box.style.height = `${maxHeight}px`;
    });
});

window.addEventListener('load', function() {
    const boxes = document.querySelectorAll('.about-equal');
    let maxHeight = 0;

    // Reset heights
    boxes.forEach(box => {
        box.style.height = 'auto'; // Reset height to auto to get natural height
    });

    // Find the maximum height
    boxes.forEach(box => {
        maxHeight = Math.max(maxHeight, box.offsetHeight);
    });

    // Set all boxes to the maximum height
    boxes.forEach(box => {
        box.style.height = `${maxHeight}px`;
    });
});

window.addEventListener('load', function() {
    const boxes = document.querySelectorAll('.equal-icon');
    let maxHeight = 0;

    // Reset heights
    boxes.forEach(box => {
        box.style.height = 'auto'; // Reset height to auto to get natural height
    });

    // Find the maximum height
    boxes.forEach(box => {
        maxHeight = Math.max(maxHeight, box.offsetHeight);
    });

    // Set all boxes to the maximum height
    boxes.forEach(box => {
        box.style.height = `${maxHeight}px`;
    });
});

//Owl Carousel
$('#banner-slider').owlCarousel({
    loop: true,
    autoplay:false,
    autoplayTimeout:3000,
    margin: 0,
    dots: true,
    nav: false,
    items: 1,
})


//Product slider
$('#self-care-product-slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots:false,
    navText: [
        '<i class="fa-solid fa-arrow-left"></i>',
        '<i class="fa-solid fa-arrow-right"></i>'
    ],
    navContainer: '#self-care-customNav',
    responsive:{
        0:{
            items: 2,
            margin: 10,
        },
        600:{
            items: 2,
            margin: 15,
        },
        1000:{
            items: 4
        }
    }
});

$('#stressRreduction-slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots:false,
    navText: [
        '<i class="fa-solid fa-arrow-left"></i>',
        '<i class="fa-solid fa-arrow-right"></i>'
    ],
    navContainer: '#stressRreduction-customNav',
    responsive:{
        0:{
            items: 2,
            margin: 10,
        },
        600:{
            items: 2,
            margin: 15,
        },
        1000:{
            items: 4
        }
    }
});

$('#motivational-slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots:false,
    navText: [
        '<i class="fa-solid fa-arrow-left"></i>',
        '<i class="fa-solid fa-arrow-right"></i>'
    ],
    navContainer: '#motivational-customNav',
    responsive:{
        0:{
            items: 2,
            margin: 10,
        },
        600:{
            items: 2,
            margin: 15,
        },
        1000:{
            items: 4
        }
    }
});




// AOS Js
AOS.init({
    easing: 'ease-in-out-sine'
  });

// Go to Top
$(function () {
// Scroll Event
$(window).on("scroll", function () {
    var scrolled = $(window).scrollTop();
    if (scrolled > 600) $(".go-top").addClass("active");
    if (scrolled < 600) $(".go-top").removeClass("active");
});
// Click Event
$(".go-top").on("click", function () {
    $("html, body").animate({ scrollTop: "0" }, 500);
});
});




$(document).ready(function() {
    $('#close-btn').click(function() {
        $('#search-overlay').fadeOut();
        $('#search-btn').show();
        $('body').css('overflow', ''); // Reset body overflow
    });
    
    $('#search-btn').click(function() {
        // $(this).hide();
        $('#search-overlay').fadeIn();
        $('body').css('overflow', 'hidden'); // Prevent body scrolling
    });
});



//Home about sec video js
// Get a reference to the video element
const video = document.getElementById('myVideo');

// Play the video on page load
video.play();

// Set the video to loop
video.addEventListener('ended', function() {
video.currentTime = 0;
video.play();
}, false);



