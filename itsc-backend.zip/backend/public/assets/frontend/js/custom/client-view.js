ZoomMtg.preLoadWasm();
ZoomMtg.prepareWebSDK();

var authEndpoint = signatureUrl;
var sdkKey = "B52PBpBVTbLPPToqO095tvX375FVkfwIZTi8";
var meetingNumber = 73325016976;
var passWord = "";
var role = 1;
var userName = "Test Suman";
var userEmail = "suman.sgn@gmail.com";
var registrantToken = "";
var zakToken = "";
var leaveUrl = "https://zoom.us";

/*
function getSignature() {
    fetch(authEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            meetingNumber: meetingNumber,
            role: role,
        }),
    }).then((response) => {
        return response.json();
    }).then((data) => {
        console.log(data);
        startMeeting(data.signature);
    }).catch((error) => {
        console.log(error);
    });
}
*/
const meetingConfig = {
    topic: 'My Meeting',
    startTime: '2024-09-12T14:30:00Z',
    duration: 30,
};
function createmeeting(){
    $.get(createMeetingUrl, function (data) {
        console.log(data);

    })
    /*
    ZoomMtg.createMeeting(meetingConfig).then((res) => {const meetingId = res.meetingId;
        console.log(`Meeting created with ID: ${meetingId}`);
    }).catch((error) => {
        console.error(`Error creating meeting: ${error}`);
    });
    */
}
async function getSignature() {
    // createmeeting();
    fetch(authEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            '_token':token,
            meetingNumber: meetingNumber,
            role: role,
        }),
    }).then((response) => {
        console.log(response);

        return response.text(); // Change to text to see the raw response
    }).then((data) => {
        console.log(data); // Log raw response
        try {
            const jsonData = JSON.parse(data); // Attempt to parse as JSON
            startMeeting(jsonData.signature);
        } catch (e) {
            console.error("Parsing error:", e);
        }
    }).catch((error) => {
        console.log(error);
    });
}

function startMeeting(signature) {
// function startMeeting() {
    document.getElementById("zmmtg-root").style.display = "block";
    let url = new URL(location.href);
    ZoomMtg.init({
        leaveUrl: leaveUrl,
        patchJsMedia: true,
        leaveOnPageUnload: true,
        success: (success) => {
            console.log(success);
            ZoomMtg.join({
                signature: signature,
                sdkKey: sdkKey,
                meetingNumber: meetingNumber,
                passWord: passWord,
                userName: userName,
                userEmail: userEmail,
                tk: registrantToken,
                zak: zakToken,
                success: (success) => {
                    console.log(success);
                },
                error: (error) => {
                    console.log(error);
                },
            });
        },
        error: (error) => {
            console.log(error);
        },
    });
}
