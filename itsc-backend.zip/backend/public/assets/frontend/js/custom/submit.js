
$("form.formSubmit,form.arrayFormSubmit").on("submit", function (e) {
    e.preventDefault();
    var $this = $(this);
    if ($this.hasClass("showBtnLoader")) {
        $this.find('.btn').append('&nbsp;<i class="fa fa-spinner fa-spin"></i>');
    }
    var formActionUrl = $this.prop("action");
    var fd = $this.hasClass("fileUpload") ? new FormData(document.getElementById($this.attr("id"))) : $this.serialize();

    let commonOption = {
        type: "post",
        url: formActionUrl,
        data: fd,
        dataType: "json",
    };
    if ($this.hasClass("fileUpload")) {
        commonOption["cache"] = false;
        commonOption["processData"] = false;
        commonOption["contentType"] = false;
    }
    $.ajax({
        ...commonOption,
        beforeSend: function () {
           // showLoader();
        },
        success: function (response) {
            console.log(response);
            btnLoad($this);

            if (response.success) { // Check for success key
                Swal.fire({
                    icon: "success",
                    title: response.message,
                    showConfirmButton: false,
                    timer: 1500,
                }).then(() => {
                    if (response.data && response.data.redirect_url) { // Check for redirect_url
                        window.location.replace(response.data.redirect_url);
                    } else {
                        // Handle other data if needed
                        if (response.data.fromsubmit === 'web-personal') {
                            customeAfterSubmitPersonal(response.data);
                        } else {
                            customeAfterSubmit(response.data);
                        }
                    }
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: response.message
                });
            }
        },
        error: function (response) {
            let responseJSON = response.responseJSON;
            console.log(responseJSON);
            btnLoad($this);
            if (responseJSON && (responseJSON.response_code === 422 || responseJSON.response_code === 500)) {
                let resdata = responseJSON.data;
                console.log(responseJSON.response_code);

                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: responseJSON.message
                });
                handleValidationErrors(resdata, $this);
            } else {
                handleGeneralErrors(responseJSON, $this);
            }
        },
        complete: function() {
            if ($this.hasClass("showBtnLoader")) {
                btnLoad($this);
            }
           // hideLoader();
        }
    });
    return false;
});

function handleValidationErrors(resdata, $form) {
    if (resdata.hasOwnProperty('mobile_number') || resdata.hasOwnProperty('first_name') ||
        resdata.hasOwnProperty('last_name') || resdata.hasOwnProperty('email_id')) {
        toggleLoginSections('reg1');
    }
    if (resdata.hasOwnProperty('role') || resdata.hasOwnProperty('gender') ||
        resdata.hasOwnProperty('your_age') || resdata.hasOwnProperty('spoken_lang')) {
        toggleLoginSections('reg2');
    }
    if (resdata.hasOwnProperty('password') || resdata.hasOwnProperty('confirm_passowrd') ||
        resdata.hasOwnProperty('profile_image') || resdata.hasOwnProperty('spoken_lang')) {
        toggleLoginSections('reg3');
    }
    $(".err_message").removeClass("d-block").remove();
    $("form .form-control").removeClass("is-invalid");
    $.each(resdata, function (index, valueMessage) {
        if ($form.hasClass('arrayFormSubmit')) {
            let indexArray = index.split('.');
            $("#" + indexArray[0] + "_" + indexArray[1]).addClass('is-invalid').after("<p class='d-block text-danger err_message'>" + valueMessage + "</p>");
        } else {
            $("#" + index).addClass("is-invalid");
            $("#" + index).after("<p class='d-block text-danger err_message'>" + valueMessage + "</p>");
        }
        if ($form.closest('.modal').length > 0) {
            $form.closest('.modal').modal('show');
        }
    });
}

function handleGeneralErrors(responseJSON, $form) {
    $(".err_message").removeClass("d-block").remove();
    $("form .form-control").removeClass("is-invalid");
    $.each(responseJSON.errors, function (index, valueMessage) {
        if ($form.hasClass('arrayFormSubmit')) {
            let indexArray = index.split('.');
            $("#" + indexArray[0] + "_" + indexArray[1]).addClass('is-invalid').after("<p class='d-block text-danger err_message'>" + valueMessage + "</p>");
        } else {
            $("#" + index).addClass("is-invalid");
            $("#" + index).after("<p class='d-block text-danger err_message'>" + valueMessage + "</p>");
        }
        if ($form.closest('.modal').length > 0) {
            $form.closest('.modal').modal('show');
        }
    });
}

function toggleLoginSections(sectionClass) {
    $('.login').each(function() {
        $(this).addClass('dnone');
        if ($(this).hasClass(sectionClass)) {
            $(this).removeClass('dnone');
        }
    });
}
function btnLoad($this){
    if($this.find('.btn').find('i').length > 0){
        $this.find('.btn').find('i').remove();
    }
}

function customeAfterSubmit(data){
    if(data.last_inserted_id != undefined){
        $('.cardul').find('a.disabledtab').each(function(){
            $(this).removeAttr('disabled');
        });
    }
    $('#'+data.next_tab_id+'-tabs').find('#lastid').val(data.last_inserted_id);
    $('#'+data.next_tab_id+'-tabs').addClass('show active');
    $('#'+data.next_tab_id+'-tab').addClass('active');
    $('#'+data.next_tab_id+'-tab').parent('a').trigger('click');
    $('#'+data.tab_id+'-tab').addClass('dnone');
    $('#'+data.tab_id+'-tab').removeClass('active');
    $('#'+data.tab_id+'-tabs').removeClass('show active');
}
function customeAfterSubmitPersonal(data){
    $('.'+data.next_tab_id+'-tabs').addClass('show active');
    $('.'+data.next_tab_id+'-tab').addClass('active');
    $('.'+data.tab_id+'-tabs').addClass('dnone');
    $('.'+data.tab_id+'-tabs').removeClass('show active');
    $('.'+data.next_tab_id+'-tabs').find('#lastid').val(data.last_inserted_id);
}
