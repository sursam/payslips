$(".changeStatus").click(function () {
    var id = $(this).attr("data-id");
    var status = $(this).attr("data-status");
    var value = $(this).attr("data-value");
    var action = $(this).attr("data-action");
    if (status == 1) {
        Swal.fire({
            title: "Are You Sure?",
            text: "If you cancel this order, cancellation charges will be applied.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes",
        }).then((result) => {
            if (result.isConfirmed) {
                var id = $(this).attr("data-id");
                var status = $(this).attr("data-status");
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                $.ajax({
                    type: "post",
                    url : action,
                    data: {
                        id: id,
                        status: value,
                    },
                    success: function (response) {
                        if (response) {
                            Swal.fire(
                                "Order Canceled!",
                                "Order Canceled successfully",
                                "success"
                            );
                            location.reload();
                        }
                    },
                });
            }
        });
    }
    // else {
    //     Swal.fire({
    //         title: "Do you want to approved it?",
    //         icon: "warning",
    //         showCancelButton: true,
    //         confirmButtonColor: "#3085d6",
    //         cancelButtonColor: "#d33",
    //         confirmButtonText: "Yes",
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             var value = $(this).attr("data-value");
    //             var id = $(this).attr("data-id");
    //             var status = $(this).attr("data-status");
    //             $.ajaxSetup({
    //                 headers: {
    //                     "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
    //                         "content"
    //                     ),
    //                 },
    //             });
    //             $.ajax({
    //                 type: "post",
    //                 url : action,
    //                 data: {
    //                     id: id,
    //                     status: value,
    //                 },
    //                 success: function (response) {
    //                     if (response) {
    //                         Swal.fire("Approved!", response.message, "success");
    //                         location.reload();
    //                     }
    //                 },
    //             });
    //         }
    //     });
    // }
});
