// JavaScript Document
'use strict';
// var baseUrl = APP_URL + '/';
var pagetype = jQuery('input[name="pagetype"]').val();
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$(window).on('load', function () {
    if ($('#preloader').length){
        setTimeout(() => {
            $('#preloader').hide();
        }, 200);
    }
});

$(document).ready(function () {
    if ($('.datepicker').length) {
        $('.datepicker').datepicker({ dateFormat: 'yy-mm-dd', placeHolder: 'yy-mm-dd',  changeYear: true,
        yearRange: "1950:2023" });
    }
});


$(".show_hide_password span").on('click', function (event) {
    event.preventDefault();
    var $this = $(this).closest('.show_hide_password');
    var type = $this.find('input').attr("type");
    if (type == "text") {
        $this.find('input').attr('type', 'password');
        $this.find('a i').attr("class", "fa fa-eye-slash");
        $this.find('svg').attr('data-icon', 'eye-slash');
    } else if (type == "password") {
        console.log($this.find('a i').length);
        $this.find('input').attr('type', 'text');
        $this.find('a i').attr("class", "fa fa-eye");
        $this.find('svg').attr('data-icon', 'eye');
    }
});

$(".custom-file-input").on("change", function () {
    var fileName = $(this).val().split("\\").pop();
    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});

$('.showOnUpload').change(function () {
    let location= $(this).data('location');
    $('#'+location).prop('src', URL.createObjectURL(this.files[0]));
});

$('.showMultipleOnUpload').change(function () {
    $('#showMultipleOnUpload').html('');
    var filesAmount = this.files.length;
    var i;
    for (i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = function (event) {
            $($.parseHTML('<img>')).attr({ 'src': event.target.result, 'width': 200, 'height': 200 }).addClass('img-fluid img-thumbnail m-2').appendTo('#showMultipleOnUpload');
            $
        }
        reader.readAsDataURL(this.files[i]);
    }
    // $('#showOnUpload').prop('src',URL.createObjectURL(this.files[0]));
});
$(document).ready(function (e) {
    $(document).on("change", ".getPopulate", function () {
        var optHtml = '<option value="">Select a ' + $(this).data('message') + '</option>';
        if ($(this).val() != '') {
            populateData($(this));
        } else {
            $('.' + $(this).data('location')).html('').html(optHtml);
        }
    });
    if ($('.getPopulate').length && $('.getPopulate').val()) {
        $('.getPopulate').trigger('change');
    }



    $(document).on('click', '.statusChange', function (e) {
        changeStatus($(this));
    });

    $(document).on('click', '.deleteData', function (e) {
        deleteData($(this));
    });
    $('.customdatatable').on('click', '.changeStatus', function (e) {
        changeStatus($(this));
    });
    $('.customdatatable').on('click', '.deleteData', function (e) {
        deleteData($(this));
    });

    $('.deleteDocument').on('click', function (e) {
        var $this = $(this);
        var uuid = $this.data('uuid');
        var find = $this.data('table');
        Swal.fire({
            title: 'Are you sure you want to delete it?',
            text: 'You wont be able to revert this action!!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "delete",
                    url: baseUrl + 'ajax/deleteData',
                    data: { 'uuid': uuid, 'find': find },
                    cache: false,
                    dataType: "json",
                    beforeSend: function () {

                    },
                    success: function (response) {
                        if (response.status) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted Successfully',
                                showConfirmButton: false,
                                timer: 1500
                            })
                            location.reload();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'We are facing some technical issue now.',
                                showConfirmButton: false,
                                timer: 1500
                            })
                        }
                    },
                    error: function (response) {
                        Swal.fire({
                            icon: 'error',
                            title: 'We are facing some technical issue now. Please try again after some time',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                    /* ,
                    complete: function(response){
                        location.reload();
                    } */
                });
            }
        });
    });

    $('.customdatatable').on('click', '.changeUserStatus,.changePaymentStatus', function (e) {
        var $this = $(this);
        var state = $this.prop('checked') == true ? 1 : 0;
        var uuid = $this.data('uuid');
        if ($this.hasClass('changeUserStatus')) {
            var value = {
                'is_active': state
            };
        } else if ($this.hasClass('changePaymentStatus')) {
            var value = {
                'is_paid': state
            };
        } else {
            var value = {
                'is_blocked': state
            };
        }
        var find = $this.data('table');
        var message = $this.data('message') ?? 'test message';
        Swal.fire({
            title: 'Are you sure you want to change the status?',
            text: 'The status will be changed',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, change it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "put",
                    url: baseUrl + 'ajax/updateStatus',
                    data: { 'uuid': uuid, 'find': find,... value },
                    cache: false,
                    dataType: "json",
                    beforeSend: function () {

                    },
                    success: function (response) {
                        if (response.status) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Status Updated!',
                                showConfirmButton: false,
                                timer: 1500
                            })
                            location.reload();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'We are facing some technical issue now.',
                                showConfirmButton: false,
                                timer: 1500
                            })
                            $this.prop('checked', !state);
                        }
                    },
                    error: function (response) {
                        Swal.fire({
                            icon: 'error',
                            title: 'We are facing some technical issue now. Please try again after some time',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        $this.prop('checked', !state);
                    }
                    /* ,
                    complete: function(response){
                        location.reload();
                    } */
                });
            } else {
                $this.prop('checked', !state);
            }
        });
    });

});

$('#parent_category,#sub_category').change(function (e) {
    e.preventDefault();
    let categoryId = $(this).val();
    let location = $(this).data('location');
    var data = '';
    $.ajax({
        type: "post",
        url: baseUrl + "ajax/getGroupedTypes",
        data: { 'category': categoryId },
        dataType: "json",
        success: function (response) {
            $('.selecttoolbox').html('');
            if (response.status && response.data.length > 0) {
                $.each(response.data, function (key, value) {
                    key = parseInt(key) + 1;
                    data += `<div class="selecttool-text ${(key % 2 == 0) ? 'selecttool-textbg' : ''}">
                    <h5>${value.name}</h5>
                    <input type="checkbox" name="types[]" class="form-checkinput" value="${value.value}">
                </div>`;
                });
                $('.selecttoolbox').html(data);
            }
        }
    });
});
//profile tab height adjust with footer
function calcProfileHeight() {
    setTimeout(() => {
        var leftbarHeight = $('.o-post-inner-lft').outerHeight();
        $('.profile-info-tab').css('min-height', leftbarHeight);
    }, 200);
}


$(window).on('resize', function () {
    calcProfileHeight();
});

function populateData(selector) {
    let optHtml = '';
    let populatelocation = selector.data('location');

    let selected = $('#' + populatelocation).data('auth') ?? '';
    console.log(selected);
    let populatemessage = selector.data('message');
    let populateStr = selector.find('option:selected').data("populate");
    optHtml += (populateStr.length == 0) ? '<option value="" selected="selected" disabled >No ' + populatemessage + '</option>' : '<option value="">Select A ' + populatemessage + '</option>';
    for (let key in populateStr) {
        let select = (selected && selected == key) ? 'selected' : '';
        optHtml += '<option value="' + key + '" ' + select + '>' + populateStr[key] + '</option>';
    }
    $('#' + populatelocation).html('').html(optHtml);
}

function changeStatus(selector) {

    var $this = selector;
    console.log($this.is(':checkbox'));
    if ($this.is(':checkbox')) {
        var state = $this.prop('checked') == true ? 1 : 0;
    } else {
        var state = $this.data('status');
    }
    var uuid = $this.data('uuid');
    if ($this.hasClass('changeUserBlock')) {
        var value = {
            'is_blocked': state
        };
    } else if ($this.hasClass('changePaymentStatus')) {
        var value = {
            'is_paid': state
        };
    } else {
        var value = {
            'is_active': state
        };
    }
    var find = $this.data('table');
    var message = $this.data('message') ?? 'test message';
    Swal.fire({
        title: 'Are you sure you want to change the status?',
        text: 'The status will be changed',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, change it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "put",
                url: baseUrl + 'ajax/updateStatus',
                data: { 'uuid': uuid, 'find': find, ...value },
                cache: false,
                dataType: "json",
                beforeSend: function () {

                },
                success: function (response) {
                    if (response.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Status Updated!',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        $this.data('message', message == 'deactive' ? 'active' : 'deactive');
                        if ($this.parent().hasClass('inTable')) {
                            $this.parent().closest('tr.manage-enable').toggleClass('block-disable');
                            let divRight = $this.parent().parent().siblings().find('div.dot-right');
                            divRight.hasClass('pe-none') ? divRight.removeClass('pe-none') : divRight.addClass('pe-none');
                        } else {
                            if ($this.is(':checkbox')) {
                                $this.parent().closest('div.manage-data').toggleClass('block-disable');
                                let divRight = $this.parent().closest('div.dot-right');
                                divRight.hasClass('pe-none') ? divRight.removeClass('pe-none') : divRight.addClass('pe-none');
                            }
                        }
                        if ($this.is(':checkbox')) {
                            $this.parent().find('label').text(state ? 'Active' : 'Inactive').css('color', state ? 'green' : 'red');
                        } else {
                            location.reload();
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'We are facing some technical issue now.',
                            showConfirmButton: false,
                            timer: 1500
                        })

                        if ($this.is(':checkbox')) {
                            $this.prop('checked', !state);
                        }

                    }
                },
                error: function (response) {
                    Swal.fire({
                        icon: 'error',
                        title: 'We are facing some technical issue now. Please try again after some time',
                        showConfirmButton: false,
                        timer: 1500
                    })
                    $this.prop('checked', !state);
                }
                /* ,
                complete: function(response){
                    location.reload();
                } */
            });
        } else {
            $this.prop('checked', !state);
        }

    });
}
function deleteData(selector) {
    var $this = selector;
    var uuid = $this.data('uuid');
    var find = $this.data('table');
    var message = $this.data('message') ?? 'test message';
    Swal.fire({
        title: 'Are you sure you want to delete it?',
        text: 'You wont be able to revert this action!!',
        icon: 'warning',
        width: '350px',
        allowOutsideClick: false,
        showCancelButton: true,
        confirmButtonColor: '#1D9300',
        cancelButtonColor: '#F90F0F',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "delete",
                url: baseUrl + 'ajax/deleteData',
                data: { 'uuid': uuid, 'find': find },
                cache: false,
                dataType: "json",
                beforeSend: function () {

                },
                success: function (response) {
                    if (response.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Deleted Successfully',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        location.reload();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'We are facing some technical issue now.',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                },
                error: function (response) {
                    Swal.fire({
                        icon: 'error',
                        title: 'We are facing some technical issue now. Please try again after some time',
                        showConfirmButton: false,
                        timer: 1500
                    })
                }
                /* ,
                complete: function(response){
                    location.reload();
                } */
            });
        }
    });
}




