@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                     Jobs List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">  Jobs List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                          <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="pickup_from_date" class="label-style">Pickup From Date
                                                    <span class="asterisk_sign">*</span></label>
                                                <input type="date" class="form-control"
                                                    value="{{ request('pickup_from_date') }}" name="pickup_from_date"
                                                    id="pickup_from_date">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="pickup_to_date" class="label-style">Pickup To Date <span
                                                        class="asterisk_sign">*</span></label>
                                                <input type="date" class="form-control" name="pickup_to_date"
                                                    value="{{ request('pickup_to_date') }}" id="pickup_to_date">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="destination_id" class="label-style">Destination</label>
                                            <select name="destination_id" id="destination_id"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($destinations as $dest)
                                                    <option value="{{ $dest->destination }}"
                                                        {{ request('destination_id') == $dest->destination ? 'selected' : '' }}>
                                                        {{ $dest->destination ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Destination Found</option>
                                                @endforelse
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="source_id" class="label-style">Source</label>
                                            <select name="source_id" id="source_id"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($sources as $sou)
                                                    <option value="{{ $sou->source }}"
                                                        {{ request('source_id') == $sou->source ? 'selected' : '' }}>
                                                        {{ $sou->source ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Source Found</option>
                                                @endforelse
                                            </select>
                                        </div>

                                        <div class="col-md-3">
                                            <label for="order_no" class="label-style">Order No</label>
                                            <select name="order_no" id="order_no"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($order_nos as $ord)
                                                    <option value="{{ $ord->order_no }}"
                                                        {{ request('order_no') == $ord->order_no ? 'selected' : '' }}>
                                                        {{ $ord->order_no ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Order No Found</option>
                                                @endforelse
                                            </select>
                                        </div>


                                        <div class="col-md-3">
                                            <label for="contractor_id" class="label-style">Contractor</label>
                                            <select name="contractor_id" id="contractor_id"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($contractors as $con)
                                                    <option value="{{ $con->id }}"
                                                        {{ request('contractor_id') == $con->id ? 'selected' : '' }}>
                                                        {{ $con->first_name.' '.$con->last_name ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Contractor Found</option>
                                                @endforelse
                                            </select>
                                        </div>

                                        <div class="col-md-3">
                                            <label for="pickup_company" class="label-style">Pickup Company</label>
                                            <select name="pickup_company" id="pickup_company"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($pickup_location_companys as $pic_company)
                                                    <option value="{{ $pic_company->pickup_location_company }}"
                                                        {{ request('pickup_company') == $pic_company->pickup_location_company ? 'selected' : '' }}>
                                                        {{ $pic_company->pickup_location_company ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Pickup Company Found</option>
                                                @endforelse
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="drop_off_company" class="label-style">Drop off Company</label>
                                            <select name="drop_off_company" id="drop_off_company"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($drop_off_location_companys as $pic_company)
                                                    <option value="{{ $pic_company->drop_off_location_company }}"
                                                        {{ request('drop_off_company') == $pic_company->drop_off_location_company ? 'selected' : '' }}>
                                                        {{ $pic_company->drop_off_location_company ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No drop off Company Found</option>
                                                @endforelse
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="trucker_id" class="label-style">Trucker</label>
                                            <select name="trucker_id" id="trucker_id"
                                                class="form-control select222">
                                                <option value="">Select One..</option>
                                                @forelse ($truckers as $truck)
                                                    <option value="{{ $truck->id }}"
                                                        {{ request('trucker_id') == $truck->id ? 'selected' : '' }}>
                                                        {{ $truck->first_name.' '.$truck->last_name ?? 'N/A' }}
                                                    </option>
                                                @empty
                                                    <option value="">No Trucker Found</option>
                                                @endforelse
                                            </select>
                                        </div>

                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                    100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip"
                                                data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-4 text-right">

                                        </div>
                                        <div class="col-md-4 text-right">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="job-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Owner</th>
                                            <th>Unique Ids</th>
                                            <th>Order No</th>
                                            <th>Material</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Pickup Date</th>
                                            <th>Delivery Date</th>
                                            <th>Total Mileage</th>
                                            <th>Total Tons</th>
                                            <th>Job Load Type</th>
                                            <th>Total Loads</th>
                                            <th>Job Estimated Price($)</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($job_list as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    {{ $detail?->user?->first_name .' '.$detail?->user?->last_name }}
                                                </td>
                                                <td>
                                                    {{ $detail?->unique_id }}
                                                </td>
                                                <td>
                                                    {{$detail?->order_no}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobMaterial?->title}}
                                                </td>
                                                <td>
                                                    {{$detail?->source}}
                                                </td>
                                                <td>
                                                    {{$detail?->destination}}
                                                </td>
                                                <td>
                                                    {{date('d/m/Y h:i A',strtotime($detail?->pickup_date_time))}}
                                                </td>
                                                <td>
                                                    {{date('d/m/Y h:i A',strtotime($detail?->delivery_date_time))}}
                                                </td>

                                                <td>
                                                    {{$detail?->total_mileage}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobLoad?->sum('weight')}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobLoadType?->title}}
                                                </td>
                                                <td>
                                                    {{$detail?->totalLoad()}}
                                                </td>

                                                <td>
                                                    {{$detail?->job_estimate_price}}
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $job_list->appends(['per_page' => request('per_page'), 'search' => request('search')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('job-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'job-report.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
