@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Invoice List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Invoice List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">

                            <div class="col-md-12" style="padding: 10px 10px 10px 10px;">

                                <div class="container mt-4 p-4" style="border: 1px solid black;border-radius: 10px;">
                                    <h3 class="text-primary mb-3 d-flex align-items-center">
                                        <i class="fas fa-file-invoice-dollar me-2"></i> Generate New Invoice
                                        <span class="ms-2" data-bs-toggle="tooltip" data-bs-placement="top"
                                            title="To generate a new invoice, select either Pickup or Delivery date range. Only one week can be selected at a time.">
                                            <i class="fa-solid fa-circle-info text-success" style="cursor: pointer;"></i>
                                        </span>
                                    </h3>

                                    <form action="{{ route('admin.report.generate-invoice') }}" method="POST"
                                        id="filterForm" class="formSubmit">
                                        @csrf
                                        <div class="card p-4 border-0 bg-white">
                                            <div class="row g-3">
                                                <!-- Pickup From Date -->
                                                <div class="col-md-3">
                                                    <label for="from_date" class="form-label fw-semibold">Pickup
                                                        From</label>
                                                    <input type="date" class="form-control shadow-sm" name="from_date"
                                                        id="from_date" value="{{ request('from_date') }}"
                                                        onchange="checkPickupDates(); document.getElementById('to_date').value=''; checkPickupToDate();">
                                                </div>

                                                <!-- Pickup To Date -->
                                                <div class="col-md-3">
                                                    <label for="to_date" class="form-label fw-semibold">Pickup
                                                        To</label>
                                                    <input type="date" class="form-control shadow-sm" name="to_date"
                                                        id="to_date" value="{{ request('to_date') }}"
                                                        onchange="checkPickupDates(); checkPickupToDate();" min=""
                                                        max="">
                                                    <div class="form-text text-danger d-none" id="pickup_to_date_error">
                                                        Pickup To Date must be within the same week.
                                                    </div>
                                                </div>

                                                <!-- Delivery From Date -->
                                                <div class="col-md-3">
                                                    <label for="completed_from_date" class="form-label fw-semibold">Delivery
                                                        From</label>
                                                    <input type="date" class="form-control shadow-sm"
                                                        name="completed_from_date" id="completed_from_date"
                                                        value="{{ request('completed_from_date') }}"
                                                        onchange="checkDeliveryDates(); document.getElementById('completed_to_date').value=''; checkDeliveryToDate();">
                                                </div>

                                                <!-- Delivery To Date -->
                                                <div class="col-md-3">
                                                    <label for="completed_to_date" class="form-label fw-semibold">Delivery
                                                        To</label>
                                                    <input type="date" class="form-control shadow-sm"
                                                        name="completed_to_date" id="completed_to_date"
                                                        value="{{ request('completed_to_date') }}"
                                                        onchange="checkDeliveryDates(); checkDeliveryToDate();"
                                                        min="" max="">
                                                    <div class="form-text text-danger d-none" id="delivery_to_date_error">
                                                        Delivery To Date must be within the same week.
                                                    </div>
                                                </div>

                                                <!-- Submit Button -->
                                                <div class="col-md-12 text-end mt-3">
                                                    <button type="submit" id="submitBtn" class="btn btn-info px-4 py-2"
                                                        onclick="return checkDateValidation()">
                                                        <span class="indicator-label"><i
                                                                class="fas fa-file-invoice me-1"></i> Generate</span>
                                                        <span class="indicator-progress d-none">Please wait...
                                                            <span class="spinner-border spinner-border-sm ms-2"></span>
                                                        </span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>


                                <div class="container mt-4 p-4" style="border: 1px solid black;border-radius: 10px;">
                                    <h3 class="text-primary mb-3 d-flex align-items-center">
                                        <i class="fas fa-file-invoice me-2"></i> Search Invoice List
                                    </h3>

                                    <form action="{{ route('admin.report.invoice-report') }}" method="GET">
                                        @csrf
                                        <div class="card p-4 border-0 bg-white">
                                            <div class="row g-3">
                                                <!-- Vendor/Contractor -->
                                                <div class="col-md-3">
                                                    <label for="vendor_id" class="form-label fw-semibold">Vendor/Contractor</label>
                                                    <select id="vendor_id" class="form-select select222"
                                                        name="vendor_id">
                                                        <option value="">Select Vendor</option>
                                                        @foreach ($vendors as $vendor)
                                                            <option value="{{ $vendor->id }}"
                                                                {{ request('vendor_id') == $vendor->id ? 'selected' : '' }}>
                                                                {{ $vendor->first_name . ' ' . $vendor->last_name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>

                                                <!-- Invoice Date -->
                                                <div class="col-md-3">
                                                    <label for="invoice_date" class="form-label fw-semibold">Invoice
                                                        Date</label>
                                                    <input type="date" class="form-control shadow-sm"
                                                        name="invoice_date" id="invoice_date"
                                                        value="{{ request('invoice_date') }}">
                                                </div>

                                                <!-- Due Date -->
                                                <div class="col-md-3">
                                                    <label for="due_date" class="form-label fw-semibold">Due
                                                        Date</label>
                                                    <input type="date" class="form-control shadow-sm" name="due_date"
                                                        id="due_date" value="{{ request('due_date') }}">
                                                </div>

                                                <!-- Results per page -->
                                                <div class="col-md-3">
                                                    <label for="per_page" class="form-label fw-semibold">Results per
                                                        page</label>
                                                    <select id="per_page" class="form-select" name="per_page">
                                                        <option value="10"
                                                            {{ request('per_page') == 10 ? 'selected' : '' }}>10</option>
                                                        <option value="25"
                                                            {{ request('per_page') == 25 ? 'selected' : '' }}>25</option>
                                                        <option value="50"
                                                            {{ request('per_page') == 50 ? 'selected' : '' }}>50</option>
                                                        <option value="100"
                                                            {{ request('per_page') == 100 ? 'selected' : '' }}>100</option>
                                                        <option value="all"
                                                            {{ request('per_page') == 'all' ? 'selected' : '' }}>All
                                                        </option>
                                                    </select>
                                                </div>

                                                <!-- Action Buttons -->
                                                <div class="col-md-12 text-end mt-3">
                                                    <button type="submit" class="btn btn-primary me-2">
                                                        <i class="fas fa-search me-1"></i> Search
                                                    </button>
                                                    <button type="button" onclick="export_data()"
                                                        class="btn btn-success me-2">
                                                        <i class="fa fa-file-excel-o me-1"></i> Export
                                                    </button>
                                                    <a href="{{ route('admin.report.invoice-report') }}"
                                                        class="btn btn-warning">
                                                        <i class="fas fa-undo me-1"></i> Reset
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                            <div class="d-flex align-items-center gap-4">
                                <div class="d-flex align-items-center gap-2">
                                    <span style="width: 16px; height: 16px; background-color: #f5aeae; border-radius: 50%; display: inline-block;"></span>
                                    <h6 class="fw-bold text-gray-800 mb-0">Already Generated</h6>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span style="width: 16px; height: 16px; background-color: #fff; border: 1px solid #ccc; border-radius: 50%; display: inline-block;"></span>
                                    <h6 class="fw-bold text-gray-800 mb-0">New Generated</h6>
                                </div>
                            </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="invoice-and-bill-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Invoice No</th>
                                            <th>Customer</th>
                                            <th>Invoice Date</th>
                                            <th>Due Date</th>
                                            <th class="d-none">Shipping Date</th>
                                            <th class="d-none">Ship Via</th>
                                            <th class="d-none">Tracking no</th>
                                            <th>Terms</th>
                                            <th class="d-none">Billing Address Line 1</th>
                                            <th class="d-none">Billing Address Line 2</th>
                                            <th class="d-none">Billing Address Line 3</th>
                                            <th class="d-none">Billing Address City</th>
                                            <th class="d-none">Billing Address Postal Code</th>
                                            <th class="d-none">Billing Address Country</th>
                                            <th class="d-none">Billing Address State</th>
                                            <th class="d-none">Shipping Address Line 1</th>
                                            <th class="d-none">Shipping Address Line 2</th>
                                            <th class="d-none">Shipping Address Line 3</th>
                                            <th class="d-none">Shipping Address City</th>
                                            <th class="d-none">Shipping Address Postal Code</th>
                                            <th class="d-none">Shipping Address Country</th>
                                            <th class="d-none">Shipping Address State</th>
                                            <th class="d-none">Memo</th>
                                            <th class="d-none">Message displayed on invoice</th>
                                            <th class="d-none">Email</th>
                                            <th class="d-none">Shipping</th>
                                            <th class="d-none">Sales Tax Code</th>
                                            <th class="d-none">Sales Tax Amount</th>
                                            <th class="d-none">Discount Amount</th>
                                            <th class="d-none">Discount Percent</th>
                                            <th class="d-none">Discount Account</th>
                                            <th class="d-none">Apply Tax After Discount</th>
                                            <th class="d-none">Service Date</th>
                                            <th>Product/Service</th>
                                            <th>Product/Service Description</th>
                                            <th class="d-none">Product/Service Quantity</th>
                                            <th class="d-none">Product/Service Rate</th>
                                            <th>Product/Service Amount</th>
                                            <th class="d-none">Product/Service Taxable</th>
                                            <th class="d-none">Product/Service Class</th>
                                            <th class="d-none">Show Sub Total</th>
                                            <th class="d-none">Deposit</th>
                                            <th class="d-none">Location</th>
                                            <th class="d-none">Custom Field Value (1)</th>
                                            <th class="d-none">Custom Field Value (2)</th>
                                            <th class="d-none">Custom Field Value (3)</th>
                                            <th class="d-none">Currency Code</th>
                                            <th class="d-none">Exchange Rate</th>
                                            <th class="d-none">Print Status</th>
                                            <th class="d-none">Email Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($generated_invoices as $detail)
                                            <tr data-user-id="{{ $detail->id }}"
                                                style="background-color:{{ $detail->is_generated == 1 ? '#ffe6e6' : '' }}">
                                                <td></td>
                                                <td>{{ $detail?->user?->first_name }} {{ $detail?->user?->last_name }}
                                                </td>
                                                <td>{{ date('m/d/Y', strtotime($detail?->from_date)) }}</td>
                                                <td>{{ date('m/d/Y', strtotime($detail?->to_date)) }}</td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td>{{ $detail?->payment_terms }}</td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td>Hauling Service</td>
                                                <td>week of
                                                    {{ date('m/d/Y', strtotime($detail?->description_start_date)) }} -
                                                    {{ date('m/d/Y', strtotime($detail?->description_end_date)) }}</td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td>{{ $detail?->amount }}</td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                                <td class="d-none"></td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="7">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                @if (request('per_page') != 'all')
                                    {!! $generated_invoices->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('invoice-and-bill-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });

                // Write the file
                XLSX.writeFile(fp, 'invoice-and-bill-list.xlsx');
            }
        </script>
        <script>
            function checkPickupDates() {
                const fromDateInput = document.getElementById('from_date');
                const toDateInput = document.getElementById('to_date');
                const errorSpan = document.getElementById('pickup_to_date_error');

                const fromDate = new Date(fromDateInput.value);
                const toDate = new Date(toDateInput.value);

                const fromWeekDay = fromDate.getDay();
                const startOfWeek = new Date(fromDate);
                startOfWeek.setDate(fromDate.getDate() - fromWeekDay);

                const endOfWeek = new Date(startOfWeek);
                endOfWeek.setDate(startOfWeek.getDate() + 6);

                toDateInput.min = fromDateInput.value;
                toDateInput.max = endOfWeek.toISOString().split('T')[0];



                const completedToDateInput = document.getElementById('completed_to_date');
                completedToDateInput.value = '';
                completedToDateInput.disabled = true;

                const completedfromDateInput = document.getElementById('completed_from_date');
                completedfromDateInput.value = '';
                completedfromDateInput.disabled = true;

                if (toDate >= startOfWeek && toDate <= endOfWeek) {
                    errorSpan.style.display = 'none';
                } else {
                    errorSpan.style.display = 'block';
                }
            }

            function checkDeliveryDates() {
                const fromDateInput = document.getElementById('completed_from_date');
                const toDateInput = document.getElementById('completed_to_date');
                const errorSpan = document.getElementById('delivery_to_date_error');

                const fromDate = new Date(fromDateInput.value);
                const toDate = new Date(toDateInput.value);

                const fromWeekDay = fromDate.getDay();
                const startOfWeek = new Date(fromDate);
                startOfWeek.setDate(fromDate.getDate() - fromWeekDay);

                const endOfWeek = new Date(startOfWeek);
                endOfWeek.setDate(startOfWeek.getDate() + 6);

                toDateInput.min = fromDateInput.value;
                toDateInput.max = endOfWeek.toISOString().split('T')[0];

                const ToDateInput1 = document.getElementById('to_date');
                ToDateInput1.value = '';
                ToDateInput1.disabled = true;

                const fromDateInput1 = document.getElementById('from_date');
                fromDateInput1.value = '';
                fromDateInput1.disabled = true;

                if (toDate >= startOfWeek && toDate <= endOfWeek) {
                    errorSpan.style.display = 'none';
                } else {
                    errorSpan.style.display = 'block';
                }
            }

            function checkDateValidation() {
                const fromDate = document.getElementById('from_date').value;
                const toDate = document.getElementById('to_date').value;
                const completedFromDate = document.getElementById('completed_from_date').value;
                const completedToDate = document.getElementById('completed_to_date').value;

                if ((fromDate && toDate) || (completedFromDate && completedToDate)) {
                    return true;
                } else {
                    alert('Please select both Pickup or Delivery dates.');
                    return false;
                }
            }
        </script>

        <script>
            function checkPickupToDate() {
                var from_date = $('#from_date').val();
                var to_date = $('#to_date').val();
                if (from_date != '' && to_date == '') {
                    $('#pickup_to_date_error').show();
                    $('#submitBtn').prop('disabled', true);
                } else {
                    $('#pickup_to_date_error').hide();
                    $('#submitBtn').prop('disabled', false);
                }
            }

            function checkDeliveryToDate() {
                var from_date = $('#completed_from_date').val();
                var to_date = $('#completed_to_date').val();
                if (from_date != '' && to_date == '') {
                    $('#delivery_to_date_error').show();
                    $('#submitBtn').prop('disabled', true);
                } else {
                    $('#delivery_to_date_error').hide();
                    $('#submitBtn').prop('disabled', false);
                }
            }

            function checkDateValidation() {
                var from_date = $('#from_date').val();
                var to_date = $('#to_date').val();
                var from_date_delivery = $('#completed_from_date').val();
                var to_date_delivery = $('#completed_to_date').val();
                if ((from_date != '' && to_date == '') || (from_date_delivery != '' && to_date_delivery == '')) {
                    return false;
                } else {
                    return true;
                }
            }
        </script>


        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
