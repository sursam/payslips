@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Complete Jobs List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Complete Jobs List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                              <div class="container">
                                <!-- Filter Section -->
                                <form action="{{ route('admin.report.complete-job-report') }}" method="GET">
                                    @csrf
                                    <div class="card p-3">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <label for="search">Destination</label>
                                                <select id="search" class="form-control select222" name="search"
                                                    onchange="changeSearch()">
                                                    <option value="">Select Destination</option>
                                                    @foreach ($destinations as $destination)
                                                        <option value="{{ $destination }}"
                                                            {{ request('search') == $destination ? 'selected' : '' }}>
                                                            {{ $destination }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <label for="source">Source</label>
                                                <select id="source" class="form-control select222" name="source">
                                                    <option value="">Select Source</option>
                                                    @foreach ($sources as $source)
                                                        <option value="{{ $source }}"
                                                            {{ request('source') == $source ? 'selected' : '' }}>
                                                            {{ $source }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                               <div class="col-md-2">
                                                <label for="trucker">Trucker</label>
                                                <select id="trucker" class="form-control select222" name="trucker">
                                                    <option value="">Select Trucker</option>
                                                    @foreach ($all_trucker as $trucker)
                                                        <option value="{{ $trucker->id }}"
                                                            {{ request('trucker') == $trucker->id ? 'selected' : '' }}>
                                                            {{ $trucker->first_name.' '.$trucker->last_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <label for="job_unique_id">Job Unique Id</label>
                                                <select id="job_unique_id" class="form-control select222" name="job_unique_id">
                                                    <option value="">Select Job Unique Id</option>
                                                    @foreach ($job_unique_ids as $job_unique_id)
                                                        <option value="{{ $job_unique_id }}"
                                                            {{ request('job_unique_id') == $job_unique_id ? 'selected' : '' }}>
                                                            {{ $job_unique_id }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Pickup From Date</label>
                                                    <input type="date" class="form-control"
                                                        value="{{ request('from_date') }}" name="from_date" id="from_date">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Pickup To Date</label>
                                                    <input type="date" class="form-control" name="to_date"
                                                        value="{{ request('to_date') }}" id="to_date">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Delivery From Date</label>
                                                    <input type="date" class="form-control"
                                                        value="{{ request('completed_from_date') }}"
                                                        name="completed_from_date" id="completed_from_date">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id"> Delivery To Date</label>
                                                    <input type="date" class="form-control" name="completed_to_date"
                                                        value="{{ request('completed_to_date') }}" id="completed_to_date">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <label for="per_page">Results per page</label>
                                                <select id="per_page" class="form-control" name="per_page">
                                                    <option value="10"
                                                        {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                    </option>
                                                    <option value="25"
                                                        {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                    </option>
                                                    <option value="50"
                                                        {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                    </option>
                                                    <option value="100"
                                                        {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                        100</option>
                                                               <option value="all"
                                                        {{ request('per_page') == 'all' ? 'selected' : '' }}>
                                                        all</option>
                                                </select>
                                            </div>


                                            <div class="col-md-4">
                                                <button type="submit" class="btn btn-primary mt-8"><i
                                                        class="fas fa-search"></i>
                                                    Search</button>
                                                <button type="button" onclick="export_data()"
                                                    class="btn btn-success mt-8"><i class="fa fa-file-excel-o"></i>
                                                    Export</button>

                                                <a href="{{ route('admin.report.complete-job-report') }}" class="btn btn-warning mt-8">
                                                    Reset</a>


                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="all-job-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Owner</th>
                                            <th>Unique Ids</th>
                                            <th>Order No</th>
                                            <th>Material</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Pickup Date</th>
                                            <th>Delivery Date</th>

                                            <th>Total Mileage</th>
                                            <th>Total Tons</th>
                                            <th>Job Load Type</th>
                                            <th>Total Loads</th>
                                            <th>Job Estimated Price($)</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($complete_job_list as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    {{ $detail?->unique_id }}
                                                </td>
                                                <td>
                                                    {{ $detail?->unique_id }}
                                                </td>
                                                <td>
                                                    {{$detail?->order_no}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobMaterial?->title}}
                                                </td>
                                                <td>
                                                    {{$detail?->source}}
                                                </td>
                                                <td>
                                                    {{$detail?->destination}}
                                                </td>
                                                <td>
                                                    {{date('d/m/Y h:i A',strtotime($detail?->pickup_date_time))}}
                                                </td>
                                                <td>
                                                    {{date('d/m/Y h:i A',strtotime($detail?->delivery_date_time))}}
                                                </td>

                                                <td>
                                                    {{$detail?->total_mileage}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobLoad?->sum('weight')}}
                                                </td>
                                                <td>
                                                    {{$detail?->jobLoadType?->title}}
                                                </td>
                                                <td>
                                                    {{$detail?->totalLoad()}}
                                                </td>

                                                <td>
                                                    {{$detail?->job_estimate_price}}
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                 @if(request('per_page') != 'all')
                                {!! $complete_job_list->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('all-job-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'complete-job-report.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
