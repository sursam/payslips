{{-- @extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    All Load Report</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> All Load Report</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="container">
                                <!-- Filter Section -->
                                <form action="{{ route('admin.report.load-report') }}" method="GET">
                                    @csrf
                                    <div class="card p-3">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id"> Truck No.</label>
                                                    <input type="text" class="form-control" name="truck_no"
                                                        placeholder="Enter Truck No" value="{{ request('truck_no') }}"
                                                        id="truck_no">
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <label for="source">Source</label>
                                                <select id="source" class="form-control select222" name="source">
                                                    <option value="">Select Source</option>
                                                    @foreach ($sources as $source)
                                                        <option value="{{ $source }}"
                                                            {{ request('source') == $source ? 'selected' : '' }}>
                                                            {{ $source }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label for="search">Destination</label>
                                                <select id="search" class="form-control select222" name="search"
                                                    onchange="changeSearch()">
                                                    <option value="">Select Destination</option>
                                                    @foreach ($destinations as $destination)
                                                        <option value="{{ $destination }}"
                                                            {{ request('search') == $destination ? 'selected' : '' }}>
                                                            {{ $destination }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-3">
                                                <label for="pickup_company">Pickup Company</label>
                                                <select id="pickup_company" class="form-control select222"
                                                    name="pickup_company">
                                                    <option value="">Select Pickup Company</option>
                                                    @foreach ($all_pickup_locations as $pickup_locations)
                                                        <option value="{{ $pickup_locations }}"
                                                            {{ request('pickup_company') == $pickup_locations ? 'selected' : '' }}>
                                                            {{ $pickup_locations }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="dropoff_company">Dropoff Company</label>
                                                <select id="dropoff_company" class="form-control select222"
                                                    name="dropoff_company">
                                                    <option value="">Select Dropoff Company</option>
                                                    @foreach ($all_dropoff_locations as $dropoff_locations)
                                                        <option value="{{ $dropoff_locations }}"
                                                            {{ request('dropoff_company') == $dropoff_locations ? 'selected' : '' }}>
                                                            {{ $dropoff_locations }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Created From Date</label>
                                                    <input type="date" class="form-control"
                                                        value="{{ request('from_date') }}" name="from_date" id="from_date">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Created To Date</label>
                                                    <input type="date" class="form-control" name="to_date"
                                                        value="{{ request('to_date') }}" id="to_date">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="contractor">Contractor</label>
                                                <select id="contractor" class="form-control select222" name="contractor">
                                                    <option value="">Select Contractor</option>
                                                    @foreach ($all_contractors as $contractor)
                                                        <option value="{{ $contractor->id }}"
                                                            {{ request('contractor') == $contractor->id ? 'selected' : '' }}>
                                                            {{ $contractor->first_name . ' ' . $contractor->last_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Is Load Completed</label>
                                                    <select class="form-control" name="is_completed" id="is_completed">
                                                        <option value="">Select</option>
                                                        <option value="1"
                                                            {{ request('is_completed') == 1 ? 'selected' : '' }}>
                                                            Yes</option>
                                                        <option value="0"
                                                            {{ request('is_completed') == 0 ? 'selected' : '' }}>
                                                            No</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <label for="per_page">Results per page</label>
                                                <select id="per_page" class="form-control" name="per_page">
                                                    <option value="10"
                                                        {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                    </option>
                                                    <option value="25"
                                                        {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                    </option>
                                                    <option value="50"
                                                        {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                    </option>
                                                    <option value="100"
                                                        {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                        100</option>
                                                    <option value="all"
                                                        {{ request('per_page') == 'all' ? 'selected' : '' }}>
                                                        all</option>
                                                </select>
                                            </div>
                                            <div class="col-md-12">
                                                <button type="submit" class="btn btn-primary mt-8"><i
                                                        class="fas fa-search"></i>
                                                    Search</button>
                                                <button type="button" onclick="export_data()"
                                                    class="btn btn-success mt-8"><i class="fa fa-file-excel-o"></i>
                                                    Export</button>



                                                <a href="{{ route('admin.report.load-report') }}"
                                                    class="btn btn-warning mt-8">
                                                    Reset</a>
                                                <a href="{{ asset('storage/loads/' . $zipFileName) }}"
                                                    class="btn btn-info mt-8" download><i class="fa fa-download"></i>
                                                    Download
                                                </a>


                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="all-load-list-report">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <td>DATE</td>
                                            <td>Payment Status</td>
                                            <td>PAYMENT</td>
                                            <td>AMOUNT</td>
                                            <td>CARRIER</td>
                                            <td>TRUCK</td>
                                            <td>TICKET #</td>
                                            <th>PICKUP COMPANY NAME</th>
                                            <th>DROP OFF COMPANY NAME</th>
                                            <td>SHIPPER</td>
                                            <td>CONSIGNEE</td>
                                            <td>BILL TO</td>
                                            <td>MATERIAL</td>
                                            <td>LOAD TYPE</td>
                                            <td>QTY</td>
                                            <td>RATE/QTY</td>
                                            <td>DRIVER RATE</td>
                                            <td>DRIVER PAY</td>
                                            <td>TOTAL</td>
                                            <td>DRIVER PAY in %</td>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($loads as $detail)
                                            <tr>
                                                <td>{{ date('m-d-Y', strtotime($detail?->created_at)) }}</td>
                                                <td>{{ $detail?->is_payment_initiated == 0 ? 'NOT PAID' : 'PAID IN FULL' }}
                                                </td>
                                                <td>{{ 'CONECTAR 051925' }}</td>
                                                <td>$ {{ number_format($detail?->load_cost, 2) }}</td>
                                                <td>{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}
                                                </td>
                                                <td>{{ $detail?->userTruckDetails ? $detail?->userTruckDetails?->company_truck_number : 'NA' }}
                                                </td>
                                                <td>{{ $detail?->ticket_no ? $detail?->ticket_no : 'NA' }}</td>
                                                <td>{{ $detail?->job?->pickup_location_company ?? 'NA' }}</td>
                                                <td>{{ $detail?->job?->drop_off_location_company ?? 'NA' }}</td>
                                                <td>{{ $detail?->job?->source }}</td>
                                                <td>{{ $detail?->job?->destination }}</td>
                                                <td>{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}
                                                </td>
                                                <td>
                                                    @if ($detail->job->jobMaterial->title != 'Other')
                                                        {{ $detail->job->jobMaterial->title }}
                                                    @elseif($detail->job->jobMaterial->title == 'Other')
                                                        {{ $detail->job->material_other }}
                                                    @else
                                                        {{ 'N/A' }}
                                                    @endif
                                                </td>
                                                <td>{{ $detail?->job?->jobLoadType?->title }}</td>
                                                <td>{{ $detail?->weight }}</td>
                                                <td>$ {{ number_format($detail?->load_cost / $detail?->weight, 2) }}</td>
                                                <td>$ {{ number_format($detail?->trucker_get / $detail?->weight, 2) }}
                                                </td>
                                                <td>$ {{ number_format($detail?->trucker_get, 2) }}</td>
                                                <td>$ {{ number_format($detail?->load_cost, 2) }}</td>
                                                <td>
                                                    {{ $detail?->load_cost > 0 ? number_format(($detail->trucker_get / $detail->load_cost) * 100, 2) . '%' : 'N/A' }}
                                                </td>


                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="16" class="text-center">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                @if (request('per_page') != 'all')
                                    {!! $loads->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('all-load-list-report');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'all-load-report.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection --}}
@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    All Load Report
                                </h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">All Load Report</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <!-- Filter Toggle Card -->
                            <div class="card mb-3">
                                <div class="card-body p-3">
                                    <button type="button" class="btn btn-primary" id="toggleFilterBtn">
                                        <i class="fas fa-filter me-2"></i>Show Filters
                                    </button>
                                    
                                    <div id="filterPanel" class="mt-3" style="display:none;">
                                        <div class="row">
                                            <div class="col-12">
                                                <h6 class="mb-3 text-muted">Select filters to display:</h6>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="truck_no_toggle">
                                                    <label class="form-check-label" for="truck_no_toggle">
                                                        Truck No.
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="source_toggle">
                                                    <label class="form-check-label" for="source_toggle">
                                                        Source
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="destination_toggle">
                                                    <label class="form-check-label" for="destination_toggle">
                                                        Destination
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="pickup_company_toggle">
                                                    <label class="form-check-label" for="pickup_company_toggle">
                                                        Pickup Company
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="dropoff_company_toggle">
                                                    <label class="form-check-label" for="dropoff_company_toggle">
                                                        Dropoff Company
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="date_range_toggle">
                                                    <label class="form-check-label" for="date_range_toggle">
                                                        Date Range
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="contractor_toggle">
                                                    <label class="form-check-label" for="contractor_toggle">
                                                        Contractor
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="is_completed_toggle">
                                                    <label class="form-check-label" for="is_completed_toggle">
                                                        Load Status
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-12">
                                                <button type="button" class="btn btn-sm btn-outline-secondary me-2" id="selectAllBtn">
                                                    Select All
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-secondary" id="clearAllBtn">
                                                    Clear All
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Filter Form Card -->
                            <div class="card mb-3">
                                <div class="card-body p-3">
                                    <form action="{{ route('admin.report.load-report') }}" method="GET" id="filterForm">
                                        <!-- Row 1: Truck No, Source, Destination -->
                                        <div class="row mb-3">
                                            <!-- Truck No -->
                                            <div class="col-md-4" id="truck_no_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="truck_no" class="form-label">
                                                        <i class="fas fa-truck me-1"></i>Truck No.
                                                    </label>
                                                    <input type="text" class="form-control" name="truck_no"
                                                           placeholder="Enter Truck No" value="{{ request('truck_no') }}"
                                                           id="truck_no">
                                                </div>
                                            </div>

                                            <!-- Source -->
                                            <div class="col-md-4" id="source_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="source" class="form-label">
                                                        <i class="fas fa-map-marker-alt me-1"></i>Source
                                                    </label>
                                                    <label for="source">Source</label>
                                                    <select id="source" class="form-control" name="source">
                                                        <option value="">Select Source</option>
                                                        @foreach ($sources as $source)
                                                            <option value="{{ $source }}"
                                                                {{ request('source') == $source ? 'selected' : '' }}>
                                                                {{ $source }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Destination -->
                                            <div class="col-md-4" id="destination_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="search" class="form-label">
                                                        <i class="fas fa-map-marker-alt me-1"></i>Destination
                                                    </label>
                                                    <select id="search" class="form-control" name="search"
                                                        onchange="changeSearch()">
                                                        <option value="">Select Destination</option>
                                                        @foreach ($destinations as $destination)
                                                            <option value="{{ $destination }}"
                                                                {{ request('search') == $destination ? 'selected' : '' }}>
                                                                {{ $destination }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Row 2: Pickup Company, Dropoff Company, Contractor -->
                                        <div class="row mb-3">
                                            <!-- Pickup Company -->
                                            <div class="col-md-4" id="pickup_company_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="pickup_company" class="form-label">
                                                        <i class="fas fa-building me-1"></i>Pickup Company
                                                    </label>
                                                    <select id="pickup_company" class="form-control"
                                                        name="pickup_company">
                                                        <option value="">Select Pickup Company</option>
                                                        @foreach ($all_pickup_locations as $pickup_locations)
                                                            <option value="{{ $pickup_locations }}"
                                                                {{ request('pickup_company') == $pickup_locations ? 'selected' : '' }}>
                                                                {{ $pickup_locations }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Dropoff Company -->
                                            <div class="col-md-4" id="dropoff_company_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="dropoff_company" class="form-label">
                                                        <i class="fas fa-building me-1"></i>Dropoff Company
                                                    </label>
                                                    <select id="dropoff_company" class="form-control"
                                                        name="dropoff_company">
                                                        <option value="">Select Dropoff Company</option>
                                                        @foreach ($all_dropoff_locations as $dropoff_locations)
                                                            <option value="{{ $dropoff_locations }}"
                                                                {{ request('dropoff_company') == $dropoff_locations ? 'selected' : '' }}>
                                                                {{ $dropoff_locations }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Contractor -->
                                            <div class="col-md-4" id="contractor_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="contractor" class="form-label">
                                                        <i class="fas fa-user-tie me-1"></i>Contractor
                                                    </label>
                                                    <select id="contractor" class="form-control" name="contractor">
                                                        <option value="">Select Contractor</option>
                                                        @foreach ($all_contractors as $contractor)
                                                            <option value="{{ $contractor->id }}"
                                                                {{ request('contractor') == $contractor->id ? 'selected' : '' }}>
                                                                {{ $contractor->first_name . ' ' . $contractor->last_name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Row 3: Date Range, Load Status -->
                                        <div class="row mb-3">
                                            <!-- Date Range -->
                                            <div class="col-md-6" id="date_range_field" style="display:none;">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="from_date" class="form-label">
                                                                <i class="fas fa-calendar-alt me-1"></i>From Date
                                                            </label>
                                                            <input type="date" class="form-control" name="from_date"
                                                                   value="{{ request('from_date') }}" id="from_date">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="to_date" class="form-label">
                                                                <i class="fas fa-calendar-alt me-1"></i>To Date
                                                            </label>
                                                            <input type="date" class="form-control" name="to_date"
                                                                   value="{{ request('to_date') }}" id="to_date">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Is Load Completed -->
                                            <div class="col-md-3" id="is_completed_field" style="display:none;">
                                                <div class="form-group">
                                                    <label for="is_completed" class="form-label">
                                                        <i class="fas fa-check-circle me-1"></i>Load Status
                                                    </label>
                                                    <select class="form-control" name="is_completed" id="is_completed">
                                                        <option value="">Select Status</option>
                                                        <option value="1" {{ request('is_completed') == '1' ? 'selected' : '' }}>
                                                            Completed
                                                        </option>
                                                        <option value="0" {{ request('is_completed') == '0' ? 'selected' : '' }}>
                                                            Pending
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Action Buttons -->
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex gap-2 flex-wrap">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-search me-1"></i>Apply Filters
                                                    </button>
                                                    <button type="button" class="btn btn-secondary" id="resetFormBtn">
                                                        <i class="fas fa-undo me-1"></i>Reset
                                                    </button>
                                                    <button type="button" class="btn btn-success" onclick="export_data()">
                                                        <i class="fas fa-download me-1"></i>Export
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="all-load-list-report">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <td>DATE</td>
                                            <td>Payment Status</td>
                                            <td>PAYMENT</td>
                                            <td>AMOUNT</td>
                                            <td>CARRIER</td>
                                            <td>TRUCK</td>
                                            <td>TICKET #</td>
                                            <th>PICKUP COMPANY NAME</th>
                                            <th>DROP OFF COMPANY NAME</th>
                                            <td>SHIPPER</td>
                                            <td>CONSIGNEE</td>
                                            <td>BILL TO</td>
                                            <td>MATERIAL</td>
                                            <td>LOAD TYPE</td>
                                            <td>QTY</td>
                                            <td>RATE/QTY</td>
                                            <td>DRIVER RATE</td>
                                            <td>DRIVER PAY</td>
                                            <td>TOTAL</td>
                                            <td>DRIVER PAY in %</td>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($loads as $detail)
                                            <tr>
                                                <td>{{ date('m-d-Y', strtotime($detail?->created_at)) }}</td>
                                                <td>{{ $detail?->is_payment_initiated == 0 ? 'NOT PAID' : 'PAID IN FULL' }}</td>
                                                <td>{{ 'CONECTAR 051925' }}</td>
                                                <td>$ {{ number_format($detail?->load_cost, 2) }}</td>
                                                <td>{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}</td>
                                                <td>{{ $detail?->userTruckDetails ? $detail?->userTruckDetails?->company_truck_number : 'NA' }}</td>
                                                <td>{{ $detail?->ticket_no ? $detail?->ticket_no : 'NA' }}</td>
                                                <td>{{ $detail?->job?->pickup_location_company ?? 'NA' }}</td>
                                                <td>{{ $detail?->job?->drop_off_location_company ?? 'NA' }}</td>
                                                <td>{{ $detail?->job?->source }}</td>
                                                <td>{{ $detail?->job?->destination }}</td>
                                                <td>{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}</td>
                                                <td>
                                                    @if ($detail->job->jobMaterial->title != 'Other')
                                                        {{ $detail->job->jobMaterial->title }}
                                                    @elseif($detail->job->jobMaterial->title == 'Other')
                                                        {{ $detail->job->material_other }}
                                                    @else
                                                        {{ 'N/A' }}
                                                    @endif
                                                </td>
                                                <td>{{ $detail?->job?->jobLoadType?->title }}</td>
                                                <td>{{ $detail?->weight }}</td>
                                                <td>$ {{ number_format($detail?->load_cost / $detail?->weight, 2) }}</td>
                                                <td>$ {{ number_format($detail?->trucker_get / $detail?->weight, 2) }}</td>
                                                <td>$ {{ number_format($detail?->trucker_get, 2) }}</td>
                                                <td>$ {{ number_format($detail?->load_cost, 2) }}</td>
                                                <td>
                                                    {{ $detail?->load_cost > 0 ? number_format(($detail->trucker_get / $detail->load_cost) * 100, 2) . '%' : 'N/A' }}
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="20" class="text-center">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                @if (request('per_page') != 'all')
                                    {!! $loads->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
        <script>
            // Export function
            function export_data() {
                let data = document.getElementById('all-load-list-report');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'all-load-report.xlsx');
            }

            // Filter functionality
            $(document).ready(function() {
                // Initialize Select2 if available
                if (typeof $.fn.select2 !== 'undefined') {
                    $('.select2').select2({
                        width: '100%'
                    });
                }

                // Check if any filters are active on page load
                checkActiveFilters();

                // Toggle filter panel
                $('#toggleFilterBtn').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const panel = $('#filterPanel');
                    const btn = $(this);
                    
                    if (panel.is(':hidden')) {
                        panel.slideDown(300);
                        btn.html('<i class="fas fa-filter me-2"></i>Hide Filters');
                        btn.removeClass('btn-primary').addClass('btn-secondary');
                    } else {
                        panel.slideUp(300);
                        btn.html('<i class="fas fa-filter me-2"></i>Show Filters');
                        btn.removeClass('btn-secondary').addClass('btn-primary');
                    }
                });

                // Checkbox change handlers
                $('#truck_no_toggle').on('change', function() {
                    toggleField('truck_no_field', this.checked);
                });

                $('#source_toggle').on('change', function() {
                    toggleField('source_field', this.checked);
                });

                $('#destination_toggle').on('change', function() {
                    toggleField('destination_field', this.checked);
                });

                $('#pickup_company_toggle').on('change', function() {
                    toggleField('pickup_company_field', this.checked);
                });

                $('#dropoff_company_toggle').on('change', function() {
                    toggleField('dropoff_company_field', this.checked);
                });

                $('#date_range_toggle').on('change', function() {
                    toggleField('date_range_field', this.checked);
                });

                $('#contractor_toggle').on('change', function() {
                    toggleField('contractor_field', this.checked);
                });

                $('#is_completed_toggle').on('change', function() {
                    toggleField('is_completed_field', this.checked);
                });

                // Select all filters
                $('#selectAllBtn').on('click', function() {
                    $('#filterPanel input[type="checkbox"]').each(function() {
                        if (!this.checked) {
                            $(this).prop('checked', true).trigger('change');
                        }
                    });
                });

                // Clear all filters
                $('#clearAllBtn').on('click', function() {
                    $('#filterPanel input[type="checkbox"]').each(function() {
                        if (this.checked) {
                            $(this).prop('checked', false).trigger('change');
                        }
                    });
                });

                // Reset form
                $('#resetFormBtn').on('click', function() {
                    // Clear all form fields
                    window.location.href = "{{ route('admin.report.load-report') }}";
                });
            });

            function toggleField(fieldId, show) {
                const field = $('#' + fieldId);
                
                if (show) {
                    field.fadeIn(300);
                } else {
                    field.fadeOut(300, function() {
                        // Clear the field value when hiding
                        clearFieldValue(fieldId);
                    });
                }
            }

            function clearFieldValue(fieldId) {
                const field = $('#' + fieldId);
                const inputs = field.find('input, select');
                
                inputs.each(function() {
                    if (this.type === 'date' || this.type === 'text') {
                        $(this).val('');
                    } else if (this.tagName === 'SELECT') {
                        $(this).prop('selectedIndex', 0);
                        // Trigger Select2 update if it's a Select2 element
                        if ($(this).hasClass('select2') && typeof $.fn.select2 !== 'undefined') {
                            $(this).trigger('change');
                        }
                    }
                });
            }

            function checkActiveFilters() {
                // Check if any form fields have values and show corresponding filters
                const urlParams = new URLSearchParams(window.location.search);
                
                const fieldMappings = {
                    'truck_no': 'truck_no_field',
                    'source': 'source_field',
                    'search': 'destination_field',
                    'pickup_company': 'pickup_company_field',
                    'dropoff_company': 'dropoff_company_field',
                    'from_date': 'date_range_field',
                    'to_date': 'date_range_field',
                    'contractor': 'contractor_field',
                    'is_completed': 'is_completed_field'
                };
                
                Object.keys(fieldMappings).forEach(param => {
                    if (urlParams.get(param)) {
                        const fieldId = fieldMappings[param];
                        const toggleId = fieldId.replace('_field', '_toggle');
                        const checkbox = $('#' + toggleId);
                        const field = $('#' + fieldId);
                        
                        if (checkbox.length && field.length) {
                            checkbox.prop('checked', true);
                            field.show();
                        }
                    }
                });
            }
        </script>

        <style>
            .form-check {
                padding-left: 1.5rem;
            }

            .form-check-input {
                margin-left: -1.5rem;
            }

            .form-label {
                font-weight: 500;
                margin-bottom: 0.5rem;
            }

            .form-label i {
                color: #6c757d;
            }

            .d-flex.gap-2 > * {
                margin-right: 0.5rem;
            }

            .d-flex.gap-2 > *:last-child {
                margin-right: 0;
            }

            /* Animation for field toggle */
            [id$="_field"] {
                transition: all 0.3s ease-in-out;
            }
        </style>
    @endpush
@endsection

