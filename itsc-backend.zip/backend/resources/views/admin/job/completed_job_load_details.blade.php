@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Load Details</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> <a
                                            href="{{ route('admin.job.completed-job') }}"> Completed
                                            Jobs List</a></li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> <a
                                            href="{{ route('admin.job.completed-job-details', $load_details?->job_id) }}">Jobs
                                            Details</a></li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Load Details</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-6" style="padding: 10px;">
                                            <div
                                                style="border: 1px solid #a9a9a9;border-radius: 10px;text-align: center;padding: 10px;">
                                                <i class="fa fa-location-dot text-success"></i>
                                                <h5 style="color:rgb(9, 9, 112)">Pickup Location</h5>
                                                <p>
                                                    {{ $load_details?->job?->source }}
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="padding: 10px;">
                                            <div
                                                style="border: 1px solid #a9a9a9;border-radius: 10px;text-align: center;padding: 10px;">
                                                <i class="fa fa-location-dot text-success"></i>
                                                <h5 style="color:rgb(9, 9, 112)">Drop Location</h5>
                                                <p>
                                                    {{ $load_details?->job?->destination }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div id="map"></div>
                                    </div>
                                    <div class="row" style="border: 1px solid #a9a9a9;padding: 10px;">
                                        <div class="col-md-5" style="text-align: left">
                                            <h4 style="color:rgb(100, 8, 8)">JOB NO: {{ $load_details?->job?->order_no }}
                                            </h4>
                                            <h4 style="color:rgb(100, 8, 8)">CAL ID: {{ $load_details?->job?->unique_id }}
                                            </h4>
                                            <h4 style="color:rgb(100, 8, 8)">Load No: {{ $load_details?->load_index }}</h4>

                                            @if ($load_details?->is_discarded == 0)
                                                <span class="badge badge-pill badge-success">
                                                    @if ($load_details?->status == 0)
                                                        Not Accepted
                                                    @elseif($load_details?->status == 1)
                                                        Accepted
                                                    @elseif($load_details?->status == 2)
                                                        Running
                                                    @elseif($load_details?->status == 3)
                                                        Complete from trucker
                                                    @else
                                                        Complete from contractor
                                                    @endif
                                                </span>
                                            @else
                                                <span class="badge badge-pill badge-danger">
                                                    Discarded
                                                </span>
                                            @endif
                                        </div>

                                         <div class="col-md-7" style="text-align: left">
                                            <h6 style="color:rgb(174, 153, 12)">Pickup Date & Time :
                                                {{ $load_details?->started_on != null ? date('m/d/Y h:i A', strtotime($load_details?->started_on)) : '--'  }}</h6>
                                            <h6 style="color:rgb(180, 180, 14)">Delivery Date & Time :
                                                {{  $load_details?->completed_on != null ? date('m/d/Y h:i A', strtotime($load_details?->completed_on)) : '--'  }}
                                            </h6>
                                        </div>
                                    </div>
                                    <div class="row">
                                        @if(!empty($load_details?->jobConfigureMapping?->challan_image_path))
                                        <div class="col-md-6">
                                            <div class="row mt-2" style="border: 1px solid #a9a9a9;padding: 10px;">
                                                <h4>Unsigned Ticket</h4>
                                                <img src="{{ $load_details?->jobConfigureMapping?->challan_image_path }}" style="width: 100%;height: 250px;" alt="">
                                                <a href="{{ $load_details?->jobConfigureMapping?->challan_image_path }}"><i class="fa fa-download"></i> Download</a>
                                            </div>
                                        </div>
                                        @endif
                                        @if(!empty($load_details?->jobConfigureMapping?->signature_image_path))
                                        <div class="col-md-6">
                                            <div class="row mt-2" style="border: 1px solid #a9a9a9;padding: 10px;">
                                                <h4>Completed Signature</h4>
                                                <img src="{{ $load_details?->jobConfigureMapping?->signature_image_path }}" style="width: 100%;height: 250px;" alt="">
                                                <a href="{{ $load_details?->jobConfigureMapping?->signature_image_path }}"><i class="fa fa-download"></i> Download</a>
                                            </div>
                                        </div>
                                        @endif
                                        @if(!empty($load_details?->jobConfigureMapping?->signed_challan_image_path))
                                        <div class="col-md-6">
                                            <div class="row mt-2" style="border: 1px solid #a9a9a9;padding: 10px;">
                                                <h4>Signed Ticket</h4>
                                                <img src="{{ $load_details?->jobConfigureMapping?->signed_challan_image_path }}" style="width: 100%;height: 250px;" alt="">
                                                <a href="{{ $load_details?->jobConfigureMapping?->signed_challan_image_path }}"><i class="fa fa-download"></i> Download</a>
                                            </div>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
        <script>
            function initMap() {
                var mapElement = document.getElementById('map');
                if (!mapElement) {
                    console.error('Error: Graph container element "map" not found in the document.');
                    return;
                }

                var map = new google.maps.Map(mapElement, {
                    zoom: 12,
                    center: {
                        lat: 82.2213456,
                        lng: 90.2345678
                    }
                });

                var directionsService = new google.maps.DirectionsService();
                var directionsRenderer = new google.maps.DirectionsRenderer({
                    map: map,
                    suppressMarkers: true // Do not automatically add markers
                });

                // Pickup marker
                var pickupLatLng = new google.maps.LatLng(parseFloat({{ $load_details?->job?->source_lat }}), parseFloat(
                    {{ $load_details?->job?->source_lng }}));
                var pickupMarker = new google.maps.Marker({
                    position: pickupLatLng,
                    map: map,
                    label: 'S'
                });

                // Create infowindow for pickup marker
                var pickupInfowindow = new google.maps.InfoWindow();

                // Fetch address for pickup point
                var pickupGeocoder = new google.maps.Geocoder();
                pickupGeocoder.geocode({
                    'location': pickupLatLng
                }, function(results, status) {
                    if (status === 'OK') {
                        if (results[0]) {
                            pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                                results[0].formatted_address + '</div>');
                        } else {
                            pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                                'Address not found</div>');
                        }
                    } else {
                        pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                            'Geocoder failed due to: ' + status + '</div>');
                    }
                });

                // Add click event listener for pickup marker
                pickupMarker.addListener('click', function() {
                    pickupInfowindow.open(map, pickupMarker);
                });

                // Destination marker
                var destinationLatLng = new google.maps.LatLng(parseFloat({{ $load_details?->job?->delivery_lat }}),
                    parseFloat(
                        {{ $load_details?->job?->delivery_lng }}));
                var destinationMarker = new google.maps.Marker({
                    position: destinationLatLng,
                    map: map,
                    label: 'D'
                });

                // Create infowindow for destination marker
                var destinationInfowindow = new google.maps.InfoWindow();

                // Fetch address for destination point
                var destinationGeocoder = new google.maps.Geocoder();
                destinationGeocoder.geocode({
                    'location': destinationLatLng
                }, function(results, status) {
                    if (status === 'OK') {
                        if (results[0]) {
                            destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                                results[0].formatted_address + '</div>');
                        } else {
                            destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                                'Address not found</div>');
                        }
                    } else {
                        destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                            'Geocoder failed due to: ' + status + '</div>');
                    }
                });

                // Add click event listener for destination marker
                destinationMarker.addListener('click', function() {
                    destinationInfowindow.open(map, destinationMarker);
                });

                // Set origin, destination, and waypoints for the route
                var routeRequest = {
                    origin: pickupLatLng,
                    destination: destinationLatLng,
                    travelMode: 'DRIVING'
                };

                // Request the directions and display on the map
                directionsService.route(routeRequest, function(response, status) {
                    if (status === 'OK') {
                        directionsRenderer.setDirections(response);
                    } else {
                        console.error('Directions request failed due to ' + status);
                    }
                });
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_API_KEY') }}&callback=initMap"></script>
            < script src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js" >
        </script>
    @endpush
@endsection
