<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Job Details Print View</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }

        h1 {
            color: #2c3e50;
        }

        #print-area h1 {
            margin-top: 0
        }

        .details {
            margin-bottom: 30px;
        }

        .images {
            display: flex;
            gap: 20px;
        }

        .ticket {
            flex: 1;
            width: 100%;
            text-align: center;
            margin: 0 auto;
        }

        .image-card {
            text-align: center;
            width: 30%;
        }

        .image-card img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            max-width: 120px;
        }

        .image-title {
            margin-top: 10px;
            font-weight: bold;
        }

        @media print {

            .print-btn,
            .download-btn {
                display: none !important;
            }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
</head>

<body>
    <table class="detailsTableTop" style="width:700px !important; border-collapse:collapse; margin:0 auto;">
        <tr>
            <td style="width: 100%; text-align: right;"><button class="print-btn" onclick="window.print()"
                    style="margin-bottom:20px;">Print/Download</button></td>
        </tr>
        <tr>
            <td style="text-align:center;">
                <div id="print-area">
                    <h1>Job Details</h1>
                    <table class="job-details-table" style="width:100%; border-collapse:collapse; margin-bottom:30px;">
                        <tbody>
                            <tr>
                                <td class="label">Job Posted By</td>
                                <td class="value">{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}</td>
                            </tr>
                            <tr>
                                <td class="label">Order No</td>
                                <td class="value">{{ $detail?->job?->order_no ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Unique ID</td>
                                <td class="value">{{ $detail?->job?->unique_id ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Ticket No</td>
                                <td class="value">{{ $detail?->ticket_no ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Material</td>
                                <td class="value">{{ $detail?->job?->jobMaterial?->title ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Source</td>
                                <td class="value">{{ $detail?->job?->source ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Destination</td>
                                <td class="value">{{ $detail?->job?->destination ?? '-' }}</td>
                            </tr>
                            <tr>
                                <td class="label">Started Date</td>
                                <td class="value">
                                    @if ($detail?->started_on)
                                        {{ date('m/d/Y h:i A', strtotime($detail->started_on)) }}
                                    @else
                                        -
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <td class="label">Completed Date</td>
                                <td class="value">
                                    @if ($detail?->completed_on)
                                        {{ date('m/d/Y h:i A', strtotime($detail->completed_on)) }}
                                    @else
                                        -
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <td class="label">Trucker Name</td>
                                <td class="value">{{ $detail?->trucker?->first_name }}
                                    {{ $detail?->trucker?->last_name }}</td>
                            </tr>
                            <tr>
                                <td class="label">Load Cost</td>
                                <td class="value">$ {{ number_format($value?->load_cost, 2) }}</td>
                            </tr>
                            <tr>
                                <td class="label">Cal Commission</td>
                                <td class="value">${{ $detail?->cal_comission }}</td>
                            </tr>
                            <tr>
                                <td class="label">Trucker Get</td>
                                <td class="value">${{ $detail?->trucker_get }}</td>
                            </tr>
                            <tr>
                                <td class="label">Description</td>
                                <td class="value">{{ $detail?->job?->description ?? '-' }}</td>
                            </tr>
                        </tbody>
                    </table>



                    <div class="images">
                        <div class="ticket">
                            @if (!empty($detail?->jobConfigureMapping?->challan_image_path))
                                <div class="image-card">
                                    <img src="{{ $detail?->jobConfigureMapping?->challan_image_path }}"
                                        alt="Unsigned Ticket">
                                </div>
                            @endif
                            <div class="image-title">Unsigned Ticket</div>
                        </div>
                        <div class="ticket">
                            @if (!empty($detail?->jobConfigureMapping?->signed_challan_image_path))
                                <div class="image-card">
                                    <img src="{{ $detail?->jobConfigureMapping?->signed_challan_image_path }}"
                                        alt="Signed Ticket">
                                </div>
                            @endif
                            <div class="image-title">Signed Ticket</div>
                        </div>
                        <div class="ticket">
                            @if (!empty($detail?->jobConfigureMapping?->signature_image_path))
                                <div class="image-card">
                                    <img src="{{ $detail?->jobConfigureMapping?->signature_image_path }}"
                                        alt="Signature">
                                </div>
                            @endif
                            <div class="image-title">Signature</div>
                        </div>

                    </div>
                </div>
            </td>
        </tr>

    </table>

    <style>
        #print-area {
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(44, 62, 80, 0.08);
        }

        button.print-btn {
            padding: 10px;
            border: 0;
            margin-bottom: 10px !important;
            font-size: 14px;
        }

        .job-details-table td {
            padding: 10px 12px;
            border: 1px solid #e1e1e1;
            text-align: left;
            font-size: 14px;
        }

        .job-details-table .label {
            font-weight: bold;
            background: #f7f7f7;
            color: #34495e;
            width: 180px;
            text-align: left
        }

        .job-details-table .value {
            color: #222;
        }

        .images {
            margin-top: 30px;
        }

        .image-card {
            background: #fafbfc;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            padding: 12px;
            transition: box-shadow 0.2s;
            width: max-content;
            margin: 0 auto;
        }

        .image-card:hover {
            box-shadow: 0 2px 12px rgba(44, 62, 80, 0.12);
        }

        .image-title {
            color: #2c3e50;
            margin-top: 0;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
    <script>
        function downloadPDF() {
            const element = document.getElementById('print-area');
            html2pdf().from(element).save('job-details.pdf').then(() => {
                setTimeout(() => {
                    // window.close();
                }, 1000);
            });
        }

        window.onload = async function() {
            await downloadPDF();
        };
    </script>
</body>

</html>
