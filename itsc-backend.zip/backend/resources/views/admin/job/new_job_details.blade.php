@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Jobs Details</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> <a href="{{ route('admin.job.new-job') }}"> New
                                            Jobs List</a></li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Jobs Details</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-6" style="padding: 10px;">
                                            <div
                                                style="border: 1px solid #a9a9a9;border-radius: 10px;text-align: center;padding: 10px;">
                                                <i class="fa fa-location-dot text-success"></i>
                                                <h5 style="color:rgb(9, 9, 112)">Pickup Location</h5>
                                                <p>
                                                    {{ $job->source }}
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="padding: 10px;">
                                            <div
                                                style="border: 1px solid #a9a9a9;border-radius: 10px;text-align: center;padding: 10px;">
                                                <i class="fa fa-location-dot text-success"></i>
                                                <h5 style="color:rgb(9, 9, 112)">Drop Location</h5>
                                                <p>
                                                    {{ $job->destination }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div id="map"></div>
                                    </div>
                                    <div class="row" style="border: 1px solid #a9a9a9;padding: 10px;">
                                        <div class="col-md-5" style="text-align: left">

                                            <h4 style="color:rgb(2, 26, 147)">Cal Id : {{ $job?->unique_id }}</h4>
                                            <h4 style="color:rgb(100, 8, 8)">Order Id : {{ $job?->order_no }}</h4>

                                            <p><b>Details :</b>Truck Types : {{ $job?->truck_type_names() }}</p>
                                            <p><b>Material Type : @if ($job?->material_other == null)
                                                        {{ $job?->jobMaterial?->title }}
                                                    @else
                                                        {{ $job->material_other }}
                                                    @endif
                                                </b></p>

                                            <p><b>Total Mileage : </b> {{ $job?->total_mileage }} miles</p>

                                            <p><b>Total Tons : </b> {{ $job?->jobLoad?->sum('weight') }}</p>
                                            <p><b>Job Load-Type : </b> {{ $job?->jobLoadType?->title }}</p>
                                            <p><b>Total Job Price : </b> {{ $job?->job_estimate_price ?? 'N/A' }}</p>
                                            <p><b>Job Posted By : </b>
                                                {{ $job?->JobPosted?->first_name . ' ' . $job?->JobPosted?->last_name }}
                                            </p>
                                            <p><b>Per Load Price :
                                                {{-- </b>${{ number_format($job?->jobLoad?->first()?->load_cost / $job?->jobLoad?->first()?->weight, 2) }} --}}
                                                </b>${{ number_format($job?->jobLoad?->first()?->load_cost) }}
                                            </p>
                                            <p><b>Per Unit Price:</b>
                                                @php
                                                    $load = $job?->jobLoad?->first();
                                                    $unitPrice = $load && $load->weight
                                                        ? number_format($load->load_cost / $load->weight, 2, '.', '') : '0.00';
                                                @endphp
                                                ${{ $unitPrice }}
                                            </p>
                                        </div>

                                        <div class="col-md-7" style="text-align: left">
                                            <h6 style="color:rgb(174, 153, 12)">Pickup Date & Time :
                                                {{ date('m/d/Y h:i A', strtotime($job?->pickup_date_time)) }}</h6>
                                            <h6 style="color:rgb(180, 180, 14)">Delivery Date & Time :
                                                {{ date('m/d/Y h:i A', strtotime($job?->delivery_date_time)) }}</h6>

                                            <h5 style="color:blue"><u>Pickup Details</u></h5>
                                            <p><b>Pickup contract : </b>{{ $job?->pickup_contact }}</p>
                                            <p><b>Pickup location company name : </b>{{ $job?->pickup_location_company }}
                                            </p>
                                            <p><b>Pickup location contact person email :
                                                </b>{{ $job?->pickup_location_email }}</p>
                                            <p><b>Pickup location contact person number :
                                                </b>{{ $job?->pickup_location_contact_no }}</p>

                                            <h5 style="color:blue"><u>Drop Details</u></h5>
                                            <p><b>Drop contract : </b>{{ $job?->drop_off_contact }}</p>
                                            <p><b>Drop location company name : </b>{{ $job?->drop_off_location_company }}
                                            </p>
                                            <p><b>Drop location contact person email :
                                                </b>{{ $job?->drop_off_location_email }}</p>
                                            <p><b>Drop location contact person number :
                                                </b>{{ $job?->drop_off_location_contact_no }}</p>



                                        </div>
                                    </div>
                                    <div class="row" style="border: 1px solid #a9a9a9;padding: 10px;">
                                        <h3> Loads Count</h3>
                                        <div class="accordion" id="accordionExample">
                                            <div class="accordion-item">
                                                <h2 class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="false" aria-controls="collapseOne">
                                                        Not Accepted : {{ $job?->jobLoad?->where('status', 0)->count() }}
                                                    </button>
                                                </h2>
                                                <div id="collapseOne" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <div class="table-responsive mt-2">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr
                                                                        class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                        <th>Status</th>
                                                                        <th>Company Truck No</th>
                                                                        <th>Truck LIC No</th>
                                                                        <th>Driver Name</th>
                                                                        <th>Weight</th>
                                                                        <th>Load Price</th>
                                                                        <th>Start Date</th>
                                                                        <th>End Date</th>

                                                                        <th>Details</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="fw-semibold text-gray-600">
                                                                    @forelse ($job->jobLoad->where('status', 0) as $detail)
                                                                        <tr>
                                                                            <td>
                                                                                @if ($detail?->is_discarded == 0)
                                                                                    <span
                                                                                        class="badge badge-pill badge-success">
                                                                                        @if ($detail?->status == 0)
                                                                                            Not Accepted
                                                                                        @elseif($detail?->status == 1)
                                                                                            Accepted
                                                                                        @elseif($detail?->status == 2)
                                                                                            Running
                                                                                        @elseif($detail?->status == 3)
                                                                                            Complete from trucker
                                                                                        @else
                                                                                            Complete from contractor
                                                                                        @endif
                                                                                    </span>
                                                                                @else
                                                                                    <span
                                                                                        class="badge badge-pill badge-danger">
                                                                                        Discarded
                                                                                    </span>
                                                                                @endif
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->weight }}</td>
                                                                            <td>{{ $detail?->load_cost }}</td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                                            </td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                                            </td>


                                                                            <td><a class="btn btn-primary btn-sm"
                                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                                        class="fa fa-eye"></i>View</a></td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr class="text-center">
                                                                            <td colspan="9">No Data Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h2 class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Accepted : {{ $job?->jobLoad?->where('status', 1)->count() }}
                                                    </button>
                                                </h2>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">

                                                        <div class="table-responsive mt-2">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr
                                                                        class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                        <th>Status</th>
                                                                        <th>Company Truck No</th>
                                                                        <th>Truck LIC No</th>
                                                                        <th>Driver Name</th>
                                                                        <th>Weight</th>
                                                                        <th>Load Price</th>
                                                                        <th>Start Date</th>
                                                                        <th>End Date</th>

                                                                        <th>Details</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="fw-semibold text-gray-600">
                                                                    @forelse ($job->jobLoad->where('status', 1) as $detail)
                                                                        <tr>
                                                                            <td>
                                                                                @if ($detail?->is_discarded == 0)
                                                                                    <span
                                                                                        class="badge badge-pill badge-success">
                                                                                        @if ($detail?->status == 0)
                                                                                            Not Accepted
                                                                                        @elseif($detail?->status == 1)
                                                                                            Accepted
                                                                                        @elseif($detail?->status == 2)
                                                                                            Running
                                                                                        @elseif($detail?->status == 3)
                                                                                            Complete from trucker
                                                                                        @else
                                                                                            Complete from contractor
                                                                                        @endif
                                                                                    </span>
                                                                                @else
                                                                                    <span
                                                                                        class="badge badge-pill badge-danger">
                                                                                        Discarded
                                                                                    </span>
                                                                                @endif
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->weight }}</td>
                                                                            <td>{{ $detail?->load_cost }}</td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                                            </td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                                            </td>


                                                                            <td><a class="btn btn-primary btn-sm"
                                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                                        class="fa fa-eye"></i>View</a></td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr class="text-center">
                                                                            <td colspan="9">No Data Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h2 class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        Running : {{ $job?->jobLoad?->where('status', 2)->count() }}
                                                    </button>
                                                </h2>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <div class="table-responsive mt-2">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr
                                                                        class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                        <th>Status</th>
                                                                        <th>Company Truck No</th>
                                                                        <th>Truck LIC No</th>
                                                                        <th>Driver Name</th>
                                                                        <th>Weight</th>
                                                                        <th>Load Price</th>
                                                                        <th>Start Date</th>
                                                                        <th>End Date</th>

                                                                        <th>Details</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="fw-semibold text-gray-600">
                                                                    @forelse ($job->jobLoad->where('status', 2) as $detail)
                                                                        <tr>
                                                                            <td>
                                                                                @if ($detail?->is_discarded == 0)
                                                                                    <span
                                                                                        class="badge badge-pill badge-success">
                                                                                        @if ($detail?->status == 0)
                                                                                            Not Accepted
                                                                                        @elseif($detail?->status == 1)
                                                                                            Accepted
                                                                                        @elseif($detail?->status == 2)
                                                                                            Running
                                                                                        @elseif($detail?->status == 3)
                                                                                            Complete from trucker
                                                                                        @else
                                                                                            Complete from contractor
                                                                                        @endif
                                                                                    </span>
                                                                                @else
                                                                                    <span
                                                                                        class="badge badge-pill badge-danger">
                                                                                        Discarded
                                                                                    </span>
                                                                                @endif
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->weight }}</td>
                                                                            <td>{{ $detail?->load_cost }}</td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                                            </td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                                            </td>


                                                                            <td><a class="btn btn-primary btn-sm"
                                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                                        class="fa fa-eye"></i>View</a></td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr class="text-center">
                                                                            <td colspan="9">No Data Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h2 class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Completed from trucker :
                                                        {{ $job?->jobLoad?->where('status', 3)->count() }}
                                                    </button>
                                                </h2>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <div class="table-responsive mt-2">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr
                                                                        class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                        <th>Status</th>
                                                                        <th>Company Truck No</th>
                                                                        <th>Truck LIC No</th>
                                                                        <th>Driver Name</th>
                                                                        <th>Weight</th>
                                                                        <th>Load Price</th>
                                                                        <th>Start Date</th>
                                                                        <th>End Date</th>

                                                                        <th>Details</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="fw-semibold text-gray-600">
                                                                    @forelse ($job->jobLoad->where('status', 3) as $detail)
                                                                        <tr>
                                                                            <td>
                                                                                @if ($detail?->is_discarded == 0)
                                                                                    <span
                                                                                        class="badge badge-pill badge-success">
                                                                                        @if ($detail?->status == 0)
                                                                                            Not Accepted
                                                                                        @elseif($detail?->status == 1)
                                                                                            Accepted
                                                                                        @elseif($detail?->status == 2)
                                                                                            Running
                                                                                        @elseif($detail?->status == 3)
                                                                                            Complete from trucker
                                                                                        @else
                                                                                            Complete from contractor
                                                                                        @endif
                                                                                    </span>
                                                                                @else
                                                                                    <span
                                                                                        class="badge badge-pill badge-danger">
                                                                                        Discarded
                                                                                    </span>
                                                                                @endif
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->weight }}</td>
                                                                            <td>{{ $detail?->load_cost }}</td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                                            </td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                                            </td>


                                                                            <td><a class="btn btn-primary btn-sm"
                                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                                        class="fa fa-eye"></i>View</a></td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr class="text-center">
                                                                            <td colspan="9">No Data Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h2 class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFive"
                                                        aria-expanded="false" aria-controls="collapseFive">
                                                        Completed from contractor :
                                                        {{ $job?->jobLoad?->where('status', 4)->count() }}
                                                    </button>
                                                </h2>
                                                <div id="collapseFive" class="accordion-collapse collapse"
                                                    data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <div class="table-responsive mt-2">
                                                            <table class="table table-bordered">
                                                                <thead>
                                                                    <tr
                                                                        class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                                        <th>Status</th>
                                                                        <th>Company Truck No</th>
                                                                        <th>Truck LIC No</th>
                                                                        <th>Driver Name</th>
                                                                        <th>Weight</th>
                                                                        <th>Load Price</th>
                                                                        <th>Start Date</th>
                                                                        <th>End Date</th>

                                                                        <th>Details</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="fw-semibold text-gray-600">
                                                                    @forelse ($job->jobLoad->where('status', 4) as $detail)
                                                                        <tr>
                                                                            <td>
                                                                                @if ($detail?->is_discarded == 0)
                                                                                    <span
                                                                                        class="badge badge-pill badge-success">
                                                                                        @if ($detail?->status == 0)
                                                                                            Not Accepted
                                                                                        @elseif($detail?->status == 1)
                                                                                            Accepted
                                                                                        @elseif($detail?->status == 2)
                                                                                            Running
                                                                                        @elseif($detail?->status == 3)
                                                                                            Complete from trucker
                                                                                        @else
                                                                                            Complete from contractor
                                                                                        @endif
                                                                                    </span>
                                                                                @else
                                                                                    <span
                                                                                        class="badge badge-pill badge-danger">
                                                                                        Discarded
                                                                                    </span>
                                                                                @endif
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                                            </td>
                                                                            <td>{{ $detail?->weight }}</td>
                                                                            <td>{{ $detail?->load_cost }}</td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                                            </td>
                                                                            <td>{{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                                            </td>


                                                                            <td><a class="btn btn-primary btn-sm"
                                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                                        class="fa fa-eye"></i>View</a></td>

                                                                        </tr>
                                                                    @empty
                                                                        <tr class="text-center">
                                                                            <td colspan="9">No Data Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="border: 1px solid #a9a9a9;padding: 10px;">
                                        <form method="POST"
                                            action="{{ route('admin.job.new-job-details', $job?->id) }}">
                                            @csrf
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <label>Start Date</label>
                                                    <input type="date" value="{{ request()['start_date'] }}"
                                                        class="form-control" name="start_date" />
                                                </div>
                                                <div class="col-md-2">
                                                    <label>End Date</label>
                                                    <input type="date" value="{{ request()['end_date'] }}"
                                                        class="form-control" name="end_date" />
                                                </div>
                                                <div class="col-md-2">
                                                    <label>Driver</label>
                                                    <select name="driver_id" class="form-control">
                                                        <option value="">Select One....</option>
                                                        @foreach ($drivers as $driver)
                                                            <option value="{{ $driver?->id }}"
                                                                {{ $driver?->id == request()['driver_id'] ? 'selected' : '' }}>
                                                                {{ $driver?->first_name }} {{ $driver?->last_name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-md-2">
                                                    <label>Company Truck No.</label>
                                                    <input type="text" value="{{ request()['company_truck_no'] }}"
                                                        class="form-control" name="company_truck_no" />
                                                </div>
                                                <div class="col-md-2">
                                                    <label>Truck LIC No.</label>
                                                    <input type="text" value="{{ request()['truck_lic_no'] }}"
                                                        class="form-control" name="truck_lic_no" />
                                                </div>
                                                <div class="col-md-3 mt-2">

                                                    <button class="btn btn-success btn-sm mt-5" type="submit"><i
                                                            class="fa fa-search"></i> Search</button>
                                                    <a class="btn btn-danger btn-sm mt-5"
                                                        href="{{ route('admin.job.all-job-details', $job->id) }}">Clear</a>
                                                </div>
                                            </div>

                                        </form>
                                        <h3> Loads</h3>
                                        <div class="table-responsive mt-2">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                                        <th>Status</th>
                                                        <th>Company Truck No</th>
                                                        <th>Truck LIC No</th>
                                                        <th>Driver Name</th>
                                                        <th>Weight</th>
                                                        <th>Load Price</th>
                                                        <th>Start Date</th>
                                                        <th>End Date</th>

                                                        <th>Details</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="fw-semibold text-gray-600">
                                                    @forelse ($job->jobLoad as $detail)
                                                        <tr>
                                                            <td>
                                                                @if ($detail?->is_discarded == 0)
                                                                    <span class="badge badge-pill badge-success">
                                                                        @if ($detail?->status == 0)
                                                                            Not Accepted
                                                                        @elseif($detail?->status == 1)
                                                                            Accepted
                                                                        @elseif($detail?->status == 2)
                                                                            Running
                                                                        @elseif($detail?->status == 3)
                                                                            Complete from trucker
                                                                        @else
                                                                            Complete from contractor
                                                                        @endif
                                                                    </span>
                                                                @else
                                                                    <span class="badge badge-pill badge-danger">
                                                                        Discarded
                                                                    </span>
                                                                @endif
                                                            </td>
                                                            <td>{{ $detail?->userTruckDetails?->company_truck_number ?? '--' }}
                                                            </td>
                                                            <td>{{ $detail?->userTruckDetails?->truck_license_no ?? '--' }}
                                                            </td>
                                                            <td>{{ $detail?->userDetails != null ? $detail?->userDetails?->first_name . ' ' . $detail?->userDetails?->last_name : '--' }}
                                                            </td>
                                                            <td>{{ $detail?->weight }}</td>
                                                            <td>{{ $detail?->load_cost }}</td>
                                                            <td>{{ $detail?->started_on != null ? date('m/d/Y h:i A', strtotime($detail?->started_on)) : '--' }}
                                                            </td>
                                                            <td>{{ $detail?->completed_on != null ? date('m/d/Y h:i A', strtotime($detail?->completed_on)) : '--' }}
                                                            </td>


                                                            <td><a class="btn btn-primary btn-sm"
                                                                    href="{{ route('admin.job.running-job-load-details', $detail?->id) }}"><i
                                                                        class="fa fa-eye"></i>View</a></td>

                                                        </tr>
                                                    @empty
                                                        <tr class="text-center">
                                                            <td colspan="9">No Data Found</td>
                                                        </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
        <script>
            function initMap() {
                var mapElement = document.getElementById('map');
                if (!mapElement) {
                    console.error('Error: Graph container element "map" not found in the document.');
                    return;
                }

                var map = new google.maps.Map(mapElement, {
                    zoom: 12,
                    center: {
                        lat: 82.2213456,
                        lng: 90.2345678
                    }
                });

                var directionsService = new google.maps.DirectionsService();
                var directionsRenderer = new google.maps.DirectionsRenderer({
                    map: map,
                    suppressMarkers: true // Do not automatically add markers
                });

                // Pickup marker
                var pickupLatLng = new google.maps.LatLng(parseFloat({{ $job->source_lat }}), parseFloat(
                    {{ $job->source_lng }}));
                var pickupMarker = new google.maps.Marker({
                    position: pickupLatLng,
                    map: map,
                    label: 'S'
                });

                // Create infowindow for pickup marker
                var pickupInfowindow = new google.maps.InfoWindow();

                // Fetch address for pickup point
                var pickupGeocoder = new google.maps.Geocoder();
                pickupGeocoder.geocode({
                    'location': pickupLatLng
                }, function(results, status) {
                    if (status === 'OK') {
                        if (results[0]) {
                            pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                                results[0].formatted_address + '</div>');
                        } else {
                            pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                                'Address not found</div>');
                        }
                    } else {
                        pickupInfowindow.setContent('<div><strong>Pickup Location</strong><br>' +
                            'Geocoder failed due to: ' + status + '</div>');
                    }
                });

                // Add click event listener for pickup marker
                pickupMarker.addListener('click', function() {
                    pickupInfowindow.open(map, pickupMarker);
                });

                // Destination marker
                var destinationLatLng = new google.maps.LatLng(parseFloat({{ $job->delivery_lat }}), parseFloat(
                    {{ $job->delivery_lng }}));
                var destinationMarker = new google.maps.Marker({
                    position: destinationLatLng,
                    map: map,
                    label: 'D'
                });

                // Create infowindow for destination marker
                var destinationInfowindow = new google.maps.InfoWindow();

                // Fetch address for destination point
                var destinationGeocoder = new google.maps.Geocoder();
                destinationGeocoder.geocode({
                    'location': destinationLatLng
                }, function(results, status) {
                    if (status === 'OK') {
                        if (results[0]) {
                            destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                                results[0].formatted_address + '</div>');
                        } else {
                            destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                                'Address not found</div>');
                        }
                    } else {
                        destinationInfowindow.setContent('<div><strong>Destination Location</strong><br>' +
                            'Geocoder failed due to: ' + status + '</div>');
                    }
                });

                // Add click event listener for destination marker
                destinationMarker.addListener('click', function() {
                    destinationInfowindow.open(map, destinationMarker);
                });

                // Set origin, destination, and waypoints for the route
                var routeRequest = {
                    origin: pickupLatLng,
                    destination: destinationLatLng,
                    travelMode: 'DRIVING'
                };

                // Request the directions and display on the map
                directionsService.route(routeRequest, function(response, status) {
                    if (status === 'OK') {
                        directionsRenderer.setDirections(response);
                    } else {
                        console.error('Directions request failed due to ' + status);
                    }
                });
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_API_KEY') }}&callback=initMap">
        </script>
        <script>
            function export_data() {
                let data = document.getElementById('new-job-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'new-job-list.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
