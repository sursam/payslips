@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    All Loads List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> All Loads List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="container">
                                <!-- Filter Section -->
                                <form action="{{ route('admin.job.all-loads') }}" method="GET">
                                    @csrf
                                    <div class="card p-3">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <label for="job_unique_id">Job Unique Id</label>
                                                <select id="job_unique_id" class="form-control select222" name="job_unique_id">
                                                    <option value="">Select Job Unique Id</option>
                                                    @foreach ($job_unique_ids as $job_unique_id)
                                                        <option value="{{ $job_unique_id }}"
                                                            {{ request('job_unique_id') == $job_unique_id ? 'selected' : '' }}>
                                                            {{ $job_unique_id }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label for="search">Destination</label>
                                                <select id="search" class="form-control select222" name="search">
                                                    <option value="">Select Destination</option>
                                                    @foreach ($destinations as $destination)
                                                        <option value="{{ $destination }}"
                                                            {{ request('search') == $destination ? 'selected' : '' }}>
                                                            {{ $destination }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label for="source">Source</label>
                                                <select id="source" class="form-control select222" name="source">
                                                    <option value="">Select Source</option>
                                                    @foreach ($sources as $source)
                                                        <option value="{{ $source }}"
                                                            {{ request('source') == $source ? 'selected' : '' }}>
                                                            {{ $source }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-3">
                                                <label for="pickup_company">Pickup Company</label>
                                                <select id="pickup_company" class="form-control select222" name="pickup_company">
                                                    <option value="">Select Pickup Company</option>
                                                    @foreach ($all_pickup_locations as $pickup_locations)
                                                        <option value="{{ $pickup_locations }}"
                                                            {{ request('pickup_company') == $pickup_locations ? 'selected' : '' }}>
                                                            {{ $pickup_locations }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="dropoff_company">Dropoff Company</label>
                                                <select id="dropoff_company" class="form-control select222" name="dropoff_company">
                                                    <option value="">Select Dropoff Company</option>
                                                    @foreach ($all_dropoff_locations as $dropoff_locations)
                                                        <option value="{{ $dropoff_locations }}"
                                                            {{ request('dropoff_company') == $dropoff_locations ? 'selected' : '' }}>
                                                            {{ $dropoff_locations }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="contractor">Contractor</label>
                                                <select id="contractor" class="form-control select222" name="contractor">
                                                    <option value="">Select Contractor</option>
                                                    @foreach ($all_contractors as $contractor)
                                                        <option value="{{ $contractor->id }}"
                                                            {{ request('contractor') == $contractor->id ? 'selected' : '' }}>
                                                            {{ $contractor->first_name . ' ' . $contractor->last_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="trucker">Trucker</label>
                                                <select id="trucker" class="form-control select222" name="trucker">
                                                    <option value="">Select Trucker</option>
                                                    @foreach ($all_trucker as $trucker)
                                                        <option value="{{ $trucker->id }}"
                                                            {{ request('trucker') == $trucker->id ? 'selected' : '' }}>
                                                            {{ $trucker->first_name . ' ' . $trucker->last_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Started From Date</label>
                                                    <input type="date" class="form-control"
                                                        value="{{ request('from_date') }}" name="from_date" id="from_date">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Started To Date</label>
                                                    <input type="date" class="form-control" name="to_date"
                                                        value="{{ request('to_date') }}" id="to_date">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Completed From Date</label>
                                                    <input type="date" class="form-control"
                                                        value="{{ request('completed_from_date') }}"
                                                        name="completed_from_date" id="completed_from_date">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="job_unique_id"> Completed To Date</label>
                                                    <input type="date" class="form-control" name="completed_to_date"
                                                        value="{{ request('completed_to_date') }}"
                                                        id="completed_to_date">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-2">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="ticket_no">Ticket No</label>
                                                    <input type="text" class="form-control" name="ticket_no" placeholder="Ticket No"
                                                        value="{{ request('ticket_no') }}" id="ticket_no">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <label for="per_page">Results per page</label>
                                                <select id="per_page" class="form-control select222" name="per_page">
                                                    <option value="10"
                                                        {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                    </option>
                                                    <option value="25"
                                                        {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                    </option>
                                                    <option value="50"
                                                        {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                    </option>
                                                    <option value="100"
                                                        {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                        100</option>
                                                    <option value="all"
                                                        {{ request('per_page') == 'all' ? 'selected' : '' }}>all</option>
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for="job_unique_id">Is Load Completed</label>
                                                    <select class="form-control" name="is_completed" id="is_completed">
                                                        <option value="">Select</option>
                                                        <option value="1"
                                                            {{ request('is_completed') == 1 ? 'selected' : '' }}>
                                                            Yes</option>
                                                        <option value="0"
                                                            {{ request('is_completed') == 0 ? 'selected' : '' }}>
                                                            No</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="">
                                                <button type="submit" class="btn btn-primary mt-8"><i
                                                        class="fas fa-search"></i>
                                                    Search</button>
                                                <button type="button" onclick="export_data()"
                                                    class="btn btn-success mt-8"><i class="fa fa-file-excel-o"></i>
                                                    Export</button>

                                                <a href="{{ route('admin.job.all-loads') }}"
                                                    class="btn btn-warning mt-8">
                                                    Reset</a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="all-job-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Unique Id</th>
                                            <th>Contractor Name</th>
                                            <th>Order No</th>
                                            <th>Pickup Company Name</th>
                                            <th>Drop Off Company Name</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Started Date</th>
                                            <th>Completed Date</th>
                                            <th>Trucker Name </th>
                                            <th>Rate/QTY</th>
                                            <th>Load Weight(TON)</th>
                                            <th>Ticket No</th>
                                            <th>Load Cost</th>
                                            <th>Cal Commission</th>
                                            <th>Trucker Get</th>
                                            <th>Unsigned Ticked</th>
                                            <th>Signed Ticked</th>
                                            <th>Signature</th>
                                            <th>Price Per Unit</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($all_loads as $detail)
                                            <tr>
                                                <td>
                                                    <a
                                                        href="{{ route('admin.job.all-job-details', $detail?->job?->id) }}">{{ $detail?->job?->unique_id }}</a><br>
                                                    <span class="badge badge-pill badge-success">
                                                        @if ($detail?->job?->status == 1)
                                                            New
                                                        @elseif($detail?->job?->status == 2)
                                                            Accepted
                                                        @elseif($detail?->job?->status == 3)
                                                            Completed
                                                        @elseif($detail?->job?->status == 4)
                                                            Cancelled
                                                        @elseif($detail?->job?->status == 5)
                                                            Past
                                                        @else
                                                            Closed
                                                        @endif
                                                    </span>
                                                    @if ($detail?->job?->is_draft == 1)
                                                        <span class="badge badge-pill badge-danger">Draft</span>
                                                    @endif
                                                </td>
                                                <td>{{ $detail?->job?->user?->first_name . ' ' . $detail?->job?->user?->last_name }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->order_no }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->pickup_location_company ?? 'NA' }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->drop_off_location_company ?? 'NA' }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->source }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->destination }}
                                                </td>
                                                <td>
                                                    @if ($detail?->started_on != null)
                                                        {{ date('m/d/Y h:i A', strtotime($detail?->started_on)) }}
                                                    @endif

                                                </td>
                                                <td>
                                                    @if ($detail?->completed_on != null)
                                                        {{ date('m/d/Y h:i A', strtotime($detail?->completed_on)) }}
                                                    @endif
                                                </td>
                                                <td> {{ $detail?->trucker ? $detail?->trucker?->first_name . ' ' . $detail?->trucker?->last_name : 'NA' }}
                                                </td>

                                                {{-- <td>{{ $detail?->job?->job_estimate_price ?? 'N/A' }}</td> --}}
                                                <td>$ {{ number_format($detail?->load_cost / $detail?->weight, 2) }}</td>
                                                <td>{{ $detail?->weight ?? 'N/A' }}</td>
                                                <td> {{ $detail?->ticket_no ?? 'N/A' }}</td>

                                                <td> {{ number_format($detail?->load_cost, 2) }}</td>
                                                <td> {{ $detail?->cal_comission }}</td>
                                                <td> {{ $detail?->trucker_get ?? 'N/A' }}</td>

                                                <td>
                                                    @if (!empty($detail?->jobConfigureMapping?->challan_image_path))
                                                        <img src="{{ $detail?->jobConfigureMapping?->challan_image_path }}"
                                                            style="width: 100%;height: 50px;" alt="">
                                                    @endif
                                                </td>
                                                <td>
                                                    @if (!empty($detail?->jobConfigureMapping?->signed_challan_image_path))
                                                        <img src="{{ $detail?->jobConfigureMapping?->signed_challan_image_path }}"
                                                            style="width: 100%;height: 50px;" alt="">
                                                    @endif
                                                </td>
                                                <td>
                                                    @if (!empty($detail?->jobConfigureMapping?->signature_image_path))
                                                        <img src="{{ $detail?->jobConfigureMapping?->signature_image_path }}"
                                                            style="width: 100%;height: 50px;" alt="">
                                                    @endif
                                                </td>


                                                <td>{{ $detail?->job?->per_unit ?? 'N/A' }}</td>
                                                <td>
                                                    <a class="btn btn-sm btn-primary btn-sm"
                                                        href="{{ route('admin.job.all-job-load-details', $detail?->id) }}"><i
                                                            class="fa fa-eye"></i>View</a>
                                                    <a class="btn btn-sm btn-success btn-sm" target="_blank"
                                                        href="{{ route('admin.job.load-print', $detail?->id) }}"><i
                                                            class="fa fa-print"></i>Print</a>
                                                </td>

                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                @if (request('per_page') != 'all')
                                    {!! $all_loads->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('all-job-list');
                let tempTable = document.createElement('table');

                for (let i = 0; i < data.rows.length; i++) {
                    let row = data.rows[i];
                    let tempRow = tempTable.insertRow();

                    // Copy all cells except the last one (Actions)
                    for (let j = 0; j < row.cells.length - 1; j++) {
                        let cell = tempRow.insertCell();
                        // If the cell contains an image, export its src
                        let img = row.cells[j].querySelector('img');
                        let text = row.cells[j].innerText;

                        // Format Started Date (index 4) and Completed Date (index 5)
                        if ((j === 4 || j === 5) && text.trim() !== "") {
                            // Try to parse date in m/d/Y h:i A and convert to Y-m-d
                            let date = new Date(text);
                            if (!isNaN(date.getTime())) {
                                let y = date.getFullYear();
                                let m = String(date.getMonth() + 1).padStart(2, '0');
                                let d = String(date.getDate()).padStart(2, '0');
                                cell.innerText = `${y}-${m}-${d}`;
                            } else {
                                cell.innerText = text;
                            }
                        } else if (img) {
                            cell.innerText = img.src;
                        } else {
                            cell.innerHTML = text;
                        }
                    }
                }

                var fp = XLSX.utils.table_to_book(tempTable, {
                    sheet: 'report'
                });
                XLSX.writeFile(fp, 'load-list.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>

    @endpush
@endsection

