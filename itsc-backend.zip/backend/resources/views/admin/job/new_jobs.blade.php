@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    New Jobs List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> New Jobs List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="container">
                                <form method="GET" action="{{ route('admin.job.new-job') }}">
                                    <div class="card p-3">

                                        <div class="row mb-3">
                                            <div class="col-md-3">
                                                <label for="status">Unique Id</label>
                                                <input type="text" id="unique_id" name="unique_id"
                                                    placeholder="Search by Unique ID" class="form-control"
                                                    value="{{ request('unique_id') }}" />
                                            </div>
                                            <div class="col-md-3">
                                                <label for="status">Order No</label>
                                                <input type="text" id="order_no" name="order_no"
                                                    placeholder="Search by Order No." class="form-control"
                                                    value="{{ request('order_no') }}" />
                                            </div>
                                            <div class="col-md-3">
                                                <label for="status">Source</label>
                                                <input type="text" id="source" name="source" placeholder="Source"
                                                    class="form-control" value="{{ request('source') }}" />
                                            </div>
                                            <div class="col-md-3">
                                                <label for="status">Destination</label>
                                                <input type="text" id="destination" name="destination"
                                                    placeholder="Destination" class="form-control"
                                                    value="{{ request('destination') }}" />
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-3">
                                                <label for="status">Pickup Date</label>
                                                <input type="date" id="pickup_date" name="pickup_date"
                                                    class="form-control" value="{{ request('pickup_date') }}" />
                                            </div>
                                            <div class="col-md-3">
                                                <label for="status">Delivery Date</label>
                                                <input type="date" id="delivery_date" name="delivery_date"
                                                    class="form-control" value="{{ request('delivery_date') }}" />
                                            </div>
                                            <div class="col-md-2">
                                                <label for="per_page">Results per page</label>
                                                <select id="per_page" class="form-control" name="per_page">
                                                    <option value="10"
                                                        {{ request('per_page') == 10 ? 'selected' : '' }}>10</option>
                                                    <option value="25"
                                                        {{ request('per_page') == 25 ? 'selected' : '' }}>25</option>
                                                    <option value="50"
                                                        {{ request('per_page') == 50 ? 'selected' : '' }}>50</option>
                                                    <option value="100"
                                                        {{ request('per_page') == 100 ? 'selected' : '' }}>100</option>
                                                    <option value="all"
                                                        {{ request('per_page') == 'all' ? 'selected' : '' }}>all</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <button class="btn btn-primary mt-5" type="submit">
                                                    <i class="fa fa-search"></i> Search
                                                </button>
                                                <a class="btn btn-info mt-5"
                                                    href="{{ route('admin.job.new-job') }}">Reset</a>
                                                <button class="btn btn-success mt-5" type="button" onclick="export_data()"
                                                    data-toggle="tooltip" title="Export Data">
                                                    <i class="fa fa-file-excel"></i> Export
                                                </button>
                                            </div>

                                        </div>

                                    </div>
                                </form>
                            </div>


                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="new-job-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Unique Ids</th>
                                            <th>Order No</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Pickup Date</th>
                                            <th>Delivery Date</th>

                                            <th>Total Mileage</th>
                                            <th>Total Tons</th>
                                            <th>Job Load Type</th>
                                            <th>Total Loads</th>
                                            <th>Spacing(MIN)</th>
                                            <th>Unit Price($)</th>
                                            <th>Job Estimated Price($)</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($job_list as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    <a
                                                        href="{{ route('admin.job.new-job-details', $detail?->id) }}">{{ $detail?->unique_id }}</a><br>
                                                    <span class="badge badge-pill badge-success">
                                                        @if ($detail?->status == 1)
                                                            New
                                                        @elseif($detail?->status == 2)
                                                            Accepted
                                                        @elseif($detail?->status == 3)
                                                            Completed
                                                        @elseif($detail?->status == 4)
                                                            Cancelled
                                                        @elseif($detail?->status == 5)
                                                            Past
                                                        @else
                                                            Closed
                                                        @endif
                                                    </span>
                                                    @if ($detail?->is_draft == 1)
                                                        <span class="badge badge-pill badge-danger">Draft</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    {{ $detail?->order_no }}
                                                </td>
                                                <td>
                                                    {{ $detail?->source }}
                                                </td>
                                                <td>
                                                    {{ $detail?->destination }}
                                                </td>
                                                <td>
                                                    {{ date('m/d/Y h:i A', strtotime($detail?->pickup_date_time)) }}
                                                </td>
                                                <td>
                                                    {{ date('m/d/Y h:i A', strtotime($detail?->delivery_date_time)) }}
                                                </td>

                                                <td>
                                                    {{ $detail?->total_mileage }}
                                                </td>
                                                <td>
                                                    {{ $detail?->jobLoad?->sum('weight') }}
                                                </td>
                                                <td>
                                                    {{ $detail?->jobLoadType?->title }}
                                                </td>
                                                <td>
                                                    {{ $detail?->totalLoad() }}
                                                </td>
                                                <td>
                                                    {{ $detail?->load_spacing_minutes }}
                                                </td>
                                                <td>
                                                    {{ $detail?->per_unit_price }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job_estimate_price }}
                                                </td>

                                                <td><a class="btn btn-sm btn-primary"
                                                        href="{{ route('admin.job.new-job-details', $detail?->id) }}"><i
                                                            class="fa fa-eye"></i>View</a></td>

                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                @if (request('per_page') != 'all')
                                    {!! $job_list->appends(request()->all())->links('pagination::bootstrap-5') !!}
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('new-job-list');

                // Create a temporary table to hold the modified data
                let tempTable = document.createElement('table');

                // Iterate through the rows of the original table
                for (let i = 0; i < data.rows.length; i++) {
                    let row = data.rows[i];
                    let tempRow = tempTable.insertRow();

                    // Copy all cells except the last one
                    for (let j = 0; j < row.cells.length - 1; j++) {
                        let cell = tempRow.insertCell();
                        cell.innerHTML = row.cells[j].innerHTML;
                    }
                }

                // Convert the temporary table to a workbook
                var fp = XLSX.utils.table_to_book(tempTable, {
                    sheet: 'report'
                });

                // Write the file
                XLSX.writeFile(fp, 'new-job-list.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
