@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Rating & Review List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">Rating & Review List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip" data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-4 text-right">

                                        </div>
                                        <div class="col-md-4 text-right">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="user-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">Sl No</th>
                                            <th class="min-w-125px">Job Unique Id</th>
                                            <th class="min-w-125px">Load Id</th>
                                            <th class="min-w-70px">User</th>
                                            <th class="min-w-70px">Comment</th>
                                            <th class="min-w-70px">Rating</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($ratings as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{$detail?->jobDetails?->unique_id}}</td>
                                                <td>{{$detail?->load_id}}</td>
                                                <td>{{$detail?->userDetails?->first_name.' '.$detail?->userDetails?->last_name}}</td>
                                               <td>{{$detail?->comment}}</td>
                                               <td><span class="badge badge-success"><i class="fa-solid fa-star"></i> {{$detail?->rating}}</span></td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $ratings->appends(['per_page' => request('per_page'), 'search' => request('search')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function export_data() {
                let data = document.getElementById('user-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'user-List.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
