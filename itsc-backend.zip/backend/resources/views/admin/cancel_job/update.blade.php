@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">

            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card custom-margin">
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <h1
                                        class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                        Cancel Job Setup Update</h1>
                                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.dashboard') }}"
                                                class="text-muted text-hover-primary">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-muted">
                                            <a href="#"
                                                class="text-muted text-hover-primary">  Cancel Job Setup Update</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-6">
                            <div class="container">
                                <form id="EquipmentForm" action="{{ route('admin.cancel-job.update') }}" method="POST"
                                    class="formSubmit fileUpload" enctype="multipart/form-data">
                                    <input type="hidden" name="id" name="id" value="{{ $details->id ?? null }}">
                                    <div class="row pt-2 mb-2">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="whole_job_cancel_fees" class="label-style">Whole Job Cancel Fees
                                                </label>
                                                <input type="text" name="whole_job_cancel_fees"
                                                    class="form-control number-only"  id="whole_job_cancel_fees"
                                                    value="{{ $details->whole_job_cancel_fees ?? null }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="whole_job_cancel_fees_type" class="label-style">Whole Job Cancel Fees Type </label>
                                                <select name="whole_job_cancel_fees_type" id="whole_job_cancel_fees_type" class="form-control">
                                                    <option value="">Select One .....</option>
                                                    <option value="1" @if(!empty($details)) {{ $details->whole_job_cancel_fees_type == '1' ? 'selected' : ''  }} @endif >In Percentage(%)</option>
                                                    <option value="0" @if(!empty($details)) {{ $details->whole_job_cancel_fees_type == '0' ? 'selected' : ''  }} @endif>Fixed Value</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row pt-2 mb-2">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="load_cancel_fees" class="label-style">Load Cancel Fees
                                                </label>
                                                <input type="text" name="load_cancel_fees"
                                                    class="form-control number-only"  id="load_cancel_fees"
                                                    value="{{ $details->load_cancel_fees ?? null }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="load_cancel_fees_type" class="label-style">Load Cancel Fees Type </label>
                                                <select name="load_cancel_fees_type" id="load_cancel_fees_type" class="form-control">
                                                    <option value="">Select One .....</option>
                                                    <option value="1" @if(!empty($details)) {{ $details->load_cancel_fees_type == 1 ? 'selected' : ''  }} @endif >In Percentage(%)</option>
                                                    <option value="0" @if(!empty($details)) {{ $details->load_cancel_fees_type == 0 ? 'selected' : ''  }} @endif>Fixed Value</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>






                                    <div class="button add-btn-div-save-style">
                                        <button type="submit" id="submitBtn" class="btn btn-info">
                                            <span
                                                class="indicator-label">{{ !empty($details) ? 'Update' : 'Save' }}</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')

    @endpush
@endsection
