@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">

            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card custom-margin">
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <h1
                                        class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                        Help Question {{ !empty($details) ? 'Edit' : 'Add' }}</h1>
                                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.dashboard') }}"
                                                class="text-muted text-hover-primary">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.help-question.list') }}"
                                                class="text-muted text-hover-primary">Help Question</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-6">
                            <div class="container">
                                <form id="help-questionForm" action="{{ route('admin.help-question.add') }}" method="POST"
                                    class="formSubmit fileUpload" enctype="multipart/form-data">
                                    <input type="hidden" name="id" name="id" value="{{ $details->id ?? null }}">
                                    <div class="row pt-2">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="title" class="label-style">Type <span class="text-danger">*</span></label>
                                                <select name="role" id="role" class="form-control">
                                                    @foreach ($role as $value)
                                                        <option value="{{$value->id}}" @if(!empty($details)) {{$value->id == $details?->role_id ? 'selected' : ''}} @endif>{{$value->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label for="title" class="label-style">Question <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" placeholder="Enter Question"
                                                    name="title" id="title" value="{{ $details?->title ?? null }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row pt-2">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description" class="label-style">Short Description</label>
                                                <textarea class="form-control" name="description" id="description" cols="30" rows="4">{{ $details?->description ?? null }}</textarea>
                                            </div>
                                        </div>
                                    </div>




                                    <div class="button add-btn-div-save-style">
                                        <button type="submit" id="submitBtn" class="btn btn-info">
                                            <span class="indicator-label">{{ !empty($details) ? 'Update' : 'Save' }}</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
    <script src="{{ asset('assets/js/custom_js/cdn/ckeditor.js') }}"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#description'))
            .then(editor => {
                editor.model.document.on('change:data', () => {
                    let editorData = editor.getData();
                    $('#description').val(editorData);
                });
            })
            .catch(err => {
                console.error(err.stack);
            });
    </script>
    @endpush
@endsection
