@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Cancel Loads List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">Cancel Loads List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip" data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-4 text-right">

                                        </div>
                                        <div class="col-md-4 text-right">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="user-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th class="min-w-50px">Sl No</th>
                                            <th class="min-w-125px">Job Unique Id</th>
                                            <th class="min-w-125px">Order No</th>
                                            <th class="min-w-70px">Source</th>
                                            <th class="min-w-70px">Destination</th>
                                            <th class="min-w-70px">Picked Date</th>
                                            <th class="min-w-70px">Delivery Date</th>
                                            <th class="min-w-70px">Truck No</th>
                                            <th class="min-w-70px">Truck LIC No.</th>
                                            <th class="min-w-70px">Trucker</th>
                                            <th class="min-w-70px">Total Tons</th>
                                            <th class="min-w-70px">Job Load Type</th>
                                            <th class="min-w-70px">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($cancel_jobs as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>

                                                <td>{{ $detail?->job?->unique_id ?? '--' }}</td>
                                                <td>{{ $detail?->job?->order_no ?? '--' }}</td>
                                                <td>{{ $detail?->job?->source ?? '--' }}</td>
                                                <td>{{ $detail?->job?->destination ?? '--' }}</td>
                                                <td>{{ date('m/d/Y h:i A',strtotime($detail?->job?->picked_date)) }}</td>
                                                <td>{{ date('m/d/Y h:i A',strtotime($detail?->job?->delivery_date)) }}</td>
                                                <td>{{ $detail?->loadDetails?->userTruckDetails?->company_truck_number ?? '--' }}</td>
                                                <td>{{ $detail?->loadDetails?->userTruckDetails?->truck_license_no ?? '--' }}</td>
                                                <td>{{ $detail?->truckerDetails?->first_name.' '.$detail?->truckerDetails?->last_name ?? '--' }}</td>
                                                <td>{{ $detail?->loadDetails?->sum('weight') ?? '--' }}</td>
                                                <td>{{ $detail?->job?->truck_type_names() ?? '--' }}</td>
                                                <td>
                                                    <span class="badge badge-success">
                                                        @if($detail?->status == 1)
                                                            Accepted
                                                        @elseif($detail?->status == 2)
                                                            Running
                                                        @elseif($detail?->status == 3)
                                                            Completed
                                                        @endif
                                                    </span>
                                                    <span class="badge badge-info">
                                                        @if($detail?->is_picked_up == 1)
                                                            Picked UP
                                                        @else
                                                            Not Picked UP
                                                        @endif
                                                    </span>
                                                    <span class="badge badge-danger">
                                                        @if($detail?->is_picked_up == 1)
                                                            Returned
                                                        @else
                                                            Not Returned
                                                        @endif
                                                    </span>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $cancel_jobs->appends(['per_page' => request('per_page'), 'search' => request('search')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            // $(document).ready(function() {
            //     var table = $('#User-list').DataTable({
            //         paging: false,
            //         lengthChange: true,
            //         searching: true,
            //         ordering: true,
            //         info: false,
            //         autoWidth: false,
            //         responsive: true,
            //         lengthMenu: [
            //             [25, 50, 75, 100, -1],
            //             [25, 50, 75, 100, 'All']
            //         ],
            //         language: {
            //             paginate: {
            //                 previous: '<i class="fas fa-chevron-left"></i>',
            //                 next: '<i class="fas fa-chevron-right"></i>'
            //             },
            //             lengthMenu: 'Show _MENU_ entries',
            //             search: 'Search:',
            //             info: 'Showing _START_ to _END_ of _TOTAL_ entries',
            //             infoEmpty: 'Showing 0 to 0 of 0 entries',
            //             infoFiltered: '(filtered from _MAX_ total entries)'
            //         }
            //     });

            //     // Export functionality
            //     $('#export-button').on('click', function() {
            //         export_data();
            //     });
            // });

            function export_data() {
                let data = document.getElementById('user-list');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'user-List.xlsx');
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
