@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">

            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card custom-margin">
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <h1
                                        class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                        Job Commission {{ !empty($details) ? 'Edit' : 'Add' }}</h1>
                                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.dashboard') }}"
                                                class="text-muted text-hover-primary">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.rate-chart.list') }}"
                                                class="text-muted text-hover-primary">Job Commission</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-6">
                            <div class="container">
                                <form id="EquipmentForm" action="{{ route('admin.rate-chart.add') }}" method="POST"
                                    class="formSubmit fileUpload" enctype="multipart/form-data">
                                    <input type="hidden" name="id" name="id" value="{{ $details->id ?? null }}">
                                    <div class="row pt-2 mb-2" style="border: 1px solid #c0c0c0; border-radius: 10px;">

                                        {{-- <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title" class="label-style">State <span
                                                        class="text-danger">*</span></label>
                                                <select name="state_id" id="state_id" class="form-control"
                                                    onchange="getCity(this.value)">
                                                    <option value="">Select One .....</option>
                                                    @foreach ($states as $state)
                                                        <option value="{{ $state->id }}"
                                                            {{ !empty($details) && $details->state_id == $state->id ? 'selected' : '' }}>
                                                            {{ $state->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div> --}}
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title" class="label-style">State <span
                                                        class="text-danger">*</span></label>
                                                <select name="state_id" data-control="select2" id="state_id"
                                                    class="form-select form-select-solid" onchange="getCity(this.value)">
                                                    <option value="">Select state</option>
                                                    @foreach ($states as $state)
                                                        <option value="{{ $state->id }}"
                                                            {{ !empty($details) && $details->state_id == $state->id ? 'selected' : '' }}>
                                                            {{ $state->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title" class="label-style">City <span
                                                        class="text-danger">*</span></label>
                                                {{-- <select name="city_id" id="city_id" class="form-control">
                                                    <option value="">Select One .....</option>
                                                </select> --}}
                                                <select name="city_id" data-control="select2" id="city_id"
                                                    class="form-select form-select-solid">
                                                    <option value="">Select City</option>
                                                </select>
                                            </div>
                                        </div>
                                        <span style="color:red;font-size:15px"><b>Note:</b> If we have not seleted state and
                                            city then common master rate will be apply for all countries.</span>
                                    </div>

                                    <div id="dynamicFields" class="row mb-2"
                                        style="border: 1px solid #c0c0c0; border-radius: 10px;">
                                        <h3 style="color:rgb(38, 38, 141)">Job Commission Settings Setup</h3>
                                        <div class="row mb-2">
                                            <div class="col-md-10">
                                                <div class="form-group">
                                                    <label for="title" class="label-style">Truck Type </label>
                                                    <select name="truck_type[]" id="truck_type" class="form-control">
                                                        <option value="">Select One....</option>
                                                        @foreach ($truck_types as $truck_type)
                                                            <option value="{{ $truck_type->id }}">
                                                                {{ $truck_type->title }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" id="addMoreBtn" class="btn btn-success btn-sm"
                                                    style="    margin-top: 29px;">+</button>
                                            </div>
                                        </div>

                                        {{-- @if (!empty($details))
                                            @foreach ($details->truckTypeIds() as $value)
                                                <div class="row mb-2">
                                                    <div class="col-md-10">
                                                        <div class="form-group">
                                                            <label for="title" class="label-style">Truck Type </label>
                                                            <select name="truck_type[]" id="truck_type"
                                                                class="form-control">
                                                                <option value="">Select One....</option>
                                                                @foreach ($truck_types as $truck_type)
                                                                    <option value="{{ $truck_type->id }}"
                                                                        {{ in_array($truck_type->id, $details->truckTypeIds()) ? 'selected' : '' }}>
                                                                        {{ $truck_type->title }}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="button" class="btn btn-danger btn-sm removeBtn" style="    margin-top: 29px;">-</button>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif --}}
                                        @if (!empty($details) && !empty($details->truckTypeIds()))
                                            @foreach ($details->truckTypeIds() as $selectedTruckTypeId)
                                                <div class="row mb-2">
                                                    <div class="col-md-10">
                                                        <div class="form-group">
                                                            <label for="title" class="label-style">Truck Type </label>
                                                            <select name="truck_type[]" class="form-control">
                                                                <option value="">Select One....</option>
                                                                @foreach ($truck_types as $truck_type)
                                                                    <option value="{{ $truck_type->id }}"
                                                                        {{ $truck_type->id == $selectedTruckTypeId ? 'selected' : '' }}>
                                                                        {{ $truck_type->title }}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="button" class="btn btn-danger btn-sm removeBtn"
                                                            style="margin-top: 29px;">-</button>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @else
                                            {{-- Show default dropdown when no details or truckTypeIds available --}}
                                            <div class="row mb-2">
                                                <div class="col-md-10">
                                                    <div class="form-group">
                                                        <label for="title" class="label-style">Truck Type </label>
                                                        <select name="truck_type[]" class="form-control">
                                                            <option value="">Select One....</option>
                                                            @foreach ($truck_types as $truck_type)
                                                                <option value="{{ $truck_type->id }}">
                                                                    {{ $truck_type->title }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="button" class="btn btn-danger btn-sm removeBtn"
                                                        style="margin-top: 29px;">-</button>
                                                </div>
                                            </div>
                                        @endif



                                    </div>


                                    <div class="row pt-2" style="border: 1px solid #c0c0c0; border-radius: 10px;">
                                        <h3 style="color:rgb(38, 38, 141)">Normal Job Commission Setup</h3>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="owner_percentage" class="label-style">Driver/Fleet Owner
                                                    Percentage
                                                    (%) </label>
                                                <input type="text" class="form-control number-only"
                                                    placeholder="Enter Driver/Fleet Owner Percentage"
                                                    name="owner_percentage" id="owner_percentage"
                                                    value="{{ $details->trucker_percentage ?? null }}"
                                                    onkeyup="getCalPer(this.value)"
                                                    oninput="
           let val = this.value.replace(/[^0-9.]/g, '')
                               .replace(/(\..*)\./g, '$1')  // prevent multiple dots
                               .replace(/^(\d+\.?\d{0,2}).*$/, '$1');
           if (parseFloat(val) > 100) val = '100';
           this.value = val;
       ">



                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="cal_percentage" class="label-style">CAL Percentage (%)
                                                </label>
                                                <input type="text" name="cal_percentage"
                                                    class="form-control number-only" readonly id="cal_percentage"
                                                    value="{{ $details->cal_percentage ?? null }}">
                                            </div>
                                        </div>
                                    </div>


                                    <div class="button add-btn-div-save-style">
                                        <button type="submit" id="submitBtn" class="btn btn-info">
                                            <span
                                                class="indicator-label">{{ !empty($details) ? 'Update' : 'Save' }}</span>
                                            <span class="indicator-progress">Please wait...
                                                <span
                                                    class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            function getCalPer(val) {
                const driver_per = parseFloat(val) || 0;
                const cal_per = 100 - driver_per;
                console.log(cal_per);
                
                $('#cal_percentage').val(cal_per.toFixed(2)); // optional: round to 2 decimal places
            }


            document.getElementById('addMoreBtn').addEventListener('click', function() {
                const dynamicFields = document.getElementById('dynamicFields');
                const newField = document.createElement('div');
                newField.className = 'row mb-2';
                newField.innerHTML = `
                <div class="col-md-10">
                        <div class="form-group">
                        <label for="title" class="label-style">Truck Type <span
                                class="text-danger">*</span></label>
                        <select name="truck_type[]" id="truck_type" class="form-control">
                            <option value="">Select One....</option>
                            @foreach ($truck_types as $truck_type)
                                <option value="{{ $truck_type->id }}">
                                    {{ $truck_type->title }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-danger btn-sm removeBtn" style="    margin-top: 29px;">-</button>
                </div>
            `;
                dynamicFields.appendChild(newField);
            });

            document.getElementById('dynamicFields').addEventListener('click', function(e) {
                if (e.target.classList.contains('removeBtn')) {
                    e.target.closest('.row').remove();
                }
            });
        </script>
        <script>
            function getCity(stateId, cityId) {
                let sel = '';
                $.ajax({
                    url: "{{ route('admin.user.get.districts') }}",
                    type: "POST",
                    data: {
                        _token: '{{ csrf_token() }}',
                        state_id: stateId,
                    },
                    success: function(response) {
                        console.log(response);
                        $.each(response, function(key, value) {
                            if (value.id == cityId) {
                                sel = 'selected';
                            } else {
                                sel = '';
                            }
                            $('#city_id').append('<option value="' + value.id + '" ' + sel + '>' + value
                                .name + '</option>');
                        });
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error("Error fetching:", textStatus, errorThrown);
                    }

                });
            }
        </script>
        @if (!empty($details))
            <script>
                getCity({{ $details->state_id }}, {{ $details->city_id }});
            </script>
        @endif
    @endpush
@endsection
