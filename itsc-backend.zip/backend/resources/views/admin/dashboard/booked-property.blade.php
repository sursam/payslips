@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6 ">
            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <!--begin::Title-->
                    <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                        Booked Property Details</h1>
                    <div class="col-md-12">
                        <form method="GET" action="{{ route('admin.booked-property') }}">
                            @csrf
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="from_date" class="label-style">From Date
                                            <span class="asterisk_sign">*</span></label>
                                        <input type="date" min="{{ date('Y-m-d') }}" class="form-control"
                                            value="{{ request('from_date') ?? date('Y-m-d') }}" name="from_date"
                                            id="from_date" required>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="to_date" class="label-style">To Date <span
                                                class="asterisk_sign">*</span></label>
                                        <input type="date" class="form-control" name="to_date"
                                            value="{{ request('to_date') ?? date('Y-m-d') }}" id="to_date" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="label-style"></label>
                                        <button class="btn btn-primary mt-8" type="submit"><i
                                                class="fas fa-search"></i>Search</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="d-flex flex-column flex-column-fluid">

            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">

                    @if (count($destinations) > 0)
                        @foreach ($destinations as $j => $destination)
                            <div class="card-body custom-card-admin">
                                <div class="row border">
                                    <div class="col-md-12 border bg-clr">
                                        <p>{{ $destination->title }}</p>
                                    </div>
                                    @if (count($destination?->sub_destinations) > 0)
                                        @foreach ($destination->sub_destinations as $i => $sub_destination)
                                            <div class="col-md-12 border crd-sprtr"
                                                style="background-color: #fff; padding:10px ; ">
                                                <div class="bg-clr-sub">
                                                    <span>{{ $sub_destination->title }}</span>
                                                    <div class="row pt-3">
                                                        @if (count($sub_destination?->properties) > 0)
                                                            @foreach ($sub_destination->properties as $k => $property)
                                                                <div class="col-md-12 border"
                                                                    style="background-color: #f4e9aa;">
                                                                    <span class="msty-hvn collapsed"
                                                                        id="headingTwo{{ $j }}-{{ $i }}-{{ $k }}"
                                                                        data-toggle="collapse"
                                                                        data-target="#collapseTwo{{ $j }}-{{ $i }}-{{ $k }}"
                                                                        aria-expanded="false"
                                                                        aria-controls="collapseTwo{{ $j }}-{{ $i }}-{{ $k }}">{{ $property->title }}
                                                                    </span>


                                                                    <div id="collapseTwo{{ $j }}-{{ $i }}-{{ $k }}"
                                                                        class="collapse"
                                                                        aria-labelledby="headingTwo{{ $j }}-{{ $i }}-{{ $k }}"
                                                                        data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <table class="table table-bordered"
                                                                                style="    background-color: white;">
                                                                                <thead>
                                                                                    <tr>

                                                                                        <th scope="col"
                                                                                            style="color:white">Date</th>

                                                                                        <th scope="col"
                                                                                            style="color:white">No of Booked
                                                                                            Rooms</th>
                                                                                        <th scope="col"
                                                                                            style="color:white">No of
                                                                                            Available Rooms</th>
                                                                                    </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                    @if (!empty($property?->dateWiseBooking(request('from_date') ?? date('Y-m-d'), request('to_date') ?? date('Y-m-d'))))
                                                                                        @foreach ($property?->dateWiseBooking(request('from_date') ?? date('Y-m-d'), request('to_date') ?? date('Y-m-d')) as $dateWiseBooking)
                                                                                            <tr>

                                                                                                <td>{{ date('d-m-Y', strtotime($dateWiseBooking['date'])) ?? 'N/A' }}
                                                                                                </td>

                                                                                                <td>{{ $dateWiseBooking['booked_rooms'] ?? 0 }}
                                                                                                </td>
                                                                                                <td>{{ $dateWiseBooking['available_rooms'] ?? 0 }}
                                                                                                </td>
                                                                                            </tr>
                                                                                        @endforeach
                                                                                    @endif

                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                    </div>



                                                                    <div class="row row">
                                                                        @if (count($property?->rooms) > 0)
                                                                            @foreach ($property->rooms as $room)
                                                                                <div class="col-md-2 border inner-hvr"
                                                                                    data-toggle="tooltip"
                                                                                    data-placement="top"
                                                                                    title="Tooltip on top"
                                                                                    style="background-color: #e8e8e8;">
                                                                                    <span> room no.
                                                                                        {{ $room->room_no }}</span>

                                                                                    @if (!empty($room->is_occupied(request('from_date') ?? date('Y-m-d'))))
                                                                                        <i class="fa fa-house-flag"
                                                                                            style="color: #ff614c;"></i>
                                                                                        <h6>{{ $room?->is_occupied(request('from_date') ?? date('Y-m-d'))?->booking?->booked_by?->first_name }}
                                                                                            {{ $room?->is_occupied(request('from_date') ?? date('Y-m-d'))?->booking?->booked_by?->last_name }}
                                                                                        </h6>
                                                                                        <p>Mob
                                                                                            no:{{ $room?->is_occupied(request('from_date') ?? date('Y-m-d'))?->booking?->booked_by?->mobile_number }}
                                                                                        </p>
                                                                                    @else
                                                                                        <i class="fa fa-house-flag"
                                                                                            style="color: #43be0a;"></i>
                                                                                    @endif
                                                                                </div>
                                                                            @endforeach
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                    </div>
                                                </div>

                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    @endif

                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
            // function formatDate(date) {
            //     return date.toISOString().split('T')[0];
            // }
            // const today = new Date();

            // document.getElementById('from_date').value = formatDate(today);
            // const toDate1 = new Date();
            // toDate1.setDate(today.getDate() + 7);
            // document.getElementById('to_date').value = formatDate(toDate1);

            document.getElementById('from_date').addEventListener('change', function() {
                const fromDateValue1 = new Date(this.value);
                const toDateInput1 = document.getElementById('to_date');
                toDateInput1.value = '';
                toDateInput1.min = this.value;
            });
        </script>
    @endpush
@endsection
