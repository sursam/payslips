@extends('layout.app')
@section('content')
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    @push('style')
        <link rel="stylesheet" href="{{ asset('assets/css/custom-widget.css') }}" />
        <style>
            #chartdiv {
                width: 100%;
                height: 300px;
            }

            #chartdiv1 {
                width: 100%;
                height: 500px;
            }

            .widget-font-text {
                font-size: 11px;
            }
        </style>
    @endpush

    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
    <div id="kt_app_content" class="app-content flex-column-fluid">
        <div id="kt_app_content_container" class="app-container container-fluid">
            <div class="row g-5 g-xl-10 mb-5 mb-xl-10">

                {{-- Unread SOS Alerts --}}
                @can('unread-sos-alert')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Unread SOS
                                                Alert</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa fa-stopwatch" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Users --}}
                @can('view-total-users')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.user.list') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #23537b;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['total_user'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total
                                                Users</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa fa-user" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Users Registered in 30 Days --}}
                @can('view-users-registered-30-days')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.user.list') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['total_user_in_30_days'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Users
                                                Registered in 30 days</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa fa-users" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Users Registered in 7 Days --}}
                @can('view-users-registered-7-days')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.user.list') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['total_user_in_7_days'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Users
                                                Registered in 7 days</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-user-tie" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Suppliers --}}
                @can('view-total-suppliers')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total
                                                Supplier</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-user-secret" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Independent Users --}}
                @can('view-total-independent-users')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.user.independent-list') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #23537b;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['trucker'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total
                                                Independent</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-users-gear" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Active Jobs --}}
                @can('view-active-jobs')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.new-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['new_job'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Active
                                                Jobs</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-briefcase" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Completed Jobs --}}
                @can('view-completed-jobs')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.completed-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['completed_job'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total
                                                Completed Jobs</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-person-digging" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Cancelled Jobs --}}
                @can('view-cancelled-jobs')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.cancel-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span
                                                class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">{{ $data['canceled_job'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total
                                                Cancelled Jobs</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-road-circle-check" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Job Commission Per Day --}}
                @can('view-job-commission-per-day')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.all-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #23537b;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count"> $
                                                {{ $data['total_job_cost'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Job
                                                Commission Per Day</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-money-bill" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Job Commission Per Week --}}
                @can('view-job-commission-per-week')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.all-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count"> $
                                                {{ $data['total_job_cost_one_week'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Job
                                                Commission Per Week</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-tags" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Job Commission Per Month --}}
                @can('view-job-commission-per-month')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.all-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #23537b;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">$
                                                {{ $data['total_job_cost_one_month'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Job
                                                Commission Per Month</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-hand-holding-dollar" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Job Commission Per Year --}}
                @can('view-job-commission-per-year')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="{{ route('admin.job.all-job') }}">
                            <div class="card card-flush widget-class"
                                style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">$
                                                {{ $data['total_job_cost_one_year'] ?? 0 }}</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Job
                                                Commission per year to date</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-money-bill-1-wave" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Driver Certification Pending --}}
                @can('view-driver-certification-pending')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Driver
                                                Certification Pending</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-certificate" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Driver Certification Fees per Month --}}
                @can('view-driver-certification-fees-month')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #23537b;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Driver
                                                Certification Fees per Month</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa fa-rupee" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Driver Certification Fees per Quarter --}}
                @can('view-driver-certification-fees-quarter')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Driver
                                                Certification Fees per Quarter</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-star" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

                {{-- Total Driver Certification Fees per Year to Date --}}
                @can('view-driver-certification-fees-year')
                    <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                        <a href="#">
                            <div class="card card-flush widget-class"
                                style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                                <div class="card-header pt-5">
                                    <div class="col-md-8">
                                        <div class="card-title d-flex flex-column">
                                            <span class="widget-font-heading fw-bold text-white me-2 lh-1 ls-n2 dashboard-count">0</span>
                                            <span class="text-white opacity-75 pt-1 fw-semibold widget-font-text">Total Driver
                                                Certification Fees per Year to Date</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4" style="text-align: center;padding: 25px 0px 0px 0px;">
                                        <i class="fa-solid fa-pen-nib" style="font-size: 37px;color: white;"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @endcan

            </div>
        </div>
    </div>

    @push('script')
        <script src="{{ asset('assets/js/widgets.bundle.js') }}"></script>
        <script src="{{ asset('assets/js/custom-widget.js') }}"></script>
    @endpush
@endsection
