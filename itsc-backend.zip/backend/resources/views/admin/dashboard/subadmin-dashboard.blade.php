@extends('layout.app')
@section('content')
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    @push('style')
        <link rel="stylesheet" href="{{ asset('assets/css/custom-widget.css') }}" />
        <style>
            #chartdiv {
                width: 100%;
                height: 300px;
            }

            #chartdiv1 {
                width: 100%;
                height: 500px;
            }
        </style>
    @endpush
    <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
        <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
            <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                Welcome to</h1>
            <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">

                @forelse (Auth::user()->destinations as $destination_de)
                    <li class="breadcrumb-item text-muted">
                        {{ $destination_de?->title }}
                    </li>
                @empty
                    <li class="breadcrumb-item text-muted">
                        No Destination Assigned
                    </li>
                @endforelse


            </ul>
        </div>
    </div>
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
    <div id="kt_app_content" class="app-content flex-column-fluid">
        <div id="kt_app_content_container" class="app-container container-fluid">
            <div class="row g-5 g-xl-10 mb-5 mb-xl-10">

                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class"
                            style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span class="fs-2hx fw-bold text-white me-2 lh-1 ls-n2">{{ $total_property }}</span>
                                        <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Total Property</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/users.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class"
                            style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span
                                            class="fs-2hx fw-bold text-white me-2 lh-1 ls-n2">{{ '₹' . $today_income_expanse ?? 0 }}</span>
                                        <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Today's Income</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/agent.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class"
                            style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span
                                            class="fs-2hx fw-bold text-white me-2 lh-1 ls-n2">{{ '₹' . $total_income_expanse ?? 0 }}</span>
                                        <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Total Income</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/agent.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>



                <div class="col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="col-md-12">
                                <div class="card-title d-flex flex-column">
                                    <span class="text-black opacity-75 pt-1 fw-semibold fs-6">Booking/Check In Report</span>
                                    <div class="col-md-12">
                                        <div class="row">
                                            {{-- <div class="col-md-4">
                                            <label for="property_id_booking_checking" class="label-style">Property <span
                                                    class="asterisk_sign">*</span></label>
                                            <select name="property_id_booking_checking" id="property_id_booking_checking"
                                                class="form-control">
                                                <option value="">All</option>
                                                @forelse ($propertys as $property)
                                                    <option value="{{ $property->id }}"
                                                        @if ($details) {{ $details?->property_id_booking_checking == $property->id ? 'selected' : '' }} @endif>
                                                        {{ $property->title ?? 'N/A' }}</option>
                                                @empty
                                                    <option value="">No property Found</option>
                                                @endforelse
                                            </select>
                                        </div> --}}
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="from_date_booking_checking" class="label-style">From Date
                                                        <span class="asterisk_sign">*</span></label>
                                                    <input type="date" class="form-control"
                                                        name="from_date_booking_checking" id="from_date_booking_checking"
                                                        required>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="to_date_booking_checking" class="label-style">To Date <span
                                                            class="asterisk_sign">*</span></label>
                                                    <input type="date" class="form-control"
                                                        name="to_date_booking_checking" id="to_date_booking_checking"
                                                        required>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="label-style"></label>
                                                    <button class="btn btn-primary mt-8" onclick="getBookingCheckin()"
                                                        type="button" id="booking_checking_btn"><i
                                                            class="fas fa-search"></i>Search</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartdiv"></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="col-md-12">
                                <div class="card-title d-flex flex-column">
                                    <span class="text-black opacity-75 pt-1 fw-semibold fs-6">Income/Expance Report</span>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="from_date" class="label-style">From Date</label>
                                                        <span class="asterisk_sign">*</span>
                                                        <input type="date" class="form-control" name="from_date"
                                                            id="from_date" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="to_date" class="label-style">To Date</label>
                                                        <span class="asterisk_sign">*</span>
                                                        <input type="date" class="form-control" name="to_date"
                                                            id="to_date" required>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="to_date" class="label-style"></label>
                                                        <button class="btn btn-primary mt-8"
                                                            onclick="getIncomeExpance()"><i
                                                                class="fas fa-search"></i>Search</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartdiv1"></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    @push('script')
        <script src="{{ asset('assets/js/widgets.bundle.js') }}"></script>
        <script src="{{ asset('assets/js/custom-widget.js') }}"></script>
        <script>
            $(function() {
                getBookingCheckin();
                getIncomeExpance();
            });

            function getBookingCheckin() {
                $.ajax({
                    url: "{{ route('admin.booking-checking') }}",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        _token: '{{ csrf_token() }}',
                        // property_id_booking_checking: $("#property_id_booking_checking").val(),
                        from_date_booking_checking: $("#from_date_booking_checking").val(),
                        to_date_booking_checking: $("#to_date_booking_checking").val(),
                        for: 'sub_admin',
                    },
                    success: function(data) {
                        initializeChartForBookingCheckin(data);
                    },
                    error: function(error) {
                        console.error("Error fetching booking check-in data:", error);
                    }
                });
            }

            function getIncomeExpance() {
                $.ajax({
                    url: "{{ route('admin.income-expance') }}",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        _token: '{{ csrf_token() }}',
                        from_date: $("#from_date").val(),
                        to_date: $("#to_date").val(),
                        for: 'sub_admin',
                    },
                    success: function(response) {
                        initializeChartForIncomeExpance(response)
                    },
                    error: function(error) {
                        console.error("Error fetching Income/Expense data:", error);
                        alert("Failed to fetch data. Please try again.");
                    }
                });
            }
        </script>
        <script src="{{ asset('assets/js/armchartDashboard.js') }}"></script>
    @endpush
@endsection
