@extends('layout.app')
@section('content')
    @push('style')
        <link rel="stylesheet" href="{{ asset('assets/css/custom-widget.css') }}" />
    @endpush
    <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                    Dashboard</h1>
                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                    <li class="breadcrumb-item text-muted">
                        <a href="{{ route('admin.dashboard') }}" class="text-muted text-hover-primary">Dashboard</a>
                    </li>
                </ul>
            </div>
        </div>
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
       
    </div>
    <div id="kt_app_content" class="app-content flex-column-fluid">
        <div id="kt_app_content_container" class="app-container container-fluid">
            <div class="row g-5 g-xl-10 mb-5 mb-xl-10">

                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class" style="background-color: #682625;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span class="fw-bold text-white me-2 lh-1 ls-n2">{{ $usercount }}</span>
                                        <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Total User</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/users.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class" style="background-color: #d99b2a;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span class="fw-bold text-white me-2 lh-1 ls-n2">{{ $agent }}</span>
                                        <span class="text-white text-whiteopacity-75 pt-1 fw-semibold fs-6">Total Agent</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/agent.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-6">
                    <a href="#">
                        <div class="card card-flush widget-class" style="background-color: #1c1c60;background-image:url('http://127.0.0.1:8000/assets/media/patterns/vector-1.png')">
                            <div class="card-header pt-5">
                                <div class="col-md-8">
                                    <div class="card-title d-flex flex-column">
                                        <span class="fw-bold text-white me-2 lh-1 ls-n2">{{ $destination }}</span>
                                        <span class="text-white opacity-75 pt-1 fw-semibold fs-6">Total Destination</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ asset('assets/media/widget-image/resort.png') }}" class="widget-image" />
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
        </div>
    </div>

    @push('script')
        <script src="{{ asset('assets/js/widgets.bundle.js') }}"></script>
        <script src="{{ asset('assets/js/custom-widget.js') }}"></script>
    @endpush
@endsection
