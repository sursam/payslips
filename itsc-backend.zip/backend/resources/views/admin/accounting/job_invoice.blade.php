@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Job Invoice List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Job Invoice List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                    100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip"
                                                data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-4 text-right">

                                        </div>
                                        <div class="col-md-4 text-right">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="job-invoice">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Id</th>
                                            <th>Order No</th>
                                            <th>Contractor</th>
                                            <th>Company</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Pickup Date</th>
                                            <th>Delivery Date</th>
                                            <th>Total Mileage</th>
                                            <th>Total Tons</th>
                                            <th>Job Load Type</th>
                                            <th>Total Loads</th>
                                            <th>Job Estimated Price(₹)</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($job_list as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    {{ $detail?->unique_id }}
                                                </td>
                                                <td>
                                                    {{ $detail?->order_no }}
                                                </td>
                                                <td>
                                                    {{ $detail?->user?->first_name.' '.$detail?->user?->last_name }}
                                                </td>
                                                <td>
                                                    {{ $detail?->user?->otherDetails?->company_legal_name }}
                                                </td>
                                                <td>
                                                    {{ $detail?->source }}
                                                </td>
                                                <td>
                                                    {{ $detail?->destination }}
                                                </td>
                                                <td>
                                                    {{ date('m/d/Y h:i A', strtotime($detail?->pickup_date_time)) }}
                                                </td>
                                                <td>
                                                    {{ date('m/d/Y h:i A', strtotime($detail?->delivery_date_time)) }}
                                                </td>

                                                <td>
                                                    {{ $detail?->total_mileage }}
                                                </td>
                                                <td>
                                                    {{ $detail?->jobLoad?->sum('weight') }}
                                                </td>
                                                <td>
                                                    {{ $detail?->jobLoadType?->title }}
                                                </td>
                                                <td>
                                                    {{ $detail?->totalLoad() }}
                                                </td>

                                                <td>
                                                    {{ $detail?->job_estimate_price }}
                                                </td>

                                                <td><a class="btn btn-sm btn-info" target="_blank"
                                                        href="{{ route('admin.accounting.generated-pdf', $detail?->id) }}"><i
                                                            class="fa fa-file-pdf"></i>Generate PDF</a></td>

                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $job_list->appends(['per_page' => request('per_page'), 'search' => request('search')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
        <script>
            function export_data() {
                let data = document.getElementById('job-invoice');
                let rows = Array.from(data.rows).map(row => {
                    // Get all cells in the row except the last one
                    return Array.from(row.cells).slice(0, -1).map(cell => cell.innerText);
                });

                // Create a new worksheet with the modified rows
                let ws = XLSX.utils.aoa_to_sheet(rows);
                let wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'report');

                // Export the workbook
                XLSX.writeFile(wb, 'job-invoice.xlsx');
            }
        </script>
    @endpush
@endsection
