@extends('layout.app')
@section('content')
    @php
        use App\Helpers\PhoneHelper;

    @endphp

    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    User List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">User List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-2 text-left">
                                            <b>Per Page</b>
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                    100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 text-left">
                                            <b>Choose Time Period</b>
                                            <select id="created_time" class="form-control" name="created_time"
                                                onchange="changeTime(this.value)">
                                                <option value="">Select One...
                                                </option>
                                                <option value="2" {{ request('created_time') == 2 ? 'selected' : '' }}>
                                                    Past 2 days
                                                </option>
                                                <option value="5" {{ request('created_time') == 5 ? 'selected' : '' }}>
                                                    Past 5 days
                                                </option>
                                                <option value="10"
                                                    {{ request('created_time') == 10 ? 'selected' : '' }}>Past
                                                    10 days
                                                </option>
                                                <option value="15"
                                                    {{ request('created_time') == 15 ? 'selected' : '' }}>Past
                                                    15 days
                                                </option>
                                                <option value="30"
                                                    {{ request('created_time') == 30 ? 'selected' : '' }}>Past
                                                    30 days
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 text-left">
                                            <b>Export Type</b>
                                            <select id="old_new" class="form-control" name="old_new"
                                                onchange="OldNew(this.value)">
                                                <option value="">All</option>
                                                <option value="1" {{ request('old_new') == 1 ? 'selected' : '' }}>New
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 text-left" style="margin-top: 18px;">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip"
                                                data-placement="top" title="Export Data"><i class="fa fa-file-excel"></i>
                                                Export</button>
                                        </div>

                                        <div class="col-md-2 text-right" style="    margin-top: 18px;
">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right" style="    margin-top: 18px;
">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function OldNew(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('old_new', value);
                                    window.location.href = url;
                                }

                                function changeTime(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('created_time', value);
                                    window.location.href = url;
                                }

                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="user-list">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">

                                            <th class="min-w-125px">Name</th>
                                            <th class="min-w-125px">Company</th>
                                            <th class="min-w-125px">Email</th>
                                            <th class="min-w-70px">Phone</th>
                                            <th class="min-w-70px">Mobile</th>
                                            <th class="min-w-70px">Fax</th>
                                            <th class="min-w-70px">Website</th>
                                            <th class="min-w-70px">Street</th>
                                            <th class="min-w-70px">City</th>
                                            <th class="min-w-70px">State</th>
                                            <th class="min-w-70px">ZIP</th>
                                            <th class="min-w-70px">Country</th>
                                            <th class="min-w-70px">Opening Balance</th>
                                            <th class="min-w-70px">Date</th>
                                            <th class="min-w-70px">Tax ID</th>

                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($details as $detail)
                                            <tr data-user-id="{{ $detail->id }}" data-status="{{ $detail->is_export }}"
                                                style="background-color:{{ $detail->is_export == 1 ? '#ffe6e6' : '' }}">
                                                <!-- Add data-user-id attribute -->
                                                <td>{{ $detail?->first_name }} {{ $detail?->last_name }}</td>
                                                <td>{{ $detail?->otherDetails?->company_legal_name }}</td>
                                                <td>{{ $detail?->email }}</td>
                                                <td></td>
                                                <td>
                                                    @php
                                                        $mobileNumber = $detail->mobile_number;
                                                        $formattedNumber = PhoneHelper::formatPhoneNumber(
                                                            $mobileNumber,
                                                        );
                                                    @endphp
                                                    {{ $formattedNumber }}
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td>{{ $detail?->address }}</td>
                                                <td>{{ $detail?->cityDetails?->name }}</td>
                                                <td>{{ $detail?->stateDetails?->name }}</td>
                                                <td>{{ $detail?->pin_code }}</td>
                                                <td>{{ $detail?->stateDetails?->countryDetails?->name }}</td>
                                                <td></td>
                                                <td></td>
                                                <td>{{ $detail?->otherDetails?->tax_id }}</td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="9">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>

                                </table>
                                {!! $details->appends([
                                        'created_time' => request('created_time'),
                                        'per_page' => request('per_page'),
                                        'search' => request('search'),
                                    ])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            function export_data() {
                // Collect user IDs and check for already exported rows
                const userIds = [];
                let hasExported = false;
                const rows = document.querySelectorAll('#user-list tbody tr');

                rows.forEach(row => {
                    const userId = row.getAttribute('data-user-id');
                    const status = row.getAttribute('data-status');
                    if (userId) {
                        userIds.push(userId);
                    }
                    if (status == "1") {
                        hasExported = true;
                    }
                });

                function doExport() {
                    fetch("{{ route('admin.user.export') }}", {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: JSON.stringify({
                                user_ids: userIds
                            })
                        })
                        .then(response => {
                            if (response.ok) {
                                return response.json();
                            }
                            throw new Error('Network response was not ok.');
                        })
                        .then(data => {
                            let dataTable = document.getElementById('user-list');
                            var fp = XLSX.utils.table_to_book(dataTable, {
                                sheet: 'report'
                            });
                            XLSX.writeFile(fp, 'user-List.xlsx');
                        })
                        .catch(error => {
                            console.error('There was a problem with the fetch operation:', error);
                        });
                }

                if (hasExported) {
                    Swal.fire({
                        title: 'Some data already exported',
                        text: 'If you want to export then press OK otherwise Cancel',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'OK',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            doExport();
                        }
                    });
                } else {
                    doExport();
                }
            }
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    @endpush
@endsection
