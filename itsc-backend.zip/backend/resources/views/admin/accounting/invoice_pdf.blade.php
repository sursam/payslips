<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Job Invoice</title>
    <link rel="shortcut icon" type="image/png" href="./favicon.png" />
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 16px;
        }

        .main-pd-wrapper {
            box-shadow: 0 0 10px #ddd;
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            width: 1000px;
            /* Fixed width for the invoice */
            margin: auto;
            /* Center the invoice */
        }

        .table-bordered {
            border-collapse: collapse;
            width: 100%;
            margin-top: 15px;
        }

        .table-bordered td,
        .table-bordered th {
            border: 1px solid #ddd;
            padding: 10px;
            word-break: break-all;
        }

        /* th {
            background-color: #fcbd021f;
            /* Set a background color for header */
        /* } */

        h4 {
            margin: 5px 0;
            font-size: 12px;
        }

        p {
            margin: 0;
            padding: 0;
        }

        .cropped {
            float: right;
            margin-bottom: 20px;
            height: 100px;
            overflow: hidden;
        }

        .cropped img {
            width: 400px;
            margin: 8px 0px 0px 80px;
        }
    </style>
</head>

<body>
    <section class="main-pd-wrapper">

        <table style="width: 100%; table-layout: fixed ;border:1px solid #ddd;">
            <tr>

                <td style="border-left: 1px solid #ddd;text-align:left" width="50%">
                    <h4 style="color: #3d56bd;font-size: 16px;">Bill From</h4>
                    <p>
                        816 Camaron, Ste 1.01, San Antonio, TX 78212<br />
                        Tel: <a href="tel:01241234568" style="color: #00bb07">+1(726) 800-6793</a>
                    </p>

                    <h4  style="color: #3d56bd;font-size: 16px;">Bill to/ Ship to ({{ $detail->user?->first_name . ' ' . $detail->user?->last_name }})</h4>
                    <p>
                        {{ $detail->user?->email }}<br />
                        {{ $detail->user?->address }}<br />
                        Tel: <a href="tel:01241234568"
                            style="color: #00bb07">+{{ $detail->user?->country_code . ' ' . $detail->user?->mobile_number }}</a>
                    </p>
                </td>
                <td style="border-left: 1px solid #ddd;text-align:right" width="50%">
                    <h4 style="color: #3d56bd;font-size: 16px;">Bill From</h4>
                    <p>
                        816 Camaron, Ste 1.01, San Antonio, TX 78212<br />
                        Tel: <a href="tel:01241234568" style="color: #00bb07">+1(726) 800-6793</a>
                    </p>

                    <h4  style="color: #3d56bd;font-size: 16px;">Bill to/ Ship to ({{ $detail->user?->first_name . ' ' . $detail->user?->last_name }})</h4>
                    <p>
                        {{ $detail->user?->email }}<br />
                        {{ $detail->user?->address }}<br />
                        Tel: <a href="tel:01241234568"
                            style="color: #00bb07">+{{ $detail->user?->country_code . ' ' . $detail->user?->mobile_number }}</a>
                    </p>
                </td>

            </tr>
        </table>

        <table class="table table-bordered">
            <thead>
                <tr style="background-color: #fff6da;">
                    <td colspan="3" class="bg-light"  width="70%">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="mb-0"><b>Pickup : </b>{{ $detail?->source }}</p>
                                <p class="mb-0"><b>Pickup Date : </b>{{ date('m/d/Y h:i A',strtotime($detail->pickup_date_time)) }}</p>
                            </div>
                            <div style="margin-top: 10px">
                                <p class="mb-0"><b>Pickout : </b>{{ $detail->destination }}</p>
                                <p class="mb-0"><b>Pickout Date : </b>{{  date('m/d/Y h:i A',strtotime($detail->delivery_date_time)) }}</p>
                            </div>
                        </div>
                    </td>
                    <td class="bg-light text-right"  width="30%" colspan="3">
                        <p><b>Job Unique Id : </b> <span style="color:blue">{{$detail?->unique_id}}</span></p>
                        <p><b>Order No : </b> {{$detail?->order_no}}</p>
                        <p><b>Material : </b>
                        @if ($detail->material_other == null)
                            {{ $detail->jobMaterial->title }}
                        @else
                            {{ $detail->material_other }}
                        @endif</p>

                    </td>
                </tr>
                <tr style="background-color: #fcbd02;">
                    <th>Truck No</th>
                    <th>Trucker Name </th>
                    <th>Weight(Ton) </th>
                    <th>Cost($)</th>

                    <th>Started On</th>
                    <th>Completed On</th>
                </tr>
            </thead>
            <tbody>
                @if($detail?->acceptedJobLoad?->isNotEmpty())
                @foreach($detail?->acceptedJobLoad as $load)
                <tr>

                    <td style="text-align: center">{{$load?->userTruckDetails?->company_truck_number ?? '--'}}</td>
                    <td style="text-align: center">{{ $load?->trucker?->first_name.' '.$load?->trucker?->last_name ?? '--'}}</td>

                    <td>
                        {{ $load?->weight ?? '--' }}
                    </td>
                    <td>
                        ${{ $load?->load_cost ?? '--' }}
                    </td>


                    <td style="text-align: center">{{ date('m/d/Y h:i A',strtotime($load->started_on)) }}</td>

                    <td style="text-align: center">{{ date('m/d/Y h:i A',strtotime($load->completed_on)) }}</td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>


        <table class="table-bordered" style="margin-top: 30px">
            <tr style="background: #fcbd02">
                <th>Total Payable Amount</th>
                <td style="text-align: right;"><b>$<?= $detail->job_estimate_price ?></b></td>
            </tr>
        </table>
    </section>
</body>

</html>
