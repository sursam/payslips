@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Pay In List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted">  Pay In List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                    100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip"
                                                data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-4 text-right">

                                        </div>
                                        <div class="col-md-4 text-right">
                                            <input type="text" id="search_data" name="search"
                                                value="{{ request('search') }}" placeholder="Search..."
                                                class="form-control" />

                                        </div>
                                        <div class="col-md-2 text-right">
                                            <button class="btn btn-info" onclick="changeSearch()"><i
                                                    class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }

                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="pay-in">
                                    <thead>
                                        {{-- <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Owner</th>
                                            <th>Job Id</th>
                                            <th>Order Id</th>
                                            <th>Total Loads</th>
                                            <th>Value(₹)</th>
                                            <th>Payment Status</th>
                                        </tr> --}}
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Id</th>
                                            <th>Load NO.</th>
                                            <th>Order No</th>
                                            <th>Contractor</th>
                                            <th>Load Cost</th>
                                            <th>Payment Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($payinList as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td><a href="{{ route('admin.job.all-job-details', $detail?->job?->id) }}">{{ $detail?->job?->unique_id }}</a></td>
                                                <td>{{ $detail?->load_index }}</td>
                                                <td>{{ $detail?->job?->order_no }}</td>
                                                {{-- <td><a href="{{ route('admin.user.contractor-details', $detail?->job?->user?->uuid) }}">{{ $detail?->job?->user?->first_name.' '.$detail?->job?->user?->last_name }}</a></td> --}}
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="symbol symbol-35px symbol-circle overflow-hidden">
                                                        <img 
                                                            alt="User profile picture" 
                                                            src="{{ $detail?->job?->user?->image_path }}" 
                                                            class="img-fluid rounded-circle" 
                                                            style="width: 35px; height: 35px; object-fit: cover;"
                                                        />
                                                        </div>
                                                        <div class="ms-3" style="min-width: 0;">
                                                        <a 
                                                            href="{{ route('admin.user.contractor-details', $detail?->job?->user?->uuid) }}" 
                                                            class="text-decoration-none fw-bold text-dark text-hover-primary d-block text-truncate"
                                                            style="max-width: 180px;"
                                                        >
                                                            {{ $detail?->job?->user?->first_name }} {{ $detail?->job?->user?->last_name }}
                                                        </a>
                                                        <span 
                                                            class="text-muted fw-semibold small text-truncate d-block"
                                                            style="max-width: 180px;"
                                                        >
                                                            {{ $detail?->job?->user?->email }}
                                                        </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>$ {{ $detail->load_cost }}</td>
                                                <td>@if($detail->is_payment_initiated == 0 ) 
                                                        <span class="badge badge-warning">Pending</span> 
                                                    @else <span class="badge badge-success">Paid</span> 
                                                    @endif
                                                </td>
                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="7">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $payinList->appends(['per_page' => request('per_page'), 'search' => request('search')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
        <script>
            function export_data() {
                let data = document.getElementById('pay-in');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'pay-in.xlsx');
            }
        </script>
    @endpush
@endsection
