@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6"></div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-header">
                            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                <h1
                                    class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                    Pay Out List</h1>
                                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-muted"> Pay Out List</li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-1 text-left">
                                            <select id="per_page" class="form-control" name="per_page"
                                                onchange="changePerPage(this.value)">
                                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10
                                                </option>
                                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25
                                                </option>
                                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>
                                                    100
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1 text-left">
                                            <button class="btn btn-info" onclick="export_data()" data-toggle="tooltip"
                                                data-placement="top" title="Export Data"><i
                                                    class="fa fa-file-excel"></i></button>
                                        </div>
                                        <div class="col-md-6 text-right">

                                        </div>

                                    </div>
                                </div>
                            </div>

                            <script>
                                function changePerPage(value) {
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    window.location.href = url;
                                }


                                function changeSearch() {
                                    var value = $('#search_data').val();
                                    const url = new URL(window.location.href);
                                    url.searchParams.set('search', value);
                                    window.location.href = url;
                                }
                            </script>

                            <div class="table-responsive mt-2">
                                <table class="table table-bordered" id="pay-out">
                                    <thead>
                                        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                            <th>Sl No</th>
                                            <th>Job Id</th>
                                            <th>Load NO.</th>
                                            <th>Order No</th>
                                            <th>Truck No</th>
                                            <th>Independent</th>
                                            <th>Load Cost</th>
                                            <th>Cal Commission($)</th>
                                            <th>Driver Payout</th>
                                            <th>Payout Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="fw-semibold text-gray-600">
                                        @forelse ($payoutList as $detail)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    <a href="{{ route('admin.job.all-job-details', $detail?->job?->id) }}">{{ $detail?->job?->unique_id }}</a>
                                                </td>
                                                <td>
                                                    {{ $detail?->load_index }}
                                                </td>
                                                <td>
                                                    {{ $detail?->job?->order_no }}
                                                </td>
                                                <td>
                                                    {{ $detail?->jobLoad?->userTruckDetails?->company_truck_number }}
                                                </td>
                                                {{-- <td>
                                                    {{ $detail?->jobLoad?->userDetails?->first_name . ' ' . $detail?->jobLoad?->userDetails?->last_name }}
                                                </td> --}}
                                                <td>
                                                    @if ($detail?->jobLoad?->userDetails != null)
                                                        <div class="d-flex align-items-center">
                                                            <div class="symbol symbol-35px symbol-circle overflow-hidden">
                                                            <img 
                                                                alt="User profile picture" 
                                                                src="{{ $detail?->jobLoad?->userDetails?->image_path }}" 
                                                                class="img-fluid rounded-circle" 
                                                                style="width: 35px; height: 35px; object-fit: cover;"
                                                            />
                                                            </div>
                                                            <div class="ms-3" style="min-width: 0;">
                                                            <a 
                                                                href="{{ route('admin.user.independent-details', $detail?->jobLoad?->userDetails?->uuid) }}" 
                                                                class="text-decoration-none fw-bold text-dark text-hover-primary d-block text-truncate"
                                                                style="max-width: 180px;"
                                                            >
                                                                {{ $detail?->jobLoad?->userDetails?->first_name }} {{ $detail?->jobLoad?->userDetails?->last_name }}
                                                            </a>
                                                            <span 
                                                                class="text-muted fw-semibold small text-truncate d-block"
                                                                style="max-width: 180px;"
                                                            >
                                                                {{ $detail?->jobLoad?->userDetails?->email }}
                                                            </span>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <span class="text-muted fw-semibold small text-truncate d-block"
                                                            style="max-width: 180px;"
                                                        >
                                                            N/A
                                                        </span>
                                                    @endif
                                                </td>
                                                <td>
                                                    $ {{ $detail?->jobLoad?->load_cost > 0 ? number_format($detail?->jobLoad?->load_cost, 2) : 0.00 }}
                                                </td>
                                                <td>
                                                    $ {{ $detail?->jobLoad?->cal_comission }}
                                                </td>
                                                <td>
                                                    $ {{ $detail?->jobLoad?->trucker_get }}
                                                </td>
                                                <td>
                                                    @if ($detail->is_paid == 1)
                                                        <span class="badge badge-success">Payout Done</span>
                                                    @else
                                                        <span class="badge badge-warning">Pending</span>
                                                    @endif
                                                </td>


                                            </tr>
                                        @empty
                                            <tr class="text-center">
                                                <td colspan="10">No Data Found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                {!! $payoutList->appends(['per_page' => request('per_page')])->links('pagination::bootstrap-5') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
        <script>
            function export_data() {
                let data = document.getElementById('pay-out');
                var fp = XLSX.utils.table_to_book(data, {
                    sheet: 'report',
                    raw: true
                });
                XLSX.writeFile(fp, 'pay-out.xlsx');
            }
        </script>
    @endpush
@endsection
