@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Home Genaral Settings List</h1>
                        <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                            <li class="breadcrumb-item text-muted">
                                <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                            </li>
                            <li class="breadcrumb-item">
                                <span class="bullet bg-gray-400 w-5px h-2px"></span>
                            </li>
                            <li class="breadcrumb-item text-muted"> Genaral Settings</li>
                        </ul>

                    </div>
                    <div class="d-flex align-items-center gap-2 gap-lg-3">
                        <div class="d-flex justify-content-end" data-kt-customer-table-toolbar="base">
                            <button type="button" class="btn btn-info goTo"
                                data-action="{{ route('admin.homepage.category.add') }}">Add
                                Category</button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card">
                        <div class="card-body pt-0">
                          

                        <form id="administrationForm" action="{{ route('admin.setting.general_setting.update') }}" method="POST" class="formSubmit fileUpload" enctype="multipart/form-data">
    @csrf
    <table class="table align-middle table-row-dashed fs-6 gy-5 dataTable" id="kt_customers_table">
        <thead>
            <tr>
                <th>Name</th>
                <th>
                    Email
                    <input type="checkbox" id="checkAllEmail">
                </th>
                <th>
                    WhatsApp
                    <input type="checkbox" id="checkAllWhatsApp">
                </th>
                <th>
                    SMS
                    <input type="checkbox" id="checkAllSMS">
                </th>
            </tr>
        </thead>
        <tbody>
            @foreach($settings as $setting)
            <tr>
                <td>{{ $setting->name }}</td>
                <td><input type="checkbox" class="email-checkbox" name="settings[{{ $setting->id }}][email]" {{ $setting->email ? 'checked' : '' }}></td>
                <td><input type="checkbox" class="whatsapp-checkbox" name="settings[{{ $setting->id }}][whatsapp]" {{ $setting->whatsapp ? 'checked' : '' }}></td>
                <td><input type="checkbox" class="sms-checkbox" name="settings[{{ $setting->id }}][sms]" {{ $setting->sms ? 'checked' : '' }}></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="d-flex justify-content-end"> <button type="submit" class="btn btn-primary">Update Settings</button> </div>
</form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script>
    document.getElementById('checkAllEmail').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.email-checkbox');
        checkboxes.forEach(checkbox => checkbox.checked = this.checked);
    });

    document.getElementById('checkAllWhatsApp').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.whatsapp-checkbox');
        checkboxes.forEach(checkbox => checkbox.checked = this.checked);
    });

    document.getElementById('checkAllSMS').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.sms-checkbox');
        checkboxes.forEach(checkbox => checkbox.checked = this.checked);
    });


        </script>
    @endpush
@endsection
