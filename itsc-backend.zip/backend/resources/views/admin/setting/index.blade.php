@extends('layout.app')
@section('content')
<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
    <div class="d-flex flex-column flex-column-fluid">

        <div id="kt_app_content" class="app-content flex-column-fluid">
            <div id="kt_app_content_container" class="app-container container-xxl">
                <div class="card custom-margin">
                <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                        Setting {{ !empty($details) ? 'Edit' : 'Add' }}</h1>
                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                        <li class="breadcrumb-item text-muted">
                            <a href="{{ route('admin.dashboard') }}" class="text-muted text-hover-primary">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                        </li>
                        <li class="breadcrumb-item text-muted">
                            <a href="{{ route('admin.setting.update') }}" class="text-muted text-hover-primary">Setting</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
                    <div class="card-body pt-6">
                        <div class="container">
                            <form id="uomForm" action="{{ route('admin.setting.update') }}" method="POST" class="formSubmit fileUpload" enctype="multipart/form-data">
                                <input type="hidden" name="id" name="id" value="{{ $details->id ?? null }}">

                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="instagram" class="label-style">Address</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <textarea class="form-control" placeholder="Enter Address" name="address" id="address">{{ $details->address ?? '' }}</textarea>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="instagram" class="label-style">Instagram</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control" placeholder="Enter instagram url" name="instagram" id="instagram" value="{{ $details->instagram ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="facebook" class="label-style">Facebook</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control" placeholder="Enter facebook url" name="facebook" id="facebook" value="{{ $details->facebook ?? null }}">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="twitter" class="label-style">Twitter</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control" placeholder="Enter twitter url" name="twitter" id="twitter" value="{{ $details->twitter ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="linkidin" class="label-style">Linked In</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control" placeholder="Enter linked in url" name="linkidin" id="linkidin" value="{{ $details->linkidin ?? null }}">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email_id" class="label-style">Contact Email</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control" placeholder="Enter contact email" name="email_id" id="email_id" value="{{ $details->email_id ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone_number" class="label-style">Contact Number</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter contact number" name="phone_number" id="phone_number" value="{{ $details->phone_number ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="contact_map" class="label-style">Contact Map</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter Contact Map" name="contact_map" id="contact_map" value="{{ $details->contact_map ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="job_payment_percentage" class="label-style">Job Payment Percentage</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter Job Payment Percentage" name="job_payment_percentage" id="job_payment_percentage" value="{{ $details->job_payment_percentage ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="haul_job_payment_percentage" class="label-style">Haul Job Payment Percentage</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter Haul Job Payment Percentage" name="haul_job_payment_percentage" id="haul_job_payment_percentage" value="{{ $details->haul_job_payment_percentage ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="cal_commission" class="label-style">Cal Commission</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter Cal Commission" name="cal_commission" id="cal_commission" value="{{ $details->cal_commission ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="on_loading_hour" class="label-style">On Loading Hour</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter On Loading Hour" name="on_loading_hour" id="on_loading_hour" value="{{ $details->on_loading_hour ?? null }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="off_loading_hour" class="label-style">Off Loading Hour</label>
                                            {{-- <span class="astrict_sign">*</span> --}}
                                            <input type="text" class="form-control " placeholder="Enter Off Loading Hour" name="off_loading_hour" id="off_loading_hour" value="{{ $details->off_loading_hour ?? null }}">
                                        </div>
                                    </div>
                                </div>

                                <div class="button add-btn-div-save-style">
                                    <button type="submit" id="submitBtn" class="btn btn-info">
                                        <span class="indicator-label">{{ !empty($details) ? 'Update' : 'Save' }}</span>
                                        <span class="indicator-progress">Please wait...
                                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('script')
@endpush
@endsection
