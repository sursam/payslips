@extends('layout.app')
@section('content')
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="d-flex flex-column flex-column-fluid">

            <div id="kt_app_content" class="app-content flex-column-fluid">
                <div id="kt_app_content_container" class="app-container container-xxl">
                    <div class="card custom-margin">
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                                    <!--begin::Title-->
                                    <h1
                                        class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                                        SOS Log List</h1>
                                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                                        <li class="breadcrumb-item text-muted">
                                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-muted">SOS Log</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <table class="table align-middle table-row-dashed fs-6 gy-5 dataTable" id="kt_customers_table">
                                <thead>
                                    <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
                                        <th>Sl No</th>
                                        <th>Reason</th>
                                        <th>User Name</th>
                                        <th>Job Unique Id</th>
                                        <th>Load Id</th>
                                        <th>Type</th>
                                    </tr>
                                </thead>
                                <tbody class="fw-semibold text-gray-600">

                                    @if($sos_details->isNotEmpty())
                                    @foreach($sos_details as $key => $sos_detail)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $sos_detail?->reason ?? '--'  }}</td>
                                        <td>{{ $sos_detail?->userDetails?->first_name.' '.$sos_detail?->userDetails?->last_name ?? '--' }}</td>
                                        <td>{{ $sos_detail?->jobDetails?->unique_id ?? '--' }}</td>
                                        <td>{{ $sos_detail?->loadDetails?->id ?? '--' }}</td>
                                        <td>{{ $sos_detail?->type == 1 ? 'SOS' : 'Delay' }}</td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('script')
        <script></script>
    @endpush
@endsection
