<?php

namespace App\Traits;

use Google\Client as Google_Client;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;

/**
 * Trait FlashMessages
 * @package App\Traits
 */

trait PushNotificationTrait
{

    /**
     * Send the FCM request
     * 
     * @param string $accessToken
     * @param array $data
     * @return mixed
     * @throws Exception
     */
    public function getAccessToken()
    {
        $credentialsFilePath = config_path('itsc_cal.json');
        $client = new Google_Client();
        $client->setAuthConfig($credentialsFilePath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $token = $client->fetchAccessTokenWithAssertion();
        $accessToken = $token['access_token'];
        return $accessToken;
    }

    public function sendNotification($deviceToken, $title, $body, $notificationBody, $deviceType, $jobId = null, $jobStatus = null)
    {
        if (!empty($deviceToken)) {
            $accessToken = $this->getAccessToken();

            if ($deviceType == 2) {
                $notification = null;
                $notiFicationdata = [
                    'title' => $title,
                    'body' => $body,
                    'notificationData' => $notificationBody,
                    "job_id" => $jobId,
                    "status" => $jobStatus
                ];
            } else {
                $notification = [
                    'title' => $title,
                    'body' => $body,
                ];
                $notiFicationdata = [
                    'notificationData' => $notificationBody,
                    "job_id" => $jobId,
                    "job_status" => $jobStatus,
                    "badge" => '5'
                ];
            }
            $data = [
                'message' => [
                    'token' => $deviceToken, //fcm token
                    'notification' => ($deviceType == 2) ? null : [
                        'title' => $title,
                        'body' => $body,
                    ],
                    'data' => $notiFicationdata,
                    "android" => [
                        "priority" => "high",
                    ],
                    "apns" => [
                        "headers" => [
                            "apns-priority" => "10",
                        ],
                        "payload" => [
                            "aps" => [
                                "content-available" => 1,
                                "mutable-content" => 1,
                            ]
                        ],
                    ],
                ],
            ];

            $dataString = json_encode($data);

            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $accessToken,
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/v1/projects/itsc-cal/messages:send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
            $response = curl_exec($ch);
            if ($response === FALSE) {
                die('FCM Send Error: ' . curl_error($ch));
            }

            curl_close($ch);

            return $response;
        }
    }
}
