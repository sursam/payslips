<?php

namespace App\Traits;

use App\Models\Load;
use PayPal\Api\Item;
use PayPal\Api\Payer;
use PayPal\Api\Amount;
use PayPal\Api\Payout;
use PayPal\Api\Details;
use PayPal\Api\Payment;
use PayPal\Api\Currency;
use PayPal\Api\ItemList;
use PayPal\Api\PayoutItem;
use PayPal\Api\Transaction;
use PayPal\Rest\ApiContext;
use Illuminate\Http\Request;
use PayPal\Api\RedirectUrls;
use Illuminate\Support\Carbon;
use PayPal\Api\PaymentExecution;
use Illuminate\Support\Facades\DB;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Api\PayoutSenderBatchHeader;


/**
 * Trait PayPal
 * @package App\Traits
 */

trait PayPal
{
    protected $apiContext;

    public function __construct()
    {
        $this->apiContext = new ApiContext(
            new OAuthTokenCredential(
                env('PAYPAL_CLIENT_ID'),      // PayPal Client ID
                env('PAYPAL_CLIENT_SECRET')   // PayPal Secret
            )
        );

        $this->apiContext->setConfig([
            'mode' => env('PAYPAL_ENVIRONMENT', 'sandbox'),
            'http.CURLOPT_TIMEOUT' => 30,
        ]);
    }
    public function getPayPalAccessToken()
    {
        // Access PayPal configuration
        $paypalClientId = config('services.paypal.key');
        $paypalSecret = config('services.paypal.secret');
        $paypalEnvironment = config('services.paypal.environment');
        $curl = curl_init();
        // Encode the client ID and client secret
        $auth = base64_encode($paypalClientId . ':' . $paypalSecret);

        curl_setopt_array($curl, [
            CURLOPT_URL => config('services.paypal.sandboxUrl') . '/v1/oauth2/token',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'Authorization: Basic ' . $auth
            ],
        ]);

        $response = curl_exec($curl);

        if ($response === false) {
            $error = curl_error($curl);
            curl_close($curl);
            return "cURL Error: " . $error;
        }

        curl_close($curl);
        $responseData = json_decode($response, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            // JSON is valid
            if (isset($responseData['access_token'])) {
                $accessToken = $responseData['access_token'];
                return $accessToken;
            } else {
                echo "Access token not found in the response.";
            }
        } else {
            echo "Invalid JSON response received.";
        }
    }
    public function createPaypalOrder($userDetails)
    {
        try {
            $requestId = null;
            if ($requestId === null) {
                $requestId = $this->generateUniqueRequestId();
            }
            $accessToken = $this->getPayPalAccessToken();
            $orderData = [
                "intent" => "CAPTURE",
                "purchase_units" => [
                    [
                        "reference_id" => $this->generateUniqueRequestId(),
                        "amount" => [
                            "currency_code" => "USD",
                            "value" => "1.00"
                        ],
                        "shipping" => [
                            "address" => [
                                "address_line_1" => $userDetails->address,
                                "address_line_2" => "Floor 6",
                                "admin_area_2" => "San Francisco",
                                "admin_area_1" => "CA",
                                "postal_code" =>  $userDetails->pin_code,
                                "country_code" => "US"
                            ]
                        ]
                    ]
                ],
                "payment_source" => [
                    "paypal" => [
                        "experience_context" => [
                            "payment_method_preference" => "IMMEDIATE_PAYMENT_REQUIRED",
                            "brand_name" => "EXAMPLE INC",
                            "locale" => "en-US",
                            "landing_page" => "LOGIN",
                            "shipping_preference" => "SET_PROVIDED_ADDRESS",
                            "user_action" => "PAY_NOW",
                            "return_url" => "https://example.com/returnUrl",
                            "cancel_url" => "https://example.com/cancelUrl"
                        ]
                    ]
                ]
            ];
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => config('services.paypal.sandboxUrl') . '/v2/checkout/orders',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($orderData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'PayPal-Request-Id: ' . $requestId,
                    'Authorization: Bearer ' . $accessToken
                ],
            ]);

            $response = curl_exec($curl);

            if ($response === false) {
                $error = curl_error($curl);
                curl_close($curl);
                return "cURL Error: " . $error;
            }

            curl_close($curl);

            $responseData = json_decode($response, true);
            $paypalCredData = [];
            if (json_last_error() === JSON_ERROR_NONE) {
                $paypalCredData = [
                    'access_token' => $accessToken,
                    'reference_id' => $requestId,
                    'order_id'     => $responseData['id'],
                    'order_response' => $response
                ];
                return [
                    'paypalCredentials' => $paypalCredData,
                    'responseData'     => $responseData,
                ];
            } else {
                return [];
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message);
        }
    }

    public function generateUniqueRequestId()
    {
        // Generate 16 bytes (128 bits) of random data or use the data passed into the function.
        $data = random_bytes(16);
        assert(strlen($data) == 16);

        // Set version to 0100
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        // Set bits 6-7 to 10
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        // Output the 36 character UUID.
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }


    // =======================================

    public function createPayment($amount, $loadIds)
    {
        try {
            // Generate a unique request ID
            $requestId = $this->generateUniqueRequestId();

            // Get PayPal access token
            $accessToken = $this->getPayPalAccessToken();
            if (!$accessToken) {
                return response()->json(['error' => 'Unable to retrieve access token'], 500);
            }

            // Prepare payment data
            $paymentData = [
                "intent" => "CAPTURE",
                "purchase_units" => [
                    [
                        "reference_id" => $requestId,
                        "amount" => [
                            "currency_code" => "USD",
                            "value" => number_format(floatval($amount), 2, '.', '')
                        ],
                        "shipping" => [
                            "address" => [
                                "address_line_1" => "test address",
                                "address_line_2" => "Floor 6",
                                "admin_area_2" => "San Francisco",
                                "admin_area_1" => "CA",
                                "postal_code" => "123456",
                                "country_code" => "US"
                            ]
                        ]
                    ]
                ],
                "payment_source" => [
                    "paypal" => [
                        "experience_context" => [
                            "payment_method_preference" => "IMMEDIATE_PAYMENT_REQUIRED",
                            "brand_name" => "EXAMPLE INC",
                            "locale" => "en-US",
                            "landing_page" => "LOGIN",
                            "shipping_preference" => "SET_PROVIDED_ADDRESS",
                            "user_action" => "PAY_NOW",
                            "return_url" => route('payment.success', ['amount' => $amount, 'loadIds' => $loadIds]),
                            "cancel_url" => route('payment.cancel')
                        ]
                    ]
                ]
            ];

            // Initialize cURL
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => env('PAYPAL_SANDBOX_URL') . '/v2/checkout/orders',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($paymentData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'PayPal-Request-Id: ' . $requestId,
                    'Authorization: Bearer ' . $accessToken
                ],
            ]);

            // Execute cURL request
            $response = curl_exec($curl);
            if ($response === false) {
                $error = curl_error($curl);
                curl_close($curl);
                return response()->json(['error' => "cURL Error: " . $error], 500);
            }

            curl_close($curl);

            $responseData = json_decode($response, true);
            $payerActionUrl = collect($responseData['links'])->firstWhere('rel', 'payer-action')['href'] ?? null;
            if ($payerActionUrl) {
                return $payerActionUrl;
            } else {
                return response()->json(['error' => 'Payer action URL not found'], 500);
            }
        } catch (\Exception $e) {
            logger()->error('Payment Creation Error: ' . $e->getMessage());
            return response()->json(['error' => 'Error creating payment'], 500);
        }
    }
    private function capturePayment($token, $amount, $loadIds)
    {
        try {
            // Get PayPal access token
            $accessToken = $this->getPayPalAccessToken();
            if (!$accessToken) {
                return response()->json(['error' => 'Unable to retrieve access token'], 500);
            }

            // Prepare capture data
            $captureData = [
                "amount" => [
                    "currency_code" => "USD", // Change to your currency
                    "value" => number_format(floatval($amount), 2, '.', '') // Replace with the actual amount
                ],
                "is_final_capture" => true,
            ];

            // Initialize cURL
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => env('PAYPAL_SANDBOX_URL') . "/v2/checkout/orders/{$token}/capture",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($captureData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $accessToken
                ],
            ]);

            // Execute cURL request
            $response = curl_exec($curl);
            if ($response === false) {
                $error = curl_error($curl);
                curl_close($curl);
                return response()->json(['error' => "cURL Error: " . $error], 500);
            }

            curl_close($curl);

            // Decode the response
            $responseData = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return response()->json(['error' => 'Invalid JSON response'], 500);
            }
            // dd($responseData);
            // Check capture status
            if ($responseData['status'] === 'COMPLETED') {
                // update load status in your database
                Load::whereIn('id', $loadIds)->update(['is_payment_initiated' => 2]);
                // return response()->json(['message' => 'Payment captured successfully', 'data' => $responseData]);
                // return response()->json([
                //     'status'        =>  true,
                //     'response_code' =>  200,
                //     'message'       =>  "Payment captured successfully",
                //     'data'          =>  $responseData
                // ]);
                $orderId = $responseData['id'];
                $amount = $responseData['purchase_units'][0]['payments']['captures'][0]['amount']['value'];
                $email = $responseData['payer']['email_address'];
                $currentDate = Carbon::now();
                return view("payment.success", compact('orderId', 'amount', 'email', 'currentDate'));
            } else {
                return response()->json(['error' => 'Payment capture failed', 'data' => $responseData], 500);
            }
        } catch (\Exception $e) {
            logger()->error('Payment Capture Error: ' . $e->getMessage());
            return response()->json(['error' => 'Error capturing payment'], 500);
        }
    }

    public function sendPayPalPayout($receiverEmail, $amount, $currency = 'USD', $note = 'Thank you for your service')
    {
        try {
            // Generate access token using the helper function
            $accessToken = $this->getPayPalAccessToken();
            if (!$accessToken) {
                throw new \Exception('Unable to fetch access token.');
            }

            // Prepare the payout data
            $payoutData = [
                "sender_batch_header" => [
                    "sender_batch_id" => $this->generateUniqueRequestId(),
                    "email_subject" => "You have received a payout!",
                    "email_message" => "You have received funds from our service!",
                ],
                "items" => [
                    [
                        "recipient_type" => "EMAIL",
                        "amount" => [
                            "value" => $amount,
                            "currency" => $currency,
                        ],
                        "receiver" => $receiverEmail, // Recipient's email
                        "note" => $note,
                        "sender_item_id" => $this->generateUniqueRequestId(),
                    ],
                ],
            ];
            // Make API call to PayPal
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => config('services.paypal.sandboxUrl') . '/v1/payments/payouts',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payoutData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $accessToken,
                ],
            ]);

            $response = curl_exec($curl);
            if ($response === false) {
                throw new \Exception('cURL Error: ' . curl_error($curl));
            }

            curl_close($curl);
            // Decode the response
            $responseData = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE || !isset($responseData['batch_header']['payout_batch_id'])) {
                throw new \Exception('Failed to send PayPal payout. Invalid response: ' . $response);
            }
            // Step 5: Log success and return response
            logger('------------------------------------------------------------------------------------');
            logger('Payout sent successfully. Batch ID: ' . $responseData['batch_header']['payout_batch_id']);
            logger('--------------------------------------------------------------------------------------');
            // Return success response
            // return [
            //     'success' => true,
            //     'batch_id' => $responseData['batch_header']['payout_batch_id'],
            //     'message' => 'Payout sent successfully',
            //     'responseData' => $responseData,
            // ];
            return true;
        } catch (\Exception $e) {
            return false;
            logger('Error sending PayPal payout: ' . $e->getMessage());
            // return [
            //     'success' => false,
            //     'message' => $e->getMessage(),
            // ];
        }
    }
}
