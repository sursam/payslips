<?php

namespace App\Traits;

use DateTime;
use App\Models\User;
use Stripe\StripeClient;


trait StripeTrait
{
    public static function getClient()
    {
        return new \Stripe\StripeClient(env('STRIPE_SECRET'));
    }
    public function createStripeCustomer($firstName, $lastName, $email)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $stripeCustomer = $stripe->customers->create([
                'name' => $firstName . ' ' . $lastName,
                'email' => $email
            ]);
            return $stripeCustomer->id;
        } catch (\Exception $e) {
            // return response()->json(['error' => 'Failed to create Stripe customer: ' . $e->getMessage()], 500);
        }
    }

    public function createStripeConnectAccount($stripeCustomerId, $firstName, $lastName, $email, $country = "US", $address, $city, $pinCode, $dob = null, $phone = null)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $fullAddress = [
                'line1' => $address,
                'city' => $city,
                'postal_code' => $pinCode,
                'country' => 'US'
            ];
            $individualData = [
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $email,
                'address' => $fullAddress
            ];

            // Add optional fields if provided
            if ($dob) {
                // DOB must be in format: ['day' => 15, 'month' => 3, 'year' => 1990]
                // If you're receiving a date string, convert it:
                if (is_string($dob)) {
                    $dobDate = new DateTime($dob);
                    $individualData['dob'] = [
                        'day' => (int)$dobDate->format('d'),
                        'month' => (int)$dobDate->format('m'),
                        'year' => (int)$dobDate->format('Y')
                    ];
                } else {
                    $individualData['dob'] = $dob; // Already in correct format
                }
            }
            if ($phone) {
                $individualData['phone'] = $phone;
            }
            $accountData = [
                'type' => 'custom',
                'country' => $country,
                'email' => $email,
                'business_type' => 'individual',
                'capabilities' => [
                    'card_payments' => ['requested' => true],
                    'transfers' => ['requested' => true]
                ],
                'individual' => $individualData,
                'metadata' => [
                    'customer_id' => $stripeCustomerId,
                    'created_by' => 'platform'
                ]
            ];

            // Debug: Log the data being sent to Stripe
            logger('Stripe Account Data:', $accountData);
            $stripeAccount = $stripe->accounts->create($accountData);

            // Also update the customer with the Connect account ID for easy lookup
            $stripe->customers->update($stripeCustomerId, [
                'metadata' => [
                    'connect_account_id' => $stripeAccount->id
                ]
            ]);

            // return [
            //     'account_id' => $stripeAccount->id,
            //     'customer_id' => $stripeCustomerId
            // ];
            return $stripeAccount->id;
        } catch (\Exception $e) {
            // Enhanced error logging
            logger('Stripe Connect Account Creation Error: ' . $e->getMessage());
            logger('Error Code: ' . $e->getCode());
            throw new \Exception('Failed to create Stripe Connect account: ' . $e->getMessage());
        }
    }

    public function accountVerification($accountId, $data)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            return $stripe->accounts->update($accountId, $data);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Account verification failed: ' . $e->getMessage()], 500);
        }
    }
    public function addBankAccount($stripeAccountId, $currency, $accHolderName, $routingNo, $accountNo)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Add bank account as external account to the Connect account
            $bankAccount = $stripe->accounts->createExternalAccount(
                $stripeAccountId, // This is the Connect account ID, not customer ID
                [
                    'external_account' => [
                        'object' => 'bank_account',
                        'currency' => $currency,
                        'account_holder_name' => $accHolderName,
                        'account_holder_type' => 'individual', // or 'company'
                        'routing_number' => $routingNo,
                        'account_number' => $accountNo,
                        'country' => 'US',
                    ],
                ]
            );

            return $bankAccount->id;
        } catch (\Exception $e) {
            throw new \Exception('Failed to add bank account to Connect account: ' . $e->getMessage());
        }
    }
    public function createPayoutToConnectAccount($stripeAccountId, $amount, $currency = 'usd')
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Create payout from the Connect account
            $payout = $stripe->payouts->create([
                'amount' => $amount, // Amount in cents
                'currency' => $currency,
            ], [
                'stripe_account' => $stripeAccountId // Important: specify the Connect account
            ]);

            return $payout;
        } catch (\Exception $e) {
            throw new \Exception('Failed to create payout: ' . $e->getMessage());
        }
    }

    // Alternative: Transfer funds from your platform to Connect account first, then payout
    public function transferToConnectAccount($stripeAccountId, $amount, $currency = 'usd')
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Transfer from your platform account to Connect account
            $transfer = $stripe->transfers->create([
                'amount' => $amount,
                'currency' => $currency,
                'destination' => $stripeAccountId,
            ]);

            return $transfer;
        } catch (\Exception $e) {
            throw new \Exception('Failed to transfer to Connect account: ' . $e->getMessage());
        }
    }
    public function generateAccountLink($accountId, $deviceType)
    {
        // Create a new Stripe client instance
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

        // Generate the account link
        $accountLink = $stripe->accountLinks->create([
            'account' => $accountId,
            'refresh_url' => route('stripe.reauth', [$deviceType]),
            'return_url' => route('stripe.complete', [$deviceType, $accountId]),
            'type' => 'account_onboarding', // Use 'account_onboarding' if applicable
        ]);

        return $accountLink->url;
    }

    public function checkStripeAccountStatus($accountId)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

        $account = $stripe->accounts->retrieve($accountId);

        $capabilities = $account->capabilities;
        $requirements = $account->requirements;
        // return [
        //     'charges_enabled' => $account->charges_enabled,
        //     'payouts_enabled' => $account->payouts_enabled,
        // ];
        return $account->charges_enabled && $account->payouts_enabled;
    }

    public function transferToConnectedAccount($connectedAccountId, $amount, $currency = 'usd', $metadata = [])
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            // Check platform account balance first
            $platformBalance = $this->getStripePlatformBalance();
            if (!$platformBalance['success']) {
                return [
                    'success' => false,
                    'error' => 'Could not retrieve platform balance'
                ];
            }

            // Find balance for the specified currency
            $availableAmount = 0;
            foreach ($platformBalance['available'] as $balanceItem) {
                if ($balanceItem['currency'] === $currency) {
                    $availableAmount = $balanceItem['amount'];
                    break;
                }
            }

            if ($availableAmount < $amount) {
                return [
                    'success' => false,
                    'error' => 'Insufficient funds in platform account',
                    'available_amount' => $availableAmount,
                    'requested_amount' => $amount,
                    'available_dollars' => $availableAmount / 100,
                    'requested_dollars' => $amount / 100
                ];
            }
            // Create transfer from platform to connected account
            $transfer = $stripe->transfers->create([
                'amount' => $amount,
                'currency' => $currency,
                'destination' => $connectedAccountId,
                'metadata' => $metadata,
            ]);

            return [
                'success' => true,
                'transfer_id' => $transfer->id,
                'amount' => $transfer->amount,
                'currency' => $transfer->currency,
                'destination' => $transfer->destination,
                'created' => $transfer->created,
                'data' => $transfer
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }

    /**
     * Transfer and then immediately payout to bank account
     * This does both operations: Platform -> Connected Account -> Bank Account
     */
    public function transferAndPayout($connectedAccountId, $amount, $bankAccountId = null, $currency = 'usd', $metadata = [])
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            // Step 1: Transfer from platform to connected account
            $transferResult = $this->transferToConnectedAccount($connectedAccountId, $amount, $currency, $metadata);
            // dd($transferResult);
            if (!$transferResult['success']) {
                return $transferResult;
            }

            // Step 2: Wait a moment for the transfer to complete
            sleep(2);

            // Step 3: Create payout from connected account to bank
            $payoutData = [
                'amount' => $amount,
                'currency' => $currency,
                'metadata' => array_merge($metadata, ['transfer_id' => $transferResult['transfer_id']]),
            ];

            if ($bankAccountId) {
                $payoutData['destination'] = $bankAccountId;
            }

            $payout = $stripe->payouts->create($payoutData, [
                'stripe_account' => $connectedAccountId
            ]);

            return [
                'success' => true,
                'transfer_id' => $transferResult['transfer_id'],
                'payout_id' => $payout->id,
                'amount' => $amount,
                'currency' => $currency,
                'transfer_data' => $transferResult['data'],
                'payout_data' => $payout
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'error_code' => $e->getCode(),
                'transfer_completed' => isset($transferResult) && $transferResult['success']
            ];
        }
    }

    /**
     * Get platform account balance
     */
    public function getStripePlatformBalance()
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $balance = $stripe->balance->retrieve();
            return [
                'success' => true,
                'available' => $balance->available,
                'pending' => $balance->pending,
                'raw_balance' => $balance
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get connected account balance
     */
    public function getConnectedAccountBalance($connectedAccountId)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $balance = $stripe->balance->retrieve([], [
                'stripe_account' => $connectedAccountId
            ]);

            return [
                'success' => true,
                'available' => $balance->available,
                'pending' => $balance->pending,
                'raw_balance' => $balance
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get transfer details
     */
    public function getTransfer($transferId)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $transfer = $stripe->transfers->retrieve($transferId);

            return [
                'success' => true,
                'data' => $transfer
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * List transfers
     */
    public function listTransfers($limit = 10, $destination = null)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $params = ['limit' => $limit];

            if ($destination) {
                $params['destination'] = $destination;
            }

            $transfers = $stripe->transfers->all($params);

            return [
                'success' => true,
                'data' => $transfers
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Reverse a transfer (if needed)
     */
    public function reverseTransfer($transferId, $amount = null, $metadata = [])
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $reverseData = ['metadata' => $metadata];

            if ($amount) {
                $reverseData['amount'] = $amount;
            }

            $reversal = $stripe->transfers->createReversal($transferId, $reverseData);

            return [
                'success' => true,
                'reversal_id' => $reversal->id,
                'amount' => $reversal->amount,
                'data' => $reversal
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    public function getUsersBankDetailList($accountId)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $externalAccounts = $stripe->accounts->allExternalAccounts(
                $accountId,
                ['object' => 'bank_account']
            );
            return $externalAccounts->data;
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return [];
        }
    }
    public function updateBankAccount($accountId, $bankAccountId, $data)
    {
        try {
            $data['account_holder_type'] = 'individual';
            $data['account_holder_name'] = auth()->user()->name;
            $data['routing_number'] = '110000000';
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            return $stripe->accounts->updateExternalAccount(
                $accountId,
                $bankAccountId,
                $data
            );
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return [];
        }
    }
    public function changeDefaultBankAccount($accountId, $bankAccountId)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Retrieve the external bank account
            $bankAccount = $stripe->accounts->retrieveExternalAccount(
                $accountId,
                $bankAccountId
            );

            // Update it to be the default for its currency
            $updatedBankAccount = $stripe->accounts->updateExternalAccount(
                $accountId,
                $bankAccountId,
                [
                    'default_for_currency' => true
                ]
            );
            // if update is successful, change in database
            if ($updatedBankAccount) {
                $isUser = User::where('stripe_account_id', $accountId)->update([
                    'stripe_bank_acc_id' => $updatedBankAccount->id
                ]);
            }

            return $updatedBankAccount;
        } catch (\Exception $e) {
            logger("Stripe error: " . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return (object)[
                'success' => false,
                'message' => 'Failed to set default bank account.'
            ];
        }
    }
    public function deleteBankAccount($accountId, $bankAccountId)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Step 1: Retrieve the bank account
            $bankAccount = $stripe->accounts->retrieveExternalAccount(
                $accountId,
                $bankAccountId
            );

            // Step 2: Check if it's the default for currency
            if (!empty($bankAccount->default_for_currency) && $bankAccount->default_for_currency === true) {
                logger("Attempted to delete default bank account: {$bankAccountId}");
                return (object)[
                    'deleted' => false,
                    'message' => 'Cannot delete default bank account. Please set another account as default first.'
                ];
            }

            // Step 3: Proceed with deletion
            $isDeleted = $stripe->accounts->deleteExternalAccount(
                $accountId,
                $bankAccountId
            );

            return $isDeleted;
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return (object)[
                'deleted' => false,
                'message' => 'Stripe error occurred during deletion.'
            ];
        }
    }

    public function retriveBankAccount($accountId, $bankAccountId)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            return $stripe->accounts->retrieveExternalAccount(
                $accountId,
                $bankAccountId
            );
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return (object)[];
        }
    }
    public function createSetupIntent($userId = 0)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        $user = User::find($userId);
        // Ensure the user has a Stripe customer ID
        if ($user->stripe_customer_id == null) {
            $customer = $stripe->customers->create([
                'name' => $user->name,
                'email' => $user->email,
            ]);
            $user->update(['stripe_customer_id' => $customer->id]);
        }
        $user = User::find($userId);
        // Create SetupIntent
        $setupIntent = $stripe->setupIntents->create([
            'customer' => $user->stripe_customer_id
        ]);
        $ephemeralKey = $stripe->ephemeralKeys->create([
            'customer' => $user->stripe_customer_id,
        ], [
            'stripe_version' => '2023-10-16', // Updated to a more recent API version
        ]);
        $setupIntent['ephemeralKey'] = $ephemeralKey->secret;

        return $setupIntent ?? [];
    }
    public function retriveCustomerPaymentMethod($customerId){
        try{
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $customer = $stripe->customers->retrieve($customerId, []);
            $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method ?? null;
            return $defaultPaymentMethodId;
        }catch(\Exception $e){
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return null;
        }
    }
    public function setDefaultPaymentMethod($customerId, $paymentMethodId){
        try{
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $customer = $stripe->customers->update($customerId, [
                'invoice_settings' => [
                    'default_payment_method' => $paymentMethodId
                ]
            ]);
            return $paymentMethodId;
        }catch(\Exception $e){
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return null;
        }
    }
}
