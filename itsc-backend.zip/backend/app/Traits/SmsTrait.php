<?php

namespace App\Traits;

use Twilio\Rest\Client;

/**
 * Trait FlashMessages
 * @package App\Traits
 */

trait SmsTrait
{
    // public function sendOtpSms($data)
    // {
    //     $phone = str_replace("+91", "", $data['phone']);
    //     $otp = $data['otp'];
    //     $message = "Hi, Your one time password is: " . $otp . ". Please don't share this with anyone - Legal meet.";
    //     $apiKey = urlencode('NDI0Nzc3NjQ0MjY5NjI2ZDQ0MzI0NjM0Njk2ZDU1NjM=');
    //     $numbers = $phone;
    //     $sender = urlencode('Legal Meet');
    //     $message = rawurlencode($message);
    //     $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
    //     $ch = curl_init('https://api.textlocal.in/send/');
    //     curl_setopt($ch, CURLOPT_POST, true);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     $resp = curl_exec($ch);
    //     curl_close($ch);
    //     $resp = json_decode($resp);
    //     return $resp;
    // }

    // twillio sms
    public function sendSMS($countryCode, $receiverNumber, $otp)
    {
        $messageText = "Your One-Time Password (OTP) for signing in Conectar Advantage is: $otp\n\n";
        $messageText .= "Please use this OTP to complete your sign-in process. ";

        try {
            $account_sid = config('services.twillio.sid');
            $auth_token = config('services.twillio.token');
            $twilio_number = config('services.twillio.from');
            $client = new Client($account_sid, $auth_token);
            $phoneNoWithCountryCode = "+" . $countryCode . $receiverNumber;
            $message = $client->messages->create(
                $phoneNoWithCountryCode,
                [
                    "body" => $messageText,
                    "from" => $twilio_number
                ]
            );

            $messageSid = $message->sid;

            return [
                'success' => true,
                'message' => 'SMS sent successfully!',
                'message_sid' => $messageSid,
                'initial_status' => $message->status
            ];
        } catch (\Exception $e) {
            logger()->error('SMS Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
