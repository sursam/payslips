<?php

namespace App\Traits;

use App\Models\Notification;
use Illuminate\Support\Facades\Auth;

/**
 * Trait FlashMessages
 * @package App\Traits
 */

trait NotificationTrait
{
    public function saveNotification($data)
    {
        try {
            $notificationSave = Notification::create($data);
            if($notificationSave) {
                return true;
            };
            return false;
        } catch (\Throwable $th) {
            $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
            return $this->responseJson(false, 500, "something went wrong");
        }
    }

    public function getAllNotifications()
    {
        try {
            $allNotification = Notification::where(['user_id' =>Auth::user()->id, 'is_read' => 0, 'is_for_job' => 0])->latest()->get();
            if ($allNotification) {
                return $allNotification;
            } else {
                return [];
            }
        } catch (\Throwable $th) {
            logger($th->getMessage() . ' -- ' . $th->getLine() . ' -- ' . $th->getFile());
            return $this->responseJson(false, 500, "internal server error", []);
        }
    }
    public function getAllJobNotifications()
    {
        try {
            $allNotification = Notification::where(['user_id' =>Auth::user()->id, 'is_read' => 0, 'is_for_job' => 1])->latest()->get();
            if ($allNotification) {
                return $allNotification;
            } else {
                return [];
            }
        } catch (\Throwable $th) {
            logger($th->getMessage() . ' -- ' . $th->getLine() . ' -- ' . $th->getFile());
            return $this->responseJson(false, 500, "internal server error", []);
        }
    }

    public function countUnReadNotification()
    {
        try {
            $allNotificationCount = Notification::where(['user_id' => Auth::user()->id, 'is_read' => 0])->count();
            if ($allNotificationCount) {
                return $allNotificationCount;
            } else {
                return 0;
            }
        } catch (\Throwable $th) {
            $status = false;
            $code = 500;
            $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
            $message = config('constants.CATCH_ERROR_MSG');
            return $this->responseJson($status, $code, $message, $response);
        }
    }
}
