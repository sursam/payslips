<?php

namespace App\Http\Controllers\Api\contractor;

use Exception;
use Dompdf\Dompdf;
use App\Models\Job;
use Dompdf\Options;
use App\Models\City;
use App\Models\Load;
use App\Models\User;
use App\Models\Earning;
use Stripe\StripeClient;
use App\Models\CancelJob;
use App\Traits\UploadAble;
use App\Models\CompanyInfo;
use App\Models\Transaction;
use App\Models\JobComission;
use App\Models\LoadActivity;
use Illuminate\Http\Request;
use App\Models\PastJobCompany;
use Illuminate\Support\Carbon;
use App\Models\JobConfigureMap;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Traits\PushNotificationTrait;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\Auth\JobResource;
use App\Http\Resources\Api\Common\AuthResource;
use App\Http\Resources\Api\Auth\RunningJobResource;
use App\Http\Resources\Api\Auth\JobResourceCollection;
use App\Http\Resources\Api\Auth\LiveActiveLoadResource;
use App\Http\Resources\Api\Auth\RunningJobLoadResource;
use App\Http\Resources\Api\Auth\ShowLoadActivityResource;
use App\Http\Resources\Api\Auth\RunningJobResourceCollection;
use App\Http\Resources\Api\Auth\PendingActionResourceCollection;

class JobController extends BaseController
{
    use UploadAble;
    use PushNotificationTrait;
    public function postJob(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'source'                        => 'required',
            'destination'                   => 'required',
            'material_id'                   => 'required|exists:materials,id',
            // 'material_other'         => ''
            'truck_type_ids'                => 'required',
            'equipment_id'                  => 'sometimes|nullable',
            // 'equipment_other'        =>
            'pickup_date_time'              => 'required|date_format:Y-m-d H:i:s',
            'delivery_date_time'            => 'required|date_format:Y-m-d H:i:s',
            'total_mileage'                 => 'required',
            'pickup_location_company'       => 'required|string|max:255',
            'pickup_location_contact_no'    => 'required',
            'pickup_location_email'         => 'required|email',
            'pickup_contact'                => 'required',
            'drop_off_location_company'     => 'required|string|max:255',
            'drop_off_location_contact_no'  => 'required',
            'drop_off_location_email'       => 'required|email',
            'drop_off_contact'              => 'required',
            'job_estimate_price'            => 'required',
            'source_lat'                    => 'required',
            'source_lng'                    => 'required',
            'delivery_lat'                  => 'required',
            'delivery_lng'                  => 'required',
            'order_no'                      => 'required',
            'per_unit'                      => 'required',
            'per_unit_price'                => 'required',
            'no_of_trucks'                  => 'required',
            'load_type_id'                  => 'required',
            'load_weight'                   => 'required|array',
            'load_weight.*'                 => 'numeric',
            'load_cost'                     => 'required|array',
            'load_cost.*'                   => 'numeric', // Each load_cost value must be numeric
            'is_draft'                      => 'required|in:0,1',               // 0 ->published 1 -> draft
            'is_hourly'                     => 'required|in:0,1'                // 0 => not hourly job 1 => hourly job

        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction();
        try {
            $totalMiles = calculateMiles($request->source_lat, $request->source_lng, $request->delivery_lat, $request->delivery_lng);
            $cityName = $this->getCity($request->source_lat, $request->source_lng);
            $cityId = null;
            if ($cityName != null) {
                $cityDetails = City::where('name', 'like', '%' . $cityName . '%')->first();
                if ($cityDetails) {
                    $cityId = $cityDetails->id;
                }
            }
            // $cityName = $this->getLocation($request->source_lat, $request->source_lng);
            $salesTax = $this->getComissionPercentage($cityId, $request->truck_type_ids);
            $truckerPercentage = $salesTax->trucker_percentage ?? 90;
            $calPercentage = $salesTax->cal_percentage ?? 10;
            $isJobCreated = Job::create([
                'user_id' => auth()->user()->id,
                'load_type_id' => $request->load_type_id,
                'order_no' => $request->order_no,
                'pickup_location_company' => $request->pickup_location_company,
                'pickup_location_contact_no' => $request->pickup_location_contact_no,
                'pickup_location_email'  => $request->pickup_location_email,
                'pickup_contact' => $request->pickup_contact,
                'drop_off_location_company' => $request->drop_off_location_company,
                'drop_off_location_contact_no' => $request->drop_off_location_contact_no,
                'drop_off_location_email' => $request->drop_off_location_email,
                'drop_off_contact'        => $request->drop_off_contact,
                'source' => $request->source,
                'destination' => $request->destination,
                'pickup_date_time' => $request->pickup_date_time,
                'delivery_date_time' => $request->delivery_date_time,
                'source_lat' => $request->source_lat,
                'source_lng' => $request->source_lng,
                'delivery_lat' => $request->delivery_lat,
                'delivery_lng' => $request->delivery_lng,
                'material_id' => $request->material_id,
                'material_other' => ($request->material_other && $request->material_other != '') ? $request->material_other : null,
                'truck_type_ids' => $request->truck_type_ids,
                'equipment_id' => $request->equipment_id ?? null,
                'equipment_other' => ($request->equipment_other && $request->equipment_other != '') ? $request->equipment_other : null,
                'no_of_trucks' => $request->no_of_trucks,
                'total_mileage' => $request->total_mileage,
                'load_spacing_minutes' => ($request->load_spacing_minutes && $request->load_spacing_minutes != '') ? $request->load_spacing_minutes : null,
                'per_unit' => $request->per_unit,
                'per_unit_price' => $request->per_unit_price,
                'job_estimate_price' => $request->job_estimate_price,
                'total_miles' => $totalMiles,
                'notes' => ($request->notes && $request->notes != '') ? $request->notes : null,
                'is_draft' => $request->is_draft,
                'is_hourly' => $request->is_hourly,
                'posted_by' => auth()->user()->id,
                'posted_for' => auth()->user()->id
            ]);
            if ($isJobCreated) {
                foreach ($request->load_weight as $index => $weight) {
                    Load::create([
                        'job_id' => $isJobCreated->id,
                        'weight' => $weight,
                        'load_cost' => isset($request->load_cost[$index]) ? (float)$request->load_cost[$index] : 0, // Default to 0 if no corresponding cost
                        'cal_comission' => (isset($request->load_cost[$index]) && (float)$request->load_cost[$index] > 0)
                            ? (float)$request->load_cost[$index] / $calPercentage
                            : 0,
                        'trucker_get' => (isset($request->load_cost[$index]) && (float)$request->load_cost[$index] > 0)
                            ? ((float)$request->load_cost[$index] - ((float)$request->load_cost[$index] * ((100 - $truckerPercentage) / 100)))
                            : 0,
                        'min_completed_hours' => $request->min_completed_hours,
                        'max_completed_hours' => $request->max_completed_hours
                    ]);
                }
                $title = "Job Posted";
                $message = $request->is_draft == 0 ? "You posted a new job with id " . $isJobCreated->unique_id : "You drafted a new job with id " . $isJobCreated->unique_id;
                $this->notificationToContracter(auth()->user()->id, $title, $message, $isJobCreated->id);
                DB::commit();
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function postJob_v1(Request $request)
    {
        // Enhanced validation
        // $validator = Validator::make($request->all(), [
        //     'job_id' => 'nullable|exists:jobs,id',
        //     'source' => 'required|string|max:255',
        //     'destination' => 'required|string|max:255',
        //     'material_id' => 'nullable|exists:materials,id',
        //     'truck_type_ids' => 'nullable|string',
        //     'equipment_id' => 'nullable|exists:equipments,id',
        //     'pickup_date_time' => 'required|date_format:Y-m-d H:i:s',
        //     'delivery_date_time' => 'required|date_format:Y-m-d H:i:s|after:pickup_date_time',
        //     'total_mileage' => 'required|numeric|min:0',
        //     'pickup_location_company' => 'required|string|max:255',
        //     'pickup_location_contact_no' => 'required|string|max:20',
        //     'pickup_location_email' => 'required|email|max:255',
        //     'pickup_contact' => 'required|string|max:255',
        //     'drop_off_location_company' => 'required|string|max:255',
        //     'drop_off_location_contact_no' => 'required|string|max:20',
        //     'drop_off_location_email' => 'required|email|max:255',
        //     'drop_off_contact' => 'required|string|max:255',
        //     'job_estimate_price' => 'required|numeric|min:0',
        //     'source_lat' => 'required|numeric|between:-90,90',
        //     'source_lng' => 'required|numeric|between:-180,180',
        //     'delivery_lat' => 'required|numeric|between:-90,90',
        //     'delivery_lng' => 'required|numeric|between:-180,180',
        //     'order_no' => 'required|string|max:100',
        //     'per_unit' => 'required|string|max:50',
        //     'per_unit_price' => 'required|numeric|min:0',
        //     'no_of_trucks' => 'required|integer|min:1',
        //     'load_type_id' => 'required|exists:load_types,id',
        //     'load_weight' => 'required|array|min:1',
        //     'load_weight.*' => 'required|numeric|min:0',
        //     'load_cost' => 'required|array|min:1',
        //     'load_cost.*' => 'required|numeric|min:0',
        //     'is_draft' => 'required|in:0,1',
        //     'is_hourly' => 'required|in:0,1',
        //     'min_completed_hours' => 'nullable|numeric|min:0',
        //     'max_completed_hours' => 'nullable|numeric|min:0|gte:min_completed_hours',
        // ]);

        // if ($validator->fails()) {
        //     return $this->responseJson(false, 422, $validator->errors()->first());
        // }

        DB::beginTransaction();

        try {
            // Calculate common data
            $commonData = $this->prepareJobData($request);

            // Determine if this is create or update
            $isUpdate = !empty($request->job_id);

            if ($isUpdate) {
                $job = $this->updateMyJob($request->job_id, $commonData);
                $message = ($request->is_draft == 0 && $request->step == 3)
                    ? "You posted your job with id " . $job->unique_id
                    : "You updated your draft job with id " . $job->unique_id;
            } else {
                $job = $this->createJob($commonData);
                $message = ($request->is_draft == 0 && $request->step == 3)
                    ? "You posted a new job with id " . $job->unique_id
                    : "You drafted a new job with id " . $job->unique_id;
            }

            // Handle loads
            if (!empty($request->loads) && count($request->loads) > 0) {
                $this->handleJobLoads($request->loads, $request->job_id);
            }

            // Send notification
            if ($request->step == 3) {
                $this->notificationToContracter(
                    auth()->user()->id,
                    "Job " . ($isUpdate ? "Updated" : "Posted"),
                    $message,
                    $job->id
                );
            }


            DB::commit();
            return $this->responseJson(true, 200, config('services.responseMessages.post.succ'), [
                "job_id" => $job->id
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            logger()->error('Job posting error: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'user_id' => auth()->id()
            ]);
            return $this->responseJson(false, 500, $e->getMessage() . "--" . $e->getLine() . "--" . $e->getLine() . "--" . $e->getFile(), (object)[]);
        }
    }

    /**
     * Prepare common job data
     */
    private function prepareJobData(Request $request): array
    {
        $jobData = null;
        if (!empty($request->job_id)) {
            $jobData = Job::find($request->job_id);
        }

        $totalMiles = calculateMiles(
            $request->source_lat,
            $request->source_lng,
            $request->delivery_lat,
            $request->delivery_lng
        );

        if ($request->source_lat && $request->source_lng) {
            $getCity = $this->findCity($request->source_lat, $request->source_lng);
            $data = $getCity->getData(); // This is stdClass

            if (isset($data->city_data) && isset($data->city_data->city_id)) {
                Log::info("================================================================");
                $cityId = $data->city_data->city_id;
                Log::info("city_id" . $cityId);
                // logger("city_id", $cityId);
                $salesTax = $this->getComissionPercentage($cityId, $request->truck_type_ids);
                Log::info("sales_tax" . $salesTax);
                Log::info("================================================================");
            } else {
                $cityId = null;
                $salesTax = null;
            }
        } else {
            $cityId = null;
            $salesTax = null;
        }


        return [
            'user_id' => $jobData ? $jobData->user_id : auth()->user()->id,
            'load_type_id' => $request->has('load_type_id') ? $request->load_type_id : ($jobData ? $jobData->load_type_id : null),
            'order_no' => $request->order_no ?? ($jobData ? $jobData->order_no : null),
            'pickup_location_company' => $request->pickup_location_company ?? ($jobData ? $jobData->pickup_location_company : null),
            'pickup_location_contact_no' => $request->pickup_location_contact_no ?? ($jobData ? $jobData->pickup_location_contact_no : null),
            'pickup_location_email' => $request->pickup_location_email ?? ($jobData ? $jobData->pickup_location_email : null),
            'pickup_contact' => $request->pickup_contact ?? ($jobData ? $jobData->pickup_contact : null),
            'drop_off_location_company' => $request->drop_off_location_company ?? ($jobData ? $jobData->drop_off_location_company : null),
            'drop_off_location_contact_no' => $request->drop_off_location_contact_no ?? ($jobData ? $jobData->drop_off_location_contact_no : null),
            'drop_off_location_email' => $request->drop_off_location_email ?? ($jobData ? $jobData->drop_off_location_email : null),
            'drop_off_contact' => $request->drop_off_contact ?? ($jobData ? $jobData->drop_off_contact : null),
            'source' => $request->source ?? ($jobData ? $jobData->source : null),
            'destination' => $request->destination ?? ($jobData ? $jobData->destination : null),
            'pickup_date_time' => $request->pickup_date_time ?? ($jobData ? $jobData->pickup_date_time : null),
            'delivery_date_time' => $request->delivery_date_time ?? ($jobData ? $jobData->delivery_date_time : null),
            'source_lat' => $request->source_lat ?? ($jobData ? $jobData->source_lat : null),
            'source_lng' => $request->source_lng ?? ($jobData ? $jobData->source_lng : null),
            'delivery_lat' => $request->delivery_lat ?? ($jobData ? $jobData->delivery_lat : null),
            'delivery_lng' => $request->delivery_lng ?? ($jobData ? $jobData->delivery_lng : null),
            'material_id' => $request->has('material_id') ? $request->material_id : ($jobData ? $jobData->material_id : null),
            'material_other' => $request->has('material_other') ? $request->material_other : ($jobData ? $jobData->material_other : null),
            'truck_type_ids' => $request->truck_type_ids ?? ($jobData ? $jobData->truck_type_ids : null),
            'equipment_id' => $request->has('equipment_id') ? $request->equipment_id : ($jobData ? $jobData->equipment_id : null),
            'equipment_other' => $request->has('equipment_other') ? $request->equipment_other : ($jobData ? $jobData->equipment_other : null),
            'no_of_trucks' => $request->no_of_trucks ?? ($jobData ? $jobData->no_of_trucks : null),
            'total_mileage' => $request->total_mileage ?? ($jobData ? $jobData->total_mileage : null),
            'load_spacing_minutes' => $request->load_spacing_minutes ?? ($jobData ? $jobData->load_spacing_minutes : 0),
            'per_unit' => $request->per_unit ?? ($jobData ? $jobData->per_unit : null),
            'per_unit_price' => $request->per_unit_price ?? ($jobData ? $jobData->per_unit_price : null),
            'job_estimate_price' => $request->job_estimate_price ?? ($jobData ? $jobData->job_estimate_price : null),
            'total_miles' => $request->total_mileage ?? ($jobData ? $jobData->total_mileage : 0.00),
            'notes' => $request->notes ?? ($jobData ? $jobData->notes : null),
            'is_draft' => $request->is_draft ?? ($jobData ? $jobData->is_draft : 1),
            'is_hourly' => $request->is_hourly ?? ($jobData ? $jobData->is_hourly : 0),
            'posted_by' => auth()->user()->id,
            'posted_for' => auth()->user()->id,
            'step' => $request->step ?? ($jobData ? $jobData->step : 3),
            'sales_tax_data' => $salesTax
        ];
    }

    /**
     * Create a new job
     */
    private function createJob(array $data): Job
    {
        $salesTaxData = $data['sales_tax_data'];
        unset($data['sales_tax_data']);

        $job = Job::create($data);
        $job->sales_tax_data = $salesTaxData;

        return $job;
    }

    /**
     * Update existing job
     */
    private function updateMyJob(int $jobId, array $data): Job
    {
        $job = Job::findOrFail($jobId);

        $salesTaxData = $data['sales_tax_data'];
        unset($data['sales_tax_data']);

        $job->update($data);
        $job->sales_tax_data = $salesTaxData;
        // $this->updateOrAddJobCompany($jobId);
        $this->updateOrAddCompanyInfo($jobId);
        return $job;
    }

    /**
     * Handle job loads creation/update
     */
    private function handleJobLoads(array $loads, $jobId): void
    {
        // check any load is have
        if (!empty($jobId)) {
            $isHaveLoads = Load::where('job_id', $jobId)->count();
            if ($isHaveLoads > 0) {
                Load::where('job_id', $jobId)->delete();
            }
        }

        // Extract only the required columns for insertion
        $filteredLoads = array_map(fn($load) => [
            'job_id' => $load['job_id'],
            'weight' => $load['weight'],
            'load_cost' => $load['load_cost'],
            'cal_comission' => $load['cal_comission'],
            'trucker_get' => $load['trucker_get'],
            'min_completed_hours' => $load['min_completed_hours'],
            'max_completed_hours' => $load['max_completed_hours']
        ], $loads);

        // Bulk insert the filtered data
        Load::insert($filteredLoads);
    }

    /**
     * Get city ID from coordinates
     */
    private function getCityId(float $lat, float $lng): ?int
    {
        $cityName = $this->getCity($lat, $lng);

        if (!$cityName) {
            return null;
        }

        $cityDetails = City::where('name', 'like', '%' . $cityName . '%')->first();

        return $cityDetails?->id;
    }
    public function publishJob(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $isJob = Job::find($request->job_id);
            if ($isJob && $isJob->is_draft == 1) {
                $isJob->update(['is_draft' => 0]);
                DB::commit();
                return $this->responseJson(true, 200, 'Job published successfully');
            } else {
                return $this->responseJson(false, 200, 'Job not found or already published');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    private function getCity($latitude, $longitude)
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => sprintf('https://api.geoapify.com/v1/geocode/reverse?lat=%s&lon=%s&format=json&apiKey=e7bc0569e63d4703ac145989bbc9efe0', $latitude, $longitude),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($httpCode !== 200) {
            return null;
        }

        // Decode JSON response
        $data = json_decode($response, true);

        // Return city name or null if not found
        return !empty($data['results'][0]['city']) ? $data['results'][0]['city'] : null;
    }
    private function getComissionPercentage($cityId, $truckTypeIds)
    {
        $truckTypeIdsArray = explode(',', $truckTypeIds);
        $percentageDetails = null;

        if ($cityId != null) {
            // First: Attempt to find commission details based on city ID and truck type IDs
            $percentageDetails = JobComission::where('city_id', $cityId)
                ->where(function ($query) use ($truckTypeIdsArray) {
                    foreach ($truckTypeIdsArray as $id) {
                        $query->orWhereRaw('FIND_IN_SET(?, truck_type_ids)', [$id]);
                    }
                })
                ->latest()
                ->first();

            // Second: If not found, check with city ID only (ignore truck types)
            if (!$percentageDetails) {
                $percentageDetails = JobComission::where('city_id', $cityId)
                    ->latest()
                    ->first();
            }

            // Third: If still not found, get default commission (null city and truck types)
            if (!$percentageDetails) {
                $percentageDetails = JobComission::whereNull('city_id')
                    ->whereNull('truck_type_ids')
                    ->first();
            }
        } else {
            // If no city ID provided, get default commission
            $percentageDetails = JobComission::whereNull('city_id')
                ->whereNull('truck_type_ids')
                ->first();
        }

        return $percentageDetails;
    }

    private function updateOrAddJobCompany($jobId)
    {
        $isJob = Job::find($jobId);
        // check if the data are updated basis on that job id
        if ($isJob) {
            PastJobCompany::updateOrCreate(
                [
                    'user_id' => auth()->user()->id
                ],
                [
                    'job_id' => $jobId,
                    'pickup_company_name' => $isJob->pickup_location_company,
                    'dropoff_company_name' => $isJob->drop_off_location_company,
                    'pickup_point_contract' => $isJob->pickup_contact,
                    'dropoff_point_contract' => $isJob->drop_off_contact,
                    'pickup_point_email' => $isJob->pickup_location_email,
                    'dropoff_point_email' => $isJob->drop_off_location_email,
                    'pickup_point_phone' => $isJob->pickup_location_contact_no,
                    'dropoff_point_phone' => $isJob->drop_off_location_contact_no
                ]
            );
        }
    }
    private function updateOrAddCompanyInfo($jobId)
    {
        $isJob = Job::find($jobId);
        // check if the data are updated basis on that job id
        if ($isJob) {
            CompanyInfo::updateOrCreate(
                [
                    'title' => $isJob->pickup_location_company
                ],
                [
                    'job_id' => $jobId,
                    'user_id' => $isJob->user_id,
                    'point_of_contact' => $isJob->pickup_contact,
                    'email' => $isJob->pickup_location_email,
                    'contact_no' => $isJob->pickup_location_contact_no,
                    'type' => 'pickup'
                ]
            );
            CompanyInfo::updateOrCreate(
                [
                    'title' => $isJob->drop_off_location_company
                ],
                [
                    'job_id' => $jobId,
                    'user_id' => $isJob->user_id,
                    'point_of_contact' => $isJob->drop_off_contact,
                    'email' => $isJob->drop_off_location_email,
                    'contact_no' => $isJob->drop_off_location_contact_no,
                    'type' => 'dropoff'
                ]
            );
        }
    }
    public function myJobsOld(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:1,2,3,4,5,6',         // 1: new/ongoing 2: accepted, 3:completed/closed 4:past, 5: cancelled 6: save/draft
            'currentDateTime' => 'required|date_format:Y-m-d H:i:s',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            // Retrieve start_date and end_date from the request
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $currentDateTime = $request->currentDateTime;

            $addedEmployees = User::where('added_by', auth()->user()->id)->pluck('id')->toArray();
            $jobs = Job::where(function ($q) {
                $q->where(['user_id' => auth()->user()->id]);
            });
            if (auth()->user()->added_by != null) {
                $jobs->orWhere('user_id', auth()->user()->added_by);
            }
            if (!empty($addedEmployees)) {
                $jobs->orWhereIn('user_id', $addedEmployees);
            }
            if ($startDate) {
                $jobs->whereDate('pickup_date_time', '>=', $startDate);
            }

            if ($endDate) {
                $jobs->whereDate('delivery_date_time', '<=', $endDate);
            }
            // new job
            if ($request->status == 1) {
                $jobs = $jobs->where(['status' => 1, 'is_draft' => 0])->where(function ($q) use ($request) {
                    $q->whereDate('delivery_date_time', '>=', $request->currentDateTime)->orWhereHas('jobLoad', function ($query) {
                        $query->whereIn('status', [1, 2, 3]);
                    });
                });
            } else if ($request->status == 2) {   // accepted jobs
                $jobs = $jobs->where(['is_draft' => 0])->where('status', 2)->where(function ($q) use ($request) {
                    $q->whereDate('delivery_date_time', '>=', $request->currentDateTime)->orWhereHas('jobLoad', function ($query) {
                        $query->whereIn('status', [1, 2, 3]);
                    });
                });
            } else if ($request->status == 3) {    // completed jobs and closed jobs
                $jobs = $jobs->whereIn('status', [3, 6])->where('is_draft', 0);
            } else if ($request->status == 4) {    // past jobs
                $jobs = $jobs->where(function ($q) use ($request) {
                    $q->whereDate('delivery_date_time', '<', $request->currentDateTime)->WhereHas('jobLoad', function ($query) {
                        $query->whereNotIn('status', [1, 2, 3]);
                    });
                });
            } else if ($request->status == 5) {   // cancelled job
                $jobs = $jobs->where('status', 5);
            } else if ($request->status == 6) {   // save/ draft job
                $jobs = $jobs->where(['status' => 1, 'is_draft' => 1]);
            } else {
                $jobs = $jobs->where('status', 4);
            }
            // return $jobs->get();
            if ($request->has('page')) {
                $jobs = $jobs->latest()->paginate(10)->appends($request->except('page'));
                return new JobResourceCollection($jobs);
            } else {
                // If no pagination, just get the latest jobs without pagination
                // $jobs = $jobs->latest()->get();
                dd($jobs->toRawSql());
                return $this->responseJson(true, 200, 'jobs found', JobResource::collection($jobs));
            }
        } catch (\Exception $e) {
            // Rollback the transaction on error
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function myJobs(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:1,2,3,4,5,6',
            'currentDateTime' => 'required|date_format:Y-m-d H:i:s',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $currentDateTime = $request->currentDateTime;

            // get all sub employees added by current user
            $addedEmployees = User::where('added_by', auth()->user()->id)->pluck('id')->toArray();

            // $jobs = Job::where(function ($q) use ($addedEmployees) {
            //     // condition by current user id
            //     $q->where('user_id', auth()->user()->id);

            //     // condition by added_by
            //     if (auth()->user()->added_by != null) {
            //         $q->orWhere('user_id', auth()->user()->added_by);
            //     }
            //     // condition by added employees
            //     if (!empty($addedEmployees)) {
            //         $q->orWhereIn('user_id', $addedEmployees);
            //     }
            // });

            $jobs = Job::whereIn('user_id', getSubContractorWithMainContractorIds(auth()->user()->id));

            // Apply status filters 
            switch ($request->status) {
                case 1: // New/Ongoing jobs
                    $jobs->where(['status' => 1, 'is_draft' => 0])
                        ->where(function ($q) use ($currentDateTime) {
                            $q->where('delivery_date_time', '>=', $currentDateTime)
                                ->orWhereHas('jobLoad', function ($query) {
                                    $query->whereIn('status', [1, 2, 3]);
                                });
                        });
                    break;

                case 2: // Accepted jobs
                    $jobs->where('is_draft', 0)
                        ->where('status', 2)
                        ->where(function ($q) use ($currentDateTime) {
                            $q->where('delivery_date_time', '>=', $currentDateTime)
                                ->orWhereHas('jobLoad', function ($query) {
                                    $query->whereIn('status', [1, 2, 3]);
                                });
                        });
                    break;

                case 3: // Completed jobs and closed jobs
                    $jobs->whereIn('status', [3, 6])
                        ->where('is_draft', 0);
                    break;

                case 4: // Past jobs
                    $jobs->where(function ($q) use ($currentDateTime) {
                        $q->where('delivery_date_time', '<', $currentDateTime)
                            ->whereHas('jobLoad', function ($query) {
                                $query->whereNotIn('status', [1, 2, 3]);
                            });
                    });
                    break;

                case 5: // Cancelled jobs
                    $jobs->where('status', 5);
                    break;

                case 6: // Save/Draft jobs
                    $jobs->where(['status' => 1, 'is_draft' => 1]);
                    break;

                default:
                    $jobs->where('status', 4);
                    break;
            }

            // Apply date range filters AFTER status conditions
            if ($startDate) {
                $jobs->where('pickup_date_time', '>=', $startDate);
            }

            if ($endDate) {
                $jobs->where('delivery_date_time', '<=', $endDate);
            }

            // Return results
            if ($request->has('page')) {
                $jobs = $jobs->latest()->paginate(10)->appends($request->except('page'));
                return new JobResourceCollection($jobs);
            } else {
                $jobs = $jobs->latest()->get();
                return $this->responseJson(true, 200, 'jobs found', JobResource::collection($jobs));
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function jobDetails($job_id = null)
    {
        // Validate the job_id
        if (is_null($job_id)) {
            return $this->responseJson(false, 200, 'Job ID is required.', (object)[]);
        }

        $validator = Validator::make(['job_id' => $job_id], [
            'job_id' => 'required|exists:jobs,id',
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return $this->responseJson(false, 400, $validator->errors()->first(), (object)[]);
        }

        try {
            // Find the job by job_id
            $isJob = Job::find($job_id);
            if ($isJob) {
                $jobDetails = new JobResource($isJob);
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), $jobDetails);
            }

            return $this->responseJson(false, 404, config('services.responseMessages.get.fail'), (object)[]);
        } catch (\Exception $e) {
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function fetchJobDetails(Request $request)
    {
        try {
            // Find the job by job_id
            $isJob = Job::where($request->fieldName, $request->fieldValue)->first();
            if ($isJob) {
                $jobDetails = new JobResource($isJob);
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), $jobDetails);
            }

            return $this->responseJson(false, 404, config('services.responseMessages.get.fail'), (object)[]);
        } catch (\Exception $e) {
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function updateJob(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'job_id'                        => 'required|exists:jobs,id',
            'source'                        => 'required',
            'destination'                   => 'required',
            'material_id'                   => 'required|exists:materials,id',
            'truck_type_ids'                => 'required',
            'equipment_id'                  => 'sometimes|nullable',
            'pickup_date_time'              => 'required|date_format:Y-m-d H:i:s',
            'delivery_date_time'            => 'required|date_format:Y-m-d H:i:s',
            'total_mileage'                 => 'required',
            'pickup_location_company'       => 'required|string|max:255',
            'pickup_location_contact_no'    => 'required',
            'pickup_location_email'         => 'required|email',
            'pickup_contact'                => 'required',
            'drop_off_location_company'     => 'required|string|max:255',
            'drop_off_location_contact_no'  => 'required',
            'drop_off_location_email'       => 'required|email',
            'drop_off_contact'              => 'required',
            'job_estimate_price'            => 'required',
            'source_lat'                    => 'required',
            'source_lng'                    => 'required',
            'delivery_lat'                  => 'required',
            'delivery_lng'                  => 'required',
            'order_no'                      => 'required',
            'per_unit'                      => 'required',
            'per_unit_price'                => 'required',
            'no_of_trucks'                  => 'required',
            'load_type_id'                  => 'required',
            'load_weight'                   => 'required|array',
            'load_weight.*'                 => 'numeric',
            'load_cost'                     => 'required|array',
            'load_cost.*'                   => 'numeric',
            'is_draft'                      => 'required|in:0,1',
            'is_hourly'                     => 'required|in:0,1'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction();
        try {
            // Find the existing job
            $job = Job::findOrFail($request->job_id);
            // $cityName = $this->getCity($request->source_lat, $request->source_lng);
            $cityName = $this->getCity($request->source_lat, $request->source_lng);
            $cityId = null;
            if ($cityName != null) {
                $cityDetails = City::where('name', 'like', '%' . $cityName . '%')->first();
                if ($cityDetails) {
                    $cityId = $cityDetails->id;
                }
            }
            $salesTax = $this->getComissionPercentage($cityId, $request->truck_type_ids);
            $truckerPercentage = $salesTax->trucker_percentage ?? 90;
            $calPercentage = $salesTax->cal_percentage ?? 10;
            // Update job details
            $job->update([
                'load_type_id' => $request->load_type_id,
                'order_no' => $request->order_no,
                'pickup_location_company' => $request->pickup_location_company,
                'pickup_location_contact_no' => $request->pickup_location_contact_no,
                'pickup_location_email'  => $request->pickup_location_email,
                'pickup_contact' => $request->pickup_contact,
                'drop_off_location_company' => $request->drop_off_location_company,
                'drop_off_location_contact_no' => $request->drop_off_location_contact_no,
                'drop_off_location_email' => $request->drop_off_location_email,
                'drop_off_contact'        => $request->drop_off_contact,
                'source' => $request->source,
                'destination' => $request->destination,
                'pickup_date_time' => $request->pickup_date_time,
                'delivery_date_time' => $request->delivery_date_time,
                'source_lat' => $request->source_lat,
                'source_lng' => $request->source_lng,
                'delivery_lat' => $request->delivery_lat,
                'delivery_lng' => $request->delivery_lng,
                'material_id' => $request->material_id,
                'material_other' => ($request->material_other && $request->material_other != '') ? $request->material_other : null,
                'truck_type_ids' => $request->truck_type_ids,
                'equipment_id' => $request->equipment_id ?? null,
                'equipment_other' => ($request->equipment_other && $request->equipment_other != '') ? $request->equipment_other : null,
                'no_of_trucks' => $request->no_of_trucks,
                'total_mileage' => $request->total_mileage,
                'load_spacing_minutes' => ($request->load_spacing_minutes && $request->load_spacing_minutes != '') ? $request->load_spacing_minutes : null,
                'per_unit' => $request->per_unit,
                'per_unit_price' => $request->per_unit_price,
                'job_estimate_price' => $request->job_estimate_price,
                'notes' => ($request->notes && $request->notes != '') ? $request->notes : null,
                'is_draft' => $request->is_draft,
                'is_hourly' => $request->is_hourly,
                'posted_by' => auth()->user()->id,
                'posted_for' => auth()->user()->id
            ]);

            // Update load weights and costs
            Load::where('job_id', $job->id)->delete(); // Remove existing load entries
            foreach ($request->load_weight as $index => $weight) {
                Load::create([
                    'job_id' => $job->id,
                    'weight' => $weight,
                    'load_cost' => isset($request->load_cost[$index]) ? (float)$request->load_cost[$index] : 0, // Default to 0 if no corresponding cost
                    'cal_comission' => (isset($request->load_cost[$index]) && (float)$request->load_cost[$index] > 0)
                        ? (float)$request->load_cost[$index] / $calPercentage
                        : 0,
                    'trucker_get' => (isset($request->load_cost[$index]) && (float)$request->load_cost[$index] > 0)
                        ? ((float)$request->load_cost[$index] - ((float)$request->load_cost[$index] * ((100 - $truckerPercentage) / 100)))
                        : 0,
                    'min_completed_hours' => $request->min_completed_hours,
                    'max_completed_hours' => $request->max_completed_hours
                ]);
            }
            $title = "Job Updated";
            $message = "You updated your job with id " . $job->unique_id;
            //$this->notificationToContracter(auth()->user()->id, $title, $message, $job->unique_id);
            DB::commit();
            return $this->responseJson(true, 200, 'Job updated Successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    private function getLocation($latitude, $longitude, $distance = 1)
    {

        $jobsWithinDistance = City::select('*')->selectRaw(
            '(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance',
            [$latitude, $longitude, $latitude]
        )
            ->having('distance', '<=', $distance)->toRawSql();

        dd($jobsWithinDistance);
    }
    public function getNearestTruckers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'latitude'     => 'required',
            'longitude'    => 'required',
            'job_id'       => 'required',
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $jobDetails = Job::find($request->job_id);
            if ($jobDetails) {
                $jobSourceLatitude = $jobDetails->source_lat;
                $jobSourceLongitude = $jobDetails->source_lng;
                $truckTypes = getTruckTypeIds($jobDetails->truck_type_ids);
                $distance =  $request->radius ?: config('constants.DEFAULT_DISTANCE_BETWEEN_USER_AND_JOBS');
                $truckers = $this->getUsersWithinDistanceAndTruckType($jobSourceLatitude, $jobSourceLongitude, $distance, $truckTypes);
                if ($truckers) {
                    return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), AuthResource::collection($truckers));
                }
                return $this->responseJson(false, 200, config('services.responseMessages.get.fail'));
            }
        } catch (\Exception $e) {
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function getUsersWithinDistanceAndTruckType($latitude, $longitude, $distance, $truckTypes)
    {
        // dd($latitude, $longitude, $distance);
        // Define the radius of the Earth in kilometers
        $earthRadius = 6371;

        // Calculate the angular distance in radians
        $angularDistance = $distance / $earthRadius;

        // Convert latitude and longitude from degrees to radians
        $latitudeRadians = deg2rad($latitude);
        $longitudeRadians = deg2rad($longitude);

        // Calculate minimum and maximum latitude and longitude
        $minLatitude = $latitudeRadians - $angularDistance;
        $maxLatitude = $latitudeRadians + $angularDistance;

        $minLongitude = $longitudeRadians - $angularDistance;
        $maxLongitude = $longitudeRadians + $angularDistance;

        // Perform the query
        $UsersWithinDistance = User::select('*')
            ->selectRaw(
                '(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance',
                [$latitude, $longitude, $latitude]
            )
            ->whereHas('roles', function ($q) {
                $q->where('id', 4);
            })
            ->whereHas('truckDetails', function ($query) use ($truckTypes) {
                $query->whereIn('truck_type_id', $truckTypes);
            })
            ->where('is_approve', 1)
            ->where('is_logged_in', 1)
            ->having('distance', '<=', $distance)->get();
        if (!empty($UsersWithinDistance)) {
            return $UsersWithinDistance;
        }
        return [];
    }
    public function showLoadCompletionRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        try {

            // $load = Load::find($request->load_id)->whereHas('job', function ($query) use ($request) {
            //     $query->where(['id' => $request->job_id])->whereIn('status', [1, 2]);
            // })->where('status', 3)->first();
            $load = Load::find($request->load_id);
            if ($load) {
                return $this->responseJson(true, 200, 'Load completion request found', new ShowLoadActivityResource($load));
            }
            return $this->responseJson(false, 200, 'Load not found', (object)[]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function acceptOrRejectLoadConfirmationRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'receiver_name' => 'required|string|min:2',
            'contractor_status' => 'required|in:1,2', // 1 => accept, 2 => reject
            'isnetweightflag' => 'required|in:0,1', // 0 => not correct, 1 => correct
            // 'correct_net_weight' => 'required_if:isnetweightflag,0|min:1|max:30',
            'signature'          => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'notes'              => 'nullable|string|max:255'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            if (isset($request->correct_net_weight) && $request->correct_net_weight < 1) {
                return $this->responseJson(false, 200, 'Net weight minimum must be 1', (object)[]);
            } else if (isset($request->correct_net_weight) && $request->correct_net_weight > 28) {
                return $this->responseJson(false, 200, 'maximum net weight you put 28', (object)[]);
            }
            if (!empty($request->signature)) {
                $image = $request->signature;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_SIGNATURE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
            }
            $isJob = Job::find($request->job_id);
            // get load details and check also its available for confirmation
            $loadDetails = Load::where(['id' => $request->load_id, 'job_id' => $request->job_id, 'status' => 3])->first();
            if (!$loadDetails) {
                return $this->responseJson(false, 200, 'Load is not completed by trucker', (object)[]);
            }
            // check the correct net weight
            $correctNetWeight = $request->correct_net_weight != null ? (float)$request->correct_net_weight : $loadDetails->trucker_taken_weight;
            if ($correctNetWeight != $loadDetails->weight) {
                $updateLoad = $this->calculateAndUpdateLoad($request->job_id, $request->load_id, $correctNetWeight);
            }
            $totalLoadCost =
                $updateJob = $isJob->update([
                    'job_estimate_price' => $this->totalLoadCost($request->job_id),
                    'per_unit' => $this->totalLoadWeight($request->job_id)
                ]);
            // genrate invoice
            $isInvoiceGenerated = $this->invoiceGenerate($request->job_id, $request->load_id);
            $updateContractorApproval = JobConfigureMap::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'driver_status' => 1])->update([
                'contractor_acceptance' => $request->contractor_status,
                'receiver_name' => $request->receiver_name,
                'isnetweightflag' => $request->isnetweightflag,
                'signature' => $isFileUploaded ? $fileName : null,
                'final_receipt' => $isInvoiceGenerated ?? null,
                'notes' => $request->notes,
                'invoice' => $isInvoiceGenerated ?? null
            ]);
            // update the load status
            $loadDetails->update(['status' => 4]);
            if ($updateContractorApproval) {
                $oneLoadCostForDriver = $loadDetails->trucker_get / $correctNetWeight;
                $driverPayAmount = $correctNetWeight * $oneLoadCostForDriver;
                // store the driver earning
                $remarks = 'Payment for completed one load of Job ID ' . $isJob->unique_id;
                $isLoad = Load::find($request->load_id);
                $this->addEarning($isLoad->user_id, $request->job_id, $request->load_id, $isLoad->trucker_get, 1, $remarks);
                // Check if all rows with the same job_id have a status of 4
                $isAllLoadsAreCompleted = Load::where('job_id', $request->job_id)->get()->every(function ($load) {
                    return $load->status == 4;
                });
                if ($isAllLoadsAreCompleted) {
                    // Update the main job status to 3 if all loads are completed
                    Job::where('id', $request->job_id)->update(['status' => 3]);
                }
                $loadIndex = calculateLoadIndex($request->job_id, $request->load_id);
                // send push notification to Trucker
                $title = 'Load Delivered Confirmation';
                $message = $message = 'Your completed load no.' . $loadIndex . ' request has been approved by the contractor with a total of ' . $correctNetWeight . ' tons, associated with Job ID: ' . $isJob->unique_id . '.';
                $this->sendPushToTrucker($loadDetails->user_id, $title, $message, $loadDetails->user?->device_type, $isJob->id, 3);
                $this->notificationToContracter($loadDetails->user_id, $title, $message, $isJob->id);
                $isPaymentDone = $this->initiatePayment($isJob->user_id, getMainContractorId($isJob->user_id));
                // dd($isPaymentDone);
                DB::commit();
                return $this->responseJson(true, 200, 'Load confirmation request updated successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    private function totalLoadCost($jobId)
    {
        $totalLoadCost = Load::where('job_id', $jobId)->sum('load_cost');
        return $totalLoadCost;
    }
    private function totalLoadWeight($jobId)
    {
        $totalLoadWeight = Load::where('job_id', $jobId)->sum('weight');
        return $totalLoadWeight;
    }
    private function calculateAndUpdateLoad($jobId, $loadId, $givenLoadWeight)
    {
        // Fetch the load to be updated
        $load = Load::findOrFail($loadId);
        // Get all loads for the job, ordered by ID descending
        $allLoads = Load::where('job_id', $jobId)->orderBy('id', 'desc')->get();

        // Calculate cost per unit weight
        $loadWeight = $load->weight;
        $oneLoadCost = $load->load_cost / $loadWeight;
        $oneLoadCostForDriver = $load->trucker_get / $loadWeight;
        // Determine if we're adding or removing weight
        if ($givenLoadWeight > $loadWeight) {
            // Handle case where we're adding weight
            $this->handleExcessLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
        } else {
            // Handle case where we're removing weight
            $this->handleReducedLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
        }
    }
    private function getOrCreateNextAvailableLoad($jobId, $excludedLoadId = null, $additionalWeight = 0)
    {
        $maxLoadWeight = 25;

        // Try to find an existing load that can still take more weight
        $query = Load::where('job_id', $jobId)
            ->where('weight', '<', $maxLoadWeight);

        if ($excludedLoadId) {
            $query->where('id', '!=', $excludedLoadId);
        }

        $load = $query->orderBy('id', 'desc')->first();

        if ($load && ($load->weight + $additionalWeight) <= $maxLoadWeight) {
            return $load;
        }

        return null; // No available load found
    }

    private function handleExcessLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver)
    {
        $extraLoad = $givenLoadWeight - $load->weight;

        if ($extraLoad > 0) {
            // Add extra weight to current load first
            $this->updateLoad($load, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);

            $lastLoad = $allLoads->first();

            if ($lastLoad && $lastLoad->id != $load->id) {
                $newWeight = $lastLoad->weight - $extraLoad;

                if ($newWeight > 0 && $newWeight <= 25) {
                    $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
                } elseif ($newWeight > 25) {
                    // Shouldn't happen if subtracting, but safe guard
                    $this->updateLoad($lastLoad, 25, $oneLoadCost, $oneLoadCostForDriver);
                    $remaining = $newWeight - 25;
                    $this->createNewLoad($load->job_id, $remaining, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
                } else {
                    // If new weight goes below 0, delete and reassign
                    $remainingExtra = abs($newWeight);
                    $lastLoad->delete();

                    $nextAvailable = $this->getOrCreateNextAvailableLoad($load->job_id, $load->id, $remainingExtra);

                    if ($nextAvailable) {
                        $this->updateLoad($nextAvailable, $nextAvailable->weight - $remainingExtra, $oneLoadCost, $oneLoadCostForDriver);
                    } else {
                        $this->createNewLoad($load->job_id, $remainingExtra, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
                    }
                }
            }
        }
    }

    private function handleReducedLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver)
    {
        $extraLoad = $load->weight - $givenLoadWeight;

        $this->updateLoad($load, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);

        $lastLoad = $allLoads->first();

        if ($lastLoad && $lastLoad->id != $load->id) {
            $newWeight = $lastLoad->weight + $extraLoad;

            if ($newWeight <= 25) {
                $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
            } else {
                $this->updateLoad($lastLoad, 25, $oneLoadCost, $oneLoadCostForDriver);
                $remaining = $newWeight - 25;
                $this->createNewLoad($load->job_id, $remaining, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
            }
        } else {
            if ($extraLoad <= 25) {
                $this->createNewLoad($load->job_id, $extraLoad, $oneLoadCost, $oneLoadCostForDriver, $load->cal_comission, $load);
            } else {
                $this->createNewLoad($load->job_id, 25, $oneLoadCost, $oneLoadCostForDriver, $load->cal_comission, $load);
                $remaining = $extraLoad - 25;
                $this->createNewLoad($load->job_id, $remaining, $oneLoadCost, $oneLoadCostForDriver, $load->cal_comission, $load);
            }
        }
    }

    private function updateLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver)
    {
        // Calculate the new weight after subtracting the extra load
        $newWeight = max(0, $lastLoad->weight - $extraLoad);
        if ($newWeight > 0) {
            // If there's still weight left, update the load
            $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
        } else {
            // If the load would be emptied, calculate remaining extra load
            $remainingExtraLoad = $extraLoad - $lastLoad->weight;
            // Delete the empty load
            $lastLoad->delete();

            if ($remainingExtraLoad > 0) {
                // If there's still extra load, find the next load up
                $upperLoad = $this->getUpperLoad($lastLoad);
                if ($upperLoad) {
                    // Update the upper load with the remaining extra load
                    $this->updateLoad($upperLoad, $upperLoad->weight - $remainingExtraLoad, $oneLoadCost, $oneLoadCostForDriver);
                }
            }
        }
    }
    private function addToLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver)
    {
        // Calculate the new weight after adding the extra load
        $newWeight = $lastLoad->weight + $extraLoad;
        if ($newWeight < 25) {
            // If the new weight is within limits, update the load
            $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
        } else {
            // If the new weight exceeds 25, cap it and create a new load for the excess
            $this->updateLoad($lastLoad, 25, $oneLoadCost, $oneLoadCostForDriver);
            $excessLoad = $newWeight - 25;
            $this->createNewLoad($lastLoad->job_id, $excessLoad, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
        }
    }
    private function updateLoad($load, $newWeight, $oneLoadCost, $oneLoadCostForDriver)
    {
        $load->update([
            'weight' => $newWeight,
            'load_cost' => $newWeight * $oneLoadCost,
            'cal_comission' => ($newWeight * $oneLoadCost) - ($newWeight * $oneLoadCostForDriver),
            'trucker_get' => $newWeight * $oneLoadCostForDriver,
        ]);
    }
    private function createNewLoad($jobId, $weight, $oneLoadCost, $oneLoadCostForDriver, $calCommission, $load)
    {
        Load::create([
            'job_id' => $jobId,
            'weight' => $weight,
            'load_cost' => $weight * $oneLoadCost,
            'cal_comission' => ($weight * $oneLoadCost) - ($weight * $oneLoadCostForDriver),
            'trucker_get' => $weight * $oneLoadCostForDriver,
            'min_completed_hours' => $load ? $load->min_completed_hours : 0,
            'max_completed_hours' => $load ? $load->max_completed_hours : 0
        ]);
        // update the job status to 1 again
        Job::where('id', $jobId)->update(['status' => 1]);
    }
    private function getUpperLoad($load)
    {
        return Load::where('id', '<', $load->id)
            ->where('job_id', $load->job_id)
            ->orderBy('id', 'DESC')
            ->first();
    }
    // private function calculateAndUpdateLoad($jobId, $loadId, $givenLoadWeight)
    // {
    //     // Fetch the load to be updated
    //     $load = Load::findOrFail($loadId);
    //     // Get all loads for the job, ordered by ID descending
    //     $allLoads = Load::where('job_id', $jobId)->orderBy('id', 'desc')->get();

    //     // Calculate cost per unit weight
    //     $loadWeight = $load->weight;
    //     $oneLoadCost = $load->load_cost / $loadWeight;
    //     $oneLoadCostForDriver = $load->trucker_get / $loadWeight;
    //     // Determine if we're adding or removing weight
    //     if ($givenLoadWeight > $loadWeight) {
    //         // Handle case where we're adding weight
    //         $this->handleExcessLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     } else {
    //         // Handle case where we're removing weight
    //         $this->handleReducedLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     }
    // }
    // private function handleExcessLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver)
    // {
    //     // Calculate the extra weight
    //     $extraLoad = $givenLoadWeight - $load->weight;
    //     // Get the most recent load (which is the first due to descending order)
    //     $lastLoad = $allLoads->first();
    //     // If there's a previous load and it's not the current one
    //     if ($lastLoad && $lastLoad->id != $load->id) {
    //         // Update the previous load to accommodate the extra weight
    //         $this->updateLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver);
    //         // $this->updateLoad($load, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     }

    //     // Update the current load with the new weight
    //     $this->updateLoad($load, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     // $this->updateLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver);
    // }

    // private function handleReducedLoad($load, $allLoads, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver)
    // {
    //     // Calculate the weight being removed
    //     $extraLoad = $load->weight - $givenLoadWeight;
    //     // Update the current load with the reduced weight
    //     $this->updateLoad($load, $givenLoadWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     // Get the most recent load
    //     $lastLoad = $allLoads->first();
    //     // If there's a previous load and it's not the current one
    //     if ($lastLoad && $lastLoad->id != $load->id) {
    //         if ($lastLoad->weight >= 25) {
    //             // If the last load is already at or above 25, create a new load
    //             $this->createNewLoad($load->job_id, $extraLoad, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
    //         } else {
    //             // Otherwise, add the extra weight to the last load
    //             $this->addToLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver);
    //         }
    //     } else {
    //         // If this is the only load, create a new one for the extra weight
    //         $this->createNewLoad($load->job_id, $extraLoad, $oneLoadCost, $oneLoadCostForDriver, $load->cal_comission, $load);
    //     }
    // }
    // private function updateLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver)
    // {
    //     // Calculate the new weight after subtracting the extra load
    //     $newWeight = max(0, $lastLoad->weight - $extraLoad);
    //     if ($newWeight > 0) {
    //         // If there's still weight left, update the load
    //         $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     } else {
    //         // If the load would be emptied, calculate remaining extra load
    //         $remainingExtraLoad = $extraLoad - $lastLoad->weight;
    //         // Delete the empty load
    //         $lastLoad->delete();

    //         if ($remainingExtraLoad > 0) {
    //             // If there's still extra load, find the next load up
    //             $upperLoad = $this->getUpperLoad($lastLoad);
    //             if ($upperLoad) {
    //                 // Update the upper load with the remaining extra load
    //                 $this->updateLoad($upperLoad, $upperLoad->weight - $remainingExtraLoad, $oneLoadCost, $oneLoadCostForDriver);
    //             }
    //         }
    //     }
    // }
    // private function addToLastLoad($lastLoad, $extraLoad, $oneLoadCost, $oneLoadCostForDriver)
    // {
    //     // Calculate the new weight after adding the extra load
    //     $newWeight = $lastLoad->weight + $extraLoad;
    //     if ($newWeight < 25) {
    //         // If the new weight is within limits, update the load
    //         $this->updateLoad($lastLoad, $newWeight, $oneLoadCost, $oneLoadCostForDriver);
    //     } else {
    //         // If the new weight exceeds 25, cap it and create a new load for the excess
    //         $this->updateLoad($lastLoad, 25, $oneLoadCost, $oneLoadCostForDriver);
    //         $excessLoad = $newWeight - 25;
    //         $this->createNewLoad($lastLoad->job_id, $excessLoad, $oneLoadCost, $oneLoadCostForDriver, $lastLoad->cal_comission, $lastLoad);
    //     }
    // }
    // private function updateLoad($load, $newWeight, $oneLoadCost, $oneLoadCostForDriver)
    // {
    //     $load->update([
    //         'weight' => $newWeight,
    //         'load_cost' => $newWeight * $oneLoadCost,
    //         'cal_comission' => ($newWeight * $oneLoadCost) - ($newWeight * $oneLoadCostForDriver),
    //         'trucker_get' => $newWeight * $oneLoadCostForDriver,
    //     ]);
    // }
    // private function createNewLoad($jobId, $weight, $oneLoadCost, $oneLoadCostForDriver, $calCommission, $load)
    // {
    //     Load::create([
    //         'job_id' => $jobId,
    //         'weight' => $weight,
    //         'load_cost' => $weight * $oneLoadCost,
    //         'cal_comission' => ($weight * $oneLoadCost) - ($weight * $oneLoadCostForDriver),
    //         'trucker_get' => $weight * $oneLoadCostForDriver,
    //         'min_completed_hours' => $load ? $load->min_completed_hours : 0,
    //         'max_completed_hours' => $load ? $load->max_completed_hours : 0
    //     ]);
    //     // update the job status to 1 again
    //     Job::where('id', $jobId)->update(['status' => 1]);
    // }
    // private function getUpperLoad($load)
    // {
    //     return Load::where('id', '<', $load->id)
    //         ->where('job_id', $load->job_id)
    //         ->orderBy('id', 'DESC')
    //         ->first();
    // }
    private function invoiceGenerate($jobId, $loadId)
    {
        $detail = Load::where(['job_id' => $jobId, 'id' => $loadId])->first();
        $options = new Options();
        $options->set('isRemoteEnabled', true);
        $dompdf = new Dompdf($options);
        $html = view('invoice.load-completion-invoice', compact('detail'));
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        // Define the file path
        $filename = time() . '.pdf';
        $directoryPath = public_path('storage/invoice');

        if (!is_dir($directoryPath)) {
            // Check if mkdir was successful
            if (!mkdir($directoryPath, 0755, true)) {
                throw new \Exception("Failed to create directory: $directoryPath");
            }
        }

        // Verify directory is writable
        if (!is_writable($directoryPath)) {
            throw new \Exception("Directory is not writable: $directoryPath");
        }

        // Save the PDF to the specified path
        $filePath = $directoryPath . '/' . $filename;
        file_put_contents($filePath, $dompdf->output());

        return $filename;
    }
    public function closeJob(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction();
        try {
            $jobDetails = Job::findOrFail($request->job_id);

            // Get all loads for the specified job, ordered by creation date (or ID if you prefer)
            $loads = Load::where('job_id', $request->job_id)
                ->orderBy('created_at', 'asc')
                ->get();

            if ($loads->isEmpty()) {
                // If there are no loads, update job status to 6
                $jobDetails->update(['status' => 6]);
                DB::commit();
                return $this->responseJson(true, 200, "Job closed successfully. No loads found.");
            }

            // Separate the last load from the rest
            $lastLoad = $loads->pop();

            // Check if any load except the last one has a status of 1, 2, or 3
            $hasPendingLoads = $loads->contains(function ($load) {
                return in_array($load->status, [1, 2, 3]);
            });

            if (!$hasPendingLoads) {
                // If no pending loads (except possibly the last one), update job status to 6
                $jobDetails->update(['status' => 6, 'is_closed' => 1]);
                DB::commit();
                return $this->responseJson(true, 200, "Job closed successfully");
            } else {
                DB::rollBack();
                return $this->responseJson(false, 200, "Some loads are still pending. Cannot close the job.");
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function changeTruckTypes(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'truck_type_ids' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $jobDetails = Job::find($request->job_id);
            // update Truck types
            $updateTruckTypes = $jobDetails->update([
                'truck_type_ids' => $request->truck_type_ids
            ]);
            if ($updateTruckTypes) {
                DB::commit();
                return $this->responseJson(true, 200, "truck type changed");
            }
            return $this->responseJson(false, 200, "truck type not changed");
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function updateLoadAmount(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'amount' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            // check the given amount is less than curerent load acount
            $isLoad = Load::find($request->load_id);
            $loadAmount = $isLoad->load_cost;
            if ($request->amount <= 0) {
                return $this->responseJson(false, 200, 'amount should be greater than 0');
            }
            // get cal comission
            $calPercentage = ($isLoad->cal_comission / $loadAmount) * 100;
            $truckerPercentage = 100 - $calPercentage;
            // update the load amount
            $isUpdateLoadAmount = $isLoad->update([
                'load_cost' => $request->amount,
                'cal_comission' => ($calPercentage * $request->amount) / 100,
                'trucker_get' => (float)$request->amount ? ((float)$request->amount - ((float)$request->amount * $calPercentage / 100)) : 0
            ]);
            if ($isUpdateLoadAmount) {
                $isJob = Job::find($request->job_id);

                // Determine updated amount & direction
                $updatedAmount = abs($request->amount - $loadAmount);
                $isIncreased = $request->amount > $loadAmount;

                // Update the main job amount dynamically
                $updateJobAmount = $isJob->update([
                    'job_estimate_price' => $isJob->job_estimate_price + ($isIncreased ? $updatedAmount : -$updatedAmount)
                ]);

                if ($updateJobAmount) {
                    DB::commit();
                    return $this->responseJson(true, 200, "Price updated for last load");
                }
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function runningJobs(Request $request)
    {
        try {
            $connectedContractors = getSubContractorWithMainContractorIds(auth()->user()->id);
            $runningJobs = Job::whereIn('user_id', $connectedContractors)->whereHas('jobLoad', function ($query) {
                $query->where(['status' => 2])->where('started_on', '!=', null);
            });

            if ($request->has('page')) {
                $runningJobs = $runningJobs->latest()->paginate(10)->appends($request->except('page'));
                return new RunningJobResourceCollection($runningJobs);
            }

            $runningJobs = $runningJobs->latest()->get();
            if ($runningJobs) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), RunningJobResource::collection($runningJobs));
            }
            return $this->responseJson(false, 200, config('services.responseMessages.get.fail'));
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function runningJobLoads(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $runningLoads = Load::where(['job_id' => $request->job_id, 'status' => 2])->where('user_id', '!=', null)->where('started_on', '!=', null)->get();
            if ($runningLoads) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), RunningJobLoadResource::collection($runningLoads));
            }
            return $this->responseJson(false, 200, config('services.responseMessages.get.fail'));
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function isHaveAnyRunningJob()
    {
        try {
            $runningLoads = Job::where(['user_id' => auth()->user()->id])->whereHas('jobLoad', function ($query) {
                $query->where('status', 2)->whereNotNull('started_on');
            })->exists();
            if ($runningLoads) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), $runningLoads);
            }
            return $this->responseJson(false, 200, config('services.responseMessages.get.fail'), false);
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function acceptRejectLoadCancellationRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'is_picked_up' => 'required|in:0,1',    // 0: not picked up 1: picked up
            'is_returned' => 'required|in:0,1'      // 0: not returned, 1: returned
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $isJob = Job::find($request->job_id); // check is trucker requested for cancellation
            $isCancellationRequested = Load::find($request->load_id);
            if ($isCancellationRequested && is_null($isCancellationRequested->cancellation_request_id)) {
                return $this->responseJson(false, 200, 'No cancellation request found');
            }
            // delete from load activity
            $isdeleteFromLoadActivity = $this->deleteFromJobLoadActivity($request->job_id, $request->load_id, $isCancellationRequested->user_id);
            // delete from load activity
            $isdeleteFromJobConfigureMap = $this->deleteFromJobConfigureMap($request->job_id, $request->load_id, $isCancellationRequested->user_id);
            // update in cancel job table
            $lastDataFromCancelJob = $this->updateInCancelJob($request->job_id, $request->load_id, $isCancellationRequested->user_id, $request->is_picked_up, $request->is_returned);
            // make load default
            $isMakeLoadAsDefaultAsPrevious = $this->makeLoadDefault($isCancellationRequested->id);

            if ($isdeleteFromLoadActivity && $isdeleteFromJobConfigureMap && $lastDataFromCancelJob && $isMakeLoadAsDefaultAsPrevious) {
                // send push notification to trucker
                $title = "Load Delivery Cancellation Approved";
                $message = "The contractor has approved your load cancellation request associated with job id " . $isJob->unique_id;
                $this->sendPushToTrucker($isCancellationRequested->user_id, $title, $message, $isJob->id, $isJob->status);
                DB::commit();
                return $this->responseJson(true, 200, 'load delivery cancellation request approved');
            }
            return $this->responseJson(false, 200, config('services.responseMessages.post.fail'));
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function makeLoadDefault($loadId)
    {
        $isLoad = Load::find($loadId);
        if ($isLoad) {
            // if no other load except this on this job then make job status to 1
            $isJob = Job::find($isLoad->job_id);
            $isLoadCount = Load::where('job_id', $isLoad->job_id)->whereNot('id', $loadId)->count();
            if ($isLoadCount == 0) {
                $isJob->update(['status' => 1]);
            }
            return $isLoad->update([
                'user_id' => null,
                'trucker_taken_weight' => null,
                'reached_on' => null,
                'started_on' => null,
                'completed_on' => null,
                'status' => 0,
                'cancellation_request_id' => null,
            ]);
        }
        return false;
    }
    private function deleteFromJobConfigureMap($jobId, $loadId, $userId)
    {
        $isdeleted = JobConfigureMap::where(['user_id' => $userId, 'job_id' => $jobId, 'load_id' => $loadId])->delete();
        if ($isdeleted) {
            return true;
        }
        return false;
    }
    private function deleteFromJobLoadActivity($jobId, $loadId, $userId)
    {
        $isdeleted = LoadActivity::where(['user_id' => $userId, 'job_id' => $jobId, 'load_id' => $loadId])->delete();
        if ($isdeleted) {
            return true;
        }
        return false;
    }
    private function updateInCancelJob($jobId, $loadId, $userId, $isPickedUp, $isReturned)
    {
        // dd($jobId, $loadId, $userId, $isPickedUp, $isReturned);
        if ($isPickedUp == 1 && $isReturned == 0) {
            $isLoad = Load::find($loadId);
            $oneLoadCostForDriver = $isLoad->trucker_get / $isLoad->weight;
            $driverPayAmount = $isLoad->trucker_taken_weight * $oneLoadCostForDriver;
            $remarks = 'For cancelled and not returned a load of job ID ' . $isLoad->job?->unique_id;
            $this->addEarning($userId, $jobId, $loadId, $driverPayAmount, 2, $remarks);
        }
        $lastCancelJobRow = CancelJob::where(['job_id' => $jobId, 'load_id' => $loadId, 'trucker_id' => $userId])->latest()->first();
        $isupdated = $lastCancelJobRow->update([
            'is_picked_up' => $isPickedUp,
            'is_returned' => $isReturned
        ]);
        if ($isupdated) {
            return $lastCancelJobRow;
        }
        return false;
    }
    private function storeInContracterCancellation($jobId, $loadId, $userId)
    {
        // dd($jobId, $loadId, $userId, $isPickedUp, $isReturned);
        $lastCancelJobRow = CancelJob::create([
            'job_id' => $jobId,
            'load_id' => $loadId,
            'trucker_id' => $userId
        ]);
        if ($lastCancelJobRow) {
            return true;
        }
        return false;
    }
    public function getRunningJobDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            $runningLoads = Load::where(['id' => $request->load_id, 'job_id' => $request->job_id, 'status' => 2])->where('user_id', '!=', null)->where('started_on', '!=', null)->first();
            if ($runningLoads) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), new RunningJobLoadResource($runningLoads));
            }
            return $this->responseJson(false, 200, "This load delivery is already done", (object)[]);
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function notifiedNearestTruckers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'user_id' => 'required|exists:users,id',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isUser = User::find($request->user_id);
            if (!is_null($isUser->fcm_token)) {
                $fcmToken = $isUser->fcm_token;
                $title = 'New Job';
                $body = 'A new job has been posted in your area...go and look ahead';
                $deviceType = $isUser->device_type;
                $jobId = (string)$request->job_id;
                $jobStatus = (string)$this->getJobStatus($jobId);
                $isNotificationSent = $this->sendNotification($fcmToken, $title, $body, $body, $deviceType, $jobId, $jobStatus);
                if ($isNotificationSent) {
                    return $this->responseJson(true, 200, 'notification sent');
                }
                return $this->responseJson(false, 200, 'notification not sent');
            } else {
                return $this->responseJson(false, 200, 'notification not sent');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function cancelWholeJob(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            // check the job is already completed or not
            $isJob = Job::find($request->job_id);
            if ($isJob->status == 3) {
                return $this->responseJson(false, 200, 'Job is already completed');
            }
            // check any associated load is already delivered or not
            $isLoad = Load::where(['job_id' => $request->job_id, 'status' => 3])->first();
            if ($isLoad) {
                return $this->responseJson(false, 200, 'one load of this job is wating in review stage');
            }
            // cancel the other loads which are not taken by any trucker i.e status 0,1,2
            $loads = Load::where(['job_id' => $request->job_id])->whereIn('status', [0, 1, 2])->whereNull('started_on')->get();
            $loadAssociatedTruckers = [];
            if ($loads) {
                foreach ($loads as $load) {
                    // if($load->user_id != null && !in_array($loadAssociatedTruckers, $load->user_id)){
                    //     array_push($loadAssociatedTruckers, $load->user_id); 
                    // }
                    $truckerGet = 0;
                    if ($load->status != 0) {
                        $this->storeInContracterCancellation($request->job_id, $load->id, $load->user_id);
                        // delete from job Con figure map
                        $this->deleteFromJobConfigureMap($request->job_id, $load->id, $load->user_id);
                        // delete from job load activities table
                        $this->deleteFromJobLoadActivity($request->job_id, $load->id, $load->user_id);
                        // update the load table
                        if ($load->status == 2 && $load->started_on != null) {
                            $truckerTakenWeight = $load->trucker_taken_weight;
                            $truckerGet = $load->trucker_get;
                            $this->earningAfterCancel($request->job_id, $load->id, $truckerTakenWeight, $truckerGet);
                        }
                        Load::find($load->id)->update([
                            'user_id' => null,
                            'trucker_taken_weight' => null,
                            'reached_on' => null,
                            'started_on' => null,
                            'status' => 0,
                        ]);
                    }
                    // send push notification to those truckers
                    // $title = 'Job is Cancelled';
                    // $message = 'load of ' . calculateLoadIndex($request->job_id, $load->id) . ' associated with job ID ' . $isJob->unique_id . ' is cancelled';
                    // $this->sendPushToTrucker($load->user_id, $title, $message, $isJob->id, $isJob->status);
                }
            }
            // cancel the job
            $isCancelJob = $isJob->update([
                'status' => 5
            ]);


            if ($isCancelJob) {
                DB::commit();
                return $this->responseJson(true, 200, 'Job is Cancelled');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
        }
    }
    public function changeJobLocation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'source' => 'required',
            'destination' => 'required',
            'source_lat' => 'required',
            'source_lng' => 'required',
            'destination_lat' => 'required',
            'destination_lng' => 'required',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $isJob = Job::find($request->job_id);
            // check any load is running for this job or not
            $isRunningLoad = Load::where('job_id', $request->job_id)->get()->every(function ($load) {
                return $load->status == 2 && $load->started_on != null;
            });
            if ($isRunningLoad) {
                return $this->responseJson(false, 200, 'associated loads of this job is running. cannot change job location');
            }
            // if not running then update the job location
            $updateJob = $isJob->update([
                'source' => $request->source,
                'destination' => $request->destination,
                'source_lat' => $request->source_lat,
                'source_lng' => $request->source_lng,
                'delivery_lat' => $request->destination_lat,
                'delivery_lng' => $request->destination_lng,
            ]);
            if ($updateJob) {
                DB::commit();
                return $this->responseJson(true, 200, 'Job location changed successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function earningAfterCancel($jobId, $loadId, $truckerTakenWeight, $truckerGet)
    {
        $isLoad = Load::find($loadId);
        $loadWeight = $isLoad->weight;
        $oneLoadCostForDriver = $truckerGet / $loadWeight;
        $driverPayAmount = $truckerTakenWeight * $oneLoadCostForDriver;
        $addEarning = Earning::create([
            'user_id' => $isLoad->user_id,
            'job_id' => $jobId,
            'load_id' => $loadId,
            'amount' => $driverPayAmount,
            'type' => 1,
            'remarks' => 'for cancelling the whole Job ' . $isLoad->job?->unique_id,
            'is_paid' => 0
        ]);
        if ($addEarning) {
            return true;
        }
        return false;
    }
    public function isAnyLoadIsverificiationOrCancellationStage(Request $request)
    {
        try {
            $connectedContractors = getSubContractorWithMainContractorIds(auth()->user()->id);
            $isRunningJob = Job::where('user_id', $connectedContractors)->whereHas('jobLoad', function ($query) {
                $query->where(function ($gq) {
                    $gq->where('status', 3)->orWhere(function ($q) {
                        $q->where('status', '!=', 3)->whereNotNull('cancellation_request_id');
                    });
                });
            });
            $isRunningJob = $isRunningJob->latest()->paginate(10)->appends($request->except('page'));
            return new PendingActionResourceCollection($isRunningJob);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function discardLoad(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'load_id' => 'required|exists:loads,id',
            'job_id' => 'required|exists:jobs,id',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $isLoad = Load::find($request->load_id);
            // check any driver already taken this load or not
            if ($isLoad->status > 0 && $isLoad->status < 3) {
                return $this->responseJson(false, 200, 'this load is already taken by trucker');
            }
            // check any driver already taken this load or not
            if ($isLoad->status == 3) {
                return $this->responseJson(false, 200, 'this load is already completed by trucker');
            }
            if ($isLoad->weight > 10) {
                return $this->responseJson(false, 200, 'this load weight is greater than 10');
            }
            // discard the load
            $isDiscardLoad = $isLoad->update([
                'is_discarded' => 1,
                // 'status' => 5
            ]);
            if ($isDiscardLoad) {
                // deduct the load amount from main job
                Job::find($request->job_id)->decrement(
                    'job_estimate_price',
                    $isLoad->load_cost
                );
                // update job status
                Job::find($request->job_id)->update([
                    'status' => 3
                ]);
                DB::commit();
                return $this->responseJson(true, 200, 'Load Discarded Successfully');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function calculateLoadAndLoadPrice(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id'                    => 'required',
            'source_lat'                => 'required',
            'source_lng'                => 'required',
            'truck_type_ids'            => 'required',
            'load_spacing_in_minutes'   => 'required',
            'max_load_capacity'         => 'required|numeric',
            'per_unit'                  => 'required|numeric',
            'price_per_unit'            => 'required|numeric',
            // 'load_type'                 => 'required|in:tons,loads,cubic_yard',
            'load_type'                 => 'required',
            'min_hours'                 => 'nullable',
            'max_hours'                 => 'nullable',
            'pickup_date_time'          => 'required',
            'delivery_date_time'        => 'required',
            'is_hourly'                 => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            // $cityName = $this->getCity($request->source_lat, $request->source_lng);
            // $cityId = null;
            // if ($cityName != null) {
            //     $cityDetails = City::where('name', 'like', '%' . $cityName . '%')->first();
            //     if ($cityDetails) {
            //         $cityId = $cityDetails->id;
            //     }
            // }
            logger("================================================================");
            logger("soure_lat " . $request->source_lat . "source_lng " . $request->source_lng);
            $getCity = $this->findCity($request->source_lat, $request->source_lng);
            logger("getCity" . "" . $getCity);
            $data = $getCity->getData(); // This is stdClass
            if (isset($data->city_data) && isset($data->city_data->city_id)) {
                logger("================================================================");
                $cityId = $data->city_data->city_id;
                logger("city_id" . $cityId);
                // logger("city_id", $cityId);
                $salesTax = $this->getComissionPercentage($cityId, $request->truck_type_ids);
                logger("sales_tax" . $salesTax);
                logger("================================================================");
            } else {
                $cityId = null;
                $salesTax = null;
            }
            // $salesTax = $this->getComissionPercentage($cityId, $request->truck_type_ids);
            $truckerPercentage = $salesTax->trucker_percentage ?? 90;
            $calPercentage = $salesTax->cal_percentage ?? 10;
            $loadsData = [];  // array to store the load data
            $noOfLoads = 0;

            if ($request->load_type == "tons") {
                // Generate loads based on per unit
                $noOfLoads = floor($request->per_unit / $request->max_load_capacity);
                $fractionPoint = fmod($request->per_unit, $request->max_load_capacity);

                for ($i = 0; $i < $noOfLoads; $i++) {
                    $loadsData[] = $this->calculateAmount(
                        $request->pickup_date_time,
                        $request->delivery_date_time,
                        $request->load_type,
                        $request->max_load_capacity,
                        $request->load_spacing_in_minutes,
                        $request->price_per_unit,
                        $request->job_id,
                        $truckerPercentage,
                        $calPercentage,
                        $request->is_hourly,
                        $request->min_hours,
                        $request->max_hours
                    );
                }

                // Handle the fractional load separately if needed
                if ($fractionPoint > 0) {
                    $loadsData[] = $this->calculateAmount(
                        $request->pickup_date_time,
                        $request->delivery_date_time,
                        $request->load_type,
                        $fractionPoint,
                        $request->load_spacing_in_minutes,
                        $request->price_per_unit,
                        $request->job_id,
                        $truckerPercentage,
                        $calPercentage,
                        $request->is_hourly,
                        $request->min_hours,
                        $request->max_hours
                    );
                }
            } else if ($request->load_type == "loads") {
                $noOfLoads = $request->per_unit;
                for ($i = 0; $i < $noOfLoads; $i++) {
                    $loadsData[] = $this->calculateAmount(
                        $request->pickup_date_time,
                        $request->delivery_date_time,
                        $request->load_type,
                        $request->max_load_capacity,
                        $request->load_spacing_in_minutes,
                        $request->price_per_unit,
                        $request->job_id,
                        $truckerPercentage,
                        $calPercentage,
                        $request->is_hourly,
                        $request->min_hours,
                        $request->max_hours
                    );
                }
            } else {
                // Cubic yard calculation with proportional distribution
                $convertingValue = 1.4;
                $qubicYardToTons = $request->per_unit * $convertingValue;  // Convert to tons
                $noOfLoads = floor($qubicYardToTons / $request->max_load_capacity);
                $fractionPoint = fmod($qubicYardToTons, $request->max_load_capacity);

                // Calculate expected total
                $expectedTotal = $request->per_unit * $request->price_per_unit;
                $totalWeight = $qubicYardToTons;
                $distributedTotal = 0;

                // Calculate full loads
                for ($i = 0; $i < $noOfLoads; $i++) {
                    $weight = $request->max_load_capacity;

                    // For the last load (when no fractional load), adjust to match exact total
                    if ($i == $noOfLoads - 1 && $fractionPoint == 0) {
                        $loadCost = $expectedTotal - $distributedTotal;
                    } else {
                        // Proportional cost based on weight
                        $loadCost = ($weight / $totalWeight) * $expectedTotal;
                        $distributedTotal += $loadCost;
                    }

                    $loadsData[] = $this->calculateAmountWithFixedCost(
                        $request->pickup_date_time,
                        $request->delivery_date_time,
                        $request->load_type,
                        $weight,
                        $request->load_spacing_in_minutes,
                        $loadCost, // Pass the calculated cost directly
                        $request->job_id,
                        $truckerPercentage,
                        $calPercentage,
                        $request->is_hourly,
                        $request->min_hours,
                        $request->max_hours
                    );
                }

                // Handle fractional load
                if ($fractionPoint > 0) {
                    $weight = $fractionPoint;
                    $loadCost = $expectedTotal - $distributedTotal; // Remaining amount

                    $loadsData[] = $this->calculateAmountWithFixedCost(
                        $request->pickup_date_time,
                        $request->delivery_date_time,
                        $request->load_type,
                        $weight,
                        $request->load_spacing_in_minutes,
                        $loadCost, // Pass the calculated cost directly
                        $request->job_id,
                        $truckerPercentage,
                        $calPercentage,
                        $request->is_hourly,
                        $request->min_hours,
                        $request->max_hours
                    );
                }
            }

            return $this->responseJson(true, 200, 'loads generated', $loadsData);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function calculateAmount($pickupDateTime, $dropOffDateTime, $loadType, $weight, $loadSpeacing, $pricePerLoad, $jobId, $truckerPercentage, $calPercentage, $isHourly, $minCompletedHours, $maxCompletedHours)
    {
        // Calculate base price
        $price = $loadType == 'loads' ? $pricePerLoad : $weight * $pricePerLoad;

        // Format weight and price to 2 decimal places
        $formattedWeight = number_format($weight, 2, '.', '');
        $formattedPrice = number_format($price, 2, '.', '');

        // Calculate commission and trucker amount using ORIGINAL price (not formatted string)
        $calCommission = 0;
        $truckerAmount = 0;

        if ($price && $price > 0) {
            // Calculate CAL commission using original $price variable
            $calCommission = number_format(($price * $calPercentage) / 100, 2, '.', '');

            // Calculate trucker amount using original $price variable
            $truckerAmount = number_format(($price * $truckerPercentage) / 100, 2, '.', '');
        }

        return [
            'job_id' => $jobId,
            'weight' => $formattedWeight,
            'load_cost' => $formattedPrice,
            'cal_comission' => $calCommission,
            'trucker_get' => $truckerAmount,
            'pickup_date_time' => $pickupDateTime,
            'delivery_date_time' => $dropOffDateTime,
            'load_spacing' => $loadSpeacing,
            'is_hourly' => $isHourly,
            'min_completed_hours' => $minCompletedHours,
            'max_completed_hours' => $maxCompletedHours
        ];
    }

    private function calculateAmountWithFixedCost($pickupDateTime, $dropOffDateTime, $loadType, $weight, $loadSpeacing, $loadCost, $jobId, $truckerPercentage, $calPercentage, $isHourly, $minCompletedHours, $maxCompletedHours)
    {
        // Format weight and load cost to 2 decimal places
        $formattedWeight = number_format($weight, 2, '.', '');
        $formattedPrice = number_format($loadCost, 2, '.', '');

        // Calculate commission and trucker amount using ORIGINAL loadCost (not formatted string)
        $calCommission = 0;
        $truckerAmount = 0;

        if ($loadCost && $loadCost > 0) {
            // Calculate CAL commission using original $loadCost variable
            $calCommission = number_format(($loadCost * $calPercentage) / 100, 2, '.', '');

            // Calculate trucker amount using original $loadCost variable
            $truckerAmount = number_format(($loadCost * $truckerPercentage) / 100, 2, '.', '');
        }

        return [
            'job_id' => $jobId,
            'weight' => $formattedWeight,
            'load_cost' => $formattedPrice,
            'cal_comission' => $calCommission,
            'trucker_get' => $truckerAmount,
            'pickup_date_time' => $pickupDateTime,
            'delivery_date_time' => $dropOffDateTime,
            'load_spacing' => $loadSpeacing,
            'is_hourly' => $isHourly,
            'min_completed_hours' => $minCompletedHours,
            'max_completed_hours' => $maxCompletedHours
        ];
    }

    public function calculateDistance(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lat1' => 'required',
            'lng1' => 'required',
            'lat2' => 'required',
            'lng2' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $distanceInfo = [
                "distance" => "0.0 km",
                "eta" => "0 mins",
                "distance_value" => 0,
                "eta_value" => 0,
            ];

            try {
                $GOOGLE_MAP_DISTANCE_URL = 'https://maps.googleapis.com/maps/api/distancematrix/json';
                $GOOGLE_MAP_API_KEY = 'AIzaSyCGRQavtVfIlnBuSkELe98R2MFjXQdnLRc';

                // Build the request URL
                $url = "$GOOGLE_MAP_DISTANCE_URL?origins={$request->lat1},{$request->lng1}&destinations={$request->lat2},{$request->lng2}&mode=driving&key=$GOOGLE_MAP_API_KEY";

                // Initialize cURL session
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($ch);
                curl_close($ch);

                // Decode JSON response
                $data = json_decode($response, true);
                if ($data && isset($data['rows'][0]['elements'][0])) {
                    $distanceInfo = [
                        "distance" => $data['rows'][0]['elements'][0]['distance']['text'] ?? '',
                        "eta" => $data['rows'][0]['elements'][0]['duration']['text'] ?? '',
                        "distance_value" => $data['rows'][0]['elements'][0]['distance']['value'] ?? 0,
                        "eta_value" => $data['rows'][0]['elements'][0]['duration']['value'] ?? 0,
                    ];
                }
            } catch (Exception $error) {
                error_log("Error fetching distance data: " . $error->getMessage());
            }

            return $distanceInfo;
        } catch (Exception $error) {
            error_log("Error calculating distance: " . $error->getMessage());
            // return [
            //     "distance" => "0.0 km",
            //     "eta" => "0 mins",
            //     "distance_value" => 0,
            //     "eta_value" => 0,
            // ];
        }
    }

    public function findCity($latitude, $longitude)
    {
        // Method 1: Exact geocoding match (recommended)
        $city = $this->findCityFromCoordinates(
            $latitude,
            $longitude
        );
        if ($city) {
            return response()->json([
                'found' => true,
                'city_data' => $city,
                'message' => "Coordinates fall within {$city->city}, {$city->state}"
            ]);
        } else {
            return response()->json([
                'found' => false,
                'message' => 'No matching city found in commission table'
            ]);
        }
    }

    public function countMyTotalJobs()
    {
        try {
            $currentDate = Carbon::now()->format('Y-m-d H:i:s');
            $myJobs = Job::where('user_id', auth()->user()->id);
            $totalPostedJobs =  Job::where('user_id', auth()->user()->id)->where(['status' => 1, 'is_draft' => 0])->where(function ($q) use ($currentDate) {
                $q->where('delivery_date_time', '>=', $currentDate)->orWhereHas('jobLoad', function ($query) {
                    $query->whereIn('status', [1, 2, 3]);
                });
            })->count();
            $pendingJobs = Job::where('user_id', auth()->user()->id)->where(['status' => 1, 'is_draft' => 0])->where(function ($q) use ($currentDate) {
                $q->where('delivery_date_time', '>=', $currentDate)->orWhereHas('jobLoad', function ($query) {
                    $query->whereIn('status', [1, 2, 3]);
                });
            })->count();
            $draftedJobs = Job::where('user_id', auth()->user()->id)->where(['status' => 1, 'is_draft' => 1])->count();
            $completedOrClosedJobs = Job::where('user_id', auth()->user()->id)->whereIn('status', [3, 6])->where('is_draft', 0)->count();
            $postedJobCounts = [
                'totalPostedJobs' => $totalPostedJobs,
                'pendingJobs' => $pendingJobs,
                'draftedJobs' => $draftedJobs,
                'completedOrClosedJobs' => $completedOrClosedJobs
            ];
            return $this->responseJson(true, 200, 'data found', $postedJobCounts);
        } catch (\Exception $e) {
            return $this->responseJson(false, 200, config('services.responseMessages.error'));
        }
    }
    public function getPastJobCompanyDetails()
    {
        try {
            $pastJobCompanyDetails = PastJobCompany::where('user_id', auth()->user()->id)->first();
            if ($pastJobCompanyDetails) {
                return $this->responseJson(true, 200, 'data found', $pastJobCompanyDetails);
            }
            return $this->responseJson(false, 200, 'No past job company details found');
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getExistingCompanies()
    {
        try {
            $existingCompanies = CompanyInfo::where('user_id', auth()->user()->id)->get();
            if ($existingCompanies) {
                return $this->responseJson(true, 200, 'data found', $existingCompanies);
            }
            return $this->responseJson(false, 200, 'No companies are found');
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getLiveRunningJobLoads()
    {
        try {
            $runningJobLoad = Load::where(['status' => 2])->where('started_on', '!=', null)->whereHas('job', function ($query) {
                $query->whereIn('user_id', getSubContractorWithMainContractorIds(auth()->user()->id));
            })->get();
            if ($runningJobLoad) {
                return $this->responseJson(true, 200, 'data found', LiveActiveLoadResource::collection($runningJobLoad));
            }
            return $this->responseJson(false, 200, 'No running job loads found', []);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    // public function initiatePayment($jobContractorId, $mainContractorId)
    // {
    //     $user = User::find($jobContractorId);

    //     if (!$user) {
    //         // Handle user not found, maybe log or throw exception
    //         return;
    //     }
    //     // Fetch completed loads with payment not initiated or not fully done (assuming status 4 means completed)
    //     $completedJobLoads = new Load;
    //     if($jobContractorId == $mainContractorId){
    //         // Main contractor's completed job loads
    //         $mainContractorCompletedJobLoads = $completedJobLoads->whereHas('job', function ($query) use ($mainContractorId) {
    //                         $query->where('user_id', $mainContractorId);
    //                     })->where('status', 4)
    //                         ->where('is_payment_initiated', '!=', 2)
    //                         ->get();
    //     }
    //     // Get all sub contractor IDs
    //     $subContractors = getSubContractorIds($mainContractorId);
    //     // Fetch completed job loads for sub contractors
    //     $completedJobLoads = Load::whereHas('job', function ($query) use ($subContractors) {
    //         $query->whereIn('user_id', $subContractors);
    //     })->where('status', 4)
    //         ->where('is_payment_initiated', '!=', 2)
    //         ->get();

    //     if ($completedJobLoads->isEmpty()) {
    //         // No loads to pay for - optionally handle this case
    //         return;
    //     }

    //     // Get job from the first load (assuming all loads belong to the same job)
    //     $job = $completedJobLoads[0]->job;
    //     $loadIds = $completedJobLoads->pluck('id')->toArray();

    //     // Get load positions string once to reuse
    //     $loadDetails = getLoadPositionsString($job->id, $loadIds);

    //     if ($user->stripe_payment_method) {
    //         $totalAmount = $completedJobLoads->sum('load_cost');

    //         $isDone = $this->chargeCustomerAutomatically(
    //             $user->stripe_customer_id,
    //             $user->stripe_payment_method,
    //             $totalAmount,
    //             $loadIds,
    //             $user,
    //             "Payment for load number {$loadDetails} under Job ID {$job->unique_id}"
    //         );

    //         if ($isDone['success']) {
    //             $title = "Payment Succeeded";
    //             $message = "Your payment succeeded for Job ID {$job->unique_id} for load no. {$loadDetails}";
    //         } else {
    //             $title = "Payment Failed";
    //             $message = "Your payment failed for Job ID {$job->unique_id} for load no. {$loadDetails}";
    //         }
    //     } else {
    //         $title = "Payment Failed";
    //         $message = "Your payment failed for Job ID {$job->unique_id} for load no. {$loadDetails}";
    //     }

    //     $this->sendPushToContracter($user->id, $title, $message, $job->id, $job->status);
    // }

    public function initiatePayment($jobContractorId, $mainContractorId)
    {
        $user = User::find($jobContractorId);
        $mainContractor = User::find($mainContractorId);
        if (!$user) {
            // Log::warning("User not found for payment initiation", ['job_contractor_id' => $jobContractorId]);
            return;
        }

        // Determine which contractor IDs to fetch loads for
        $contractorIds = $this->getContractorIds($jobContractorId, $mainContractorId);
        if (empty($contractorIds)) {
            // Log::info("No contractor IDs found for payment", ['main_contractor_id' => $mainContractorId]);
            return;
        }

        // Fetch all completed job loads for relevant contractors in one query
        $completedJobLoads = Load::with('job') // Eager load job to avoid N+1 queries
            ->whereHas('job', function ($query) use ($contractorIds) {
                $query->whereIn('user_id', $contractorIds);
            })
            ->where('status', 4)
            ->where('is_payment_initiated', '!=', 2)
            ->get();
        if ($completedJobLoads->isEmpty()) {
            // Log::info("No completed loads found for payment", [
            //     'contractor_ids' => $contractorIds,
            //     'job_contractor_id' => $jobContractorId
            // ]);
            return;
        }

        // Get unique job IDs and all load IDs
        $jobIds = $completedJobLoads->pluck('job_id')->unique()->toArray();
        $loadIds = $completedJobLoads->pluck('id')->toArray();
        $totalAmount = $completedJobLoads->sum('load_cost');
        // Get load positions grouped by job
        $loadDetailsByJob = getJobAndLoadPositions($jobIds, $loadIds);

        // Format load details for notification
        $loadDetailsMessage = $this->formatLoadDetailsMessage($loadDetailsByJob);

        // Group loads by job for detailed processing
        $loadsByJob = $completedJobLoads->groupBy('job_id');

        // Process payment for all loads
        $paymentResult = $this->processPayment(
            $mainContractor,
            $totalAmount,
            $loadIds,
            $loadsByJob,
            $loadDetailsByJob,
            $loadDetailsMessage
        );

        // Send notifications for each job
        $this->sendPaymentNotifications($user->id, $paymentResult, $loadsByJob, $loadDetailsByJob);

        // return $paymentResult;
    }

    private function getContractorIds($jobContractorId, $mainContractorId)
    {
        $contractorIds = [];

        // Always include the main contractor
        $contractorIds[] = $mainContractorId;

        // Get sub contractors
        $subContractors = getSubContractorIds($mainContractorId);

        // Merge sub contractors if they exist
        if (!empty($subContractors) && is_array($subContractors)) {
            $contractorIds = array_merge($contractorIds, $subContractors);
        }

        // Remove duplicates and return
        return array_unique($contractorIds);
    }

    private function formatLoadDetailsMessage(array $loadDetailsByJob): string
    {
        if (empty($loadDetailsByJob)) {
            return '';
        }

        $messages = [];
        foreach ($loadDetailsByJob as $jobUniqueId => $loads) {
            $messages[] = "{$jobUniqueId}: {$loads}";
        }

        return implode('; ', $messages);
    }

    /**
     * Process the payment for the user
     */
    private function processPayment(
        $user,
        $totalAmount,
        $loadIds,
        $loadsByJob,
        $loadDetailsByJob,
        $loadDetailsMessage
    ) {
        if (!$user->stripe_payment_method || !$user->stripe_customer_id) {
            // return [
            //     'success' => false,
            //     'title' => 'Payment Failed',
            //     'message' => "Payment method not found. Jobs: {$loadDetailsMessage}",
            //     'loadsByJob' => $loadsByJob,
            //     'loadDetailsByJob' => $loadDetailsByJob
            // ];
            return;
        }

        try {
            $chargeResult = $this->chargeCustomerAutomatically(
                $user->stripe_customer_id,
                $user->stripe_payment_method,
                $totalAmount,
                $loadIds,
                $user,
                "Payment for {$loadDetailsMessage}"
            );

            if ($chargeResult['success']) {
                return [
                    'success' => true,
                    'title' => 'Payment Succeeded',
                    'message' => "Your payment succeeded for {$loadDetailsMessage}",
                    'transaction_id' => $chargeResult['transaction_id'] ?? null,
                    'loadsByJob' => $loadsByJob,
                    'loadDetailsByJob' => $loadDetailsByJob,
                    'total_amount' => $totalAmount
                ];
            } else {
                return [
                    'success' => false,
                    'title' => 'Payment Failed',
                    'message' => "Your payment failed for {$loadDetailsMessage}. Reason: " . ($chargeResult['error'] ?? 'Unknown error'),
                    'loadsByJob' => $loadsByJob,
                    'loadDetailsByJob' => $loadDetailsByJob
                ];
            }
        } catch (\Exception $e) {
            Log::error("Payment processing error", [
                'user_id' => $user->id,
                'load_ids' => $loadIds,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'title' => 'Payment Failed',
                'message' => "Payment processing failed for {$loadDetailsMessage}",
                'loadsByJob' => $loadsByJob,
                'loadDetailsByJob' => $loadDetailsByJob
            ];
        }
    }

    /**
     * Send push notifications to contractor about payment result for each job
     */
    private function sendPaymentNotifications($userId, $paymentResult, $loadsByJob, $loadDetailsByJob)
    {
        try {
            foreach ($loadsByJob as $jobId => $loads) {
                $job = $loads->first()->job;
                $jobUniqueId = $job->unique_id;

                // Get load details for this specific job
                $jobLoadDetails = $loadDetailsByJob[$jobUniqueId] ?? '';

                // Create job-specific message
                $jobMessage = $paymentResult['success']
                    ? "Your payment succeeded for Job ID {$jobUniqueId} for {$jobLoadDetails}"
                    : "Your payment failed for Job ID {$jobUniqueId} for {$jobLoadDetails}";

                $this->sendPushToContracter(
                    $userId,
                    $paymentResult['title'],
                    $jobMessage,
                    $job->id,
                    $job->status
                );
            }
        } catch (\Exception $e) {
            Log::error("Failed to send payment notification", [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
        }
    }



    // stripe payment for pending load of contractor
    public function chargeCustomerAutomatically($stripeCustomerId, $paymentMethodId, $amountInCents, $loadIds, $user, $description = '')
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Set the payment method as default for the customer
            $stripe->customers->update($stripeCustomerId, [
                'invoice_settings' => [
                    'default_payment_method' => $paymentMethodId,
                ],
            ]);

            // Create and confirm the payment intent
            $paymentIntent = $stripe->paymentIntents->create([
                'amount' => $amountInCents * 100,
                'currency' => 'usd',
                'customer' => $stripeCustomerId,
                'payment_method' => $paymentMethodId,
                'off_session' => true,
                'confirm' => true,
                'description' => $description,
            ]);

            if ($paymentIntent->status == 'succeeded') {
                // Store the transaction
                Transaction::create([
                    'user_id' => $user->id,
                    'transaction_id' => $paymentIntent->id,
                    'payment_method_id' => $paymentMethodId,
                    'payment_method' => 2, // 1: PayPal, 2: Stripe
                    'amount' => $amountInCents,
                    'response_data' => json_encode($paymentIntent),
                    'transaction_date' => now(),
                    'load_ids' => json_encode($loadIds),
                    'status' => 1,
                ]);

                Load::whereIn('id', $loadIds)->update(['is_payment_initiated' => 2]);
                $user->update(['last_payment_at' => now()]);
            }
            logger("Payment Intent ID: " . $paymentIntent->id);
            logger("payment done");
            return [
                'success' => true,
                'payment_intent_id' => $paymentIntent->id,
            ];
        } catch (\Stripe\Exception\CardException $e) {
            $error = $e->getError();

            if ($error->code == 'authentication_required') {
                return [
                    'success' => false,
                    'requires_action' => true,
                    'client_secret' => $error->payment_intent->client_secret,
                    'payment_intent_id' => $error->payment_intent->id,
                    'message' => 'Authentication required',
                ];
            }

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    public function getMainContractor(Request $request)
    {
        $userId = getMainContractorId($request->user_id);
        dd($userId);
    }
}
