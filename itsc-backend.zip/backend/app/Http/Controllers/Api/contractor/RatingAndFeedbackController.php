<?php

namespace App\Http\Controllers\Api\contractor;

use Exception;
use App\Models\Feedback;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Auth\RatingCollection;

class RatingAndFeedbackController extends Controller
{
    public function myReviews(Request $request){
        $getRatingDetails = Feedback::where('given_to',auth()->user()->id)->latest()->paginate(10)->appends($request->except('page'));
        return new RatingCollection($getRatingDetails);
    }
}
