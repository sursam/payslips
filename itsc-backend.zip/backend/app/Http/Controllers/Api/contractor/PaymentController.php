<?php

namespace App\Http\Controllers\Api\contractor;

use App\Http\Controllers\BaseController;
use App\Traits\PayPal;
use Illuminate\Http\Request;

class PaymentController extends BaseController
{
    use PayPal;
    public function generatePaymentLink(Request $request)
    {
        // $request->validate([
        //     'amount' => 'required|numeric',
        //     'currency' => 'nullable|string|max:3', // Optional currency code
        // ]);

        $amount = 1200;
        $currency = 'USD'; // Default to USD if not provided

        try {
            $paymentLink = $this->createPayment($amount, $currency);
            // $payerActionUrl = $paymentLink->getData()->payer_action_url ?? null;
            if ($paymentLink) {
                return response()->json(['payer_action_url' => $paymentLink], 200);
            } else {
                return response()->json(['error' => 'Payer action URL not found'], 500);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function success(Request $request)
    {
        $this->capturePayment($request->token, $request->amount, $request->loadIds);
    }
    public function cancel(Request $request)
    {
        dd($request->all());
    }
    
}
