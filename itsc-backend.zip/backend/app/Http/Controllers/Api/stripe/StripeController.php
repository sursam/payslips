<?php

namespace App\Http\Controllers\Api\stripe;

use App\Models\Load;
use App\Models\User;
use Stripe\StripeClient;
use App\Models\Transaction;
use App\Traits\StripeTrait;
use App\Models\PaymentTerms;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\Auth\JobLoadResource;

class StripeController extends BaseController
{
    use stripeTrait;

    // public function initiatePayment(Request $request)
    // {
    //     try {
    //         $user = auth()->user();
    //         $currentDate = now();

    //         $paymentTerms = PaymentTerms::where('user_id', $user->id)->first();
    //         if (!$paymentTerms) {
    //             return $this->responseJson(false, 200, 'Payment terms not found for user.', (object)[]);
    //         }

    //         $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at);
    //         $intervalInDays = $lastPaidAt->diffInDays($currentDate);

    //         // if ($intervalInDays < $paymentTerms->pay_in) {
    //         //     return $this->responseJson(false, 200, 'Payment interval not reached yet.', (object)[]);
    //         // }

    //         // Fetch eligible completed job loads
    //         $completedJobLoads = Load::whereHas('job', function ($query) use ($user) {
    //             $query->where('user_id', $user->id);
    //         })
    //             ->where('status', 4)
    //             ->where('is_payment_initiated', '!=', 2)
    //             ->get();

    //         if ($completedJobLoads->isEmpty()) {
    //             return $this->responseJson(false, 200, 'No completed job loads found for payment.', (object)[]);
    //         }

    //         // Calculate payment amount and gather load IDs
    //         $payAmount = $completedJobLoads->sum('load_cost');
    //         $loadIds = $completedJobLoads->pluck('id')->toArray();

    //         if ($payAmount <= 0) {
    //             return $this->responseJson(false, 200, 'Payable amount is zero.', (object)[]);
    //         }

    //         // Generate payment intent or charge automatically
    //         $startDate = $lastPaidAt->format('m-d-Y');
    //         $endDate = $currentDate->format('m-d-Y');

    //         $transactionData = null;

    //         // Check if user has a successful previous transaction with a saved payment method
    //         $lastSucceededTransaction = Transaction::where([
    //             'user_id' => $user->id,
    //             'status' => 1,
    //         ])->latest()->first();

    //         $lastPaymentMethodId = $lastSucceededTransaction?->payment_method_id;

    //         // if ($lastPaymentMethodId) {
    //         //     $autoChargeResponse = $this->chargeCustomerAutomatically(
    //         //         $user->stripe_customer_id,
    //         //         $lastPaymentMethodId,
    //         //         $payAmount,
    //         //         "Payment for loads from $startDate to $endDate"
    //         //     );

    //         //     if (!empty($autoChargeResponse['success']) && $autoChargeResponse['success'] === true) {
    //         //         // Successful automatic charge
    //         //         $transactionData = $this->storeTransactionAfterAutoCharge(
    //         //             $user->id,
    //         //             $autoChargeResponse['payment_intent_id'],
    //         //             $payAmount,
    //         //             $loadIds,
    //         //             $lastPaymentMethodId
    //         //         );
    //         //     } elseif (!empty($autoChargeResponse['requires_action'])) {
    //         //         // Payment requires user action (e.g., 3D Secure)
    //         //         return $this->responseJson(false, 402, 'Authentication required to complete payment.', [
    //         //             'client_secret' => $autoChargeResponse['client_secret'],
    //         //             'requires_action' => true,
    //         //         ]);
    //         //     }
    //         // }

    //         // // If auto charge wasn't possible or failed, fallback to PaymentIntent creation
    //         // if (!$transactionData) {
    //         $transactionData = $this->generateStripePaymentViaIntent(
    //             $payAmount,
    //             $startDate,
    //             $endDate,
    //             $loadIds,
    //             $user->id
    //         );
    //         // }

    //         if (!empty($transactionData)) {
    //             $transactionData['load_details'] = $this->paidLoadDetails($loadIds);
    //             return $this->responseJson(true, 200, 'Payment data generated successfully.', $transactionData);
    //         }

    //         return $this->responseJson(false, 500, 'Failed to generate payment data.', (object)[]);
    //     } catch (\Exception $e) {
    //         logger()->error('Initiate Payment Error', [
    //             'message' => $e->getMessage(),
    //             'line'    => $e->getLine(),
    //             'file'    => $e->getFile(),
    //         ]);

    //         return $this->responseJson(false, 500, 'Something went wrong: ' . $e->getMessage(), []);
    //     }
    // }
    public function initiatePayment(Request $request)
    {
        try {
            $user = auth()->user();
            $mainContractorId = getMainContractorId($user->id);
            $currentDate = now();

            $paymentTerms = PaymentTerms::where('user_id', $mainContractorId)->first();
            if (!$paymentTerms) {
                return $this->responseJson(false, 200, 'Payment terms not found for user.', (object)[]);
            }

            $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at);
            $intervalInDays = $lastPaidAt->diffInDays($currentDate);

            // if ($intervalInDays < $paymentTerms->pay_in) {
            //     return $this->responseJson(false, 200, 'Payment interval not reached yet.', (object)[]);
            // }

            // Fetch eligible completed job loads
            $completedJobLoads = Load::whereHas('job', function ($query) use ($user) {
                $query->whereIn('user_id', getSubContractorWithMainContractorIds($user->id));
            })
                ->where('status', 4)
                ->where('is_payment_initiated', '!=', 2)
                ->get();

            if ($completedJobLoads->isEmpty()) {
                return $this->responseJson(false, 200, 'No completed job loads found for payment.', (object)[]);
            }

            // Calculate payment amount and gather load IDs
            $payAmount = $completedJobLoads->sum('load_cost');
            $loadIds = $completedJobLoads->pluck('id')->toArray();

            if ($payAmount <= 0) {
                return $this->responseJson(false, 200, 'Payable amount is zero.', (object)[]);
            }

            // Generate payment intent or charge automatically
            $startDate = $lastPaidAt->format('m-d-Y');
            $endDate = $currentDate->format('m-d-Y');

            $transactionData = null;

            // Check if user has a successful previous transaction with a saved payment method
            $lastSucceededTransaction = Transaction::where([
                'user_id' => $user->id,
                'status' => 1,
            ])->latest()->first();
            $jobIds = $completedJobLoads->pluck('job_id')->unique()->toArray();
            $loadIds = $completedJobLoads->pluck('id')->toArray();
            $lastPaymentMethodId = $lastSucceededTransaction?->payment_method_id;
            $loadDetailsByJob = getJobAndLoadPositions($jobIds, $loadIds);

            // Format load details for notification
            $loadDetailsMessage = $this->formatLoadDetailsMessage($loadDetailsByJob);
            $transactionData = $this->generateStripePaymentViaIntent(
                $payAmount,
                $startDate,
                $endDate,
                $loadIds,
                $mainContractorId,
                $loadDetailsMessage
            );

            if (!empty($transactionData)) {
                $transactionData['load_details'] = $this->paidLoadDetails($loadIds);
                return $this->responseJson(true, 200, 'Payment data generated successfully.', $transactionData);
            }

            return $this->responseJson(false, 500, 'Failed to generate payment data.', (object)[]);
        } catch (\Exception $e) {
            logger()->error('Initiate Payment Error', [
                'message' => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
            ]);

            return $this->responseJson(false, 500, 'Something went wrong: ' . $e->getMessage(), []);
        }
    }


    private function generateStripePaymentViaIntent($payAmount, $startDate, $endDate, $loadIds, $userId, $loadDetailsMessage)
    {
        try {
            // Initialize Stripe with secret key
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $user = User::find($userId);
            $userStripeCustomerId = $user->stripe_customer_id;

            // Ensure user has a Stripe customer ID
            if ($userStripeCustomerId == null) {
                $stripeCustomer = $stripe->customers->create([
                    'name' => $user->name,
                    'email' => $user->email,
                    'metadata' => [
                        'user_id' => $user->id,
                        'created_at' => now()->toIso8601String()
                    ]
                ]);

                $user->update(['stripe_customer_id' => $stripeCustomer->id]);
                $userStripeCustomerId = $stripeCustomer->id;
            }

            // Validate amount
            if (!is_numeric($payAmount) || $payAmount <= 0) {
                throw new \InvalidArgumentException('Invalid payment amount');
            }
            $amountInCents = $payAmount * 100;
            // Create PaymentIntent with automatic payment methods
            $paymentIntent = $stripe->paymentIntents->create([
                'amount' => $amountInCents,
                'currency' => env('STRIPE_CURRENCY', 'usd'),
                'customer' => $userStripeCustomerId,
                'automatic_payment_methods' => [
                    'enabled' => true,
                    'allow_redirects' => 'always',
                ],
                'setup_future_usage' => 'off_session',
                'description' => "Payment for {$loadDetailsMessage}",
            ]);

            // Validate PaymentIntent creation
            if (!$paymentIntent || !isset($paymentIntent->client_secret)) {
                throw new \Exception('Payment Intent creation failed: ' . ($paymentIntent->last_payment_error ?? 'Unknown error'));
            }
            // Create transaction record
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'transaction_id' => $paymentIntent->id,
                'payment_method' => 2, // 1: PayPal, 2: Stripe
                'amount' => $payAmount,
                'response_data' => json_encode($paymentIntent),
                'transaction_date' => now(),
                'load_ids' => json_encode($loadIds),
                'status' => 0, // Pending
            ]);

            // Create an ephemeral key for the customer
            $ephemeralKey = $stripe->ephemeralKeys->create([
                'customer' => $userStripeCustomerId,
            ], [
                'stripe_version' => '2023-10-16', // Updated to a more recent API version
            ]);

            // Return only what's needed for the client
            return [
                'customer' => $userStripeCustomerId,
                'initiate_payment_reference' => $paymentIntent->id,
                'setupIntent' => $paymentIntent->client_secret,
                'ephemeral_key' => $ephemeralKey->secret,
                'stripe_publishable_key' => env('STRIPE_PUBLIC_KEY'),
                'stripe_secret_key' => env('STRIPE_SECRET_KEY'),
                'amount' => $payAmount,
                'currency' => strtoupper(env('STRIPE_CURRENCY', 'usd')),
            ];
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle Stripe-specific errors
            logger()->error('Stripe API Error: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);

            return [
                'success' => false,
                'message' => 'Payment processing error: ' . $e->getMessage(),
                'error_code' => $e->getStripeCode()
            ];
        } catch (\Exception $e) {
            // Handle general errors
            logger()->error('Payment Error: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
            ]);

            return [
                'success' => false,
                'message' => 'Something went wrong with the payment process. Please try again.'
            ];
        }
    }


    public function paymentComplete(Request $request)
    {
        // Validate the request data
        $validator = Validator::make($request->all(), [
            'transaction_id' => 'required|string|exists:transactions,transaction_id',
            // 'payment_method_id' => 'required|string',
            'status' => 'required|in:1,2,3',
            // 'final_response' => 'required|string',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first());
        }

        DB::beginTransaction();

        try {
            // Retrieve the transaction using the payment reference number
            $transaction = Transaction::where('transaction_id', $request->transaction_id)->first();
            $transactedUser = User::find($transaction->user_id);
            if (!$transaction) {
                return $this->responseJson(false, 404, "Transaction not found.");
            }
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $paymentIntent = $stripe->paymentIntents->retrieve($request->transaction_id);
            $paymentMethodId = $paymentIntent->payment_method;
            $stripeCustomerId = $transactedUser->stripe_customer_id ?? null;
            // set default payment method
            if ($stripeCustomerId) {
                $this->setDefaultPaymentMethod($stripeCustomerId, $paymentIntent->payment_method);
            }
            // Update transaction with the provided data
            $updateData = [
                'payment_method_id' => $paymentMethodId,
                'status' => $request->status,
                // 'response_data' => $request->final_response
            ];

            // Add payment_method_id only for successful payments
            // if ($request->status == 1) {
            //     $updateData['payment_method_id'] = $request->payment_method_id;
            // }

            // Update the transaction
            $transaction->update($updateData);

            // For successful payments, update the load payment status
            if ($request->status == 1) {
                $loadIds = json_decode($transaction->load_ids, true);

                if (!empty($loadIds)) {
                    Load::whereIn('id', $loadIds)->update(['is_payment_initiated' => 2]);
                }
                $transactedUser->update(['stripe_payment_method' => $paymentMethodId, 'last_payment_at' => now()]);
                DB::commit();
                return $this->responseJson(true, 200, "Payment completed successfully.");
            } else {
                // For failed payments
                DB::commit();
                return $this->responseJson(false, 200, "Payment failed.");
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger('Payment completion error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while processing the payment.");
        }
    }
    public function completedKyc($deviceType, $accountId)
    {
        if ($accountId != null) {
            // check for is kyc is completed
            if (!$this->checkStripeAccountStatus($accountId)) {
                // generate the link again for complete the process
                $isAccountOnboardingUrl = $this->generateAccountLink($accountId, $deviceType);
                if ($isAccountOnboardingUrl) {
                    return view('stripe.kyc-pending', compact('isAccountOnboardingUrl'));
                }
            } else {
                // kyc is completed update the completed_steps to 6
                User::where('stripe_account_id', $accountId)->update(['completed_steps' => 6]);
                return view('stripe.kyc-completed', compact('deviceType'));
            }
        } else {
            return view('stripe.kyc-completed', compact('deviceType'));
        }
    }
    public function kycSuccess(Request $request)
    {
        return view('stripe.kyc-verified');
    }
    public function getPaymentHistoryOLd(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'per_page' => 'nullable|integer|min:1',
            'page' => 'nullable|integer|min:1'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        $customerId = auth()->user()->stripe_customer_id;
        if (!$customerId) {
            return $this->responseJson(false, 400, "Stripe customer ID not found for user.", []);
        }

        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

        $perPage = $request->input('per_page', 10); // default 10
        $currentPage = $request->input('page', 1);  // default 1
        $offset = ($currentPage - 1) * $perPage;
        $startDate = $request->input('start_date') ?? null;
        $endDate = $request->input('end_date') ?? null;
        try {
            $totalPaid = 0;
            // Fetch a large enough batch to simulate offset
            $maxFetch = $offset + $perPage;
            $params = [
                'customer' => $customerId,
                'limit' => $maxFetch,
            ];
            if ($startDate || $endDate) {
                $createdFilter = [];
                if ($startDate != null) {
                    $createdFilter['gte'] = strtotime($startDate . ' 00:00:00');
                }
                if ($endDate != null) {
                    $createdFilter['lte'] = strtotime($endDate . ' 23:59:59');
                }
                $params['created'] = $createdFilter;
            }
            // Fetch payment intents
            $paymentIntents = $stripe->paymentIntents->all($params);
            // return $paymentIntents;
            $filteredPayments = [];
            foreach ($paymentIntents->data as $index => $paymentIntent) {
                $totalPaid += $paymentIntent->amount_received / 100;
                if ($index < $offset) continue; // skip until offset
                $paymentIntentData = [
                    'payment_intent_id' => $paymentIntent->id,
                    'amount_processed' => $paymentIntent->amount / 100,
                    'currency' => strtoupper($paymentIntent->currency),
                    'status' => $paymentIntent->status,
                    'amount_received' => $paymentIntent->amount_received / 100,
                    'created_at' => date('Y-m-d H:i:s', $paymentIntent->created),
                    'capture_method' => $paymentIntent->capture_method,
                    'description' => $paymentIntent->description,
                    'latest_charge' => $paymentIntent->latest_charge,
                ];

                $paymentMethodData = null;
                if ($paymentIntent->payment_method) {
                    $paymentMethod = $stripe->paymentMethods->retrieve($paymentIntent->payment_method);
                    $paymentMethodData = [
                        'id' => $paymentMethod->id,
                        'type' => $paymentMethod->type,
                    ];
                    if ($paymentMethod->type === 'card') {
                        $paymentMethodData['card'] = [
                            'brand' => $paymentMethod->card->brand,
                            'last4' => $paymentMethod->card->last4,
                            'exp_month' => $paymentMethod->card->exp_month,
                            'exp_year' => $paymentMethod->card->exp_year,
                        ];
                    }
                }

                $filteredPayments[] = [
                    'paymentIntent' => $paymentIntentData,
                    'paymentMethod' => $paymentMethodData,
                ];
            }

            $total = count($paymentIntents->data);
            $lastPage = ceil($total / $perPage);
            return response()->json([
                'status' => true,
                'response_code' => 200,
                'message' => 'Payment history retrieved successfully.',
                'data' => [
                    // 'total_paid' => $totalPaid,
                    'total_paid' => number_format($totalPaid, 2, '.', ''),
                    'payments' => $filteredPayments
                ],
                'pagination' => [
                    'total' => $total,
                    'per_page' => $perPage,
                    'current_page' => (int)$currentPage,
                    'last_page' => $lastPage,
                    'total_pages' => $lastPage
                ],
            ]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            return $this->responseJson(false, 500, $e->getMessage(), []);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
    public function getPaymentHistory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'per_page' => 'nullable|integer|min:1',
            'page' => 'nullable|integer|min:1'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        $customerId = auth()->user()->stripe_customer_id;
        if (!$customerId) {
            return $this->responseJson(false, 400, "Stripe customer ID not found for user.", []);
        }

        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

        $perPage = $request->input('per_page', 10);
        $currentPage = $request->input('page', 1);
        $startDate = $request->input('start_date') ?? null;
        $endDate = $request->input('end_date') ?? null;

        try {
            $params = [
                'customer' => $customerId,
                'limit' => 100, // Stripe max
            ];

            if ($startDate || $endDate) {
                $createdFilter = [];
                if ($startDate != null) {
                    $createdFilter['gte'] = strtotime($startDate . ' 00:00:00');
                }
                if ($endDate != null) {
                    $createdFilter['lte'] = strtotime($endDate . ' 23:59:59');
                }
                $params['created'] = $createdFilter;
            }

            // Fetch ALL payment intents to get accurate count
            $allPaymentIntents = [];
            $totalPaid = 0;
            $hasMore = true;
            $startingAfter = null;

            while ($hasMore) {
                if ($startingAfter) {
                    $params['starting_after'] = $startingAfter;
                }

                $paymentIntents = $stripe->paymentIntents->all($params);

                foreach ($paymentIntents->data as $pi) {
                    $allPaymentIntents[] = $pi;
                    $totalPaid += $pi->amount_received / 100;
                }

                $hasMore = $paymentIntents->has_more;
                if ($hasMore && count($paymentIntents->data) > 0) {
                    $startingAfter = end($paymentIntents->data)->id;
                }
            }

            // Calculate pagination values
            $totalRecords = count($allPaymentIntents);  // Total payment intents
            $totalPages = ceil($totalRecords / $perPage);  // Total pages available
            $offset = ($currentPage - 1) * $perPage;

            // Get current page data
            $paginatedIntents = array_slice($allPaymentIntents, $offset, $perPage);

            $filteredPayments = [];
            foreach ($paginatedIntents as $paymentIntent) {
                $paymentIntentData = [
                    'payment_intent_id' => $paymentIntent->id,
                    'amount_processed' => $paymentIntent->amount / 100,
                    'currency' => strtoupper($paymentIntent->currency),
                    'status' => $paymentIntent->status,
                    'amount_received' => $paymentIntent->amount_received / 100,
                    'created_at' => date('Y-m-d H:i:s', $paymentIntent->created),
                    'capture_method' => $paymentIntent->capture_method,
                    'description' => $paymentIntent->description,
                    'latest_charge' => $paymentIntent->latest_charge,
                ];

                $paymentMethodData = null;
                if ($paymentIntent->payment_method) {
                    $paymentMethod = $stripe->paymentMethods->retrieve($paymentIntent->payment_method);
                    $paymentMethodData = [
                        'id' => $paymentMethod->id,
                        'type' => $paymentMethod->type,
                    ];
                    if ($paymentMethod->type === 'card') {
                        $paymentMethodData['card'] = [
                            'brand' => $paymentMethod->card->brand,
                            'last4' => $paymentMethod->card->last4,
                            'exp_month' => $paymentMethod->card->exp_month,
                            'exp_year' => $paymentMethod->card->exp_year,
                        ];
                    }
                }

                $filteredPayments[] = [
                    'paymentIntent' => $paymentIntentData,
                    'paymentMethod' => $paymentMethodData,
                ];
            }

            return response()->json([
                'status' => true,
                'response_code' => 200,
                'message' => 'Payment history retrieved successfully.',
                'data' => [
                    'total_paid' => number_format($totalPaid, 2, '.', ''),
                    'payments' => $filteredPayments
                ],
                'pagination' => [
                    'total' => $totalRecords,        // Total number of payment records
                    'per_page' => $perPage,          // Records per page
                    'current_page' => (int)$currentPage,  // Current page
                    'last_page' => $totalPages,      // Last page number
                    'total_pages' => $totalPages     // Total count of pages (same as last_page)
                ],
            ]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            return $this->responseJson(false, 500, $e->getMessage(), []);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
    public function chargeCustomerAutomatically($stripeCustomerId, $paymentMethodId, $amountInCents, $description = '')
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Optional: set payment method as default for future
            $stripe->customers->update($stripeCustomerId, [
                'invoice_settings' => [
                    'default_payment_method' => $paymentMethodId,
                ],
            ]);

            // Create the off-session PaymentIntent
            $paymentIntent = $stripe->paymentIntents->create([
                'amount' => $amountInCents,
                'currency' => 'usd',
                'customer' => $stripeCustomerId,
                'payment_method' => $paymentMethodId,
                'off_session' => true,
                'confirm' => true,
                'description' => $description,
            ]);

            return [
                'success' => true,
                'payment_intent_id' => $paymentIntent->id,
            ];
        } catch (\Stripe\Exception\CardException $e) {
            $error = $e->getError();

            if ($error->code === 'authentication_required') {
                // User must complete authentication manually
                return [
                    'success' => false,
                    'requires_action' => true,
                    'client_secret' => $error->payment_intent->client_secret,
                    'payment_intent_id' => $error->payment_intent->id,
                    'message' => 'Authentication required',
                ];
            }

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }
    public function getPaidLoadDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_intent_id' => 'required|string|exists:transactions,transaction_id',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        try {
            // get transaction details
            $isTransaction = Transaction::where('transaction_id', $request->payment_intent_id)->first();
            if (!$isTransaction || $isTransaction->status != 1) {
                return $this->responseJson(false, 200, "Transaction not succeeded", []);
            }
            $loadIds = json_decode($isTransaction->load_ids, true);
            if (!$loadIds) {
                return $this->responseJson(false, 200, "No load IDs associated with this transaction.", []);
            }
            $paidLoadDetails = $this->paidLoadDetails($loadIds);
            return $this->responseJson(true, 200, "Paid load details retrieved successfully.", $paidLoadDetails);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong.", []);
        }
    }
    public function createPaymentIntent(Request $request)
    {
        $userId = auth()->user()->id;
        try {
            $setupIntent = $this->createSetupIntent($userId);
            if (!$setupIntent) {
                return $this->responseJson(false, 200, "Setup intent not found.", []);
            }
            $data = [
                'setup_intent' => $setupIntent,
                'customer_id' => auth()->user()->stripe_customer_id,
                'publishable_key' => env('STRIPE_PUBLIC_KEY')
            ];
            return $this->responseJson(true, 200, "Setup intent created successfully.", $data);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
    private function paidLoadDetails($loadIds)
    {
        if (!$loadIds) {
            return [];
        }
        $loads = Load::whereIn('id', $loadIds)->get();
        if ($loads->isEmpty()) {
            return [];
        }
        return JobLoadResource::collection($loads);
    }
    public function updatePaymentMethod(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_method_id' => 'required|string',
            'customer_id' => 'required|string',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        try {
            $updatePaymentMethod = User::where('stripe_customer_id', $request->customer_id)->update([
                'stripe_payment_method' => $request->payment_method_id
            ]);
            if (!$updatePaymentMethod) {
                return $this->responseJson(false, 200, "Payment method not updated.", []);
            }
            $this->setDefaultPaymentMethod($request->customer_id, $request->payment_method_id);
            return $this->responseJson(true, 200, "Payment method updated successfully.", []);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
    public function getContractorPaymentMethod()
    {
        try {
            $user = auth()->user();

            if (!$user || !$user->stripe_customer_id) {
                return $this->responseJson(false, 404, "User or Stripe customer ID not found.");
            }

            $stripeCustomerId = $user->stripe_customer_id;

            // Initialize Stripe client
            $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET_KEY'));

            // Retrieve the customer from Stripe to get default payment method
            $customer = $stripe->customers->retrieve($stripeCustomerId, []);

            $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method ?? null;

            // Retrieve all payment methods for this customer (assuming your method retrieves cards)
            $paymentMethods = $this->retriveCustomerPaymentMethod($stripeCustomerId);

            // Prepare the response data
            $data = [
                'default_payment_method_id' => $defaultPaymentMethodId,
                'payment_methods' => $paymentMethods,
            ];

            return $this->responseJson(true, 200, "Payment method retrieved successfully.", $data);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Failed to retrieve payment methods.");
        }
    }


    // Format load details for notification
    private function formatLoadDetailsMessage(array $loadDetailsByJob): string
    {
        if (empty($loadDetailsByJob)) {
            return '';
        }

        $messages = [];
        foreach ($loadDetailsByJob as $jobUniqueId => $loads) {
            $messages[] = "{$jobUniqueId}: {$loads}";
        }

        return implode('; ', $messages);
    }
    public function generateSetupIntent()
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $user = User::find(auth()->user()->id);
            // Create SetupIntent
            $setupIntent = $stripe->setupIntents->create([
                'customer' => $user->stripe_customer_id
            ]);
            return $this->responseJson(true, 200, "Setup intent created successfully.", ['clientSecret' => $setupIntent->client_secret]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Failed to create setup intent.");
        }
    }
    public function fetchCustomerPaymentMethod()
    {
        try {
            $user = auth()->user();

            if (!$user || !$user->stripe_customer_id) {
                return $this->responseJson(false, 404, "User or Stripe customer ID not found.");
            }

            $stripeCustomerId = $user->stripe_customer_id;
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $paymentMethods = $stripe->customers->allPaymentMethods(
                $stripeCustomerId,
                ['limit' => 20]
            );

            // Prepare the response data
            $data = [
                'payment_methods' => $paymentMethods,
            ];

            return $this->responseJson(true, 200, "Payment method retrieved successfully.", $paymentMethods);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Failed to retrieve payment methods.");
        }
    }
    public function deletePaymentMethod(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_method_id' => 'required|string'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        try {
            $stripePaymentMethod = auth()->user()->stripe_payment_method;
            if($stripePaymentMethod == $request->payment_method_id){
                $updatePaymentMethod = User::where('id', auth()->user()->id)->update([
                    'stripe_payment_method' => null
                ]);
                if (!$updatePaymentMethod) {
                    return $this->responseJson(false, 200, "Payment method not deleted.", []);
                }
            }
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $stripe->paymentMethods->detach($request->payment_method_id, []);
            return $this->responseJson(true, 200, "Payment method deleted successfully.", []);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
    public function addDefaultPaymentMethod(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_method_id' => 'required|string',
            'customer_id' => 'required|string',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), []);
        }
        try {
            $user = User::where('stripe_customer_id', $request->customer_id)->first();
            $isAdded = false;
            if($user && !$user->stripe_payment_method){
                $updatePaymentMethod = User::where('stripe_customer_id', $request->customer_id)->update([
                    'stripe_payment_method' => $request->payment_method_id
                ]);
                if (!$updatePaymentMethod) {
                    return $this->responseJson(false, 200, "Payment method not updated.", []);
                }
                $this->setDefaultPaymentMethod($request->customer_id, $request->payment_method_id);
                $isAdded = true;
            }
            return $this->responseJson(true, 200, "Payment method updated successfully.", ['isAdded' => $isAdded]);
        } catch (\Exception $e) {
            logger('Payment history error: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong while retrieving payment history.", []);
        }
    }
}
