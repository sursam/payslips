<?php

namespace App\Http\Controllers\Api;

use App\Models\FavouriteProduct;
use App\Models\User;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use App\Traits\NotificationTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\User\ProfileCollection;

class UserController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    use NotificationTrait;

    public function userList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_type' => 'required',
        ]);
        if ($validator->fails()) {
            $status = false;
            $code = 200;
            $response = [];
            $message = $validator->errors()->first();
            return $this->responseJson($status, $code, $message, $response);
        }
        // dd($userFound->toArray());
        $query = User::where(['user_type' => $request->user_type, 'is_approve' => 1, 'is_blocked' => 0]);

        if ($request->has('name')) {
            $query = $query->where(function ($q) use ($request) {
                $q->where('name', 'LIKE', '%' . $request->name . '%');
            });
        }
        if ($request->is_verified != '') {
            $query = $query->where('is_verified', (int)$request->is_verified);
        }
        if (!empty($request->state)) {
            $query = $query->where('state', $request->state);
        }
        if (!empty($request->city)) {
            $query = $query->where('city', $request->city);
        }

        $userDetails = $query->get();

        if (is_null($userDetails->toArray())) {
            $status = false;
            $code = 200;
            $response = [];
            $message = 'No Data Found';
            return $this->responseJson($status, $code, $message, $response);
        }

        if ($userDetails) {
            $status = true;
            $code = 200;
            $response = ProfileCollection::collection($userDetails);
            $message = "User Found";
            return $this->responseJson($status, $code, $message, $response);
        } else {
            $status = false;
            $code = 200;
            $response = [];
            $message = 'Something went wrong.';
            return $this->responseJson($status, $code, $message, $response);
        }
    }
    public function profileDetails(Request $request)
    {
        try {
            $userDetails = Auth::user();
            if ($userDetails) {
                $status = true;
                $code = 200;
                $response = new ProfileCollection($userDetails);
                $message = "Data Found";
                return $this->responseJson($status, $code, $message, $response);
            } else {
                $status = true;
                $code = 200;
                $response = [];
                $message = "No Data Found";
                return $this->responseJson($status, $code, $message, $response);
            }
        } catch (\Throwable $th) {
            $status = false;
            $code = 500;
            $response = $th->getMessage();
            $message = config('constants.CATCH_ERROR_MSG');
            return $this->responseJson($status, $code, $message, $response);
        }
    }
    public function updateProfile(Request $request)
    {
        $id = Auth::user()->id;
        $rules = [
            "email" => 'sometimes|email|unique:users,email,' . $id,
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            $status = false;
            $code = 200;
            $response = [];
            $message = $validator->errors()->first();
            return $this->responseJson($status, $code, $message, $response);
        }
        DB::beginTransaction();
        try {
            $data_to_update = array();

            if (!empty($request->name)) {
                $data_to_update['name'] = $request->name;
            }
            if (!empty($request->email)) {
                $data_to_update['email'] = $request->email;
            }
            if (!empty($request->lat)) {
                $data_to_update['lat'] = $request->lat;
            }
            if (!empty($request->lng)) {
                $data_to_update['lng'] = $request->lng;
            }

            if (!empty($request->profile_image)) {
                $image = $request->profile_image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $data_to_update['profile_image'] = $fileName;
                }
            }

            $userUpdated = User::where('id', $id)->update($data_to_update);

            if ($userUpdated) {
                DB::commit();
                $userDetails = User::where('id', $id)->first();
                $status = true;
                $code = 200;
                $response = new ProfileCollection($userDetails);
                $message = "Profile updated successfully";
            } else {
                $status = true;
                $code = 200;
                $response = [];
                $message = "No Data Found";
            }
        } catch (\Throwable $th) {
            DB::rollBack();
            $status = false;
            $code = 500;
            $response = $th->getMessage();
            $message = config('constants.CATCH_ERROR_MSG');
        }
        return $this->responseJson($status, $code, $message, $response);
    }
}
