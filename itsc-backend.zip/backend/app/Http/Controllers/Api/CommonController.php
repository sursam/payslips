<?php

namespace App\Http\Controllers\Api;

use DateTime;
use Stripe\Payout;
use App\Models\Faq;
use App\Models\Job;
use App\Models\City;
use App\Models\Load;
use App\Models\User;
use App\Models\State;
use App\Models\Country;
use Twilio\Rest\Client;
use App\Models\AppIntro;
use App\Models\Feedback;
use App\Models\LoadType;
use App\Models\Material;
use Stripe\StripeClient;
use App\Models\AppBanner;
use App\Models\Equipment;
use App\Models\SosReason;
use App\Models\TruckType;
use App\Models\AppVersion;
use App\Scopes\ActiveScope;
use App\Traits\StripeTrait;
use Laravel\Passport\Token;
use App\Models\Notification;
use App\Models\PaymentTerms;
use Illuminate\Http\Request;
use App\Models\HomepageBanner;
use Illuminate\Support\Carbon;
use App\Traits\NotificationTrait;
use App\Models\CancellationReason;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\Auth\JobResource;
use App\Http\Resources\common\MasterResource;
use App\Http\Resources\common\TruckTypeResource;
use App\Http\Resources\common\FlashScreenResource;
use App\Http\Resources\Api\Auth\NotificationResource;
use App\Http\Resources\Api\Common\LoadResourceCollection;

class CommonController extends BaseController
{
    use NotificationTrait;
    use StripeTrait;
    public function getCountries()
    {
        $isCountries = Country::all();
        $status = $isCountries->isNotEmpty();
        $message = $status ? 'Data found' : 'Data not found';
        $countries = $status ? $isCountries : [];
        return $this->responseJson($status, 200, $message, $countries);
    }

    public function getState(Request $request)
    {
        try {
            $isStates = State::where('country_id', 233)->get();
            $status = $isStates->isNotEmpty();
            $message = $status ? 'Data found' : 'Data not found';
            $countries = $status ? $isStates : [];
            return $this->responseJson($status, 200, $message, $isStates);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getStatesByCountry(Request $request)
    {
        try {
            $isStates = State::select([DB::raw('name as label'), 'id'])->where('country_code', $request->country_code)->get();
            $status = $isStates->isNotEmpty();
            $message = $status ? 'Data found' : 'Data not found';
            $states = $status ? $isStates : [];
            return $this->responseJson($status, 200, $message, $states);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getCity(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'state_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isCities = City::where('state_id', $request->state_id)->get();
            $status = $isCities->isNotEmpty();
            $message = $status ? 'Data found' : 'Data not found';
            $countries = $status ? $isCities : [];
            return $this->responseJson($status, 200, $message, $isCities);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getCitiesByState(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'state_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isCities = City::select([DB::raw('name as label'), 'id'])->where('state_id', $request->state_id)->get();
            $status = $isCities->isNotEmpty();
            $message = $status ? 'Data found' : 'Data not found';
            $cities = $status ? $isCities : [];
            return $this->responseJson($status, 200, $message, $cities);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getFlashScreen()
    {
        try {
            $isFlashScreens = AppIntro::orderby('position', 'asc')->get();
            $status = $isFlashScreens->isNotEmpty();
            $message = $status ? 'Data found' : 'Data not found';
            $data = $status ? FlashScreenResource::collection($isFlashScreens) : [];
            return $this->responseJson($status, 200, $message, $data);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function getHomePageBanner()
    {
        try {
            $isBanners = AppBanner::where('is_active', 1)->orderby('position', 'asc')->get();
            $status = $isBanners->isNotEmpty();
            $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.fail');
            $data = $status ? MasterResource::collection($isBanners) : [];
            return $this->responseJson($status, 200, $message, $data);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function getTruckTypes()
    {
        try {
            $isTruckTypes = TruckType::get();
            $status = $isTruckTypes->isNotEmpty();
            $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.fail');
            $truckTypesResource = $status
                ? TruckTypeResource::collection($isTruckTypes)
                : [];

            return $this->responseJson($status, 200, $message, $truckTypesResource);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getBanners()
    {
        try {
            $isBanners = AppBanner::withoutGlobalScope(ActiveScope::class)->get();
            $status = $isBanners->isNotEmpty();
            $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.fail');
            $truckTypesResource = $status
                ? MasterResource::collection($isBanners)
                : [];

            return $this->responseJson($status, 200, $message, $truckTypesResource);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function changeLanguage(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'language' => 'required|in:1,2',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $updateLanguage = auth()->user()->update([
                'language' => $request->language
            ]);
            if ($updateLanguage) {
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
            }
            return $this->responseJson(false, 200, config('services.responseMessages.post.fail'));
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function sosReasons()
    {
        try {
            $isSosReasons = SosReason::get();
            $status = $isSosReasons->isNotEmpty();
            $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.fail');
            $sosReasons = $status
                ? $isSosReasons
                : [];

            return $this->responseJson($status, 200, $message, $sosReasons);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function cancellationReasons()
    {
        try {
            $isCancellationReasons = CancellationReason::get();
            $status = $isCancellationReasons->isNotEmpty();
            $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.fail');
            $cancellationReasons = $status
                ? $isCancellationReasons
                : [];

            return $this->responseJson($status, 200, $message, $cancellationReasons);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getMaterials()
    {
        // Fetch materials and sort them in ascending order
        $isMaterials = Material::orderBy('title', 'asc')->get(); // Assuming 'name' is the column to sort by

        // Check if materials are not empty
        $status = $isMaterials->isNotEmpty();
        $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.enough');

        // Sort materials to move "other" to the end
        if ($status) {
            $materials = $isMaterials->sort(function ($a, $b) {
                if ($a->title == 'Other') {
                    return 1; // Move 'other' to the end
                }
                if ($b->title == 'Other') {
                    return -1; // Keep 'other' at the end
                }
                return 0; // No change
            });
        } else {
            $materials = [];
        }

        return $this->responseJson($status, 200, $message, MasterResource::collection($materials));
    }

    public function getEquipment()
    {
        $isEquipment = Equipment::get();
        $status = $isEquipment->isNotEmpty();
        $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.enough');
        $equipments = $status ? MasterResource::collection($isEquipment) : [];
        return $this->responseJson($status, 200, $message, $equipments);
    }
    public function getLoadTypes()
    {
        $isLoadType = LoadType::where('slug', '!=', 'hour')->get();
        $status = $isLoadType->isNotEmpty();
        $message = $status ? config('services.responseMessages.get.succ') : config('services.responseMessages.get.enough');
        $loadTypes = $status ? MasterResource::collection($isLoadType) : [];
        return $this->responseJson($status, 200, $message, $loadTypes);
    }

    public function getLiveJobCordinates(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'latitude' => 'required',
            'longitude' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $currentDate = date("Y-m-d H:i:s");
            $latitude = $request->latitude != null ? $request->latitude :  '';
            $longitude = $request->longitude != null ? $request->longitude :  '';
            $distance = config('constants.DEFAULT_DISTANCE_BETWEEN_USER_AND_JOBS');
            $getJobDetails = $this->getJobsWithinDistance($latitude, $longitude, $distance, $currentDate);
            if (!empty($getJobDetails)) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), JobResource::collection($getJobDetails));
            }
            return $this->responseJson(true, 200, config('services.responseMessages.get.fail'));
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function addRatingReview(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'rating'  => 'required',
            'comment' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $jobDetails = Job::find($request->job_id);
            $addRatingAndReview = Feedback::create([
                'comment' => $request->comment,
                'rating'  => $request->rating,
                'sender_id' => $jobDetails->user_id,
                'receiver_id' => $jobDetails->user_id,
                'given_by' => auth()->user()->id,
                'given_to' => $jobDetails->user_id,
                'job_id'     => $request->job_id,
                'load_id'     => $request->load_id
            ]);
            if ($addRatingAndReview) {
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
            }
            return $this->responseJson(true, 200, config('services.responseMessages.post.fail'));
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function addReviewByContractor(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'rating'  => 'required',
            'comment' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            //get load completed trucker id
            $loadDetails = Load::find($request->load_id);
            $jobDetails = Job::find($request->job_id);
            $addRatingAndReview = Feedback::create([
                'comment' => $request->comment,
                'rating'  => $request->rating,
                'sender_id' => $jobDetails->user_id,
                'receiver_id' => $jobDetails->user_id,
                'given_by' => auth()->user()->id,
                'given_to' => $loadDetails->user_id,
                'job_id'     => $request->job_id,
                'load_id'     => $request->load_id
            ]);
            if ($addRatingAndReview) {
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
            }
            return $this->responseJson(true, 200, config('services.responseMessages.post.fail'));
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getNotification()
    {

        $isNotification = Notification::where(['user_id' => auth()->user()->id, 'is_for_job' => 0])->latest()->get();
        if ($isNotification->isNotEmpty()) {
            $this->updateNotificationIsRead(auth()->user()->id, false);
            return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), $isNotification);
        }
        return $this->responseJson(true, 200, config('services.responseMessages.get.fail'));
    }
    public function getJobWiseNotification()
    {
        $isNotification = Notification::where(['user_id' => auth()->user()->id, 'is_for_job' => 1])->latest()->get();
        if ($isNotification->isNotEmpty()) {
            $notification = NotificationResource::collection($isNotification);
            $this->updateNotificationIsRead(auth()->user()->id, true);
            return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), $notification);
        }
        return $this->responseJson(true, 200, config('services.responseMessages.get.fail'));
    }
    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required',
            'confirm_password' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $user = auth()->user();
            // check with old password
            if (Hash::check($request->old_password, $user->password)) {
                // update current password
                if ($request->new_password == $request->confirm_password) {
                    $password = bcrypt($request->new_password);
                    $isPasswordUpdated = auth()->user()->update([
                        'password' => $password
                    ]);
                    if ($isPasswordUpdated) {
                        return $this->responseJson(true, 200, 'password is changed');
                    }
                    return $this->responseJson(false, 200, 'password is not changed');
                } else {
                    return $this->responseJson(false, 200, 'new password and confirm password must be same');
                }
            } else {
                return $this->responseJson(false, 200, 'old password not matched');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function updateNotificationIsRead($userId, $isJobRelated)
    {
        $query = Notification::where(['user_id' => $userId, 'is_read' => 0]);

        if ($isJobRelated) {
            $query->where('is_for_job', 1);
        } else {
            $query->where('is_for_job', 0);
        }

        $isNotificationRead = $query->update(['is_read' => 1]);

        return (bool) $isNotificationRead;
    }
    // private function remainingPaymentDays($userId)
    // {
    //     // Get current date and time
    //     $currentDate = Carbon::now();

    //     // Fetch pending payment loads for the user
    //     $isPaymentPending = Load::whereHas('job', function ($query) use ($userId) {
    //         $query->where('user_id', $userId);
    //     })->where('is_payment_initiated', 1)->get();
    //     if ($isPaymentPending->isNotEmpty()) {
    //         $paymentLinkGeneratedAt = $isPaymentPending->first()->updated_at ?? null;
    //         if ($paymentLinkGeneratedAt) {
    //             // Parse the paymentLinkGeneratedAt and currentDate
    //             $paymentLinkGeneratedAtDateTime = new DateTime($paymentLinkGeneratedAt);
    //             $currentDateTime = new DateTime($currentDate);

    //             // Calculate the interval (days elapsed)
    //             $interval = $currentDateTime->diff($paymentLinkGeneratedAtDateTime);
    //             $daysElapsed = $interval->days;
    //             // Calculate remaining days in the 30-day payment window
    //             $daysRemaining = 3 - $daysElapsed;
    //             // $daysRemaining = -1;

    //             // Determine if the user can post a job (true or false)
    //             $canPostJob = $daysRemaining >= 1 ? true : false;

    //             // Return both values
    //             return $canPostJob;
    //         }
    //     }

    //     // If no payment is pending, return null for all values
    //     return true;
    // }
    private function remainingPaymentDays($userId)
    {
        // Get current date and time
        $currentDate = Carbon::now();
        $user = User::find($userId);
        // Fetch pending payment loads for the user
        $isPaymentPending = Load::whereHas('job', function ($query) use ($userId) {
            $query->where('user_id', $userId);
        })->where('status', 4)
            ->where('is_payment_initiated', 0)
            ->exists();
        $paymentTermsDays = PaymentTerms::where('user_id', $userId)->first()->pay_in ?? 0;
        $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at);
        $intervalInDays = $lastPaidAt->diffInDays($currentDate);

        // return $isPaymentPending && ($intervalInDays >= $paymentTermsDays) ? false : true;
        return $isPaymentPending;
    }
    public function getJobLoads(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $loads = Load::where('job_id', $request->job_id)->paginate(10)->appends($request->except('page'));
            return new LoadResourceCollection($loads);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function getCityCoordinates(Request $request)
    {
        // Get Google API key from config
        $apiKey = env('GOOGLE_API_KEY');

        try {
            // Make request to Google Geocoding API
            $response = Http::timeout(10)->get('https://maps.googleapis.com/maps/api/geocode/json', [
                'address' => "{$request->city}, {$request->state}",
                'key' => $apiKey
            ]);

            if ($response->successful()) {
                $data = $response->json();

                if ($data['status'] === 'OK' && !empty($data['results'])) {
                    $result = $data['results'][0];
                    $location = $result['geometry']['location'];

                    $coordinates = [
                        'city' => $request->city,
                        'state' => $request->state,
                        'latitude' => $location['lat'],
                        'longitude' => $location['lng'],
                        'formatted_address' => $result['formatted_address'],
                        'place_id' => $result['place_id'] ?? null,
                        'types' => $result['types'] ?? []
                    ];

                    return $coordinates;
                }

                // Handle API errors
                if ($data['status'] === 'ZERO_RESULTS') {
                    return null; // No results found
                }

                throw new \Exception("Google API Error: " . $data['status']);
            }

            throw new \Exception("HTTP Error: " . $response->status());
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function appVersionUpdate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'required|in:1,2,3',
            'version' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $platformType = $request->type;
            $version = $request->version;

            // If only 'type' is provided, return the latest version for the platform
            if (!$version) {
                $latestVersion = AppVersion::where('platform_type', $platformType)
                    ->latest('id') // or created_at if you prefer
                    ->first();

                if ($latestVersion) {
                    return $this->responseJson(true, 200, 'Latest version retrieved successfully', $latestVersion);
                } else {
                    return $this->responseJson(false, 404, 'No version found for this platform.');
                }
            }

            // Check if this version is already recorded
            $existing = AppVersion::where('platform_type', $platformType)
                ->where('version', $version)
                ->first();

            if (!$existing) {
                $record = AppVersion::where('platform_type', $platformType)->first();

                if ($record) {
                    $record->update([
                        'version' => $version
                    ]);
                } else {
                    $record = AppVersion::create([
                        'platform_type' => $platformType,
                        'version' => $version
                    ]);
                }
            } else {
                $record = $existing;
            }

            return $this->responseJson(true, 200, 'Version processed successfully', $record);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }

    public function getAppFaqs()
    {
        try {
            // get the FAQs
            $isFaqs = Faq::where('is_active', 1)->orderBy('position')->get();
            $status = $isFaqs->isNotEmpty();
            $message = $status ? "FAQs found" : "FAQs not found";
            return $this->responseJson($status, 200, $message, $isFaqs);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function sendPayout()
    {
        try {
            // $firstBankToken = "ba_1RiZe9JkoYtFflHHhbyRtc9X";
            // $secondBankToken = "ba_1RirUoJkoYtFflHHlKW23m3D";
            // $stripe = new StripeClient(env('STRIPE_SECRET_KEY','sk_test_51HQXnUJkoYtFflHHtXDXdNB5111TXKJrBpFCJIQikTnMrL7IHxLJyYXxeuvLXju3bTCYSTcEH5grkgqGNwLEp0NC00WWZHGHAV'));
            // $payout = $stripe->payouts->create([
            //     'amount' => 100,       // $10.00 in cents
            //     'currency' => 'usd',
            //     'destination' => $secondBankToken,  // Your bank account ID
            //     'method' => 'instant',  // or 'standard' for regular payout
            //     'statement_descriptor' => 'COMPANY PAYOUT' // Appears on bank statement
            // ]);
            $acc = "acct_1RiuKOR72oAp28yh";
            $amount = 100;
            $isPayout = $this->createPayoutToConnectAccount($acc, $amount);
            dd($isPayout);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function deleteUser(Request $request)
    {
        try {
            $user = auth()->user();
            // ->activeJobs()->activeJobs?->count();
            if ($user->user_type == 3 && $user->activeJobs()?->count() <= 0) {
                auth()->user()->update(['email' => auth()->user()->email . '@deleted', 'mobile_number' => date('YmdHis')]);
                Token::where('user_id', auth()->user()->id)->update(['revoked' => true]);
            } else if ($user->user_type == 4 && $user->activeLoads?->count() <= 0) {
                auth()->user()->update(['email' => auth()->user()->email . '@deleted', 'mobile_number' => date('YmdHis')]);
                Token::where('user_id', auth()->user()->id)->update(['revoked' => true]);
            } else {
                return $this->responseJson(false, 200, 'You have active jobs or loads. Please complete them before deleting your account.');
            }
            return $this->responseJson(true, 200, 'Your account has been deleted successfully.');
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 404, 'User not found');
        }
    }

    public function isReadyForJob(Request $request)
    {
        $user = auth()->user();
        $userRole = $user->roles[0]->slug;

        // Initialize response structure
        $response = [
            'is_ready_for_job' => false,
            'is_approved_by_admin' => false,
            'is_payment_needed' => false,
            'interval_in_days' => 0,
            'is_bank_details_updated' => false,
            'is_kyc_updated' => null,
            'kyc_update_link' => null,
            'message' => ''
        ];

        switch ($userRole) {
            case 'contractor':
            case 'sub-contractor':
                return $this->handleContractorStatus($user, $response);

            case 'independent':
                return $this->handleIndependentStatus($user, $response);

            default:
                $response['message'] = 'Please wait for document verification';
                return $this->responseJson(true, 200, $response['message'], $response);
        }
    }

    private function handleContractorStatus($user, $response)
    {
        // Remove KYC-related keys for contractors as they don't apply
        unset($response['is_kyc_updated'], $response['kyc_update_link']);

        if ($user->is_blocked) {
            return $this->handleBlockedContractor($user, $response);
        }
        $response['is_approved_by_admin'] = $user->is_blocked ? false : true;
        return $this->handleActiveContractor($user, $response);
    }

    private function handleBlockedContractor($user, $response)
    {
        $paymentData = $this->getContractorPaymentData($user);

        $response['interval_in_days'] = $paymentData['interval_in_days'];
        $response['is_payment_needed'] = $paymentData['is_payment_needed'];
        $response['message'] = 'Your Payment terms are not verified yet. Please wait for admin approval.';

        return $this->responseJson(true, 200, $response['message'], $response);
    }

    private function handleActiveContractor($user, $response)
    {
        $paymentTerms = PaymentTerms::where('user_id', $user->id)->first();
        if (!$paymentTerms) {
            $response['message'] = 'Payment terms not configured. Please contact support.';
            return $this->responseJson(true, 200, $response['message'], $response);
        }

        $paymentData = $this->getContractorPaymentData($user, $paymentTerms);
        $response['interval_in_days'] = $paymentData['interval_in_days'];
        $response['is_payment_needed'] = $paymentData['is_payment_needed'];

        // Check if contractor can post a job
        if (!$this->remainingPaymentDays($user->id)) {
            $response['is_ready_for_job'] = true;
            $response['message'] = 'You are ready to post a job';
        } elseif ($paymentData['is_payment_needed']) {
            $response['message'] = 'Your payment is due. Please settle before posting a new job.';
        } else {
            $response['message'] = 'You are not eligible to post a job at this time.';
        }

        return $this->responseJson(true, 200, $response['message'], $response);
    }

    private function handleIndependentStatus($user, $response)
    {
        $isDocumentVerified = $user->is_ready_for_job == 1;
        $hasBankDetails = $user->stripe_bank_acc_id !== null;
        $hasStripeAccount = $user->stripe_account_id !== null;

        // Initialize stripe account status variables
        $isStripeAccountActive = false;
        $kycUpdationLink = null;

        // Check Stripe account status only if both stripe_account_id and stripe_bank_acc_id exist
        if ($hasStripeAccount && $hasBankDetails) {
            try {
                $isStripeAccountActive = $this->checkStripeAccountStatus($user->stripe_account_id);

                // Generate KYC update link if stripe account is not active
                if (!$isStripeAccountActive) {
                    $kycUpdationLink = $this->generateAccountLink($user->stripe_account_id, $user->device_type);
                }
            } catch (\Exception $e) {
                // Handle API errors gracefully
                logger('Stripe account status check failed', [
                    'user_id' => $user->id,
                    'stripe_account_id' => $user->stripe_account_id,
                    'error' => $e->getMessage()
                ]);
                $isStripeAccountActive = false;
                $kycUpdationLink = $this->generateAccountLink($user->stripe_account_id, $user->device_type);
            }
        } elseif ($hasStripeAccount && !$hasBankDetails) {
            // Has Stripe account but no bank details - need KYC update
            try {
                $kycUpdationLink = $this->generateAccountLink($user->stripe_account_id, $user->device_type);
            } catch (\Exception $e) {
                logger('Failed to generate account link', [
                    'user_id' => $user->id,
                    'stripe_account_id' => $user->stripe_account_id,
                    'error' => $e->getMessage()
                ]);
            }
        }

        // Set KYC status and link in response
        if ($hasStripeAccount) {
            $response['is_kyc_updated'] = $isStripeAccountActive;
            $response['kyc_update_link'] = $kycUpdationLink; // null if KYC is updated, link if not
        } else {
            $response['is_kyc_updated'] = false;
            $response['kyc_update_link'] = null; // No Stripe account to update
        }

        // Determine user status based on verification and Stripe account state
        if ($isDocumentVerified && $isStripeAccountActive) {
            // Fully verified and ready
            $response['is_ready_for_job'] = true;
            $response['is_bank_details_updated'] = true;
            $response['is_approved_by_admin'] = true;
            $response['message'] = 'You are ready to accept the job';
        } elseif ($isDocumentVerified && $hasBankDetails && !$isStripeAccountActive) {
            // Document verified, has bank details, but Stripe account needs attention
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = true;
            $response['is_approved_by_admin'] = true;
            $response['message'] = 'Please Complete Your Personal and working details verification to accept jobs.';
        } elseif ($isDocumentVerified && $hasStripeAccount && !$hasBankDetails) {
            // Document verified, has Stripe account, but no bank details
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = false;
            $response['is_approved_by_admin'] = true;
            $response['message'] = 'Please complete your bank account setup to accept jobs.';
        } elseif ($isDocumentVerified && !$hasStripeAccount) {
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = false;
            $response['is_approved_by_admin'] = true;
            $response['message'] = 'add your bank details to accept jobs.';
        } elseif (!$isDocumentVerified && $hasBankDetails && $isStripeAccountActive) {
            // Stripe setup complete but documents not verified
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = true;
            $response['is_approved_by_admin'] = false;
            $response['message'] = "You're on track! Once the Safety Department verifies your documents, you'll be able to start accepting jobs";
        } elseif (!$isDocumentVerified && ($hasStripeAccount || $hasBankDetails)) {
            // Partial Stripe setup but documents not verified
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = $hasBankDetails;
            $response['is_approved_by_admin'] = false;
            $response['message'] = 'Please wait for document verification and complete payment setup.';
        } else {
            // No document verification and no Stripe setup
            $response['is_ready_for_job'] = false;
            $response['is_bank_details_updated'] = false;
            $response['is_approved_by_admin'] = false;
            $response['message'] = 'Please wait for document verification.';
        }

        return $this->responseJson(true, 200, $response['message'], $response);
    }

    // private function getContractorPaymentData($user, $paymentTerms = null)
    // {
    //     $paymentTerms = $paymentTerms ?? PaymentTerms::where('user_id', $user->id)->first();
    //     // Set timezone to Chicago
    //     $tz = 'America/Chicago';

    //     $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at);
    //     $currentDate = Carbon::now();
    //     $intervalInDays = $lastPaidAt->diffInDays($currentDate);
    //     // Single optimized query for completed job loads
    //     $completedJobLoads = Load::whereHas('job', function ($query) use ($user, $lastPaidAt, $currentDate, $paymentTerms) {
    //         $query->where('user_id', $user->id);

    //         // Apply date filter only if payment terms exist and pay_in > 0
    //         // if ($paymentTerms && $paymentTerms->pay_in > 0) {
    //         //     $query->whereBetween('created_at', [$lastPaidAt, $currentDate]);
    //         // }
    //     })
    //         ->where('status', 4)
    //         ->where('is_payment_initiated', "!=", 2)
    //         ->exists(); // Use exists() instead of get() for better performance
    //     $payInDays = $paymentTerms->pay_in ?? 0;
    //     $isPaymentNeeded = $completedJobLoads && $intervalInDays >= $payInDays;

    //     return [
    //         'interval_in_days' => $intervalInDays,
    //         'is_payment_needed' => $isPaymentNeeded,
    //         'has_completed_loads' => $completedJobLoads
    //     ];
    // }
    // private function getContractorPaymentData($user, $paymentTerms = null)
    // {
    //     $paymentTerms = $paymentTerms ?? PaymentTerms::where('user_id', $user->id)->first();
    //     // Set timezone to Chicago
    //     $tz = 'America/Chicago';

    //     // Convert last paid date or user creation date to Carbon object in Chicago time
    //     $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at)->setTimezone($tz);
    //     // Current time in Chicago timezone
    //     $currentDate = Carbon::now($tz);
    //     // Get midnight today in Chicago timezone
    //     $midnightToday = Carbon::now($tz)->startOfDay();

    //     // Check if a job was completed since midnight (today)
    //     $completedJobLoads = Load::whereHas('job', function ($query) use ($user) {
    //         $query->where('user_id', $user->id);
    //     })
    //         ->where('status', 4)
    //         ->where('is_payment_initiated', '!=', 2)
    //         // ->where('created_at', '>=', $midnightToday->copy()->setTimezone('UTC')) // important: DB timestamps are likely in UTC
    //         ->exists();

    //     // Compute difference in days from last payment
    //     $intervalInDays = $lastPaidAt->diffInDays($currentDate);

    //     // Set payment needed to true if jobs completed after midnight
    //     $isPaymentNeeded = $completedJobLoads && $intervalInDays >= $paymentTerms->pay_in;
    //     return [
    //         'interval_in_days' => $intervalInDays,
    //         'is_payment_needed' => $isPaymentNeeded,
    //         'has_completed_loads' => $completedJobLoads
    //     ];
    // }
    private function getContractorPaymentData($user, $paymentTerms = null)
    {
        $paymentTerms = $paymentTerms ?? PaymentTerms::where('user_id', $user->id)->first();
        // Set timezone to Chicago
        $tz = 'America/Chicago';

        // Convert last paid date or user creation date to Carbon object in Chicago time
        $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at)->setTimezone($tz);
        // Current time in Chicago timezone
        $currentDate = Carbon::now($tz);
        // Get midnight today in Chicago timezone
        $midnightToday = Carbon::now($tz)->startOfDay();

        // Check if a job was completed since midnight (today)
        $completedJobLoads = Load::whereHas('job', function ($query) use ($user) {
            $query->whereIn('user_id', getSubContractorWithMainContractorIds($user->id));
        })
            ->where('status', 4)
            ->where('is_payment_initiated', '!=', 2)
            // ->where('created_at', '>=', $midnightToday->copy()->setTimezone('UTC')) // important: DB timestamps are likely in UTC
            ->exists();

        // Compute difference in days from last payment
        $intervalInDays = $lastPaidAt->diffInDays($currentDate);

        // Set payment needed to true if jobs completed after midnight
        $isPaymentNeeded = $completedJobLoads;
        return [
            'interval_in_days' => $intervalInDays,
            'is_payment_needed' => $isPaymentNeeded,
            'has_completed_loads' => $completedJobLoads
        ];
    }

    public function myActiveJobCordinates(Request $request)
    {
        try {
            $currentDate = date("Y-m-d H:i:s");
            $getJobDetails = $this->getMyJobs($currentDate);
            if (!empty($getJobDetails)) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), JobResource::collection($getJobDetails));
            }
            return $this->responseJson(true, 200, config('services.responseMessages.get.fail'));
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }


    // stripe payout and account balence transfer related methods


    public function getStripeAccountBalance()
    {
        try {
            // dd("here");
            $balence = $this->getAccountBalence();
            dd($balence);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function transferMoneyToConnectedAccount(Request $request)
    {
        $user = auth()->user();
        $amount = 100;
        if (!$user->stripe_account_id) {
            return response()->json([
                'success' => false,
                'message' => 'User does not have a connected Stripe account'
            ], 400);
        }

        // Convert amount to cents
        $amountInCents = round($amount * 100);

        // Create transfer
        $result = $this->transferToConnectedAccount(
            $user->stripe_account_id,
            $amountInCents,
            'usd',
            [
                'user_id' => $user->id,
                'transfer_reason' => 'Trucker Payment'
            ]
        );

        if ($result['success']) {
            // Optionally save transfer record to database
            $this->saveTransfer($user->id, $result);

            return response()->json([
                'success' => true,
                'message' => 'Transfer completed successfully',
                'transfer_id' => $result['transfer_id'],
                'amount' => $result['amount'] / 100,
                'currency' => $result['currency'],
                'destination' => $result['destination']
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Transfer failed',
            'error' => $result['error']
        ], 400);
    }

    /**
     * Transfer to connected account and then payout to bank
     */
    public function transferAndPayoutMoney()
    {

        $user = auth()->user();
        $amount = 100;
        if (!$user->stripe_account_id) {
            return response()->json([
                'success' => false,
                'message' => 'User does not have a connected Stripe account'
            ], 400);
        }

        // Convert amount to cents
        $amountInCents = round($amount * 100);
        // Transfer and payout
        $result = $this->transferAndPayout(
            $user->stripe_account_id,
            $amountInCents,
            $user->stripe_bank_acc_id,
            'usd',
            [
                'user_id' => $user->id,
                'operation' => 'transfer_and_payout'
            ]
        );

        if ($result['success']) {
            return response()->json([
                'success' => true,
                'message' => 'Transfer and payout completed successfully',
                'transfer_id' => $result['transfer_id'],
                'payout_id' => $result['payout_id'],
                'amount' => $result['amount'] / 100,
                'currency' => $result['currency']
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Transfer and payout failed',
            'error' => $result['error'],
            'transfer_completed' => $result['transfer_completed'] ?? false
        ], 400);
    }

    /**
     * Get platform balance
     */
    public function getStripeMainPlatformBalance()
    {
        $result = $this->getStripePlatformBalance();

        if ($result['success']) {
            $balances = collect($result['available'])->map(function ($balance) {
                return [
                    'currency' => $balance['currency'],
                    'amount' => $balance['amount'] / 100,
                    'amount_cents' => $balance['amount']
                ];
            });

            return response()->json([
                'success' => true,
                'available_balances' => $balances
            ]);
        }

        return response()->json([
            'success' => false,
            'error' => $result['error']
        ], 400);
    }

    /**
     * Get connected account balance
     */
    public function getConnectedUserAccountBalance(Request $request)
    {
        $user = auth()->user();

        $result = $this->getConnectedAccountBalance($user->stripe_account_id);

        if ($result['success']) {
            $balances = collect($result['available'])->map(function ($balance) {
                return [
                    'currency' => $balance['currency'],
                    'amount' => $balance['amount'] / 100,
                    'amount_cents' => $balance['amount']
                ];
            });

            return response()->json([
                'success' => true,
                'available_balances' => $balances
            ]);
        }

        return response()->json([
            'success' => false,
            'error' => $result['error']
        ], 400);
    }

    /**
     * Get transfer history
     */
    public function getTransferHistory(Request $request)
    {
        // $request->validate([
        //     'limit' => 'nullable|integer|min:1|max:100'
        // ]);
        $user = auth()->user();
        $limit = $request->limit ?? 10;
        $destination = null;

        $destination = $user->stripe_account_id;

        $result = $this->listTransfers($limit, $destination);

        if ($result['success']) {
            $transfers = collect($result['data']->data)->map(function ($transfer) {
                return [
                    'id' => $transfer->id,
                    'amount' => $transfer->amount / 100,
                    'currency' => $transfer->currency,
                    'destination' => $transfer->destination,
                    'created' => date('Y-m-d H:i:s', $transfer->created),
                    'metadata' => $transfer->metadata
                ];
            });

            return response()->json([
                'success' => true,
                'transfers' => $transfers
            ]);
        }

        return response()->json([
            'success' => false,
            'error' => $result['error']
        ], 400);
    }

    /**
     * Save transfer record (optional)
     */
}
