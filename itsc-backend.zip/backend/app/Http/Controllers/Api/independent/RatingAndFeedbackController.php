<?php

namespace App\Http\Controllers\Api\independent;

use App\Models\Feedback;
use Faker\Provider\Base;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\Auth\RatingCollection;

class RatingAndFeedbackController extends BaseController
{
    public function myReviews(Request $request){
        $getRatingDetails = Feedback::where('given_to',auth()->user()->id)->latest()->paginate(10)->appends($request->except('page'));
        return new RatingCollection($getRatingDetails);
    }
}
