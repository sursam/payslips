<?php

namespace App\Http\Controllers\Api\independent;

use App\Models\Job;
use App\Models\Load;
use App\Models\User;
use App\Models\SosLog;
use App\Models\CancelJob;
use App\Traits\UploadAble;
use App\Models\JobActivity;
use App\Models\LoadActivity;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\JobConfigureMap;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use App\Traits\PushNotificationTrait;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\Auth\JobResource;
use App\Http\Resources\Api\Auth\AcceptedJobResource;
use App\Http\Resources\Api\Auth\CompletedJobDetails;
use App\Http\Resources\Api\Auth\JobResourceCollection;
use App\Http\Resources\Api\Auth\CompletedJobCollection;
use App\Http\Resources\Api\Auth\RunningJobLoadResource;
use App\Http\Resources\Api\Auth\AcceptedJobLoadResource;

class JobController extends BaseController
{
    use UploadAble;
    use PushNotificationTrait;
    public function manageJob(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:1,2,3,4,5,6',
            'currentDateTime' => 'required|date_format:Y-m-d H:i:s'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            $jobs = [];
            $job = new Job();
            $truckerLatitude = auth()->user()->latitude;
            $truckerLongitude = auth()->user()->longitude;
            $distance = $request->radius ?: config('constants.DEFAULT_DISTANCE_BETWEEN_USER_AND_JOBS');
            $truckTypeId = auth()->user()->truckDetails->truck_type_id ?? null;

            if ($request->status == 1) {    // new / ongoing
                $jobs = $this->getJobsWithinDistanceAndTruckTypes($truckerLatitude, $truckerLongitude, $distance, $request->currentDateTime, $request->status, $truckTypeId);
            } else if ($request->status == 2) {      // hidden jobs
                $jobs = $this->getHiddenJobs($truckerLatitude, $truckerLongitude, $distance, $request->currentDateTime);
            } else if ($request->status == 3) {     // accepted jobs
                $jobs = $job->whereHas('jobLoad', function ($query) {
                    $query->where('user_id', auth()->user()->id)->whereIn('status', [1, 2, 3]);
                })->get();

                if ($jobs) {
                    return $this->responseJson(true, 200, 'accepted job found', AcceptedJobResource::collection($jobs));
                }
                return $this->responseJson(false, 200, 'no accepted jobs found');
            } else if ($request->status == 4) {
                $jobs = $job->where('delivery_date_time', '<', $request->currentDateTime);
            } else if ($request->status == 6) {
                $jobs = $job->where(['status' => 1, 'is_draft' => 1]);
            } else {
                $jobs = $job->where('status', 4);
            }

            // Apply pagination only if the 'page' parameter is present
            if ($request->has('page')) {
                $jobs = $jobs->latest()->paginate(10)->appends($request->except('page'));
                return new JobResourceCollection($jobs);
            } else {
                // If no pagination, just get the latest jobs without pagination
                $jobs = $jobs->latest()->get();
                return $this->responseJson(true, 200, 'jobs found', JobResource::collection($jobs));
            }
        } catch (\Exception $e) {
            // Rollback the transaction on error
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function acceptedJobLoad()
    {
        $acceptedJob = Load::where('user_id', auth()->user()->id)->where('status', '!=', 4)->first();
        if ($acceptedJob) {
            return $this->responseJson(true, 200, 'accepted job found', new AcceptedJobLoadResource($acceptedJob));
        }
        return $this->responseJson(false, 200, 'no accepted job found', (object)[]);
    }
    private function getJobsWithinDistanceAndTruckTypes($latitude, $longitude, $distance, $currentDateTime, $status, $truckTypeId = null)
    {
        // Define the radius of the Earth in kilometers
        $earthRadius = 6371;

        // Calculate the angular distance in radians
        $angularDistance = $distance / $earthRadius;

        // Convert latitude and longitude from degrees to radians
        $latitudeRadians = deg2rad($latitude);
        $longitudeRadians = deg2rad($longitude);

        // Calculate minimum and maximum latitude and longitude
        $minLatitude = $latitudeRadians - $angularDistance;
        $maxLatitude = $latitudeRadians + $angularDistance;

        $minLongitude = $longitudeRadians - $angularDistance;
        $maxLongitude = $longitudeRadians + $angularDistance;

        // Perform the query
        $jobsWithinDistance = Job::select('*')->where('is_draft', 0)->where(function ($q) use ($currentDateTime, $status) {
            $q->where('delivery_date_time', '>=', $currentDateTime)->where('status', $status);
        })
            ->selectRaw(
                '(6371 * acos(cos(radians(?)) * cos(radians(source_lat)) * cos(radians(source_lng) - radians(?)) + sin(radians(?)) * sin(radians(source_lat)))) AS distance',
                [$latitude, $longitude, $latitude]
            )
            ->where(function ($que) {
                $que->whereHas('jobActivity', function ($query) {
                    $query->where('user_id', auth()->user()->id)
                        ->where('is_showed', 0);
                })->orWhereDoesntHave('jobActivity', function ($subQuery) {
                    $subQuery->where('user_id', auth()->user()->id);
                });
            })
            ->having('distance', '<=', $distance);
        if (!empty($jobsWithinDistance)) {
            return $jobsWithinDistance;
        }
        return [];
    }
    private function getHiddenJobs($latitude, $longitude, $distance, $currentDateTime, $status = null)
    {
        $jobsWithinDistance = Job::where('delivery_date_time', '>=', $currentDateTime)
            ->where('status', 1)
            ->whereHas('jobActivity', function ($query) {
                $query->where(['user_id' => auth()->user()->id, 'is_showed' => 1]);
            });
        if (!empty($jobsWithinDistance)) {
            return $jobsWithinDistance;
        }
        return [];
    }
    private function acceptedJobDetails($userId)
    {
        $acceptedJob = Job::whereHas('jobLoad', function ($query) {
            $query->where('user_id', auth()->user()->id)->whereIn('status', [1, 2, 3]);
        });
    }
    private function acceptedJob($userId)
    {
        $acceptedJob = Job::whereHas('jobLoad', function ($query) {
            $query->where('user_id', auth()->user()->id)->whereIn('status', [1, 2, 3]);
        })->first();
        if ($acceptedJob) {
            return $acceptedJob;
        }
        return (object)[];
    }
    public function showHideJob(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        try {
            // Get the current user's ID
            $userId = auth()->user()->id;

            // Check if the job activity exists
            $jobActivity = JobActivity::where(['job_id' => $request->job_id, 'user_id' => $userId])->first();
            $message = '';
            if ($jobActivity) {
                // Toggle the is_showed status
                $jobActivity->is_showed = !$jobActivity->is_showed;
                $jobActivity->save();
                $message = "Job unhide";
            } else {
                // If no row exists, create a new JobActivity with is_showed set to 1
                JobActivity::create([
                    'job_id' => $request->job_id,
                    'user_id' => $userId,
                    'is_showed' => 1,
                ]);
                $message = "Job hidden";
            }

            return $this->responseJson(true, 200, $message);
        } catch (\Exception $e) {
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function acceptLoad(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        // Start a transaction with a higher isolation level
        DB::beginTransaction();

        try {
            // Lock the load record to prevent concurrent modifications
            $load = Load::where('id', $request->load_id)
                ->lockForUpdate() // This is crucial for preventing race conditions
                ->first();

            // Check if the load is already assigned to another driver
            if ($load && $load->user_id !== null) {
                DB::rollBack();
                return $this->responseJson(false, 200, 'This load has already been accepted by another driver');
            }

            // job details
            $isJob = Job::find($request->job_id);

            // Check if job exists
            if (!$isJob) {
                DB::rollBack();
                return $this->responseJson(false, 200, 'Job not found');
            }

            $currentDate = Carbon::now()->format('Y-m-d');
            $jobPickupDate = Carbon::parse($isJob->pickup_date_time)->format('Y-m-d');
            if ($currentDate < $jobPickupDate) {
                $pickupDateFormatted = Carbon::parse($isJob->pickup_date_time)->format('jS F Y');
                DB::rollBack();
                return $this->responseJson(false, 200, "Patience! This job becomes available on $pickupDateFormatted");
            }

            // Get truck type ID
            $truckTypeId = auth()->user()->truckDetails->truck_type_id ?? null;

            // Check if driver is already assigned to another active load
            $isAlreadyInAJob = Load::where('user_id', auth()->user()->id)
                ->where('status', '!=', 4)
                ->exists();

            if ($isAlreadyInAJob) {
                DB::rollBack();
                return $this->responseJson(false, 200, 'You have already accepted one load of a job');
            }

            // Check if the load is available for the job and matches the truck type
            $isLoadAvailable = Load::where('id', $request->load_id)
                ->whereNull('user_id')
                ->whereHas('job', function ($query) use ($truckTypeId) {
                    $query->whereRaw('FIND_IN_SET(?, truck_type_ids)', [$truckTypeId]);
                })
                ->first();

            if (!$isLoadAvailable) {
                DB::rollBack();
                return $this->responseJson(false, 200, 'You do not have a suitable truck to perform this job or the load is no longer available');
            }

            // Generate a 6-digit token
            $token = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
            // Update or create job configure map
            JobConfigureMap::updateOrCreate(
                [
                    'user_id' => auth()->user()->id,
                    'job_id' => $request->job_id,
                    'load_id' => $request->load_id
                ],
                ['token' => $token]
            );
            

            // Create load activity record
            LoadActivity::updateOrCreate(
                [
                    'user_id' => auth()->user()->id,
                    'job_id' => $request->job_id,
                    'load_id' => $request->load_id
                ],
                [
                    'status' => 1,
                    'weight' => $isLoadAvailable->weight ?? 0
                ]
            );

            // Update the load status - assign it to the current driver
            $load->user_id = auth()->user()->id;
            $load->status = 1;
            $load->save();

            // Check if all loads for this job are now accepted
            $isAllLoadsAreAccepted = Load::where('job_id', $request->job_id)->get()->every(function ($load) {
                return $load->status == 1;
            });

            if ($isAllLoadsAreAccepted) {
                // Update the main job status to 2 (in progress) if all loads are accepted
                Job::where('id', $request->job_id)->update(['status' => 2]);
            }
            $loadIndex = calculateLoadIndex($request->job_id, $request->load_id);
            // Send push notification to contractor
            $title = 'Job Acceptance';
            $message = 'Load No. '.$loadIndex.' associated with job ID ' . $isJob->unique_id . ' has been successfully accepted by the Trucker .';
            $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
            $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);

            // Send push notification to Trucker
            $title = 'Job Acceptance';
            $message = 'You have accepted load No. '.$loadIndex.' from job ID ' . $isJob->unique_id .'.';
            $this->sendPushToTrucker(auth()->user()->id, $title, $message, auth()->user()->device_type, $isJob->id, $isJob->status);
            $this->notificationToTrucker(auth()->user()->id, $title, $message, $isJob->id);

            // Commit the transaction
            DB::commit();
            return $this->responseJson(true, 200, 'Load successfully accepted');
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback the transaction on error

            // Log the error message with more details
            logger('Error in acceptLoad: ' . $e->getMessage() . ' -- Line: ' . $e->getLine() . ' -- File: ' . $e->getFile());

            // Check if it's a deadlock or lock wait timeout
            if (strpos($e->getMessage(), 'Deadlock') !== false || strpos($e->getMessage(), 'Lock wait timeout') !== false) {
                return $this->responseJson(false, 200, 'This load is currently being processed by another request. Please try again.');
            }

            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function reachedLocation(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction(); // Start a transaction

        try {
            $isJob = Job::find($request->job_id);
            // check he accepted this load or not
            $isLoadAccepted = Load::where(['id' => $request->load_id, 'user_id' => auth()->user()->id])->first();
            if (!$isLoadAccepted && $isLoadAccepted->status != 1) {
                return $this->responseJson(false, 200, 'you already reached into location or started this job');
            }
            $updateLoadStatus = $isLoadAccepted->update(['reached_on' => date('Y-m-d H:i:s'), 'status' => 2]);
            $updateLoadActivity = LoadActivity::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 1])
                ->update(['status' => 2]);
            if ($updateLoadStatus && $updateLoadActivity) {
                // send push notification to contracter
                $title = 'Arrival at Job Location';
                $message = 'Trucker '. auth()->user()->first_name. ' '. auth()->user()->last_name .' arrived at the job site to pick up the load No. '.calculateLoadIndex($request->job_id, $request->load_id).' associated with job ID ' . $isJob->unique_id. '.';
                $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
                // send push notification to Trucker
                $title = 'Arrival at Job Location';
                $message = 'You have reached the job pickup location. Check in with the scale house or loader.';
                $this->sendPushToTrucker(auth()->user()->id, $title, $message, auth()->user()->device_type, $isJob->id, $isJob->status);
                $this->notificationToTrucker(auth()->user()->id, $title, $message, $isJob->id);
                DB::commit(); // Commit the transaction
                return $this->responseJson(true, 200, 'Successfully reached into location');
            }
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback the transaction on error
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function startJob(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'challan' => 'nullable|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'load_weight' => 'required|numeric|min:1|max:28',
        ], [
            'load_weight.required' => 'Please enter the load weight',
            'load_weight.numeric' => 'Please enter the valid load weight',
            'load_weight.min' => 'minimum 1 tons of load is required',
            'load_weight.max' => 'maximum 28 tons of load is allowed',
            'challan.mimes' => 'Upload ticket must be in jpeg,png,jpg,gif,svg format',
            'challan.max' => 'Upload ticket size must be less than 2 MB',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction(); // Start a transaction

        try {
            $isJob = Job::find($request->job_id);
            $fileName = null;
            if (!empty($request->challan)) {
                $image = $request->challan;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_CHALLAN_IMAGE_UPLOAD_PATH'), $fileName, 'public');
            }
            // check he reached into job location or not
            $isReachedLocation = Load::where(['id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 2])->first();
            if (!$isReachedLocation) {
                return $this->responseJson(false, 200, 'you have not reached into location yet');
            }
            // update started on Load 
            $updateLoad = $isReachedLocation->update(['started_on' => date('Y-m-d H:i:s'), 'trucker_taken_weight' => $request->load_weight]);
            if ($updateLoad) {
                // update challan in job configure map
                if (!empty($request->challan)) {
                    $updateChallan = JobConfigureMap::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id])
                        ->update(['challan' => $fileName]);
                }
                // update load activity
                LoadActivity::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 2])
                    ->update(
                        [
                            'weight' => $request->load_weight,
                            'started_on' => date('Y-m-d H:i:s'),
                            'status' => 3
                        ]
                    );
            }
            // send push notification to contracter
            $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
            $title = 'Job Started';
            // $message = 'The trucker ' . $truckerName . ' has started the job with the job ID. ' . $isJob->unique_id;
            $message = 'The truck driver,' . $truckerName . ', has begun the journey with the load No. ' . calculateLoadIndex($request->job_id, $request->load_id) . ' associated with the job ID: ' . $isJob->unique_id;
            $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
            $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
            // send push notification to Trucker
            $title = 'Job Started';
            $message = 'Your Job has officially started. Please proceed to the drop off location.';
            $this->sendPushToTrucker(auth()->user()->id, $title, $message, auth()->user()->device_type, $isJob->id, $isJob->status);
            $this->notificationToTrucker(auth()->user()->id, $title, $message, $isJob->id);
            DB::commit(); // Commit the transaction
            return $this->responseJson(true, 200, 'Successfully started the job');
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback the transaction on error
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function endJob(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'is_ticket_signed' => 'required|in:1,0',   // 1: signed, 0: not signed
            'challan' => 'nullable|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ], [
            'challan.mimes' => 'Upload ticket must be in jpeg,png,jpg,gif,svg format',
            'challan.max' => 'Upload ticket size must be less than 2 MB',
            'is_ticket_signed.in' => 'is_ticket_signed should be yes or no',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction(); // Start a transaction

        try {
            $ticketNo = isset($request->ticket_no) && $request->ticket_no !== null ? $request->ticket_no : null;
            $isJob = Job::find($request->job_id);
            // check he started this job or not
            $isJobStarted = Load::where(['id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 2])->first();
            if (!$isJobStarted) {
                return $this->responseJson(false, 200, 'you have not started this job yet');
            }
            // check if already requested for cancellation or not
            if ($isJobStarted->cancellation_request_id != null) {
                return $this->responseJson(false, 200, 'you have already requested for cancellation. Wait for contractor approval');
            }
            // check the ticket is signed or not 
            if ($request->is_ticket_signed == 1 && $request->challan == null) {
                $isSignedTicketUploaded = JobConfigureMap::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id])->first();
                if ($isSignedTicketUploaded->challan == null) {
                    return $this->responseJson(false, 200, 'Please upload the signed ticket');
                }
            } else if ($request->is_ticket_signed == 0 && $request->notes == null) {
                return $this->responseJson(false, 200, 'Please add notes');
            }
            $fileName = null;
            if (!empty($request->challan)) {
                $image = $request->challan;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_CHALLAN_IMAGE_UPLOAD_PATH'), $fileName, 'public');
            }
            // update started on Load 
            $updateLoad = $isJobStarted->update(['completed_on' => date('Y-m-d H:i:s'), 'status' => 3, 'ticket_no' => $ticketNo]);
            if ($updateLoad) {
                // update load activity
                LoadActivity::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 3])
                    ->update(
                        [
                            'completed_on' => date('Y-m-d H:i:s'),
                            'status' => 4
                        ]
                    );
                JobConfigureMap::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id])->update(['driver_status' => 1, 'challan_on_delivery' => $fileName, 'is_ticket_signed' => $request->is_ticket_signed, 'trucker_notes' => $request->notes]);
            }
            // send push notification to contracter
            $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
            $title = 'Job Load Delivered';
            // $message = 'Trucker ' . $truckerName . ' has delivered one load from job ID ' . $isJob->unique_id . 'at drop point';
            $message = 'Trucker ' . $truckerName . ' has successfully completed the load No. ' .calculateLoadIndex($request->job_id, $request->load_id).' associated with job ID ' . $isJob->unique_id;
            $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
            $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
            // send push notification to Trucker
            $title = 'Job Load Delivered';
            $message = 'Load successfully delivered. Wait for Contractor approval before proceeding to the next jobs.';
            $this->sendPushToTrucker(auth()->user()->id, $title, $message, auth()->user()->device_type, $isJob->id, $isJob->status);
            $this->notificationToTrucker(auth()->user()->id, $title, $message, $isJob->id);
            DB::commit(); // Commit the transaction
            return $this->responseJson(true, 200, 'Successfully ended the job');
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback the transaction on error
            // Log the error message
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function updateMyCurrentJobLocation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'latitude' => 'required',
            'longitude' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isLoad = Load::find($request->load_id);
            $isLoadIsRunning = Load::where(['id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 2])->where('started_on', '!=', null)->first();
            if (!$isLoadIsRunning) {
                return $this->responseJson(false, 200, 'you have not started this job yet or delivered this load', ['load_status' => $isLoad->status]);
            }
            $updateJobLoadDeliveryLocation = LoadActivity::where(['job_id' => $request->job_id, 'load_id' => $request->load_id, 'user_id' => auth()->user()->id, 'status' => 3])
                ->update([
                    'current_lat' => $request->latitude,
                    'current_lng' => $request->longitude
                ]);
            // if ($updateJobLoadDeliveryLocation) {
            //     return $this->responseJson(true, 200, 'Location updated successfully');
            // }
            return $this->responseJson(true, 200, 'Location updated', ['load_status' => $isLoad->status]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getCompletedJobLoads(Request $request)
    {
        $request->validate([
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
            ]);

        // Retrieve start_date and end_date from the request
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        try {
            // $completedLoad = Load::where(['user_id' => auth()->user()->id, 'status' => 4])->orderBy('id', 'desc');
            $completedLoad = Load::where(['user_id' => auth()->user()->id, 'status' => 4])->orderBy('id', 'desc');
            if ($startDate) {
                $completedLoad->whereDate('completed_on', '>=', $startDate);
            }

            if ($endDate) {
                $completedLoad->whereDate('completed_on', '<=', $endDate);
            }
            if ($completedLoad) {
                return new CompletedJobCollection($completedLoad->paginate(10)->appends($request->except('page')));
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function getCompletedJobDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        try {
            $loadDetails = Load::find($request->load_id);
            if ($loadDetails) {
                return $this->responseJson(true, 200, "data found", new CompletedJobDetails($loadDetails));
            }
            return $this->responseJson(false, 200, "no data found", (object)[]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function getRunningJob()
    {
        try {
            $runningJobLoad = Load::where(['user_id' => auth()->user()->id, 'status' => 2])->where('started_on', '!=', null)->first();
            if ($runningJobLoad) {
                return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), new RunningJobLoadResource($runningJobLoad));
            }
            return $this->responseJson(false, 200, config('services.responseMessages.get.fail'), (object)[]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function raiseSOS(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'reason' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isJob = Job::find($request->job_id);
            $isRaisedSOS = SosLog::updateOrCreate(
                [
                    'user_id' => auth()->user()->id,
                    'job_id' => $request->job_id,
                    'load_id' => $request->load_id,
                    'type'  => 1
                ],
                [
                    'reason' => $request->reason
                ]
            );
            if ($isRaisedSOS) {
                // send push notification to contracter
                $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
                $title = 'Emergency Alert: SOS';
                // $message = 'Trucker ' . $truckerName . ' has Raised SOS who taken one load from job ID ' . $isJob->unique_id;
                $message = 'A trucker issued an emergency alert SOS regarding a specific load associated with job ID ' . $isJob->unique_id;
                $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
                return $this->responseJson(true, 200, 'sos raised successfully');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function markedAsDelay(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'reason' => 'required',
            'estimated_time' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isJob = Job::find($request->job_id);
            $isRaisedDelay = SosLog::updateOrCreate(
                [
                    'user_id' => auth()->user()->id,
                    'job_id' => $request->job_id,
                    'load_id' => $request->load_id,
                    'type'  => 2
                ],
                [
                    'reason' => $request->reason
                ]
            );
            if ($isRaisedDelay) {
                // send push notification to contracter
                $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
                $title = 'Load Delayed';
                // $message = 'Trucker ' . $truckerName . ' has delayed for '. $request->estimated_time .'min who taken one load from job ID ' . $isJob->unique_id;
                $message = 'A load with the job id' . $isJob->unique_id . ' is currently experiencing a delay due to ' . $request->reason . ', by ' . $request->estimated_time . ' minutes';
                $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
                return $this->responseJson(true, 200, 'Load Delivery delay notified');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function isAlreadyInAJob()
    {
        try {
            $isAlreadyInAJob = LoadActivity::where(['user_id' => auth()->user()->id, 'status' => 3])->first();
            if ($isAlreadyInAJob && $isAlreadyInAJob->jobLoad?->cancellation_request_id == null) {
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'), new RunningJobLoadResource($isAlreadyInAJob));
            }
            return $this->responseJson(false, 200, 'No running jobs found', (object)[]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "internal server error", (object)[]);
        }
    }
    public function cancelJobLoad(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'job_id' => 'required|exists:jobs,id',
            'load_id' => 'required|exists:loads,id',
            'cancellation_reason' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            // get Load details
            $isJob = Job::find($request->job_id);
            $isload = Load::find($request->load_id);
            // Check if load exists
            if (!$isload) {
                return $this->responseJson(false, 200, 'Load not found');
            }
            if ($isload->user_id != auth()->user()->id) {
                return $this->responseJson(false, 200, 'you have not accepted this job load');
            }
            // check if status is 1 i.e accepted then simply cancel this load and make it available for all
            if ($isload->status == 1) {
                // delete from load activity
                $isdeleteFromLoadActivity = $this->deleteFromJobLoadActivity($request->job_id, $request->load_id, auth()->user()->id);
                // delete from load activity
                $isdeleteFromJobCOnfigureMap = $this->deleteFromJobConfigureMap($request->job_id, $request->load_id, auth()->user()->id);
                // make load default
                $isMakeLoadAsDefaultAsPrevious = $this->makeLoadDefault($request->load_id);

                if ($isdeleteFromLoadActivity && $isdeleteFromJobCOnfigureMap && $isMakeLoadAsDefaultAsPrevious) {
                    $this->updateCancellationReason($request->cancellation_reason, auth()->user()->id, $request->job_id, $request->load_id, $isload->status);
                    // send push notification to contracter
                    $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
                    $title = "Load Delivery Canceled";
                    // $message = "The trucker has canceled the load delivery";
                    $message = "Trucker " . $truckerName . " has cancelled one of the loads associated with job ID " . $isJob->unique_id;
                    $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                    $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
                    DB::commit();
                    return $this->responseJson(true, 200, 'load delivery cancelled');
                }
            } else if ($isload->status == 2 && is_null($isload->started_on)) { // check if status is 2 i.e reached then simply cancel this load and make it available for all
                // delete from load activity
                $isdeleteFromLoadActivity = $this->deleteFromJobLoadActivity($request->job_id, $request->load_id, auth()->user()->id);
                // delete from load activity
                $isdeleteFromJobCOnfigureMap = $this->deleteFromJobConfigureMap($request->job_id, $request->load_id, auth()->user()->id);
                // make load default
                $isMakeLoadAsDefaultAsPrevious = $this->makeLoadDefault($isload->id);

                if ($isdeleteFromLoadActivity && $isdeleteFromJobCOnfigureMap && $isMakeLoadAsDefaultAsPrevious) {
                    $this->updateCancellationReason($request->cancellation_reason, auth()->user()->id, $request->job_id, $request->load_id, $isload->status);
                    // send push notification to contracter
                    $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
                    $title = "Load Delivery Canceled";
                    $message = "Trucker " . $truckerName . " has cancelled one of the loads associated with job ID " . $isJob->unique_id;
                    $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                    DB::commit();
                    return $this->responseJson(true, 200, 'load delivery cancelled');
                }
            } else if ($isload->status == 2 && !is_null($isload->started_on)) { // check if status is 2 i.e running then simply cancel this load and make it available for all
                // check is already request for cancellation
                if ($isload->status == 2 && !is_null($isload->started_on) && $isload->cancellation_request_id == auth()->user()->id) {
                    return $this->responseJson(false, 200, 'Already requested for load cancellation');
                }
                // request for load cancellation
                $updateLoad = $isload->update([
                    'cancellation_request_id' => auth()->user()->id
                ]);
                if ($updateLoad) {
                    $this->updateCancellationReason($request->cancellation_reason, auth()->user()->id, $request->job_id, $request->load_id, $isload->status);
                    // send push notification to contracter
                    $truckerName = auth()->user()->first_name . ' ' . auth()->user()->last_name;
                    $title = "Load Delivery Cancellation Request";
                    $message = $truckerName . " is requested for load cancellation";
                    $this->sendPushToContracter($isJob->user_id, $title, $message, $isJob->id, $isJob->status);
                    $this->notificationToContracter($isJob->user_id, $title, $message, $isJob->id);
                    DB::commit();
                    return $this->responseJson(true, 200, 'load cancellation request raised');
                }
            } else {
                return $this->responseJson(false, 200, 'not cancelled now!! already deliveried from your end');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function makeLoadDefault($loadId)
    {
        $isLoad = Load::find($loadId);
        if ($isLoad) {
            // if no other load except this on this job then make job status to 1
            $isJob = Job::find($isLoad->job_id);
            $isLoadCount = Load::where('job_id', $isLoad->job_id)->whereNot('id', $loadId)->count();
            if ($isLoadCount == 0) {
                $isJob->update(['status' => 1]);
            }
            return $isLoad->update([
                'user_id' => null,
                'trucker_taken_weight' => null,
                'reached_on' => null,
                'started_on' => null,
                'completed_on' => null,
                'status' => 0,
                'cancellation_request_id' => null,
            ]);
        }
        return false;
    }
    private function deleteFromJobConfigureMap($jobId, $loadId, $userId)
    {
        $isdeleted = JobConfigureMap::where(['user_id' => $userId, 'job_id' => $jobId, 'load_id' => $loadId])->delete();
        if ($isdeleted) {
            return true;
        }
        return false;
    }
    private function deleteFromJobLoadActivity($jobId, $loadId, $userId)
    {
        $isdeleted = LoadActivity::where(['user_id' => $userId, 'job_id' => $jobId, 'load_id' => $loadId])->delete();
        if ($isdeleted) {
            return true;
        }
        return false;
    }
    private function updateCancellationReason($cancellationReason, $truckerId, $jobId, $loadId, $status)
    {
        $addUpdateCancellation = CancelJob::create([
            'job_id' => $jobId,
            'load_id' => $loadId,
            'trucker_id' => $truckerId,
            'reason' => $cancellationReason,
            'status' => $status,
            'cancelled_at' => now()->format('Y-m-d H:i:s'),
            'cancelled_by' => $truckerId
        ]);

        if ($addUpdateCancellation) {
            return true;
        }
        return false;
    }


    // chatting related functions

    public function setupChatRoom($contractorId, $truckerId, $loadId)
    {
        try {
            // Call Node.js chat server API
            $response = Http::post(env('CHAT_SERVER_URL') . '/api/setup-chat', [
                'contractor_id' => $contractorId,
                'trucker_id' => $truckerId,
                'load_id' => $loadId
            ]);
            if ($response->successful()) {
                return true;
            } else {
                return false;
            }

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return false;
        }
    }
}
