<?php

namespace App\Http\Controllers\Api\independent;

use App\Models\Earning;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use App\Models\TruckerPayoutActivity;
use App\Http\Controllers\BaseController;
use App\Http\Resources\Api\Auth\TruckerPayoutActivityResourceCollection;

class PayoutController extends BaseController
{
    public function getMyTransactionActivity(Request $request){
        try{
            $paidTransactionActivity = TruckerPayoutActivity::where('user_id', auth()->user()->id)->latest()
                ->paginate(10)->appends($request->except('page'));
                $totalPayouts = TruckerPayoutActivity::where('user_id', auth()->user()->id)
                    ->where('status', 1)
                    ->sum('amount');
                return new TruckerPayoutActivityResourceCollection($paidTransactionActivity, $totalPayouts);
        }catch(\Exception $e){
            return $this->responseJson(false, 500, "failed to fetch paid transaction activity");
        }
    }
}
