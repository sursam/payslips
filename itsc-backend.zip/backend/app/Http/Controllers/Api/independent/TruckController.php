<?php

namespace App\Http\Controllers\Api\independent;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Auth\UserTruckResource;
use App\Models\UserTruck;
use Illuminate\Http\Request;

class TruckController extends BaseController
{
    public function myTruckDetails(){
        try{
            $userTruck = UserTruck::where('user_id',auth()->user()->id)->first();
            if(!$userTruck){
                return $this->responseJson(false, 200, config('services.responseMessages.get.fail'),(object)[]);
            }
            return $this->responseJson(true, 200, config('services.responseMessages.get.succ'),new UserTruckResource($userTruck));
        }catch(\Exception $e){
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'),(object)[]);
        }
    }
}
