<?php

namespace App\Http\Controllers\Api\independent;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Auth\EarningResource;
use App\Models\Earning;
use Exception;
use Illuminate\Http\Request;

class EarningController extends BaseController
{
    public function myEarnings(Request $request)
    {
        try {
            // Validate the incoming request
            $request->validate([
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
            ]);

            // Retrieve start_date and end_date from the request
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');

            // Build the base query
            $query = Earning::where('user_id', auth()->user()->id);

            // Clone the query for calculation purposes to avoid overwriting filters
            $creditedQuery = clone $query;
            $deductedQuery = clone $query;

            // Apply date filters if provided
            if ($startDate) {
                $query->whereDate('created_at', '>=', $startDate);
                $creditedQuery->whereDate('created_at', '>=', $startDate);
                $deductedQuery->whereDate('created_at', '>=', $startDate);
            }

            if ($endDate) {
                $query->whereDate('created_at', '<=', $endDate);
                $creditedQuery->whereDate('created_at', '<=', $endDate);
                $deductedQuery->whereDate('created_at', '<=', $endDate);
            }

            // Calculate totals using separate cloned queries
            $creditedAmount = $creditedQuery->where('type', 1)->sum('amount');
            $deductedAmount = $deductedQuery->where('type', 2)->sum('amount');
            $totalEarning = $creditedAmount - $deductedAmount;

            // Fetch detailed earnings data
            $earnings = $query->latest()->get();

            return $this->responseJson(true, 200, 'Total earnings retrieved successfully.', [
                'total_earning' => number_format($totalEarning, 2, '.', ''),
                'details' => EarningResource::collection($earnings),
            ]);
        } catch (Exception $e) {
            // Log the error and return a user-friendly response
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object) []);
        }
    }
}
