<?php

namespace App\Http\Controllers\Api;

use App\Models\Role;
use App\Models\User;
use App\Traits\PayPal;
use App\Models\Profile;
use Twilio\Rest\Client;
use App\Traits\SmsTrait;
use Stripe\StripeClient;
use App\Mail\WelcomeMail;
use App\Models\TruckType;
use App\Models\UserEmail;
use App\Models\UserTruck;
use App\Models\Permission;
use App\Traits\UploadAble;
use App\Scopes\ActiveScope;
use App\Traits\StripeTrait;
use Laravel\Passport\Token;
use App\Models\EmailContant;
use App\Models\PaymentTerms;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Validation\Rule;
use App\Models\PaypalCredential;
use App\Traits\NotificationTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\ForgetPasswordTokenMail;
use App\Mail\WelcomeMailForAdminUser;
use App\Mail\WelcomeMailForContractor;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\Auth\UserResource;
use App\Http\Resources\Api\Common\AuthResource;
use App\Http\Resources\Api\Auth\UserResourceCollection;

class AuthController extends BaseController
{
    use CommonFunction;
    use SmsTrait;
    use PayPal;
    use UploadAble;
    use NotificationTrait;
    use StripeTrait;

    // Signup process (step 1) - common for both Contractor and independent
    public function registration(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:100',
            'last_name'  => 'required|string|max:100',
            'email' => [
                'required',
                'email',
                Rule::unique('users', 'email')->whereNull('deleted_at'),
            ],
            'country_code' => 'required',
            'mobile' => [
                'required',
                'digits:10',
                Rule::unique('users', 'mobile_number')->whereNull('deleted_at'),
            ],
            'password'   => 'required',
            'registration_source' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'dob' => 'required|date|date_format:Y-m-d|before:today',
            'state_id' => 'required|numeric',
            'city_id' => 'required|numeric',
            'address' => 'required',
            'pin_code' => 'required',
            'role' => 'required|exists:roles,slug',
            'device_token' => 'required',
            'fcm_token'    => 'required',
            'device_type' => 'required|in:1,2,3',
            // 'image' => 'required|mimes:jpg,jpeg,png|max:2048',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            $isRole = '';
            if (!empty($request->role) && $request->role == 'contructer') {
                $isRole = Role::where('slug', $request->role);
            } else {
                $isRole = Role::where('slug', $request->role);
            }
            $isRole = $isRole->first();
            if (!empty($request->image)) {
                $image = $request->image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                $request->merge(['profile_image' => $fileName]);
            }
            $request->merge(['user_type' => $isRole->id, 'mobile_number' => $request->mobile, 'completed_steps' => 1, 'is_blocked' => 1]);
            $isUserCreated = User::create($request->except('image', 'token', 'role', 'mobile', 'link'));
            if ($isUserCreated) {
                $isUserCreated->roles()->attach($isRole);
                if (App::environment(['production','testing'])) {
                    switch($request->role){
                        case 'independent':
                            $this->sendWelcomeEmail($request->first_name, $request->last_name, $request->email);
                            break;
                        case 'contractor':
                            $this->sendWelcomeEmailForContractor($request->first_name, $request->last_name, $request->email);
                            break;
                        case 'sub-contractor':
                            $this->sendWelcomeEmailForSubContractor($request->first_name, $request->last_name, $request->email, $request->password, $request->link);
                            break;
                    }
                }
                db::commit();
                $token = $isUserCreated->createToken('registration')->accessToken;
                return $this->responseJson(true, 200, 'User created successfully', new AuthResource($isUserCreated, $token));
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message, (object)[]);
        }
    }
    public function getUserDetails($uuid)
    {
        $user = User::with(['paymentTerms', 'permissions'])->where('uuid', $uuid)->first();
        if ($user != null) {
            return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), new AuthResource($user));
        }
        return $this->responseJson(false, 200, config('services.responseMessages.get.fail'), (object)[]);
    }
    public function updateUser(Request $request)
    {
        $user = User::where(['mobile_number' => $request->mobile])->first();
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name'  => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users', 'email')->ignore($user->id)->whereNull('deleted_at'),
            ],
            'country_code' => 'required',
            'mobile' => [
                'required',
                'digits:10',
                Rule::unique('users', 'mobile_number')->ignore($user->id)->whereNull('deleted_at'),
            ],
            'registration_source' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'dob' => 'required|date|date_format:Y-m-d',
            'state_id' => 'required|numeric',
            'city_id' => 'required|numeric',
            'address' => 'required',
            'pin_code' => 'required',
            'role' => 'required|exists:roles,slug',
            'device_token' => 'required',
            'fcm_token'    => 'required',
            'device_type' => 'required|in:1,2,3',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            if (!empty($request->image)) {
                $image = $request->image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                $request->merge(['profile_image' => $fileName]);
            }
            $request->merge(['mobile_number' => $request->mobile]);
            if ($user) {
                $isUserUpdated = $user->update($request->except('id', 'image', 'token', 'role', 'mobile', 'link'));
                if($isUserUpdated){
                    db::commit();
                    return $this->responseJson(true, 200, 'User updated successfully', new AuthResource($user));
                }
            }else{
                DB::rollback();
                $status = false;
                $code = 500;
                $message = "Something went wrong";
                return $this->responseJson($status, $code, $message, (object)[]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message, (object)[]);
        }
    }

    public function deleteUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'uuid' => 'required|exists:users,uuid',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isUser = User::where(['uuid' => $request->uuid])->first();
            if (!$isUser) {
                return $this->responseJson(false, 200, "Sub contractor doesn't exist");
            }
            $isUser->delete();
            Profile::where([
                'user_id' => $isUser->id
            ])->delete();
            PaymentTerms::where([
                'user_id' => $isUser->id
            ])->delete();
            DB::commit();
            return $this->responseJson(true, 200, 'Sub contractor deleted successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    // Signup process (step 2) - common for both Contractor and independent
    public function registrationSecondStep(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'company_legal_name'      => 'required|string|max:255',
            'company_dba'             => 'sometimes|nullable|string|max:255',
            'country'                 => 'required',
            'phone_2'                 => 'required|digits:10',
            'tax_id'                  => 'required',
            'driver_license'          => 'sometimes|nullable',
            'driving_license_expiery' => 'sometimes|nullable|date|date_format:Y-m-d'
        ]);

        // Return validation errors if any
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        // Start a database transaction
        DB::beginTransaction();
        try {
            // Update or create the profile
            $isProfileCreated = Profile::updateOrCreate(
                ['user_id' => auth()->user()->id],
                [
                    'company_legal_name' => $request->company_legal_name,
                    'tax_id' => $request->tax_id,
                    'company_dba' => $request->company_dba ?: null,
                    'country_code' => $request->country,
                    'phone_2' => $request->phone_2,
                    'driving_license_no' => $request->driver_license ?: null,
                    'driving_license_expiery' => $request->driving_license_expiery ?: null
                ]
            );

            // Check if the profile was created or updated successfully
            if ($isProfileCreated) {
                // Update completed steps to 2
                $user = auth()->user();
                $user->update(['completed_steps' => 2]);

                // Commit the transaction
                DB::commit();

                // Get the bearer token
                $token = $request->bearerToken();

                return $this->responseJson(true, 200, 'Professional details uploaded', [
                    'token' => $token,  // Pass the existing Passport token
                    'completed_steps' => $user->completed_steps,
                ]);
            }
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    // Signup process (step 3) - common for both Contractor and independent
    public function choosePaymentOrPayoutMethod(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_method' => 'required|in:1,2',    // 1: paypal, 2: stripe
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $stripeCustomerId = null;
            // finally update the data
            if ($request->payment_method == 2 && !auth()->user()->stripe_customer_id) {
                $stripeCustomerId = $this->createStripeCustomer(auth()->user()->first_name, auth()->user()->last_name, auth()->user()->email);
            }
            $isPaymentOrPayoutMethodUpdated = auth()->user()->update([
                'payment_method' => $request->payment_method,
                'stripe_customer_id' => auth()->user()->stripe_customer_id ?: $stripeCustomerId,
                'completed_steps' => auth()->user()->user_type == 4 ? 3 : 4
            ]);
            if ($isPaymentOrPayoutMethodUpdated) {
                return $this->responseJson(true, 200, 'payment method updated');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function validatePaypalCredentials()
    {
        DB::beginTransaction();
        try {
            $userDetails = auth()->user();
            $isValidate = $this->createPaypalOrder($userDetails);
            if (!empty($isValidate)) {
                $updateUserPaypalCredentials = PaypalCredential::updateOrCreate([
                    'user_id' => auth()->user()->id
                ], [
                    'access_token'   => $isValidate['paypalCredentials']['access_token'],
                    'reference_id'   => $isValidate['paypalCredentials']['reference_id'],
                    'order_id'       => $isValidate['paypalCredentials']['order_id'],
                    'order_response' => $isValidate['paypalCredentials']['order_response'],
                ]);
            }
            DB::commit();
            return $this->responseJson(true, 200, 'data found successfully', [$isValidate['responseData']]);
        } catch (\Exception $e) {
            DB::rollBack();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message);
        }
    }
    public function updateAuthorizedData(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'payer_id' => 'required',
            'token_id' => 'required',
        ]);

        // Return validation errors if any
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        // Begin database transaction
        DB::beginTransaction();
        try {
            // Update PayPal credentials
            $isUpdated = auth()->user()->paypalCredentials()->update([
                'token_id' => $request->token_id,
                'payer_id' => $request->payer_id,
            ]);

            // Check if the update was successful
            if ($isUpdated) {
                auth()->user()->update([
                    'completed_steps' => 3
                ]);
                DB::commit(); // Commit the transaction
                return $this->responseJson(true, 200, "Data updated successfully");
            } else {
                DB::rollback(); // Rollback if no rows were updated
                return $this->responseJson(false, 404, "No records were updated");
            }
        } catch (\Exception $e) {
            DB::rollback(); // Rollback the transaction on error
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong");
        }
    }
    // Signup process (step 4) - only for contractor
    public function updatePaymentTerms(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pay_in' => 'required|numeric'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            $updatePaymentTerms = PaymentTerms::updateOrCreate([
                'user_id' => auth()->user()->id
            ], [
                'is_default' => 1,
                'pay_in' => $request->pay_in
            ]);
            if ($updatePaymentTerms) {
                // update completed steps to 3
                $user = auth()->user();
                $user->update(['is_logged_in' => 1, 'completed_steps' => 4]);
                if ($request->pay_in <= 7) {
                    auth()->user()->update([
                        'is_blocked' => 0
                    ]);
                }
                $title = "Registration";
                $message = "Welcome to Conectar";
                $this->notificationToContracter(auth()->user()->id, $title, $message);
                DB::commit();
                // Get the existing token from the request
                $token = $request->bearerToken();
                return $this->responseJson(true, 200, 'Payment Terms Updated', [
                    'token' => $token,  // Pass the existing Passport token
                    'completed_steps' => $user->completed_steps,
                ]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message, (object)[]);
        }
    }

    // Signup process (step 4) - only for Trucker
    public function updateTruckDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'truck_reg_number' => 'required',
            'truck_model' => 'required',
            'truck_type' => 'required',
            'company_trucknumber' => 'required',
            'truck_image' => 'nullable|mimes:jpg,png,jpeg'

        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $fileName = null;
            if (!empty($request->truck_image)) {
                $image = $request->truck_image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_TRUCK_IMG_UPLOAD_PATH'), $fileName, 'public');
            }
            $truckType = TruckType::find($request->truck_type);
            if (!$truckType) {
                return $this->responseJson(false, 200, 'Truck type not found');
            }
            $truckData = [
                'truck_type_id' => $request->truck_type,
                'truck_license_no' => $request->truck_reg_number,
                'company_truck_number' => $request->company_trucknumber,
                'truck_make' => $request->truck_model,
                'truck_carrying_capacity' => isset($request->truck_carring_capacity) && $request->truck_carring_capacity != null ? $request->truck_carring_capacity : $truckType->weight_capacity,
            ];

            // Include the image filename if it exists
            if ($fileName) {
                $truckData['image'] = $fileName;
            }
            $isTruckDetailsAdded = UserTruck::updateOrCreate(
                ['user_id' => auth()->user()->id],
                $truckData
            );
            if ($isTruckDetailsAdded) {
                auth()->user()->update([
                    'is_logged_in' => 1,
                    'completed_steps' => 4
                ]);
                $title = "Truck Details Added";
                $message = "Truck Details Updated";
                $this->notificationToContracter(auth()->user()->id, $title, $message);
                DB::commit();
                return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
            }
        } catch (\Exception $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function loginWithEmail(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
            'device_token' => 'required',
            'device_type' => 'required|in:1,2,3',
            'fcm_token'  => 'required'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            // Attempt to authenticate the user
            if (Auth::attempt($request->only(['email', 'password']))) {
                $userDetails = auth()->user(); // Get the authenticated user
                Token::where('user_id', auth()->user()->id)->update(['revoked' => true]);
                $tokenResult = $userDetails->createToken('Login Successfully')->accessToken;
                auth()->user()->update([
                    'is_logged_in' => 1,
                    'device_token' => $request->device_token,
                    'device_type' => $request->device_type,
                    'fcm_token' => $request->fcm_token
                ]);
                // Prepare the response
                $status = true;
                $code = 200;
                $response = new AuthResource($userDetails, $tokenResult);
                $message = 'Successfully logged in';

                // Commit the transaction
                DB::commit();
            } else {
                // Authentication failed
                $status = false;
                $code = 200;
                $response = (object)[];
                $message = 'Invalid Credentials';
            }

            return $this->responseJson($status, $code, $message, $response);
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function loginWithPhone(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'device_token' => 'required|string',
            'device_type' => 'required|in:1,2,3',
            'country_code' => 'required|string',
            'mobile' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            $otp = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT); // Generate OTP
            if ($request->mobile == 9999999999) {
                $otp = "1111";
            }
            // Check if the user exists
            $user = User::where('country_code', $request->country_code)
                ->where('mobile_number', $request->mobile)
                ->first();
            $userType = 0;
            $userRoleSlug = '';
            if ($user) {
                if (App::environment('production')) {
                    $this->sendSMS($request->country_code, $request->mobile, $otp);
                }
                // Check if the user is already logged in
                // if ($user->is_logged_in) {
                //     return $this->responseJson(false, 200, "Someone is already logged in", (object)[]);
                // }
                // if ($request->mobile == '2103231624') {
                //     $isSmsSent = $this->sendSMS($request->country_code, $request->mobile, $otp);
                // }
                // if ($isSmsSent && isset($isSmsSent['message_sid'])) {
                //     // SMS sent successfully
                //     $messageSid = $isSmsSent['message_sid'];
                //     dd("Success: Message SID - " . $messageSid);
                // } else {
                //     // SMS sending failed
                //     $errorMessage = $isSmsSent['error'] ?? "Unknown error";
                //     dd("Failed: Error - " . $errorMessage);
                // }

                // Update the existing user's verification code
                $user->update(['verification_code' => $otp, 'device_token' => $request->device_token, 'device_type' => $request->device_type]);
                $userType = $user->user_type;
                $userRoleSlug = $user->roles[0]?->slug;
            } else {
                return $this->responseJson(false, 200, 'User does not exist', (object)[]);
            }

            // Commit the transaction
            DB::commit();

            return $this->responseJson(true, 200, 'OTP sent successfully', ['verification_code' => $otp, 'user_type' => $userType, 'user_role_slug' => $userRoleSlug]);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            DB::rollback();
            return $this->responseJson(false, 500, "something went wrong", (object)[]);
        }
    }
    public function loginVerification(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required|digits:10',
            'otp' => 'required|numeric'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            $user = User::where(['mobile_number' => $request->mobile, 'verification_code' => $request->otp])->first();
            if ($user) {
                Token::where('user_id', $user->id)->update(['revoked' => true]);
                $user->update([
                    'is_logged_in' => 1,
                    'is_verified' => 1,
                    'fcm_token' => $request->fcm_token,

                    'verification_code' => null
                ]);
                DB::Commit();
                $token = $user->createToken('logged in')->accessToken;

                if ($token) {
                    $status = true;
                    $code = 200;
                    $response = new AuthResource($user, $token);
                    $message = 'OTP Verified Successfully';
                } else {
                    $status = false;
                    $code = 500;
                    $response = (object)[];
                    $message = 'Something went wrong';
                }
            } else {
                $status = false;
                $code = 200;
                $response = (object)[];
                $message = 'OTP doesn\'t match';
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            DB::rollBack();
            $status = false;
            $code = 500;
            $message = config('constants.CATCH_ERROR_MSG');
            $response = (object)[];
        }
        return $this->responseJson($status, $code, $message, $response);
    }

    public function myProfile()
    {
        $user = Auth::user();
        if ($user != null) {
            return $this->responseJson(true, 200, config('services.responseMessages.get.succ'), new AuthResource($user));
        }
        return $this->responseJson(false, 200, config('services.responseMessages.get.fail'), (object)[]);
    }

    public function updateProfile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'mobile' => 'required|digits:10|unique:users,mobile_number,' . auth()->user()->id,
            'email' => 'required|email|unique:users,email,' . auth()->user()->id,
            'address' => 'required',
            'state' => 'required|exists:states,id',
            'city' => 'required|exists:cities,id',
            'pincode' => 'required|numeric|digits_between:5,10',
            'dob' => 'required|date|before:today',
            'profile_image' => 'nullable|mimes:jpg,jpeg,png',
            'driving_license_no' => 'nullable',
            'driving_license_expiery' => 'nullable|date_format:Y-m-d|after:today'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $user = auth()->user();
            if (!empty($request->profile_image)) {
                $image = $request->profile_image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                $user->update(['profile_image' => $fileName]);
            }
            if ($user->email != $request->email) {
                UserEmail::create([
                    'user_id' => $user->id,
                    'old_email' => $user->email,
                    'new_email' => $request->email
                ]);
            }
            $isUpdateDetails = auth()->user()->update([
                'first_name' => $request->fname,
                'last_name' => $request->lname,
                'email' => $request->email,
                'country_code' => $request->country,
                'mobile_number' => $request->mobile,
                'address' => $request->address,
                'state_id' => $request->state,
                'city_id' => $request->city,
                'pin_code' => $request->pincode,
                'dob' => $request->dob
            ]);
            if ($isUpdateDetails) {
                if (isset($request->driving_license_no) && $request->driving_license_no != null) {
                    auth()->user()->otherDetails()->update([
                        'driving_license_no' => $request->driving_license_no,
                        'driving_license_expiery' => $request->driving_license_expiery
                    ]);
                }
                DB::commit();
                $this->generalNotifiation(auth()->user()->id, 'Profile Updated', 'Your profile has been updated');
                $userData = new AuthResource(auth()->user());
                return $this->responseJson(true, 200, "Profile Updated", $userData);
            } else {
                return $this->responseJson(false, 200, "Profile Updation failed", (object)[]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function isEmailOrPhoneExist(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'mobile' => 'required|digits:10',
            'country' => 'required', // Added string validation for country
        ]);

        // Return validation errors if any
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        try {
            // Start a database transaction
            DB::beginTransaction();

            // Check if the email exists
            $userByEmail = User::withoutGlobalScope(ActiveScope::class)->where('email', $request->email);
            if($request->id){
                $userByEmail = $userByEmail->where('id', '<>', $request->id);
            }
            $isEmailExist = $userByEmail->exists();

            // Check if the phone number exists
            $userByPhone = User::withoutGlobalScope(ActiveScope::class)->where(['country_code' => $request->country, 'mobile_number' => $request->mobile]);
            if($request->id){
                $userByEmail = $userByPhone->where('id', '<>', $request->id);
            }
            $isPhoneExist = $userByPhone->exists();

            // Prepare response messages based on existence
            if ($isEmailExist && $isPhoneExist) {
                $message = 'Both email and phone number exist.';
            } elseif ($isEmailExist) {
                $message = 'Email exists';
            } elseif ($isPhoneExist) {
                $message = 'Phone number exists';
            } else {
                $message = 'Neither email nor phone number exists.';
            }

            // Commit the transaction
            DB::commit();

            // Overall status: true if neither exists
            $overallStatus = !$isEmailExist && !$isPhoneExist; // true if neither exists

            // Return the response with both email and phone status
            return $this->responseJson($overallStatus, 200, $message, [
                'email_exists' => $isEmailExist,
                'phone_exists' => $isPhoneExist,
            ]);
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }

    public function logout(Request $request)
    {
        // update is logged in to 0
        auth()->user()->update([
            'is_logged_in' => 0,
            'fcm_token' => null
        ]);
        $token = auth()->user()->token();
        $tokenRevoke = $token->revoke();
        if ($tokenRevoke) {
            $status = true;
            $code = 200;
            $response = [];
            $message = 'You have been successfully logged out!';
        } else {
            $status = false;
            $code = 500;
            $response = [];
            $message = 'Something went wrong';
        }
        return $this->responseJson($status, $code, $message, $response);
    }
    public function forgotPasswordToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
        ], [
            'email.required' => 'The email field is mandatory.',
            'email.email' => 'The email must be a valid email address.',
            'email.exists' => 'User does not exist on this email',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            $userDetails = User::where('email', $request->email)->first();
            $otp = generateOTP(4);
            User::where('id', $userDetails->id)->update([
                'verification_code' => $otp
            ]);
            DB::commit();
            if (App::environment(['production','testing'])) {
                $this->sendResetPasswordEmail($userDetails->first_name, $userDetails->last_name, $request->email, $otp);
            }
            $response = ['email' => $request->email, 'otp' => $otp];
            $message = 'OTP Sent Successfully';
            return $this->responseJson(true, 200, $message, $response);
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function verifyToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'otp'   => 'required|digits:4'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        DB::beginTransaction();
        try {
            $checkToken = User::where(['email' => $request->email, 'verification_code' => $request->otp])->first();
            if ($checkToken) {
                return $this->responseJson(true, 200, "OTP Verified Successfully");
            }
            return $this->responseJson(false, 200, "Invalid OTP");
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'password' => 'required|min:6|string',
            'email'    => 'required|email|exists:users,email'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }

        DB::beginTransaction();
        try {
            if ($request->email) {
                $condition = ['email' => $request->email];
                $userFound = User::where($condition)->first();
            }
            if ($userFound) {
                $otpUpdate =  User::find($userFound->id)->update(['password' => Hash::make($request->password)]);
                if ($otpUpdate) {
                    DB::Commit();
                    $this->generalNotifiation($userFound->id, 'Password Change', 'Your password has been changed');
                    return $this->responseJson(true, 200, "Password updated successfully");
                    // return $this->responseJson(true, 200, config('services.responseMessages.post.succ'));
                } else {
                    return $this->responseJson(false, 200, "Failed to update password");
                    // return $this->responseJson(false, 200, config('services.responseMessages.post.fail'));
                }
            } else {
                return $this->responseJson(false, 200, 'User not found');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function updateOnlineOffline(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'flag' => 'required|in:0,1',    // 0: offline ,1: online
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isUpdate = auth()->user()->update([
                'is_approve' => $request->flag
            ]);
            $status = $isUpdate;
            $message = $status ? config('services.responseMessages.update.succ') : config('services.responseMessages.update.fail');
            return $this->responseJson($status, 200, $message);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function updateMyLocation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'latitude' => 'required',
            'longitude' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first());
        }
        try {
            $isUpdate = auth()->user()->update([
                'latitude' => $request->latitude,
                'longitude' => $request->longitude
            ]);
            $status = $isUpdate;
            $message = $status ? config('services.responseMessages.update.succ') : config('services.responseMessages.update.fail');
            return $this->responseJson($status, 200, $message);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    private function sendWelcomeEmail($firstName, $lastName, $email)
    {
        // Fetch the user from the database
        $fullName = $firstName . ' ' . $lastName;
        $emailContent = EmailContant::where('slug', 'welcome-mail')->first();
        $subject = $emailContent->subject;
        $content = $emailContent->description;

        // Send the email
        Mail::to($email)->send(new WelcomeMail($fullName, $content, $subject));

        return true;
    }

    private function sendResetPasswordEmail($firstName, $lastName, $email, $token)
    {
        // Fetch the user from the database
        $fullName = $firstName . ' ' . $lastName;
        $subject = 'Password Reset';
        // Send the email
        Mail::to($email)->send(new ForgetPasswordTokenMail($subject, $fullName, $token));

        return true;
    }
    private function sendWelcomeEmailForContractor($firstName, $lastName, $email)
    {
        // Fetch the user from the database
        $fullName = $firstName . ' ' . $lastName;
        $emailContent = EmailContant::where('slug', 'welcome-mail-for-contractor')->first();
        $subject = $emailContent->subject;
        $content = $emailContent->description;

        // Send the email
        Mail::to($email)->send(new WelcomeMailForContractor($fullName, $content, $subject));

        return true;
    }
    private function sendWelcomeEmailForSubContractor($firstName, $lastName, $email, $password, $link)
    {
        // Fetch the user from the database
        $fullName = $firstName . ' ' . $lastName;
        $emailContent = EmailContant::where('slug', 'welcome-mail-for-admin-user')->first();
        $subject = $emailContent->subject;
        $content = $emailContent->description;

        $details = [
            'contant' => $content,
            'name' => $fullName,
            'user_name' => $email,
            'password' => $password,
            'link' => $link,
            'subject' => $subject
        ];
        // Send the email
        Mail::to($email)->send(new WelcomeMailForAdminUser($details));

        return true;
    }
    // private function sendSMS($countryCode, $receiverNumber, $otp)
    // {
    //     $messageText = "Your One-Time Password (OTP) for signing in Conectar Advantage is: $otp\n\n";
    //     $messageText .= "Please use this OTP to complete your sign-in process. ";

    //     try {
    //         $account_sid = env('TWILLIO_ACCOUNT_SID');
    //         $auth_token = env('TWILLIO_AUTH_TOKEN');
    //         $twilio_number = env('TWILIO_FROM');
    //         // dd($account_sid, $auth_token, $twilio_number);
    //         $client = new Client($account_sid, $auth_token);
    //         $phoneNoWithCountryCode = "+" . $countryCode . $receiverNumber;

    //         $message = $client->messages->create(
    //             $phoneNoWithCountryCode,
    //             [
    //                 "body" => $messageText,
    //                 "from" => $twilio_number
    //             ]
    //         );

    //         $messageSid = $message->sid;

    //         return [
    //             'success' => true,
    //             'message' => 'SMS sent successfully!',
    //             'message_sid' => $messageSid,
    //             'initial_status' => $message->status
    //         ];
    //     } catch (\Exception $e) {
    //         logger()->error('SMS Error: ' . $e->getMessage());
    //         return [
    //             'success' => false,
    //             'error' => $e->getMessage()
    //         ];
    //     }
    // }
    private function checkSMSDeliveryStatus($messageSid)
    {
        try {
            $account_sid = env('TWILLIO_ACCOUNT_SID');
            $auth_token = env('TWILLIO_AUTH_TOKEN');

            $client = new Client($account_sid, $auth_token);

            // Fetch the message to get current status
            $message = $client->messages($messageSid)->fetch();

            $isDelivered = $message->status === 'delivered';

            return [
                'success' => true,
                'message_sid' => $messageSid,
                'status' => $message->status,
                'is_delivered' => $isDelivered,
                'error_code' => $message->errorCode,
                'error_message' => $message->errorMessage,
                'date_sent' => $message->dateSent ? $message->dateSent->format('Y-m-d H:i:s') : null,
                'date_updated' => $message->dateUpdated->format('Y-m-d H:i:s')
            ];
        } catch (\Exception $e) {
            logger()->error('Error checking SMS status: ' . $e->getMessage());
            return [
                'success' => false,
                'message_sid' => $messageSid,
                'error' => $e->getMessage()
            ];
        }
    }
    public function updateStripeDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'routing_number' => [
                'required',
                'digits:9',
                'numeric',
                'regex:/^[0-9]{9}$/'
            ],
            'account_number' => [
                'required'
            ],
        ], [
            'routing_number.required' => 'Routing number is required.',
            'routing_number.digits' => 'Routing number must be exactly 9 digits.',
            'routing_number.numeric' => 'Routing number must contain only numbers.',
            'routing_number.regex' => 'Routing number must be exactly 9 digits with no spaces or special characters.',
            'account_number.required' => 'Account number is required.'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            // Check if we're in test mode and log it
            if ($this->isStripeTestMode()) {
                logger('Stripe test mode detected - using test bank account numbers');
            }

            // Step 1: Ensure we have a Stripe customer
            if (auth()->user()->payment_method != 2 || auth()->user()->stripe_customer_id == null) {
                $stripeCustomerId = $this->createStripeCustomer(auth()->user()->first_name, auth()->user()->last_name, auth()->user()->email);
                auth()->user()->update([
                    'payment_method' => 2,
                    'stripe_customer_id' => $stripeCustomerId
                ]);
            }

            $stripeCustomerId = auth()->user()->stripe_customer_id;
            $stripeAccountId = null;
            $stripeBankAccId = null;

            if (auth()->user()->payment_method == 2 && $stripeCustomerId) {
                // Step 2: Check if Connect account already exists, if not create one
                $stripeAccountId = $this->getOrCreateStripeConnectAccount();

                if (!$stripeAccountId) {
                    DB::rollBack();
                    return $this->responseJson(false, 500, 'Failed to create or retrieve Stripe Connect account.');
                }

                // Step 3: Handle bank account - remove existing and add new one
                $routingNumber = trim($request->routing_number);
                $accountNumber = trim($request->account_number);

                // Remove existing bank account if any
                $this->removeExistingBankAccount($stripeAccountId);

                // Add new bank account
                $stripeBankAccId = $this->addBankAccount(
                    $stripeAccountId,
                    'USD',
                    auth()->user()->first_name . ' ' . auth()->user()->last_name,
                    $routingNumber,
                    $accountNumber
                );

                if (!$stripeBankAccId) {
                    DB::rollBack();
                    return $this->responseJson(false, 200, 'Invalid bank details. Please verify your routing and account numbers.', (object)[]);
                }
            }

            // Step 4: Update the database
            $isPaymentOrPayoutMethodUpdated = auth()->user()->update([
                'stripe_account_id' => $stripeAccountId,
                'stripe_bank_acc_id' => $stripeBankAccId
            ]);

            if ($isPaymentOrPayoutMethodUpdated) {
                // Generate link for update Details for KYC
                // $isKycCompleted = $this->isKycCompleted();
                // if ($isKycCompleted) {
                //     return $this->responseJson(true, 200, 'Payment method updated.', (object)[]);
                // }
                $accountDetailsUpdationLink = $this->generateAccountLink($stripeAccountId, auth()->user()->device_type);
                if ($accountDetailsUpdationLink) {
                    DB::commit();
                    return $this->responseJson(
                        true,
                        200,
                        'Payment method updated.',
                        [
                            'stripe_account_id' => $stripeAccountId,
                            'stripe_bank_acc_id' => $stripeBankAccId,
                            'account_details_updation_link' => $accountDetailsUpdationLink,
                            'is_existing_account' => !empty(auth()->user()->stripe_account_id),
                            'is_kyc_completed' => $this->isKycCompleted(),
                        ],
                    );
                } else {
                    DB::rollBack();
                    return $this->responseJson(false, 500, 'Failed to generate account details link.');
                }
            } else {
                DB::rollBack();
                return $this->responseJson(false, 500, 'Database update failed.', (object)[]);
            }
        } catch (\Stripe\Exception\CardException $e) {
            DB::rollBack();
            logger('Stripe Card Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Card error: ' . $e->getDeclineCode() . '. Please check your card details and try again.', (object)[]);
        } catch (\Stripe\Exception\RateLimitException $e) {
            DB::rollBack();
            logger('Stripe Rate Limit Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 429, 'Too many requests. Please try again in a few minutes.', (object)[]);
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            DB::rollBack();

            // Handle the specific "test bank account" error with a user-friendly message
            if (strpos($e->getMessage(), 'must use a test bank account number') !== false) {
                if ($this->isStripeTestMode()) {
                    return $this->responseJson(false, 400, 'This is a test environment. Please use test bank account numbers or contact support for live account setup.', (object)[]);
                } else {
                    return $this->responseJson(false, 400, 'Invalid bank account details. Please verify your routing and account numbers.', (object)[]);
                }
            }

            logger('Stripe Invalid Request Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Invalid request: ' . $e->getMessage(), (object)[]);
        } catch (\Stripe\Exception\AuthenticationException $e) {
            DB::rollBack();
            logger('Stripe Authentication Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authentication failed. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\ApiConnectionException $e) {
            DB::rollBack();
            logger('Stripe API Connection Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 503, 'Payment service temporarily unavailable. Please try again later.', (object)[]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            DB::rollBack();
            logger('Stripe API Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'Payment service error. Please try again or contact support.', (object)[]);
        } catch (\Stripe\Exception\PermissionException $e) {
            DB::rollBack();
            logger('Stripe Permission Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 403, 'Payment service configuration error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\UnknownApiErrorException $e) {
            DB::rollBack();
            logger('Stripe Unknown API Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'An unexpected payment service error occurred. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidClientException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Client Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authorization failed. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidGrantException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Grant Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authorization error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidRequestException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Request Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service request error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidScopeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Scope Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 403, 'Payment service scope error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\UnsupportedGrantTypeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Unsupported Grant Type Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service grant type error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\UnsupportedResponseTypeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Unsupported Response Type Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service response type error. Please contact support.', (object)[]);
        } catch (\Exception $e) {
            DB::rollBack();
            logger('General Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'An unexpected error occurred. Please try again or contact support.', (object)[]);
        }
    }
    private function getOrCreateStripeConnectAccount()
    {
        try {
            $user = auth()->user();
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            // Check if user already has a Connect account
            if (!empty($user->stripe_account_id)) {
                // Verify the account still exists in Stripe
                try {
                    $account = $stripe->accounts->retrieve($user->stripe_account_id);

                    // Check if account is valid and not deleted
                    if ($account && !$account->deleted) {
                        logger("Using existing Stripe Connect account: {$user->stripe_account_id}");
                        return $user->stripe_account_id;
                    } else {
                        logger("Existing Connect account {$user->stripe_account_id} is deleted, creating new one");
                        // Account was deleted, we need to create a new one
                        $user->update(['stripe_account_id' => null, 'stripe_bank_acc_id' => null]);
                    }
                } catch (\Stripe\Exception\InvalidRequestException $e) {
                    // Account doesn't exist in Stripe, create new one
                    logger("Connect account {$user->stripe_account_id} not found in Stripe, creating new one");
                    $user->update(['stripe_account_id' => null, 'stripe_bank_acc_id' => null]);
                }
            }

            // Create new Connect account
            $newAccountId = $this->createStripeConnectAccount(
                $user->stripe_customer_id,
                $user->first_name,
                $user->last_name,
                $user->email,
                "US",
                $user->address,
                $user->cityDetails->name,
                $user->pin_code,
                $user->dob,
                $user->mobile_number
            );

            if ($newAccountId) {
                // Update user with new account ID
                $user->update(['stripe_account_id' => $newAccountId]);
                logger("Created new Stripe Connect account: {$newAccountId}");
            }

            return $newAccountId;
        } catch (\Exception $e) {
            logger('Error in getOrCreateStripeConnectAccount: ' . $e->getMessage());
            return null;
        }
    }
    private function removeExistingBankAccount($stripeAccountId)
    {
        try {
            $user = auth()->user();
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            // If user has existing bank account ID, try to remove it
            if (!empty($user->stripe_bank_acc_id)) {
                try {
                    $stripe->accounts->deleteExternalAccount(
                        $stripeAccountId,
                        $user->stripe_bank_acc_id
                    );
                    logger("Removed existing bank account: {$user->stripe_bank_acc_id}");
                } catch (\Stripe\Exception\InvalidRequestException $e) {
                    // Bank account might not exist, that's okay
                    logger("Bank account {$user->stripe_bank_acc_id} not found or already removed");
                }
            }

            // Also check for any existing bank accounts on the Connect account
            $externalAccounts = $stripe->accounts->allExternalAccounts($stripeAccountId, [
                'object' => 'bank_account',
                'limit' => 10
            ]);

            foreach ($externalAccounts->data as $bankAccount) {
                try {
                    $stripe->accounts->deleteExternalAccount($stripeAccountId, $bankAccount->id);
                    logger("Removed existing bank account from Connect account: {$bankAccount->id}");
                } catch (\Exception $e) {
                    logger("Failed to remove bank account {$bankAccount->id}: " . $e->getMessage());
                }
            }

            return true;
        } catch (\Exception $e) {
            logger('Error removing existing bank accounts: ' . $e->getMessage());
            return false;
        }
    }
    private function isStripeTestMode()
    {
        // Get your Stripe secret key from config
        $stripeKey = env('STRIPE_SECRET');

        // Test keys start with 'sk_test_'
        return strpos($stripeKey, 'sk_test_') === 0;
    }
    private function getTestBankAccountDetails($routingNumber, $accountNumber)
    {
        // Stripe test routing numbers and what they simulate
        $testRoutingNumbers = [
            '110000000', // Valid routing number
            '021000021', // Valid routing number (Chase)
            '011401533', // Valid routing number (Wells Fargo)
            '121000248', // Valid routing number (Wells Fargo)
        ];

        // Stripe test account numbers and their behaviors
        $testAccountNumbers = [
            '000123456789', // Default valid test account
            '000111111116', // Valid account
            '000111111113', // Valid account
            '000222222227', // Account that will be rejected (for testing failures)
            '000333333335', // Account that will be rejected (for testing failures)
        ];

        return [
            'routing_number' => $testRoutingNumbers[0], // Use first valid test routing number
            'account_number' => $testAccountNumbers[0], // Use default valid test account
        ];
    }
    private function addBankAccount($connectAccountId, $currency, $accountHolderName, $routingNumber, $accountNumber)
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            // Check if we're in test mode
            $isTestMode = $this->isStripeTestMode();

            if ($isTestMode) {
                // Validate and potentially convert to test account numbers
                $testAccountDetails = $this->getTestBankAccountDetails($routingNumber, $accountNumber);
                $routingNumber = $testAccountDetails['routing_number'];
                $accountNumber = $testAccountDetails['account_number'];

                logger("Using test bank account - Routing: {$routingNumber}, Account: {$accountNumber}");
            }

            // Create external account (bank account) for the Connect account
            $bankAccount = $stripe->accounts->createExternalAccount(
                $connectAccountId,
                [
                    'external_account' => [
                        'object' => 'bank_account',
                        'country' => 'US',
                        'currency' => strtolower($currency),
                        'routing_number' => $routingNumber,
                        'account_number' => $accountNumber,
                        'account_holder_name' => $accountHolderName,
                        'account_holder_type' => 'individual', // or 'company'
                    ]
                ]
            );

            logger("Successfully added bank account to Connect account: {$bankAccount->id}");
            return $bankAccount->id;
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            // Handle the specific test bank account error
            if (strpos($e->getMessage(), 'must use a test bank account number') !== false) {
                logger('Test bank account required: ' . $e->getMessage());

                // If in test mode, provide helpful error message
                if ($this->isStripeTestMode()) {
                    throw new \Exception('Invalid bank account for test environment. Please use test account numbers or switch to live mode.');
                }
            }

            logger('Stripe Invalid Request (Bank Account): ' . $e->getMessage());
            return false;
        } catch (\Exception $e) {
            logger('Failed to add bank account to Connect account: ' . $e->getMessage());
            return false;
        }
    }
    public function getStripeConnectAccountStatus()
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
            $user = auth()->user();

            if (empty($user->stripe_account_id)) {
                return $this->responseJson(false, 200, 'No Connect account found.');
            }

            $account = $stripe->accounts->retrieve($user->stripe_account_id);

            // Get external accounts (bank accounts)
            $externalAccounts = $stripe->accounts->allExternalAccounts($user->stripe_account_id, [
                'object' => 'bank_account',
                'limit' => 10
            ]);

            return $this->responseJson(true, 200, 'Connect account details retrieved.', [
                'account_id' => $user->stripe_account_id,
                'account_status' => $account->details_submitted ? 'active' : 'pending',
                'charges_enabled' => $account->charges_enabled,
                'payouts_enabled' => $account->payouts_enabled,
                'bank_accounts_count' => count($externalAccounts->data),
                'requirements' => $account->requirements,
            ]);
        } catch (\Exception $e) {
            logger('Error getting Connect account status: ' . $e->getMessage());
            return $this->responseJson(false, 500, 'Failed to retrieve account status.');
        }
    }
    private function cleanupFailedConnectAccount($accountId)
    {
        $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));
        try {
            $stripe->accounts->update($accountId, [
                'metadata' => [
                    'status' => 'failed_setup',
                    'reason' => 'bank_account_validation_failed',
                    'created_at' => now()->toDateTimeString(),
                    'cleanup_performed' => 'true'
                ]
            ]);

            logger("Cleaned up failed Connect account: {$accountId}");
            return true;
        } catch (\Exception $e) {
            logger("Failed to cleanup Connect account {$accountId}: " . $e->getMessage());
            return false;
        }
    }
    public function getKycUpdateLink()
    {
        try {
            $user = auth()->user();
            $generatedLink = $this->generateAccountLink(auth()->user()->stripe_account_id);
            dd($generatedLink);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function isKycCompleted()
    {
        try {
            $user = auth()->user();
            $isKycDone = $this->checkStripeAccountStatus(auth()->user()->stripe_account_id);
            return $isKycDone;
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    // Signup process (step 5) - only for trucker to add bank details
    public function addBankDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'routing_number' => [
                'required',
                'digits:9',
                'numeric',
                'regex:/^[0-9]{9}$/'
            ],
            'account_number' => [
                'required'
            ],
            'account_holder_name' => 'required'
        ], [
            'routing_number.required' => 'Routing number is required.',
            'routing_number.digits' => 'Routing number must be exactly 9 digits.',
            'routing_number.numeric' => 'Routing number must contain only numbers.',
            'routing_number.regex' => 'Routing number must be exactly 9 digits with no spaces or special characters.',
            'account_number.required' => 'Account number is required.',
            'account_holder_name.required' => 'Account holder name is required.',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            // Check if we're in test mode and log it
            if ($this->isStripeTestMode()) {
                logger('Stripe test mode detected - using test bank account numbers');
            }

            // Step 1: Ensure we have a Stripe customer
            if (auth()->user()->payment_method != 2 || auth()->user()->stripe_customer_id == null) {
                $stripeCustomerId = $this->createStripeCustomer(auth()->user()->first_name, auth()->user()->last_name, auth()->user()->email);
                auth()->user()->update([
                    'payment_method' => 2,
                    'stripe_customer_id' => $stripeCustomerId
                ]);
            }

            $stripeCustomerId = auth()->user()->stripe_customer_id;
            $stripeAccountId = null;
            $stripeBankAccId = null;

            if (auth()->user()->payment_method == 2 && $stripeCustomerId) {
                // Step 2: Check if Connect account already exists, if not create one
                $stripeAccountId = $this->getOrCreateStripeConnectAccount();

                if (!$stripeAccountId) {
                    DB::rollBack();
                    return $this->responseJson(false, 500, 'Failed to create or retrieve Stripe Connect account.');
                }

                // Step 3: Handle bank account - remove existing and add new one
                $routingNumber = trim($request->routing_number);
                $accountNumber = trim($request->account_number);

                // Remove existing bank account if any
                // $this->removeExistingBankAccount($stripeAccountId);

                // Add new bank account
                $stripeBankAccId = $this->addBankAccount(
                    $stripeAccountId,
                    'USD',
                    $request->account_holder_name,
                    $routingNumber,
                    $accountNumber,
                );

                if (!$stripeBankAccId) {
                    DB::rollBack();
                    return $this->responseJson(false, 200, 'Invalid bank details. Please verify your routing and account numbers.', (object)[]);
                }
            }
            // $user = User::find(auth()->user()->id);
            // Step 4: Update the database
            $isPaymentOrPayoutMethodUpdated = auth()->user()->update([
                'stripe_account_id' => $stripeAccountId,
                'stripe_bank_acc_id' => $stripeBankAccId,
                'completed_steps' => auth()->user()->completed_steps < 6 ? 5 : auth()->user()->completed_steps
            ]);

            if ($isPaymentOrPayoutMethodUpdated) {
                $accountDetailsUpdationLink = $this->generateAccountLink($stripeAccountId, auth()->user()->device_type);
                if ($accountDetailsUpdationLink) {
                    DB::commit();
                    return $this->responseJson(
                        true,
                        200,
                        'Payment method updated.',
                        [
                            'completed_steps' => auth()->user()->completed_steps,
                            'stripe_account_id' => $stripeAccountId,
                            'stripe_bank_acc_id' => $stripeBankAccId,
                            'account_details_updation_link' => auth()->user()->completed_steps < 6 ? $accountDetailsUpdationLink : null,
                            'is_existing_account' => !empty(auth()->user()->stripe_account_id),
                            'is_kyc_completed' => $this->isKycCompleted(),
                        ],
                    );
                } else {
                    DB::rollBack();
                    return $this->responseJson(false, 500, 'Failed to generate account details link.');
                }
            } else {
                DB::rollBack();
                return $this->responseJson(false, 500, 'Database update failed.', (object)[]);
            }
        } catch (\Stripe\Exception\CardException $e) {
            DB::rollBack();
            logger('Stripe Card Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Card error: ' . $e->getDeclineCode() . '. Please check your card details and try again.', (object)[]);
        } catch (\Stripe\Exception\RateLimitException $e) {
            DB::rollBack();
            logger('Stripe Rate Limit Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 429, 'Too many requests. Please try again in a few minutes.', (object)[]);
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            DB::rollBack();

            // Handle the specific "test bank account" error with a user-friendly message
            if (strpos($e->getMessage(), 'must use a test bank account number') !== false) {
                if ($this->isStripeTestMode()) {
                    return $this->responseJson(false, 400, 'This is a test environment. Please use test bank account numbers or contact support for live account setup.', (object)[]);
                } else {
                    return $this->responseJson(false, 400, 'Invalid bank account details. Please verify your routing and account numbers.', (object)[]);
                }
            }
            logger('Stripe Invalid Request Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Invalid request: ' . $e->getMessage(), (object)[]);
        } catch (\Stripe\Exception\AuthenticationException $e) {
            DB::rollBack();
            logger('Stripe Authentication Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authentication failed. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\ApiConnectionException $e) {
            DB::rollBack();
            logger('Stripe API Connection Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 503, 'Payment service temporarily unavailable. Please try again later.', (object)[]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            DB::rollBack();
            logger('Stripe API Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'Payment service error. Please try again or contact support.', (object)[]);
        } catch (\Stripe\Exception\PermissionException $e) {
            DB::rollBack();
            logger('Stripe Permission Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 403, 'Payment service configuration error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\UnknownApiErrorException $e) {
            DB::rollBack();
            logger('Stripe Unknown API Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'An unexpected payment service error occurred. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidClientException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Client Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authorization failed. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidGrantException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Grant Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 401, 'Payment service authorization error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidRequestException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Request Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service request error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\InvalidScopeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Invalid Scope Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 403, 'Payment service scope error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\UnsupportedGrantTypeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Unsupported Grant Type Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service grant type error. Please contact support.', (object)[]);
        } catch (\Stripe\Exception\OAuth\UnsupportedResponseTypeException $e) {
            DB::rollBack();
            logger('Stripe OAuth Unsupported Response Type Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 400, 'Payment service response type error. Please contact support.', (object)[]);
        } catch (\Exception $e) {
            DB::rollBack();
            logger('General Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'An unexpected error occurred. Please try again or contact support.', (object)[]);
        }
    }
    public function getUserBankAccounts()
    {
        try {
            $stripeAccountId = auth()->user()->stripe_account_id;
            $accounts = $this->getUsersBankDetailList($stripeAccountId);
            return $this->responseJson(true, 200, "Bank accounts retrieved successfully.", $accounts);
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong. Please try again.");
        }
    }
    // public function updateBankDetails(){}
    public function deleteBankAccountDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'bank_account_id' => 'required',
        ], [
            'bank_account_id.required' => 'Bank Account ID is required.'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            $accountId = auth()->user()->stripe_account_id;
            $bankAccountId = $request->bank_account_id;

            // Step 1: Retrieve bank account
            $bankAccount = $this->retriveBankAccount($accountId, $bankAccountId);

            if (isset($bankAccount->id)) {
                // Step 2: Attempt deletion
                $isBankAccountDeleted = $this->deleteBankAccount($accountId, $bankAccountId);

                // Step 3: Handle deletion response
                if (!empty($isBankAccountDeleted->deleted) && $isBankAccountDeleted->deleted == true) {
                    DB::commit();
                    return $this->responseJson(true, 200, "Bank account deleted successfully.", (object)[]);
                } else {
                    DB::rollBack();
                    $errorMessage = isset($isBankAccountDeleted->message)
                        ? $isBankAccountDeleted->message
                        : "Bank account could not be deleted.";
                    return $this->responseJson(false, 200, $errorMessage, (object)[]);
                }
            } else {
                DB::rollBack();
                return $this->responseJson(false, 200, "Bank account not found.", (object)[]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function setDefaultBankAccount(Request $request)
    {
        // Step 1: Validate input
        $validator = Validator::make($request->all(), [
            'bank_account_id' => 'required',
        ], [
            'bank_account_id.required' => 'Bank Account ID is required.'
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            $accountId = auth()->user()->stripe_account_id;
            $bankAccountId = $request->bank_account_id;

            // Step 2: Retrieve bank account
            $bankAccount = $this->retriveBankAccount($accountId, $bankAccountId);

            if (!isset($bankAccount->id)) {
                DB::rollBack();
                return $this->responseJson(false, 404, "Bank account not found.", (object)[]);
            }

            // Step 3: Update it to be default for currency
            $updatedBankAccount = $this->changeDefaultBankAccount($accountId, $bankAccountId);

            DB::commit();
            return $this->responseJson(true, 200, "Bank account set as default for currency.", $updatedBankAccount);
        } catch (\Exception $e) {
            DB::rollBack();
            logger("Stripe error: " . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Failed to set default bank account.", (object)[]);
        }
    }
    // public function updateBankDetails(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'routing_number' => [
    //             'required',
    //             'digits:9',
    //             'numeric',
    //             'regex:/^[0-9]{9}$/'
    //         ],
    //         'account_number' => 'required',
    //         'bank_account_id' => 'required',
    //         'account_holder_name' => 'required'
    //     ], [
    //         'routing_number.required' => 'Routing number is required.',
    //         'routing_number.digits' => 'Routing number must be exactly 9 digits.',
    //         'routing_number.numeric' => 'Routing number must contain only numbers.',
    //         'routing_number.regex' => 'Routing number must be exactly 9 digits with no spaces or special characters.',
    //         'account_number.required' => 'Account number is required.',
    //         'account_holder_name.required' => 'Account holder name is required.',
    //     ]);

    //     if ($validator->fails()) {
    //         return $this->responseJson(false, 422, $validator->errors()->first(), (object)[]);
    //     }

    //     DB::beginTransaction();
    //     try {
    //         $accountId = auth()->user()->stripe_account_id;
    //         $oldBankAccountId = $request->bank_account_id;

    //         // Step 1: Add new bank account
    //         $newBankAccount = $this->addBankAccount(
    //             $accountId,
    //             'USD',
    //             $request->account_holder_name,
    //             $request->routing_number,
    //             $request->account_number
    //         );
    //         if (!$newBankAccount) {
    //             DB::rollBack();
    //             return $this->responseJson(false, 400, "Failed to add new bank account.", (object)[]);
    //         }
    //         // Step 2: Retrieve old bank account
    //         $oldBankAccount = $this->retriveBankAccount($accountId, $oldBankAccountId);

    //         // Step 3: Check if it's the default for currency
    //         if (!empty($oldBankAccount->default_for_currency)) {
    //             DB::rollBack();
    //             return $this->responseJson(false, 200, "Cannot update default bank account. Please set another account as default first.", (object)[]);
    //         }

    //         // make default
    //         // $this->changeDefaultBankAccount($accountId, $newBankAccount);


    //         if (empty($oldBankAccount->id)) {
    //             DB::rollBack();
    //             return $this->responseJson(false, 404, "Old bank account not found.", (object)[]);
    //         }


    //         $deleted = $this->deleteBankAccount($accountId, $oldBankAccountId);

    //         if (empty($deleted->deleted) || $deleted->deleted !== true) {
    //             DB::rollBack();
    //             return $this->responseJson(false, 200, "Failed to delete old bank account.", (object)[]);
    //         }

    //         DB::commit();
    //         return $this->responseJson(true, 200, "Bank account updated successfully.", (object)[]);
    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         logger('General Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
    //         return $this->responseJson(false, 500, 'An unexpected error occurred. Please try again or contact support.', (object)[]);
    //     }
    // }
    public function updateBankDetails(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'routing_number' => [
                'required',
                'digits:9',
                'numeric',
                'regex:/^[0-9]{9}$/'
            ],
            'account_number' => 'required',
            'bank_account_id' => 'required',
            'account_holder_name' => 'required'
        ], [
            'routing_number.required' => 'Routing number is required.',
            'routing_number.digits' => 'Routing number must be exactly 9 digits.',
            'routing_number.numeric' => 'Routing number must contain only numbers.',
            'routing_number.regex' => 'Routing number must be exactly 9 digits with no spaces or special characters.',
            'account_number.required' => 'Account number is required.',
            'account_holder_name.required' => 'Account holder name is required.',
        ]);

        if ($validator->fails()) {
            return $this->responseJson(false, 422, $validator->errors()->first(), (object)[]);
        }

        DB::beginTransaction();
        try {
            $accountId = auth()->user()->stripe_account_id;
            $oldBankAccountId = $request->bank_account_id;

            // Step 1: Retrieve old bank account first
            $oldBankAccount = $this->retriveBankAccount($accountId, $oldBankAccountId);

            if (empty($oldBankAccount->id)) {
                DB::rollBack();
                return $this->responseJson(false, 404, "Old bank account not found.", (object)[]);
            }

            // Step 2: Check if it's the default for currency - if yes, return error
            if (!empty($oldBankAccount->default_for_currency)) {
                DB::rollBack();
                return $this->responseJson(false, 200, "Cannot update default bank account. Please set another account as default first.", (object)[]);
            }

            // Step 3: Delete old bank account first
            $deleted = $this->deleteBankAccount($accountId, $oldBankAccountId);

            if (empty($deleted->deleted) || $deleted->deleted !== true) {
                DB::rollBack();
                return $this->responseJson(false, 200, "Failed to delete old bank account.", (object)[]);
            }

            // Step 4: Add new bank account
            $newBankAccount = $this->addBankAccount(
                $accountId,
                'USD',
                $request->account_holder_name,
                $request->routing_number,
                $request->account_number
            );

            if (!$newBankAccount) {
                DB::rollBack();
                return $this->responseJson(false, 200, "Failed to add new bank account.", (object)[]);
            }

            DB::commit();
            return $this->responseJson(true, 200, "Bank account updated successfully.", (object)[]);
        } catch (\Exception $e) {
            DB::rollBack();
            logger('General Error: ' . $e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, 'An unexpected error occurred. Please try again or contact support.', (object)[]);
        }
    }

    public function updateCompanyDetails(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'company_legal_name'      => 'required|string|max:255',
            'company_dba'             => 'sometimes|nullable|string|max:255',
            'country'                 => 'required',
            'phone_2'                 => 'required|digits:10',
            'tax_id'                  => 'required',
            'driver_license'          => 'sometimes|nullable',
            'driving_license_expiery' => 'sometimes|nullable|date|date_format:Y-m-d'
        ]);

        // Return validation errors if any
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        // Start a database transaction
        DB::beginTransaction();
        try {
            // Update or create the profile
            $isProfileCreated = Profile::updateOrCreate(
                ['user_id' => $request->user_id],
                [
                    'company_legal_name' => $request->company_legal_name,
                    'tax_id' => $request->tax_id,
                    'company_dba' => $request->company_dba ?: null,
                    'country_code' => $request->country,
                    'phone_2' => $request->phone_2,
                    'driving_license_no' => $request->driver_license ?: null,
                    'driving_license_expiery' => $request->driving_license_expiery ?: null
                ]
            );

            // Check if the profile was created or updated successfully
            if ($isProfileCreated) {
                // Commit the transaction
                DB::commit();

                return $this->responseJson(true, 200, 'Professional details uploaded', []);
            }
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollback();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'), (object)[]);
        }
    }
    public function updatePaymentTermsByUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pay_in' => 'required|numeric'
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }
        DB::beginTransaction();
        try {
            $updatePaymentTerms = PaymentTerms::updateOrCreate([
                'user_id' => $request->user_id
            ], [
                'is_default' => 1,
                'pay_in' => $request->pay_in
            ]);
            if ($updatePaymentTerms) {
                $data = ['completed_steps' => 4];
                if ($request->pay_in <= 7) {
                    $data['is_blocked'] = 0;
                }
                User::where('id', $request->user_id)->update($data);
                $this->notificationToContracter($request->user_id, "Registration", "Welcome to Conectar");
                DB::commit();
                return $this->responseJson(true, 200, 'Payment Terms Updated', []);
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message, (object)[]);
        }
    }
    public function getSubContractorList(Request $request)
    {
        // dd($request->all());
        try {
            $query = User::with('stateDetails', 'cityDetails')->withoutGlobalScope(ActiveScope::class)->whereHas('roles', function($q){
                $q->where('slug', 'sub-contractor');
            })->where('added_by', auth()->user()->id)->latest();

            // dd($query->where('user_type', 9)->latest()->get());
            if ($request->has('page')) {
                $contractorList = $query->paginate(10)->appends($request->except('page'));
                return new UserResourceCollection($contractorList);
            } else {
                $contractorList = $query->get();
                return $this->responseJson(true, 200, 'Sub contractor found', UserResource::collection($contractorList));
            }
        } catch (\Exception $e) {
            // Rollback the transaction on error
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function fetchPermissions(Request $request)
    {
        try {
            $type = $request->type ? $request->type : 0;
            $permissions = Permission::where('type', $type)->get()->groupBy('group_by');
            // dd($permissions);
            return $this->responseJson(true, 200, 'Sub contractor permissions found', $permissions);
        } catch (\Exception $e) {
            // Rollback the transaction on error
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
    public function updateUserPermissions(Request $request)
    {
        DB::beginTransaction();
        try {
            $user = User::where(['uuid' => $request->uuid])->first();
            if ($user) {
                $user->permissions()->detach();
                $user->givePermissionsTo($request->permissions);
                db::commit();
                return $this->responseJson(true, 200, 'Permissions updated successfully', (object)[]);
            }else{
                $status = false;
                $code = 500;
                $message = "Something went wrong";
                return $this->responseJson($status, $code, $message, (object)[]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            $status = false;
            $code = 500;
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            $message = "Something went wrong";
            return $this->responseJson($status, $code, $message, (object)[]);
        }
    }
}
