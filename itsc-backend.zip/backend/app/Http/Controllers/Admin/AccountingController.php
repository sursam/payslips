<?php

namespace App\Http\Controllers\Admin;

// use CityModels\{City, Job, Load, Profile, State, User, UserEmail};
use Dompdf\Dompdf;
use App\Models\Job;
use Dompdf\Options;
use App\Models\Load;
use App\Models\Role;
use App\Models\User;
use App\Models\Earning;
use App\Traits\UploadAble;
use App\Scopes\ActiveScope;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;



class AccountingController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        // Get the number of items per page from the request or default to 10
        $perPage = $request->input('per_page', 10);
        // dd($perPage);

        // Get the time filter from the request
        $perTime = $request->input('created_time', '');
        $old_new = $request->input('old_new', '');

        // Get the search term from the request
        $search = $request->input('search', '');

        // Fetch the independent list with the specified pagination and search filter
        $details = User::withoutGlobalScope(ActiveScope::class)->select('*', DB::raw('DATEDIFF(CURRENT_DATE, created_at) AS age_in_days'))
            ->where(function ($query) use ($search) {
                $query->where('first_name', 'like', "%{$search}%")
                    ->orWhere('last_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
            })
            ->when($perTime, function ($query) use ($perTime) {
                $query->having('age_in_days', '<=', $perTime);
            })
            ->when($old_new, function ($query) use ($old_new) {
                $query->where('is_export', '!=', $old_new);
            })->whereIn('user_type',['3','4'])
            ->latest()
            ->paginate($perPage);
        return view('admin.accounting.index', compact('details', 'search'));
    }



    public function job_invoice(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $search = $request->input('search', '');

        // Fetch the independent list with the specified pagination and search filter
        $job_list = Job::where('status', 3)->when($search, function ($query) use ($search) {
            $query->where('unique_id', 'like', "%{$search}%")
                ->orWhere('order_no', 'like', "%{$search}%");
        })->latest()
            ->paginate($perPage);

        return view('admin.accounting.job_invoice', compact('job_list', 'search'));
    }

    public function generated_pdf($id)
    {
        // Retrieve job details by ID
        $detail = Job::with('acceptedJobLoad','acceptedJobLoad.trucker','acceptedJobLoad.userTruckDetails')->find($id);

        // return view('admin.accounting.invoice_pdf', compact('detail'));

        // Check if the job exists
        if (!$detail) {
            return response()->json(['error' => 'Job not found'], 404);
        }

        // Set up Dompdf options
        $options = new Options();
        $options->set('isRemoteEnabled', true);

        // Create a new instance of Dompdf
        $dompdf = new Dompdf($options);

        // Load the HTML view for the PDF
        $html = view('admin.accounting.invoice_pdf', compact('detail'))->render();
        $dompdf->loadHtml($html);

        // Set the paper size and orientation
        $dompdf->setPaper('A4', 'landscape');

        // Render the PDF
        $dompdf->render();

        // Return the generated PDF as a response
        return $dompdf->stream('invoice.pdf', ['Attachment' => true]);
    }

    public function pay_in(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $search = $request->input('search', '');

        // Fetch the independent list with the specified pagination and search filter
        // $payin_list = Job::where('status', 1)->when($search, function ($query) use ($search) {
        //     $query->where('unique_id', 'like', "%{$search}%")
        //         ->orWhere('order_no', 'like', "%{$search}%");
        // })->latest()
        //     ->paginate($perPage);
        $payinList = Load::where('status', 4)
                ->whereHas('job', function ($query) use ($search) {
                    $query->when($search, function ($q) use ($search) {
                        $q->where('unique_id', 'like', "%{$search}%")
                        ->orWhere('order_no', 'like', "%{$search}%");
                    });
                })
                ->latest()
                ->paginate(request('per_page', 15));

            $payinList->getCollection()->each(function ($item) {
                $item->load_index = calculateLoadIndex($item->job_id, $item->id);
            });

        return view('admin.accounting.pay_in', compact('payinList', 'search'));
    }


    // public function pay_out(Request $request)
    // {
    //     $perPage = $request->input('per_page', 10);
    //     $payout_list = Load::where('status', 4)->latest()
    //         ->paginate($perPage);
    //     return view('admin.accounting.pay_out', compact('payout_list'));
    // }
    public function pay_out(Request $request)
    {
        $perPage = $request->input('per_page', 10);
        $payoutList = Earning::latest()->paginate($perPage);
        $payoutList->getCollection()->each(function ($item) {
            $item->load_index = calculateLoadIndex($item->job?->id, $item->jobLoad?->id);
        });
        return view('admin.accounting.pay_out', compact('payoutList'));
    }


}
