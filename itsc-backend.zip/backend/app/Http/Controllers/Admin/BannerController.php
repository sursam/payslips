<?php

namespace App\Http\Controllers\Admin;

use App\Models\AppBanner as Banner;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Scopes\ActiveScope;


class BannerController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = Banner::withoutGlobalScope(ActiveScope::class)->orderBy('position','asc')->get();
        return view('admin.banner.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'url' => 'required|url',
                    'description' => 'required|string'
                ]);
                $message = "Banner Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'url' => 'required|url',
                    'description' => 'required|string',
                    'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
                ]);
                $message = "Banner Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "url" => $request->url,
                    "description" => $request->description,
                ];
                if (empty($id)) {
                    $position = Banner::withoutGlobalScope(ActiveScope::class)->max('position') + 1;
                    $postData["position"] = $position;
                }
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_BANNER_UPLOAD_PATH'), $fileName, 'public');
                    // dd($isFileUploaded);
                    if ($isFileUploaded) {
                        $postData['file'] = $fileName;
                    }
                }
                $details = Banner::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.banner.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'app_banners');
            $details = Banner::withoutGlobalScope(ActiveScope::class)->find($uuid);
        }
        return view('admin.banner.add', compact('details'));
    }

    public function order(Request $request)
    {
        if ($request->post()) {
            DB::beginTransaction();
            try {

                foreach($request->order as $key => $value) {
                     Banner::withoutGlobalScope(ActiveScope::class)->where('id', $value)->update(['position' => $key+1]);
                }
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => '', 'data' => $details ?? null, 'url' => route('admin.banner.list')];
            return response($data);
        }
    }
}
