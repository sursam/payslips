<?php

namespace App\Http\Controllers\Admin;

use App\Models\TruckType;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class TruckTypeController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = TruckType::latest()->get();
        return view('admin.truck-type.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'specs' => 'required|numeric',
                    'weight_capacity' => 'required|numeric',

                ]);
                $message = "Truck Type Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'specs' => 'required|numeric',
                    'weight_capacity' => 'required|numeric',
                    'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
                ]);
                $message = "Truck Type Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "specs" => $request->specs,
                    "weight_capacity" => $request->weight_capacity
                ];

                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_TRUCK_TYPE_UPLOAD_PATH'), $fileName, 'public');
                    // dd($isFileUploaded);
                    if ($isFileUploaded) {
                        $postData['file'] = $fileName;
                    }
                }
                $details = TruckType::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.truck-type.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'truck_types');
            $details = TruckType::find($uuid);
        }
        return view('admin.truck-type.add', compact('details'));
    }
}
