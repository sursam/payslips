<?php

namespace App\Http\Controllers\Admin;

use App\Models\Material;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Models\MaterialOption;


class MaterialController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = Material::with('materialOptions')->latest()->get();
        return view('admin.material.index', compact('details'));
    }

    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'type' => 'required'
                ]);
                $message = "Material Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'type' => 'required'
                ]);
                $message = "Material Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "type" => $request->type
                ];
                $details = Material::updateOrCreate(['id' => $id], $postData);
                if (!empty($id)) {
                    MaterialOption::where('equipment_id', $id)->delete();
                }

                if (!empty($request->material_options[0])) {

                    foreach ($request->material_options as $key => $value) {
                        $option = MaterialOption::updateOrCreate([
                            'material_id' => $details->id,
                            'title' => $request->material_options[$key]
                        ]);
                    }
                }


                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.material.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'materials');
            $details = Material::with('materialOptions')->find($uuid);
        }
        return view('admin.material.add', compact('details'));
    }
}
