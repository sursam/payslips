<?php

namespace App\Http\Controllers\Admin;

use App\Models\Job;
use App\Models\Load;
use App\Models\User;
use App\Models\PaymentTerms;
use Illuminate\Http\Request;
use App\Models\GeneratedBill;
use Illuminate\Support\Carbon;
use App\Models\JobConfigureMap;
use App\Models\GeneratedInvoice;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BaseController;
use Intervention\Image\ImageManagerStatic as Image;

class ReportController extends BaseController
{
    public function complete_job_report(Request $request)
    {

        $destinations = Job::groupBy('destination')->pluck('destination');
        $sources = Job::groupBy('source')->pluck('source');
        $job_unique_ids = Job::groupBy('unique_id')->pluck('unique_id');
        $all_trucker = User::where('user_type', '4')->get();

        // Get filter values from request
        $destination = $request->input('search', '');
        $source = $request->input('source', '');
        $trucker = $request->input('trucker', '');
        $job_unique_id = $request->input('job_unique_id', '');
        $from_date = $request->input('from_date', '');
        $to_date = $request->input('to_date', '');
        $completed_from_date = $request->input('completed_from_date', '');
        $completed_to_date = $request->input('completed_to_date', '');
        $perPage = $request->input('per_page', 10);

        $query = Job::when($destination, function ($q, $destination) {
            $q->where('destination', $destination);
        })
            ->when($source, function ($q, $source) {
                $q->where('source', $source);
            })
            ->when($job_unique_id, function ($q, $job_unique_id) {
                $q->where('unique_id', $job_unique_id);
            })
            ->when($trucker, function ($q, $trucker) {
                $q->whereHas('jobLoad', function ($q) use ($trucker) {
                    $q->where('user_id', $trucker);
                });
            })
            ->when($from_date, function ($q, $from_date) {
                $q->whereDate('pickup_date_time', '>=', $from_date);
            })
            ->when($to_date, function ($q, $to_date) {
                $q->whereDate('pickup_date_time', '<=', $to_date);
            })

            ->when($completed_from_date, function ($q, $completed_from_date) {
                $q->whereDate('delivery_date_time', '>=', $completed_from_date);
            })
            ->when($completed_to_date, function ($q, $completed_to_date) {
                $q->whereDate('delivery_date_time', '<=', $completed_to_date);
            })->where('status', 3);

        if ($perPage == 'all') {
            $complete_job_list = $query->latest()->get();
        } else {
            $complete_job_list = $query->latest()->paginate($perPage);
        }

        return view('admin.report.complete-job-report', compact('complete_job_list', 'destinations', 'sources', 'job_unique_ids', 'all_trucker'));
    }
    public function comission_report(Request $request)
    {
        $destinations = Job::groupBy('destination')->pluck('destination');
        $sources = Job::groupBy('source')->pluck('source');
        $job_unique_ids = Job::groupBy('unique_id')->pluck('unique_id');
        $all_trucker = User::where('user_type', '4')->get();

        // Get filter values from request
        $destination = $request->input('search', '');
        $source = $request->input('source', '');
        $trucker = $request->input('trucker', '');
        $job_unique_id = $request->input('job_unique_id', '');
        $from_date = $request->input('from_date', '');
        $to_date = $request->input('to_date', '');
        $completed_from_date = $request->input('completed_from_date', '');
        $completed_to_date = $request->input('completed_to_date', '');
        $perPage = $request->input('per_page', 10);

        $query = Job::when($destination, function ($q, $destination) {
            $q->where('destination', $destination);
        })
            ->when($source, function ($q, $source) {
                $q->where('source', $source);
            })
            ->when($job_unique_id, function ($q, $job_unique_id) {
                $q->where('unique_id', $job_unique_id);
            })
            ->when($trucker, function ($q, $trucker) {
                $q->whereHas('jobLoad', function ($q) use ($trucker) {
                    $q->where('user_id', $trucker);
                });
            })
            ->when($from_date, function ($q, $from_date) {
                $q->whereDate('pickup_date_time', '>=', $from_date);
            })
            ->when($to_date, function ($q, $to_date) {
                $q->whereDate('pickup_date_time', '<=', $to_date);
            })

            ->when($completed_from_date, function ($q, $completed_from_date) {
                $q->whereDate('delivery_date_time', '>=', $completed_from_date);
            })
            ->when($completed_to_date, function ($q, $completed_to_date) {
                $q->whereDate('delivery_date_time', '<=', $completed_to_date);
            })->where('status', 3);

        if ($perPage == 'all') {
            $comission_data = $query->latest()->get();
        } else {
            $comission_data = $query->latest()->paginate($perPage);
        }

        return view('admin.report.comission-report', compact('comission_data', 'destinations', 'sources', 'job_unique_ids', 'all_trucker'));
    }
    public function report_and_bills(Request $request)
    {

        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);
        $tracker_id = $request->input('tracker_id', '');
        $bill_date = $request->input('bill_date', '');
        $due_date = $request->input('due_date', '');
        $bill_no = $request->input('bill_no', '');

        $vendors = User::where('user_type', 4)->get();


        // Fetch the independent list with the specified pagination and search filter
        $query = GeneratedBill::with('user')->when($tracker_id, function ($query) use ($tracker_id) {
            $query->where('user_id', $tracker_id);
        })->when($bill_date, function ($q, $bill_date) {
            $q->whereDate('from_date', '=', $bill_date);
        })->when($due_date, function ($q, $due_date) {
            $q->whereDate('to_date', '=', $due_date);
        })->when($bill_no, function ($q, $bill_no) {
            $q->where('bill_no', 'like', '%' . $bill_no . '%');
        })->latest();

        if ($perPage == 'all') {
            $generated_bills = $query->latest()->get();
        } else {
            $generated_bills = $query->latest()->paginate($perPage);
        }
        return view('admin.report.report-and-bills', compact('generated_bills', 'vendors'));
    }
    public function generate_bill_old(Request $request)
    {
        if ($request->post()) {
            DB::beginTransaction();
            try {
                $from_date = $request->input('from_date', '');
                $to_date = $request->input('to_date', '');
                $completed_from_date = $request->input('completed_from_date', '');
                $completed_to_date = $request->input('completed_to_date', '');

                $bill_date = '';
                $due_date = '';

                if (!empty($from_date) && !empty($to_date)) {
                    $bill_date = date('Y-m-d', strtotime($from_date . ' this monday'));
                    $due_date = date('Y-m-d', strtotime($from_date . ' +2 weeks Friday'));
                }
                if (!empty($completed_from_date) && !empty($completed_to_date)) {
                    $bill_date = date('Y-m-d', strtotime($completed_from_date . ' this monday'));
                    $due_date = date('Y-m-d', strtotime($completed_from_date . ' +2 weeks Friday'));
                }
                dd($bill_date, $due_date);

                $load_details = Load::select('user_id', 'id')
                    ->when($from_date, function ($q, $from_date) {
                        $q->whereDate('started_on', '>=', $from_date);
                    })
                    ->when($to_date, function ($q, $to_date) {
                        $q->whereDate('started_on', '<=', $to_date);
                    })
                    ->when($completed_from_date, function ($q, $completed_from_date) {
                        $q->whereDate('completed_on', '>=', $completed_from_date);
                    })
                    ->when($completed_to_date, function ($q, $completed_to_date) {
                        $q->whereDate('completed_on', '<=', $completed_to_date);
                    })
                    ->get()
                    ->groupBy('user_id')
                    ->map(function ($jobs) {
                        return $jobs->pluck('id')->toArray();
                    })
                    ->toArray();

                // dd($load_details);

                if (!empty($load_details)) {
                    foreach ($load_details as $user_id => $ids) {
                        // dd($user_id);/
                        $loaddetails = Load::whereIn('id', $ids)
                            ->where('status', 4)
                            // ->where('is_bill_generated', 0)
                            ->get()
                            ->pluck('load_cost')
                            ->toArray();

                        $total_cost = array_sum($loaddetails);
                        if ($total_cost > 0) {
                            $bill_no = rand(10000, 99999);
                            $user_details = User::where('id', $user_id)->first();
                            $name = substr($user_details?->first_name, 0, 3); // Ensure user
                            $postData = [
                                "bill_no" => $bill_no . $name,
                                "user_id" => $user_id,
                                "from_date" => $bill_date,
                                "to_date" => $due_date,
                                "amount" => $total_cost,
                            ];

                            GeneratedBill::create($postData);

                            foreach ($ids as $id) {
                                Load::where('id', $id)->where('status', 4)->update(['is_bill_generated' => 1]);
                            }
                        }
                    }
                    $message = "Generated";
                } else {
                    $message = "Generated";
                }
                DB::commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => null, 'url' => route('admin.report.report-and-bills')];
            return response($data);
        }
    }
    public function generate_bill_v1(Request $request)
    {
        if ($request->isMethod('post')) {
            $request->validate([
                'from_date' => 'required_without:completed_from_date',
                'to_date' => 'required_with:from_date',
                'completed_from_date' => 'required_without:from_date',
                'completed_to_date' => 'required_with:completed_from_date',
            ]);


            DB::beginTransaction();

            try {
                $from_date = $request->input('from_date', '');
                $to_date = $request->input('to_date', '');
                $completed_from_date = $request->input('completed_from_date', '');
                $completed_to_date = $request->input('completed_to_date', '');

                if ($from_date && $to_date && strtotime($from_date) > strtotime($to_date)) {
                    return response()->json(['status' => false, 'message' => 'From date cannot be after To date'], 200);
                }
                if ($completed_from_date && $completed_to_date && strtotime($completed_from_date) > strtotime($completed_to_date)) {
                    return response()->json(['status' => false, 'message' => 'Completed From date cannot be after Completed To date'], 200);
                }

                // Bill & Due Dates
                $bill_date = '';
                $due_date = '';
                $description_start_date = '';
                $description_end_date = '';
                if (!empty($from_date) && !empty($to_date)) {
                    // Get the Sunday of the week containing from_date
                    $bill_date = date('Y-m-d', strtotime('last sunday', strtotime($from_date)));
                    // Get Friday 2 weeks after from_date
                    $due_date = date('Y-m-d', strtotime('friday +1 weeks', strtotime($from_date)));

                    // Set description dates
                    $description_start_date = $bill_date;
                    $description_end_date = date('Y-m-d', strtotime('next saturday', strtotime($from_date)));
                }
                if (!empty($completed_from_date) && !empty($completed_to_date)) {
                    // Get the Sunday of the week containing completed_from_date
                    $bill_date = date('Y-m-d', strtotime('last sunday', strtotime($completed_from_date)));
                    // Get Friday 2 weeks after completed_from_date
                    $due_date = date('Y-m-d', strtotime('friday +1 weeks', strtotime($completed_from_date)));

                    // Set description dates
                    $description_start_date = $bill_date;
                    $description_end_date = date('Y-m-d', strtotime('next saturday', strtotime($completed_from_date)));
                }

                // Check if bill with same dates already exists
                $existingBill = GeneratedBill::where('from_date', $bill_date)
                    ->where('to_date', $due_date)
                    ->exists();

                if ($existingBill) {
                    return $this->responseJson(false, 200, 'Bill for this period has already been generated', null);
                }

                $load_details = Load::select('user_id', 'id')
                    ->when($from_date, fn($q) => $q->whereDate('started_on', '>=', $from_date))
                    ->when($to_date, fn($q) => $q->whereDate('started_on', '<=', $to_date))
                    ->when($completed_from_date, fn($q) => $q->whereDate('completed_on', '>=', $completed_from_date))
                    ->when($completed_to_date, fn($q) => $q->whereDate('completed_on', '<=', $completed_to_date))
                    ->get()
                    ->groupBy('user_id')
                    ->map(fn($jobs) => $jobs->pluck('id')->toArray())
                    ->toArray();
                if (empty($load_details)) {
                    return $this->responseJson(false, 200, 'No load records found for selected filters', null);
                }
                foreach ($load_details as $user_id => $ids) {
                    $loaddetails = Load::whereIn('id', $ids)
                        ->where('status', 4)
                        ->where('is_bill_generated', 0)
                        ->get();

                    if ($loaddetails->isEmpty()) {
                        continue;
                    }

                    $truckerGet = $loaddetails->pluck('trucker_get')->toArray();
                    $total_cost = array_sum($truckerGet);

                    if ($total_cost > 0) {
                        $user_details = User::find($user_id);
                        if (!$user_details) {
                            continue;
                        }

                        $name = substr($user_details->first_name ?? '', 0, 3);

                        // Unique Bill No
                        do {
                            $bill_no = rand(10000, 99999) . strtoupper($name);
                        } while (GeneratedBill::where('bill_no', $bill_no)->exists());

                        $postData = [
                            "bill_no" => $bill_no,
                            "user_id" => $user_id,
                            "from_date" => $bill_date,
                            "to_date" => $due_date,
                            "description_start_date" => $description_start_date,
                            "description_end_date" => $description_end_date,
                            "load_ids" => implode(',', $loaddetails->pluck('id')->toArray()),
                            "amount" => $total_cost,
                        ];
                        // before truncate change the is_bill_generated to 0 for deleted rows
                        Load::whereIn('id', $loaddetails->pluck('id')->toArray())
                            ->update(['is_bill_generated' => 0]);
                        GeneratedBill::truncate(); // Clear previous data 
                        GeneratedBill::create($postData);

                        Load::whereIn('id', $loaddetails->pluck('id')->toArray())
                            ->update(['is_bill_generated' => 1]);
                    }
                }

                DB::commit();

                return response()->json([
                    'status' => true,
                    'message' => 'Bill generation completed successfully.',
                    'data' => null,
                    'url' => route('admin.report.report-and-bills'),
                ]);
            } catch (\Throwable $th) {
                DB::rollback();
                return response()->json([
                    'status' => false,
                    'code' => 500,
                    'message' => config('constants.CATCH_ERROR_MSG'),
                    'error' => $th->getMessage() . "---" . $th->getLine(),
                ]);
            }
        }
    }
    public function generate_bill(Request $request)
    {
        if ($request->isMethod('post')) {
            $request->validate([
                'from_date' => 'required_without:completed_from_date',
                'to_date' => 'required_with:from_date',
                'completed_from_date' => 'required_without:from_date',
                'completed_to_date' => 'required_with:completed_from_date',
            ]);

            DB::beginTransaction();

            try {
                $from_date = $request->input('from_date', '');
                $to_date = $request->input('to_date', '');
                $completed_from_date = $request->input('completed_from_date', '');
                $completed_to_date = $request->input('completed_to_date', '');

                if ($from_date && $to_date && strtotime($from_date) > strtotime($to_date)) {
                    return response()->json(['status' => false, 'message' => 'From date cannot be after To date'], 200);
                }
                if ($completed_from_date && $completed_to_date && strtotime($completed_from_date) > strtotime($completed_to_date)) {
                    return response()->json(['status' => false, 'message' => 'Completed From date cannot be after Completed To date'], 200);
                }

                // Bill & Due Dates
                $bill_date = '';
                $due_date = '';
                $description_start_date = '';
                $description_end_date = '';

                if (!empty($from_date) && !empty($to_date)) {
                    // Get the Sunday of the week containing from_date (or from_date if it's already Sunday)
                    $from_timestamp = strtotime($from_date);
                    $day_of_week = date('w', $from_timestamp); // 0 = Sunday, 1 = Monday, etc.

                    if ($day_of_week == 0) {
                        $bill_date = $from_date; // Already Sunday
                    } else {
                        $bill_date = date('Y-m-d', strtotime('-' . $day_of_week . ' days', $from_timestamp));
                    }

                    // Get Friday 1 week after from_date
                    $due_date = date('Y-m-d', strtotime('friday +1 weeks', $from_timestamp));

                    // Set description dates
                    $description_start_date = $bill_date;
                    $description_end_date = date('Y-m-d', strtotime($bill_date . ' +6 days')); // Saturday of same week
                }

                if (!empty($completed_from_date) && !empty($completed_to_date)) {
                    // Get the Sunday of the week containing completed_from_date
                    $completed_timestamp = strtotime($completed_from_date);
                    $day_of_week = date('w', $completed_timestamp);

                    if ($day_of_week == 0) {
                        $bill_date = $completed_from_date; // Already Sunday
                    } else {
                        $bill_date = date('Y-m-d', strtotime('-' . $day_of_week . ' days', $completed_timestamp));
                    }

                    // Get Friday 1 week after completed_from_date
                    $due_date = date('Y-m-d', strtotime('friday +1 weeks', $completed_timestamp));

                    // Set description dates
                    $description_start_date = $bill_date;
                    $description_end_date = date('Y-m-d', strtotime($bill_date . ' +6 days')); // Saturday of same week
                }

                // Check if bill with same dates already exists
                $existingBill = GeneratedBill::where('from_date', $bill_date)
                    ->where('to_date', $due_date)
                    ->exists();

                if ($existingBill) {
                    return $this->responseJson(false, 200, 'Bill for this period has already been generated', null);
                }

                $load_details = Load::select('user_id', 'id')
                    ->when($from_date, fn($q) => $q->whereDate('started_on', '>=', $from_date))
                    ->when($to_date, fn($q) => $q->whereDate('started_on', '<=', $to_date))
                    ->when($completed_from_date, fn($q) => $q->whereDate('completed_on', '>=', $completed_from_date))
                    ->when($completed_to_date, fn($q) => $q->whereDate('completed_on', '<=', $completed_to_date))
                    ->get()
                    ->groupBy('user_id')
                    ->map(fn($jobs) => $jobs->pluck('id')->toArray())
                    ->toArray();

                if (empty($load_details)) {
                    return $this->responseJson(false, 200, 'No load records found for selected filters', null);
                }

                $bills_created = 0;

                // FIXED: Move truncate outside the loop and add condition
                // $should_clear_previous = $request->input('clear_previous_bills', false);
                // if ($should_clear_previous) {
                // GeneratedBill::truncate(); // Only clear if explicitly requested
                // }
                // GeneratedBill::query()->delete();
                // Load::where('is_bill_generated', 1)->update(['is_bill_generated' => 0]);
                GeneratedBill::query()->update([
                    'is_generated' => 1
                ]);
                foreach ($load_details as $user_id => $ids) {
                    $loaddetails = Load::whereIn('id', $ids)
                        ->where('status', 4)
                        ->where('is_bill_generated', 0)
                        ->get();

                    if ($loaddetails->isEmpty()) {
                        continue;
                    }

                    $truckerGet = $loaddetails->pluck('trucker_get')->toArray();
                    $total_cost = array_sum($truckerGet);

                    if ($total_cost > 0) {
                        $user_details = User::find($user_id);
                        if (!$user_details) {
                            continue;
                        }

                        $name = substr($user_details->first_name ?? '', 0, 3);

                        // Unique Bill No with better collision handling
                        $attempts = 0;
                        do {
                            $bill_no = rand(10000, 99999) . strtoupper($name);
                            $attempts++;

                            // Prevent infinite loop
                            if ($attempts > 100) {
                                throw new \Exception("Unable to generate unique bill number after 100 attempts");
                            }
                        } while (GeneratedBill::where('bill_no', $bill_no)->exists());

                        $postData = [
                            "bill_no" => $bill_no,
                            "user_id" => $user_id,
                            "from_date" => $bill_date,
                            "to_date" => $due_date,
                            "description_start_date" => $description_start_date,
                            "description_end_date" => $description_end_date,
                            "load_ids" => implode(',', $loaddetails->pluck('id')->toArray()),
                            "amount" => $total_cost,
                        ];

                        // Create the bill
                        GeneratedBill::create($postData);

                        // Update load records to mark as billed
                        Load::whereIn('id', $loaddetails->pluck('id')->toArray())
                            ->update(['is_bill_generated' => 1]);

                        $bills_created++;
                    }
                }

                DB::commit();

                return response()->json([
                    'status' => true,
                    'message' => "Bill generation completed successfully. {$bills_created} bills created.",
                    'data' => ['bills_created' => $bills_created],
                    'url' => route('admin.report.report-and-bills'),
                ]);
            } catch (\Throwable $th) {
                DB::rollback();

                // Reset any loads that might have been marked as billed during the failed transaction
                if (!empty($load_details)) {
                    foreach ($load_details as $user_id => $ids) {
                        Load::whereIn('id', $ids)->update(['is_bill_generated' => 0]);
                    }
                }

                return response()->json([
                    'status' => false,
                    'code' => 500,
                    'message' => $th->getMessage() . " on line " . $th->getLine(),
                    'error' => $th->getMessage() . " on line " . $th->getLine(),
                ]);
            }
        }
    }
    public function job_report(Request $request)
    {
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $search = $request->input('search', '');

        $filter_type = $request->input('filter_type', '');

        // Fetch the independent list with the specified pagination and search filter
        $job_list = Job::with('user')->when($search, function ($query) use ($search) {
            $query->where('bill_no', 'like', "%{$search}%");
        })->latest()->paginate($perPage);

        $destinations = Job::select('destination')->groupBy('destination')->get();
        $sources = Job::select('source')->groupBy('source')->get();
        $order_nos = Job::select('order_no')->groupBy('order_no')->get();
        $contractors = User::where('user_type', 3)->get();
        $pickup_location_companys = Job::select('pickup_location_company')->groupBy('pickup_location_company')->get();
        $drop_off_location_companys = Job::select('drop_off_location_company')->groupBy('drop_off_location_company')->get();
        $truckers = User::where('user_type', 4)->get();

        return view('admin.report.job-report', compact('job_list', 'destinations', 'sources', 'order_nos', 'contractors', 'drop_off_location_companys', 'truckers', 'pickup_location_companys'));
    }
    public function invoice_report(Request $request)
    {

        $perPage = $request->input('per_page', 10);
        $vendor_id = $request->input('vendor_id', '');
        $invoice_date = $request->input('invoice_date', '');
        $due_date = $request->input('due_date', '');
        $invoice_no = $request->input('invoice_no', '');
        $vendors = User::where('user_type', 3)->get();

        // Fetch the independent list with the specified pagination and search filter
        $query = GeneratedInvoice::with('user')->when($vendor_id, function ($query) use ($vendor_id) {
            $query->where('user_id', $vendor_id);
        })->when($invoice_date, function ($q, $invoice_date) {
            $q->whereDate('from_date', '=', $invoice_date);
        })->when($due_date, function ($q, $due_date) {
            $q->whereDate('to_date', '=', $due_date);
        })->latest();

        if ($perPage == 'all') {
            $generated_invoices = $query->latest()->get();
        } else {
            $generated_invoices = $query->latest()->paginate($perPage);
        }

        return view('admin.report.invoice-report', compact('generated_invoices', 'vendors'));
    }
    public function generate_invoice_old(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'from_date' => 'required_without:completed_from_date',
                'to_date' => 'required_with:from_date',
                'completed_from_date' => 'required_without:from_date',
                'completed_to_date' => 'required_with:completed_from_date',
            ]);
            DB::beginTransaction();
            try {
                $from_date = $request->input('from_date', '');
                $to_date = $request->input('to_date', '');
                $completed_from_date = $request->input('completed_from_date', '');
                $completed_to_date = $request->input('completed_to_date', '');

                $invoice_date = '';
                $due_date = '';

                if (!empty($from_date) && !empty($to_date)) {
                    $invoice_date = date('Y-m-d', strtotime($from_date . ' this monday'));
                    $due_date = date('Y-m-d', strtotime($from_date . ' +2 weeks Friday'));
                }
                if (!empty($completed_from_date) && !empty($completed_to_date)) {
                    $invoice_date = date('Y-m-d', strtotime($completed_from_date . ' this monday'));
                    $due_date = date('Y-m-d', strtotime($completed_from_date . ' +2 weeks Friday'));
                }



                $job_details = Job::select('user_id', 'id')
                    ->when($from_date, function ($q, $from_date) {
                        $q->whereDate('pickup_date_time', '>=', $from_date);
                    })
                    ->when($to_date, function ($q, $to_date) {
                        $q->whereDate('pickup_date_time', '<=', $to_date);
                    })
                    ->when($completed_from_date, function ($q, $completed_from_date) {
                        $q->whereDate('delivery_date_time', '>=', $completed_from_date);
                    })
                    ->when($completed_to_date, function ($q, $completed_to_date) {
                        $q->whereDate('delivery_date_time', '<=', $completed_to_date);
                    })
                    ->get()
                    ->groupBy('user_id')
                    ->map(function ($jobs) {
                        return $jobs->pluck('id')->toArray();
                    })
                    ->toArray();

                if (!empty($job_details)) {
                    foreach ($job_details as $user_id => $job_ids) {
                        $load_details = Load::whereIn('job_id', $job_ids)
                            // ->where('status', 4)
                            // ->where('is_invoice_generated', 0)
                            ->get()
                            ->pluck('load_cost')
                            ->toArray();

                        $total_cost = array_sum($load_details);
                        if ($total_cost > 0) {
                            $invoice_no = rand(10000, 99999);
                            $user_details = User::where('id', $user_id)->first();
                            $name = substr($user_details->first_name, 0, 3); // Ensure user
                            $postData = [
                                "payment_terms" => $user_details?->paymentTerms?->pay_in,
                                "invoice_no" => $invoice_no . $name,
                                "user_id" => $user_id,
                                "from_date" => $invoice_date,
                                "to_date" => $due_date,
                                "amount" => $total_cost,
                            ];

                            GeneratedInvoice::create($postData);

                            foreach ($job_ids as $job_id) {
                                Load::where('job_id', $job_id)->where('status', 4)->update(['is_invoice_generated' => 1]);
                            }
                        }
                    }
                    $message = "Generated";
                } else {
                    $message = "Generated";
                }
                DB::commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => null, 'url' => route('admin.report.invoice-report')];
            return response($data);
        }
    }
    // public function generate_invoice(Request $request)
    // {
    //     if (!$request->post()) {
    //         return response()->json(['status' => false, 'message' => 'Invalid request method'], 405);
    //     }

    //     $request->validate([
    //         'from_date' => 'required_without:completed_from_date|date',
    //         'to_date' => 'required_with:from_date|date|after_or_equal:from_date',
    //         'completed_from_date' => 'required_without:from_date|date',
    //         'completed_to_date' => 'required_with:completed_from_date|date|after_or_equal:completed_from_date',
    //     ]);

    //     DB::beginTransaction();

    //     try {
    //         $dates = $this->extractDates($request);
    //         $invoiceDates = $this->calculateInvoiceDates($dates);

    //         // Check for existing invoice with same dates
    //         // if ($this->invoiceExistsForPeriod($invoiceDates)) {
    //         //     return $this->responseJson(false, 200, 'Invoice for this time period has already been generated', null);
    //         // }

    //         $jobDetails = $this->getJobDetails($dates);

    //         if (empty($jobDetails)) {
    //             return response()->json([
    //                 'status' => false,
    //                 'message' => 'No jobs found for selected date ranges.',
    //                 'data' => null
    //             ], 200);
    //         }

    //         $invoicesGenerated = $this->processInvoices($jobDetails, $invoiceDates);

    //         if ($invoicesGenerated === 0) {
    //             return response()->json([
    //                 'status' => false,
    //                 'message' => 'No eligible loads found for invoice generation.',
    //                 'data' => null
    //             ], 200);
    //         }

    //         DB::commit();

    //         return response()->json([
    //             'status' => true,
    //             'message' => "Successfully generated {$invoicesGenerated} invoice(s).",
    //             'data' => null,
    //             'url' => route('admin.report.invoice-report'),
    //         ]);
    //     } catch (\Throwable $th) {
    //         DB::rollback();
    //         return $this->responseJson(false, 500, config('constants.CATCH_ERROR_MSG'), $th->getMessage());
    //     }
    // }
    // private function extractDates(Request $request): array
    // {
    //     return [
    //         'from_date' => $request->input('from_date', ''),
    //         'to_date' => $request->input('to_date', ''),
    //         'completed_from_date' => $request->input('completed_from_date', ''),
    //         'completed_to_date' => $request->input('completed_to_date', ''),
    //     ];
    // }
    // private function calculateInvoiceDates(array $dates): array
    // {
    //     $baseDate = !empty($dates['from_date']) ? $dates['from_date'] : $dates['completed_from_date'];

    //     return [
    //         'invoice_date' => date('Y-m-d', strtotime('last sunday', strtotime($baseDate))),
    //         'base_date' => $baseDate,
    //         'description_start_date' => date('Y-m-d', strtotime('last sunday', strtotime($baseDate))),
    //         // 'description_end_date' => date('Y-m-d', strtotime('+6 days', strtotime($baseDate))),
    //         'description_end_date' => date('Y-m-d', strtotime($baseDate . ' +4 days'))
    //     ];
    // }
    // private function invoiceExistsForPeriod(array $invoiceDates): bool
    // {
    //     return GeneratedInvoice::where('from_date', $invoiceDates['invoice_date'])->exists();
    // }
    // private function getJobDetails(array $dates): array
    // {
    //     return Job::select('user_id', 'id')
    //         ->when($dates['from_date'], fn($q) => $q->whereDate('pickup_date_time', '>=', $dates['from_date']))
    //         ->when($dates['to_date'], fn($q) => $q->whereDate('pickup_date_time', '<=', $dates['to_date']))
    //         ->when($dates['completed_from_date'], fn($q) => $q->whereDate('delivery_date_time', '>=', $dates['completed_from_date']))
    //         ->when($dates['completed_to_date'], fn($q) => $q->whereDate('delivery_date_time', '<=', $dates['completed_to_date']))
    //         ->get()
    //         ->groupBy('user_id')
    //         ->map(fn($jobs) => $jobs->pluck('id')->toArray())
    //         ->toArray();
    // }
    // private function processInvoices(array $jobDetails, array $invoiceDates): int
    // {
    //     $invoicesGenerated = 0;

    //     // Bulk fetch users and payment terms to reduce queries
    //     $userIds = array_keys($jobDetails);
    //     $users = User::with('paymentTerms')->whereIn('id', $userIds)->get()->keyBy('id');

    //     foreach ($jobDetails as $userId => $jobIds) {
    //         $user = $users->get($userId);
    //         if (!$user) continue;

    //         $contractorPaymentTerms = $user->paymentTerms->pay_in ?? 30;

    //         $loadDetails = Load::whereIn('job_id', $jobIds)
    //             ->where('status', 4)
    //             ->get();

    //         if ($loadDetails->isEmpty()) continue;

    //         $totalCost = $loadDetails->sum('load_cost');
    //         if ($totalCost <= 0) continue;

    //         $invoiceData = $this->prepareInvoiceData($user, $contractorPaymentTerms, $invoiceDates, $totalCost, $jobIds);

    //         if ($this->createInvoice($invoiceData, $jobIds)) {
    //             $invoicesGenerated++;
    //         }
    //     }

    //     return $invoicesGenerated;
    // }
    // private function prepareInvoiceData(User $user, int $contractorPaymentTerms, array $invoiceDates, float $totalCost, array $jobIds): array
    // {
    //     $name = strtoupper(substr($user->first_name ?? 'XXX', 0, 3));

    //     // Generate unique invoice number
    //     do {
    //         $invoiceNo = rand(10000, 99999) . $name;
    //     } while (GeneratedInvoice::where('invoice_no', $invoiceNo)->exists());

    //     $dueDate = date('Y-m-d', strtotime($invoiceDates['invoice_date'] . ' +' . $contractorPaymentTerms . ' days'));

    //     return [
    //         'payment_terms' => $user->paymentTerms->pay_in ?? null,
    //         'invoice_no' => $invoiceNo,
    //         'user_id' => $user->id,
    //         'from_date' => $invoiceDates['invoice_date'],
    //         'to_date' => $dueDate,
    //         'description_start_date' => $invoiceDates['description_start_date'],
    //         'description_end_date' => $invoiceDates['description_end_date'],
    //         'load_ids' => implode(',', $jobIds),
    //         'amount' => $totalCost,
    //     ];
    // }
    // private function createInvoice(array $invoiceData, array $jobIds): bool
    // {
    //     try {
    //         // before create invoice, reset is_invoice_generated to 0 for the jobs
    //         Load::whereIn('job_id', $jobIds)
    //             ->where('status', 4)
    //             ->update(['is_invoice_generated' => 0]);
    //         // Create the invoice
    //         GeneratedInvoice::query()->delete(); // Clear previous data
    //         GeneratedInvoice::create($invoiceData);

    //         Load::whereIn('job_id', $jobIds)
    //             ->where('status', 4)
    //             ->where('is_invoice_generated', 0)
    //             ->update(['is_invoice_generated' => 1]);

    //         return true;
    //     } catch (\Exception $e) {
    //         // Log error if needed
    //         return false;
    //     }
    // }
    public function generate_invoice(Request $request)
    {
        if (!$request->post()) {
            return response()->json(['status' => false, 'message' => 'Invalid request method'], 405);
        }

        $request->validate([
            'from_date' => 'required_without:completed_from_date|date',
            'to_date' => 'required_with:from_date|date|after_or_equal:from_date',
            'completed_from_date' => 'required_without:from_date|date',
            'completed_to_date' => 'required_with:completed_from_date|date|after_or_equal:completed_from_date',
        ]);

        DB::beginTransaction();

        try {
            // Extract dates from request
            $dates = [
                'from_date' => $request->input('from_date', ''),
                'to_date' => $request->input('to_date', ''),
                'completed_from_date' => $request->input('completed_from_date', ''),
                'completed_to_date' => $request->input('completed_to_date', ''),
            ];

            // Calculate invoice dates
            $baseDate = !empty($dates['from_date']) ? $dates['from_date'] : $dates['completed_from_date'];
            $invoiceDates = [
                'invoice_date' => date('Y-m-d', strtotime('last sunday', strtotime($baseDate))),
                'base_date' => $baseDate,
                'description_start_date' => date('Y-m-d', strtotime('last sunday', strtotime($baseDate))),
                'description_end_date' => date('Y-m-d', strtotime($baseDate . ' +4 days'))
            ];

            // Check for existing invoice with same dates
            if (GeneratedInvoice::where('from_date', $invoiceDates['invoice_date'])->exists()) {
                return $this->responseJson(false, 200, 'Invoice for this time period has already been generated', null);
            }

            // Get job details grouped by user
            $jobDetails = Job::select('user_id', 'id')
                ->when($dates['from_date'], fn($q) => $q->whereDate('pickup_date_time', '>=', $dates['from_date']))
                ->when($dates['to_date'], fn($q) => $q->whereDate('pickup_date_time', '<=', $dates['to_date']))
                ->when($dates['completed_from_date'], fn($q) => $q->whereDate('delivery_date_time', '>=', $dates['completed_from_date']))
                ->when($dates['completed_to_date'], fn($q) => $q->whereDate('delivery_date_time', '<=', $dates['completed_to_date']))
                ->get()
                ->groupBy('user_id')
                ->map(fn($jobs) => $jobs->pluck('id')->toArray())
                ->toArray();

            if (empty($jobDetails)) {
                return response()->json([
                    'status' => false,
                    'message' => 'No jobs found for selected date ranges.',
                    'data' => null
                ], 200);
            }

            // Process invoices for each user
            $invoicesGenerated = 0;

            // Bulk fetch users and payment terms to reduce queries
            $userIds = array_keys($jobDetails);
            $users = User::with('paymentTerms')->whereIn('id', $userIds)->get()->keyBy('id');

            foreach ($jobDetails as $userId => $jobIds) {
                $user = $users->get($userId);
                if (!$user) continue;

                $contractorPaymentTerms = $user->paymentTerms->pay_in ?? 30;

                $loadDetails = Load::whereIn('job_id', $jobIds)
                    ->where('status', 4)
                    ->get();

                if ($loadDetails->isEmpty()) continue;

                $totalCost = $loadDetails->sum('load_cost');
                if ($totalCost <= 0) continue;

                // Prepare invoice data
                $name = strtoupper(substr($user->first_name ?? 'XXX', 0, 3));

                // Generate unique invoice number
                do {
                    $invoiceNo = rand(10000, 99999) . $name;
                } while (GeneratedInvoice::where('invoice_no', $invoiceNo)->exists());

                $dueDate = date('Y-m-d', strtotime($invoiceDates['invoice_date'] . ' +' . $contractorPaymentTerms . ' days'));

                $invoiceData = [
                    'payment_terms' => $user->paymentTerms->pay_in ?? null,
                    'invoice_no' => $invoiceNo,
                    'user_id' => $user->id,
                    'from_date' => $invoiceDates['invoice_date'],
                    'to_date' => $dueDate,
                    'description_start_date' => $invoiceDates['description_start_date'],
                    'description_end_date' => $invoiceDates['description_end_date'],
                    'load_ids' => implode(',', $jobIds),
                    'amount' => $totalCost,
                    'is_generated' => 0
                ];

                // Create invoice
                try {
                    // Reset is_invoice_generated to 0 for the jobs before creating invoice
                    // Load::whereIn('job_id', $jobIds)
                    //     ->where('status', 4)
                    //     ->update(['is_invoice_generated' => 0]);

                    // // Create the invoice
                    // GeneratedInvoice::query()->delete(); // Clear previous data
                    GeneratedInvoice::query()->update([
                        'is_generated' => 1
                    ]);
                    GeneratedInvoice::create($invoiceData);

                    // Update loads as invoiced
                    Load::whereIn('job_id', $jobIds)
                        ->where('status', 4)
                        ->where('is_invoice_generated', 0)
                        ->update(['is_invoice_generated' => 1]);

                    $invoicesGenerated++;
                } catch (\Exception $e) {
                    // Continue to next user if this invoice fails
                    continue;
                }
            }

            if ($invoicesGenerated === 0) {
                return response()->json([
                    'status' => false,
                    'message' => 'No eligible loads found for invoice generation.',
                    'data' => null
                ], 200);
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => "Successfully generated {$invoicesGenerated} invoice(s).",
                'data' => null,
                'url' => route('admin.report.invoice-report'),
            ]);
        } catch (\Throwable $th) {
            DB::rollback();
            return $this->responseJson(false, 500, config('constants.CATCH_ERROR_MSG'), $th->getMessage());
        }
    }
    public function loadReport(Request $request)
    {
        $destinations = Job::groupBy('destination')->pluck('destination');
        $sources = Job::groupBy('source')->pluck('source');
        $job_unique_ids = Job::groupBy('unique_id')->pluck('unique_id');
        $all_trucker = User::where('user_type', '4')->get();
        $all_contractors = User::where('user_type', '3')->get();
        $all_pickup_locations = Job::groupBy('pickup_location_company')->pluck('pickup_location_company');
        $all_dropoff_locations = Job::groupBy('drop_off_location_company')->pluck('drop_off_location_company');


        // Get filter values from request
        $destination = $request->input('search', '');
        $source = $request->input('source', '');
        $truckNo = $request->input('truck_no', '');
        $perPage = $request->input('per_page', 10);
        $from_date = $request->input('from_date', '');
        $to_date = $request->input('to_date', '');
        $dropoff_company = $request->input('dropoff_company', '');
        $pickup_company = $request->input('pickup_company', '');
        $contractor = $request->input('contractor', '');

        $query = Load::with('job')
            ->when($destination, function ($q, $destination) {
                $q->whereHas('job', function ($q) use ($destination) {
                    $q->where('destination', $destination);
                });
            })->when($pickup_company, function ($query, $pickup_company) {
                $query->whereHas('job', function ($q) use ($pickup_company) {
                    $q->where('pickup_location_company', $pickup_company);
                });
            })->when($contractor, function ($query, $contractor) {
                $query->whereHas('job', function ($q) use ($contractor) {
                    $q->where('user_id', $contractor);
                });
            })
            ->when($dropoff_company, function ($query, $dropoff_company) {
                $query->whereHas('job', function ($q) use ($dropoff_company) {
                    $q->where('drop_off_location_company', $dropoff_company);
                });
            })
            ->when($source, function ($q, $source) {
                $q->whereHas('job', function ($q) use ($source) {
                    $q->where('source', $source);
                });
            })
            ->when($from_date, function ($query, $from_date) {
                $query->whereDate('created_at', '>=', $from_date);
            })
            ->when($to_date, function ($query, $to_date) {
                $query->whereDate('created_at', '<=', $to_date);
            })
            ->when($truckNo, function ($q, $truckNo) {
                $q->whereHas('userTruckDetails', function ($q) use ($truckNo) {
                    $q->where('company_truck_number', $truckNo);
                });
            })->where(function ($q) use ($request) {
                if ($request->is_completed == '1') {
                    $q->where('status', 4);
                } else {
                    $q->where('status', '!=', 4);
                }
            })->orderBy('id', 'desc');

        if ($perPage == 'all') {
            $loads = $query->get();
        } else {
            $loads = $query->paginate($perPage);
        }

        $all_load_ids = $loads->pluck('id')->toArray();

        // Fetch JobConfigureMap details for all loads
        $currentDateTime = Carbon::now()->format('Ymd_His');
        $baseDir = public_path("storage/load_images");

        // Ensure the base directory exists
        if (!is_dir($baseDir)) {
            mkdir($baseDir, 0777, true);
        }

        $baseDir1 = public_path("storage/loads");

        // Ensure the base directory exists
        if (!is_dir($baseDir1)) {
            mkdir($baseDir1, 0777, true);
        }

        // Eager load 'job' relationship to avoid null errors
        $details = JobConfigureMap::with('job')->whereIn('load_id', $all_load_ids)->get();
        $allCopiedFiles = [];
        foreach ($details as $load) {
            // Check if job relationship exists
            $jobId = isset($load->job) && isset($load->job->unique_id) ? $load->job->unique_id : 'unknown';
            $loadId = $load->load_id;
            $folderName = "{$jobId}-{$loadId}";
            $folderPath = $baseDir . "/{$folderName}";

            // Ensure the folder path exists, creating parent directories as needed
            if (!is_dir($folderPath)) {
                if (!mkdir($folderPath, 0777, true) && !is_dir($folderPath)) {
                    // Directory creation failed
                    continue;
                }
            }

            $images = [];
            if (!empty($load->signature)) {
                $signaturePath = public_path('storage/signature/' . $load->signature);
                if (file_exists($signaturePath)) {
                    $images[] = $signaturePath;
                }
            }
            if (!empty($load->challan)) {
                $challanPath = public_path('storage/challan/' . $load->challan);
                if (file_exists($challanPath)) {
                    $images[] = $challanPath;
                }
            }
            if (!empty($load->challan_on_delivery)) {
                $challanDeliveryPath = public_path('storage/challan/' . $load->challan_on_delivery);
                if (file_exists($challanDeliveryPath)) {
                    $images[] = $challanDeliveryPath;
                }
            }

            foreach ($images as $sourcePath) {
                $destinationPath = $folderPath . '/' . basename($sourcePath);
                if (!file_exists($destinationPath)) {
                    if (!@copy($sourcePath, $destinationPath)) {
                        // Copy failed, skip this file
                        continue;
                    }
                }
                $allCopiedFiles[] = $destinationPath;
            }
        }

        // Create a new ZipArchive instance
        $zip = new \ZipArchive();
        $zipFileName = time() . '.zip';
        $zipFilePath = storage_path('app/public/loads/' . $zipFileName);

        // Ensure the directory for the zip file exists
        $zipDir = dirname($zipFilePath);
        if (!is_dir($zipDir)) {
            mkdir($zipDir, 0777, true);
        }

        if ($zip->open($zipFilePath, \ZipArchive::CREATE) === TRUE) {
            foreach ($allCopiedFiles as $file) {
                if (file_exists($file)) {
                    // Add file to zip, keep folder structure under load_images
                    $relativePath = str_replace(public_path('storage/'), '', $file);
                    $zip->addFile($file, $relativePath);
                }
            }
            $zip->close();
        } else {
            throw new \Exception("Could not create zip file at: " . $zipFilePath);
        }

        // Delete the load_images folder after zipping
        // $this->deleteDirectory($baseDir);


        return view('admin.report.all-load-report', compact('zipFileName', 'loads', 'destinations', 'sources', 'truckNo', 'perPage', 'zipFileName', 'all_dropoff_locations', 'all_pickup_locations', 'all_contractors'));
    }
    // Helper function to delete a directory recursively
    protected function deleteDirectory($dir)
    {
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        return rmdir($dir);
    }
    private function getContractorPaymentTerms($contractorId)
    {
        $contractor = PaymentTerms::where('user_id', $contractorId)->first();
        return $contractor ? $contractor?->pay_in : 0;
    }
}
