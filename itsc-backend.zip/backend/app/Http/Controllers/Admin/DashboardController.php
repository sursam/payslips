<?php

namespace App\Http\Controllers\Admin;

use App\Models\Job;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\BaseController;

class DashboardController extends BaseController
{
    public function dashboard()
    {
        Log::channel('daily_with_date')->info('This is a log message.');
        $data['total_user'] = User::count();

        $today = date('Y-m-d');

        $after_30_days = date('Y-m-d', strtotime($today . ' - 30 days'));
        $data['total_user_in_30_days'] = User::whereDate('created_at','>=',$after_30_days)->whereDate('created_at','<=',$today)->count();

        $after_7_days = date('Y-m-d', strtotime($today . ' - 7 days'));
        $data['total_user_in_7_days'] = User::whereDate('created_at','>=',$after_7_days)->whereDate('created_at','<=',$today)->count();

        $data['trucker'] = User::where('user_type',3)->count();
        $data['contractor'] = User::where('user_type',4)->count();
        $data['new_job'] = Job::where('status',1)->count();
        $data['completed_job'] = Job::where('status',3)->count();
        $data['canceled_job'] = Job::where('status',4)->count();
        $data['total_job_cost'] = Job::where('is_draft',0)->whereDate('created_at',$today)->sum('job_estimate_price');
        $data['total_job_cost_one_week'] = Job::where('is_draft',0)->whereDate('created_at','>=',$after_7_days)->whereDate('created_at','<=',$today)->sum('job_estimate_price');

        $data['total_job_cost_one_month'] = Job::where('is_draft',0)->whereDate('created_at','>=',$after_30_days)->whereDate('created_at','<=',$today)->sum('job_estimate_price');

        $after_365_days = date('Y-m-d', strtotime($today . ' - 365 days'));

        $data['total_job_cost_one_year'] = Job::where('is_draft',0)->whereDate('created_at','>=',$after_365_days)->whereDate('created_at','<=',$today)->sum('job_estimate_price');


        return view('admin.dashboard.superadmin-dashboard',compact('data'));
    }




}
