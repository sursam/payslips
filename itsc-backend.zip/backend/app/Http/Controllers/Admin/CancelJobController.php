<?php

namespace App\Http\Controllers\Admin;

use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Models\CancelJobSetup;
use App\Scopes\ActiveScope;


class CancelJobController extends BaseController
{
    public function update(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            DB::beginTransaction();
            try {

                $postData = [

                    "whole_job_cancel_fees" => $request->whole_job_cancel_fees,
                    "whole_job_cancel_fees_type" => $request->whole_job_cancel_fees_type,

                    "load_cancel_fees" => $request->load_cancel_fees,
                    "load_cancel_fees_type" => $request->load_cancel_fees_type,


                ];
                $details = CancelJobSetup::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => 'Update Successfully', 'data' => $details ?? null, 'url' => route('admin.cancel-job.update')];
            return response($data);
        }
        $details = array();
        $details = CancelJobSetup::first();

        return view('admin.cancel_job.update',compact('details'));
    }
}
