<?php

namespace App\Http\Controllers\Admin;

use App\Models\Job;
use App\Models\Load;
use App\Models\User;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class JobController extends BaseController
{

    public function all_job(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        $filters = [];

        $uniqueId = $request->input('unique_id');
        if (!empty($uniqueId)) {
            $filters[] = function ($query) use ($uniqueId) {
                $query->where('unique_id', "$uniqueId");
            };
        }

        $orderNo = $request->input('order_no');
        if (!empty($orderNo)) {
            $filters[] = function ($query) use ($orderNo) {
                $query->where('order_no', "$orderNo");
            };
        }

        $source = $request->input('source', '');
        if (!empty($source)) {
            $filters[] = function ($query) use ($source) {
                $query->where('source', 'like', "%{$source}%");
            };
        }

        $destination = $request->input('destination', ''); // Fixed misspelled variable name
        if (!empty($destination)) {
            $filters[] = function ($query) use ($destination) {
                $query->where('destination', 'like', "%{$destination}%");
            };
        }

        $pickupDate = $request->input('pickup_date', '');
        $deliveryDate = $request->input('delivery_date', '');
        if (!empty($pickupDate)) {
            $filters[] = function ($query) use ($pickupDate) {
                $query->whereDate('pickup_date_time', $pickupDate); // Changed "like" to "=" for dates
            };
        }
        if (!empty($deliveryDate)) {
            $filters[] = function ($query) use ($deliveryDate) {
                $query->whereDate('delivery_date_time', $deliveryDate); // Changed "like" to "=" for dates
            };
        }

        $status = $request->input('status');
        if (!empty($status)) {
            $filters[] = function ($query) use ($status) {
                $query->where('status', "$status");
            };
        }
        $query = Job::where(function ($query) use ($filters) {
            foreach ($filters as $filter) {
                $query->where($filter);
            }
        });
        if ($perPage == 'all') {
            $job_list = $query->latest()->get();
        } else {
            $job_list = $query->latest()->paginate($perPage);
        }
        return view('admin.job.all_job', compact('job_list', 'uniqueId', 'orderNo', 'source', 'destination', 'pickupDate', 'deliveryDate', 'status'));
    }

    public function new_job(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $filters = [];

        $uniqueId = $request->input('unique_id', '');
        if (!empty($uniqueId)) {
            $filters[] = function ($query) use ($uniqueId) {
                $query->where('unique_id', 'like', "%{$uniqueId}%");
            };
        }

        $orderNo = $request->input('order_no', '');
        if (!empty($orderNo)) {
            $filters[] = function ($query) use ($orderNo) {
                $query->where('order_no', 'like', "%{$orderNo}%");
            };
        }

        $source = $request->input('source', '');
        if (!empty($source)) {
            $filters[] = function ($query) use ($source) {
                $query->where('source', 'like', "%{$source}%");
            };
        }

        $destination = $request->input('destination', ''); // Fixed misspelled variable name
        if (!empty($destination)) {
            $filters[] = function ($query) use ($destination) {
                $query->where('destination', 'like', "%{$destination}%");
            };
        }

        $pickupDate = $request->input('pickup_date', '');
        $deliveryDate = $request->input('delivery_date', '');
        if (!empty($pickupDate)) {
            $filters[] = function ($query) use ($pickupDate) {
                $query->whereDate('pickup_date_time', $pickupDate); // Changed "like" to "=" for dates
            };
        }
        if (!empty($deliveryDate)) {
            $filters[] = function ($query) use ($deliveryDate) {
                $query->whereDate('delivery_date_time', $deliveryDate); // Changed "like" to "=" for dates
            };
        }

        $query = Job::where('status', 1)->where(function ($query) use ($filters) {
            foreach ($filters as $filter) {
                $query->where($filter);
            }
        });

        if ($perPage == 'all') {
            $job_list = $query->latest()->get();
        } else {
            $job_list = $query->latest()->paginate($perPage);
        }

        return view('admin.job.new_jobs', compact('job_list', 'uniqueId', 'orderNo', 'source', 'destination', 'pickupDate', 'deliveryDate'));
    }

    public function running_job(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $filters = [];

        $uniqueId = $request->input('unique_id', '');
        if (!empty($uniqueId)) {
            $filters[] = function ($query) use ($uniqueId) {
                $query->where('unique_id', 'like', "%{$uniqueId}%");
            };
        }

        $orderNo = $request->input('order_no', '');
        if (!empty($orderNo)) {
            $filters[] = function ($query) use ($orderNo) {
                $query->where('order_no', 'like', "%{$orderNo}%");
            };
        }

        $source = $request->input('source', '');
        if (!empty($source)) {
            $filters[] = function ($query) use ($source) {
                $query->where('source', 'like', "%{$source}%");
            };
        }

        $destination = $request->input('destination', ''); // Fixed misspelled variable name
        if (!empty($destination)) {
            $filters[] = function ($query) use ($destination) {
                $query->where('destination', 'like', "%{$destination}%");
            };
        }

        $pickupDate = $request->input('pickup_date', '');
        $deliveryDate = $request->input('delivery_date', '');
        if (!empty($pickupDate)) {
            $filters[] = function ($query) use ($pickupDate) {
                $query->whereDate('pickup_date_time', $pickupDate); // Changed "like" to "=" for dates
            };
        }
        if (!empty($deliveryDate)) {
            $filters[] = function ($query) use ($deliveryDate) {
                $query->whereDate('delivery_date_time', $deliveryDate); // Changed "like" to "=" for dates
            };
        }

        // Fetch the independent list with the specified pagination and search filter
        // $job_list = Job::where('status', 3)
        //     ->whereHas('runningJobLoad',function($q) use ($request){
        //         $q->where('status', 2);
        //     }) // Corrected here
        //     ->when($search, function ($query) use ($search) {
        //         $query->where('unique_id', 'like', "%{$search}%")
        //             ->orWhere('order_no', 'like', "%{$search}%");
        //     })
        //     ->latest()
        //     ->paginate($perPage);
        $query = Job::where('status', 3)->whereHas('runningJobLoad', function ($q) use ($request) {
            $q->where('status', 2);
        })->where(function ($query) use ($filters) {
            foreach ($filters as $filter) {
                $query->where($filter);
            }
        });
        if ($perPage == 'all') {
            $job_list = $query->latest()->get();
        } else {
            $job_list = $query->latest()->paginate($perPage);
        }


        return view('admin.job.running_jobs', compact('job_list', 'uniqueId', 'orderNo', 'source', 'destination', 'pickupDate', 'deliveryDate'));
    }

    public function completed_job(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $filters = [];

        $uniqueId = $request->input('unique_id', '');
        if (!empty($uniqueId)) {
            $filters[] = function ($query) use ($uniqueId) {
                $query->where('unique_id', 'like', "%{$uniqueId}%");
            };
        }

        $orderNo = $request->input('order_no', '');
        if (!empty($orderNo)) {
            $filters[] = function ($query) use ($orderNo) {
                $query->where('order_no', 'like', "%{$orderNo}%");
            };
        }

        $source = $request->input('source', '');
        if (!empty($source)) {
            $filters[] = function ($query) use ($source) {
                $query->where('source', 'like', "%{$source}%");
            };
        }

        $destination = $request->input('destination', ''); // Fixed misspelled variable name
        if (!empty($destination)) {
            $filters[] = function ($query) use ($destination) {
                $query->where('destination', 'like', "%{$destination}%");
            };
        }

        $pickupDate = $request->input('pickup_date', '');
        $deliveryDate = $request->input('delivery_date', '');
        if (!empty($pickupDate)) {
            $filters[] = function ($query) use ($pickupDate) {
                $query->whereDate('pickup_date_time', $pickupDate); // Changed "like" to "=" for dates
            };
        }
        if (!empty($deliveryDate)) {
            $filters[] = function ($query) use ($deliveryDate) {
                $query->whereDate('delivery_date_time', $deliveryDate); // Changed "like" to "=" for dates
            };
        }

        // Fetch the independent list with the specified pagination and search filter
        // $job_list = Job::where('status', 3)->when($search, function ($query) use ($search) {
        //     $query->where('unique_id', 'like', "%{$search}%")
        //         ->orWhere('order_no', 'like', "%{$search}%");
        // })->latest()
        //     ->paginate($perPage);
        $query = Job::where('status', 3)->where(function ($query) use ($filters) {
            foreach ($filters as $filter) {
                $query->where($filter);
            }
        });
        if ($perPage == 'all') {
            $job_list = $query->latest()->get();
        } else {
            $job_list = $query->latest()->paginate($perPage);
        }


        return view('admin.job.complete_jobs', compact('job_list', 'uniqueId', 'orderNo', 'source', 'destination', 'pickupDate', 'deliveryDate'));
    }

    public function cancel_job(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $filters = [];

        $uniqueId = $request->input('unique_id', '');
        if (!empty($uniqueId)) {
            $filters[] = function ($query) use ($uniqueId) {
                $query->where('unique_id', 'like', "%{$uniqueId}%");
            };
        }

        $orderNo = $request->input('order_no', '');
        if (!empty($orderNo)) {
            $filters[] = function ($query) use ($orderNo) {
                $query->where('order_no', 'like', "%{$orderNo}%");
            };
        }

        $source = $request->input('source', '');
        if (!empty($source)) {
            $filters[] = function ($query) use ($source) {
                $query->where('source', 'like', "%{$source}%");
            };
        }

        $destination = $request->input('destination', ''); // Fixed misspelled variable name
        if (!empty($destination)) {
            $filters[] = function ($query) use ($destination) {
                $query->where('destination', 'like', "%{$destination}%");
            };
        }

        $pickupDate = $request->input('pickup_date', '');
        $deliveryDate = $request->input('delivery_date', '');
        if (!empty($pickupDate)) {
            $filters[] = function ($query) use ($pickupDate) {
                $query->whereDate('pickup_date_time', $pickupDate); // Changed "like" to "=" for dates
            };
        }
        if (!empty($deliveryDate)) {
            $filters[] = function ($query) use ($deliveryDate) {
                $query->whereDate('delivery_date_time', $deliveryDate); // Changed "like" to "=" for dates
            };
        }

        // Fetch the independent list with the specified pagination and search filter
        // $job_list = Job::where('status', 4)->when($search, function ($query) use ($search) {
        //     $query->where('unique_id', 'like', "%{$search}%")
        //         ->orWhere('order_no', 'like', "%{$search}%");
        // })->latest()
        //     ->paginate($perPage);
        $query = Job::where('status', 4)->where(function ($query) use ($filters) {
            foreach ($filters as $filter) {
                $query->where($filter);
            }
        });
        if ($perPage == 'all') {
            $job_list = $query->latest()->get();
        } else {
            $job_list = $query->latest()->paginate($perPage);
        }
        return view('admin.job.cancel_jobs', compact('job_list', 'uniqueId', 'orderNo', 'source', 'destination', 'pickupDate', 'deliveryDate'));
    }


    public function all_job_detail(Request $request, $id = null)
    {

        $job = Job::with('jobLoad')->where('id', $id)->first();

        $load_details = Load::where(function ($q) use ($request) {
            if (!is_null($request->start_date)) {
                $q->where('started_on', 'like', '%' . $request->start_date . '%');
            }
            if (!is_null($request->end_date)) {
                $q->where('completed_on', 'like', '%' . $request->end_date . '%');
            }
            if (!is_null($request->driver_id)) {
                $q->where('user_id', $request->driver_id);
            }
        })->when(!is_null($request->company_truck_no) || !is_null($request->truck_lic_no), function ($q) use ($request) {
            $q->whereHas('userTruckDetails', function ($q) use ($request) {
                if (!is_null($request->company_truck_no)) {
                    $q->where('company_truck_number', 'like', '%' . $request->company_truck_no . '%');
                }
                if (!is_null($request->truck_lic_no)) {
                    $q->where('truck_license_no', 'like', '%' . $request->truck_lic_no . '%');
                }
            });
        })->where('job_id', $id)->get();

        $drivers = User::where('user_type', '4')->get();
        return view('admin.job.all_job_details', compact('job', 'drivers', 'load_details'));
    }

    public function new_job_detail(Request $request, $id = null)
    {

        $job = Job::with('jobLoad')->where('id', $id)->first();

        $load_details = Load::where(function ($q) use ($request) {
            if (!is_null($request->start_date)) {
                $q->where('started_on', 'like', '%' . $request->start_date . '%');
            }
            if (!is_null($request->end_date)) {
                $q->where('completed_on', 'like', '%' . $request->end_date . '%');
            }
            if (!is_null($request->driver_id)) {
                $q->where('user_id', $request->driver_id);
            }
        })->when(!is_null($request->company_truck_no) || !is_null($request->truck_lic_no), function ($q) use ($request) {
            $q->whereHas('userTruckDetails', function ($q) use ($request) {
                if (!is_null($request->company_truck_no)) {
                    $q->where('company_truck_number', 'like', '%' . $request->company_truck_no . '%');
                }
                if (!is_null($request->truck_lic_no)) {
                    $q->where('truck_license_no', 'like', '%' . $request->truck_lic_no . '%');
                }
            });
        })->where('job_id', $id)->get();

        $drivers = User::where('user_type', '4')->get();
        return view('admin.job.new_job_details', compact('job', 'drivers', 'load_details'));
    }

    public function running_job_detail(Request $request, $id = null)
    {

        $job = Job::with('jobLoad')->where('id', $id)->first();

        $load_details = Load::where(function ($q) use ($request) {
            if (!is_null($request->start_date)) {
                $q->where('started_on', 'like', '%' . $request->start_date . '%');
            }
            if (!is_null($request->end_date)) {
                $q->where('completed_on', 'like', '%' . $request->end_date . '%');
            }
            if (!is_null($request->driver_id)) {
                $q->where('user_id', $request->driver_id);
            }
        })->when(!is_null($request->company_truck_no) || !is_null($request->truck_lic_no), function ($q) use ($request) {
            $q->whereHas('userTruckDetails', function ($q) use ($request) {
                if (!is_null($request->company_truck_no)) {
                    $q->where('company_truck_number', 'like', '%' . $request->company_truck_no . '%');
                }
                if (!is_null($request->truck_lic_no)) {
                    $q->where('truck_license_no', 'like', '%' . $request->truck_lic_no . '%');
                }
            });
        })->where('job_id', $id)->get();

        $drivers = User::where('user_type', '4')->get();
        return view('admin.job.running_job_details', compact('job', 'drivers', 'load_details'));
    }


    public function complete_job_detail(Request $request, $id = null)
    {

        $job = Job::with('jobLoad')->where('id', $id)->first();

        $load_details = Load::where(function ($q) use ($request) {
            if (!is_null($request->start_date)) {
                $q->where('started_on', 'like', '%' . $request->start_date . '%');
            }
            if (!is_null($request->end_date)) {
                $q->where('completed_on', 'like', '%' . $request->end_date . '%');
            }
            if (!is_null($request->driver_id)) {
                $q->where('user_id', $request->driver_id);
            }
        })->when(!is_null($request->company_truck_no) || !is_null($request->truck_lic_no), function ($q) use ($request) {
            $q->whereHas('userTruckDetails', function ($q) use ($request) {
                if (!is_null($request->company_truck_no)) {
                    $q->where('company_truck_number', 'like', '%' . $request->company_truck_no . '%');
                }
                if (!is_null($request->truck_lic_no)) {
                    $q->where('truck_license_no', 'like', '%' . $request->truck_lic_no . '%');
                }
            });
        })->where('job_id', $id)->get();

        $drivers = User::where('user_type', '4')->get();
        return view('admin.job.completed_job_details', compact('job', 'drivers', 'load_details'));
    }

    public function cancel_job_detail(Request $request, $id = null)
    {

        $job = Job::with('jobLoad')->where('id', $id)->first();

        $load_details = Load::where(function ($q) use ($request) {
            if (!is_null($request->start_date)) {
                $q->where('started_on', 'like', '%' . $request->start_date . '%');
            }
            if (!is_null($request->end_date)) {
                $q->where('completed_on', 'like', '%' . $request->end_date . '%');
            }
            if (!is_null($request->driver_id)) {
                $q->where('user_id', $request->driver_id);
            }
        })->when(!is_null($request->company_truck_no) || !is_null($request->truck_lic_no), function ($q) use ($request) {
            $q->whereHas('userTruckDetails', function ($q) use ($request) {
                if (!is_null($request->company_truck_no)) {
                    $q->where('company_truck_number', 'like', '%' . $request->company_truck_no . '%');
                }
                if (!is_null($request->truck_lic_no)) {
                    $q->where('truck_license_no', 'like', '%' . $request->truck_lic_no . '%');
                }
            });
        })->where('job_id', $id)->get();

        $drivers = User::where('user_type', '4')->get();
        return view('admin.job.cancel_job_details', compact('job', 'drivers', 'load_details'));
    }


    // public function all_job_load_detail($id)
    // {
    //     $load_details = Load::find($id);
    //     return view('admin.job.all_job_load_details', compact('load_details'));
    // }
    public function all_job_load_detail($id)
    {
        $load_details = Load::find($id);

        if (!$load_details) {
            return redirect()->back()->withErrors('Load not found.');
        }

        $jobId = $load_details->job_id;

        // Fetch all loads related to the job
        $allLoadsOfJob = Load::where('job_id', $jobId)
            ->orderBy('created_at')
            ->pluck('id')
            ->toArray();

        // Create index map
        $loadIndexMap = array_flip($allLoadsOfJob);
        array_walk($loadIndexMap, function (&$value) {
            $value = $value + 1; // Start index from 1
        });

        // Set load index for the current load
        $load_details->load_index = $loadIndexMap[$load_details->id] ?? null;

        return view('admin.job.all_job_load_details', compact('load_details'));
    }


    // public function new_job_load_detail($id)
    // {
    //     $load_details = Load::find($id);
    //     return view('admin.job.new_job_load_details', compact('load_details'));
    // }

    // public function running_job_load_details($id)
    // {
    //     $load_details = Load::find($id);
    //     return view('admin.job.running_job_load_details', compact('load_details'));
    // }

    // public function completed_job_load_details($id)
    // {
    //     $load_details = Load::find($id);
    //     return view('admin.job.completed_job_load_details', compact('load_details'));
    // }
    // public function cancel_job_load_details($id)
    // {
    //     $load_details = Load::find($id);
    //     return view('admin.job.cancel_job_load_details', compact('load_details'));
    // }
    public function new_job_load_detail($id)
    {
        $load_details = Load::find($id);

        if (!$load_details) {
            return redirect()->back()->withErrors('Load not found.');
        }

        $load_details->load_index = $this->calculateLoadIndex($load_details->job_id, $load_details->id);

        return view('admin.job.new_job_load_details', compact('load_details'));
    }

    public function running_job_load_details($id)
    {
        $load_details = Load::find($id);

        if (!$load_details) {
            return redirect()->back()->withErrors('Load not found.');
        }

        $load_details->load_index = $this->calculateLoadIndex($load_details->job_id, $load_details->id);

        return view('admin.job.running_job_load_details', compact('load_details'));
    }

    public function completed_job_load_details($id)
    {
        $load_details = Load::find($id);

        if (!$load_details) {
            return redirect()->back()->withErrors('Load not found.');
        }

        $load_details->load_index = $this->calculateLoadIndex($load_details->job_id, $load_details->id);

        return view('admin.job.completed_job_load_details', compact('load_details'));
    }

    public function cancel_job_load_details($id)
    {
        $load_details = Load::find($id);

        if (!$load_details) {
            return redirect()->back()->withErrors('Load not found.');
        }

        $load_details->load_index = $this->calculateLoadIndex($load_details->job_id, $load_details->id);

        return view('admin.job.cancel_job_load_details', compact('load_details'));
    }


    public function all_loads(Request $request)
    {

        $destinations = Job::groupBy('destination')->pluck('destination');
        $sources = Job::groupBy('source')->pluck('source');
        $all_pickup_locations = Job::groupBy('pickup_location_company')->pluck('pickup_location_company');
        $all_dropoff_locations = Job::groupBy('drop_off_location_company')->pluck('drop_off_location_company');
        $job_unique_ids = Job::groupBy('unique_id')->pluck('unique_id');
        $all_trucker = User::where('user_type', '4')->get();
        $all_contractors = User::where('user_type', '3')->get();

        // Get filter values from request
        $destination = $request->input('search', '');
        $ticket_no = $request->input('ticket_no', '');
        $contractor = $request->input('contractor', '');
        $source = $request->input('source', '');
        $trucker = $request->input('trucker', '');
        $job_unique_id = $request->input('job_unique_id', '');
        $from_date = $request->input('from_date', '');
        $to_date = $request->input('to_date', '');
        $completed_from_date = $request->input('completed_from_date', '');
        $completed_to_date = $request->input('completed_to_date', '');
        $perPage = $request->input('per_page', 10);
        $dropoff_company = $request->input('dropoff_company', '');
        $pickup_company = $request->input('pickup_company', '');

        $query = Load::when($destination, function ($query, $destination) {
            $query->whereHas('job', function ($q) use ($destination) {
                $q->where('destination', $destination);
            });
        })
            ->when($source, function ($query, $source) {
                $query->whereHas('job', function ($q) use ($source) {
                    $q->where('source', $source);
                });
            })->when($request->pickup_company, function ($query, $pickup_company) {
                $query->whereHas('job', function ($q) use ($pickup_company) {
                    $q->where('pickup_location_company', $pickup_company);
                });
            })
            ->when($request->dropoff_company, function ($query, $dropoff_company) {
                $query->whereHas('job', function ($q) use ($dropoff_company) {
                    $q->where('drop_off_location_company', $dropoff_company);
                });
            })
            ->when($contractor, function ($query, $contractor) {
                $query->whereHas('job', function ($q) use ($contractor) {
                    $q->where('user_id', $contractor);
                });
            })
            ->when($job_unique_id, function ($query, $job_unique_id) {
                $query->whereHas('job', function ($q) use ($job_unique_id) {
                    $q->where('unique_id', $job_unique_id);
                });
            })
            ->when($trucker, function ($query, $trucker) {
                $query->where('user_id', $trucker);
            })
            ->when($ticket_no, function ($query, $ticket_no) {
                $query->where('ticket_no', 'like', "%{$ticket_no}%");
            })
            ->when($from_date, function ($query, $from_date) {
                $query->whereDate('started_on', '>=', $from_date);
            })
            ->when($to_date, function ($query, $to_date) {
                $query->whereDate('started_on', '<=', $to_date);
            })
            ->when($completed_from_date, function ($query, $completed_from_date) {
                $query->whereDate('completed_on', '>=', $completed_from_date);
            })
            ->when($completed_to_date, function ($query, $completed_to_date) {
                $query->whereDate('completed_on', '<=', $completed_to_date);
            })
            ->where(function ($q) use ($request) {
                if ($request->is_completed == '1') {
                    $q->where('status', 4);
                } else {
                    $q->where('status', '!=', 4);
                }
            })->orderBy('id', 'desc');

            if ($perPage == 'all') {
                $all_loads = $query->latest()->get();
            } else {
                $all_loads = $query->latest()->paginate($perPage);
            }

        return view('admin.job.all_loads', compact('all_loads', 'destinations', 'sources', 'job_unique_ids', 'all_trucker', 'all_contractors', 'all_dropoff_locations', 'all_pickup_locations'));
    }

    public function load_print($id)
    {
        $detail = Load::find($id);
        return view('admin.job.load_print', compact('detail'));
    }
    private function calculateLoadIndex($jobId, $loadId)
    {
        $allLoadsOfJob = Load::where('job_id', $jobId)
            ->orderBy('created_at')
            ->pluck('id')
            ->toArray();

        $loadIndexMap = array_flip($allLoadsOfJob);
        array_walk($loadIndexMap, function (&$value) {
            $value = $value + 1; // Start index from 1 instead of 0
        });

        return $loadIndexMap[$loadId] ?? null;
    }

}
