<?php

namespace App\Http\Controllers\Admin;

use App\Models\HelpQuestion;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Models\Role;

class HelpQuestionController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = HelpQuestion::latest()->get();
        return view('admin.help_question.index', compact('details'));
    }
    public function add(Request $request)
    {
        $details = collect();
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'role' => 'required',
                    'description' => 'nullable',
                ]);
                $message = "Help Question Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'role' => 'required',
                    'description' => 'nullable',
                ]);
                $message = "Help Question Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "role_id" => $request->role,
                    "description" => $request->description
                ];

                $details = HelpQuestion::updateOrCreate(['id' => $id], $postData);



                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.help-question.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'help_questions');
            $details = HelpQuestion::find($uuid);
        }

        $role = Role::get();

        return view('admin.help_question.add', compact('details','role'));
    }
}
