<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\SosLog;

class SosLogController extends BaseController
{
    public function index(Request $request)
    {
        $sos_details = SosLog::with('userDetails','loadDetails','jobDetails')->get();
        return view('admin.sos_log.index',compact('sos_details'));
    }
}
