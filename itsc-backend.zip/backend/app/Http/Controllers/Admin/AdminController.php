<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\BaseController;
use App\Models\ContactData;
use App\Models\Destination;
use App\Scopes\ActiveScope;
use Illuminate\Support\Facades\Log;

class AdminController extends BaseController
{
    use UploadAble;
    public function dashboard()
    {
        Log::channel('daily_with_date')->info('This is a log message.');
        $details = array();
        $usercount = User::where('user_type','3')->withoutGlobalScope(ActiveScope::class)->count();
        $agent = User::where('user_type','4')->withoutGlobalScope(ActiveScope::class)->count();
        $destination = Destination::withoutGlobalScope(ActiveScope::class)->count();
        return view('admin.dashboard', compact('details','usercount','agent','destination'));
    }

    public function profileUpdate(Request $request)
    {
        $request->validate([
            'admin_first_name' => 'required|string',
            'admin_last_name' => 'required|string',
            'admin_email' => 'required|email',
            'admin_mobile_number' => 'required|digits:10|numeric',
        ]);
        if ($request->post()) {
            // dd($request->all());
            $postData = [
                "first_name" => $request->admin_first_name,
                "last_name" => $request->admin_last_name,
                "mobile_number" => $request->admin_mobile_number,
                "email" => $request->admin_email,
            ];
            if (!empty($request->admin_profile_image)) {
                $image = $request->admin_profile_image;
                $type = $image->getClientOriginalExtension();
                $fileName = uniqid() . '.' . $type;
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $postData['profile_image'] = $fileName;
                }
            }
            $data = User::updateOrCreate(['id' => Auth::user()->id], $postData);
        }
        $message = "Updated Successfully";
        $data = ['status' => true, 'message' => $message, 'data' => $postData];
        return response($data);
    }

    public function passwordUpdate(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'old_password' => 'required|min:8',
                'new_password' => 'required|min:8',
                'confirm_password' => 'required|min:8|same:new_password',
            ]);
            $old_pass = Auth::user()->password;
            if (empty($request->old_password)) {
                $hash_old_pass = '';
            } else {
                $hash_old_pass = $request->old_password;
            }
            $check = Hash::check($hash_old_pass, $old_pass);

            if (empty($request->old_password)) {
                $message = "Provide Old Password";
                $data = ['status' => false, 'message' => $message, 'data' => ''];
            } else if ($check !== true) {
                $message = "Provided Old Password is Wrong";
                $data = ['status' => false, 'message' => $message, 'data' => ''];
            } else if (empty($request->new_password)) {
                $message = "Provide New Password";
                $data = ['status' => false, 'message' => $message, 'data' => ''];
            } else if (empty($request->confirm_password)) {
                $message = "Provide Confirm Password";
                $data = ['status' => false, 'message' => $message, 'data' => ''];
            } else if ($request->confirm_password !== $request->new_password) {
                $message = "New Password & Confirm Password Have to be Same";
                $data = ['status' => false, 'message' => $message, 'data' => ''];
            } else {
                $postData = [
                    "password" => Hash::make($request->confirm_password),
                ];
                $data = User::updateOrCreate(['id' => Auth::user()->id], $postData);
                $message = " Password Updated Successfully";
                $data = ['status' => true, 'message' => $message, 'data' => $postData];
            }
        }
        return response($data);
    }


    public function contactUsData(Request $request){
        $contact = ContactData::all();
        return view('admin.contact.index', compact('contact'));
    }
}
