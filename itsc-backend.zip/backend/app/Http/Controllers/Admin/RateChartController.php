<?php

namespace App\Http\Controllers\Admin;

use App\Models\City;
use App\Models\State;
use App\Models\TruckType;
use App\Models\JobComission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\BaseController;

class RateChartController extends BaseController
{
    public function index(Request $request)
    {
        $details = JobComission::latest()->get();
        // dd($details);
        return view('admin.rate_chart.index', compact('details'));
    }

    public function add(Request $request)
    {
        if ($request->post()) {

            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'state_id' => 'nullable',
                    'city_id' => 'required_with:state_id',
                    'owner_percentage' => 'required',
                    'cal_percentage' => 'required'
                ],[
                    'city_id.required_with' => 'City is required if state is selected',
                    'owner_percentage.required' => 'Trucker Percentage is required',
                    'cal_percentage.required' => 'Cal Percentage is required',
                ]);
                $message = "Job Commission Updated Successfully";
            } else {
                $request->validate([
                    'state_id' => 'nullable',
                    'city_id' => 'required_with:state_id',
                    'owner_percentage' => 'required',
                    'cal_percentage' => 'required'
                ],[
                    'city_id.required_with' => 'City is required if state is selected',
                    'owner_percentage.required' => 'Trucker Percentage is required',
                    'cal_percentage.required' => 'Cal Percentage is required'
                ]);
                $message = "Job Commission Created Successfully";
            }
            // find state and city name 
            $stateDetails = State::find($request->state_id);
            $cityDetails = City::find($request->city_id);
            // find the co ordinates 
            $coordinates = $this->getCityCoordinates($stateDetails->name, $cityDetails->name);
            $filteredTruckTypes = array_filter($request->truck_type, function ($value) {
                return !is_null($value) && $value !== '';
            });
            DB::beginTransaction();
            try {

                $postData = [
                    "state_id" => $request->state_id,
                    "city_id" => $request->city_id,
                    'latitude' => $coordinates['latitude'],
                    'longitude' => $coordinates['longitude'],
                    'place_id' => $coordinates['place_id'],
                    "truck_type_ids" => implode(',',$filteredTruckTypes),
                    "trucker_percentage" => $request->owner_percentage,
                    "cal_percentage" => $request->cal_percentage,
                ];
                $details = JobComission::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.rate-chart.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'job_comissions');
            $details = JobComission::find($uuid);
        }

        $states = State::get();
        $truck_types = TruckType::get();

        return view('admin.rate_chart.add', compact('details','states','truck_types'));
    }
    public function getCityCoordinates($state, $city)
    {
        // Get Google API key from config
        $apiKey = env('GOOGLE_API_KEY', 'AIzaSyBYyEVLoI7MeOd2EXKQhePjACpY8pe8wcc');

        try {
            // Make request to Google Geocoding API
            $response = Http::timeout(10)->get('https://maps.googleapis.com/maps/api/geocode/json', [
                'address' => "{$city}, {$state}",
                'key' => $apiKey
            ]);

            if ($response->successful()) {
                $data = $response->json();

                if ($data['status'] === 'OK' && !empty($data['results'])) {
                    $result = $data['results'][0];
                    $location = $result['geometry']['location'];

                    $coordinates = [
                        'city' => $city,
                        'state' => $state,
                        'latitude' => $location['lat'],
                        'longitude' => $location['lng'],
                        'formatted_address' => $result['formatted_address'],
                        'place_id' => $result['place_id'] ?? null,
                        'types' => $result['types'] ?? []
                    ];

                    return $coordinates;
                }

                // Handle API errors
                if ($data['status'] === 'ZERO_RESULTS') {
                    return null; // No results found
                }

                throw new \Exception("Google API Error: " . $data['status']);
            }

            throw new \Exception("HTTP Error: " . $response->status());
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, config('services.responseMessages.error'));
        }
    }
}
