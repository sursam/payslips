<?php

namespace App\Http\Controllers\Admin;

use App\Models\Equipment;
use App\Models\EquipmentOption;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;


class EquipmentController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = Equipment::latest()->get();
        return view('admin.equipment.index', compact('details'));
    }
    public function add(Request $request)
    {
        $details = collect();
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'type' => 'required',
                    'equipment_options' => 'nullable|array',
                ]);
                $message = "Equipment Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'type' => 'required',
                    'equipment_options' => 'nullable|array',
                ]);
                $message = "Equipment Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "type" => $request->type,
                    "loading_spreading" => $request->loading_spreading
                ];

                $details = Equipment::updateOrCreate(['id' => $id], $postData);

                if (!empty($id)) {
                    EquipmentOption::where('equipment_id', $id)->delete();
                }

                if (!empty($request->equipment_options)) {
                    foreach ($request->equipment_options as $key => $value) {
                        $option = EquipmentOption::updateOrCreate([
                            'equipment_id' => $details->id,
                            'title' => $request->equipment_options[$key]
                        ]);
                    }
                }

                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.equipment.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'equipment');
            $details = Equipment::with('EquipmentsOptions')->find($uuid);
        }

        return view('admin.equipment.add', compact('details'));
    }
}
