<?php

namespace App\Http\Controllers\Admin;

use App\Models\CancellationReason;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class CancellationReasonController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = CancellationReason::latest()->get();
        return view('admin.cancellation-reason.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'description' => 'required|string'
                ]);
                $message = "Cancellation Reason Updated Successfully";
            } else {
                $request->validate([
                  'description' => 'required|string'
                ]);
                $message = "Cancellation Reason Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "description" => $request->description,
                ];

                $details = CancellationReason::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.cancellation-reason.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'cancellation_reasons');
            $details = CancellationReason::find($uuid);
        }
        return view('admin.cancellation-reason.add', compact('details'));
    }
}
