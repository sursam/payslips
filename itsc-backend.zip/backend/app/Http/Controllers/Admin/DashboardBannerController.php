<?php

namespace App\Http\Controllers\Admin;

use App\Models\DashboardBanner as Banner;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class DashboardBannerController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = Banner::orderBy('position','asc')->get();
        return view('admin.dashboard-banner.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'url' => 'required|string',
                    'description' => 'required|string'
                ]);
                $message = "Banner Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'url' => 'required|string',
                    'description' => 'required|string',
                    'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
                ]);
                $message = "Banner Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "url" => $request->url,
                    "description" => $request->description,
                ];
                if (empty($id)) {
                    $position = Banner::max('position') + 1;
                    $postData["position"] = $position;
                }
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_DASHBOARD_BANNER_UPLOAD_PATH'), $fileName, 'public');
                    // dd($isFileUploaded);
                    if ($isFileUploaded) {
                        $postData['file'] = $fileName;
                    }
                }
                $details = Banner::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.dashboard-banner.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'dashboard_banners');
            $details = Banner::find($uuid);
        }
        return view('admin.dashboard-banner.add', compact('details'));
    }
    public function order(Request $request)
    {
        if ($request->post()) {
            DB::beginTransaction();
            try {

                foreach($request->order as $key => $value) {
                    Banner::where('id', $value)->update(['position' => $key+1]);
                }
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => '', 'data' => $details ?? null, 'url' => route('admin.dashboard-banner.list')];
            return response($data);
        }
    }
}
