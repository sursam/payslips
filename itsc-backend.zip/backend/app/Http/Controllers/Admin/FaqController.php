<?php

namespace App\Http\Controllers\Admin;

use App\Models\Faq;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class FaqController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = Faq::orderBy('position')->get();
        return view('admin.faq.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'question' => 'required|string'
                ]);
                $message = "FAQ Updated Successfully";
            } else {
                $request->validate([
                    'question' => 'required|string'
                ]);
                $message = "FAQ Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "question" => $request->question,
                    "answer" => $request->answer ?? null,
                    "link" => $request->link ?? null,
                    "video_code" => $request->link ? getVideoCode($request->link) : null,
                ];

                $details = Faq::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.faq.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'faqs');
            $details = Faq::find($uuid);
        }
        return view('admin.faq.add', compact('details'));
    }
    public function order(Request $request)
    {
        if ($request->post()) {
            DB::beginTransaction();
            try {

                foreach($request->order as $key => $value) {
                    Faq::where('id', $value)->update(['position' => $key+1]);
                }
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => '', 'data' => $details ?? null, 'url' => route('admin.banner.list')];
            return response($data);
        }
    }

}
