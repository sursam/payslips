<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\Feedback;

class RatingReviewController extends BaseController
{

    public function index(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $search = $request->input('search', '');

        // Fetch the independent list with the specified pagination and search filter
        $ratings = Feedback::whereHas('jobDetails',function ($query) use ($search) {
            $query->where('unique_id', 'like', "%{$search}%")
                ->orWhere('order_no', 'like', "%{$search}%");
        })->latest()
            ->paginate($perPage);

        return view('admin.rating_review.index',compact('ratings'));
    }
}
