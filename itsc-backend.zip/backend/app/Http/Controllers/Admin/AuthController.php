<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AuthController extends BaseController
{
    public function login(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'email' => 'required|email|exists:users,email',
                'password' => 'required'
            ]);
            $credentials = $request->only(['email', 'password']);
            $user = User::where('email', $credentials['email'])->first();

            if (!auth()->attempt($credentials)) {
                $data = ['status' => false, 'message' => 'Incorrect Details. Please try again', 'data' => null, 'url' => route('admin.login')];
            } else {
                $data = ['status' => true, 'message' => 'Login Successfully', 'data' => null, 'url' => route('admin.dashboard')];
            }
            return response($data);
        }
        return view('auth.login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/admin/login');
    }

    public function forgotPassword(Request $request)
    {
        $request->validate([
            'forgot_email' => 'required|email|exists:users,email',
        ]);

        $user = User::where('email', $request->forgot_email)->first();

        if (!$user) {
            $data = ['status' => true, 'message' => 'User Not Found', 'data' => $user ?? null];
        } else {
            $token = Str::random(60);
            $user->update(['remember_token' => $token]);
            $resetLink = route('admin.reset.password', $token);

            Mail::send('mail.reset-password', ['link' => $resetLink], function ($message) use ($request) {
                $message->to($request->forgot_email);
                $message->subject('Reset Password Link');
            });
            $data = ['status' => true, 'message' => 'Check your email for resetting your password', 'data' => $user ?? null];
        }

        return response($data);
    }

    public function resetPassword(Request $request)
    {
        $token = '';
        $linkExpire = true;
        $user = User::where('remember_token', $request->reset_token)->first();
        if ($request->post()) {
            $request->validate([
                'new_password' => 'required|min:8',
                'password_confirmation' => 'required|min:8|same:new_password',
            ]);
            DB::beginTransaction();
            try {
                $update = $user->update(['remember_token' => null, 'password' => bcrypt($request->new_password)]);
                DB::commit();
                $data = ['status' => true, 'message' => 'Password Reset Successfully. Please Login.', 'data' => $user ?? null, 'url' => ''];
            } catch (\Throwable $th) {
                DB::rollBack();
                $data = ['status' => true, 'message' => 'Something Went Wrong', 'data' => $user ?? null, 'url' => ''];
            }
            return response($data);
        }
        if (!empty($user)) {
            $linkExpire = false;
        }
        $token = $request->token;
        return view('auth.login', compact('token', 'linkExpire'));
    }
    public function delete(Request $request)
    {
        if ($request->post()) {
            $request->validate([
                'email' => 'required|exists:users,email',
            ]);
            $user = User::where(['email' => $request->email, 'is_active' => 1])->first();
            if ($user) {
                $user->update([
                    'is_active' => 0
                ]);
                $data = ['status' => true, 'message' => 'data deleted', 'data' => null, 'url' => route('admin.delete')];
                return response($data);
            } else {
                $data = ['status' => false, 'message' => 'User Not Found', 'data' => null, 'url' => route('admin.delete')];
                return response($data);
            }
        }
        return view('auth.delete');
    }
}
