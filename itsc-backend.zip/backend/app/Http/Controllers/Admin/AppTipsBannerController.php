<?php

namespace App\Http\Controllers\Admin;

use App\Models\AppTipsBanner;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class AppTipsBannerController extends BaseController
{
    use CommonFunction;
    use UploadAble;

    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;

            $request->validate([
                'url' => 'required|string',
                'description' => 'required|string'
            ]);
            $message = "App Tips Banner Updated Successfully";

            DB::beginTransaction();
            try {

                $postData = [
                    "url" => $request->url,
                    "description" => $request->description,
                ];

                $details = AppTipsBanner::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.app-tips-banner.add')];
            return response($data);
        }
        $details = array();
        $details = AppTipsBanner::first();

        return view('admin.app-tips-banners.add', compact('details'));
    }
}
