<?php

namespace App\Http\Controllers\Admin;

use App\Models\Job;
use App\Models\City;
use App\Models\Load;
use App\Models\Role;
use App\Models\User;
use App\Models\State;
use App\Models\Profile;
use App\Models\TruckType;
use App\Models\UserEmail;
use App\Models\UserTruck;
use App\Traits\UploadAble;
use PharIo\Manifest\Email;
use App\Scopes\ActiveScope;
use App\Models\EmailContant;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeMailForAdminUser;
use App\Http\Controllers\BaseController;

class UserController extends BaseController
{
    use CommonFunction;
    use UploadAble;

    public function add(Request $request)
    {
        $user = array();
        if ($request->post()) {
            $id = $request->id ?? NULL;

            if (!empty($id)) {       // data update
                // Update User Validation
                $request->validate([
                    'first_name' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                    'last_name' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                    'email' => [
                        'required',
                        'email',
                        'regex:/^[^<>]*$/',
                        Rule::unique('users')->ignore($id)->where(function ($query) {
                            return $query->whereNull('deleted_at');
                        }),
                    ],
                    'mobile_number' => [
                        'required',
                        'numeric',
                        'digits:10',
                        Rule::unique('users')->ignore($id)->where(function ($query) {
                            return $query->whereNull('deleted_at');
                        }),
                        'not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i',
                    ],
                    'role' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                ]);
                $message = "User Updated Successfully";
            } else {                 // data insert
                // Create User Validation
                $request->validate([
                    'first_name' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                    'last_name' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                    'email' => [
                        'required',
                        'email',
                        'regex:/^[^<>]*$/',

                        Rule::unique('users')->where(function ($query) {
                            return $query->whereNull('deleted_at');
                            //  ->whereNotIn('user_type', [3, 4]);
                        }),
                    ],
                    'mobile_number' => [
                        'required',
                        'numeric',
                        'digits:10',
                        Rule::unique('users')->where(function ($query) {
                            return $query->whereNull('deleted_at');
                            //  ->whereNotIn('user_type', [3, 4]);
                        }),
                        'not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i',
                    ],
                    'role' => 'required|string|not_regex:/<script\b[^>]*>([\s\S]*?)<\/script>/i|max:255',
                    'file' => 'nullable|file|max:5120|mimes:jpg,jpeg,png',
                ]);

                $message = "User Created Successfully";
            }

            // dd('ok');
            // Proceed with further logic, e.g., saving the user and returning a response

            DB::beginTransaction();
            try {
                if ($id != null) {
                    // dd($request->all());
                    $deta = User::where('id', '!=', $id)->where(function ($query) {
                        return $query->whereNull('deleted_at');
                        //  ->whereNotIn('user_type', [3, 4]);
                    })->where('email', $request->email)->where('mobile_number', $request->mobile_number)->first();
                } else {
                    $deta = User::where(function ($query) {
                        return $query->whereNull('deleted_at');
                        //  ->whereNotIn('user_type', [3, 4]);
                    })->where('email', $request->email)->where('mobile_number', $request->mobile_number)->first();
                }

                // dd($deta);

                if ($deta != null) {
                    $data = ['status' => true, 'message' => 'Mobile Number and Email must be unique', 'data' => [], 'url' => route('admin.user.add')];
                    return response($data);
                }



                $password = '12345678';
                $postData = [
                    "first_name" => $request->first_name,
                    "last_name" => $request->last_name,
                    "mobile_number" => $request->mobile_number,
                    "email" => $request->email,
                    'user_type' => $request->role,
                    'is_approve' => 0,
                    'is_verified' => 1,
                    "password" => bcrypt($password),
                ];
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $postData['profile_image'] = $fileName;
                    }
                }

                $user = User::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                $user->roles()->sync($request->role);
                $contant_details = EmailContant::where('slug', 'welcome-mail-for-admin-user')->first();
                if ($contant_details != null) {
                    $details = [
                        'contant' => $contant_details?->description,
                        'name' => $request?->first_name . ' ' . $request?->last_name,
                        'user_name' => $request?->email,
                        'password' => $password,
                        'link' => route('admin.login'),
                        'subject' => $contant_details?->subject
                    ];
                    if (App::environment(['production','testing'])) {
                        Mail::to($request->email)->send(new WelcomeMailForAdminUser($details));
                    }
                }

                DB::commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }

            $data = ['status' => true, 'message' => $message, 'data' => [], 'url' => route('admin.user.admin-user-list')];
            return response($data);
        }

        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'users');
            $details = User::withoutGlobalScope(ActiveScope::class)->find($uuid);
        }
        $roles = Role::whereNotIn('slug', ['super-admin', 'independent', 'contractor'])->latest()->get();
        return view('admin.user.add', compact('details', 'roles'));
    }


    public function user_truck_details_update(Request $request)
    {

        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $message = "User Truck updated Successfully";
            } else {
                $message = "User Truck Created Successfully";
            }

            DB::beginTransaction();
            try {
                $postData = [
                    "company_truck_number" => $request->company_truck_number,
                    "truck_license_no" => $request->truck_license_no,
                    "truck_carrying_capacity" => $request->truck_carrying_capacity,
                ];


                $details = UserTruck::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                $user_details = User::where('id', $details->user_id)->first();

                DB::commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }

            $data = ['status' => true, 'message' => $message, 'data' => [], 'url' => route('admin.user.details', $user_details->uuid)];
            return response($data);
        }
    }

    public function user_truck_details_update_independent(Request $request)
    {

        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $message = "User Truck updated Successfully";
            } else {
                $message = "User Truck Created Successfully";
            }

            DB::beginTransaction();
            try {
                $postData = [
                    "company_truck_number" => $request->company_truck_number,
                    "truck_license_no" => $request->truck_license_no,
                    "truck_carrying_capacity" => $request->truck_carrying_capacity,
                ];


                $details = UserTruck::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                $user_details = User::where('id', $details->user_id)->first();

                DB::commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }

            $data = ['status' => true, 'message' => $message, 'data' => [], 'url' => route('admin.user.independent-details', $user_details->uuid)];
            return response($data);
        }
    }



    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $name = $request->input('name', '');
        $email = $request->input('email', '');
        $phone = $request->input('phone', '');
        // dd($name, $email, $phone);
        $filters = [];
        $query = User::with('stateDetails', 'cityDetails')
            ->withoutGlobalScope(ActiveScope::class);

        if ($name !== '') {
            $nameParts = explode(" ", trim($name));

            if (count($nameParts) >= 3) {
                // First name = first two parts joined
                $firstName = $nameParts[0] . ' ' . $nameParts[1];
                // Last name = last part
                $lastName = $nameParts[count($nameParts) - 1];
            } else {
                // Old logic
                $firstName = $nameParts[0] ?? ''; // First word
                $lastName = isset($nameParts[1]) ? implode(" ", array_slice($nameParts, 1)) : ''; // Remaining words
            }

            $query->where(function ($query) use ($firstName, $lastName) {
                if (!empty($firstName)) {
                    $query->where('first_name', 'like', "%{$firstName}%");
                }
                if (!empty($lastName)) {
                    $query->orWhere('last_name', 'like', "%{$lastName}%");
                }
            });
        }


        if ($email != '') {
            $query->where('email', 'like', "%{$email}%");
        }
        if ($phone != '') {
            $query->where('mobile_number', 'like', "%{$phone}%");
        }
        if ($perPage === 'all') {
            $details = $query->whereIn('user_type', [3, 4])->latest()->get();
        } else {
            $details = $query->whereIn('user_type', [3, 4])->latest()->paginate($perPage);
        }
        return view('admin.user.index', compact('details', 'name', 'email', 'phone'));
    }

    public function admin_user_list(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);

        // Get the search term from the request
        $name = $request->input('name', '');
        $email = $request->input('email', '');
        $phone = $request->input('phone', '');
        $filters = [];

        $query = User::whereHas('roles',function($q){
            $q->whereNotIn('slug',['contractor','independent','sub-contractor']);
        })->withoutGlobalScope(ActiveScope::class);

        if ($name !== '') {
            $nameParts = explode(" ", trim($name));
            $firstName = $nameParts[0] ?? ''; // First word
            $lastName = isset($nameParts[1]) ? implode(" ", array_slice($nameParts, 1)) : ''; // Remaining words

            $query->where(function ($query) use ($firstName, $lastName) {
                if (!empty($firstName)) {
                    $query->where('first_name', 'like', "%{$firstName}%");
                }
                if (!empty($lastName)) {
                    $query->orWhere('last_name', 'like', "%{$lastName}%");
                }
            });
        }

        if ($email != '') {
            $query->where('email', 'like', "%{$email}%");
        }
        if ($phone != '') {
            $query->where('mobile_number', 'like', "%{$phone}%");
        }
        if ($perPage === 'all') {
            $details = $query->whereNotIn('user_type', [3, 4])->latest()->get();
        } else {
            $details = $query->whereNotIn('user_type', [3, 4])->latest()->paginate($perPage);
        }

        return view('admin.user.admin_user_list', compact('details', 'name', 'email', 'phone'));
    }


    public function independent_list(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);
        // Get the search term from the request
        $name = $request->input('name', '');
        $email = $request->input('email', '');
        $phone = $request->input('phone', '');
        $is_ready_for_job = $request->input('is_ready_for_job', '');
        $filters = [];

        $query = User::with('stateDetails', 'cityDetails')->withoutGlobalScope(ActiveScope::class);

        if ($name !== '') {
            $nameParts = explode(" ", trim($name));
            $firstName = $nameParts[0] ?? ''; // First word
            $lastName = isset($nameParts[1]) ? implode(" ", array_slice($nameParts, 1)) : ''; // Remaining words

            $query->where(function ($query) use ($firstName, $lastName) {
                if (!empty($firstName)) {
                    $query->where('first_name', 'like', "%{$firstName}%");
                }
                if (!empty($lastName)) {
                    $query->orWhere('last_name', 'like', "%{$lastName}%");
                }
            });
        }

        if ($email != '') {
            $query->where('email', 'like', "%{$email}%");
        }
        if ($phone != '') {
            $query->where('mobile_number', 'like', "%{$phone}%");
        }
        if ($is_ready_for_job != '') {
            $query->where('is_ready_for_job', $is_ready_for_job);
        }

        if ($perPage === 'all') {
            $independent_list = $query->where(['user_type' => 4])->where('completed_steps', '>=', 4)->latest()->get();
        } else {
            $independent_list = $query->where(['user_type' => 4])->where('completed_steps', '>=', 4)->latest()->paginate($perPage);
        }
        return view('admin.user.independent_list', compact('independent_list', 'name', 'email', 'phone', 'is_ready_for_job'));
    }

    public function contractor_list(Request $request)
    {
        // Get the number of items per page from the request or default to 2
        $perPage = $request->input('per_page', 10);
        $name = $request->input('name', '');
        $email = $request->input('email', '');
        $phone = $request->input('phone', '');
        $paymentTerms = $request->input('payment_terms');
        $filters = [];

        $query = User::with('stateDetails', 'cityDetails')->withoutGlobalScope(ActiveScope::class);

        if ($name !== '') {
            $nameParts = explode(" ", trim($name));
            $firstName = $nameParts[0] ?? ''; // First word
            $lastName = isset($nameParts[1]) ? implode(" ", array_slice($nameParts, 1)) : ''; // Remaining words

            $query->where(function ($query) use ($firstName, $lastName) {
                if (!empty($firstName)) {
                    $query->where('first_name', 'like', "%{$firstName}%");
                }
                if (!empty($lastName)) {
                    $query->orWhere('last_name', 'like', "%{$lastName}%");
                }
            });
        }

        if ($email != '') {
            $query->where('email', 'like', "%{$email}%");
        }
        if ($phone != '') {
            $query->where('mobile_number', 'like', "%{$phone}%");
        }
        if (isset($paymentTerms)) {
            $query->where('is_blocked', $paymentTerms);
        }

        if ($perPage === 'all') {
            $contractor_list = $query->where('user_type', 3)->where('completed_steps', '>=', 4)->latest()->get();
        } else {
            $contractor_list = $query->where('user_type', 3)->where('completed_steps', '>=', 4)->latest()->paginate($perPage);
        }
        return view('admin.user.contractor_list', compact('contractor_list', 'name', 'email', 'phone', 'paymentTerms'));
    }


    public function details($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        $subUsers = [];
        if($details->roles[0]->slug == 'contractor'){
            $subUsers = User::withoutGlobalScope(ActiveScope::class)->where('added_by', $details->id)->get();
        }
        return view('admin.user.details', compact('details', 'subUsers'));
    }

    public function user_truck_details_edit($id)
    {
        $details  = UserTruck::withoutGlobalScope(ActiveScope::class)->where('user_id', $id)->first();
        $user_details  = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
        // dd( $details);
        $truck_type  = TruckType::get();
        return view('admin.user.edit-user-truck-details', compact('details', 'user_details', 'truck_type'));
    }

    public function user_truck_details_edit_independent($id)
    {
        $details  = UserTruck::withoutGlobalScope(ActiveScope::class)->where('user_id', $id)->first();
        $user_details  = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
        $truck_type  = TruckType::get();
        // dd( $details,$user_details);
        return view('admin.user.edit-user-truck-details-independent', compact('details', 'user_details', 'truck_type'));
    }

    public function contractor_details($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        $submitted_job = Job::where(['is_draft' => 0, 'status' => 1, 'user_id' => $details->id])->toRawSql();
        $completed_job = Job::where('is_draft', 0)->where('status', 3)->get();
        return view('admin.user.contractor_details', compact('details', 'submitted_job', 'completed_job'));
    }

    public function independent_details($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        return view('admin.user.independent_details', compact('details'));
    }

    public function edit_personal_info($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        $states = State::where('country_id', 233)->get();
        $cities = City::get();
        return view('admin.user.edit-user-details', compact('details', 'states', 'cities'));
    }

    public function edit_others_info($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        return view('admin.user.edit-user-other-details', compact('details'));
    }

    public function edit_personal_info_independent($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        $states = State::where('country_id', 233)->get();
        $cities = City::get();
        return view('admin.user.edit-user-details-independent', compact('details', 'states', 'cities'));
    }



    public function edit_others_info_independent($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();

        return view('admin.user.edit-user-other-details-independent', compact('details'));
    }

    public function edit_personal_info_contractor($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        $states = State::where('country_id', 233)->get();
        $cities = City::get();
        return view('admin.user.edit-user-details-contractor', compact('details', 'states', 'cities'));
    }

    public function edit_others_info_contractor($uuid)
    {
        $details  = User::withoutGlobalScope(ActiveScope::class)->where('uuid', $uuid)->first();
        return view('admin.user.edit-user-other-details-contractor', compact('details'));
    }

    public function update_personal_details(Request $request)
    {
        $user = array();
        if ($request->post()) {

            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:users,email,' . $request->id,
                'dob' => 'required',
                'address' => 'required',
                'state_id' => 'required',
                'city_id' => 'required',

            ],[
                'email.unique' => 'Email already exists for another user',
                'state_id.required' => 'State is required',
                'city_id.required' => 'City is required',
            ]);
            $message = "User Updated Successfully";

            DB::beginTransaction();
            try {
                $id = $request->id;
                if ($id != null) {
                    $user_details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
                    if ($request->email != $user_details->email) {
                        UserEmail::create([
                            'user_id' => $id,
                            'old_email' => $user_details->email,
                            'new_email' => $request->email,
                        ]);
                    }
                }
                if ($id != null) {
                    $user_details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
                    if ($request->email == $user_details->email) {
                        UserEmail::create([
                            'user_id' => $id,
                            'old_email' => $user_details->email,
                            'new_email' => $request->email,
                        ]);
                    }
                }

                $postData = [
                    "first_name" => $request->first_name,
                    "last_name" => $request->last_name,
                    "mobile_number" => $request->mobile_number,
                    "email" => $request->email,
                    "dob" => $request->dob,
                    "address" => $request->address,
                    "pin_code" => $request->pin_no,
                    "state_id" => $request->state_id,
                    "city_id" => $request->city_id,
                ];
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $postData['profile_image'] = $fileName;
                    }
                }

                $user = User::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();

            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.details', $details?->uuid)];
            return response($data);
        }
    }

    public function update_other_details(Request $request)
    {
        $user = array();
        if ($request->post()) {


            $message = "User Othes Details Updated Successfully";

            DB::beginTransaction();
            try {
                $user_id = $request->id;
                $postData = [
                    "company_legal_name" => $request->company_legal_name,
                    "company_dba" => $request->company_dba,
                    "phone_2" => $request->phone_2,
                    "tax_id" => $request->tax_id,
                    "driving_license_no" => $request->driving_license_no,
                    "driving_license_expiery" => $request->driving_license_expiery,

                ];

                $user = Profile::updateOrCreate(['user_id' => $user_id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $details = User::withoutGlobalScope(ActiveScope::class)->where('id', $user_id)->first();

            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.details', $details?->uuid)];
            return response($data);
        }
    }

    public function update_personal_details_independent(Request $request)
    {
        $user = array();
        if ($request->post()) {

            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required',
                'dob' => 'required',
                'address' => 'required',

            ]);
            $message = "User Updated Successfully";

            DB::beginTransaction();
            try {
                $id = $request->id;
                if ($id != null) {
                    $user_details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
                    if ($request->email != $user_details->email) {
                        UserEmail::create([
                            'user_id' => $id,
                            'old_email' => $user_details->email,
                            'new_email' => $request->email,
                        ]);
                    }
                }
                $postData = [
                    "first_name" => $request->first_name,
                    "last_name" => $request->last_name,
                    "mobile_number" => $request->mobile_number,
                    "email" => $request->email,
                    "dob" => $request->dob,
                    "address" => $request->address,
                    "pin_code" => $request->pin_no,
                    "state_id" => $request->state_id,
                    "city_id" => $request->city_id,
                ];
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $postData['profile_image'] = $fileName;
                    }
                }

                $user = User::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }


            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.independent-details', $user_details?->uuid)];
            return response($data);
        }
    }

    public function update_other_details_independent(Request $request)
    {
        $user = array();
        if ($request->post()) {


            $message = "User Othes Details Updated Successfully";

            DB::beginTransaction();
            try {
                $user_id = $request->id;
                $postData = [
                    "company_legal_name" => $request->company_legal_name,
                    "company_dba" => $request->company_dba,
                    "phone_2" => $request->phone_2,
                    "tax_id" => $request->tax_id,
                    "driving_license_no" => $request->driving_license_no,
                    "driving_license_expiery" => $request->driving_license_expiery,

                ];

                $user = Profile::updateOrCreate(['user_id' => $user_id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            // dd($user_id);
            $details = User::withoutGlobalScope(ActiveScope::class)->where('id', $user_id)->first();


            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.independent-details', $details?->uuid)];
            return response($data);
        }
    }

    public function update_personal_details_contractor(Request $request)
    {
        $user = array();
        if ($request->post()) {

            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required',
                'dob' => 'required',
                'address' => 'required',

            ]);
            $message = "User Updated Successfully";

            DB::beginTransaction();
            try {
                $id = $request->id;
                if ($id != null) {
                    $user_details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();
                    if ($request->email != $user_details->email) {
                        UserEmail::create([
                            'user_id' => $id,
                            'old_email' => $user_details->email,
                            'new_email' => $request->email,
                        ]);
                    }
                }
                $postData = [
                    "first_name" => $request->first_name,
                    "last_name" => $request->last_name,
                    "mobile_number" => $request->mobile_number,
                    "email" => $request->email,
                    "dob" => $request->dob,
                    "address" => $request->address,
                    "pin_code" => $request->pin_no,
                    "state_id" => $request->state_id,
                    "city_id" => $request->city_id,
                ];
                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $postData['profile_image'] = $fileName;
                    }
                }

                $user = User::withoutGlobalScope(ActiveScope::class)->updateOrCreate(['id' => $id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $details = User::withoutGlobalScope(ActiveScope::class)->where('id', $id)->first();

            // dd($details);

            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.contractor-details', $details?->uuid)];
            return response($data);
        }
    }

    public function update_other_details_contractor(Request $request)
    {
        $user = array();
        if ($request->post()) {


            $message = "User Othes Details Updated Successfully";

            DB::beginTransaction();
            try {
                $user_id = $request->id;
                $postData = [
                    "company_legal_name" => $request->company_legal_name,
                    "company_dba" => $request->company_dba,
                    "phone_2" => $request->phone_2,
                    "tax_id" => $request->tax_id,
                    "driving_license_no" => $request->driving_license_no,
                    "driving_license_expiery" => $request->driving_license_expiery,

                ];

                $user = Profile::updateOrCreate(['user_id' => $user_id], $postData);

                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $details = User::withoutGlobalScope(ActiveScope::class)->where('id', $user_id)->first();

            $data = ['status' => true, 'message' => $message, 'data' => $user, 'url' => route('admin.user.contractor-details', $details?->uuid)];
            return response($data);
        }
    }

    public function getDistricts(Request $request)
    {
        $districts = City::where('state_id', $request->state_id)->get();
        return response()->json($districts);
    }

    public function export(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'user_ids' => 'required|array',
            'user_ids.*' => 'exists:users,id', // Ensure IDs exist in the users table
        ]);

        // Update the is_export field for the specified users
        User::whereIn('id', $request->user_ids)->update(['is_export' => 1]);

        return response()->json(['success' => true]);
    }

    public function force_logout(Request $request)
    {

        // Find the user by UUID
        $user = User::where('uuid', $request->uuid)->first();

        $user->update(['is_logged_in' => 0, 'fcm_token' => null]);

        // Check if the user exists
        if (!$user) {
            return response()->json(['status' => false, 'message' => 'User not found'], 404);
        }

        // Revoke all tokens for the user
        $user->tokens()->delete(); // This revokes all tokens

        return response()->json(['status' => true, 'message' => 'User logged out successfully']);
    }


    public function load_details($id)
    {
        $load_details = Load::find($id);
        return view('admin.user.load_details', compact('load_details'));
    }

    public function getCity(Request $request)
    {
        $citys = City::where('state_id', $request->state_id)->get();
        return response()->json($citys);
    }
}
