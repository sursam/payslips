<?php

namespace App\Http\Controllers\Admin;

use App\Models\Setting;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class SettingController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        if ($request->post()) {
            $message = "Settings Updated Successfully";

            DB::beginTransaction();
            try {
                $postData = array();
                if (!empty($request->phone_number)) {
                    $postData['phone_number'] = $request->phone_number;
                }
                if (!empty($request->email_id)) {
                    $postData['email_id'] = $request->email_id;
                }

                if (!empty($request->address)) {
                    $postData['address'] = $request->address;
                }
                if (!empty($request->copyright_text)) {
                    $postData['copyright_text'] = $request->copyright_text;
                }
                if (!empty($request->facebook)) {
                    $postData['facebook'] = $request->facebook;
                }
                if (!empty($request->linkidin)) {
                    $postData['linkidin'] = $request->linkidin;
                }
                if (!empty($request->twitter)) {
                    $postData['twitter'] = $request->twitter;
                }
                if (!empty($request->instagram)) {
                    $postData['instagram'] = $request->instagram;
                }
                if (!empty($request->contact_map)) {
                    $postData['contact_map'] = $request->contact_map;
                }
                if (!empty($request->job_payment_percentage)) {
                    $postData['job_payment_percentage'] = $request->job_payment_percentage;
                }
                if (!empty($request->haul_job_payment_percentage)) {
                    $postData['haul_job_payment_percentage'] = $request->haul_job_payment_percentage;
                }
                if (!empty($request->cal_commission)) {
                    $postData['cal_commission'] = $request->cal_commission;
                }
                if (!empty($request->on_loading_hour)) {
                    $postData['on_loading_hour'] = $request->on_loading_hour ?? 0;
                }
                if (!empty($request->off_loading_hour)) {
                    $postData['off_loading_hour'] = $request->off_loading_hour ?? 0;
                }

                $details = Setting::updateOrCreate(['id' => 1], $postData);
                DB::Commit();
            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $response = array('Message' => $th->getMessage(), 'File Path' => $th->getFile(), 'Line Number' => $th->getLine());
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.setting.update')];
            return response($data);
        }
        $details = Setting::find(1);
        return view('admin.setting.index', compact('details'));
    }

}
