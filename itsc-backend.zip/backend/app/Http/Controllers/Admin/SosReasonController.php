<?php

namespace App\Http\Controllers\Admin;

use App\Models\SosReason;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class SosReasonController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = SosReason::latest()->get();
        return view('admin.sos-reason.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'description' => 'required|string'
                ]);
                $message = "SosReason Updated Successfully";
            } else {
                $request->validate([
                  'description' => 'required|string'
                ]);
                $message = "SosReason Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "description" => $request->description,
                ];

                $details = SosReason::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.sos-reason.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'sos_reasons');
            $details = SosReason::find($uuid);
        }
        return view('admin.sos-reason.add', compact('details'));
    }
}
