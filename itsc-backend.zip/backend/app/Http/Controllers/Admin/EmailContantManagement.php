<?php

namespace App\Http\Controllers\Admin;

use App\Models\Service;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use App\Models\EmailContant;
use PharIo\Manifest\Email;

class EmailContantManagement extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = EmailContant::latest()->get();
        return view('admin.email-contant.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                ]);
                $message = "Email Contant Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                ]);
                $message = "Email Contant Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "slug" => isSluggable($request->title), //$request->slug,
                    "subject" => $request->subject,
                    "description" => $request->description,
                ];

                $details = EmailContant::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.email-contant.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'email_contants');
            $details = EmailContant::find($uuid);
        }
        return view('admin.email-contant.add', compact('details'));
    }
}
