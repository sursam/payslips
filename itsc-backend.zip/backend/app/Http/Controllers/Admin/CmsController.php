<?php

namespace App\Http\Controllers\Admin;

use App\Models\CMS;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use App\Traits\CommonFunction;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;

class CmsController extends BaseController
{
    use CommonFunction;
    use UploadAble;
    public function index(Request $request)
    {
        $details = CMS::orderBy('id','asc')->get();
        return view('admin.cms.index', compact('details'));
    }
    public function add(Request $request)
    {
        if ($request->post()) {
            $id = $request->id ?? NULL;
            if (!empty($id)) {
                $request->validate([
                    'title' => 'required|string',
                    'description' => 'required|string'
                ]);
                $message = "CMS Updated Successfully";
            } else {
                $request->validate([
                    'title' => 'required|string',
                    'description' => 'required|string',
                    'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
                ]);
                $message = "CMS Created Successfully";
            }

            DB::beginTransaction();
            try {

                $postData = [
                    "title" => $request->title,
                    "description" => $request->description,
                ];

                if (!empty($request->file)) {
                    $image = $request->file;
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_CMS_UPLOAD_PATH'), $fileName, 'public');
                    // dd($isFileUploaded);
                    if ($isFileUploaded) {
                        $postData['file'] = $fileName;
                    }
                }
                $details = CMS::updateOrCreate(['id' => $id], $postData);
                DB::Commit();

            } catch (\Throwable $th) {
                DB::rollback();
                $status = false;
                $code = 500;
                $response = $th->getMessage();
                $message = config('constants.CATCH_ERROR_MSG');
                return $this->responseJson($status, $code, $message, $response);
            }
            $data = ['status' => true, 'message' => $message, 'data' => $details ?? null, 'url' => route('admin.cms.list')];
            return response($data);
        }
        $details = array();
        if (!empty($request->uuid)) {
            $uuid = uuidtoid($request->uuid, 'c_m_s');
            $details = CMS::find($uuid);
        }
        return view('admin.cms.add', compact('details'));
    }

}
