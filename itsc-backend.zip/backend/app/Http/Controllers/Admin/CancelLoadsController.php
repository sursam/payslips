<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\CancelJob;

class CancelLoadsController extends BaseController
{
    public function index(Request $request)
    {

        $perPage = $request->input('per_page', 10);
        $search = $request->input('search', '');
        $cancel_jobs = CancelJob::whereHas('job',function($q) use ($search){
            $q->where('unique_id', 'like', "%{$search}%")
            ->orWhere('order_no', 'like', "%{$search}%");
        })->latest()
        ->paginate($perPage);

        return view('admin.cancel_loads.index',compact('cancel_jobs'));
    }
}
