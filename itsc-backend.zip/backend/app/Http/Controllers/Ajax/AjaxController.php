<?php

namespace App\Http\Controllers\Ajax;


use App\Models\AppBanner as Banner;
use App\Models\User;
use App\Models\DashboardBanner;
use App\Traits\PushNotificationTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use App\Models\AppIntro;
use App\Models\CancellationReason;
use App\Models\CMS;
use App\Models\EmailContant;
use App\Models\LoadType;
use App\Models\SosReason;
use App\Models\Material;
use App\Models\Equipment;
use App\Models\Faq;
use App\Models\HelpQuestion;
use App\Models\HomepageBanner;
use App\Models\JobComission;
use App\Models\PaymentTerms;
use App\Models\Role;
use App\Models\Service;
use App\Models\TruckType;
use App\Scopes\ActiveScope;

class AjaxController extends BaseController
{
    use PushNotificationTrait;
    public function deleteData(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            switch ($table) {
                case 'users':
                    $id = uuidtoid($request->uuid, $table);
                    $data = User::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->update(['email' => $data->email.'@deleted','mobile_number' => date('YmdHis')]);
                    $data->delete();
                    $message = 'User Deleted';
                    break;
                case 'app_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Banner::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->delete();
                    $message = 'Banner Deleted';
                    break;

                case 'email_contants':
                    $id = uuidtoid($request->uuid, $table);
                    $data = EmailContant::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->delete();
                    $message = 'Email Contant Deleted';
                    break;

                case 'app_intros':
                    $id = uuidtoid($request->uuid, $table);
                    $data = AppIntro::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->delete();
                    $message = 'App Into Deleted';
                    break;
                case 'c_m_s':
                    $id = uuidtoid($request->uuid, $table);
                    $data = CMS::find($id);
                    $data->delete();
                    $message = 'CMS Deleted';
                    break;
                case 'dashboard_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = DashboardBanner::find($id);
                    $data->delete();
                    $message = 'Dashboard Banner Deleted';
                    break;
                case 'sos_reasons':
                    $id = uuidtoid($request->uuid, $table);
                    $data = SosReason::find($id);
                    $data->delete();
                    $message = 'Sos Reason Deleted';
                    break;
                case 'cancellation_reasons':
                    $id = uuidtoid($request->uuid, $table);
                    $data = CancellationReason::find($id);
                    $data->delete();
                    $message = 'Cancellation Reason Deleted';
                    break;
                case 'load_types':
                    $id = uuidtoid($request->uuid, $table);
                    $data = LoadType::find($id);
                    $data->delete();
                    $message = 'Load Type Deleted';
                    break;
                case 'materials':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Material::find($id);
                    $data->delete();
                    $message = 'Material Deleted';
                    break;
                case 'equipment':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Equipment::find($id);
                    $data->delete();
                    $message = 'Equipment Deleted';
                    break;
                case 'truck_types':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  TruckType::find($id);
                    $data->delete();
                    $message = ' Truck Type Deleted';
                    break;
                case 'homepage_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  HomepageBanner::find($id);
                    $data->delete();
                    $message = 'Banner Deleted';
                    break;
                case 'services':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  Service::find($id);
                    $data->delete();
                    $message = 'Services Deleted';
                    break;

                case 'help_questions':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  HelpQuestion::find($id);
                    $data->delete();
                    $message = 'Help Question Deleted';
                    break;
                case 'job_comissions':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  JobComission::find($id);
                    $data->delete();
                    $message = 'Job Commissions Deleted';
                    break;
                case 'roles':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  Role::find($id);
                    $data->delete();
                    $message = 'Role Deleted';
                    break;
                case 'faqs':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  Faq::find($id);
                    $data->delete();
                    $message = 'Faq Deleted';
                    break;
            }
            if ($data) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 200, 'Something Went Wrong');
            }
        } else {
            abort(403);
        }
    }
    public function statusChange(Request $request)
    {
        // dd(1);
        if ($request->ajax()) {
            $table = $request->find;
            $message = 'Status changed successfully';
            switch ($table) {
                case 'users':
                    $id = uuidtoid($request->uuid, $table);
                    $data = User::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->update(['is_active' => $request->status, 'is_logged_in' => 0]);
                    break;
                case 'app_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Banner::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'app_intros':
                    $id = uuidtoid($request->uuid, $table);
                    $data = AppIntro::withoutGlobalScope(ActiveScope::class)->find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'c_m_s':
                    $id = uuidtoid($request->uuid, $table);
                    $data = CMS::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'dashboard_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = DashboardBanner::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'sos_reasons':
                    $id = uuidtoid($request->uuid, $table);
                    $data = SosReason::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'cancellation_reasons':
                    $id = uuidtoid($request->uuid, $table);
                    $data = CancellationReason::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;

                case 'load_types':
                    $id = uuidtoid($request->uuid, $table);
                    $data = LoadType::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'materials':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Material::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'equipment':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Equipment::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'truck_types':
                    $id = uuidtoid($request->uuid, $table);
                    $data = TruckType::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'homepage_banners':
                    $id = uuidtoid($request->uuid, $table);
                    $data = HomepageBanner::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'services':
                    $id = uuidtoid($request->uuid, $table);
                    $data = Service::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;

                case 'help_questions':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  HelpQuestion::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'faqs':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  Faq::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
                case 'job_comissions':
                    $id = uuidtoid($request->uuid, $table);
                    $data =  JobComission::find($id);
                    $data->update(['is_active' => $request->status]);
                    break;
        }
            if ($data) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 200, 'Something Went Wrong');
            }
        } else {
            abort(403);
        }
    }
    public function approvedstatusstatusChange(Request $request)
    {
        // dd(1);
        if ($request->ajax()) {
            $table = $request->find;
            $message = 'Successfully';
            switch ($table) {
                case 'users':
                    $id = uuidtoid($request->uuid, $table);

                    $data = User::withoutGlobalScope(ActiveScope::class)->find($id);

                    $data->is_ready_for_job = $request->status;
                    $data->save();
                    break;

        }
        // $pdf = PDF::loadView('certificates.template', $data);

        // // Optional: Set paper size and orientation
        // $pdf->setPaper('a4', 'landscape');

        // // Get PDF content
        // $pdfContent = $pdf->output();

        // Send email with certificate
        // Mail::to($request->email)
        //     ->send(new CertificateMail($request->name, $pdfContent));

            if ($data) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 200, 'Something Went Wrong');
            }
        } else {
            abort(403);
        }
    }

    public function approvedstatus_status_Change(Request $request)
    {
        if ($request->ajax()) {
            $table = 'users';
            $message = 'Successfully';
            $id = uuidtoid($request->uuid, $table);
            $data = User::find($id);
            $message = '';
            if($request->stat == 'approved'){
                $data->is_blocked = '0';
                $data->save();
                $message = 'Your Payment terms is approved from admin. Now You can post jobs';
            }else{
                $payment_terms = PaymentTerms::where('user_id', $data->id)->first();
                if($payment_terms->pay_in > 7){
                    $payment_terms->pay_in = 7;
                    $payment_terms->save();
                }
                $data->is_blocked = '0';
                $data->save();
                $message = 'Your Payment terms is updated into 7 days from admin. Now You can post jobs';
            }

            if ($data) {
                $title = 'Payment Terms';
                $body = $message;
                $this->sendNotification($data->fcm_token, $title, $body, $body, $data->device_type);
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 200, 'Something Went Wrong');
            }
        } else {
            abort(403);
        }
    }
}
