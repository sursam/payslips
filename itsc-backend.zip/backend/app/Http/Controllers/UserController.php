<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\State;
use App\Models\District;
use App\Models\UserDetails;
use App\Models\Proprietor;
use Illuminate\Support\Str;
use App\Models\AgentDetails;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Models\Country;
use App\Models\City;
use App\Models\Setting;
use App\Traits\UploadAble;
use App\Traits\CommonFunction;
use App\Scopes\ActiveScope;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    use CommonFunction;
    use UploadAble;
    public function responseJson($data, $status = 200, array $headers = [], $options = 0)
    {
        return response()->json($data, $status, $headers, $options);
    }


    public function index(Request $request){
        if (auth()->guard('frontend')->check()) {
            return redirect()->route('profile-detail');
        }

        $country = Country::all()->pluck('name', 'id');
        $districts = District::all()->pluck('dist_name', 'id');
        $state = State::all()->pluck('name', 'id');

        return view('frontend.user.index', compact('districts', 'state', 'country'));
    }



    public function getStates($country_id)
    {
        $states = State::where('country_id', $country_id)->pluck('name', 'id');
        return response()->json($states);
    }


    public function getDistricts($state_id)
    {
        $districts = City::where('state_id', $state_id)->pluck('name', 'id');
        return response()->json($districts);
    }



    public function registartion(Request $request){

        $country = Country::where('status','1')->get()->pluck('name', 'id');
        $cities  = City::where('status','1')->get()->pluck('dist_name', 'id');
        $states  = State::where('status','1')->get()->pluck('name', 'id');
        return view('frontend.agent.registartion', compact('country', 'cities','states'));

    }




       // ... existing code ...
       public function store(Request $request)
       {

        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'address' => 'required',
            'countries' => 'required',
            'city' => 'required',
            'state' => 'required',
            'mobile_number' => 'required|unique:users,mobile_number|digits:10',
            'pin_code' => 'required',
            'email' => 'required|email|unique:users,email',

        ]);
           DB::beginTransaction();
           try {
              // $verificationCode = rand(1000, 9999);

                $verificationCode = "1234";
               $aadharNumber = $request->aadhar_no;
               $lastFourDigits = Str::substr($aadharNumber, -4);
               if (!empty($request->profile_image)) {
                $image = $request->profile_image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($image, config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $postData['file'] = $fileName;
                }
            }
               $user = User::create([
                   'first_name' => $request->input('first_name'),
                   'last_name' => $request->input('last_name'),
                   'email' => $request->input('email'),
                   'password' => bcrypt('12345'),
                   'user_type' => '3',
                   'verification_code' => $verificationCode,
                   'mobile_number' => $request->input('mobile_number'),
                   'profile_image'=>$fileName
               ]);


               DB::commit();


               $user = User::where('id', $user->id)->first();
               Mail::send('mail.registration', ['user' => $user], function ($message) use ($user) {
                $message->to($user->email);
                $message->subject('Welcome to Karela Forest Development Corporation!');
            });

               return $this->responseJson(
                [
                    'success' => true,
                    'message' => 'User Registration successfully.'
                ],
                200
            );

           } catch (\Exception $e) {
               DB::rollBack();
               return response()->json(['error' => 'An error occurred: ' . $e->getMessage()], 500);
           }
       }


       public function userLogin(Request $request){
            $request->validate([
                'mobile' => 'required|string|size:10', // Validate mobile number
            ]);

            $mobile = $request->input('mobile');
            $user = User::where('mobile_number', $mobile)->first();
            if (!$user) {
                return response()->json(['success' => false, 'message' => 'You are not register, please register and login again .']);
            }
            $otp = rand(100000, 999999);
            session(['otp' => $otp, 'mobile' => $mobile]);

            return response()->json(['success' => true, 'message' => 'OTP Sent Successfully.']);

       }


       public function otpVerify(Request $request) {
        $request->validate([
            'mobile_number' => 'required|string',
            'otp' => 'required|string'
        ]);

        $user = User::where('mobile_number', $request->mobile_number)->first();

        if (!$user) {
            return response()->json(['status' => false, 'message' => 'User not found'], 404);
        }

        if ($user->verification_code !== $request->otp) {
            return response()->json(['status' => false, 'message' => 'Invalid OTP'], 401);
        }

        Auth::guard('frontend')->login($user);
        //$user->verification_code = null; // Uncomment if you want to clear the verification code
        $user->save();
        return $this->responseJson(
            [
                'success' => true,
                'message' => 'User OTP verified successfully.',
                'redirectUrl' => '', // You can set a redirect URL if needed
            ],
            200
        );
    }

    // Function to store cart data


            public function verifyOtp(Request $request)
        {
            $request->validate([
                'otp' => 'required',
            ]);

            try {
                $otpRecord = User::where('id', $request->user_id)
                    ->where('verification_code', $request->otp)
                    ->where('is_verified', '0')
                    ->first();


                if ($otpRecord) {
                    $otpRecord->verification_code = "";
                    $otpRecord->is_verified = "1";
                    $otpRecord->save();

                    return $this->responseJson(
                        [
                            'success' => true,
                            'message' => 'OTP verified successfully.',
                            'data' => [
                                'redirect_url' => ''
                            ]
                        ],
                        200
                    );
                }

                return $this->responseJson(
                    [
                        'success' => false,
                        'message' => 'Invalid or expired OTP',
                        'data' => [
                            'redirect_url' => ''
                        ]
                    ],
                    200
                );
            } catch (\Exception $e) {
                return response()->json(['error' => 'An error occurred: ' . $e->getMessage()], 500);
            }
        }


        public function agentOpt(Request $request){
            $id=$request->id;
            return view('frontend.agent.opt_verify',compact('id'));
        }



                public function fetchRenewalData(Request $request)
        {
            // Validate the request
            $request->validate([
                'ta_id' => 'required',
            ]);

            // Attempt to find the user by ta_id
            $user = User::where('ta_id', $request->ta_id)->first();

            // Check if the user was found
            if (!$user) {
                // Return a JSON response with an error message
                return response()->json([
                    'message' => 'User not found with the provided TA-ID.',
                    'errors' => [
                        'ta_id' => [
                            'User not found with the provided TA-ID.'
                        ]
                    ]
                ], 404);
            }

            // Fetch districts and states
            $districts = District::all()->pluck('dist_name', 'id');
            $state = State::all()->pluck('name', 'id');


            $html = view('frontend.agent.renewaldata', compact('districts', 'state',))->render();

            // Return the rendered HTML
            return response()->json(['html' => $html]);
        }


        public function login(Request $request){
            $type=$request->get('type');

            return view('frontend.agent.login',compact('type'));
        }


        public function subLogin(Request $request){
            $this->validate($request, [
                'ta_id' => 'required',
                'password' => 'required|string',
            ]);
            DB::beginTransaction();
            try {
                $userData = ['ta_id'=> $request->ta_id, 'password' => $request->password];
                $rememberMe = $request->has('remember') ? true : false;
                if (auth()->guard('frontend')->attempt($userData, $rememberMe)) {
                    $user = auth()->guard('frontend')->user();

                    DB::commit();


            if($type="renewal"){
                  $redirectUrl = route('agent.renewal');
            }else if($type="existing"){

                $redirectUrl = "";

            }

               return $this->responseJson(
                [
                    'success' => true,
                    'message' => 'Agent Login successfully.',
                    'data' => [
                        'redirect_url' => $redirectUrl
                    ]
                ],
                200
            );
                }
                return $this->responseJson(false, 200, 'Login Credential or password are wrong.', '');
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }


        public function renewal(Request $request){
            $id = auth()->guard('frontend')->user()->id;
           $user=User::where('id',$id)->first();

            $districts = District::all()->pluck('dist_name', 'id');
            $state = State::all()->pluck('name', 'id');
            return view('frontend.agent.renewal',compact('user','districts','state'));
        }


        public function update(Request $request, )
{
    $id=$request->id;
    $this->validate($request, [
        'first_name' => 'required',
        'last_name' => 'required',
        'address' => 'required',
        'village' => 'required',
        'district' => 'required',
        'state' => 'required',
        'mobile_number' => 'required',
        'pin_code' => 'required',
        'aadhar_no' => 'required',
        'pan_card' => 'required',
        'email' => 'required|email|unique:users,email,' . $id,
        'firm_name' => 'required|string',
        'firm_address' => 'required|string',
        'firm_village' => 'required|string',
        'firm_dist' => 'required|string',
        'firm_state' => 'required|string',
        'firm_pin_code' => 'required|string',
        'firm_web_site' => 'required',
        'firm_office_no' => 'required',
        'firm_mobile' => 'required',
        'firm_email' => 'required|email',
        'firm_year' => 'required|integer',
        'whether_premises' => 'required',
        'bank_branch' => 'required',
        'foreign_tourist' => 'required',
        'branches_country_one' => 'required',
        'branches_country_two' => 'required',
        'branches_country_three' => 'required',
        'domestic_tourists' => 'required',
        'declarer_name' => 'required',
        'place' => 'required',
        'date' => 'required',
    ]);

    DB::beginTransaction();

    try {
        $user = User::findOrFail($id);
        $user->update([
            'first_name' => $request->input('first_name'),
            'last_name' => $request->input('last_name'),
            'email' => $request->input('email'),
            'mobile_number' => $request->input('mobile_number'),
        ]);

        foreach ($request->pname as $key => $name) {
            $proprietor = Proprietor::where('user_id', $user->id)->where('id', $key)->first();
            if ($proprietor) {
                $proprietor->update([
                    'name' => $request->pname[$key]['name'],
                    'mobile_no' => $request->pmobile_no[$key]['mobile'],
                    'aadhaar_no' => $request->paadhaar_no[$key]['aadhar'],
                    'pancard_no' => $request->ppancard_no[$key]['pan'],
                ]);
            }
        }

        $agentFirm = AgentFirm::where('user_id', $user->id)->first();
        $agentFirm->update([
            'firm_name' => $request->firm_name,
            'firm_address' => $request->firm_address,
            'firm_village' => $request->firm_village,
            'firm_dist' => $request->firm_dist,
            'firm_state' => $request->firm_state,
            'firm_pin_code' => $request->firm_pin_code,
            'firm_web_site' => $request->firm_web_site,
            'firm_office_no' => $request->firm_office_no,
            'firm_mobile' => $request->firm_mobile,
            'firm_email' => $request->firm_email,
            'firm_year' => $request->firm_year,
            'firm_whether_premises' => $request->whether_premises,
            'firm_bank_branch' => $request->bank_branch,
            'firm_foreign_tourist' => $request->foreign_tourist,
            'firm_branches_country_one' => $request->branches_country_one,
            'firm_branches_country_two' => $request->branches_country_two,
            'firm_branches_country_three' => $request->branches_country_three,
        ]);

        $agentDetails = AgentDetails::where('user_id', $user->id)->first();
        $agentDetails->update([
            'registration_type' => 'renewal',
            'operated_by' => $request->operated_by,
            'company_by' => $request->if_company,
            'address' => $request->address,
            'city_id' => $request->district,
            'state_id' => $request->state_id,
            'country_id' => $request->country_id,
            'pin_code' => $request->pin_code,
            'pan_code' => $request->pan_code,
            'aadhar_no' => $request->aadhar_no,
            'village' => $request->village,
            'place' => $request->place,
            'date' => $request->date,
            'declarer_name' => $request->declarer_name,
        ]);

        DB::commit();
        return $this->responseJson(
            [
                'success' => true,
                'message' => 'Agent updated successfully.',
            ],
            200
        );

    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json(['error' => 'An error occurred: ' . $e->getMessage()], 500);
    }
}

    public function profileDetail(Request $request){

        $user =User::where('id',auth()->guard('frontend')->user()->id)->first();
        if($user->user_type == 3){
        return view('frontend.user.profile',compact('user'));
        }else if($user->user_type == 4){
            $districts = District::all()->pluck('dist_name', 'id');
            $state = State::all()->pluck('name', 'id');
            $settings = Setting::where('id','1')->first();
            return view('frontend.agent.profile',compact('user','districts','state','settings'));
        }
    }

/**
 * Display the form for editing the user's profile.
 *
 * Retrieves the authenticated user, along with lists of active countries,
 * cities, and states. Passes this data to the 'frontend.user.editprofile' view.
 *
 * @param Request $request
 * @return \Illuminate\View\View
 */

    public function profileEdit(Request $request){
        $user = User::where('id', Auth::guard('frontend')->id())->first();
        $countries = Country::where('status','1')->get()->pluck('name', 'id');
        $cities  = City::where('country_code','IN')->get()->pluck('name', 'id');

        $states  = State::where('country_code','IN')->get()->pluck('name', 'id');
        if($user->user_type == 3){
            return view('frontend.user.editprofile',compact('user','countries','cities','states'));
            }else if($user->user_type == 4){
                $districts = District::all()->pluck('dist_name', 'id');
                $state = State::all()->pluck('name', 'id');
                return view('frontend.agent.editprofile',compact('user','countries','states','cities'));
            }


    }

    public function profileUpdate(Request $request)
    {
        // Validate the request
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'address' => 'required',
            'country' => 'required',
            'city' => 'required',
            'state' => 'required',
            'mobile_number' => 'required|digits:10|unique:users,mobile_number,' . auth()->guard('frontend')->id(),
            'pin_code' => 'required',
            'email' => 'required|email|unique:users,email,' . auth()->guard('frontend')->id(),
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        DB::beginTransaction();
        try {
            $user = auth()->guard('frontend')->user();
            $userData = [
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $request->input('email'),
                'mobile_number' => $request->input('mobile_number'),
            ];

            // Handle profile image upload
            if ($request->hasFile('profile_image')) {
                $image = $request->profile_image;
                $fileName = uniqid() . '.' . $image->getClientOriginalExtension();

                // Delete old image if exists

                // Upload new image
                $isFileUploaded = $this->uploadOne(
                    $image,
                    config('constants.SITE_PROFILE_IMAGE_UPLOAD_PATH'),
                    $fileName,
                    'public'
                );

                if ($isFileUploaded) {
                    $userData['profile_image'] = $fileName;
                }
            }

            // Update user data
            $user->update($userData);

            // Update or Create user details
            UserDetails::updateOrCreate(
                ['user_id' => $user->id],
                [
                    'address' => $request->address,
                    'city' => $request->city,
                    'country' => $request->country,
                    'state' => $request->state,
                    'pin_code' => $request->pin_code
                ]
            );

            DB::commit();

            return $this->responseJson(
                [
                    'success' => true,
                    'message' => 'Profile updated successfully.',
                    'redirectUrl' => route('profile-detail')
                ],
                200
            );

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(
                [
                    'success' => false,
                    'message' => 'An error occurred while updating profile: ' . $e->getMessage()
                ],
                500
            );
        }
    }

    public function myBooking(Request $request){
        if(auth()->guard('frontend')->check()){
            $my_bookings = [];
            $setting = Setting::first();
            $my_bookings = Booking::where('user_id',auth()->guard('frontend')->user()->id)->withoutGlobalScope(ActiveScope::class)->get();
            return view('frontend.user.mybooking',compact('my_bookings','setting'));
        }else{
            return redirect()->route('home');
        }

    }

        public function logout()
        {
            Auth::guard('frontend')->logout();
            return redirect('/home');
        }



}
