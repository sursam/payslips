<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\User;
use App\Models\Earning;
use App\Models\JobComission;
use App\Models\Notification;
use Illuminate\Support\Facades\Http;

class BaseController extends Controller
{
    protected $data = null;

    protected function setPageTitle($title, $subTitle = '')
    {
        view()->share(['pageTitle' => $title, 'subTitle' => $subTitle]);
    }

    /**
     * @param int $errorCode
     * @param null $message
     * @return \Illuminate\Http\Response
     */
    protected function showErrorPage($errorCode = 404, $message = null)
    {
        $data['message'] = $message;
        return response()->view('errors.' . $errorCode, $data, $errorCode);
    }

    /**
     * @param bool $error
     * @param int $responseCode
     * @param array $message
     * @param null $data
     * @return \Illuminate\Http\JsonResponse
     */
    protected function responseJson($status = true, $responseCode = 200, $message = "", $data = [])
    {
        return response()->json([
            'status'        =>  $status,
            'response_code' =>  $responseCode,
            'message'       =>  $message,
            'data'          =>  $data
        ], $responseCode);
    }

    protected function createUserName($string)
    {
        $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0, 3);
        $nrRand = rand(0, 100);

        $username = trim($firstPart) . trim($secondPart) . trim($nrRand);
        return $username;
    }
    protected function getJobsWithinDistance($latitude, $longitude, $distance, $currentDateTime)
    {
        // Define the radius of the Earth in kilometers
        $earthRadius = 6371;

        // Calculate the angular distance in radians
        $angularDistance = $distance / $earthRadius;

        // Convert latitude and longitude from degrees to radians
        $latitudeRadians = deg2rad($latitude);
        $longitudeRadians = deg2rad($longitude);

        // Calculate minimum and maximum latitude and longitude
        $minLatitude = $latitudeRadians - $angularDistance;
        $maxLatitude = $latitudeRadians + $angularDistance;

        $minLongitude = $longitudeRadians - $angularDistance;
        $maxLongitude = $longitudeRadians + $angularDistance;

        // Perform the query
        $jobsWithinDistance = Job::select('*')
        // ->where('user_id', auth()->user()->id)
        ->where('is_draft',0)
        ->whereIn('status',[1,2])
        ->where('delivery_date_time','>=',$currentDateTime)
            ->selectRaw(
                '(6371 * acos(cos(radians(?)) * cos(radians(source_lat)) * cos(radians(source_lng) - radians(?)) + sin(radians(?)) * sin(radians(source_lat)))) AS distance',
                [$latitude, $longitude, $latitude]
            )
            ->having('distance', '<=', $distance)->get();
        if(!empty($jobsWithinDistance)){
            return $jobsWithinDistance;
        }
        return [];
    }
    protected function getMyJobs($currentDateTime)
    {
        // Perform the query
        $jobsWithinDistance = Job::select('*')
            ->whereIn('user_id', getSubContractorWithMainContractorIds(auth()->user()->id))
            ->where('is_draft',0)
            ->whereIn('status',[1,2])
            ->where(function ($q) use ($currentDateTime) {
                    $q->where('delivery_date_time', '>', $currentDateTime)->orWhereHas('jobLoad', function ($query) {
                        $query->whereIn('status', [1, 2, 3, 5]);
                    });
                })
            ->get();
        if(!empty($jobsWithinDistance)){
            return $jobsWithinDistance;
        }
        return [];
    }
    protected function getUsersWithinDistance($latitude, $longitude, $distance)
    {
        // dd($latitude, $longitude, $distance);
        // Define the radius of the Earth in kilometers
        $earthRadius = 6371;

        // Calculate the angular distance in radians
        $angularDistance = $distance / $earthRadius;

        // Convert latitude and longitude from degrees to radians
        $latitudeRadians = deg2rad($latitude);
        $longitudeRadians = deg2rad($longitude);

        // Calculate minimum and maximum latitude and longitude
        $minLatitude = $latitudeRadians - $angularDistance;
        $maxLatitude = $latitudeRadians + $angularDistance;

        $minLongitude = $longitudeRadians - $angularDistance;
        $maxLongitude = $longitudeRadians + $angularDistance;

        // Perform the query
        $UsersWithinDistance = User::select('*')
            ->selectRaw(
                '(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance',
                [$latitude, $longitude, $latitude]
            )
            ->having('distance', '<=', $distance)->get();
        if(!empty($UsersWithinDistance)){
            return $UsersWithinDistance;
        }
        return [];
    }

    protected function getJobStatus($jobId){
        $job = Job::find($jobId);
        return $job->status;
    }
    protected function sendPushToContracter($userId, $title, $message, $jobId = null, $jobStatus = null)
    {
        $contracterDetails = User::find($userId);
        $jobId = $jobId ? (string)$jobId : null;
        $jobStatus = $jobStatus ? (string)$jobStatus : null;
        $isNotificationSent = $this->sendNotification($contracterDetails->fcm_token, $title, $message, $message, $contracterDetails->device_type, $jobId, $jobStatus);
        if($isNotificationSent){
            return true;
        }
        return false;
    }
    protected function sendPushToTrucker($userId, $title, $message, $deviceType, $jobId = null, $jobStatus = null)
    {
        $truckerDetails = User::find($userId);
        $jobId = $jobId ? (string)$jobId : null;
        $jobStatus = $jobStatus ? (string)$jobStatus : null;
        $isNotificationSent = $this->sendNotification($truckerDetails->fcm_token, $title, $message, $message, $truckerDetails->device_type, $jobId, $jobStatus);
        if($isNotificationSent){
            return true;
        }
        return false;
    }
    protected function notificationToContracter($userId, $title, $message, $jobId = null)
    {
        $isNotificationCreate = Notification::create([
            'title' => $title,
            'user_id' => $userId,
            'job_id' => $jobId,
            'description' => $message,
            'is_for_job' => $jobId ? true : false,
            'job_status' => $jobId ? $this->getJobStatus($jobId) : null,
            'alert_type' => 3
        ]);
        if($isNotificationCreate){
            return true;
        }
        return false;
    }
    protected function notificationToTrucker($userId, $title, $message, $jobId = null)
    {
        $isNotificationCreate = Notification::create([
            'title' => $title,
            'user_id' => $userId,
            'job_id' => $jobId,
            'description' => $message,
            'is_for_job' => $jobId ? true : false,
            'job_status' => $jobId ? $this->getJobStatus($jobId) : null,
            'alert_type' => 3
        ]);
        if($isNotificationCreate){
            return true;
        }
        return false;
    }
    protected function generalNotifiation($userId, $title, $message){
        $isNotificationCreate = Notification::create([
            'title' => $title,
            'user_id' => $userId,
            'description' => $message,
            'is_for_job' => false,
            'alert_type' => 3
        ]);
        if($isNotificationCreate){
            return true;
        }
        return false;
    }
    protected function addEarning($userId, $jobId, $loadId, $amount, $type, $remarks){
        $isEarningAdded = Earning::create([
            'user_id' => $userId,
            'job_id' => $jobId,
            'load_id' => $loadId,
            'amount' => $amount,
            'type'   => $type,
            'remarks' => $remarks
        ]);
        if($isEarningAdded){
            return true;
        }
        return false;
    }



    // find city for comission

    public function findCityFromCoordinates($latitude, $longitude)
    {
        // if (!$this->googleMapsApiKey) {
        //     throw new \Exception('Google Maps API key not configured');
        // }
        $googleMapsApiKey = env('GOOGLE_API_KEY','AIzaSyBYyEVLoI7MeOd2EXKQhePjACpY8pe8wcc');

        try {
            // Get reverse geocoding results
            $geocodeResults = $this->performReverseGeocode($latitude, $longitude);
            if (empty($geocodeResults)) {
                return null;
            }

            // Extract city and state from geocoding results
            $locationInfo = $this->extractLocationInfo($geocodeResults);
            
            if (!$locationInfo) {
                return null;
            }
            // Find matching city in commission table
            return $this->findMatchingCommission($locationInfo);

        } catch (\Exception $e) {
            logger('Location lookup failed', [
                'latitude' => $latitude,
                'longitude' => $longitude,
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }

    /**
     * Perform reverse geocoding API call
     */
    private function performReverseGeocode($latitude, $longitude)
    {
        $googleMapsApiKey = env('GOOGLE_API_KEY', 'AIzaSyBYyEVLoI7MeOd2EXKQhePjACpY8pe8wcc');
        $response = Http::timeout(15)->get('https://maps.googleapis.com/maps/api/geocode/json', [
            'latlng' => "{$latitude},{$longitude}",
            'key' => $googleMapsApiKey
        ]);

        if (!$response->successful()) {
            throw new \Exception('Geocoding API request failed');
        }

        $data = $response->json();
        
        if ($data['status'] !== 'OK') {
            if ($data['status'] === 'ZERO_RESULTS') {
                return [];
            }
            throw new \Exception('Geocoding failed: ' . $data['status']);
        }
        return $data['results'] ?? [];
    }

    /**
     * Extract city, state, and place_id from geocoding results
     */
    private function extractLocationInfo($results)
    {
        foreach ($results as $result) {
            if (!isset($result['address_components'])) {
                continue;
            }

            $locationInfo = [
                'city' => null,
                'state' => null,
                'place_id' => $result['place_id'] ?? null
            ];

            // Extract city and state from address components
            foreach ($result['address_components'] as $component) {
                $types = $component['types'];

                // Get city (locality)
                if (in_array('locality', $types) && !$locationInfo['city']) {
                    $locationInfo['city'] = $component['long_name'];
                }

                // Get state (administrative_area_level_1)
                if (in_array('administrative_area_level_1', $types) && !$locationInfo['state']) {
                    $locationInfo['state'] = $component['long_name'];
                }
            }

            // If we found both city and state, return this info
            if ($locationInfo['city'] && $locationInfo['state']) {
                return $locationInfo;
            }
        }

        return null;
    }

    /**
     * Find matching commission record based on location info
     */
    private function findMatchingCommission($locationInfo)
    {
        $query = new JobComission; // Replace 'commission' with your actual table name

        // Try exact match first (city + state)
        // $exactMatch = $query->where(function($q) use ($locationInfo) {
        //     $q->whereRaw('LOWER(city) = ?', [strtolower($locationInfo['city'])])
        //       ->whereRaw('LOWER(state) = ?', [strtolower($locationInfo['state'])]);
        // })->first();
        $exactMatch = $query->where(function($q) use ($locationInfo) {
           $q->whereHas('state', function ($stateQuery) use ($locationInfo) {
               $stateQuery->whereRaw('LOWER(name) = ?', [strtolower($locationInfo['state'])]);
           })->whereHas('city', function ($cityQuery) use ($locationInfo) {
               $cityQuery->whereRaw('LOWER(name) = ?', [strtolower($locationInfo['city'])]);
           });
        })->first();
        if ($exactMatch) {
            return $exactMatch;
        }

        // Try place_id match if available
        if ($locationInfo['place_id']) {
            $placeIdMatch = $query->where('place_id', $locationInfo['place_id'])->first();
            if ($placeIdMatch) {
                return $placeIdMatch;
            }
        }

        // Try city name only (in case state names don't match exactly)
        // $cityMatch = $query->whereRaw('LOWER(city) = ?', [strtolower($locationInfo['city'])])->first();
        $cityMatch = $cityMatch ?? $query->whereHas('city', function ($cityQuery) use ($locationInfo) {
            $cityQuery->whereRaw('LOWER(name) = ?', [strtolower($locationInfo['city'])]);
        })->first();
        return $cityMatch;
    }

    /**
     * Alternative method: Find closest city by distance if exact match fails
     * 
     * @param float $latitude
     * @param float $longitude
     * @param int $maxDistanceKm Maximum distance to consider (default 50km)
     * @return object|null
     */
    public function findClosestCity($latitude, $longitude, $maxDistanceKm = 50)
    {
        // Get all cities from commission table
        $cities = JobComission::whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->get();

        $closestCity = null;
        $minDistance = $maxDistanceKm;

        foreach ($cities as $city) {
            $distance = $this->calculateDistance(
                $latitude, 
                $longitude, 
                $city->latitude, 
                $city->longitude
            );

            if ($distance < $minDistance) {
                $minDistance = $distance;
                $closestCity = $city;
            }
        }

        return $closestCity;
    }

    /**
     * Calculate distance between two coordinates using Haversine formula
     */
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat/2) * sin($dLat/2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon/2) * sin($dLon/2);

        $c = 2 * atan2(sqrt($a), sqrt(1-$a));

        return $earthRadius * $c;
    }

    /**
     * Comprehensive method that tries both geocoding and distance approaches
     * 
     * @param float $latitude
     * @param float $longitude
     * @return object|null
     */
    public function findCityWithFallback($latitude, $longitude)
    {
        // First try: Exact geocoding match
        $geocodeResult = $this->findCityFromCoordinates($latitude, $longitude);
        
        if ($geocodeResult) {
            return $geocodeResult;
        }

        // Second try: Find closest city by distance
        $distanceResult = $this->findClosestCity($latitude, $longitude, 25); // 25km radius
        
        return $distanceResult;
    }
}
