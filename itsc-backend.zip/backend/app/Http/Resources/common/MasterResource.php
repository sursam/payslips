<?php

namespace App\Http\Resources\common;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MasterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'load-types')){
            $dataArray = [
                'load_id' => $this->id,
                'name' => $this->title,
                'slug' => $this->slug
            ];
            return $dataArray;
        } else if(str_contains(request()->route()->getName(), 'materials')){
            $dataArray = [
                'material_id' => $this->id ?? '',
                'name' => $this->title ?? '',
                'type'  => $this->type ?? ''
            ];
            return $dataArray;
        } else if(str_contains(request()->route()->getName(), 'equipments')){
            $dataArray = [
                'equipment_id' => $this->id ?? '',
                'name' => $this->title ?? '',
                'type' => $this->type ?? ''
            ];
            return $dataArray;
        }else if(str_contains(request()->route()->getName(), 'banners')){
            $dataArray = [
                'banner_id'=> $this->id ?? '',
                'banner_title' => $this->title ?? '',
                'banner_image' => $this->image_path,
                'banner_url' => $this->url ?? '',
            ];
            return $dataArray;
        }
    }
}
