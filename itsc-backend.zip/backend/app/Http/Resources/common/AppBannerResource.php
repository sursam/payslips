<?php

namespace App\Http\Resources\common;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AppBannerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'banner_id'=> $this->id ?? '',
            'banner_title' => $this->title ?? '',
            'banner_image' => $this->image_path,
            'banner_url' => $this->url ?? '',
        ];
    }
}
