<?php

namespace App\Http\Resources\common;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TruckTypeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'truck_type_id' => $this->id ?? '',
            'name' => $this->title ?? '',
            'specs' => $this->specs ?? '',
            'weight_capacity' => $this->weight_capacity ?? '',
            'trucktype_image' => $this->image_path,
        ];
    }
}
