<?php

namespace App\Http\Resources\Api\Common;

use DateTime;
use App\Models\Job;
use App\Models\City;
use App\Models\Load;
use App\Models\User;
use App\Models\State;
use App\Models\Country;
use App\Models\Feedback;
use App\Traits\StripeTrait;
use App\Models\Notification;
use App\Models\PaymentTerms;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Auth\Contractor\ProfessionalDetailResource;

class AuthResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    protected $token;

    use StripeTrait;

    public function __construct($resource, $token = null)
    {
        parent::__construct($resource);
        $this->token = $token;
    }
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'get-nearest-truckers') || str_contains(request()->route()->getName(), 'get-accepted-job-load')) {
            $dataArray = [
                'id' => $this->id,
                'fname' => $this->first_name,
                'lname' => $this->last_name,
                'country_code' => $this->country_code,
                'mobile' => (string)$this->mobile_number,
                'email' => $this->email,
                'language' => $this->language,
                'completed_steps' => $this->completed_steps,
                'user_role' => $this->roles[0]->id,
                'profile_image' => $this->image_path,
                'is_available' => $this->is_approve,
                'company_legal_name' => $this->otherDetails?->company_legal_name,
                'phone_2' => $this->otherDetails?->phone_2,
                'rating' => number_format($this->getAverageRating($this->id), 1, '.', ''),
            ];
        } else {
            $isCountryDetails = $this->getCountryDetails($this->country_code);
            $isStateDetails = $this->getStateDetails($this->state_id);
            $isCityDetails = $this->getCityDetails($this->city_id);
            $dataArray = [
                'user' => [
                    'id' => $this->id,
                    'fname' => $this->first_name,
                    'lname' => $this->last_name,
                    'country_code' => $this->country_code,
                    'mobile' => (string)$this->mobile_number,
                    'email' => $this->email,
                    'language' => $this->language,
                    'completed_steps' => $this->completed_steps,
                    'user_role' => $this->roles[0]->id,
                    'profile_image' => $this->image_path,
                    'address' => $this->address,
                    'pincode' => $this->pin_code,
                    'dob' => $this->dob,
                    'total_job' => $this->myTotalPostedJobsOrLoad($this->id),
                    'average_rating' => number_format($this->getAverageRating($this->id), 1, '.', ''),
                    'days_ago' => $this->getDaysAgo($this->created_at),
                    'is_available' => $this->is_approve,
                    'country_details' => [
                        'country_id' => $isCountryDetails->id,
                        'iso' => $isCountryDetails->iso2,
                        'country_name' => $isCountryDetails->name,
                        'phone_code' => $isCountryDetails->phonecode
                    ],
                    'state_details' => [
                        'state_id' => $isStateDetails->id,
                        'state_name' => $isStateDetails->name,
                        'country_id' => $isStateDetails->country_id,
                    ],
                    'city_details' => [
                        'id' => $isCityDetails->id,
                        'state_id' => $isCityDetails->state_id,
                        'name' => $isCityDetails->name,
                    ],
                    'complete_profile_info' => new ProfessionalDetailResource($this->otherDetails),
                    'todayTotalWorkingHours' => 0,
                    'total_unread_job_alerts' => $this->myUnreadJobAlerts($this->id),
                    'total_normal_job_alerts' => $this->myNormalJobAlerts($this->id),
                    'my_jobs' => $this->myTotalPostedJobsOrLoad($this->id),
                    'remaining_payment_days' => $this->user_type == 3 ? $this->remainingPaymentDays($this->id)['daysElapsed'] : 0,
                    'can_post_job' => $this->user_type == 3 ? $this->remainingPaymentDays($this->id)['canPostJob'] : true,
                    'pending_actions_on_job' => $this->getPendingActionsOnJob($this->id) ?? 0,
                    'is_payment_pending' => ($this->user_type == 3 && $this->getContractorPaymentData($this->id)) ? true : false,
                    'kyc_updation_link' => $this->isKycCompleted($this->id) == false && $this->stripe_account_id ? $this->generateAccountLink($this->stripe_account_id, $this->device_type) : null,
                    'user_type' => $this->user_type,
                    'is_any_running_jobLoad_exist' => $this->doesHaveAnyRunningJob($this->id),
                    'payment_terms' => (($this->roles[0]?->slug == 'contractor' || $this->roles[0]?->slug == 'sub-contractor') && $this->paymentTerms) ? $this->paymentTerms->pay_in : 0,
                    'permissions' => $this->permissions->pluck('slug'),
                    'user_role_slug' => $this->roles[0]?->slug,
                    'stripe_payment_method' => $this->stripe_payment_method,
                    'stripe_customer_id' => $this->stripe_customer_id
                ],
                'token' => $this->token ?: null, // Include the token in the response
                'isSubContractor' => $this->roles[0]->slug == 'sub-contractor'
            ];
        }
        return $dataArray;
    }

    // get country details
    private function getCountryDetails($countryCode)
    {
        $isCountryCode = new Country;
        if ($countryCode == 1) {
            $isCountryCode = $isCountryCode->where('iso2', 'US')->first();
        } else {
            $isCountryCode = $isCountryCode->where('phonecode', $countryCode)->first();
        }
        return $isCountryCode;
    }
    // get state details
    private function getStateDetails($stateId)
    {
        $isState = State::find($stateId);
        return $isState;
    }
    // get city details
    private function getCityDetails($cityId)
    {
        $isCity = City::find($cityId);
        return $isCity;
    }
    private function myTotalPostedJobsOrLoad($userId)
    {
        if ($this->roles[0]->slug == 'independent') {
            return Load::where(['user_id' => $userId, 'status' => 4])->count();
        } else {
            return Job::where('user_id', $userId)->count();
        }
    }
    private function myUnreadJobAlerts($userId)
    {
        return Notification::where(['user_id' => $userId, 'is_for_job' => 1, 'is_read' => 0])->count();
    }
    private function myNormalJobAlerts($userId) : int
    {
        return Notification::where(['user_id' => $userId, 'is_for_job' => 0, 'is_read' => 0])->count();
    }
    private function getAverageRating($userId)
    {
        return Feedback::where('given_to', $userId)->avg('rating');
    }
    private function getDaysAgo($createdAt)
    {
        $currentDate = Carbon::now()->format('Y-m-d H:i:s');
        $createdAtDateTime = new DateTime($createdAt);
        $currentDateTime = new DateTime($currentDate);
        $interval = $currentDateTime->diff($createdAtDateTime);
        $daysAgo = $interval->days;
        return $daysAgo;
    }
    private function getContractorPaymentData($userId)
    {
        $user = User::find($userId);
        $paymentTerms = PaymentTerms::where('user_id', $user->id)->first();

        $lastPaidAt = Carbon::parse($user->last_payment_at ?? $user->created_at);
        $currentDate = Carbon::now();
        $intervalInDays = $lastPaidAt->diffInDays($currentDate);
        if($intervalInDays > 0){
            // Single optimized query for completed job loads
            $completedJobLoads = Load::whereHas('job', function ($query) use ($user, $lastPaidAt, $currentDate, $paymentTerms) {
                $query->where('user_id', $user->id);

                // Apply date filter only if payment terms exist and pay_in > 0
                if ($paymentTerms && $paymentTerms->pay_in > 0) {
                    $query->whereBetween('created_at', [$lastPaidAt, $currentDate]);
                }
            })
                ->where('status', 4)
                ->where('is_payment_initiated', '!=', 2)
                ->exists();
            // dd($completedJobLoads);
            return $completedJobLoads;
        }
        return false;
    }
    // private function remainingPaymentDays($userId)
    // {
    //     $user = User::find($userId);
    //     // Get current date and time
    //     $currentDate = Carbon::now();

    //     // Fetch pending payment loads for the user
    //     $isPaymentPending = Load::whereHas('job', function ($query) use ($userId) {
    //         $query->where('user_id', $userId);
    //     })->where(['is_payment_initiated' => 0, 'status' => 4])->get();
    //     if ($isPaymentPending->isNotEmpty()) {
    //         $paymentLinkGeneratedAt = $isPaymentPending->first()->updated_at ?? null;
    //         dd($paymentLinkGeneratedAt);
    //         if ($paymentLinkGeneratedAt) {
    //             // Parse the paymentLinkGeneratedAt and currentDate
    //             $paymentLinkGeneratedAtDateTime = new DateTime($paymentLinkGeneratedAt);
    //             $currentDateTime = new DateTime($currentDate);

    //             // Calculate the interval (days elapsed)
    //             $interval = $currentDateTime->diff($paymentLinkGeneratedAtDateTime);
    //             $daysElapsed = $interval->days;
    //             $daysRemaining = $user->paymentTerms?->pay_in - $daysElapsed;
    //             // Calculate remaining days in the 30-day payment window
    //             // $daysRemaining = 3 - $daysElapsed;
    //             // $daysRemaining = -1;

    //             // Determine if the user can post a job (true or false)
    //             $canPostJob = $daysElapsed == $user->paymentTerms?->pay_in ? false : true;

    //             // Return both values
    //             return [
    //                 'daysElapsed' => $daysRemaining, // Return remaining days if >= 1, otherwise return 0
    //                 'canPostJob' => $canPostJob // True if <= 3, otherwise false
    //             ];
    //         }
    //     }

    //     // If no payment is pending, return null for all values
    //     return [
    //         'daysElapsed' => null,
    //         'canPostJob' => null
    //     ];
    // }
    private function remainingPaymentDays($userId)
    {
        $user = User::find($userId);
        // Get current date and time
        $currentDate = Carbon::now();

        // Fetch pending payment loads for the user
        $isPaymentPending = Load::whereHas('job', function ($query) use ($userId) {
            $query->where('user_id', $userId);
        })->where(['is_payment_initiated' => 0, 'status' => 4])->get();
        if ($isPaymentPending->isNotEmpty()) {
            $lastPaidAt = $user->last_payment_at ?? $user->created_at;
            if ($lastPaidAt) {
                // Parse the paymentLinkGeneratedAt and currentDate
                $paymentLinkGeneratedAtDateTime = new DateTime($lastPaidAt);
                $currentDateTime = new DateTime($currentDate);

                // Calculate the interval (days elapsed)
                $interval = $currentDateTime->diff($paymentLinkGeneratedAtDateTime);
                $daysElapsed = $interval->days;
                $daysRemaining = $user->paymentTerms?->pay_in - $daysElapsed ;

                // Determine if the user can post a job (true or false)
                $canPostJob = $daysElapsed >= $user->paymentTerms?->pay_in ? false : true;
                // Return both values
                return [
                    'daysElapsed' => $daysRemaining < 0 ? 0 : $daysRemaining, // Return remaining days if >= 1, otherwise return 0
                    'canPostJob' => $canPostJob // True if <= 3, otherwise false
                ];
            }
        }

        // If no payment is pending, return null for all values
        return [
            'daysElapsed' => 0,
            'canPostJob' => true
        ];
    }
    private function getPendingActionsOnJob($userId)
    {
        return Load::whereHas('job', function ($query) use ($userId) {
            $query->where('user_id', $userId);
        })->where(function($gq){
            $gq->where('status', 3)->orWhere(function ($q) {
                $q->where('status', '!=', 3)->whereNotNull('cancellation_request_id');
            });
        })->count();
    }
    private function isKycCompleted($userId)
    {
        try {
            $user = User::find($userId);
            if($user->user_type == 4 && $user->completed_steps < 6){
                $isKycDone = $this->checkStripeAccountStatus($user->stripe_account_id);
            }else{
                $isKycDone = true;
            }
            return $isKycDone;
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return false; // or true, depending on your business logic
        }
    }

    private function doesHaveAnyRunningJob($userId)
    {
        $user = User::find($userId);
        if (!$user) {
            return false; // User not found
        }
        $statusFilter = [1, 2, 3];
        $query = Load::query();
        if ($user->user_type == 4) {
            // Truckers
            $query->where('user_id', $userId);
        } else {
            // Contractors
            $query->whereHas('job', function ($q) use ($userId) {
                $q->where('user_id', $userId);
            });
        }

        return $query->whereIn('status', $statusFilter)->exists();
    }

}
