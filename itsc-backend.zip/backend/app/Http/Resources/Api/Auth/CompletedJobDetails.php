<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CompletedJobDetails extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'job_id' => $this->job?->id,
            'load_id' => $this->id ?? '',
            'load_index' => calculateLoadIndex($this->job?->id, $this->id),
            'source'  => $this->job?->source,
            'destination' => $this->job?->destination,
            'unique_id' => $this->job?->unique_id,
            'order_no' => $this->job?->order_no,
            // 'material' => $this->job?->material_id != null ? $this->job?->jobMaterial?->title : $this->job?->material_other,
            'material' => $this->job?->jobMaterial?->title == "Other" 
                            ? $this->job?->material_other 
                            : ($this->job?->material_id != null 
                                ? $this->job?->jobMaterial?->title 
                                : $this->job?->material_other),
            'completed_on' => $this->completed_on ?? '',
            'receiver_name' => $this->jobConfigureMapping?->receiver_name,
            'loaded_truck_weight' => number_format($this->weight, 2, '.', '') ?? '',
            'weight_received_by_trucker' => number_format($this->trucker_taken_weight, 2, '.', '') ?? '',
            'weight_received_by_contracter' => number_format($this->weight, 2, '.', '') ?? '',
            'equipment' => $this->job?->equipment_id != null ? $this->job?->jobEquipment?->title : $this->job?->equipment_other,
            'per_load_price' => number_format($this->trucker_get, 2, '.', '') ?? '',
            'total_mileage' => number_format($this->job?->total_mileage, 2, '.', '') ?? '', //$this->job?->total_mileage,
            'notes' => $this->jobConfigureMapping?->notes,
            'net_weight' => number_format($this->weight, 2, '.', '') ?? '',
            'invoice' => $this->jobConfigureMapping?->final_receipt_image_path,
            'contractor_details' => [
                    'id' => $this->job?->user?->id,
                    'fname' => $this->job?->user?->first_name,
                    'lname' => $this->job?->user?->last_name,
                    'country_code' => $this->job?->user?->country_code,
                    'mobile' => (string)$this->job?->user?->mobile_number,
                    'email' => $this->job?->user?->email,
                    'image' => $this->job?->user?->image_path,
                ],
            // 'price_per_ton' => number_format($this->job?->per_unit_price, 2, '.', '') ?? '',
            'price_per_ton' => auth()->user()->user_type == 3 ? number_format($this->load_cost / $this->weight, 2, '.', '') : number_format($this->trucker_get / $this->weight, 2, '.', ''),
        ];
    }
}
