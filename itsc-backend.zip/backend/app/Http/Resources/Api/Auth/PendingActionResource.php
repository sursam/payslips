<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use App\Models\TruckType;
use Illuminate\Http\Request;
use App\Http\Resources\Api\Auth\JobLoadResource;
use Illuminate\Http\Resources\Json\JsonResource;

class PendingActionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'contractor_details' => [
                'id' => $this->user?->id,
                'fname' => $this->user?->first_name,
                'lname' => $this->user?->last_name,
                'country_code' => $this->user?->country_code,
                'mobile' => (string)$this->user?->mobile_number,
                'email' => $this->user?->email,
            ],
            'truck_details' => $this->getTruckTypeDetails($this->truck_type_ids),
            'load_type_id' => $this->load_type_id,
            'unique_id' => $this->unique_id,
            'order_no' => $this->order_no,
            'job_type' => $this->job_type,
            'pickup_location_company' => $this->pickup_location_company,
            'pickup_location_contact_no' => $this->pickup_location_contact_no,
            'pickup_location_email' => $this->pickup_location_email,
            'pickup_contact' => $this->pickup_contact,
            'drop_off_location_company' => $this->drop_off_location_company,
            'drop_off_location_contact_no' => $this->drop_off_location_contact_no,
            'drop_off_location_email' => $this->drop_off_location_email,
            'drop_off_contact' => $this->drop_off_contact,
            'scheduling_type' => $this->scheduling_type,
            'source' => $this->source,
            'destination' => $this->destination,
            'pickup_date_time' => $this->pickup_date_time,
            'delivery_date_time' => $this->delivery_date_time,
            'source_lat' => $this->source_lat,
            'source_lng' => $this->source_lng,
            'delivery_lat' => $this->delivery_lat,
            'delivery_lng' => $this->delivery_lng,
            'priority' => $this->priority,
            'material_id' => $this->material_id,
            'material_name' => $this->jobMaterial?->title,
            'material_details' => [
                'id' => $this->jobMaterial?->id,
                'name' => $this->jobMaterial?->title,
            ],
            'equipment_details' => $this->equipment_id ? [
                'id' => $this->jobEquipment?->id,
                'name' => $this->jobEquipment?->title,
            ] : null,
            'load_type' => [
                'id' => $this->jobLoadType?->id,
                'name' => $this->jobLoadType?->title,
                'slug' => $this->jobLoadType?->slug
            ],
            'total_load' => $this->jobLoad ? number_format($this->jobLoad->sum('weight'), 2, '.', '') : '0.00',
            'material_other' => $this->material_other,
            'material_option_id' => $this->material_option_id,
            'material_option_other' => $this->material_option_other,
            'truck_type_ids' => $this->truck_type_ids,
            'fright_charges' => $this->fright_charges,
            'equipment_id' => $this->equipment_id,
            'equipment_name' => $this->equipment_id != null ? $this->jobEquipment?->title : null,
            'equipment_other' => $this->equipment_other,
            'equipment_option_id' => $this->equipment_option_id,
            'equipment_option_other' => $this->equipment_option_other,
            'no_of_trucks' => $this->no_of_trucks,
            'total_mileage' => number_format($this->total_mileage, 2, '.', ''),
            'load_spacing_minutes' => number_format($this->load_spacing_minutes, 2, '.', ''),
            'per_unit' => number_format($this->per_unit, 2, '.', ''),
            'per_unit_price' => number_format($this->per_unit_price, 2, '.', ''),
            'job_estimate_price' => number_format($this->job_estimate_price, 2, '.', ''),
            'total_miles' => number_format($this->total_miles, 2, '.', ''),
            'status' => $this->status,
            'job_completed_date' => $this->job_completed_date,
            'payment_status' => $this->payment_status,
            'payment_type' => $this->payment_type,
            'payment_date' => $this->payment_date,
            'notes' => $this->notes,
            'is_draft' => $this->is_draft,
            'is_closed' => $this->is_closed,
            'is_hourly' => $this->is_hourly,
            'available_loads' => $this->getLoadDetails($this->id),
            'job_created_by' => $this->user_id
        ];
    }
    private function getTruckTypeDetails($truckTypeIds)
    {
        $explodedTruckTypes = explode(',', $truckTypeIds);
        $truckTypes = TruckType::whereIn('id', $explodedTruckTypes)->get();
        $dataArray = [];

        if ($truckTypes) {
            foreach ($truckTypes as $truckType) {
                $dataArray[] = [
                    'truck_type_id' => $truckType->id,
                    'name' => $truckType->title,
                    'specs' => $truckType->specs,
                    'weight_capacity' => $truckType->weight_capacity,
                    'trucktype_image' => $truckType->image_path,
                ];
            }
        }

        return $dataArray;
    }
    private function getLoadDetails($jobId)
    {
        // Get all loads for indexing
        $allLoadsOfJob = Load::where('job_id', $jobId)
            ->orderBy('created_at')
            ->pluck('id')
            ->toArray();
        
        $loadIndexMap = array_flip($allLoadsOfJob);
        array_walk($loadIndexMap, function(&$value, $key) {
            $value = $value + 1; // Start from 1 instead of 0
        });
        
        // Get filtered loads
        $loads = Load::where('job_id', $jobId)
            ->where(function($query) {
                $query->where('status', 3)->orWhereNotNull('cancellation_request_id');
            })
            ->get();
        
        // Add index to each load
        $loads->each(function($load) use ($loadIndexMap) {
            $load->load_index = $loadIndexMap[$load->id] ?? null;
        });
        
        return JobLoadResource::collection($loads);
    }

}
