<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RunningJobResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'job_id' => $this->id,
            'source' => $this->source,
            'unique_id' => $this->unique_id,
            'destination' => $this->destination,
            'pickup_date' => $this->pickup_date_time,
            'delivery_date' => $this->delivery_date_time,
            'total_job_cost' => number_format($this->job_estimate_price, 2, '.',''),
            'per_unit' => number_format($this->per_unit,  2, '.',''),
            'total_job_load' => $this->getTotalJobLoad($this->id),
        ];
    }
    private function getTotalJobLoad($jobId): int
    {
        return Load::where('job_id', $jobId)->count();
    }
}
