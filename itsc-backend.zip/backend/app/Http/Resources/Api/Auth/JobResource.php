<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use App\Models\TruckType;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Common\LoadResourceCollection;

class JobResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'get-jobs')) {     // for trucker
            $dataArray = [
                'id' => $this->id,
                'user_id' => $this->user_id,
                'contractor_details' => [
                    'id' => $this->user?->id,
                    'fname' => $this->user?->first_name,
                    'lname' => $this->user?->last_name,
                    'country_code' => $this->user?->country_code,
                    'mobile' => (string)$this->user?->mobile_number,
                    'email' => $this->user?->email,
                ],
                'truck_details' => $this->getTruckTypeDetails($this->truck_type_ids),
                'load_type_id' => $this->load_type_id,
                'unique_id' => $this->unique_id,
                'order_no' => $this->order_no,
                'job_type' => $this->job_type,
                'pickup_location_company' => $this->pickup_location_company,
                'pickup_location_contact_no' => $this->pickup_location_contact_no,
                'pickup_location_email' => $this->pickup_location_email,
                'pickup_contact' => $this->pickup_contact,
                'drop_off_location_company' => $this->drop_off_location_company,
                'drop_off_location_contact_no' => $this->drop_off_location_contact_no,
                'drop_off_location_email' => $this->drop_off_location_email,
                'drop_off_contact' => $this->drop_off_contact,
                'scheduling_type' => $this->scheduling_type,
                'source' => $this->source,
                'destination' => $this->destination,
                'pickup_date_time' => $this->pickup_date_time,
                'delivery_date_time' => $this->delivery_date_time,
                'source_lat' => $this->source_lat,
                'source_lng' => $this->source_lng,
                'delivery_lat' => $this->delivery_lat,
                'delivery_lng' => $this->delivery_lng,
                'priority' => $this->priority,
                'material_id' => $this->material_id,
                'material_name' => $this->jobMaterial?->title,
                'material_details' => [
                    'id' => $this->jobMaterial?->id,
                    'name' => $this->jobMaterial?->title,
                ],
                'equipment_details' => $this->equipment_id ? [
                    'id' => $this->jobEquipment?->id,
                    'name' => $this->jobEquipment?->title,
                ] : null,
                'load_type' => [
                    'id' => $this->jobLoadType?->id,
                    'name' => $this->jobLoadType?->title,
                    'slug' => $this->jobLoadType?->slug
                ],
                // 'total_load' => $this->jobLoad?->count(),
                'total_load' => $this->jobLoad ? number_format($this->jobLoad->sum('weight'), 2, '.', '') : '0.00',
                'material_other' => $this->material_other,
                'material_option_id' => $this->material_option_id,
                'material_option_other' => $this->material_option_other,
                'truck_type_ids' => $this->truck_type_ids,
                'fright_charges' => $this->fright_charges,
                'equipment_id' => $this->equipment_id,
                'equipment_name' => $this->equipment_id != null ? $this->jobEquipment?->title : null,
                'equipment_other' => $this->equipment_other,
                'equipment_option_id' => $this->equipment_option_id,
                'equipment_option_other' => $this->equipment_option_other,
                'no_of_trucks' => $this->no_of_trucks,
                'total_mileage' => number_format($this->total_mileage, 2, '.', ''),
                'load_spacing_minutes' => number_format($this->load_spacing_minutes, 2, '.', ''),
                'per_unit' => number_format($this->per_unit, 2, '.', ''),
                'per_unit_price' => number_format($this->per_unit_price, 2, '.', ''),
                'job_estimate_price' => number_format($this->job_estimate_price, 2, '.', ''),
                'total_miles' => number_format($this->total_mileage, 2, '.', ''),
                'total_km' => number_format($this->total_mileage * 1.609, 2, '.', ''),
                'status' => $this->status,
                'job_completed_date' => $this->job_completed_date,
                'payment_status' => $this->payment_status,
                'payment_type' => $this->payment_type,
                'payment_date' => $this->payment_date,
                'notes' => $this->notes,
                'is_draft' => $this->is_draft,
                'is_closed' => $this->is_closed,
                'is_hourly' => $this->is_hourly,
                // 'available_loads' => JobLoadResource::collection($this->getNotDiscardedLoads($this->id)),   //  for prod usage
                'available_load_count' => $this->jobLoad ? $this->jobLoad->where('is_discarded', 0)->count() : 0,
                'is_accepted_any_load' => $this->hasAcceptedOrRunningLoad($this->id),
                'step' => $this->step,
                'min_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->min : 0,
                'max_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->max : 0,
                'created_user' => $this->user ? ($this->user?->first_name . ' ' . $this->user?->last_name) : 'NA',
                'created_by' => $this->user?->id,
                'created_at' => $this->created_at,
            ];
        } else if (str_contains(request()->route()->getName(), 'manage-job') || str_contains(request()->route()->getName(), 'job-details')) {   // for contractor
            $dataArray = [
                'id' => $this->id,
                'user_id' => $this->user_id,
                'contractor_details' => [
                    'id' => $this->user?->id,
                    'fname' => $this->user?->first_name,
                    'lname' => $this->user?->last_name,
                    'country_code' => $this->user?->country_code,
                    'mobile' => (string)$this->user?->mobile_number,
                    'email' => $this->user?->email,
                ],
                'truck_details' => $this->getTruckTypeDetails($this->truck_type_ids),
                'load_type_id' => $this->load_type_id,
                'unique_id' => $this->unique_id,
                'order_no' => $this->order_no,
                'job_type' => $this->job_type,
                'pickup_location_company' => $this->pickup_location_company,
                'pickup_location_contact_no' => $this->pickup_location_contact_no,
                'pickup_location_email' => $this->pickup_location_email,
                'pickup_contact' => $this->pickup_contact,
                'drop_off_location_company' => $this->drop_off_location_company,
                'drop_off_location_contact_no' => $this->drop_off_location_contact_no,
                'drop_off_location_email' => $this->drop_off_location_email,
                'drop_off_contact' => $this->drop_off_contact,
                'scheduling_type' => $this->scheduling_type,
                'source' => $this->source,
                'destination' => $this->destination,
                'pickup_date_time' => $this->pickup_date_time,
                'delivery_date_time' => $this->delivery_date_time,
                'source_lat' => $this->source_lat,
                'source_lng' => $this->source_lng,
                'delivery_lat' => $this->delivery_lat,
                'delivery_lng' => $this->delivery_lng,
                'priority' => $this->priority,
                'material_id' => $this->material_id,
                'material_name' => $this->jobMaterial?->title,
                'material_details' => [
                    'id' => $this->jobMaterial?->id,
                    'name' => $this->jobMaterial?->title,
                ],
                'equipment_details' => $this->equipment_id ? [
                    'id' => $this->jobEquipment?->id,
                    'name' => $this->jobEquipment?->title,
                ] : null,
                'load_type' => [
                    'id' => $this->jobLoadType?->id,
                    'name' => $this->jobLoadType?->title,
                    'slug' => $this->jobLoadType?->slug
                ],
                // 'total_load' => $this->jobLoad?->count(),
                'total_load' => $this->jobLoad ? number_format($this->jobLoad->sum('weight'), 2, '.', '') : '0.00',
                'material_other' => $this->material_other,
                'material_option_id' => $this->material_option_id,
                'material_option_other' => $this->material_option_other,
                'truck_type_ids' => $this->truck_type_ids,
                'fright_charges' => $this->fright_charges,
                'equipment_id' => $this->equipment_id,
                'equipment_name' => $this->equipment_id != null ? $this->jobEquipment?->title : null,
                'equipment_other' => $this->equipment_other,
                'equipment_option_id' => $this->equipment_option_id,
                'equipment_option_other' => $this->equipment_option_other,
                'no_of_trucks' => $this->no_of_trucks,
                'total_mileage' => number_format($this->total_mileage, 2, '.', ''),
                'total_miles' => number_format($this->total_mileage, 2, '.', ''),
                'total_km' => number_format($this->total_mileage * 1.609, 2, '.', ''),
                'load_spacing_minutes' => number_format($this->load_spacing_minutes, 2, '.', ''),
                'per_unit' => number_format($this->per_unit, 2, '.', ''),
                'per_unit_price' => number_format($this->per_unit_price, 2, '.', ''),
                'job_estimate_price' => number_format($this->job_estimate_price, 2, '.', ''),
                'status' => $this->status,
                'job_completed_date' => $this->job_completed_date,
                'payment_status' => $this->payment_status,
                'payment_type' => $this->payment_type,
                'payment_date' => $this->payment_date,
                'notes' => $this->notes,
                'is_draft' => $this->is_draft,
                'is_closed' => $this->is_closed,
                'is_hourly' => $this->is_hourly,
                // 'available_loads' => JobLoadResource::collection($this->jobLoad),    //  for prod usage
                'available_load_count' => $this->jobLoad ? $this->jobLoad->count() : 0,
                'step' => $this->step,
                'is_available_for_edit' => $this->isAvailableForEdit($this->id) ?? false,
                'min_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->min : 0,
                'max_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->max : 0,
                'created_at' => $this->created_at,
                'created_user' => $this->user ? ($this->user?->first_name . ' ' . $this->user?->last_name) : 'NA',
                'created_by' => $this->user?->id,
            ];
        } else if (str_contains(request()->route()->getName(), 'active-job-cordinates')) {
            $dataArray = [
                'id' => $this->id,
                'user_id' => $this->user_id,
                'contractor_details' => [
                    'id' => $this->user?->id,
                    'fname' => $this->user?->first_name,
                    'lname' => $this->user?->last_name,
                    'country_code' => $this->user?->country_code,
                    'mobile' => (string)$this->user?->mobile_number,
                    'email' => $this->user?->email,
                ],
                'unique_id' => $this->unique_id,
                'source' => $this->source,
                'destination' => $this->destination,
                'pickup_date_time' => $this->pickup_date_time,
                'delivery_date_time' => $this->delivery_date_time,
                'source_lat' => $this->source_lat,
                'source_lng' => $this->source_lng,
                'delivery_lat' => $this->delivery_lat,
                'delivery_lng' => $this->delivery_lng,
                'job_status'   => $this->status,

            ];
        } else {
            $dataArray = [
                'id' => $this->id,
                'user_id' => $this->user_id,
                'contractor_details' => [
                    'id' => $this->user?->id,
                    'fname' => $this->user?->first_name,
                    'lname' => $this->user?->last_name,
                    'country_code' => $this->user?->country_code,
                    'mobile' => (string)$this->user?->mobile_number,
                    'email' => $this->user?->email,
                ],
                'truck_details' => $this->getTruckTypeDetails($this->truck_type_ids),
                'load_type_id' => $this->load_type_id,
                'unique_id' => $this->unique_id,
                'order_no' => $this->order_no,
                'job_type' => $this->job_type,
                'pickup_location_company' => $this->pickup_location_company,
                'pickup_location_contact_no' => $this->pickup_location_contact_no,
                'pickup_location_email' => $this->pickup_location_email,
                'pickup_contact' => $this->pickup_contact,
                'drop_off_location_company' => $this->drop_off_location_company,
                'drop_off_location_contact_no' => $this->drop_off_location_contact_no,
                'drop_off_location_email' => $this->drop_off_location_email,
                'drop_off_contact' => $this->drop_off_contact,
                'scheduling_type' => $this->scheduling_type,
                'source' => $this->source,
                'destination' => $this->destination,
                'pickup_date_time' => $this->pickup_date_time,
                'delivery_date_time' => $this->delivery_date_time,
                'source_lat' => $this->source_lat,
                'source_lng' => $this->source_lng,
                'delivery_lat' => $this->delivery_lat,
                'delivery_lng' => $this->delivery_lng,
                'priority' => $this->priority,
                'material_id' => $this->material_id,
                'material_name' => $this->jobMaterial?->title,
                'material_details' => [
                    'id' => $this->jobMaterial?->id,
                    'name' => $this->jobMaterial?->title,
                ],
                'equipment_details' => $this->equipment_id ? [
                    'id' => $this->jobEquipment?->id,
                    'name' => $this->jobEquipment?->title,
                ] : null,
                'load_type' => [
                    'id' => $this->jobLoadType?->id,
                    'name' => $this->jobLoadType?->title,
                    'slug' => $this->jobLoadType?->slug
                ],
                // 'total_load' => $this->jobLoad?->count(),
                'total_load' => $this->jobLoad ? number_format($this->jobLoad->sum('weight'), 2, '.', '') : '0.00',
                'material_other' => $this->material_other,
                'material_option_id' => $this->material_option_id,
                'material_option_other' => $this->material_option_other,
                'truck_type_ids' => $this->truck_type_ids,
                'fright_charges' => $this->fright_charges,
                'equipment_id' => $this->equipment_id,
                'equipment_name' => $this->equipment_id != null ? $this->jobEquipment?->title : null,
                'equipment_other' => $this->equipment_other,
                'equipment_option_id' => $this->equipment_option_id,
                'equipment_option_other' => $this->equipment_option_other,
                'no_of_trucks' => $this->no_of_trucks,  
                'total_mileage' => number_format($this->total_mileage, 2, '.', ''),
                'load_spacing_minutes' => number_format($this->load_spacing_minutes, 2, '.', ''),
                'per_unit' => number_format($this->per_unit, 2, '.', ''),
                'per_unit_price' => number_format($this->per_unit_price, 2, '.', ''),
                'job_estimate_price' => number_format($this->job_estimate_price, 2, '.', ''),
                'total_miles' => number_format($this->total_mileage, 2, '.', ''),
                'total_km' => number_format($this->total_mileage * 1.609, 2, '.', ''),
                'status' => $this->status,
                'job_completed_date' => $this->job_completed_date,
                'payment_status' => $this->payment_status,
                'payment_type' => $this->payment_type,
                'payment_date' => $this->payment_date,
                'notes' => $this->notes,
                'is_draft' => $this->is_draft,
                'is_closed' => $this->is_closed,
                'is_hourly' => $this->is_hourly,
                // 'available_loads' => JobLoadResource::collection($this->jobLoad),      //  for prod usage
                // 'available_loads' => new LoadResourceCollection($this->jobLoad),
                'available_load_count' => $this->jobLoad ? $this->jobLoad->count() : 0,
                'step' => $this->step,
                'min_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->min : 0,
                'max_completed_hours' => $this->is_hourly ? $this->getMinMaxHrs($this->id)->max : 0,
                'created_at' => $this->created_at,
                'created_user' => $this->user ? ($this->user?->first_name . ' ' . $this->user?->last_name) : 'NA',
                'created_by' => $this->user?->id,
            ];
        }
        return $dataArray;
    }

    // get trucktypes 
    private function getTruckTypeDetails($truckTypeIds)
    {
        $explodedTruckTypes = explode(',', $truckTypeIds);
        $truckTypes = TruckType::whereIn('id', $explodedTruckTypes)->get();
        $dataArray = [];

        if ($truckTypes) {
            foreach ($truckTypes as $truckType) {
                $dataArray[] = [
                    'truck_type_id' => $truckType->id,
                    'name' => $truckType->title,
                    'specs' => $truckType->specs,
                    'weight_capacity' => $truckType->weight_capacity,
                    'trucktype_image' => $truckType->image_path,
                ];
            }
        }

        return $dataArray;
    }
    private function getLoadStatus($status, $data = null): string
    {
        if ($status == 1) {
            return 'Accepted';
        } elseif ($status == 2 && $data == null) {
            return 'Reached';
        } elseif ($status == 2 && $data != null) {
            return 'Running';
        } elseif ($status == 3) {
            return 'Waiting_for_verification';
        } else {
            return 'Completed';
        }
    }


    private function getNotDiscardedLoads($jobId)
    {
        return Load::where('job_id', $jobId)->where(['is_discarded' => 0])->get();
    }
    private function hasAcceptedOrRunningLoad($jobId): bool
    {
        return Load::where('job_id', $jobId)->where('user_id', auth()->user()->id)->whereIn('status', [1, 2])->exists();
    }
    private function isAvailableForEdit($jobId): bool
    {
        return !Load::where('job_id', $jobId)->whereIn('status', [1, 2, 3, 4])->exists();
    }
    private function getMinMaxHrs($jobId): object
    {
        // Get the first indexed load entry for the given job
        $firstLoad = Load::where('job_id', $jobId)->orderBy('created_at', 'asc')->first();

        // Ensure there is a valid load entry before accessing properties
        if (!$firstLoad) {
            return (object) ['min' => 0, 'max' => 0];
        }

        // Get min and max completed hours
        $minHrs = $firstLoad->min_completed_hours ?? 0;
        $maxHrs = $firstLoad->max_completed_hours ?? 0;

        return (object) ['min' => $minHrs, 'max' => $maxHrs];
    }

}
