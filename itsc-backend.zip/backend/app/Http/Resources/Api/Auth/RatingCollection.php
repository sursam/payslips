<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class RatingCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @return array<int|string, mixed>
     */
    public function toArray(Request $request): array
    {
        $averageRating = round($this->collection->avg('rating'), 2);
        $totalCount = $this->collection->count();

        $rating_percentage = [
            'five_star'  => $totalCount > 0 ? round($this->collection->where('rating', 5)->count() / $totalCount * 100, 2) : 0,
            'four_star'  => $totalCount > 0 ? round($this->collection->where('rating', 4)->count() / $totalCount * 100, 2) : 0,
            'three_star' => $totalCount > 0 ? round($this->collection->where('rating', 3)->count() / $totalCount * 100, 2) : 0,
            'two_star'   => $totalCount > 0 ? round($this->collection->where('rating', 2)->count() / $totalCount * 100, 2) : 0,
            'one_star'   => $totalCount > 0 ? round($this->collection->where('rating', 1)->count() / $totalCount * 100, 2) : 0,
        ];

        return [
		    'status' => true,
			'message'=>'Ratings Found Successfully',
			'data' => RatingResource::collection($this->collection),
			'pagination' => [
				'total' => $this->total(),
				'count' => $this->count(),
				'per_page' => $this->perPage(),
				'current_page' => $this->currentPage(),
				'total_pages' => $this->lastPage(),
				'next_page' => $this->nextPageUrl()
			],
            'overall' => [
                'avg' => $averageRating,
                'rating_percentage' => $rating_percentage
            ]
		];
    }
    public function withResponse($request, $response)
    {
        $jsonResponse = json_decode($response->getContent(), true);
        unset($jsonResponse['links'],$jsonResponse['meta']);
        $response->setContent(json_encode($jsonResponse));
    }
}
