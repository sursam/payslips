<?php

namespace App\Http\Resources\Api\Auth\Contractor;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProfessionalDetailResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'company_legal_name' => $this->company_legal_name ?? '',
            'tax_id' => $this->tax_id ?? '',
            'company_dba' => $this->company_dba ?? '',
            'phone_2' => $this->phone_2 ?? '',
            'country_code' => $this->country_code ?? '',
            'company_ein' => $this->tax_id ?? '',
            'driving_license_no' => $this->driving_license_no ?? '',
            'driving_license_expiery' => $this->driving_license_expiery ?? ''
        ];
    }
}
