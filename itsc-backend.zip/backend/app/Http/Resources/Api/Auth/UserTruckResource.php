<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserTruckResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'truck_type_name' => $this->truckType?->title,
            'truck_type_id' => $this->truck_type_id,
            'image' => $this->image_path,
            'truck_license_no' => $this->truck_license_no,
            'company_truck_number' => $this->company_truck_number,
            'truck_model' => $this->truck_make,
            'truck_carrying_capacity' => $this->truck_carrying_capacity,
            'truck_color' => $this->truck_color
        ];
    }
}
