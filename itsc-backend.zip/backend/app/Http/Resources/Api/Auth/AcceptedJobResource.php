<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use App\Models\TruckType;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AcceptedJobResource extends JsonResource
{

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $acceptedLoadId = $this->getAcceptedLoadId(auth()->user()->id);
        return [
            'id' => $this->id,
            'load_id' => $acceptedLoadId,
            'user_id' => $this->user_id,
            'contractor_details' => $this->getContractorDetails(),
            'truck_details' => $this->getTruckTypeDetails($this->truck_type_ids),
            'load_type_id' => $this->load_type_id,
            'unique_id' => $this->unique_id,
            'order_no' => $this->order_no,
            'job_type' => $this->job_type,
            'pickup_location_company' => $this->pickup_location_company,
            'pickup_location_contact_no' => $this->pickup_location_contact_no,
            'pickup_location_email' => $this->pickup_location_email,
            'pickup_contact' => $this->pickup_contact,
            'drop_off_location_company' => $this->drop_off_location_company,
            'drop_off_location_contact_no' => $this->drop_off_location_contact_no,
            'drop_off_location_email' => $this->drop_off_location_email,
            'drop_off_contact' => $this->drop_off_contact,
            'scheduling_type' => $this->scheduling_type,
            'source' => $this->source,
            'destination' => $this->destination,
            'pickup_date_time' => $this->pickup_date_time,
            'delivery_date_time' => $this->delivery_date_time,
            'source_lat' => $this->source_lat,
            'source_lng' => $this->source_lng,
            'delivery_lat' => $this->delivery_lat,
            'delivery_lng' => $this->delivery_lng,
            'priority' => $this->priority,
            'material_id' => $this->material_id,
            'material_name' => $this->jobMaterial?->title,
            'material_details' => $this->getMaterialDetails(),
            'equipment_details' => $this->getEquipmentDetails(),
            'load_type' => $this->getLoadTypeDetails(),
            'material_other' => $this->material_other,
            'material_option_id' => $this->material_option_id,
            'material_option_other' => $this->material_option_other,
            'truck_type_ids' => $this->truck_type_ids,
            'fright_charges' => $this->fright_charges,
            'equipment_id' => $this->equipment_id,
            'equipment_name' => $this->equipment_id ? $this->jobEquipment?->title : null,
            'equipment_other' => $this->equipment_other,
            'equipment_option_id' => $this->equipment_option_id,
            'equipment_option_other' => $this->equipment_option_other,
            'no_of_trucks' => $this->no_of_trucks,
            'total_mileage' => number_format($this->total_mileage, 2, '.', ''),
            'load_spacing_minutes' => number_format($this->load_spacing_minutes, 2, '.', ''),
            'per_unit' => number_format($this->per_unit, 2, '.', ''),
            'per_unit_price' => number_format($this->per_unit_price, 2, '.', ''),
            'job_estimate_price' => number_format($this->job_estimate_price, 2, '.', ''),
            'total_miles' => number_format($this->total_miles, 2, '.', ''),
            'status' => $this->status,
            'job_completed_date' => $this->job_completed_date,
            'payment_status' => $this->payment_status,
            'payment_type' => $this->payment_type,
            'payment_date' => $this->payment_date,
            'notes' => $this->notes,
            'is_draft' => $this->is_draft,
            'is_closed' => $this->is_closed,
            'is_hourly' => $this->is_hourly,
            'available_loads' => $this->getAcceptedLoadDetails($acceptedLoadId, auth()->user()->id),
        ];
    }

    private function getAcceptedLoadId(?int $userId): ?int
    {
        if (!$userId) {
            return null;
        }

        $isLoad = Load::where('user_id', $userId)
            ->whereIn('status', [1, 2, 3])
            ->first();

        return $isLoad ? $isLoad->id : null;
    }

    private function getAcceptedLoadDetails(?int $loadId, ?int $userId)
    {
        if (!$loadId || !$userId) {
            return null; // Return null if loadId or userId is not provided
        }

        $getLoad = Load::where('id', $loadId)
            ->where('user_id', $userId)
            ->whereIn('status', [1, 2, 3])
            ->first(); // Use first() to get a single object

        if (!$getLoad) {
            return null; // Return null if no load is found
        }

        // Convert the load object to an array
        $loadData[] = [
            'id' => $getLoad->id,
            'job_id' => $getLoad->job_id,
            'user_id' => $getLoad->user_id,
            'weight' => number_format($getLoad->weight, 2, '.', ''),
            'trucker_taken_weight' => number_format($getLoad->trucker_taken_weight, 2, '.', ''),
            'price_per_ton' => ($getLoad->weight > 0)
                ? (auth()->user()->user_type == 3
                    ? number_format($getLoad->load_cost / $getLoad->weight, 2, '.', '')
                    : number_format($getLoad->trucker_get / $getLoad->weight, 2, '.', ''))
                : '0.00',

            'load_cost' => number_format($getLoad->load_cost, 2, '.', ''),
            'cal_comission' => number_format($getLoad->cal_comission, 2, '.', ''),
            'trucker_get' => number_format($getLoad->trucker_get, 2, '.', ''),
            'min_completed_hours' => $getLoad->min_completed_hours,
            'max_completed_hours' => $getLoad->max_completed_hours,
            'reached_on' => $getLoad->reached_on,
            'started_on' => $getLoad->started_on,
            'completed_on' => $getLoad->completed_on,
            'status' => $getLoad->status,
            'cancellation_request_id' => $getLoad->cancellation_request_id,
            'is_payment_initiated' => $getLoad->is_payment_initiated,
        ];

        return $loadData; // Return the load data as an array
    }


    private function getContractorDetails(): array
    {
        return [
            'id' => $this->user?->id,
            'fname' => $this->user?->first_name,
            'lname' => $this->user?->last_name,
            'country_code' => $this->user?->country_code,
            'mobile' => (string)$this->user?->mobile_number,
            'email' => $this->user?->email,
        ];
    }

    private function getMaterialDetails(): array
    {
        return [
            'id' => $this->jobMaterial?->id,
            'name' => $this->jobMaterial?->title,
        ];
    }

    private function getEquipmentDetails(): ?array
    {
        return $this->equipment_id ? [
            'id' => $this->jobEquipment?->id,
            'name' => $this->jobEquipment?->title,
        ] : null;
    }

    private function getLoadTypeDetails(): ?array
    {
        return [
            'id' => $this->jobLoadType?->id,
            'name' => $this->jobLoadType?->title,
            'slug' => $this->jobLoadType?->slug,
        ];
    }
    private function getTruckTypeDetails($truckTypeIds)
    {
        $explodedTruckTypes = explode(',', $truckTypeIds);
        $truckTypes = TruckType::whereIn('id', $explodedTruckTypes)->get();
        $dataArray = [];

        if ($truckTypes) {
            foreach ($truckTypes as $truckType) {
                $dataArray[] = [
                    'truck_type_id' => $truckType->id,
                    'name' => $truckType->title,
                    'specs' => $truckType->specs,
                    'weight_capacity' => $truckType->weight_capacity,
                    'trucktype_image' => $truckType->image_path,
                ];
            }
        }

        return $dataArray;
    }
}
