<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Feedback;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CompletedJobs extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'load_id' => $this->id,
            'load_index' => calculateLoadIndex($this->job?->id, $this->id),
            'job_id'  => $this->job?->id,
            'unique_id' => $this->job?->unique_id,
            'source' => $this->job?->source,
            'destination' => $this->job?->destination,
            'order_no' => $this->job?->order_no,
            'material' => !is_null($this->job?->material_other) ? $this->job?->material_other : $this->job?->jobMaterial?->title,
            'completed_on' => $this->completed_on,
            'is_review_added' => $this->isReviewed($this->job?->id, $this->id),
        ];
    }

    private function isReviewed($jobId, $loadId): bool
    {
        return Feedback::where(['job_id' => $jobId, 'load_id' => $loadId, 'given_by' => auth()->user()->id])->exists();
    }
}
