<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RunningJobLoadResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'running-job-loads')) {
            $dataArray = [
                'job_id' => $this->job?->id,
                'load_id' => $this->id ?? '',
                'unique_id' => $this->job?->unique_id,
                'trucker_details' => [
                    'id' => $this->trucker?->id,
                    'fname' => $this->trucker?->first_name,
                    'lname' => $this->trucker?->last_name,
                    'country_code' => $this->trucker?->country_code,
                    'mobile' => (string)$this->trucker?->mobile_number,
                    'email' => $this->trucker?->email,
                    'image' => $this->trucker?->image_path
                ],
                'source' => $this->job?->source,
                'destination' => $this->job?->destination,
                'source_lat' => $this->job?->source_lat,
                'source_lng' => $this->job?->source_lat,
                'delivery_lat' => $this->job?->delivery_lat,
                'delivery_lng' => $this->job?->delivery_lng,
                'driver_current_lat' => $this->loadActivity?->current_lat,
                'driver_current_lng' => $this->loadActivity?->current_lng,
                'truck_type_name' => $this->trucker?->truckDetails?->truckType?->title,
                'truck_weight_capacity' => $this->trucker?->truckDetails?->truckType?->weight_capacity,
                'company_truck_no' => $this->trucker?->truckDetails?->company_truck_number,
                'truck_lic_no' => $this->trucker?->truckDetails?->truck_license_no,
                'started_on' => $this->started_on ?? '',
                'completed_on' => $this->completed_on ?? '',
                'weight' => $this->weight,
                'load_cost' => $this->load_cost,
                'trucker_taken_weight' => $this->trucker_taken_weight,
            ];
        } else if (str_contains(request()->route()->getName(), 'is-driver-started-job')) {
            $dataArray = [
                'job_id' => $this->job_id,
                'load_id' => $this->load_id,
                'unique_id' => $this->job?->unique_id,
                'status' => $this->getStatus($this->status),
                'started_on' => $this->started_on ?? '',
                'current_lat' => $this->current_lat ?? '',
                'current_lng' => $this->current_lng ?? '',
                'weight' => $this->jobLoad?->weight,
                'trucker_get' => $this->jobLoad?->trucker_get,
                'is_hourly' => $this->job?->is_hourly,
                'current_time' => now()->format('Y-m-d H:i:s'),
                'contractor_details' => [
                    'id' => $this->job?->user?->id,
                    'fname' => $this->job?->user?->first_name,
                    'lname' => $this->job?->user?->last_name,
                    'country_code' => $this->job?->user?->country_code,
                    'mobile' => (string)$this->job?->user?->mobile_number,
                    'email' => $this->job?->user?->email,
                    'image' => $this->job?->user?->image_path,
                    'company_legal_name' => $this->job?->user?->otherDetails?->company_legal_name,
                    'tax_id' => $this->job?->user?->otherDetails?->tax_id,
                    'phone_2' => $this->job?->user?->otherDetails?->phone_2,
                ],
                'job_location_info' => [
                    'source_lat' => $this->job?->source_lat,
                    'source_long' => $this->job?->source_lng,
                    'destination_lat' => $this->job?->delivery_lat,
                    'destination_long' => $this->job?->delivery_lng,
                ]
            ];
        } else {
            $dataArray = [
                'job_id' => $this->job?->id,
                'load_id' => $this->id ?? '',
                'unique_id' => $this->job?->unique_id,
                'contracter_details' => [
                    'id' => $this->job?->user?->id,
                    'fname' => $this->job?->user?->first_name,
                    'lname' => $this->job?->user?->last_name,
                    'country_code' => $this->job?->user?->country_code,
                    'mobile' => (string)$this->job?->user?->mobile_number,
                    'email' => $this->job?->user?->email,
                    'image' => $this->job?->user?->image_path
                ],
                'job_status' => $this->status,
                'source' => $this->job?->source,
                'destination' => $this->job?->destination,
                'source_lat' => $this->job?->source_lat,
                'source_lng' => $this->job?->source_lat,
                'delivery_lat' => $this->job?->delivery_lat,
                'delivery_lng' => $this->job?->delivery_lng,
                'driver_current_lat' => $this->loadActivity?->current_lat,
                'driver_current_lng' => $this->loadActivity?->current_lng,
                'truck_type_name' => $this->trucker?->truckDetails?->truckType?->title,
                'truck_weight_capacity' => $this->trucker?->truckDetails?->truckType?->weight_capacity,
                'company_truck_no' => $this->trucker?->truckDetails?->company_truck_number,
                'status' => $this->status,
                'started_on' => $this->started_on
            ];
        }
        return $dataArray;
    }

    private function getStatus($status,):String
    {
        if($status == 1){
            return 'accepted';
        } else if($status == 2){
            return 'reached';
        } else if($status == 3){
            return 'Running';
        } else if($status == 4){
            return 'Waiting_for_verification';
        } else{
            return 'cancelled';
        }
    }
}
