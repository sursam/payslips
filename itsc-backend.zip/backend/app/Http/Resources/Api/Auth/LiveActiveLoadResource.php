<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LiveActiveLoadResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'load_id' => $this->id,
            'load_index' => $this->calculateLoadIndex($this->job?->id, $this->id),
            'trucker_details' => [
                'id' => $this->trucker?->id,
                'fname' => $this->trucker?->first_name,
                'lname' => $this->trucker?->last_name,
                'country_code' => $this->trucker?->country_code,
                'mobile' => (string)$this->trucker?->mobile_number,
                'email' => $this->trucker?->email,
            ],
            'job_details' => [
                'id' => $this->job?->id,
                'user_id' => $this->job?->user_id,
                'unique_id' => $this->job?->unique_id,
                'source' => $this->job?->source,
                'destination' => $this->job?->destination,
                'pickup_date_time' => $this->job?->pickup_date_time,
                'delivery_date_time' => $this->job?->delivery_date_time,
                'source_lat' => $this->job?->source_lat,
                'source_lng' => $this->job?->source_lng,
                'destination_lat' => $this->job?->delivery_lat,
                'destination_lng' => $this->job?->delivery_lng,
                'job_status' => $this->job?->status
            ],
            
            'trucker_current_lat' => $this->loadActivity?->current_lat,
            'trucker_current_lng' => $this->loadActivity?->current_lng,
        ];
    }

    private function calculateLoadIndex($jobId, $loadId)
    {
        $allLoadsOfJob = Load::where('job_id', $jobId)
            ->orderBy('id')
            ->pluck('id')
            ->toArray();

        $loadIndexMap = array_flip($allLoadsOfJob);
        array_walk($loadIndexMap, function (&$value) {
            $value = $value + 1; // Start index from 1 instead of 0
        });

        return $loadIndexMap[$loadId] ?? null;
    }
}
