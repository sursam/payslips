<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ShowLoadActivityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'job_id' => $this->job_id,
            'load_id' => $this->id,
            'trucker_details' => [
                'id' => $this->trucker?->id,
                'fname' => $this->trucker?->first_name,
                'lname' => $this->trucker?->last_name,
                'country_code' => $this->trucker?->country_code,
                'mobile' => (string)$this->trucker?->mobile_number,
                'email' => $this->trucker?->email,
                'profile_image' => $this->trucker?->image_path,
            ],
            'challan' => $this->jobConfigureMapping?->challan_image_path,
            'signed_challan' => $this->jobConfigureMapping?->signed_challan_image_path,
            'is_ticket_signed' => $this->jobConfigureMapping?->is_ticket_signed,
            'trucker_notes' => $this->jobConfigureMapping?->trucker_notes,
            'load_actual_weight' => number_format($this->weight, 2, '.', ''), //$this->weight,
            'trucker_taken_weight' => number_format($this->trucker_taken_weight, 2, '.', ''), //$this->trucker_taken_weight,
            'contracter_name' => $this->job?->user?->first_name . ' ' . $this->job?->user?->last_name,
            'ticket_no' => $this->ticket_no ?? null
        ];
    }
}
