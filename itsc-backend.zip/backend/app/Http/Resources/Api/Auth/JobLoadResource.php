<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\User;
use App\Models\Feedback;
use Illuminate\Http\Request;
use App\Http\Resources\Api\Common\AuthResource;
use Illuminate\Http\Resources\Json\JsonResource;

class JobLoadResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'manage-job') || str_contains(request()->route()->getName(), 'pending-verification-or-cancellation-jobs') || str_contains(request()->route()->getName(), 'get-Job-loads-contractor')) {
            $dataArray = [
                'id' => $this->id,
                'load_index' => $this->load_index ?? null,
                'job_id' => $this->job_id,
                'trucker_id' => $this->user_id,
                'weight' => number_format($this->weight, 2, '.', ''),
                'contractor_added_weight' => $this->status == 4 ? number_format($this->weight, 2, '.', '') : null,
                'driver_load_weight' => number_format($this->trucker_taken_weight, 2, '.', ''),
                'price_per_ton' => auth()->user()->user_type == 3 ? number_format($this->load_cost / $this->weight, 2, '.', '') : number_format($this->load_cost / $this->weight, 2, '.', ''),
                'load_cost' => number_format($this->load_cost, 2, '.', ''),
                'cal_comission' => number_format($this->cal_comission, 2, '.', ''),
                'discounted_load_cost' => number_format($this->trucker_get, 2, '.', ''),
                'min_completed_hours' => $this->min_completed_hours,
                'max_completed_hours' => $this->max_completed_hours,
                'reached_on' => $this->reached_on,
                'started_on' => $this->started_on,
                'completed_on' => $this->completed_on,
                'status' => $this->status,
                'cancellation_request_id' => $this->cancellation_request_id,
                'feedback' => $this->getLoadRatingsAndFeedback($this->id),
                'is_discarded' => (bool)$this->is_discarded,
                'trucker_details' => $this->user_id ? [
                    'id' => $this->trucker?->id,
                    'fname' => $this->trucker?->first_name,
                    'lname' => $this->trucker?->last_name,
                    'country_code' => $this->trucker?->country_code,
                    'mobile' => (string)$this->trucker?->mobile_number,
                    'email' => $this->trucker?->email,
                    'language' => $this->trucker?->language,
                    'completed_steps' => $this->trucker?->completed_steps,
                    'user_role' => $this->trucker?->roles[0]->id,
                    'truck_type' => $this->trucker?->truckDetails?->truckType?->title ?? 'NA',
                    'truck_type_image' => $this->trucker?->truckDetails?->truckType?->image_path,
                    'weight_capacity'   => $this->trucker?->truckDetails?->truckType?->weight_capacity ?? 'NA',
                    'rating' => $this->getAverageRating($this->trucker?->id),
                    'profile_image' => $this->trucker?->image_path
                ] : null,
                'ticket_no' => $this->ticket_no,
                'pickup_date_time' => $this->job?->pickup_date_time,
                'delivery_date_time' => $this->job?->delivery_date_time,
                'is_hourly' => $this->job?->is_hourly,
                'load_spacing' => $this->job?->load_spacing_minutes,
                'pickup_latitude' => $this->job?->source_lat,
                'pickup_longitude' => $this->job?->source_lng,
                'delivery_latitude' => $this->job?->delivery_lat,
                'delivery_longitude' => $this->job?->delivery_lng,
                'load_job_status' => $this->job?->status
            ];
        } else if (str_contains(request()->route()->getName(), 'get-jobs') || str_contains(request()->route()->getName(), 'get-Job-loads-independent')) {
            $dataArray = [
                'id' => $this->id,
                'job_id' => $this->job_id,
                'trucker_id' => $this->user_id,
                'weight' => number_format($this->weight, 2, '.', ''),
                'contractor_added_weight' => $this->status == 4 ? number_format($this->weight, 2, '.', '') : null,
                'driver_load_weight' => number_format($this->trucker_taken_weight, 2, '.', ''),
                'price_per_ton' => auth()->user()->user_type == 3 ? number_format($this->trucker_get / $this->weight, 2, '.', '') : number_format($this->trucker_get / $this->weight, 2, '.', ''),
                'load_cost' => number_format($this->load_cost, 2, '.', ''),
                'cal_comission' => number_format($this->cal_comission, 2, '.', ''),
                'discounted_load_cost' => number_format($this->trucker_get, 2, '.', ''),
                'min_completed_hours' => $this->min_completed_hours,
                'max_completed_hours' => $this->max_completed_hours,
                'reached_on' => $this->reached_on,
                'started_on' => $this->started_on,
                'completed_on' => $this->completed_on,
                'status' => $this->status,
                'cancellation_request_id' => $this->cancellation_request_id,
                'feedback' => $this->getLoadRatingsAndFeedback($this->id),
                'is_discarded' => (bool)$this->is_discarded,
                'trucker_details' => $this->user_id ? [
                    'id' => $this->trucker?->id,
                    'fname' => $this->trucker?->first_name,
                    'lname' => $this->trucker?->last_name,
                    'country_code' => $this->trucker?->country_code,
                    'mobile' => (string)$this->trucker?->mobile_number,
                    'email' => $this->trucker?->email,
                    'language' => $this->trucker?->language,
                    'completed_steps' => $this->trucker?->completed_steps,
                    'user_role' => $this->trucker?->roles[0]->id,
                    'truck_type' => $this->trucker?->truckDetails?->truckType?->title ?? 'NA',
                    'weight_capacity'   => $this->trucker?->truckDetails?->truckType?->weight_capacity ?? 'NA',
                    'profile_image' => $this->trucker?->image_path
                ] : null,
                'ticket_no' => $this->ticket_no,
                'pickup_date_time' => $this->job?->pickup_date_time,
                'delivery_date_time' => $this->job?->delivery_date_time,
                'is_hourly' => $this->job?->is_hourly,
                'load_spacing' => $this->job?->load_spacing_minutes
            ];
        } else if (str_contains(request()->route()->getName(), 'get-paid-load-details') || str_contains(request()->route()->getName(), 'initiate-payment')) {
            $dataArray = [
                'id' => $this->id,
                'unique_id' => $this->job?->unique_id,
                'load_index' => calculateLoadIndex($this->job_id, $this->id) ?? null,
                'weight' => number_format($this->weight, 2, '.', ''),
                'job_id' => $this->job_id,
                'load_cost' => number_format($this->load_cost, 2, '.', ''),
                'status' => $this->status,
            ];
        } else {
            $dataArray = [
                'id' => $this->id,
                'job_id' => $this->job_id,
                'trucker_id' => $this->user_id,
                'weight' => number_format($this->weight, 2, '.', ''),
                'contractor_added_weight' => number_format($this->weight, 2, '.', ''),
                'driver_load_weight' => number_format($this->trucker_taken_weight, 2, '.', ''),
                'price_per_ton' => auth()->user()->user_type == 3 ? number_format($this->load_cost / $this->weight, 2, '.', '') : number_format($this->trucker_get / $this->weight, 2, '.', ''),
                'load_cost' => number_format($this->load_cost, 2, '.', ''),
                'cal_comission' => number_format($this->cal_comission, 2, '.', ''),
                'discounted_load_cost' => number_format($this->trucker_get, 2, '.', ''),
                'min_completed_hours' => $this->min_completed_hours,
                'max_completed_hours' => $this->max_completed_hours,
                'reached_on' => $this->reached_on,
                'started_on' => $this->started_on,
                'completed_on' => $this->completed_on,
                'status' => $this->status,
                'cancellation_request_id' => $this->cancellation_request_id,
                'feedback' => $this->getLoadRatingsAndFeedback($this->id),
                'is_discarded' => (bool)$this->is_discarded,
                'trucker_details' => $this->user_id ? [
                    'id' => $this->trucker?->id,
                    'fname' => $this->trucker?->first_name,
                    'lname' => $this->trucker?->last_name,
                    'country_code' => $this->trucker?->country_code,
                    'mobile' => (string)$this->trucker?->mobile_number,
                    'email' => $this->trucker?->email,
                    'language' => $this->trucker?->language,
                    'completed_steps' => $this->trucker?->completed_steps,
                    'user_role' => $this->trucker?->roles[0]->id,
                    'truck_type' => $this->trucker?->truckDetails?->truckType?->title ?? 'NA',
                    'weight_capacity'   => $this->trucker?->truckDetails?->truckType?->weight_capacity ?? 'NA',
                    'profile_image' => $this->trucker?->image_path
                ] : null,
                'ticket_no' => $this->ticket_no,
                'pickup_date_time' => $this->job?->pickup_date_time,
                'delivery_date_time' => $this->job?->delivery_date_time,
                'is_hourly' => $this->job?->is_hourly,
                'load_spacing' => $this->job?->load_spacing_minutes,
                'load_job_status' => $this->job?->status
            ];
        }
        return $dataArray;
    }

    private function getTrucker($userId)
    {
        $isUser = User::find($userId);
        return $isUser;
    }
    private function getLoadRatingsAndFeedback($loadId)
    {
        $isFeedback = Feedback::where(['load_id' => $loadId])->whereIn('given_by', getSubContractorWithMainContractorIds(auth()->user()->id))->first();
        if ($isFeedback) {
            return [
                'comment' => $isFeedback->comment,
                'rating' => number_format($isFeedback->rating, 2, '.', ''),
            ];
        }
        return null;
    }
    private function getAverageRating($userId)
    {
        return Feedback::where('given_to', $userId)->avg('rating');
    }
}
