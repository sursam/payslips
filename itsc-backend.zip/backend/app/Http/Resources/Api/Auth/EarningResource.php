<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use App\Models\Earning;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EarningResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'job_id' => $this->job_id ?? '',
            'unique_id' => $this->job?->unique_id ?? '',
            'load_id' => $this->load_id ?? '',
            'amount' => number_format($this->amount, 2, '.', ''),
            'type' => $this->type,
            'remarks' => $this->remarks,
            'is_paid' => $this->is_paid,
            // 'is_load_cancelled' => $this->isJobLoadCompletedOrCancelled($this->load_id),
            'created_at' => $this->created_at
        ];
    }


    // private function isJobLoadCompletedOrCancelled($load_id)
    // {
    //     $isLoad = Load::find($load_id);
    //     $isDebitedEarning = Earning::where(['load_id' => $load_id, 'use' 'type' => 2])->exists();
    //     $isCreatedEarning = Earning::where(['load_id' => $load_id, 'type' => 1])->exists();
    //     if(!$isLoad){
    //         return true;
    //     } else if($isLoad->user_id != auth()->user()->id){
    //         return true;
    //     } else if($isLoad->user_id != auth()->user()->id){
    //         return true;
    //     } else if($isDebitedEarning && $isLoad->user_id == auth()->user()->id){
    //         return true;
    //     } else if($isDebitedEarning && $isLoad->user_id != auth()->user()->id){
    //         return true;
    //     } else if($isCreatedEarning && $isLoad->user_id == auth()->user()->id){
    //         return false;
    //     } else {
    //         return false;
    //     }
        
    // }
}
