<?php

namespace App\Http\Resources\Api\Auth;

use App\Models\Load;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TruckerPayoutActivityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'transfer_id' => $this->transfer_id,
            'payout_id' => $this->payout_id,
            'amount' => number_format($this->amount, 2, '.', ''),
            'currency' => $this->currency,
            'status' => $this->status,
            'payout_date' => $this->payout_date,
            'description' => $this->description,
            'payment_method' => $this->payment_method,
            'payment_based_on' => $this->payment_from_date,
            'payment_based_to' => $this->payment_to_date,
            'load_details' => $this->getLoadDetails($this->load_ids)
        ];
    }
    // private function getLoadDetails(?string $loadIds): array
    // {
    //     if (empty($loadIds)) {
    //         return [];
    //     }

    //     $explodedLoads = array_filter(explode(',', $loadIds));

    //     if (empty($explodedLoads)) {
    //         return [];
    //     }

    //     $loads = Load::with('job')->whereIn('id', $explodedLoads)->where('status', 4)->get();

    //     return $loads->map(function ($load) {
    //         return [
    //             'load_id' => $load->id,
    //             'job_id' => $load->job?->id,
    //             'job_unique_id' => $load->job?->unique_id,
    //             'weight' => number_format($load->weight, 2, '.', ''),
    //             'trucker_taken_weight' => number_format($load->trucker_taken_weight, 2, '.', ''),
    //             'load_cost' => number_format($load->load_cost, 2, '.', ''),
    //             'trucker_get' => number_format($load->trucker_get, 2, '.', ''),
    //         ];
    //     })->toArray();
    // }

    private function getLoadDetails(?string $loadIds): array
    {
        if (empty($loadIds)) {
            return [];
        }

        $explodedLoads = array_filter(explode(',', $loadIds));

        if (empty($explodedLoads)) {
            return [];
        }

        $loads = Load::with('job')->whereIn('id', $explodedLoads)->where('status', 4)->get();

        // Group loads by job_id to calculate indexes efficiently
        $loadsByJob = $loads->groupBy('job_id');
        $loadIndexMaps = [];

        // Create index maps for each job
        foreach ($loadsByJob as $jobId => $jobLoads) {
            $allLoadsOfJob = Load::where('job_id', $jobId)
                ->orderBy('id')
                ->pluck('id')
                ->toArray();

            $loadIndexMap = array_flip($allLoadsOfJob);
            array_walk($loadIndexMap, function (&$value, $key) {
                $value = $value + 1; // Start from 1 instead of 0
            });

            $loadIndexMaps[$jobId] = $loadIndexMap;
        }

        return $loads->map(function ($load) use ($loadIndexMaps) {
            return [
                'load_id' => $load->id,
                'job_id' => $load->job?->id,
                'job_unique_id' => $load->job?->unique_id,
                'weight' => number_format($load->weight, 2, '.', ''),
                'trucker_taken_weight' => number_format($load->trucker_taken_weight, 2, '.', ''),
                'load_cost' => number_format($load->load_cost, 2, '.', ''),
                'trucker_get' => number_format($load->trucker_get, 2, '.', ''),
                'load_index' => $loadIndexMaps[$load->job_id][$load->id] ?? null,
            ];
        })->toArray();
    }
}
