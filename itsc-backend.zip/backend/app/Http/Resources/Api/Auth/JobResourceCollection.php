<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use App\Http\Resources\Api\Auth\JobResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class JobResourceCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @return array<int|string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
		    'status' => true,
			'message'=>'Job Found Successfully',
			'data' => JobResource::collection($this->collection),
			'pagination' => [
				'total' => $this->total(),
				'count' => $this->count(),
				'per_page' => $this->perPage(),
				'current_page' => $this->currentPage(),
				'total_pages' => $this->lastPage(),
				'next_page' => $this->nextPageUrl()
			],
		];
    }
    public function withResponse($request, $response)
    {
        $jsonResponse = json_decode($response->getContent(), true);
        unset($jsonResponse['links'],$jsonResponse['meta']);
        $response->setContent(json_encode($jsonResponse));
    }
}
