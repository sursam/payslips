<?php

namespace App\Http\Resources\Api\Auth;

// use App\Http\Resources\Api\Common\LoadResourceCollection;
// use App\Models\Load;
// use App\Models\TruckType;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $dataArray = [
            // 'id' => $this->->id,
            'uuid' => $this->uuid,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'country_code' => $this->country_code,
            'mobile' => (string)$this->mobile_number,
            'dob' => $this->dob,
            'state' => [
                // 'id' => $this->stateDetails?->id,
                'name' => $this->stateDetails?->name,
                'slug' => $this->stateDetails?->slug,
                'country_id' => $this->stateDetails?->country_id,
                'country_code' => $this->stateDetails?->country_code,
                'iso2' => $this->stateDetails?->iso2,
                'status' => $this->stateDetails?->status,
            ],
            'city' => [
                // "id" => $this->stateDetails?->id,
                "name" => $this->cityDetails?->name,
                "slug" => $this->cityDetails?->slug,
                "state_id" => $this->cityDetails?->state_id,
                "state_code" => $this->cityDetails?->state_code,
                "country_id" => $this->cityDetails?->country_id,
                "country_code" => $this->cityDetails?->country_code,
                "latitude" => $this->cityDetails?->latitude,
                "longitude" => $this->cityDetails?->longitude,
                "status" => $this->cityDetails?->status,
            ],
            'created_at' => $this->created_at,
        ];
        return $dataArray;
    }

}
