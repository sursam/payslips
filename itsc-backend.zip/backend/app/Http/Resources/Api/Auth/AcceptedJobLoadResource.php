<?php

namespace App\Http\Resources\Api\Auth;

use App\Http\Resources\Api\Common\AuthResource;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AcceptedJobLoadResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'job_id' => $this->job_id,
            'token_id' => $this->jobConfigureMapping?->token,
            'loadtype' => $this->job?->load_type_id,
            'weight' => number_format($this->weight,2, '.', ''),
            'jobloadcost' => number_format($this->load_cost,2, '.', ''), 
            'startdatetime' => $this->started_on,
            'enddatetime' => $this->completed_on,
            'discounted_load_price' => number_format($this->trucker_get,2, '.', ''), 
            'status' => $this->getLoadStatus($this->status, $this->started_on),
            'driver_current_lat' => $this->loadActivity?->current_lat,
            'driver_current_long' => $this->loadActivity?->current_lng,
            'contractor_details' => new AuthResource($this->job->user),
            'is_hourly' => $this->job?->is_hourly,
            'current_time' => date('Y-m-d H:i:s'),
            'job_pickup_date_time' => $this->job?->pickup_date_time,
            'job_delivery_date_time' => $this->job?->delivery_date_time,
            'job_load_spacing_minutes' => number_format($this->job?->load_spacing_minutes, 2, '.', ''),
            'job_location_info' => [
                'source_lat' => $this->job->source_lat,
                'source_long' => $this->job->source_lng,
                'destination_lat' => $this->job->delivery_lat,
                'destination_long' => $this->job->delivery_lng,
            ],
            'cancellation_request_id' => $this->cancellation_request_id
        ];
    }

    private function getLoadStatus($status, $data = null) : string
    {
        if($status == 1){
            return 'Accepted';
        }elseif($status == 2 && $data == null){
            return 'Reached';
        }elseif($status == 2 && $data != null){
            return 'Running';
        }elseif($status == 3){
            return 'Waiting_for_verification';
        }else{
            return 'Completed';
        }
    }
}
