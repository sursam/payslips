<?php

namespace App\Http\Resources\Api\Auth;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RatingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (str_contains(request()->route()->getName(), 'my-reviews')) {
            $dataArray = [
                'job_id' => $this->job_id,
                'load_id' => $this->load_id,
                'load_index' => calculateLoadIndex($this->job_id, $this->load_id),
                'job_unique_id' => $this->jobDetails?->unique_id,
                'rating' => number_format($this->rating, 1, '.', ''), //$this->rating,
                'feedback' => $this->comment,
                'given_contractor' => [
                    'id' => $this->givenByUser?->id,
                    'fname' => $this->givenByUser?->first_name,
                    'lname' => $this->givenByUser?->last_name,
                    'country_code' => $this->givenByUser?->country_code,
                    'mobile' => (string)$this->givenByUser?->mobile_number,
                    'email' => $this->givenByUser?->email,
                    'profile_image' => $this->givenByUser?->image_path,
                ],
                'created_at' => $this->created_at,
            ];
        }else{
            
            $dataArray = [
                'job_id' => $this->job_id,
                'load_id' => $this->load_id,
                'job_unique_id' => $this->jobDetails?->unique_id,
                'rating' => number_format($this->rating, 1, '.', ''), //$this->rating,
                'feedback' => $this->comment,
                'given_trucker' => [
                    'id' => $this->givenByUser?->id,
                    'fname' => $this->givenByUser?->first_name,
                    'lname' => $this->givenByUser?->last_name,
                    'country_code' => $this->givenByUser?->country_code,
                    'mobile' => (string)$this->givenByUser?->mobile_number,
                    'email' => $this->givenByUser?->email,
                    'profile_image' => $this->givenByUser?->image_path,
                ],
                'created_at' => $this->created_at,
            ];
        }
        return $dataArray;
    }
}
