<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class FrontendGuardMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Check if the user is authenticated using the 'frontend' guard
        if (!Auth::guard('frontend')->check()) {
            // Redirect to the login page if not authenticated
            return redirect()->route('home'); // Adjust the route name as necessary
        }

        return $next($request); // Proceed to the next middleware or request
    }
}
