<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class NotificationMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Check if the request is for a specific route
        if (request()->route()->getName() == 'accept-load') {
            // Get the authenticated user
            // $data = [
            //     'title' => 'Accept Load',
            //     'user_id' => auth()->user()->id,
            //     'job_id' => $request->job_id,
            //     'description' => ''

            // ]
        }
        return $next($request);
    }
}
