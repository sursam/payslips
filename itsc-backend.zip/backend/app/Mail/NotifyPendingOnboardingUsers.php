<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Log;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyPendingOnboardingUsers extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public $subject;    
    public $username;
    public $content;

    public function __construct($username, $content, $subject)
    {
        $this->username = $username;
        $this->content = $content;
        $this->subject = $subject;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subject,
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.notifyPendingOnboardingUsers', // Update this to your actual view path
            with: [
                'username' => $this->username,
                'content' => $this->content,
                'subject' => $this->subject,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }

    public function failed(\Throwable $exception): void
    {
        // Log the failure
        Log::error('Failed to send onboarding email', [
            'username' => $this->username,
            'subject' => $this->subject,
            'error' => $exception->getMessage()
        ]);

        // Optional: Notify administrators or retry logic
        // You could also store failed emails in database for later retry
    }
}
