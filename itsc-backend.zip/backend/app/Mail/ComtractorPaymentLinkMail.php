<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ComtractorPaymentLinkMail extends Mailable
{
    use Queueable, SerializesModels;

    public $subject;    
    public $username;
    public $content;
    public $paymentLink;
    public $dateRange;
    /**
     * Create a new message instance.
     */
    public function __construct($username, $content, $subject, $paymentLink, $dateRange)
    {
        $this->username = $username;
        $this->content = $content;
        $this->subject = $subject;
        $this->paymentLink = $paymentLink;
        $this->dateRange = $dateRange;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subject,
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.contractorPaymentInvitationLink', // Update this to your actual view path
            with: [
                'username' => $this->username,
                'content' => $this->content,
                'paymentLink' => $this->paymentLink,
                'dateRange' => $this->dateRange
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
