<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserTruck extends Model
{
    use HasFactory;

    protected $guarded = [];
    public function getImagePathAttribute()
    {
        $filePath = 'storage/user_truck/' . $this->image;
        if (!$this->image || !file_exists(public_path($filePath))) {
            return asset('assets/media/avatars/300-10.jpg');
        }
        return asset($filePath);
    }

    // relations
    public function truckType():BelongsTo
    {
        return $this->belongsTo(TruckType::class);
    }

    public function user():BelongsTo
    {
        return $this->belongsTo(User::class,'user_id');
    }
}
