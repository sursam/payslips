<?php

namespace App\Models;

use App\Models\Job;
use App\Models\User;
use App\Models\UserTruck;
use App\Models\LoadActivity;
use App\Models\JobConfigureMap;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Load extends Model
{
    use HasFactory;
    protected $guarded = [];



    // relations
    public function trucker(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function job(): BelongsTo
    {
        return $this->belongsTo(Job::class);
    }

    public function userTruckDetails():BelongsTo
    {
        return $this->belongsTo(UserTruck::class,'user_id','user_id');
    }

    public function userDetails():BelongsTo
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function jobConfigureMapping():HasOne
    {
        return $this->hasOne(JobConfigureMap::class);
    }
    public function loadActivity(): HasOne
    {
        return $this->hasOne(LoadActivity::class);
    }

}
