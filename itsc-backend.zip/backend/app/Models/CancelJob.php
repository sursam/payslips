<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CancelJob extends Model
{
    use HasFactory,SoftDeletes;
    protected $guarded = [];

    public function job()
    {
        return $this->belongsTo(Job::class);
    }

    public function truckerDetails(){
        return $this->belongsTo(User::class,'trucker_id');
    }
    public function loadDetails()
    {
        return $this->belongsTo(Load::class,'load_id');
    }


}
