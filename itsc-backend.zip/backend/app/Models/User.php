<?php

namespace App\Models;

use App\Models\Earning;
use Webpatser\Uuid\Uuid;
use App\Scopes\ActiveScope;
use Faker\Provider\ar_EG\Payment;
use Laravel\Passport\HasApiTokens;
use App\Traits\HasRolesAndPermissions;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRolesAndPermissions;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
        self::softDeleted(function ($model) {
            $model->email = $model->mobile_number.'-'.$model->email.'-'.time();
            $model->mobile_number = time();
            $model->update();
        });
        static::addGlobalScope(new ActiveScope);
    }
    protected $appends = ['image_path'];
    protected $guarded  = [];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];
    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
    public function getImagePathAttribute()
    {
        $filePath = 'storage/profile/' . $this->profile_image;
        if (!$this->profile_image || !file_exists(public_path($filePath))) {
            return asset('assets/media/avatars/300-10.jpg');
        }
        return asset($filePath);
    }


    // relations
    public function otherDetails(): HasOne
    {
        return $this->hasOne(Profile::class);
    }
    public function truckDetails(): HasOne
    {
        return $this->hasOne(UserTruck::class);
    }
    public function paypalCredentials(): HasOne
    {
        return $this->hasOne(PaypalCredential::class);
    }

    public function stateDetails()
    {
        return $this->belongsTo(State::class, 'state_id');
    }

    public function cityDetails()
    {
        return $this->belongsTo(City::class, 'city_id');
    }

    public function role()
    {
        return $this?->roles?->first()?->name;
    }

    public function roleSlug()
    {
        return $this?->roles?->first()?->slug;
    }

    public function emailChangeLog()
    {
        return $this->hasMany(UserEmail::class);
    }

    public function completeLoadAsDriver()
    {
        return $this->hasMany(Load::class, 'user_id')->where('status', 4);
    }

    public function SubmittedJob()
    {
        return $this->hasMany(Job::class, 'user_id')->where('status', 1);
    }

    public function CompletedJob()
    {
        return $this->hasMany(Job::class, 'user_id')->where('status', 3);
    }
    public function CompletedAndClosedJob()
    {
        return $this->hasMany(Job::class, 'user_id')->where('status', 3)->orWhere('status', 6)->where('user_id', $this->id);
    }

    public function paymentTerms(): HasOne
    {
        return $this->hasOne(PaymentTerms::class);
    }
    public function earnings()
    {
        return $this->hasMany(Earning::class);
    }

    public function activeLoads()
    {
        return $this->hasMany(Load::class, 'user_id')->where('status', 1);
    }

    public function activeJobs()
    {
        return $this->hasMany(Job::class, 'user_id')->where('status', 1);
    }
}
