<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class District extends Model
{
    use HasFactory;

    protected $table = 'district';

    protected $fillable = [
        'dist_state',
        'dist_name',
        'dist_id',
    ];

    public $timestamps = false; // Assuming you don't have created_at and updated_at columns
}
