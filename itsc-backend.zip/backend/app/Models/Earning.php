<?php

namespace App\Models;

use App\Models\Job;
use App\Models\Load;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Earning extends Model
{
    use HasFactory,SoftDeletes;
    protected $guarded = [];



    // relations
    public function trucker():BelongsTo
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function job():BelongsTo
    {
        return $this->belongsTo(Job::class,'job_id');
    }
    public function jobLoad():BelongsTo
    {
        return $this->belongsTo(Load::class,'load_id');
    }
}
