<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;



class JobComission extends Model
{
    use HasFactory, SoftDeletes;
    protected $guarded = [];


    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function state()
    {
        return $this->belongsTo(State::class,'state_id');
    }

    public function city()
    {
        return $this->belongsTo(City::class,'city_id');
    }

    public function truckTypeIds()
    {
        // Check if truck_type_ids is not empty or null
        if (empty($this->truck_type_ids)) {
            return null; // Return null if it's empty
        }

        // Explode the string into an array
        $data1 = explode(',', $this->truck_type_ids);

        // Return the array
        return $data1 ?? null;
    }

    public function truck_type_names()
    {
        if($this->truckTypeIds() != null){
           return implode(',', TruckType::whereIn('id', $this->truckTypeIds())->pluck('title')->toarray()) ?? '--';
        }else{
            return '--';
        }

    }
}
