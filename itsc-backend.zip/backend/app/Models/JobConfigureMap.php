<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobConfigureMap extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $appends = ['challan_image_path','signature_image_path','signed_challan_image_path'];



    public function getChallanImagePathAttribute()
    {
        $filePath = 'storage/challan/' . $this->challan;
        if (!$this->challan || !file_exists(public_path($filePath))) {
            return null;
        }
        return asset($filePath);
    }
    public function getSignedChallanImagePathAttribute()
    {
        $filePath = 'storage/challan/' . $this->challan_on_delivery;
        if (!$this->challan_on_delivery || !file_exists(public_path($filePath))) {
            return null;
        }
        return asset($filePath);
    }
    public function getSignatureImagePathAttribute()
    {
        $filePath = 'storage/signature/' . $this->signature;
        if (!$this->signature || !file_exists(public_path($filePath))) {
            return null;
        }
        return asset($filePath);
    }
    public function getFinalReceiptImagePathAttribute()
    {
        $filePath = 'storage/invoice/' . $this->invoice;
        if (!$this->invoice || !file_exists(public_path($filePath))) {
            return null;
        }
        return asset($filePath);
    }
    public function getInvoicePathAttribute()
    {
        $filePath = 'storage/invoice/' . $this->invoice;
        if (!$this->invoice || !file_exists(public_path($filePath))) {
            return null;
        }
        return asset($filePath);
    }

    public function job()
    {
        return $this->belongsTo(Job::class, 'job_id');
    }

}
