<?php

namespace App\Models;

use App\Models\Load;
use App\Models\User;
use App\Models\LoadType;
use App\Models\Material;
use App\Models\Equipment;
use App\Models\TruckType;
use App\Models\JobActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rules\Unique;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Job extends Model
{
    use HasFactory;
    public static function boot()
    {
        parent::boot();

        self::creating(function ($model) {
            // Get the last unique_id from the database
            $lastId = self::orderBy('id', 'desc')
                ->value('id');

            // Extract the numeric part and increment it
            if ($lastId) {
                $lastNumber = (int) $lastId; // Get the number after '#CAL'
                $newNumber = $lastNumber + 1;
            } else {
                $newNumber = 1; // Start from 1 if no records exist
            }

            // Format the new unique_id
            $model->unique_id = '#CAL' . str_pad($newNumber, 2, '0', STR_PAD_LEFT);
        });
    }

    protected $guarded  = [];



    // relations
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function jobLoad(): HasMany
    {
        return $this->hasMany(Load::class);
    }
    public function jobMaterial(): BelongsTo
    {
        return $this->belongsTo(Material::class, 'material_id');
    }
    public function jobEquipment(): BelongsTo
    {
        return $this->belongsTo(Equipment::class, 'equipment_id');
    }
    public function jobLoadType(): BelongsTo
    {
        return $this->belongsTo(LoadType::class, 'load_type_id');
    }
    public function jobActivity(): HasMany
    {
        return $this->hasMany(JobActivity::class, 'job_id');
    }

    public function totalLoad()
    {
        return $this->jobLoad->count();
    }

    public function runningJobLoad(): HasMany
    {
        return $this->hasMany(Load::class)->where('status', 2);
    }

    public function hasRunningJobLoad(): bool
    {
        return $this->runningJobLoad()->exists();
    }

    public function JobPosted()
    {
        return $this->belongsTo(User::class, 'posted_by');
    }

    public function truckTypeIds()
    {
        return explode(',', $this->truck_type_ids);
    }
    public function truck_type_names()
    {
        return implode(',', TruckType::whereIn('id', $this->truckTypeIds())->pluck('title')->toarray());
    }

    public function acceptedJobLoad(): HasMany
    {
        return $this->hasMany(Load::class)->where('status', 4);
    }
}
