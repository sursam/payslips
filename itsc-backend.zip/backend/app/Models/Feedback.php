<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Feedback extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function userDetails()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function jobDetails()
    {
        return $this->belongsTo(Job::class,'job_id');
    }

    public function loadDetails()
    {
        return $this->belongsTo(Load::class,'load_id');
    }
    public function givenByUser():BelongsTo
    {
        return $this->belongsTo(User::class,'given_by');
    }
    public function givenToUser():BelongsTo
    {
        return $this->belongsTo(User::class,'given_to');
    }


}
