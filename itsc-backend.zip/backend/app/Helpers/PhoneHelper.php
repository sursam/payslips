<?php

namespace App\Helpers;

class PhoneHelper
{
    public static function formatPhoneNumber($number)
    {
        // Remove non-numeric characters
        $digits = preg_replace('/\D/', '', $number);

        // Check if the number has 10 digits
        if (strlen($digits) == 10) {
            return sprintf('%s-%s-%s', substr($digits, 0, 3), substr($digits, 3, 3), substr($digits, 6, 4));
        } else {
            return 'Invalid number';
        }
    }
}
