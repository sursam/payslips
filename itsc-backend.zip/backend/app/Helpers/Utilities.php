<?php

use App\Models\Load;
use App\Models\Role;
use App\Models\User;
use App\Models\TruckType;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

if (!function_exists('isSluggable')) {
    function isSluggable($value)
    {
        return Str::slug($value);
    }
}

if (!function_exists('pageLimit')) {
    function pageLimit($limit = NULL)
    {
        if (is_null($limit)) {
            $limitCount = 10;
        } else {
            $limitCount = $limit;
        }
        return $limitCount;
    }
}

if (!function_exists('sidebarOpen')) {
    function sidebarOpen($routes = [])
    {
        $currRoute = Route::currentRouteName();
        $open = false;
        foreach ($routes as $route) {
            if (str_contains($route, '*')) {
                if (str_contains($currRoute, substr($route, 0, strpos($route, '*')))) {
                    $open = true;
                    break;
                }
            } else {
                if ($currRoute === $route) {
                    $open = true;
                    break;
                }
            }
        }
        return $open ? 'show' : '';
    }
}

if (!function_exists('sidebarActive')) {
    function sidebarActive($routes = [])
    {
        $currRoute = Route::currentRouteName();
        $open = false;
        foreach ($routes as $route) {
            if (str_contains($route, '*')) {
                if (str_contains($currRoute, substr($route, 0, strpos($route, '*')))) {
                    $open = true;
                    break;
                }
            } else {
                if ($currRoute === $route) {
                    $open = true;
                    break;
                }
            }
        }
        return $open ? 'active' : '';
    }
}

if (!function_exists('get_content')) {
    function get_content($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        ob_start();
        curl_exec($ch);
        curl_close($ch);
        $string = ob_get_contents();
        ob_end_clean();
        return $string;
    }
}

if (!function_exists('isMobileDevice')) {
    function isMobileDevice()
    {
        return preg_match(
            "/(android|avantgo|blackberry|bolt|boost|cricket|docomo
                            |fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",
            $_SERVER["HTTP_USER_AGENT"]
        );
    }
}

if (!function_exists('getStatusName')) {
    function getStatusName($status)
    {
        $returnData = "In Active";
        if ($status == 1) {
            $returnData = "Active";
        } else if ($status == 3) {
            $returnData = "Deleted";
        } else if ($status == 4) {
            $returnData = "Drafted";
        }
        return $returnData;
    }
}

if (!function_exists('getDayNumber')) {
    function getDayNumber($dayName)
    {
        $days = ["sunday" => 1, "monday" => 2, "tuesday" => 3, "wednesday" => 4, "thursday" => 5, "friday" => 6, "saturday" => 7];
        $currentDay = $days[$dayName];
        return $currentDay;
    }
}

if (!function_exists('uuidtoid')) {
    function uuidtoid($uuid, $table)
    {
        $dbDetails = DB::table($table)
            ->select('id')
            ->where('uuid', $uuid)->first();

        if ($dbDetails) {
            return $dbDetails->id;
        } else {
            abort(404);
        }
    }
}

if (!function_exists('idtouuid')) {
    function idtouuid($id, $table)
    {
        $dbDetails = DB::table($table)
            ->select('uuid')
            ->where('id', $id)->first();

        if ($dbDetails) {
            return $dbDetails->uuid;
        } else {
            abort(404);
        }
    }
}

if (!function_exists('safe_b64encode')) {
    function safe_b64encode($string)
    {
        $pretoken = "";
        $posttoken = "";

        $codealphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codealphabet .= "abcdefghijklmnopqrstuvwxyz";
        $codealphabet .= "0123456789";
        $max = strlen($codealphabet); // edited

        for ($i = 0; $i < 3; $i++) {
            $pretoken .= $codealphabet[rand(0, $max - 1)];
        }

        for ($i = 0; $i < 3; $i++) {
            $posttoken .= $codealphabet[rand(0, $max - 1)];
        }

        $string = $pretoken . $string . $posttoken;
        $data = base64_encode($string);
        $data = str_replace(array('+', '/', '='), array('-', '_', ''), $data);
        return $data;
    }
}

if (!function_exists('safe_b64decode')) {
    function safe_b64decode($string)
    {
        $data = str_replace(array('-', '_'), array('+', '/'), $string);
        $mod4 = strlen($data) % 4;
        if ($mod4) {
            $data .= substr('====', $mod4);
        }

        $data = base64_decode($data);
        $data = substr($data, 3);
        $data = substr($data, 0, -3);

        return $data;
    }
}

if (!function_exists('human_date')) {
    function human_date($date)
    {
        $now = Carbon::now();
        $date = Carbon::parse($date);
        return $date->diffForHumans($now);
    }
}

if (!function_exists('getCurrency')) {
    function getCurrency()
    {
        return '₹ ';
    }
}

if (!function_exists('generateOtp')) {
    function generateOtp($digit = 4)
    {
        $generator = "1357902468";
        $result = "";
        for ($i = 1; $i <= $digit; $i++) {
            $result .= substr($generator, (rand() % (strlen($generator))), 1);
        }
        return $result;
    }
}


if (!function_exists('getRoles')) {
    function getRoles()
    {
        $data = Role::where('is_active', 1)->whereNotIn('slug', ['super-admin'])->get();
        return $data;
    }
}
if (!function_exists('calculateMiles')) {
    function calculateMiles($lat1, $lng1, $lat2, $lng2)
    {
        $theta      = $lng1 - $lng2;
        $dist       = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist       = acos($dist);
        $dist       = rad2deg($dist);
        $miles      = $dist * 60 * 1.1515;
        $totalMiles = round($miles, 2);
        return $totalMiles;
    }
}
if (!function_exists('getTruckTypeIds')) {
    function getTruckTypeIds($truckTypeIds)
    {
        $explodedTruckTypes = explode(',', $truckTypeIds);
        $truckTypes = TruckType::whereIn('id', $explodedTruckTypes)->pluck('id');
        return $truckTypes;
    }
}
if (!function_exists('getVideoCode')) {
    function getVideoCode($url)
    {
        if (str_contains($url, '?v=')) {
            parse_str(parse_url($url, PHP_URL_QUERY), $my_array_of_vars);
            return $my_array_of_vars['v'];
        } else {
            parse_str(parse_url($url, PHP_URL_PATH), $my_array_of_vars);
            return preg_replace('/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s', '', array_keys($my_array_of_vars)[0]);
        }
    }
}
if(!function_exists('calculateLoadIndex')) {
    function calculateLoadIndex($jobId, $loadId)
    {
        $allLoadsOfJob = Load::where('job_id', $jobId)
            ->orderBy('id')
            ->pluck('id')
            ->toArray();

        $loadIndexMap = array_flip($allLoadsOfJob);
        array_walk($loadIndexMap, function (&$value) {
            $value = $value + 1; 
        });

        return $loadIndexMap[$loadId] ?? null;
    }
}
if (!function_exists('getLoadPositionsString')) {
    function getLoadPositionsString(int $jobId, array $loadIds): string
    {
        // Get all loads for the job, ordered by id
        $allLoads = Load::where('job_id', $jobId)
            ->orderBy('id')
            ->pluck('id')
            ->toArray();

        // Map load ID => position (1-based)
        $loadPositions = array_flip($allLoads);
        array_walk($loadPositions, function (&$pos) {
            $pos = $pos + 1;
        });

        // For each requested load ID, get its position if exists
        $positions = [];
        foreach ($loadIds as $loadId) {
            if (isset($loadPositions[$loadId])) {
                $positions[] = 'Load ' . $loadPositions[$loadId];
            }
        }

        // Return as comma-separated string
        return implode(', ', $positions);
    }
}
if (!function_exists('getJobAndLoadPositions')) {
    function getJobAndLoadPositions(array $jobIds, array $loadIds): array
    {
        if (empty($jobIds) || empty($loadIds)) {
            return [];
        }

        // Fetch all loads for the given jobs with job relation
        $loads = Load::with('job:id,unique_id')
            ->whereIn('job_id', $jobIds)
            ->whereIn('id', $loadIds)
            ->orderBy('job_id')
            ->orderBy('id')
            ->get();

        if ($loads->isEmpty()) {
            return [];
        }

        // Group loads by job_id
        $loadsByJob = $loads->groupBy('job_id');

        // Get all loads for each job to calculate positions
        $allLoadsByJob = Load::whereIn('job_id', $jobIds)
            ->orderBy('job_id')
            ->orderBy('id')
            ->get()
            ->groupBy('job_id');

        $result = [];

        foreach ($loadsByJob as $jobId => $jobLoads) {
            // Get all load IDs for this job (ordered)
            $allLoadsForJob = $allLoadsByJob->get($jobId);
            
            if (!$allLoadsForJob) {
                continue;
            }

            $allLoadIds = $allLoadsForJob->pluck('id')->toArray();
            
            // Map load ID => position (1-based)
            $loadPositions = array_flip($allLoadIds);
            array_walk($loadPositions, function (&$pos) {
                $pos = $pos + 1;
            });

            // Get positions for requested loads
            $positions = [];
            foreach ($jobLoads as $load) {
                if (isset($loadPositions[$load->id])) {
                    $positions[] = 'Load ' . $loadPositions[$load->id];
                }
            }

            // Use job unique_id as key
            $jobUniqueId = $jobLoads->first()->job->unique_id ?? "Job {$jobId}";
            $result[$jobUniqueId] = implode(', ', $positions);
        }

        return $result;
    }
}

if(!function_exists('getMainContractorId')){
    function getMainContractorId($userId){
        $user = User::find($userId);
        if($user && $user->added_by != null){
            return $user->added_by;
        }else{
            return $user->id;
        }
    }
}
if(!function_exists('getSubContractorIds')){
    function getSubContractorIds($userId){
        $user = User::find($userId);
        $subContractorIds = [];
        if($user && $user->added_by == null){
            $subContractorIds = User::where('added_by', $user->id)->pluck('id')->toArray();
        }else{
            $subContractorIds = User::where('added_by', $user->added_by)->pluck('id')->toArray();
        }
        return $subContractorIds;
    }
}
if (!function_exists('getSubContractorWithMainContractorIds')) {
    function getSubContractorWithMainContractorIds($userId)
    {
        $user = User::find($userId);
        
        if (!$user) {
            return [];
        }

        $contractorIds = [];
        
        // If user is main contractor (added_by is null)
        if ($user->added_by == null) {
            // Add main contractor ID
            $contractorIds[] = $user->id;
            
            // Get all sub-contractors added by this main contractor
            $subContractorIds = User::where('added_by', $user->id)->pluck('id')->toArray();
            
            if (!empty($subContractorIds)) {
                $contractorIds = array_merge($contractorIds, $subContractorIds);
            }
        } else {
            // User is a sub-contractor, get the main contractor and all siblings
            $mainContractorId = $user->added_by;
            
            // Add main contractor ID
            $contractorIds[] = $mainContractorId;
            
            // Get all sub-contractors (including the current user) under the same main contractor
            $subContractorIds = User::where('added_by', $mainContractorId)->pluck('id')->toArray();
            
            if (!empty($subContractorIds)) {
                $contractorIds = array_merge($contractorIds, $subContractorIds);
            }
        }
        
        // Remove duplicates and return
        return array_unique($contractorIds);
    }
}



