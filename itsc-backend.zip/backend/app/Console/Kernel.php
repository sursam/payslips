<?php

namespace App\Console;

use App\Console\Commands\DbBackUp;
use Illuminate\Console\Scheduling\Schedule;
use App\Console\Commands\TruckerWeeklyPayout;
use App\Console\Commands\LessThanTenTonsLoadInAJob;
use App\Console\Commands\SendContractorPaymentLink;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected $commands = [
        TruckerWeeklyPayout::class,
        LessThanTenTonsLoadInAJob::class,
        SendContractorPaymentLink::class,
        DbBackUp::class
    ];
    protected function schedule(Schedule $schedule): void
    {
        // $schedule->command('trucker-weekly-payout-via-stripe')->cron('0 17 * * 5');
        $schedule->command('trucker-weekly-payout-via-stripe')
                    ->weeklyOn(3, '01:00')
                    ->timezone('America/Chicago');
        $schedule->command('push-for-less-than-ten-tons-load-in-a-job')->everyFiveMinutes();
        $schedule->command('db-back-up')->dailyAt('00:00');
        $schedule->command('notify-for-complete-account-onboarding')->everySixHours();
        // $schedule->command('contructor-automate-payment-via-stripe')->everyFiveMinutes();
                    // ->everyDayOn('00:00')
                    // ->timeZone('America/Chicago');
        // $schedule->command('update-default-payment-method')->everyFiveMinutes();
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');
    }
}
