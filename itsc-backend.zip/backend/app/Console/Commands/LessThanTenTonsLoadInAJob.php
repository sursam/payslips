<?php

namespace App\Console\Commands;

use App\Models\Load;
use App\Models\User;
use Illuminate\Console\Command;
use App\Traits\PushNotificationTrait;

class LessThanTenTonsLoadInAJob extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    use PushNotificationTrait;
    protected $signature = 'push-for-less-than-ten-tons-load-in-a-job';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'alert contracter via push notification on every 5 minutes for less than 10 tons in a load of his one job';

    /**
     * Execute the console command.
     */

    public function handle()
    {
        $currentDateTime = date('Y-m-d H:i:s');
        $loads = Load::with('job')
            ->where('weight', '<', 10)
            ->where('status', 1)
            ->whereHas('job', function ($query) use ($currentDateTime) {
                $query->whereDate('delivery_date_time', '>=', $currentDateTime);
            })->get();

        // Extract unique user IDs from the loads
        $userIds = $loads->pluck('job.user_id')->unique()->values()->all();

        // Prepare to send notifications
        foreach ($loads as $load) {
            $userId = $load->job->user_id;
            $user = User::find($userId);

            if ($user) {
                $notificationData = [
                    'title' => 'Load Alert',
                    'body' => 'You have a load under 10 tons in one of your jobs. Please check it.',
                ];

                $jobId = $load->job->id;
                $jobStatus = $load->job->status;

                // Send push notification
                $this->sendNotification(
                    $user->fcm_token,
                    $notificationData['title'],
                    $notificationData['body'],
                    $notificationData['body'],
                    $user->device_type,
                    $jobId,
                    $jobStatus
                );
            }
        }

        $this->info('Push notifications sent to users for loads under 10 tons.');
    }
}
