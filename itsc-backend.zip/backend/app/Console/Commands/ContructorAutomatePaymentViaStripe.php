<?php

namespace App\Console\Commands;

use App\Models\Load;
use App\Models\User;
use Stripe\StripeClient;
use App\Models\Transaction;
use App\Traits\StripeTrait;
use App\Models\PaymentTerms;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use App\Traits\PushNotificationTrait;

class ContructorAutomatePaymentViaStripe extends Command
{

    /**
     * The name and signature of the console command.
    *
    * @var string
    */
    protected $signature = 'contructor-automate-payment-via-stripe';
    
    /**
     * The console command description.
    *
    * @var string
    */
    protected $description = 'Command description';
    
    /**
     * Execute the console command.
    **/
    
    use PushNotificationTrait;
    use StripeTrait;
    public function handle()
    {
        logger('Starting ContractorAutomatePaymentViaStripe at ' . now('Asia/Kolkata'));
        $currentDate = Carbon::now();
        // get those users who have payment methods
        $usersWhoHavePaymentMethods = User::whereNotNull('stripe_payment_method')->get();
        foreach ($usersWhoHavePaymentMethods as $key => $user) {
            // loads which was completed but pending for payment
            $completedJobLoads = Load::whereHas('job',function($query) use ($user){
                $query->where('user_id', $user->id);
            })->where('status', 4)->where('is_payment_initiated', '!=', 2)->get();
            if($completedJobLoads->count() > 0){
                logger("----------------------------------------------------");
                logger(
                    "User customer id: " . $user->stripe_customer_id .
                    " payment method id: " . $user->stripe_payment_method .
                    " amount in cents: " . $completedJobLoads->sum('load_cost') .
                    " user: " . $user->id .
                    " completed load ids: " . implode(', ', $completedJobLoads->pluck('id')->toArray())
                );
                logger("----------------------------------------------------");
                $isDone = $this->chargeCustomerAutomatically(
                    $user->stripe_customer_id,
                    $user->stripe_payment_method,
                    $completedJobLoads->sum('load_cost'),
                    $completedJobLoads->pluck('id')->toArray(),
                    $user,
                    "Payment for loads: " . implode(', ', $completedJobLoads->pluck('id')->toArray())
                );

                if ($isDone['success']) {
                    logger("✅ Payment succeeded for user ID {$user->id}. PaymentIntent ID: {$isDone['payment_intent_id']}");
                    foreach ($completedJobLoads as $load) {
                        $title = "Payment Succeeded";
                        $message = "Your payment succeeded for Job ID {$load->job?->unique_id} for amount {$load->load_cost} USD.";
                        $this->sendPushToContracter($user->id, $title, $message, $load->job?->id, $load->job?->status);
                    }
                } else {
                    logger("❌ Payment failed for user ID {$user->id}. Reason: " . ($isDone['message'] ?? 'Unknown error'));
                    foreach ($completedJobLoads as $load) {
                        $title = "Payment Failed";
                        $message = "Your payment failed for Job ID {$load->job?->unique_id} for amount {$load->load_cost} USD.";
                        $this->sendPushToContracter($user->id, $title, $message, $load->job?->id, $load->job?->status);
                    }
                }
                
            }
        }
        
    }
    public function chargeCustomerAutomatically($stripeCustomerId, $paymentMethodId, $amountInCents, $loadIds, $user, $description = '')
    {
        try {
            $stripe = new StripeClient(env('STRIPE_SECRET_KEY'));

            // Set the payment method as default for the customer
            $stripe->customers->update($stripeCustomerId, [
                'invoice_settings' => [
                    'default_payment_method' => $paymentMethodId,
                ],
            ]);

            // Create and confirm the payment intent
            $paymentIntent = $stripe->paymentIntents->create([
                'amount' => $amountInCents * 100,
                'currency' => 'usd',
                'customer' => $stripeCustomerId,
                'payment_method' => $paymentMethodId,
                'off_session' => true,
                'confirm' => true,
                'description' => $description,
            ]);

            if ($paymentIntent->status == 'succeeded') {
                // Store the transaction
                Transaction::create([
                    'user_id' => $user->id,
                    'transaction_id' => $paymentIntent->id,
                    'payment_method_id' => $paymentMethodId,
                    'payment_method' => 2, // 1: PayPal, 2: Stripe
                    'amount' => $amountInCents,
                    'response_data' => json_encode($paymentIntent),
                    'transaction_date' => now(),
                    'load_ids' => json_encode($loadIds),
                    'status' => 1,
                ]);

                Load::whereIn('id', $loadIds)->update(['is_payment_initiated' => 2]);
                $user->update(['last_payment_at' => now()]);
            }
            logger("Payment Intent ID: " . $paymentIntent->id);
            logger("payment done");
            return [
                'success' => true,
                'payment_intent_id' => $paymentIntent->id,
            ];
        } catch (\Stripe\Exception\CardException $e) {
            $error = $e->getError();

            if ($error->code == 'authentication_required') {
                return [
                    'success' => false,
                    'requires_action' => true,
                    'client_secret' => $error->payment_intent->client_secret,
                    'payment_intent_id' => $error->payment_intent->id,
                    'message' => 'Authentication required',
                ];
            }

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    public function sendPushToContracter($userId, $title, $message, $jobId = null, $jobStatus = null)
    {
        $contracterDetails = User::find($userId);
        $jobId = $jobId ? (string)$jobId : null;
        $jobStatus = $jobStatus ? (string)$jobStatus : null;
        $isNotificationSent = $this->sendNotification($contracterDetails->fcm_token, $title, $message, $message, $contracterDetails->device_type, $jobId, $jobStatus);
        if($isNotificationSent){
            return true;
        }
        return false;
    }
}
