<?php

namespace App\Console\Commands;

use App\Models\Load;
use App\Models\User;
use App\Models\Earning;
use App\Traits\StripeTrait;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use App\Models\TruckerPayoutActivity;

class TruckerWeeklyPayoutViaStripe extends Command
{
    use stripeTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'trucker-weekly-payout-via-stripe';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Payout truckers weekly based on their earnings';

    public function __construct()
    {
        parent::__construct(); // Call the parent constructor
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        logger("payout started");
        
        // Get today's date
        $today = Carbon::now();

        // If today is Friday or later in the week, stay in the same week
        // Otherwise, move back to last week's Friday
        $startOfWeek = $today->copy()->modify('last monday')->subWeek();
        $endOfWeek = $startOfWeek->copy()->modify('+6 days');
        logger("Start of week: $startOfWeek, End of week: $endOfWeek");
        // Get all truckers who worked in the current week with their emails and earnings
        $truckers = User::whereHas('earnings', function ($query) use ($startOfWeek, $endOfWeek) {
            $query->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                ->where('is_paid', 0);
        })
            ->with(['earnings' => function ($query) use ($startOfWeek, $endOfWeek) {
                $query->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                    ->where('is_paid', 0);
            }])
            ->get();
        if ($truckers->isNotEmpty()) {
            $truckers->map(function ($user) use ($startOfWeek, $endOfWeek) {
                $totalEarnings = $user->earnings->where('type', 1)->sum('amount');
                $totalDeductions = $user->earnings->where('type', 2)->sum('amount');
                $netAmount = $totalEarnings - $totalDeductions;

                $loadIds = $user->earnings->pluck('load_id')->filter()->unique()->implode(',');

                $this->makePayout($user, $netAmount, $startOfWeek, $endOfWeek, $loadIds);
            });
        }
        logger($truckers);
    }
    private function makePayout($user, $amount, $startOfWeek, $endOfWeek, $loadIds)
    {
        $response = $this->transferAndPayoutMoney($user, $amount);
        $isPayoutDone = $response->getData(true);
        $status = $isPayoutDone['success'] ? true : false;
        TruckerPayoutActivity::create([
            'user_id' => $user->id,
            'transfer_id' => $isPayoutDone['transfer_id'] ?? null,
            'payout_id' => $isPayoutDone['payout_id'] ?? null,
            'amount' => $isPayoutDone['amount'] ?? $amount,
            'currency' => 'USD',
            'status' => $status ? '1' : '2', // 1 for success, 2 for failure
            'payout_date' => Carbon::now()->format('Y-m-d H:i:s'),
            'load_ids' => $loadIds,
            'description' => $status ? 'weekly payout done' : 'payout failed',
            'payment_from_date' => $startOfWeek,
            'payment_to_date' => $endOfWeek,
        ]);
        if ($status) {
            // update the is_payment_initiated to 1 in the loads table
            // Load::whereIn('id', explode(',', $loadIds))
            //     ->update(['is_payment_initiated' => 1]);
            // Update earnings to mark them as paid
            Earning::where('user_id', $user->id)
                ->where('is_paid', 0)
                ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                ->update(['is_paid' => 1]);

            logger("---------------------Payout Successful---------------------");
            logger("Payout to {$user->email} of amount {$amount} was successful.");
        } else {
            logger("---------------------Payout Failed---------------------");
            logger("Payout to {$user->email} failed.");
        }
    }
    public function transferAndPayoutMoney($user, $amount)
    {

        // $user = auth()->user();
        // $amount = 100;
        if (!$user->stripe_account_id) {
            return response()->json([
                'success' => false,
                'message' => 'User does not have a connected Stripe account'
            ], 400);
        }

        // Convert amount to cents
        $amountInCents = round($amount * 100);
        // Transfer and payout
        $result = $this->transferAndPayout(
            $user->stripe_account_id,
            $amountInCents,
            $user->stripe_bank_acc_id,
            'usd',
            [
                'user_id' => $user->id,
                'operation' => 'transfer_and_payout'
            ]
        );

        if ($result['success']) {
            return response()->json([
                'success' => true,
                'message' => 'Transfer and payout completed successfully',
                'transfer_id' => $result['transfer_id'],
                'payout_id' => $result['payout_id'],
                'amount' => $result['amount'] / 100,
                'currency' => $result['currency']
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Transfer and payout failed',
            'error' => $result['error'],
            'transfer_completed' => $result['transfer_completed'] ?? false
        ], 400);
    }
}
