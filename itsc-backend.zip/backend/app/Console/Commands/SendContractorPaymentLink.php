<?php

namespace App\Console\Commands;

use App\Models\Load;
use App\Traits\PayPal;
use App\Models\EmailContant;
use App\Models\PaymentTerms;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\ComtractorPaymentLinkMail;

class SendContractorPaymentLink extends Command
{
    use PayPal;
    // cron
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send-contractor-payment-link';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';
    public function __construct()
    {
        parent::__construct(); // Ensure this line is present
    }
    /**
     * Execute the console command.
     */
    public function handle(){
        $paymentTerms = PaymentTerms::get();
        $currentDate = Carbon::now();
        foreach ($paymentTerms as $key =>$paymentTerm){
            $lastPaidAt = $paymentTerm->user?->last_payment_at ?? $paymentTerm->user->created_at;
            $lastPaidAt = Carbon::parse($lastPaidAt);
            // Calculate the interval in terms of days
            $intervalInDays = $lastPaidAt->diffInDays($currentDate);
            if($intervalInDays == $paymentTerm->pay_in){
                // dump("Interval in days: " . $intervalInDays);
                // dump("Payment terms: " . $paymentTerm->pay_in);
                // dump("User ID: " . $paymentTerm->user?->id);
                $payAmount = 0.0; // Reset payAmount for each user
                $loadIds = [];
                $completedJobLoads = Load::whereHas('job', function ($query) use ($lastPaidAt, $paymentTerm, $currentDate) {
                    $query->where('user_id', $paymentTerm->user_id)
                        ->whereBetween('created_at', [
                            $lastPaidAt,
                            $currentDate // Explicitly cap at current datetime
                        ]);
                })->where('status', 4)->get();
                foreach ($completedJobLoads as $completedJobLoad) {
                    $payAmount += $completedJobLoad->load_cost;
                    array_push($loadIds, $completedJobLoad->id);
                }
                dump("pay amount: " . $payAmount);
                if ($payAmount > 0) {
                    // dump("Pay amount: " . $payAmount);
                    // dump("Load IDs: " . implode(', ', $loadIds)); // Formatting improvement
                    // dump("User: " . $paymentTerm->user->email ?? 'Unknown User');
                    // Convert date format to mm-dd-yyyy
                    $startDate = Carbon::parse($lastPaidAt)->format('m-d-Y');
                    $endDate = $currentDate->format('m-d-Y');

                    $this->sendPaymentLink($paymentTerm->user, $payAmount, $startDate, $endDate, $loadIds);
                }
            }
        }
    }
    private function sendPaymentLink($user, $payAmount, $startDate, $endDate, $loadIds)
    {
        $dateRange = $startDate . ' -> ' . $endDate;
        $fullName = $user->first_name . ' ' . $user->last_name;
        $emailContent = EmailContant::where('slug', 'contracter-payment-email')->first();
        $subject = $emailContent->subject;
        $content = $emailContent->description;

        $paymentLink = $this->createPayment($payAmount, $loadIds);
        // logger('Payment Link: ' . $paymentLink);
        // logger('User Email: ' . $user->email);
        // dump($user->email);
        // dump($payAmount);
        // dump($startDate . ' -> ' . $endDate);
        //dump($paymentLink);
        if ($paymentLink) {
            Mail::to($user->email)->send(new ComtractorPaymentLinkMail($fullName, $content, $subject, $paymentLink, $dateRange));
        }
        // update load payment status to 1
        Load::whereIn('id', $loadIds)->update(['is_payment_initiated' => 1]);
        // update user last payment date
        $user->update(['last_payment_at' => Carbon::now()]);
    }
}
