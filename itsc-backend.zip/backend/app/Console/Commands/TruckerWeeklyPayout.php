<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Models\Earning;
use App\Traits\PayPal;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;

class TruckerWeeklyPayout extends Command
{
    use PayPal;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'trucker-weekly-payout';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Payout truckers weekly based on their earnings';

    /**
     * Constructor to initialize the parent Command class.
     */
    public function __construct()
    {
        parent::__construct(); // Call the parent constructor
    }

    public function handle()
    {
        // Calculate the start and end of the current week
        $startOfWeek = Carbon::now()->startOfWeek()->format('Y-m-d');
        $endOfWeek = Carbon::now()->endOfWeek()->format('Y-m-d');

        // Get all truckers who worked in the current week with their emails and earnings
        $truckers = User::whereHas('earnings', function ($query) use ($startOfWeek, $endOfWeek) {
            $query->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                ->where('is_paid', 0);
        })
            ->with(['earnings' => function ($query) use ($startOfWeek, $endOfWeek) {
                $query->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                    ->where('is_paid', 0);
            }])
            ->get()
            ->map(function ($user) {
                // Calculate earnings (type = 1)
                $totalEarnings = $user->earnings->where('type', 1)->sum('amount');

                // Calculate deductions (type = 2)
                $totalDeductions = $user->earnings->where('type', 2)->sum('amount');

                // Calculate net amount
                $netAmount = $totalEarnings - $totalDeductions;

                $this->makePayout($user, $netAmount);
            });
    }


    private function makePayout($user, $amount)
    {
        // Example of calling the PayPal trait method:
        $isPayoutDone = $this->sendPayPalPayout($user->email, $amount);
        if($isPayoutDone) {
            // Calculate the current week's date range
            $startOfWeek = Carbon::now()->startOfWeek()->format('Y-m-d');
            $endOfWeek = Carbon::now()->endOfWeek()->format('Y-m-d');
            // Update the earnings to mark them as paid
            Earning::where('user_id', $user->id)
            ->where('is_paid', 0)
            ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
            ->update(['is_paid' => 1]);
            // Log the payout details
            logger("---------------------Payout Successful---------------------");
            logger("Payout to {$user->email} of amount {$amount} was successful.");
            logger("Payout details: ");
            logger("User ID: {$user->id}");
            logger("Amount: {$amount}");
            logger("Date Range: {$startOfWeek} to {$endOfWeek}");
            logger("-------------------------------------------------------");
        } else {
            // Handle the case where the payout fails
            logger("---------------------Payout Failed---------------------");
            logger("Payout to {$user->email} failed.");
            logger("-------------------------------------------------------");
        }
    }
}
