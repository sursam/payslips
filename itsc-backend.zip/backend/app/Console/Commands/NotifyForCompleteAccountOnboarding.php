<?php

namespace App\Console\Commands;

use App\Mail\NotifyPendingOnboardingUsers;
use App\Models\User;
use App\Models\EmailContant;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class NotifyForCompleteAccountOnboarding extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notify-for-complete-account-onboarding';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'notify all the contractors and truckers to complete their account onboarding process. This command will run on every 6 hrs interval';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $users = $this->getPendingOrboardingUsers();
        // dump($users);
        if (empty($users)) {
            return;
        }
        $this->sendNotifyWelcomeEmailForUsers($users);
        logger('Notification sent to pending onboarding users successfully.');
    }

    /**
     * Get the users who have not completed their onboarding steps.
     *
     * @return array
     */
    public function getPendingOrboardingUsers()
    {
        $users = User::whereIn('user_type', [3, 4])->where('completed_steps', '<', 4)->select('id', 'email', 'first_name', 'last_name')->get();
        return $users;
    }
    public function sendNotifyWelcomeEmailForUsers($users)
    {
        $emailContent = EmailContant::where('slug', 'onboarding-alert-mail')->first();
        if (!$emailContent) {
            return false;
        }

        $subject = $emailContent->subject;
        $content = $emailContent->description;

        // Use collection each - no nested loops
        $users->each(function ($user) use ($subject, $content) {
            $fullName = $user->first_name . ' ' . $user->last_name;
            Mail::to($user->email)->queue(
                new NotifyPendingOnboardingUsers($fullName, $content, $subject)
            );
        });

        return true;
    }
}
