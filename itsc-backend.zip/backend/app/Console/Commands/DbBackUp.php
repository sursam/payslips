<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class DbBackUp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'db-back-up';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'backup the database on everyday 12 AM Once and store it into storage app/db_backup';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        // Define backup directory and file name
        $backupDir = public_path("storage/backup");
        $backupFile = 'Conectar_Db'.now()->format("m-d-y") . ".gz";
        $path = "{$backupDir}/{$backupFile}";

        // Ensure backup directory exists with 777 permissions
        if (!File::exists($backupDir)) {
            File::makeDirectory($backupDir, 0777, true, true);
        }

        // Construct MySQL dump command
        $command = "mysqldump --user=" . env('DB_USERNAME') .
            " --password=" . env('DB_PASSWORD') .
            " --host=" . env("DB_HOST") .
            " " . env('DB_DATABASE') . " | gzip > " . escapeshellarg($path);

        // Execute the command
        $output = null;
        $resultCode = null;
        exec($command, $output, $resultCode);

        // Verify command execution
        if ($resultCode === 0) {
            $this->info("Backup successfully created: {$path}");
        } else {
            $this->error("Failed to create backup.");
        }
    }
}
