<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Traits\StripeTrait;
use Illuminate\Console\Command;

class UpdateDefaultPaymentMethod extends Command
{
    use StripeTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update-default-payment-method';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $usersWhoHavePaymentMethods = User::whereNotNull('stripe_payment_method')->get();
        foreach ($usersWhoHavePaymentMethods as $key => $user) {
            $savePaymentMethods = $this->getContractorPaymentMethod($user->id);
            $user->update(['stripe_payment_method' => $savePaymentMethods]);
        }
    }

    public function getContractorPaymentMethod($userId){
        try{
            $userCustomerId = User::find($userId)->stripe_customer_id;
            $savePaymentMethods = $this->retriveCustomerPaymentMethod($userCustomerId);
            return $savePaymentMethods;
        }catch(\Exception $e){
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return (object)[];
        }
    }
}
