<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Permission;
use Illuminate\Support\Str;

class ContractorPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json  = file_get_contents(database_path() . '/data/contractor-permission.json');
        $data  = json_decode($json);
        foreach ($data->permissions as $key => $value) {
            Permission::updateOrCreate([
                'name' => $value->name,
                'slug' => Str::slug($value->name),
                'group_by' => $value->group_by,
                'type' => 1
            ]);
        }
    }
}
