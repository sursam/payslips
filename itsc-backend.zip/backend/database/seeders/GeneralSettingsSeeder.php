<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GeneralSettingsSeeder extends Seeder
{
    public function run()
    {
        DB::table('general_settings')->insert([
            [
                'name' => 'Setting 1',
                'slug' => 'setting-1',
                'email' => 'setting1@example.com',
                'whatsapp' => true,
                'sms' => false,
            ],
            [
                'name' => 'Setting 2',
                'slug' => 'setting-2',
                'email' => 'setting2@example.com',
                'whatsapp' => false,
                'sms' => true,
            ],
        ]);
    }
}

