<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Faker\Factory as Faker;
use App\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(Request $request): void
    {
        $faker = Faker::create();

        // Super Admin User
        $superAdminRole = Role::where('slug', 'super-admin')->first();
        $permissions = Permission::all();
        $superAdminUser = new User();
        $superAdminUser->uuid = $faker->uuid;
        $superAdminUser->first_name = 'Super';
        $superAdminUser->last_name = 'Admin';
        $superAdminUser->user_type = 1;
        $superAdminUser->email = 'superadmin@gmail.com';
        $superAdminUser->mobile_number = 6290261220;
        $superAdminUser->password = bcrypt('admin@123');
        $superAdminUser->registration_ip = $request->getClientIp();
        $superAdminUser->is_active = 1;
        $superAdminUser->save();
        $superAdminUser->roles()->attach($permissions);
        $superAdminRole->permissions()->attach($permissions);

    }
}
