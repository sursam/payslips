<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->foreignId('load_type_id')->nullable()->references('id')->on('load_types')->constrained();
            $table->string('unique_id')->nullable();
            $table->string('order_no')->nullable()->comment('user_given');
            $table->tinyInteger('job_type')->default(true)->comment('1:general, 2:Haul Off');
            $table->string('pickup_location_company')->nullable();
            $table->string('pickup_location_contact_no')->nullable();
            $table->string('pickup_location_email')->nullable();
            $table->longText('pickup_contact')->nullable();
            $table->string('drop_off_location_company')->nullable();
            $table->string('drop_off_location_contact_no')->nullable();
            $table->string('drop_off_location_email')->nullable();
            $table->longText('drop_off_contact')->nullable();
            $table->string('scheduling_type')->nullable();
            $table->longText('source')->nullable();
            $table->longText('destination')->nullable();
            $table->timestamp('pickup_date_time')->nullable();
            $table->timestamp('delivery_date_time')->nullable();
            $table->string('source_lat')->nullable();
            $table->string('source_lng')->nullable();
            $table->string('delivery_lat')->nullable();
            $table->string('delivery_lng')->nullable();
            $table->tinyInteger('priority')->default(2)->comment('1:high, 2:medium, 3:low');
            $table->foreignId('material_id')->nullable()->references('id')->on('materials')->constrained();
            $table->string('material_other')->nullable();
            $table->foreignId('material_option_id')->nullable()->references('id')->on('material_options')->constrained();
            $table->string('material_option_other')->nullable();
            $table->string('truck_type_ids')->nullable();
            $table->double('fright_charges',8,2)->nullable();
            $table->foreignId('equipment_id')->nullable()->references('id')->on('equipment')->constrained();
            $table->string('equipment_other')->nullable();
            $table->foreignId('equipment_option_id')->nullable()->references('id')->on('equipment_options')->constrained();
            $table->string('equipment_option_other')->nullable();
            $table->integer('no_of_trucks')->nullable();
            $table->double('total_mileage',8,2)->nullable();
            $table->string('load_spacing_minutes')->nullable()->comment('in_minutes');
            $table->double('per_unit_price',8,2)->nullable();
            $table->double('job_estimate_price',8,2)->nullable()->comment('total_job_cost');
            $table->double('total_miles',8,2)->nullable();
            $table->tinyInteger('status')->default(1)->comment('1:new , 2:accepted, 3:completed, 4:cancelled, 5: past, 6:closed');
            $table->date('job_completed_date')->nullable();
            $table->boolean('payment_status')->default(false)->comment('1:paid, 0: not paid');
            $table->tinyInteger('payment_type')->nullable()->comment('1:full, 2:partial');
            $table->date('payment_date')->nullable();
            $table->longText('notes')->nullable();
            $table->boolean('is_draft')->default(false)->comment('1:draft, 0:published');
            $table->boolean('is_closed')->default(false)->comment('1:closed, 0:not closed');
            $table->boolean('is_hourly')->default(false)->comment('1:hourly, 0:not hourly');
            $table->foreignId('posted_by')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->foreignId('posted_for')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('jobs');
    }
};
