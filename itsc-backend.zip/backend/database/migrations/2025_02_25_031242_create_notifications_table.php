<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->longText('description')->nullable();
            $table->boolean('is_for_job')->default(false)->comment('1: for job , 0: normal');
            $table->tinyInteger('job_status')->nullable();
            $table->tinyInteger('alert_type')->nullable()->comment('1: red, 2: yellow, 3: blue');
            $table->boolean('is_read')->default(false)->comment('1: read 0: not read');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notifications');
    }
};
