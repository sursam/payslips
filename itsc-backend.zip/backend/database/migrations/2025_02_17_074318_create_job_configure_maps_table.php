<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_configure_maps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('fleet_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('fleet_id');
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('trucker_id');
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->foreignId('load_id')->nullable()->references('id')->on('loads')->constrained()->cascadeOnDelete();
            $table->integer('token')->nullable();
            $table->string('challan')->nullable();
            $table->double('empty_truck_weight',8,2)->nullable();
            $table->double('loaded_truck_weight',8,2)->nullable();
            $table->string('signature')->nullable();
            $table->string('final_receipt')->nullable();
            $table->string('receiver_name')->nullable();
            $table->longText('notes')->nullable();
            $table->tinyInteger('isnetweightflag')->nullable();
            $table->boolean('contractor_acceptance')->default(false)->comment('1: accepted, 0: not accepted');
            $table->tinyInteger('driver_status')->nullable();
            $table->string('invoice')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_configure_maps');
    }
};
