<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_comissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('city_id')->nullable()->references('id')->on('cities')->constrained()->cascadeOnDelete();
            $table->string('truck_type_ids')->nullable();
            $table->double('hourly_rate',8,2)->nullable();
            $table->double('weight_rate',8,2)->nullable();
            $table->double('trucker_percentage',8,2)->nullable();
            $table->double('cal_percentage',8,2)->nullable();
            $table->double('jobowner_cancel_fees',8,2)->nullable();
            $table->double('driver_cancel_fees',8,2)->nullable();
            $table->double('hauloff_driver_percentage',8,2)->nullable();
            $table->double('hauloff_cal_percentage',8,2)->nullable();
            $table->double('hauloff_jobowner_cancel_fees',8,2)->nullable();
            $table->double('hauloff_driver_cancel_fees',8,2)->nullable();
            $table->double('normal_backhaul_percentage',8,2)->nullable();
            $table->double('hauloff_backhaul_percentage',8,2)->nullable();
            $table->boolean('is_active')->default(true)->comment('1: active, 0: inactive');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_comissions');
    }
};
