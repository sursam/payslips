<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cancel_jobs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->foreignId('load_id')->nullable()->references('id')->on('loads')->constrained()->cascadeOnDelete();
            $table->foreignId('trucker_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->tinyInteger('is_picked_up')->nullable()->comment('1: picked_up 0: not picked up');
            $table->tinyInteger('is_returned')->nullable()->comment('1: returned 0: not returned');
            $table->longText('reason')->nullable();
            $table->tinyInteger('status')->nullable()->comment('1: Accepted, 2:Reached, 3:Running');
            $table->timestamp('cancelled_at')->nullable();
            $table->foreignId('cancelled_by')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cancel_jobs');
    }
};
