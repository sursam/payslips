<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('generated_invoices', function (Blueprint $table) {
            $table->date('description_start_date')->nullable()->after('to_date');
            $table->date('description_end_date')->nullable()->after('description_start_date');
            $table->string('load_ids')->nullable()->after('description_end_date')->comment('Comma-separated list of load IDs for the invoice');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('generated_invoices', function (Blueprint $table) {
            $table->dropColumn(['description_start_date', 'description_end_date', 'load_ids']);
        });
    }
};
