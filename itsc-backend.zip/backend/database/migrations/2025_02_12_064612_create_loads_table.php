<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('loads', function (Blueprint $table) {
            $table->id();
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('trucker_id');
            $table->double('weight',8,2)->nullable();
            $table->double('trucker_taken_weight',8,2)->nullable();
            $table->double('load_cost',8,2)->nullable();
            $table->double('cal_comission',8,2)->nullable();
            $table->double('trucker_get',8,2)->nullable();
            $table->integer('min_completed_hours')->nullable();
            $table->integer('max_completed_hours')->nullable();
            $table->timestamp('reached_on')->nullable();
            $table->timestamp('started_on')->nullable();
            $table->timestamp('completed_on')->nullable();
            $table->tinyInteger('status')->default(false)->comment('0:not accepted, 1: accepted, 2: running, 3:complete_from_trucker, 4: complete_from_contractor');
            $table->foreignId('cancellation_request_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('trucker_id');
            $table->boolean('is_payment_initiated')->default(false)->comment('0: not done, 1: payment link initiated, 2: payment done');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('loads');
    }
};
