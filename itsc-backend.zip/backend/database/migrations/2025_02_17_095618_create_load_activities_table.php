<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('load_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->foreignId('load_id')->nullable()->references('id')->on('loads')->constrained()->cascadeOnDelete();
            $table->foreignId('fleet_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('fleet_id');
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete()->comment('trucker_id');
            $table->double('weight',8,2)->nullable();
            $table->double('cost',8,2)->nullable();
            $table->timestamp('started_on')->nullable();
            $table->timestamp('completed_on')->nullable();
            $table->tinyInteger('status')->nullable()->comment('1: Accepted, 2:Reached, 3:Running 4:Waiting_for_verification, 5:cancelled 6: Completed');
            $table->string('current_lat')->nullable();
            $table->string('current_lng')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('load_activities');
    }
};
