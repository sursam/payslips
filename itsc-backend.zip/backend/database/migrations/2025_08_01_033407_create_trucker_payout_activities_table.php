<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('trucker_payout_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->string('transfer_id')->nullable();
            $table->string('payout_id')->nullable();
            $table->double('amount', 8, 2)->nullable();
            $table->string('currency')->default('USD');
            $table->tinyInteger('status')->default(0)->comment('0: pending, 1: success, 2: failure');
            $table->longText('response_data')->nullable(); // Store API response from Stripe
            $table->timestamp('payout_date')->useCurrent(); // When the payout was made
            $table->longText('load_ids')->nullable(); // Store IDs of loads associated with the payout
            $table->string('description')->nullable(); // Optional description for the payout activity
            $table->string('type')->default('weekly'); // Type of payout activity, 
            $table->string('payment_method')->default('stripe'); // Payment method used for the payout
            $table->date('payment_from_date')->nullable(); // Start date of the payment period
            $table->date('payment_to_date')->nullable(); // End date of the payment period
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('trucker_payout_activities');
    }
};
