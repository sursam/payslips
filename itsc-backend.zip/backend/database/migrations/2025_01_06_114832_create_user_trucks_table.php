<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_trucks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->foreignId('truck_type_id')->nullable()->references('id')->on('truck_types')->constrained()->cascadeOnDelete();
            $table->string('image')->nullable();
            $table->string('truck_vin_number')->nullable();
            $table->string('truck_license_no')->nullable();
            $table->string('company_truck_number')->nullable();
            $table->string('truck_make')->nullable();
            $table->string('truck_body_style')->nullable();
            $table->string('truck_color')->nullable();
            $table->string('truck_cabin_type')->nullable();
            $table->double('truck_empty_weight',8,2)->nullable();
            $table->double('truck_carrying_capacity',8,2)->nullable();
            $table->boolean('is_active')->default(true)->comment('1:active,0:in-active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_trucks');
    }
};
