<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('earnings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->foreignId('job_id')->nullable()->references('id')->on('jobs')->constrained()->cascadeOnDelete();
            $table->foreignId('load_id')->nullable()->references('id')->on('loads')->constrained()->cascadeOnDelete();
            $table->double('amount',8,2)->nullable();
            $table->tinyInteger('type')->nullable()->comment('1: credit 2: debit');
            $table->longText('remarks')->nullable();
            $table->boolean('is_paid')->default(false)->comment("1: paid, 0: not paid");
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('earnings');
    }
};
