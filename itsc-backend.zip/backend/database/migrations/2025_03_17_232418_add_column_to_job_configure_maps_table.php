<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('job_configure_maps', function (Blueprint $table) {
            $table->boolean('is_ticket_signed')->default(false)->after('token')->comment('1: signed, 0: not signed');
            $table->longText('trucker_notes')->nullable()->after('challan');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('job_configure_maps', function (Blueprint $table) {
            $table->dropColumn('is_ticket_signed');
            $table->dropColumn('trucker_notes');
        });
    }
};
