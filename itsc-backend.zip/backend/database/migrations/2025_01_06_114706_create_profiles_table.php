<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->references('id')->on('users')->constrained()->cascadeOnDelete();
            $table->string('company_legal_name')->nullable();
            $table->string('tax_id')->nullable();
            $table->string('company_dba')->nullable();
            $table->bigInteger('phone_2')->nullable();
            $table->string('email')->nullable();
            $table->string('driving_license_no')->nullable();
            $table->date('driving_license_expiery')->nullable();
            $table->boolean('is_active')->default(true)->comment('1:active,0:in-active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('profiles');
    }
};
