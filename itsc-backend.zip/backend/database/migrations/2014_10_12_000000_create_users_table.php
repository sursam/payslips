<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->nullable();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->tinyInteger('user_type')->default(2)->comment('1-Super Admin,2:All Admin,3:Customer');
            $table->tinyInteger('language')->default(1)->comment('1:english,2:spanish');
            $table->string('email')->nullable()->unique();
            $table->rememberToken();
            $table->string('password')->nullable();
            $table->integer('country_code')->nullable();
            $table->bigInteger('mobile_number')->nullable()->unique();
            $table->string('verification_code')->nullable()->comment('OTP used for verifying the phone number');
            $table->tinyInteger('registration_source')->default(1)->comment('1:Mobile,2:Web');
            $table->string('registration_ip', 100)->nullable();
            $table->text('address')->nullable();
            $table->bigInteger('pin_code')->nullable();
            $table->foreignId('state_id')->nullable()->references('id')->on('states')->constrained()->cascadeOnDelete();
            $table->foreignId('city_id')->nullable()->references('id')->on('cities')->constrained()->cascadeOnDelete();
            $table->string('latitude')->nullable();
            $table->string('longitude')->nullable();
            $table->date('dob')->nullable();
            $table->string('profile_image')->nullable();
            $table->boolean('is_logged_in')->default(false)->comment('0:Not Logged In,1:Logged In');
            $table->tinyInteger('is_verified')->default(true)->comment('0:Not Verified,1:Verified')->nullable();
            $table->tinyInteger('is_active')->default(true)->comment('0:Inactive,1:Active')->nullable();
            $table->tinyInteger('is_approve')->default(true)->comment('0:Unapproved,1:Approved')->nullable();
            $table->tinyInteger('is_blocked')->default(false)->comment('0:Unblocked,1:Blocked')->nullable();
            $table->string('fcm_token')->nullable();
            $table->string('device_type')->default(1)->comment('1:Web,2:Android,3:iOS')->nullable();
            $table->tinyInteger('completed_steps')->nullable();
            $table->string('device_token')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
