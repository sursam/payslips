-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 01, 2024 at 08:48 AM
-- Server version: 8.0.39-0ubuntu0.20.04.1
-- PHP Version: 8.2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `primeparkusa`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookingRequests`
--

CREATE TABLE `bookingRequests` (
  `id` int NOT NULL,
  `customerId` int NOT NULL,
  `slotId` int NOT NULL,
  `vehicleTypeId` int NOT NULL,
  `customerMobile` int NOT NULL,
  `plateNumber` varchar(255) NOT NULL,
  `fromDate` date NOT NULL,
  `selectedCheckInTime` time NOT NULL,
  `toDate` date NOT NULL,
  `selectedCheckOutTime` time NOT NULL,
  `bookingStatus` enum('Booked','Checked In','Checked Out','Failed') NOT NULL,
  `bookingTicketNo` varchar(255) DEFAULT NULL,
  `paymentType` varchar(255) DEFAULT NULL,
  `paymentStatus` enum('Due','Booking Charges Paid','Fully Paid','Full Due','Onsite Charges Due','Payment Failed') NOT NULL DEFAULT 'Due',
  `isCancelled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-Not Cancelled, true-Cancelled',
  `cancellationReason` varchar(255) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carMovements`
--

CREATE TABLE `carMovements` (
  `id` int NOT NULL,
  `bookingRequestId` int NOT NULL,
  `vendorId` int DEFAULT NULL,
  `reservationId` varchar(255) DEFAULT NULL,
  `actualvehicleTypeId` int NOT NULL,
  `actualFromDate` date NOT NULL,
  `actualCheckInTime` time NOT NULL,
  `actualToDate` date NOT NULL,
  `actualCheckOutTime` time NOT NULL,
  `isOverStay` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-no, true-yes',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int NOT NULL,
  `bookingRequestId` int NOT NULL,
  `reservationAmount` double NOT NULL DEFAULT '0',
  `parkingChargeTotal` double NOT NULL DEFAULT '0',
  `overSizeChargeTotal` double DEFAULT '0',
  `extraPassengers` int DEFAULT '0',
  `extraPassengerChargesTotal` double DEFAULT '0',
  `overstayDays` int DEFAULT '0',
  `overstayAmountTotal` double DEFAULT '0',
  `payableAmount` double NOT NULL DEFAULT '0',
  `paidAmount` double NOT NULL DEFAULT '0',
  `dueAmount` double NOT NULL DEFAULT '0',
  `paymentType` varchar(255) DEFAULT NULL,
  `paymentStatus` enum('Due','Booking Charges Paid','Fully Paid','Full Due','Onsite Charges Due','Failed') NOT NULL DEFAULT 'Due',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `modulePermissions`
--

CREATE TABLE `modulePermissions` (
  `userId` int NOT NULL,
  `moduleId` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `modulePermissions`
--

INSERT INTO `modulePermissions` (`userId`, `moduleId`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 11, '2024-08-26 12:05:58', '2024-08-26 12:05:58', NULL),
(5, 12, '2024-08-26 12:05:58', '2024-08-26 12:05:58', NULL),
(6, 11, '2024-08-26 12:08:07', '2024-08-26 12:08:07', NULL),
(6, 12, '2024-08-26 12:08:07', '2024-08-26 12:08:07', NULL),
(7, 1, '2024-08-26 12:15:35', '2024-08-26 12:15:35', NULL),
(8, 1, '2024-08-27 02:48:56', '2024-08-27 02:48:56', NULL),
(8, 2, '2024-09-13 09:13:59', '2024-09-13 09:13:59', NULL),
(8, 3, '2024-09-13 09:13:59', '2024-09-13 09:13:59', NULL),
(8, 4, '2024-09-13 09:13:59', '2024-09-13 09:13:59', NULL),
(9, 1, '2024-08-27 03:48:09', '2024-08-27 03:48:09', NULL),
(10, 1, '2024-08-27 06:05:23', '2024-08-27 06:05:23', NULL),
(11, 1, '2024-08-27 09:04:32', '2024-08-27 09:04:32', NULL),
(11, 2, '2024-08-27 09:04:32', '2024-08-27 09:04:32', NULL),
(12, 1, '2024-08-27 09:05:40', '2024-08-27 09:05:40', NULL),
(12, 3, '2024-08-27 09:05:40', '2024-08-27 09:05:40', NULL),
(13, 1, '2024-08-27 10:36:21', '2024-08-27 10:36:21', NULL),
(14, 1, '2024-08-27 11:40:20', '2024-08-27 11:40:20', NULL),
(14, 2, '2024-08-27 11:40:20', '2024-08-27 11:40:20', NULL),
(15, 1, '2024-08-27 11:59:50', '2024-08-27 11:59:50', NULL),
(16, 1, '2024-08-27 12:02:25', '2024-08-27 12:02:25', NULL),
(17, 1, '2024-08-27 12:07:12', '2024-08-27 12:07:12', NULL),
(18, 1, '2024-08-27 12:12:04', '2024-08-27 12:12:04', NULL),
(19, 1, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(19, 2, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(19, 3, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(19, 4, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(19, 5, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(19, 6, '2024-08-27 12:49:51', '2024-08-27 12:49:51', NULL),
(20, 1, '2024-08-27 13:23:39', '2024-08-27 13:23:39', NULL),
(20, 2, '2024-08-27 13:23:39', '2024-08-27 13:23:39', NULL),
(20, 3, '2024-08-27 13:23:39', '2024-08-27 13:23:39', NULL),
(21, 1, '2024-08-27 13:31:02', '2024-08-27 13:31:02', NULL),
(22, 1, '2024-08-27 13:34:06', '2024-08-27 13:34:06', NULL),
(22, 12, '2024-08-27 13:34:06', '2024-08-27 13:34:06', NULL),
(23, 1, '2024-08-27 14:05:49', '2024-08-27 14:05:49', NULL),
(23, 2, '2024-08-27 14:05:49', '2024-08-27 14:05:49', NULL),
(24, 1, '2024-08-28 06:19:44', '2024-08-28 06:19:44', NULL),
(24, 2, '2024-08-28 06:19:44', '2024-08-28 06:19:44', NULL),
(24, 3, '2024-08-28 06:19:44', '2024-08-28 06:19:44', NULL),
(24, 4, '2024-08-28 06:19:44', '2024-08-28 06:19:44', NULL),
(25, 5, '2024-08-28 06:52:19', '2024-08-28 06:52:19', NULL),
(26, 1, '2024-08-28 10:42:53', '2024-08-28 10:42:53', NULL),
(26, 2, '2024-08-28 10:42:53', '2024-08-28 10:42:53', NULL),
(27, 1, '2024-08-28 11:25:13', '2024-08-28 11:25:13', NULL),
(28, 1, '2024-09-01 09:33:29', '2024-09-01 09:33:29', NULL),
(28, 2, '2024-09-01 09:33:29', '2024-09-01 09:33:29', NULL),
(30, 1, '2024-09-02 04:11:09', '2024-09-02 04:11:09', NULL),
(31, 1, '2024-09-03 04:48:22', '2024-09-03 04:48:22', NULL),
(32, 1, '2024-09-05 12:09:45', '2024-09-05 12:09:45', NULL),
(33, 1, '2024-09-16 09:54:10', '2024-09-16 09:54:10', NULL),
(34, 1, '2024-09-16 10:18:14', '2024-09-16 10:18:14', NULL),
(34, 2, '2024-09-16 10:18:14', '2024-09-16 10:18:14', NULL),
(35, 6, '2024-09-16 12:56:59', '2024-09-16 12:56:59', NULL),
(35, 7, '2024-09-16 12:56:59', '2024-09-16 12:56:59', NULL),
(35, 8, '2024-09-16 12:56:59', '2024-09-16 12:56:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int NOT NULL,
  `parentModuleId` int DEFAULT NULL,
  `moduleName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `moduleSlug` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `moduleIcon` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `parentModuleId`, `moduleName`, `moduleSlug`, `created_at`, `updated_at`, `deleted_at`, `moduleIcon`) VALUES
(1, NULL, 'Users', 'users', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/prime_users.png'),
(2, NULL, 'Bookings', 'bookings', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(3, NULL, 'Parking Slots', 'parking-slots', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/parking-slot.png'),
(4, NULL, 'Rate Chart', 'rate-chart', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/rate-chart.png'),
(5, NULL, 'Payments', 'payments', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/payment.png'),
(6, NULL, 'Policies', 'policies', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(7, NULL, 'Reports', 'reports', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(8, NULL, 'Vendors', 'vendors', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(9, NULL, 'Notifications', 'notifications', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/notification.png'),
(10, 7, 'Car Movements', 'car-movements', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(11, 7, 'Revenue Report', 'revenue-report', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png'),
(12, 7, 'Inventory Report', 'inventory-report', NULL, NULL, NULL, 'http://3.108.121.124/park-prime/park-prime-frontend-admin/images/booking.png');

-- --------------------------------------------------------

--
-- Table structure for table `parkingBusinesses`
--

CREATE TABLE `parkingBusinesses` (
  `id` int NOT NULL,
  `businessName` varchar(255) NOT NULL,
  `noOfGrounds` int NOT NULL,
  `parkingCapacity` int DEFAULT NULL,
  `isAquired` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-Not Aquired, true-Aquired',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `parkingBusinesses`
--

INSERT INTO `parkingBusinesses` (`id`, `businessName`, `noOfGrounds`, `parkingCapacity`, `isAquired`, `isActive`, `deleted_by`, `deleted_at`, `createdAt`, `updatedAt`) VALUES
(1, 'Prime Park', 1, 662, 1, 1, NULL, NULL, '2024-09-16 12:28:11', '2024-09-16 12:28:11');

-- --------------------------------------------------------

--
-- Table structure for table `parkingGrounds`
--

CREATE TABLE `parkingGrounds` (
  `id` int NOT NULL,
  `parkingBusinessId` int NOT NULL,
  `groundName` varchar(255) NOT NULL,
  `noOfLots` int NOT NULL,
  `parkingCapacity` int DEFAULT NULL,
  `isGroundFull` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-Not Full, true-Full',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `parkingGrounds`
--

INSERT INTO `parkingGrounds` (`id`, `parkingBusinessId`, `groundName`, `noOfLots`, `parkingCapacity`, `isGroundFull`, `isActive`, `deleted_by`, `deleted_at`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Park Prime J.F.K. Airport Ground', 14, 662, 0, 1, NULL, NULL, '2024-09-16 12:28:51', '2024-09-16 12:28:51');

-- --------------------------------------------------------

--
-- Table structure for table `parkingLots`
--

CREATE TABLE `parkingLots` (
  `id` int NOT NULL,
  `parkingGroundId` int NOT NULL,
  `lotName` varchar(255) NOT NULL,
  `noOfBays` int NOT NULL,
  `noOfRows` int NOT NULL,
  `bayPosition` enum('L','R','M') NOT NULL DEFAULT 'L',
  `minDays` int NOT NULL,
  `maxDays` int NOT NULL,
  `isLotFull` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-No, true-Yes',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `parkingLots`
--

INSERT INTO `parkingLots` (`id`, `parkingGroundId`, `lotName`, `noOfBays`, `noOfRows`, `bayPosition`, `minDays`, `maxDays`, `isLotFull`, `isActive`, `deleted_by`, `deleted_at`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'F-ST', 2, 7, 'L', 1, 3, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(2, 1, 'I-ST', 1, 17, 'R', 1, 3, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(3, 1, 'H-ST', 2, 3, 'R', 1, 3, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(4, 1, 'G-FM', 2, 1, 'R', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(5, 1, 'E-FM', 3, 5, 'R', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(6, 1, 'D1-FM', 4, 29, 'R', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(7, 1, 'D2-LT', 4, 14, 'R', 15, 9999, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(8, 1, 'B1-LT', 6, 20, 'L', 15, 9999, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(9, 1, 'B2-FM', 6, 20, 'L', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(10, 1, 'B3-FM', 5, 2, 'L', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(11, 1, 'B4-FM', 4, 9, 'L', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(12, 1, 'B5-FM', 3, 8, 'L', 4, 14, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(13, 1, 'C-OF', 1, 30, 'M', 0, 9999, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10'),
(14, 1, 'A1-LT', 6, 15, 'L', 14, 9999, 0, 1, NULL, NULL, '2024-09-24 11:13:10', '2024-09-24 11:13:10');

-- --------------------------------------------------------

--
-- Table structure for table `policies`
--

CREATE TABLE `policies` (
  `id` int NOT NULL,
  `policies` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `policies`
--

INSERT INTO `policies` (`id`, `policies`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '\n\n<h1> Policies</h1>		\n		\n<p>1. Your reservation will be subject to Parking hourly and daily rate as soon as the voucher is expired. The hourly rate is 10/hour and the daily rate is $15 for small cars and $18 for SUV/ Trucks per day.		\n</p>		\n<p>2.This facility does NOT allow in/out privileges. You CANNOT enter & exit more than once. </p>		\n<p>3. For all Cancelled online vouchers/Reservation customers are required to pay for one day of parking and a $10 service fee.</p>		\n<p>4. This facility does not allow online reservation extensions. Additional time must be paid on-site at a regular rate.</p>		\n<p>5. Customer is required to take pictures of their vehicles (all sides) at the location during drop-off and also agree that no damage claim can be filed without providing those pictures.</p>	\n<p>6. Customer must leave the car key  to the attendant and agree that failure to do so may result to towing fees from $75 to $150.</p>	\n<p>7. Customer agree that all balance must be paid in full prior to retrieval of vehicle.</p>	\n\n	', '2024-08-14 11:44:53', '2024-09-09 05:29:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `priceCharts`
--

CREATE TABLE `priceCharts` (
  `id` int NOT NULL,
  `vehicleTypeId` int NOT NULL,
  `dailyParkingRate` double DEFAULT '0',
  `overSizeRate` double DEFAULT '0',
  `lateFees` double DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `priceCharts`
--

INSERT INTO `priceCharts` (`id`, `vehicleTypeId`, `dailyParkingRate`, `overSizeRate`, `lateFees`, `created_at`, `updated_at`, `isActive`, `deleted_at`) VALUES
(35, 52, 400, 400, 900, '2024-09-09 06:02:37', '2024-09-11 10:21:28', 1, NULL),
(37, 54, 60, 30, 30, '2024-09-09 06:02:56', '2024-09-10 13:50:50', 1, NULL),
(39, 56, 90, 50, 60, '2024-09-09 12:11:25', '2024-09-10 13:50:56', 1, NULL),
(40, 57, 100, 200, 170, '2024-09-10 07:27:46', '2024-09-23 09:39:12', 1, NULL),
(41, 58, 100, 30, 40, '2024-09-10 07:35:24', '2024-09-16 07:03:57', 0, '2024-09-16 07:03:49'),
(47, 63, 450, 56, 4, '2024-09-12 13:52:49', '2024-09-16 09:54:43', 0, '2024-09-16 09:26:17'),
(48, 64, 230, 356, 6, '2024-09-12 14:16:49', '2024-09-16 13:30:13', 0, '2024-09-16 10:14:58'),
(49, 65, 45, 3, 55, '2024-09-12 14:18:13', '2024-09-16 07:03:05', 0, '2024-09-16 06:58:20'),
(50, 66, 4334, 4, 45, '2024-09-16 07:02:36', '2024-09-16 07:02:49', 0, '2024-09-16 06:58:20'),
(51, 67, 10, 40, 40, '2024-09-17 09:38:40', '2024-09-17 09:38:45', 0, '2024-09-16 10:14:58'),
(52, 68, 800, 1000, 400, '2024-09-23 08:27:02', '2024-09-23 08:59:35', 0, '2024-09-18 13:50:56'),
(53, 69, 700, 900, 500, '2024-09-23 09:01:32', '2024-09-23 09:44:00', 1, NULL),
(54, 70, 800, 1000, 400, '2024-09-23 10:01:21', '2024-09-23 10:01:21', 1, NULL),
(55, 71, 800, 1000, 400, '2024-09-23 10:03:29', '2024-09-23 10:03:29', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int NOT NULL,
  `roleName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roleName`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super Admin', NULL, NULL, NULL),
(2, 'Agent', NULL, NULL, NULL),
(3, 'Vendor', NULL, NULL, NULL),
(4, 'Customer', NULL, NULL, NULL),
(5, 'Guest', NULL, NULL, NULL),
(6, 'Supervisor', NULL, NULL, NULL),
(7, 'Manager', NULL, NULL, NULL),
(8, 'Corporate', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Sessions`
--

CREATE TABLE `Sessions` (
  `sid` varchar(36) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `sid` varchar(36) COLLATE utf8mb4_general_ci NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text COLLATE utf8mb4_general_ci,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE `slots` (
  `id` int NOT NULL,
  `parkingLotId` int NOT NULL,
  `slotName` varchar(255) NOT NULL,
  `slotBayNumber` int NOT NULL,
  `slotRowNumber` int NOT NULL,
  `occupancyStatus` enum('Vacant','Occupied','Booked','Overstay') NOT NULL DEFAULT 'Vacant',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`id`, `parkingLotId`, `slotName`, `slotBayNumber`, `slotRowNumber`, `occupancyStatus`, `isActive`, `deleted_by`, `deleted_at`, `createdAt`, `updatedAt`) VALUES
(1, 1, '1FOL-1', 1, 1, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(2, 1, '1FOL-2', 2, 1, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(3, 1, '2FOL-1', 1, 2, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(4, 1, '2FOL-2', 2, 2, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(5, 1, '3FOL-1', 1, 3, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(6, 1, '3FOL-2', 2, 3, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(7, 1, '4FOL-1', 1, 4, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(8, 1, '4FOL-2', 2, 4, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(9, 1, '5FOL-1', 1, 5, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(10, 1, '5FOL-2', 2, 5, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(11, 1, '6FOL-1', 1, 6, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(12, 1, '6FOL-2', 2, 6, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(13, 1, '7FOL-1', 1, 7, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(14, 1, '7FOL-2', 2, 7, 'Vacant', 1, NULL, NULL, '2024-09-17 15:18:24', '2024-09-17 15:18:24'),
(32, 2, 'FOR-1', 1, 1, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(33, 2, 'FOR-2', 1, 2, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(34, 2, 'FOR-3', 1, 3, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(35, 2, 'FOR-4', 1, 4, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(36, 2, 'FOR-5', 1, 5, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(37, 2, 'FOR-6', 1, 6, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(38, 2, 'FOR-7', 1, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(39, 2, 'FOR-8', 1, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(40, 2, 'FOR-9', 1, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(41, 2, 'FOR-10', 1, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(42, 2, 'FOR-11', 1, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(43, 2, 'FOR-12', 1, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(44, 2, 'FOR-13', 1, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(45, 2, 'FOR-14', 1, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(46, 2, 'FOR-15', 1, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(47, 2, 'FOR-16', 1, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(48, 2, 'FOR-17', 1, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 12:51:27', '2024-09-23 12:51:27'),
(49, 3, '1FOR-18', 1, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(50, 3, '2FOR-18', 2, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(51, 3, '1FOR-19', 1, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(52, 3, '2FOR-19', 2, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(53, 3, '1FOR-20', 1, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(54, 3, '2FOR-20', 2, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:26:16', '2024-09-23 13:26:16'),
(55, 4, '1R-1', 1, 1, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:09', '2024-09-23 13:32:09'),
(56, 4, '1R-2', 2, 1, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:09', '2024-09-23 13:32:09'),
(57, 5, '2R-1', 1, 2, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(58, 5, '3R-1', 1, 3, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(59, 5, '4R-1', 1, 4, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(60, 5, '5R-1', 1, 5, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(61, 5, '6R-1', 1, 6, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(62, 5, '2R-2', 2, 2, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(63, 5, '3R-2', 2, 3, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(64, 5, '4R-2', 2, 4, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(65, 5, '5R-2', 2, 5, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(66, 5, '6R-2', 2, 6, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(67, 5, '2R-3', 3, 2, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(68, 5, '3R-3', 3, 3, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(69, 5, '4R-3', 3, 4, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(70, 5, '5R-3', 3, 5, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(71, 5, '6R-3', 3, 6, 'Vacant', 1, NULL, NULL, '2024-09-23 11:57:26', '2024-09-23 11:57:26'),
(72, 6, '7R-1', 1, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(73, 6, '8R-1', 1, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(74, 6, '9R-1', 1, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(75, 6, '10R-1', 1, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(76, 6, '7R-2', 2, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(77, 6, '8R-2', 2, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(78, 6, '9R-2', 2, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(79, 6, '10R-2', 2, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(80, 6, '7R-3', 3, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(81, 6, '8R-3', 3, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(82, 6, '9R-3', 3, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(83, 6, '10R-3', 3, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(84, 6, '7R-4', 4, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(85, 6, '8R-4', 4, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(86, 6, '9R-4', 4, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(87, 6, '10R-4', 4, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:02', '2024-09-23 13:03:02'),
(88, 6, '11R-1', 1, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(89, 6, '12R-1', 1, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(90, 6, '13R-1', 1, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(91, 6, '14R-1', 1, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(92, 6, '15R-1', 1, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(93, 6, '16R-1', 1, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(94, 6, '17R-1', 1, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(95, 6, '18R-1', 1, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(96, 6, '19R-1', 1, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(97, 6, '20R-1', 1, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(98, 6, '21R-1', 1, 21, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(99, 6, '22R-1', 1, 22, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(100, 6, '23R-1', 1, 23, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(101, 6, '24R-1', 1, 24, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(102, 6, '25R-1', 1, 25, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(103, 6, '26R-1', 1, 26, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(104, 6, '27R-1', 1, 27, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(105, 6, '28R-1', 1, 28, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(106, 6, '29R-1', 1, 29, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(107, 6, '30R-1', 1, 30, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(108, 6, '31R-1', 1, 31, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(109, 6, '32R-1', 1, 32, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(110, 6, '33R-1', 1, 33, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(111, 6, '34R-1', 1, 34, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(112, 6, '35R-1', 1, 35, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(113, 6, '11R-2', 2, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(114, 6, '12R-2', 2, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(115, 6, '13R-2', 2, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(116, 6, '14R-2', 2, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(117, 6, '15R-2', 2, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(118, 6, '16R-2', 2, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(119, 6, '17R-2', 2, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(120, 6, '18R-2', 2, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(121, 6, '19R-2', 2, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(122, 6, '20R-2', 2, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(123, 6, '21R-2', 2, 21, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(124, 6, '22R-2', 2, 22, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(125, 6, '23R-2', 2, 23, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(126, 6, '24R-2', 2, 24, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(127, 6, '25R-2', 2, 25, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(128, 6, '26R-2', 2, 26, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(129, 6, '27R-2', 2, 27, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(130, 6, '28R-2', 2, 28, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(131, 6, '29R-2', 2, 29, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(132, 6, '30R-2', 2, 30, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(133, 6, '31R-2', 2, 31, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(134, 6, '32R-2', 2, 32, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(135, 6, '33R-2', 2, 33, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(136, 6, '34R-2', 2, 34, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(137, 6, '35R-2', 2, 35, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(138, 6, '11R-3', 3, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(139, 6, '12R-3', 3, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(140, 6, '13R-3', 3, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(141, 6, '14R-3', 3, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(142, 6, '15R-3', 3, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(143, 6, '16R-3', 3, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(144, 6, '17R-3', 3, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(145, 6, '18R-3', 3, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(146, 6, '19R-3', 3, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(147, 6, '20R-3', 3, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(148, 6, '21R-3', 3, 21, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(149, 6, '22R-3', 3, 22, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(150, 6, '23R-3', 3, 23, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(151, 6, '24R-3', 3, 24, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(152, 6, '25R-3', 3, 25, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(153, 6, '26R-3', 3, 26, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(154, 6, '27R-3', 3, 27, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(155, 6, '28R-3', 3, 28, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(156, 6, '29R-3', 3, 29, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(157, 6, '30R-3', 3, 30, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(158, 6, '31R-3', 3, 31, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(159, 6, '32R-3', 3, 32, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(160, 6, '33R-3', 3, 33, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(161, 6, '34R-3', 3, 34, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(162, 6, '35R-3', 3, 35, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(163, 6, '11R-4', 4, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(164, 6, '12R-4', 4, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(165, 6, '13R-4', 4, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(166, 6, '14R-4', 4, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(167, 6, '15R-4', 4, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(168, 6, '16R-4', 4, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(169, 6, '17R-4', 4, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(170, 6, '18R-4', 4, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(171, 6, '19R-4', 4, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(172, 6, '20R-4', 4, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(173, 6, '21R-4', 4, 21, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(174, 6, '22R-4', 4, 22, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(175, 6, '23R-4', 4, 23, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(176, 6, '24R-4', 4, 24, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(177, 6, '25R-4', 4, 25, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(178, 6, '26R-4', 4, 26, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(179, 6, '27R-4', 4, 27, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(180, 6, '28R-4', 4, 28, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(181, 6, '29R-4', 4, 29, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(182, 6, '30R-4', 4, 30, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(183, 6, '31R-4', 4, 31, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(184, 6, '32R-4', 4, 32, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(185, 6, '33R-4', 4, 33, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(186, 6, '34R-4', 4, 34, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(187, 6, '35R-4', 4, 35, 'Vacant', 1, NULL, NULL, '2024-09-23 13:03:25', '2024-09-23 13:03:25'),
(188, 7, '36R-1', 1, 36, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(189, 7, '37R-1', 1, 37, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(190, 7, '38R-1', 1, 38, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(191, 7, '39R-1', 1, 39, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(192, 7, '40R-1', 1, 40, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(193, 7, '41R-1', 1, 41, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(194, 7, '42R-1', 1, 42, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(195, 7, '43R-1', 1, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(196, 7, '44R-1', 1, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(197, 7, '45R-1', 1, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(198, 7, '46R-1', 1, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(199, 7, '47R-1', 1, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(200, 7, '48R-1', 1, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(201, 7, '49R-1', 1, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(202, 7, '36R-2', 2, 36, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(203, 7, '37R-2', 2, 37, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(204, 7, '38R-2', 2, 38, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(205, 7, '39R-2', 2, 39, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(206, 7, '40R-2', 2, 40, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(207, 7, '41R-2', 2, 41, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(208, 7, '42R-2', 2, 42, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(209, 7, '43R-2', 2, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(210, 7, '44R-2', 2, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(211, 7, '45R-2', 2, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(212, 7, '46R-2', 2, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(213, 7, '47R-2', 2, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(214, 7, '48R-2', 2, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(215, 7, '49R-2', 2, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(216, 7, '36R-3', 3, 36, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(217, 7, '37R-3', 3, 37, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(218, 7, '38R-3', 3, 38, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(219, 7, '39R-3', 3, 39, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(220, 7, '40R-3', 3, 40, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(221, 7, '41R-3', 3, 41, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(222, 7, '42R-3', 3, 42, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(223, 7, '43R-3', 3, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(224, 7, '44R-3', 3, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(225, 7, '45R-3', 3, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(226, 7, '46R-3', 3, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(227, 7, '47R-3', 3, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(228, 7, '48R-3', 3, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(229, 7, '49R-3', 3, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(230, 7, '36R-4', 4, 36, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(231, 7, '37R-4', 4, 37, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(232, 7, '38R-4', 4, 38, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(233, 7, '39R-4', 4, 39, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(234, 7, '40R-4', 4, 40, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(235, 7, '41R-4', 4, 41, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(236, 7, '42R-4', 4, 42, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(237, 7, '43R-4', 4, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(238, 7, '44R-4', 4, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(239, 7, '45R-4', 4, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(240, 7, '46R-4', 4, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(241, 7, '47R-4', 4, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(242, 7, '48R-4', 4, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(243, 7, '49R-4', 4, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:04:44', '2024-09-23 13:04:44'),
(244, 8, '43L-1', 1, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(245, 8, '44L-1', 1, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(246, 8, '45L-1', 1, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(247, 8, '46L-1', 1, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(248, 8, '47L-1', 1, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(249, 8, '48L-1', 1, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(250, 8, '49L-1', 1, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(251, 8, '50L-1', 1, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(252, 8, '51L-1', 1, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(253, 8, '52L-1', 1, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(254, 8, '53L-1', 1, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(255, 8, '54L-1', 1, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(256, 8, '55L-1', 1, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(257, 8, '56L-1', 1, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(258, 8, '57L-1', 1, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(259, 8, '58L-1', 1, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(260, 8, '59L-1', 1, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(261, 8, '60L-1', 1, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(262, 8, '61L-1', 1, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(263, 8, '62L-1', 1, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(264, 8, '43L-2', 2, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(265, 8, '44L-2', 2, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(266, 8, '45L-2', 2, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(267, 8, '46L-2', 2, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(268, 8, '47L-2', 2, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(269, 8, '48L-2', 2, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(270, 8, '49L-2', 2, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(271, 8, '50L-2', 2, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(272, 8, '51L-2', 2, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(273, 8, '52L-2', 2, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(274, 8, '53L-2', 2, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(275, 8, '54L-2', 2, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(276, 8, '55L-2', 2, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(277, 8, '56L-2', 2, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(278, 8, '57L-2', 2, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(279, 8, '58L-2', 2, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(280, 8, '59L-2', 2, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(281, 8, '60L-2', 2, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(282, 8, '61L-2', 2, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(283, 8, '62L-2', 2, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(284, 8, '43L-3', 3, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(285, 8, '44L-3', 3, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(286, 8, '45L-3', 3, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(287, 8, '46L-3', 3, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(288, 8, '47L-3', 3, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(289, 8, '48L-3', 3, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(290, 8, '49L-3', 3, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(291, 8, '50L-3', 3, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(292, 8, '51L-3', 3, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(293, 8, '52L-3', 3, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(294, 8, '53L-3', 3, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(295, 8, '54L-3', 3, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(296, 8, '55L-3', 3, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(297, 8, '56L-3', 3, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(298, 8, '57L-3', 3, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(299, 8, '58L-3', 3, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(300, 8, '59L-3', 3, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(301, 8, '60L-3', 3, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(302, 8, '61L-3', 3, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(303, 8, '62L-3', 3, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(304, 8, '43L-4', 4, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(305, 8, '44L-4', 4, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(306, 8, '45L-4', 4, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(307, 8, '46L-4', 4, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(308, 8, '47L-4', 4, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(309, 8, '48L-4', 4, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(310, 8, '49L-4', 4, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(311, 8, '50L-4', 4, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(312, 8, '51L-4', 4, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(313, 8, '52L-4', 4, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(314, 8, '53L-4', 4, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(315, 8, '54L-4', 4, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(316, 8, '55L-4', 4, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(317, 8, '56L-4', 4, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(318, 8, '57L-4', 4, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(319, 8, '58L-4', 4, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(320, 8, '59L-4', 4, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(321, 8, '60L-4', 4, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(322, 8, '61L-4', 4, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(323, 8, '62L-4', 4, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(324, 8, '43L-5', 5, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(325, 8, '44L-5', 5, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(326, 8, '45L-5', 5, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(327, 8, '46L-5', 5, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(328, 8, '47L-5', 5, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(329, 8, '48L-5', 5, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(330, 8, '49L-5', 5, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(331, 8, '50L-5', 5, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(332, 8, '51L-5', 5, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(333, 8, '52L-5', 5, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(334, 8, '53L-5', 5, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(335, 8, '54L-5', 5, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(336, 8, '55L-5', 5, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(337, 8, '56L-5', 5, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(338, 8, '57L-5', 5, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(339, 8, '58L-5', 5, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(340, 8, '59L-5', 5, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(341, 8, '60L-5', 5, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(342, 8, '61L-5', 5, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(343, 8, '62L-5', 5, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(344, 8, '43L-6', 6, 43, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(345, 8, '44L-6', 6, 44, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(346, 8, '45L-6', 6, 45, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(347, 8, '46L-6', 6, 46, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(348, 8, '47L-6', 6, 47, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(349, 8, '48L-6', 6, 48, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(350, 8, '49L-6', 6, 49, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(351, 8, '50L-6', 6, 50, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(352, 8, '51L-6', 6, 51, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(353, 8, '52L-6', 6, 52, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(354, 8, '53L-6', 6, 53, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(355, 8, '54L-6', 6, 54, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(356, 8, '55L-6', 6, 55, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(357, 8, '56L-6', 6, 56, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(358, 8, '57L-6', 6, 57, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(359, 8, '58L-6', 6, 58, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(360, 8, '59L-6', 6, 59, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(361, 8, '60L-6', 6, 60, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(362, 8, '61L-6', 6, 61, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(363, 8, '62L-6', 6, 62, 'Vacant', 1, NULL, NULL, '2024-09-23 13:10:24', '2024-09-23 13:10:24'),
(364, 9, '63L-1', 1, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(365, 9, '64L-1', 1, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(366, 9, '65L-1', 1, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(367, 9, '66L-1', 1, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(368, 9, '67L-1', 1, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(369, 9, '68L-1', 1, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(370, 9, '69L-1', 1, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(371, 9, '70L-1', 1, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(372, 9, '71L-1', 1, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(373, 9, '72L-1', 1, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(374, 9, '73L-1', 1, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(375, 9, '74L-1', 1, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(376, 9, '75L-1', 1, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(377, 9, '76L-1', 1, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(378, 9, '77L-1', 1, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(379, 9, '78L-1', 1, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(380, 9, '79L-1', 1, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(381, 9, '80L-1', 1, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(382, 9, '81L-1', 1, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(383, 9, '82L-1', 1, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(384, 9, '83L-1', 1, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(385, 9, '63L-2', 2, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(386, 9, '64L-2', 2, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(387, 9, '65L-2', 2, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(388, 9, '66L-2', 2, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(389, 9, '67L-2', 2, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(390, 9, '68L-2', 2, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(391, 9, '69L-2', 2, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(392, 9, '70L-2', 2, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(393, 9, '71L-2', 2, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(394, 9, '72L-2', 2, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(395, 9, '73L-2', 2, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(396, 9, '74L-2', 2, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(397, 9, '75L-2', 2, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(398, 9, '76L-2', 2, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(399, 9, '77L-2', 2, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(400, 9, '78L-2', 2, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(401, 9, '79L-2', 2, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(402, 9, '80L-2', 2, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(403, 9, '81L-2', 2, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(404, 9, '82L-2', 2, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(405, 9, '83L-2', 2, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(406, 9, '63L-3', 3, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(407, 9, '64L-3', 3, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(408, 9, '65L-3', 3, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(409, 9, '66L-3', 3, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(410, 9, '67L-3', 3, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(411, 9, '68L-3', 3, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(412, 9, '69L-3', 3, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(413, 9, '70L-3', 3, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(414, 9, '71L-3', 3, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(415, 9, '72L-3', 3, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(416, 9, '73L-3', 3, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(417, 9, '74L-3', 3, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(418, 9, '75L-3', 3, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(419, 9, '76L-3', 3, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(420, 9, '77L-3', 3, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(421, 9, '78L-3', 3, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(422, 9, '79L-3', 3, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(423, 9, '80L-3', 3, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(424, 9, '81L-3', 3, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(425, 9, '82L-3', 3, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(426, 9, '83L-3', 3, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(427, 9, '63L-4', 4, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(428, 9, '64L-4', 4, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(429, 9, '65L-4', 4, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(430, 9, '66L-4', 4, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(431, 9, '67L-4', 4, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(432, 9, '68L-4', 4, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(433, 9, '69L-4', 4, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(434, 9, '70L-4', 4, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(435, 9, '71L-4', 4, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(436, 9, '72L-4', 4, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(437, 9, '73L-4', 4, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(438, 9, '74L-4', 4, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(439, 9, '75L-4', 4, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(440, 9, '76L-4', 4, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(441, 9, '77L-4', 4, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(442, 9, '78L-4', 4, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(443, 9, '79L-4', 4, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(444, 9, '80L-4', 4, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(445, 9, '81L-4', 4, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(446, 9, '82L-4', 4, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(447, 9, '83L-4', 4, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(448, 9, '63L-5', 5, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(449, 9, '64L-5', 5, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(450, 9, '65L-5', 5, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(451, 9, '66L-5', 5, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(452, 9, '67L-5', 5, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(453, 9, '68L-5', 5, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(454, 9, '69L-5', 5, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(455, 9, '70L-5', 5, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(456, 9, '71L-5', 5, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(457, 9, '72L-5', 5, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(458, 9, '73L-5', 5, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(459, 9, '74L-5', 5, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(460, 9, '75L-5', 5, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(461, 9, '76L-5', 5, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(462, 9, '77L-5', 5, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(463, 9, '78L-5', 5, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(464, 9, '79L-5', 5, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(465, 9, '80L-5', 5, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(466, 9, '81L-5', 5, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(467, 9, '82L-5', 5, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(468, 9, '83L-5', 5, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(469, 9, '63L-6', 6, 63, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(470, 9, '64L-6', 6, 64, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(471, 9, '65L-6', 6, 65, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(472, 9, '66L-6', 6, 66, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(473, 9, '67L-6', 6, 67, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(474, 9, '68L-6', 6, 68, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(475, 9, '69L-6', 6, 69, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(476, 9, '70L-6', 6, 70, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(477, 9, '71L-6', 6, 71, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(478, 9, '72L-6', 6, 72, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(479, 9, '73L-6', 6, 73, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(480, 9, '74L-6', 6, 74, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(481, 9, '75L-6', 6, 75, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(482, 9, '76L-6', 6, 76, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(483, 9, '77L-6', 6, 77, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(484, 9, '78L-6', 6, 78, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(485, 9, '79L-6', 6, 79, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(486, 9, '80L-6', 6, 80, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(487, 9, '81L-6', 6, 81, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(488, 9, '82L-6', 6, 82, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(489, 9, '83L-6', 6, 83, 'Vacant', 1, NULL, NULL, '2024-09-23 13:11:55', '2024-09-23 13:11:55'),
(490, 10, '84L-1', 1, 84, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(491, 10, '85L-1', 1, 85, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(492, 10, '84L-2', 2, 84, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(493, 10, '85L-2', 2, 85, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(494, 10, '84L-3', 3, 84, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(495, 10, '85L-3', 3, 85, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(496, 10, '84L-4', 4, 84, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(497, 10, '85L-4', 4, 85, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(498, 10, '84L-5', 5, 84, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(499, 10, '85L-5', 5, 85, 'Vacant', 1, NULL, NULL, '2024-09-23 13:31:12', '2024-09-23 13:31:12'),
(500, 11, '86L-1', 1, 86, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(501, 11, '87L-1', 1, 87, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(502, 11, '88L-1', 1, 88, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(503, 11, '89L-1', 1, 89, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(504, 11, '90L-1', 1, 90, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(505, 11, '91L-1', 1, 91, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(506, 11, '92L-1', 1, 92, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(507, 11, '93L-1', 1, 93, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(508, 11, '94L-1', 1, 94, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(509, 11, '86L-2', 2, 86, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(510, 11, '87L-2', 2, 87, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(511, 11, '88L-2', 2, 88, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(512, 11, '89L-2', 2, 89, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(513, 11, '90L-2', 2, 90, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(514, 11, '91L-2', 2, 91, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(515, 11, '92L-2', 2, 92, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(516, 11, '93L-2', 2, 93, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(517, 11, '94L-2', 2, 94, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(518, 11, '86L-3', 3, 86, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(519, 11, '87L-3', 3, 87, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(520, 11, '88L-3', 3, 88, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(521, 11, '89L-3', 3, 89, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(522, 11, '90L-3', 3, 90, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(523, 11, '91L-3', 3, 91, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(524, 11, '92L-3', 3, 92, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(525, 11, '93L-3', 3, 93, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(526, 11, '94L-3', 3, 94, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(527, 11, '86L-4', 4, 86, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(528, 11, '87L-4', 4, 87, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(529, 11, '88L-4', 4, 88, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(530, 11, '89L-4', 4, 89, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(531, 11, '90L-4', 4, 90, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(532, 11, '91L-4', 4, 91, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(533, 11, '92L-4', 4, 92, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(534, 11, '93L-4', 4, 93, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(535, 11, '94L-4', 4, 94, 'Vacant', 1, NULL, NULL, '2024-09-23 13:32:11', '2024-09-23 13:32:11'),
(536, 12, '95L-1', 1, 95, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(537, 12, '96L-1', 1, 96, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(538, 12, '97L-1', 1, 97, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(539, 12, '98L-1', 1, 98, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(540, 12, '99L-1', 1, 99, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(541, 12, '100L-1', 1, 100, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(542, 12, '101L-1', 1, 101, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26');
INSERT INTO `slots` (`id`, `parkingLotId`, `slotName`, `slotBayNumber`, `slotRowNumber`, `occupancyStatus`, `isActive`, `deleted_by`, `deleted_at`, `createdAt`, `updatedAt`) VALUES
(543, 12, '102L-1', 1, 102, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(544, 12, '95L-2', 2, 95, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(545, 12, '96L-2', 2, 96, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(546, 12, '97L-2', 2, 97, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(547, 12, '98L-2', 2, 98, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(548, 12, '99L-2', 2, 99, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(549, 12, '100L-2', 2, 100, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(550, 12, '101L-2', 2, 101, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(551, 12, '102L-2', 2, 102, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(552, 12, '95L-3', 3, 95, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(553, 12, '96L-3', 3, 96, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(554, 12, '97L-3', 3, 97, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(555, 12, '98L-3', 3, 98, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(556, 12, '99L-3', 3, 99, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(557, 12, '100L-3', 3, 100, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(558, 12, '101L-3', 3, 101, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(559, 12, '102L-3', 3, 102, 'Vacant', 1, NULL, NULL, '2024-09-23 13:34:26', '2024-09-23 13:34:26'),
(560, 13, 'C-1', 1, 1, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(561, 13, 'C-2', 1, 2, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(562, 13, 'C-3', 1, 3, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(563, 13, 'C-4', 1, 4, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(564, 13, 'C-5', 1, 5, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(565, 13, 'C-6', 1, 6, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(566, 13, 'C-7', 1, 7, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(567, 13, 'C-8', 1, 8, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(568, 13, 'C-9', 1, 9, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(569, 13, 'C-10', 1, 10, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(570, 13, 'C-11', 1, 11, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(571, 13, 'C-12', 1, 12, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(572, 13, 'C-13', 1, 13, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(573, 13, 'C-14', 1, 14, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(574, 13, 'C-15', 1, 15, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(575, 13, 'C-16', 1, 16, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(576, 13, 'C-17', 1, 17, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(577, 13, 'C-18', 1, 18, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(578, 13, 'C-19', 1, 19, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(579, 13, 'C-20', 1, 20, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(580, 13, 'C-21', 1, 21, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(581, 13, 'C-22', 1, 22, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(582, 13, 'C-23', 1, 23, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(583, 13, 'C-24', 1, 24, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(584, 13, 'C-25', 1, 25, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(585, 13, 'C-26', 1, 26, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(586, 13, 'C-27', 1, 27, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(587, 13, 'C-28', 1, 28, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(588, 13, 'C-29', 1, 29, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(589, 13, 'C-30', 1, 30, 'Vacant', 1, NULL, NULL, '2024-09-23 15:38:19', '2024-09-23 15:38:19'),
(590, 14, '28L-1', 1, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(591, 14, '29L-1', 1, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(592, 14, '30L-1', 1, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(593, 14, '31L-1', 1, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(594, 14, '32L-1', 1, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(595, 14, '33L-1', 1, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(596, 14, '34L-1', 1, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(597, 14, '35L-1', 1, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(598, 14, '36L-1', 1, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(599, 14, '37L-1', 1, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(600, 14, '38L-1', 1, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(601, 14, '39L-1', 1, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(602, 14, '40L-1', 1, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(603, 14, '41L-1', 1, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(604, 14, '42L-1', 1, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(605, 14, '28L-2', 2, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(606, 14, '29L-2', 2, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(607, 14, '30L-2', 2, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(608, 14, '31L-2', 2, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(609, 14, '32L-2', 2, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(610, 14, '33L-2', 2, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(611, 14, '34L-2', 2, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(612, 14, '35L-2', 2, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(613, 14, '36L-2', 2, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(614, 14, '37L-2', 2, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(615, 14, '38L-2', 2, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(616, 14, '39L-2', 2, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(617, 14, '40L-2', 2, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(618, 14, '41L-2', 2, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(619, 14, '42L-2', 2, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(620, 14, '28L-3', 3, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(621, 14, '29L-3', 3, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(622, 14, '30L-3', 3, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(623, 14, '31L-3', 3, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:40', '2024-09-24 09:17:40'),
(624, 14, '32L-3', 3, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(625, 14, '33L-3', 3, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(626, 14, '34L-3', 3, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(627, 14, '35L-3', 3, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(628, 14, '36L-3', 3, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(629, 14, '37L-3', 3, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(630, 14, '38L-3', 3, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(631, 14, '39L-3', 3, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(632, 14, '40L-3', 3, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(633, 14, '41L-3', 3, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(634, 14, '42L-3', 3, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(635, 14, '28L-4', 4, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(636, 14, '29L-4', 4, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(637, 14, '30L-4', 4, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(638, 14, '31L-4', 4, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(639, 14, '32L-4', 4, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(640, 14, '33L-4', 4, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(641, 14, '34L-4', 4, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(642, 14, '35L-4', 4, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(643, 14, '36L-4', 4, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(644, 14, '37L-4', 4, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(645, 14, '38L-4', 4, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(646, 14, '39L-4', 4, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(647, 14, '40L-4', 4, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(648, 14, '41L-4', 4, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(649, 14, '42L-4', 4, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(650, 14, '28L-5', 5, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(651, 14, '29L-5', 5, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(652, 14, '30L-5', 5, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(653, 14, '31L-5', 5, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(654, 14, '32L-5', 5, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(655, 14, '33L-5', 5, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(656, 14, '34L-5', 5, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(657, 14, '35L-5', 5, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(658, 14, '36L-5', 5, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(659, 14, '37L-5', 5, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(660, 14, '38L-5', 5, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(661, 14, '39L-5', 5, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(662, 14, '40L-5', 5, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(663, 14, '41L-5', 5, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(664, 14, '42L-5', 5, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(665, 14, '28L-6', 6, 28, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(666, 14, '29L-6', 6, 29, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(667, 14, '30L-6', 6, 30, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(668, 14, '31L-6', 6, 31, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(669, 14, '32L-6', 6, 32, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(670, 14, '33L-6', 6, 33, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(671, 14, '34L-6', 6, 34, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(672, 14, '35L-6', 6, 35, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(673, 14, '36L-6', 6, 36, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(674, 14, '37L-6', 6, 37, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(675, 14, '38L-6', 6, 38, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(676, 14, '39L-6', 6, 39, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(677, 14, '40L-6', 6, 40, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(678, 14, '41L-6', 6, 41, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41'),
(679, 14, '42L-6', 6, 42, 'Vacant', 1, NULL, NULL, '2024-09-24 09:17:41', '2024-09-24 09:17:41');

-- --------------------------------------------------------

--
-- Table structure for table `staticCharges`
--

CREATE TABLE `staticCharges` (
  `id` int NOT NULL,
  `parkingGroundId` int NOT NULL,
  `reservationCharge` double DEFAULT '0',
  `defaultPassengerCount` int DEFAULT '0',
  `extraPassengerChargePerHead` double DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `staticCharges`
--

INSERT INTO `staticCharges` (`id`, `parkingGroundId`, `reservationCharge`, `defaultPassengerCount`, `extraPassengerChargePerHead`, `created_at`, `updated_at`, `isActive`, `deleted_at`) VALUES
(1, 1, 25, 4, 10, NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `roleId` int NOT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `dialCode` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Others') COLLATE utf8mb4_general_ci DEFAULT 'Others',
  `profileImage` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` mediumtext COLLATE utf8mb4_general_ci,
  `webLogin` text COLLATE utf8mb4_general_ci,
  `appLogin` text COLLATE utf8mb4_general_ci,
  `fcmToken` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `OTP` int DEFAULT NULL,
  `macAddress` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'MAC Address of Currently Logged In Device',
  `loginFlag` tinyint(1) DEFAULT '0' COMMENT 'false-Off, true-On',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `isVerified` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-No, true-Yes',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deviceId` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Device ID of device being used; For mobile devices only.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `roleId`, `firstName`, `lastName`, `email`, `dialCode`, `phone`, `password`, `dob`, `gender`, `profileImage`, `address`, `webLogin`, `appLogin`, `fcmToken`, `OTP`, `macAddress`, `loginFlag`, `isActive`, `isVerified`, `created_at`, `updated_at`, `deleted_by`, `deleted_at`, `deviceId`) VALUES
(1, 1, 'Super', 'Admin', 'superadmin@parkprime.com', '1', '1111111111', '$2y$10$BvYpPsPVpbBH.3aoSV/3.Ouf.vc85E4czl1V2J/WP5a82Ne.inGPi', NULL, 'Others', NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sZUlkIjoxLCJmaXJzdE5hbWUiOiJTdXBlciIsImxhc3ROYW1lIjoiQWRtaW4iLCJlbWFpbCI6InN1cGVyYWRtaW5AcGFya3ByaW1lLmNvbSIsInBob25lIjoiMTExMTExMTExMSIsImRldmljZVR5cGUiOjIsIm1hY0FkZHJlc3MiOiIwYTpiYzplZTpiNDo1Mjo5MCIsImlhdCI6MTcyNzc3MDIxNiwiZXhwIjoxNzMwMzYyMjE2fQ.-EMQJFxCi-mMlEIkgpRD7YlxO7b2eixLO5xBxNnrSBA', '', 'askhdaklsjdnklasdlk', NULL, '0a:bc:ee:b4:52:90', 1, 1, 1, NULL, '2024-10-01 08:10:16', NULL, NULL, NULL),
(2, 1, 'Diksha ', 'Mehta', 'super.admin@abc.com', '+1', '7908285667', '$2a$10$NiAbJOAJBcMo0EqY6lSimucWeVnqbk/tA9oIkkmZA0veaDNI/X4re', '2024-08-26', 'Male', '1724673707281Group 7.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:01:47', '2024-08-26 12:01:47', NULL, NULL, NULL),
(3, 1, 'Diksha ', 'Mehta', 'superssdmin@yopmail.com', '+1', '7908285661', '$2a$10$Ndo0pyu4XRbmdWeYi7V7/OefA1R9l0vYyiiQjR3v4UlgQd7APUYwC', '2024-08-26', 'Male', '1724673813489instagram (3).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:03:34', '2024-08-26 12:03:34', NULL, NULL, NULL),
(4, 1, 'Diksha ', 'Mehta', 'superssdmin1@yopmail.com', '+1', '7908285660', '$2a$10$0wPPGqnlyifAalrJIgk09.J70MztZwq8nCmDQ5GJiKgzhYI74lYLW', '2024-08-26', 'Male', '1724673918678instagram (3).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:05:18', '2024-08-26 12:05:18', NULL, NULL, NULL),
(5, 1, 'Diksha ', 'Mehta', 'superssdmin2@yopmail.com', '+1', '7908285610', '$2a$10$9HE34xo90Ks5Y9YYn1p0G.fdFQ8IDSmjpiOsKg3i.vg7ouBBbC0Wm', '2024-08-26', 'Male', '1724673958521instagram (3).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:05:58', '2024-08-26 12:05:58', NULL, NULL, NULL),
(6, 1, 'Diksha ', 'Mehta', 'superssdmin3@yopmail.com', '+1', '7908282661', '$2a$10$/BmCnS1lEJD6sUSUITDpu.1UqmjP5AlEIKZip2QoRlzSVwWQrHO76', '2024-08-26', 'Male', '1724674086353Group 7.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:08:07', '2024-08-26 12:08:07', NULL, NULL, NULL),
(7, 1, 'Diksha ', 'Mehta', 'dikshamehta.dev@gmail.com', '+44', '1234567890', '$2a$10$IdZTw3lfOWnXCM3IJFaI8OQ8/gXELJHoQSVNZ7RdhGuUkqvm6Y602', '2024-08-09', 'Female', '1724674535722icon (1).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-26 12:15:35', '2024-08-26 12:15:35', NULL, NULL, NULL),
(8, 2, 'Shyam edit again', 'Employee', 'se@gmail.com', '1', '9999999990', '$2a$10$f5RxGCNyKCVUw7q1AZLUJe6LFsKqbILB/rswAK./FVD.vObO6qaji', '2024-08-09', 'Male', '1724726935669facebook (1).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-27 02:48:56', '2024-09-17 10:41:23', 1, '2024-09-16 07:03:49', NULL),
(9, 1, 'Diksha ', 'Mehta', 'chotidiksha719@gmail.com', '+44', '8987678767', '$2a$10$cYk59RRb8a/1OA7qG1mIquEWJH3u1j2WUtFXaSKXxfZK1ZfHzfeza', '2024-08-07', 'Female', '1724730488692email.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 03:48:09', '2024-08-27 03:48:09', NULL, NULL, NULL),
(10, 1, 'diksha', 'mehta', 'ekataguha@gmail.com', '+33', '9090909090', '$2a$10$kbmZmXl7ydrxsPm4RvngP.HyEBEpG80vy5hr6dgW/ydmzSLoSx8gG', '2024-08-06', 'Female', NULL, 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 06:05:23', '2024-08-27 06:05:23', NULL, NULL, NULL),
(11, 1, 'ram', 'mehta', 'admin@gmail.com', '+33', '1234567654', '$2a$10$szHCALoTQbR1tF0TnHchNuusosQhzb8VaMnlZg2kXlUwDcFv568by', '2024-08-01', 'Male', '1724749472141Group (6).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 09:04:32', '2024-08-27 09:04:32', NULL, NULL, NULL),
(12, 1, 'Shyam', 'Mehra', 'shyamradmin@gmail.com', '+1', '9876543256', '$2a$10$CyQwDdYphmlnYlbLRcXCouMnhx8hZUdG6yeSOUOEZF.kZMrh.9ruC', '2021-08-18', 'Male', '1724749540271Group (6).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 09:05:40', '2024-08-27 09:05:40', NULL, NULL, NULL),
(13, 1, 'ram', 'mehta', 'admin@sft.com', '+33', '9876543259', '$2a$10$kjeJQeC4yVM6AuQA/Z8ROusvQaS93YRWS4kEJEt7cy4xtcNSj2y7y', '2024-08-01', 'Male', '1724754980967Group (6).png', 'hdhsht', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 10:36:21', '2024-08-27 10:36:21', NULL, NULL, NULL),
(14, 1, 'ram', 'mehta', 'superain@gmail.com', '+44', '1234567684', '$2a$10$H3hzJmk9RqttigCR18N3SeheO7ILM8vx2323AGQL9kpBMRGa67yiK', '2024-08-01', 'Female', '1724758820238Group (6).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 11:40:20', '2024-08-27 11:40:20', NULL, NULL, NULL),
(15, 1, 'Shyam', 'Mehta', 'abc1@gmail.com', '+91', '2345678923', '$2a$10$hj0ubkzpa651OFOMD90RWun1XuEFlSdDc5uA/mAGfnviwjko7L7y.', '2024-08-01', 'Male', '1724759990735Group (6).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 11:59:50', '2024-08-27 11:59:50', NULL, NULL, NULL),
(16, 1, 'Harsh', 'Mehta', 'abc3@gmail.com', '+91', '2345676923', '$2a$10$Y0QJXhjPt6tlqvst.oI2i.qUKio0uf21RHhA3p5s6yBtc7TAddMGy', '2024-08-01', 'Male', '1724760145481Group (6).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 12:02:25', '2024-08-27 12:02:25', NULL, NULL, NULL),
(17, 1, 'Shyam', 'mehta', 'diksha.mehta@shyamfuture.com', '+44', '9876543258', '$2a$10$Ico1ZSPKo8HEXf5ygOLMXeDogcwtXnj0xzzLlvtfnvkWnqM4mO30S', '2024-08-01', 'Female', '1724760432429Group (6).png', 'hdhsht', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 12:07:12', '2024-08-27 12:07:12', NULL, NULL, NULL),
(18, 1, 'Harsh', 'Mehra', 'ekatag7ha@gmail.com', '+44', '9876573259', '$2a$10$qLewtVP1iRxQ0JcEzZJDv.hzw8XjUdTDw9gbDM0gL3Xr1n9cukvWa', '2024-08-01', 'Male', '1724760724366Group (6).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 12:12:04', '2024-08-27 12:12:04', NULL, NULL, NULL),
(19, 2, 'Dikshuu', 'Mehta', 'dm@gmail.com', '+1', '9998887776', '$2a$10$gZSooOnDrHrI7PQYJyJV/.keQahzhNq7ql71ae5umvwj7K31T3cei', '1997-05-08', 'Female', '1724762991767Group (7).png', 'Purulia', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-27 12:49:51', '2024-09-16 07:26:37', 1, '2024-09-16 07:03:49', NULL),
(20, 2, 'Test ', 'Employee', 'te@gmail.com', '+1', '8889998889', '$2a$10$frFYBlvBxfGDQG8ddjHS/uii1.ih/nSa71bKjPc3wn01rLy4rQHWK', '2024-08-01', 'Male', '1724765019323Group (6).png', 'hdhsht', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-27 13:23:39', '2024-09-16 07:26:23', 1, '2024-09-16 07:03:49', NULL),
(21, 2, 'Harsh', 'Mehra', 'superaymin@gmail.com', '+1', '7897654324', '$2a$10$vMYzz4hPIbyTb/gOTuHz6OpmGpwKZarLqOkWYrD1XE8QdT42JZU52', '2024-08-01', 'Male', '1724765462495Group (7).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-27 13:31:02', '2024-08-27 13:31:02', NULL, NULL, NULL),
(22, 2, 'Shyamo', 'mehra', 'admhin@gmail.com', '+1', '1234567854', '$2a$10$wUd0a2aI6epPx/Kck1IHKuG6oCNwfp3q6JgWyaYagyz/6YP3vZu1a', '2024-08-01', 'Male', '1724765646057Group (7).png', 'ranchii', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-27 13:34:06', '2024-09-16 07:26:09', 1, '2024-09-16 07:03:49', NULL),
(23, 2, 'Shyam', 'Mehra', 'superadnin@gmail.com', '+1', '9876543653', '$2a$10$Uzziz0OwIDLrM5LumU5ns.QIbgtQ1EmS1w0oZyPEwCz/cW7O6pp5K', '2024-08-01', 'Female', '1724767549279Group (6).png', 'Purulia', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-27 14:05:49', '2024-09-16 07:26:16', 1, '2024-09-16 07:03:49', NULL),
(24, 2, 'Test ', 'Employee', 'adminoo@gmail.com', '+1', '9876547259', '$2a$10$SzPdDvM5ZqIvphzu5lr1fuG2ZnXApK0yKrtCL7Pb27SNHneZrzs0m', '2024-08-01', 'Male', '1724825983212Vector (3).png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-28 06:19:44', '2024-09-16 07:27:30', 1, '2024-09-16 07:03:49', NULL),
(25, 2, 'Shyam', 'Mehra', 'admi8776@gmail.com', '+44', '9087564329', '$2a$10$VJpzVilPLbBXrtQts9e6yut8HmBpmhglf.40tCiglNNqK9p2pm26.', '2024-08-05', 'Male', '1724827938076Group (6).png', 'hdhsht', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-08-28 06:52:18', '2024-09-16 13:31:03', 1, '2024-09-16 10:14:58', NULL),
(26, 2, 'Samanta', 'mehra', 'abcty@gmail.com', '+44', '6543987654', '$2a$10$yNW/UyVkoEZsMpz8BVRGreI356CCnK.aA.XEmlPaRMwKjYH4aOVo6', '2024-08-01', 'Male', '1724841772512Group(6).png', 'Ranchi', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-28 10:42:53', '2024-08-28 10:42:53', NULL, NULL, NULL),
(27, 2, 'Taniya', 'Saha', 'taniya@gmail.com', '+1', '2345678928', '$2a$10$WtKFV69JZgt65rcuE0pDx.eqd3.j5ZmGDLMea5LbKtJk0zhRnMqPK', '2024-08-01', 'Male', '1724844313247Personnel.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-08-28 11:25:13', '2024-08-28 11:25:13', NULL, NULL, NULL),
(28, 2, 'Amann', 'Mehra', 'dikshamehta.devv@gmail.com', '+1', '1234567675', '$2a$10$BxgFA3fiJPgSzTIID7ARIeH/U7nAv7EVn4vbDHQFH4HQurE7jckAK', '2024-08-06', 'Male', '1725183208928twitter(1).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-01 09:33:29', '2024-09-20 14:46:22', 1, '2024-09-18 13:50:56', NULL),
(30, 2, 'test2', 'Mehta', 'superadmin1234@parkprime.com', '+1', '9865432678', '$2a$10$dXJIOOJkdTCzpku32VGdqef0yWw1hCqt8Z0qUGtKKz0I43vWpsiym', '2024-08-02', 'Male', '1725250269487Object.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-02 04:11:09', '2024-09-16 07:33:50', 1, '2024-09-16 07:03:49', NULL),
(31, 2, 'Kunal ', 'Khanna', 'kunal@gmail.com', '+1', '1234567874', '$2a$10$iRvHM9Gwpud2ghsWtN18BeQZ/ahZe8xefTO8QcHt09JC10SOTWO1m', '2024-09-01', 'Male', '1725338901643Object.png', 'Purulia', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-03 04:48:22', '2024-09-20 13:50:10', 1, '2024-09-18 13:50:56', NULL),
(32, 2, 'demo', 'new', 'demo@gmail.com', '+1', '6667776668', '$2a$10$jCCjYXLBbd3zBU/Tp/tBpe44UOlVdDAozVLdCDydNpWoXpIXosCxe', '2024-08-01', 'Male', '1725538184842akar-icons_edit(1).png', 'ranchi', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-05 12:09:45', '2024-09-16 07:26:55', 1, '2024-09-16 07:03:49', NULL),
(33, 2, 'Shyam', 'Mehra', 'admin22@gmail.com', '+1', '1234567777', '$2a$10$nDP8YXHVjhCinvGe1EdTlOT.HIm5JA47dlWnHInvGq93lkJoOcWgG', '2024-09-02', 'Male', '1726480449947akar-icons_edit(1).png', 'Purulia', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-16 09:54:10', '2024-09-16 09:54:25', 1, '2024-09-16 09:26:17', NULL),
(34, 2, 'Test', 'User', 'empp@parkprime.com', '+1', '1234567600', '$2a$10$G0j1DmLo/puBBczzsn8xO.I43AMmJDzTJI8MwF5u2qdfqmqZ3no0W', '2024-09-01', 'Male', '1726481894031akar-icons_edit(1).png', 'Purulia', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-16 10:18:14', '2024-09-16 12:45:52', 1, '2024-09-16 10:14:58', NULL),
(35, 2, 'Rajdeep', 'Nandi', 'adminrajdeep@gmail.com', '+1', '1234567676', '$2a$10$lIPHpCSnW6K.m9MCVklIt.G8rXGgBqBEohFB1O1SPwSjymLFaMEp.', '2018-09-03', 'Male', '1726491419508Group1563.png', 'kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-16 12:56:59', '2024-09-16 12:57:03', 1, '2024-09-16 10:14:58', NULL),
(36, 3, 'Amit', '', 'amit@parkprime.com', '+91', '8766548662', '$2a$10$/nPv7ov1gIBSK/IP7d4HTuKdYyO/Xide8gJIYG8G4F4GNFMjZtKTa', NULL, 'Others', '1727605121207company.png', 'Kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-29 10:18:41', '2024-10-01 08:10:38', 1, '2024-10-01 08:10:38', NULL),
(37, 3, 'Amit Singh', '', 'test34@parkprime.com', '+91', '7754546534', '$2a$10$hryhwg46mckJ/uWMixRcXeUp7d9u5h33JHD87d5sN7qFM/eqnSuQW', NULL, 'Others', '1727605580278company.png', 'Kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-29 10:26:20', '2024-10-01 08:11:57', 1, '2024-10-01 08:11:57', NULL),
(38, 3, 'Suman', '', 'test88@parkprime.com', '+91', '7656667788', '$2a$10$IBvJ7QqHvNogleoWLkRRtuyKT62SERzKLPhYXHZXXXU.lh9K5G6yW', NULL, 'Others', '1727605939971company.png', 'Delhi', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-29 10:32:20', '2024-10-01 08:10:31', 1, '2024-10-01 08:10:31', NULL),
(39, 3, 'Sourav', '', 'test22@parkprime.com', '+91', '6756654555', '$2a$10$EMVQPHHX.yICCkHLGXXPOOTYmf6VvgoKPv.16kA/06v6fV/S5V58.', NULL, 'Others', NULL, 'Kolkata', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, '2024-09-29 14:36:42', '2024-10-01 08:12:02', 1, '2024-10-01 08:12:02', NULL),
(40, 3, 'Sourav Singh', '', 'test25@parkprime.com', '+91', '6756652222', '$2a$10$eZB5OoOXP2QRa5ZO5becV.9pJh9uOV4I.eF9cNh/OtrlpYfMac93G', NULL, 'Others', NULL, 'Kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-09-29 14:38:41', '2024-09-29 14:38:41', NULL, NULL, NULL),
(41, 3, 'Kalyan Roy', '', 'kalyan@parkprime.com', '+91', '7754546511', '$2a$10$h28tdautoZimrQLfrFSVZOESsrJNRyMT0GbBf.Xk8ZOKI.KgQDRp2', NULL, 'Others', NULL, 'Kolkata', NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '2024-10-01 06:17:52', '2024-10-01 07:54:01', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vehicleTypes`
--

CREATE TABLE `vehicleTypes` (
  `id` int NOT NULL,
  `typeName` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `vehicleTypes`
--

INSERT INTO `vehicleTypes` (`id`, `typeName`, `created_at`, `updated_at`, `isActive`, `deleted_at`) VALUES
(52, 'Sedan', '2024-09-09 06:02:37', '2024-09-09 06:02:37', 1, NULL),
(54, 'Small SUV', '2024-09-09 06:02:56', '2024-09-09 06:02:56', 1, NULL),
(56, 'Truck', '2024-09-09 12:11:25', '2024-09-09 12:11:25', 1, NULL),
(57, 'Car', '2024-09-10 07:27:46', '2024-09-10 07:27:46', 1, NULL),
(58, 'Motorcycle', '2024-09-10 07:35:24', '2024-09-10 07:35:24', 1, NULL),
(63, 'Bus', '2024-09-12 13:52:49', '2024-09-12 13:52:49', 1, NULL),
(64, 'Hatchback', '2024-09-12 14:16:49', '2024-09-12 14:16:49', 1, NULL),
(65, 'test new', '2024-09-12 14:18:13', '2024-09-12 14:18:13', 1, NULL),
(66, 'test34', '2024-09-16 07:02:36', '2024-09-16 07:02:36', 1, NULL),
(67, 'Test Bus', '2024-09-17 09:38:40', '2024-09-17 09:38:40', 1, NULL),
(68, 'XUV', '2024-09-23 08:27:02', '2024-09-23 08:27:02', 1, NULL),
(69, 'Bike', '2024-09-23 09:01:32', '2024-09-23 09:01:32', 1, NULL),
(70, 'Taxi', '2024-09-23 10:01:21', '2024-09-23 10:01:21', 1, NULL),
(71, 'Mini Truck', '2024-09-23 10:03:29', '2024-09-23 10:03:29', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `initials` varchar(255) NOT NULL,
  `isOnsiteChargeApplicable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-No, true-Yes',
  `isActive` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'false-Inactive, true-Active',
  `isVerified` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'false-No, true-Yes',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `userId`, `initials`, `isOnsiteChargeApplicable`, `isActive`, `isVerified`, `created_at`, `updated_at`, `deleted_by`, `deleted_at`) VALUES
(1, 36, 'test', 0, 0, 0, '2024-09-29 10:18:41', '2024-10-01 08:10:38', 1, '2024-10-01 08:10:38'),
(2, 37, 'test', 0, 0, 0, '2024-09-29 10:26:20', '2024-10-01 08:11:57', 1, '2024-10-01 08:11:57'),
(3, 38, 'test1', 0, 0, 0, '2024-09-29 10:32:20', '2024-10-01 08:10:31', 1, '2024-10-01 08:10:31'),
(4, 39, 'test2', 0, 0, 0, '2024-09-29 14:36:42', '2024-10-01 08:12:02', 1, '2024-10-01 08:12:02'),
(5, 40, 'test4', 0, 1, 0, '2024-09-29 14:38:41', '2024-09-29 14:38:41', NULL, NULL),
(6, 41, 'TL', 0, 1, 0, '2024-10-01 06:17:52', '2024-10-01 07:54:01', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookingRequests`
--
ALTER TABLE `bookingRequests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerId` (`customerId`),
  ADD KEY `slotId` (`slotId`),
  ADD KEY `vehicleTypeId` (`vehicleTypeId`);

--
-- Indexes for table `carMovements`
--
ALTER TABLE `carMovements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookingRequestId` (`bookingRequestId`),
  ADD KEY `vendorId` (`vendorId`),
  ADD KEY `actualvehicleTypeId` (`actualvehicleTypeId`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookingRequestId` (`bookingRequestId`);

--
-- Indexes for table `modulePermissions`
--
ALTER TABLE `modulePermissions`
  ADD PRIMARY KEY (`userId`,`moduleId`),
  ADD UNIQUE KEY `modulePermissions_moduleId_userId_unique` (`userId`,`moduleId`),
  ADD KEY `moduleId` (`moduleId`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parentModuleId` (`parentModuleId`);

--
-- Indexes for table `parkingBusinesses`
--
ALTER TABLE `parkingBusinesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parkingGrounds`
--
ALTER TABLE `parkingGrounds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `parking_grounds_parking_business_id_ground_name` (`parkingBusinessId`,`groundName`);

--
-- Indexes for table `parkingLots`
--
ALTER TABLE `parkingLots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `parking_lots_parking_ground_id_lot_name` (`parkingGroundId`,`lotName`);

--
-- Indexes for table `policies`
--
ALTER TABLE `policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priceCharts`
--
ALTER TABLE `priceCharts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehicleTypeId` (`vehicleTypeId`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Sessions`
--
ALTER TABLE `Sessions`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `slots`
--
ALTER TABLE `slots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slots_parking_lot_id_slot_name_slot_bay_number_slot_row_number` (`parkingLotId`,`slotName`,`slotBayNumber`,`slotRowNumber`);

--
-- Indexes for table `staticCharges`
--
ALTER TABLE `staticCharges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parkingGroundId` (`parkingGroundId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roleId` (`roleId`);

--
-- Indexes for table `vehicleTypes`
--
ALTER TABLE `vehicleTypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookingRequests`
--
ALTER TABLE `bookingRequests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `carMovements`
--
ALTER TABLE `carMovements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `parkingBusinesses`
--
ALTER TABLE `parkingBusinesses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parkingGrounds`
--
ALTER TABLE `parkingGrounds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parkingLots`
--
ALTER TABLE `parkingLots`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `policies`
--
ALTER TABLE `policies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priceCharts`
--
ALTER TABLE `priceCharts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `slots`
--
ALTER TABLE `slots`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=680;

--
-- AUTO_INCREMENT for table `staticCharges`
--
ALTER TABLE `staticCharges`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `vehicleTypes`
--
ALTER TABLE `vehicleTypes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookingRequests`
--
ALTER TABLE `bookingRequests`
  ADD CONSTRAINT `bookingRequests_ibfk_22` FOREIGN KEY (`customerId`) REFERENCES `users` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `bookingRequests_ibfk_23` FOREIGN KEY (`slotId`) REFERENCES `slots` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `bookingRequests_ibfk_24` FOREIGN KEY (`vehicleTypeId`) REFERENCES `vehicleTypes` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `carMovements`
--
ALTER TABLE `carMovements`
  ADD CONSTRAINT `carMovements_ibfk_22` FOREIGN KEY (`bookingRequestId`) REFERENCES `bookingRequests` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `carMovements_ibfk_23` FOREIGN KEY (`vendorId`) REFERENCES `vendors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `carMovements_ibfk_24` FOREIGN KEY (`actualvehicleTypeId`) REFERENCES `vehicleTypes` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`bookingRequestId`) REFERENCES `bookingRequests` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `modulePermissions`
--
ALTER TABLE `modulePermissions`
  ADD CONSTRAINT `modulePermissions_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modulePermissions_ibfk_2` FOREIGN KEY (`moduleId`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`parentModuleId`) REFERENCES `modules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `parkingGrounds`
--
ALTER TABLE `parkingGrounds`
  ADD CONSTRAINT `parkingGrounds_ibfk_1` FOREIGN KEY (`parkingBusinessId`) REFERENCES `parkingBusinesses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parkingLots`
--
ALTER TABLE `parkingLots`
  ADD CONSTRAINT `parkingLots_ibfk_1` FOREIGN KEY (`parkingGroundId`) REFERENCES `parkingGrounds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `priceCharts`
--
ALTER TABLE `priceCharts`
  ADD CONSTRAINT `priceCharts_ibfk_1` FOREIGN KEY (`vehicleTypeId`) REFERENCES `vehicleTypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `slots`
--
ALTER TABLE `slots`
  ADD CONSTRAINT `slots_ibfk_1` FOREIGN KEY (`parkingLotId`) REFERENCES `parkingLots` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staticCharges`
--
ALTER TABLE `staticCharges`
  ADD CONSTRAINT `staticCharges_ibfk_1` FOREIGN KEY (`parkingGroundId`) REFERENCES `parkingGrounds` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `vendors`
--
ALTER TABLE `vendors`
  ADD CONSTRAINT `vendors_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
