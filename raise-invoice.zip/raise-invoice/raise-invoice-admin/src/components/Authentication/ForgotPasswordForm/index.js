"use client";

import { useState, useEffect } from "react";
import { Row, Col, Form } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { ToastContainer, toast } from "react-toastify";
import apiConnection from "../../../utils/apiConnection";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
// import Router from 'next/router';

const ForgotPasswordForm = () => {
  const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
  const [showOtp, setShowOtp] = useState(false)
  const [buttonText, setButtonText] = useState('Get OTP')
  // const [otpText, setOtpText] = useState(false)
  var [state, setState] = useState({
    email: '',
    otp: '',    
  });
  var { email, otp } = state;
  const router = useRouter();

  useEffect(() => {
    if (authToken) {
        router.push('/dashboard/')
    }
  }, []);

  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
  };

  var validationSchema = Yup.object().shape({
    email: Yup.string()
        .required('Email is required')
        .email('Invalid email format'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => { 
      clearErrors()   
      reset(state)
  }
  const onSubmit = async (formData) => {
    // console.log(formData)
    try {
        const response = await apiConnection.post('forgot-password', formData)
        if (response.status === 200) {
          if(response.data.otp){
            setShowOtp(true)
            // setOtpText(response.data.otp);
            setState(prevState => ({
              ...prevState,
              otp: response.data.otp,
            }));
            setButtonText('Verify OTP')
          }else{
            // console.log(response.data.resetToken)
            // resetForm();
            // Router.push({
            //   pathname: '/authentication/reset-password',
            //   query: { token: response.data.resetToken },
            // })
            router.push(`/authentication/reset-password/?token=${response.data.resetToken}`);            
          }
                             
          toast.success(response.data.message);
        }
    } catch (error) {
        if (error?.response?.status === 400) {
            toast.error(error?.response?.data?.message);
        } else if (error?.response?.status === 422) {
            toast.error(error?.response?.data?.message);
        } else {
            toast.error(error?.response?.data?.message);
        }
    }
  };

  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      email: '',
    }));
  }
  return (
    <>
      <div className="auth-main-content m-auto m-1230 px-3">
        <ToastContainer position="top-right" autoClose={3000} />
        <Row className="align-items-center">
          <Col lg={6} className="d-none d-lg-block">
            <Image
              src="/images/login-page.png"
              className="rounded-3"
              alt="forgot"
              width={646}
              height={804}
            />
          </Col>

          <Col lg={6}>
            <div className="mw-480 ms-lg-auto">
              <div className="d-inline-block mb-4">
                <Image
                  src="/images/logo.svg"
                  className="for-light-logo"
                  alt="login"
                  width={100}
                  height={26}
                />
                <Image
                  src="/images/white-logo.svg"
                  className="for-dark-logo"
                  alt="login"
                  width={100}
                  height={26}
                />
              </div>

              <h3 className="fs-28 mb-2">Forgot your password?</h3>
              <p className="fw-medium fs-16 mb-4">
                Enter the email address you used when you joined and we’ll send you otp to reset your password.
              </p>

              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-4">
                  <label className="label text-secondary">Email Address</label>
                  <Form.Control 
                    type="email" 
                    {...register('email', {onChange: handleChange})}
                    value={email}  
                    className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`}
                    placeholder="example@raiseinvoice.com"
                  />
                  <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                </Form.Group>

                {showOtp ? 
                  <Form.Group className="mb-4">
                    <label className="label text-secondary">OTP</label>
                    <Form.Control 
                      type="text" 
                      {...register('otp', {onChange: handleChange})}
                      value={otp}  
                      className={`form-control ${errors.otp ? 'is-invalid' : (otp ? 'is-valid' : '')}`}
                      placeholder="Enter OTP"
                    />
                    <div className="invalid-feedback">{errors.otp?.message?.toString()}</div>
                  </Form.Group>
                : ''}

                <Form.Group className="mb-4">
                  <button
                    type="submit"
                    className="btn btn-primary fw-medium py-2 px-3 w-100"
                    onClick={submitForm}
                  >
                    <div className="d-flex align-items-center justify-content-center py-1">
                      <span className="material-symbols-outlined fs-20 text-white me-2">
                        autorenew
                      </span>
                      <span>{buttonText}</span>
                    </div>
                  </button>
                </Form.Group>

                <Form.Group>
                  <p>
                    Back to{" "}
                    <Link
                      href="/authentication/sign-in/"
                      className="fw-medium text-primary text-decoration-none"
                    >
                      Sign In
                    </Link>
                  </p>
                </Form.Group>
              </Form>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default ForgotPasswordForm;
