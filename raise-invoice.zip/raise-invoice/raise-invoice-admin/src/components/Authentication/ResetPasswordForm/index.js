"use client";

import { useState, useEffect } from "react";
import { Row, Col, Form } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { ToastContainer, toast } from "react-toastify";
import apiConnection from "../../../utils/apiConnection";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useRouter, useSearchParams } from 'next/navigation';

const ResetPasswordForm = () => {
  const authToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("auth-token") : null;
  const router = useRouter();
  const searchParams = useSearchParams() 
  const resetToken = searchParams.get('token')
  var [state, setState] = useState({
    resetToken: resetToken,
    password: '',
    confirm_password: ''
    
  });
  var { password, confirm_password } = state;

  useEffect(() => {
    if (authToken) {
      router.push('/dashboard/')
    }
  }, []);

  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
  };

  var validationSchema = Yup.object().shape({
    password: Yup.string()
        .required('Password is required'),
    confirm_password: Yup.string()
        .required('Confirm Password is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => { 
      clearErrors()   
      reset(state)
  }
  const onSubmit = async (formData) => {
    console.log(formData)
    try {
        const response = await apiConnection.post('reset-password', formData)
        if (response.status === 200) {
          resetForm();                   
          toast.success(response.data.message);
          router.push(`/authentication/sign-in/`);
        }
    } catch (error) {
        if (error?.response?.status === 400) {
            toast.error(error?.response?.data?.message);
        } else if (error?.response?.status === 422) {
            toast.error(error?.response?.data?.message);
        } else {
            toast.error(error?.response?.data?.message);
        }
    }
  };

  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      password: '',
      confirm_password: ''
    }));
  }
  return (
    <>
      <div className="auth-main-content m-auto m-1230 px-3">
        <ToastContainer position="top-right" autoClose={3000} />
        <Row className="align-items-center">
          <Col lg={6} className="d-none d-lg-block">
            <Image
              src="/images/login-page.png"
              className="rounded-3"
              alt="forgot"
              width={646}
              height={804}
            />
          </Col>

          <Col lg={6}>
            <div className="mw-480 ms-lg-auto">
              <div className="d-inline-block mb-4">
                <Image
                  src="/images/logo.svg"
                  className="for-light-logo"
                  alt="login"
                  width={100}
                  height={26}
                />
                <Image
                  src="/images/white-logo.svg"
                  className="for-dark-logo"
                  alt="login"
                  width={100}
                  height={26}
                />
              </div>

              <h3 className="fs-28 mb-2">Reset Password</h3>
              <p className="fw-medium fs-16 mb-4">
                Enter your new password and confirm it another time in the field below.
              </p>

              <Form onSubmit={handleSubmit(onSubmit)}>
                
                <Form.Group className="mb-4">
                  <label className="label text-secondary">New Password</label>
                  <Form.Control
                    type="password"
                    {...register('password', {onChange: handleChange})}
                    value={password}  
                    className={`form-control ${errors.password ? 'is-invalid' : (password ? 'is-valid' : '')}`}
                    placeholder="Type your new password"
                  />
                </Form.Group>

                <Form.Group className="mb-4">
                  <label className="label text-secondary">Confirm Password</label>
                  <Form.Control
                    type="password"
                    {...register('confirm_password', {onChange: handleChange})}
                    value={confirm_password}  
                    className={`form-control ${errors.confirm_password ? 'is-invalid' : (confirm_password ? 'is-valid' : '')}`}
                    placeholder="Type your confirm password"
                  />
                </Form.Group>

                <Form.Group className="mb-4">
                  <button
                    type="submit"
                    className="btn btn-primary fw-medium py-2 px-3 w-100"
                    onClick={submitForm}
                  >
                    <div className="d-flex align-items-center justify-content-center py-1">
                      <span className="material-symbols-outlined fs-20 text-white me-2">
                        autorenew
                      </span>
                      <span>Update</span>
                    </div>
                  </button>
                </Form.Group>

                <Form.Group>
                  <p>
                    Back to{" "}
                    <Link
                      href="/authentication/sign-in/"
                      className="fw-medium text-primary text-decoration-none"
                    >
                      Sign In
                    </Link>
                  </p>
                </Form.Group>
              </Form>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default ResetPasswordForm;