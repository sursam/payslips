"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { ToastContainer, toast } from "react-toastify";
import Select from 'react-select';
import DOMPurify from 'dompurify';

import dynamic from 'next/dynamic';
const CustomEditor = dynamic(() => import('../../Ckeditor/custom-editor'), { ssr: false });


const EditBlock = ({ uuid, buuid }) => {
  console.log(uuid, buuid)
  const router = useRouter();
  const [section_type, setSectionType] = useState('');
  const [faqList, setFaqList] = useState([]);
  const [pageList, setPageList] = useState([]);
  const [sanitizedHTML, setSanitizedHTML] = useState('');
  var [state, setState] = useState({
    id: null,
    title: '',
    subtitle: '',
    description: '',
    template: '',
    page_id: '',
    section_type: '',
    status: '',
    faq_ids: [],
    testimonial_ids: []
  });
  var { title, subtitle, page_id, description, template, status, faq_ids, testimonial_ids } = state;

  // const handleChange = (event) => {
  //   const { name, value } = event.target;
  //   setState(prevState => ({
  //     ...prevState,
  //     [name]: value,
  //   }));
  //   trigger(name);
  // };

  const handleChange = (event) => {
    const { name, value, options } = event.target;

    if (options) {
      const selectedValues = Array.from(options)
        .filter(option => option.selected)
        .map(option => option.value);
      setState(prevState => ({
        ...prevState,
        [name]: selectedValues,
      }));
    } else {
      setState(prevState => ({
        ...prevState,
        [name]: value,
      }));
    }

    trigger(name);
  };

  const handleChangeSelectSection = (event) => {
    const selectedValue = event.target.value;
    setSectionType(selectedValue);
  };

  const handleChangeEditor = (name, value) => {
    const cleanHTML = DOMPurify.sanitize(value);
    setSanitizedHTML(cleanHTML);
  };

  var validationSchema = Yup.object().shape({
    title: Yup.string()
      .required('Title is required'),
    // subtitle: Yup.string()
    //   .required('sub title is required'),
    // description: Yup.string()
    //   .required('Description is required')
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {
    clearErrors()
    reset(state)
  }
  const cancelForm = () => {
    router.push(`/page/block/${uuid}/list/`)
  }
  const onSubmit = async (formData) => {
    formData.template = sanitizedHTML;
    // console.log(formData); return;
    try {
      const response = await apiConnection.post('save-block', formData)
      if (response.status === 200) {
        resetForm();
        toast.success(response.data.message);
        router.push(`/page/block/${page_id}/list`);
      }
    } catch (error) {
      if (error?.response?.status === 400) {
        toast.error(error?.response?.data?.message);
      } else if (error?.response?.status === 422) {
        toast.error(error?.response?.data?.message);
      } else {
        toast.error(error?.response?.data?.message);
      }
    }
  };

  const resetForm = () => {
    clearErrors();
    setState(prevState => ({
      ...prevState,
      id: null,
      name: '',
      message: '',
      designation: null,
      company: '',
    }));
  }

  const getBlockDetails = async () => {
    try {
      const blockResponse = await apiConnection.post('get-block-details', { uuid: buuid })

      if (blockResponse?.data?.status) {
        let blockData = blockResponse?.data?.data;

        setSectionType(blockData?.section_type);
        setSanitizedHTML(blockData?.template);
        setState(prevState => ({
          ...prevState,
          id: blockData?.id,
          page_id: blockData?.page?.uuid,
          title: blockData?.title,
          subtitle: blockData?.subtitle,
          description: blockData?.description,
          template: blockData?.template,
          section_type: blockData?.section_type,
          status: blockData?.status,
          faq_ids: blockData.faq_ids ? blockData.faq_ids.split(',').map(item => item.trim()) : [],
          testimonial_ids: blockData.testimonial_ids ? blockData.testimonial_ids.split(',').map(item => item.trim()) : []
        }));
      }
    } catch (error) {
      console.log('error', error);
    }
  };

  const getFaqList = async () => {
    try {
      const response = await apiConnection.post('get-faq-list');
      console.log(response?.data?.data)
      setFaqList(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };

  const getsetPageList = async () => {
    try {
      const response = await apiConnection.post('get-testimonial-list');
      console.log(response?.data?.data)
      setPageList(response?.data?.data);
    } catch (error) {
      console.log('error', error);
    }
  };

  const sectionTypeList = [
    { id: 1, text: 'Faq Section' },
    { id: 2, text: 'Testimonial Section' },
    { id: 3, text: 'Content Section' },
  ];

  useEffect(() => {
    getFaqList();
    getsetPageList();
    if (buuid) {
      getBlockDetails();
    }
  },
    [])

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col lg={12}>
            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="">
                <Row>

                  <Col sm={12} lg={12}>

                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Block Type</label>
                      <Form.Control
                        as="select"
                        {...register('section_type', { onChange: handleChangeSelectSection })}
                        className="form-control"
                        value={section_type}
                        disabled
                      >
                        <option value="">Select Block Type</option>
                        {sectionTypeList.map(faq => (
                          <option key={faq.id} value={faq.id}>
                            {faq.text}
                          </option>
                        ))}
                      </Form.Control>
                    </Form.Group>

                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Title</label>
                      <Form.Control
                        type="text"
                        {...register('title', { onChange: handleChange })}
                        value={title ?? ''}
                        className={`form-control ${errors.title ? 'is-invalid' : (title ? 'is-valid' : '')}`}
                        placeholder="Enter block title"
                      />
                      <div className="invalid-feedback">{errors.title?.message?.toString()}</div>
                    </Form.Group>
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Subtitle</label>
                      <Form.Control
                        type="text"
                        {...register('subtitle', { onChange: handleChange })}
                        value={subtitle ?? ''}
                        className={`form-control ${errors.subtitle ? 'is-invalid' : (subtitle ? 'is-valid' : '')}`}
                        placeholder="Enter block subtitle"
                      />
                      <div className="invalid-feedback">{errors.subtitle?.message?.toString()}</div>
                    </Form.Group>
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Description</label>
                      <Form.Control
                        type="text"
                        {...register('description', { onChange: handleChange })}
                        value={description ?? ''}
                        className={`form-control ${errors.description ? 'is-invalid' : (description ? 'is-valid' : '')}`}
                        placeholder="Enter block description"
                      />
                      <div className="invalid-feedback">{errors.description?.message?.toString()}</div>
                    </Form.Group>

                  </Col>

                  {section_type == '1' && (
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Select FAQs</label>
                      <Form.Control
                        as="select"
                        multiple
                        {...register('faq_ids', { onChange: handleChange })}
                        className="form-control"
                        value={faq_ids}
                        style={{ height: "120px" }}
                      >
                        {faqList.map(faq => (
                          <option key={faq?.id} value={faq?.id}>
                            {faq?.question}
                          </option>
                        ))}
                      </Form.Control>
                    </Form.Group>
                  )}
                  {section_type == '2' && (
                    <Form.Group className="mb-4">
                      <label className="label text-secondary">Select Testimonials</label>
                      <Form.Control
                        as="select"
                        multiple
                        {...register('testimonial_ids', { onChange: handleChange })}
                        className="form-control"
                        value={testimonial_ids}
                        style={{ height: "120px" }}
                      >
                        {pageList.map(testimonial => (
                          <option key={testimonial?.id} value={testimonial?.id}>
                            {testimonial?.name}
                          </option>
                        ))}
                      </Form.Control>
                    </Form.Group>
                  )}
                  {section_type == '3' && (
                    <Col sm={12} lg={12} className="mb-4">
                      <label className="label text-secondary">Content Section</label>
                      <CustomEditor
                        name='description'
                        className=""
                        value={sanitizedHTML}
                        placeholder="Type here...."
                        data={sanitizedHTML}
                        handleChangeEditor={handleChangeEditor}
                      />
                    </Col>
                  )}

                  <Col sm={12} lg={12}>
                    <div className="d-flex flex-wrap gap-3">
                      <button className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white" type="button" onClick={cancelForm}>
                        Cancel
                      </button>
                      <button className="btn btn-primary py-2 px-4 fw-medium fs-16" type="submit" onClick={submitForm}>
                        {" "}
                        <i className="ri-add-line text-white fw-medium"></i> {uuid ? 'Update ' : 'Add '}
                        Block
                      </button>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default EditBlock;
