"use client";

import { Card, Table } from "react-bootstrap";
import Link from "next/link";
// import Image from "next/image";
import SearchForm from "./SearchForm";
import { useState, useEffect } from 'react';
import apiConnection from "../../../utils/apiConnection";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import { useParams } from 'next/navigation';
import { can } from "../../../utils/helper";
import Pagination from "../../Pagination";

const BlockListTable = () => {
  const { uuid } = useParams();
  const [blockList, setBlockList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);

  const getBlockList = async (searchText = '', page = 1, limit = 10) => {
    try {
      const response = await apiConnection.post('get-block-list', { searchText: searchText, page_id: uuid, page, limit });
      setBlockList(response?.data?.data);
      setTotalPages(response?.data?.totalPages);
    } catch (error) {
      console.log('error', error);
    }
  };
  const handleDelete = async (e, uuid) => {
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
            try {
              const response = await apiConnection.post('delete-block', { uuid: uuid })
              if (response?.data?.status) {
                toast.success("Block deleted successfully")
                const updatedBlockList = blockList.filter((item) => item.uuid !== uuid);
                setBlockList(updatedBlockList);
              }
            } catch (error) {
              console.error('Error deleting block data:', error);
            }
          }
        },
        {
          label: 'No'
        }
      ]
    });
  }

  useEffect(() => {
    getBlockList('', currentPage)
  },
    [currentPage]);
  const handlePageChange = (page) => {
    setCurrentPage(page);
    getBlockList('', page);
  };
  
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
            <SearchForm getBlockList={getBlockList} />
            {can(['add-block']) ?
              <Link
                href={`/page/block/${uuid}/add`}
                className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
              >
                <span className="py-sm-1 d-block">
                  <i className="ri-add-line d-none d-sm-inline-block"></i>{" "}
                  <span>Add Block</span>
                </span>
              </Link>
            : ''}
          </div>

          <div className="default-table-area ">
            <div className="table-responsive">
              <Table className="table align-middle">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Page</th>
                    <th scope="col">title</th>
                    <th scope="col">Sub title</th>
                    <th scope="col">Description</th>
                    <th scope="col">Order Number</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {blockList.length ?
                    blockList.map((value, i) => (
                      <tr key={i}>
                        <td>{++i}</td>
                        <td>{value.page.page_title}</td>
                        <td>{value.title}</td>
                        <td>{value.subtitle}</td>
                        <td>{(value.description.length > 250) ? value.description.substr(0, 250) + '...' : value.description}</td>
                        <td>{value.order_number}</td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            {can(['edit-block']) ?
                              <Link
                                href={`/page/block/${uuid}/edit/${value.uuid}/`}
                                className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                title="Edit Block"
                              >
                                <i className="material-symbols-outlined fs-16 text-body">edit</i>
                              </Link>
                            : ''}
                            {can(['delete-block']) ?
                              <button className="ps-0 border-0 bg-transparent lh-1 position-relative top-2" onClick={e => handleDelete(e, value.uuid)} title="Delete Block">
                                <span className="material-symbols-outlined fs-16 text-danger">
                                  delete
                                </span>
                              </button>
                            : ''}
                          </div>
                        </td>
                      </tr>
                    )) : <tr key="0"><td colSpan={7} className="text-center">No blocks are available</td></tr>}
                </tbody>
              </Table>
            </div>

            {/* Pagination */}
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default BlockListTable;
