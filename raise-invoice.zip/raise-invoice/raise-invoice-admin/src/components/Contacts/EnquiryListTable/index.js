"use client";

import { Card, Table } from "react-bootstrap";
import SearchForm from "./SearchForm";
// import Pagination from "./Pagination";
import {useState, useEffect} from 'react';
import apiConnection from "../../../utils/apiConnection";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import Link from "next/link";
import { can } from "../../../utils/helper";

const Contacts = () => {
  const [enquiryList, setEnquiryList] = useState([]);
    
  const getEnquiryList = async (searchText = '') => {
    try {
        const response = await apiConnection.post('get-enquiry-list', {searchText: searchText});
        console.log(response?.data?.data)
        setEnquiryList(response?.data?.data);
    } catch (error) {
        console.log('error', error);
    }
  };
  const handleDelete = async (e, uuid) => {
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
              try {
                  const response = await apiConnection.post('delete-enquiry', { uuid: uuid })
                  if(response?.data?.status){
                      toast.success("Enquiry deleted successfully")
                      const updatedEnquiryList = enquiryList.filter((item) => item.uuid !== uuid);
                      setEnquiryList(updatedEnquiryList);
                  }
              } catch (error) {
                  console.error('Error deleting enquiry data:', error);
              }
          }
        },
        {
          label: 'No'
        }
      ]
    });
  }
  useEffect(() => {
    getEnquiryList()
  }, 
  [])
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-0">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 p-4">
            <SearchForm getEnquiryList={getEnquiryList} />

            {/* <div className="text-end">
              <Form.Select
                className="month-select form-control"
                aria-label="Default select example"
              >
                <option defaultValue="0">All</option>
                <option defaultValue="1">Active</option>
                <option defaultValue="2">Deactive</option>
              </Form.Select>
            </div> */}
          </div>

          <div className="default-table-area style-two">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th scope="col">
                      {/* <Form>
                        <Form.Check
                          type="checkbox"
                          id="default-checkbox"
                          label="ID"
                        />
                      </Form> */}
                      ID
                    </th>
                    <th scope="col">User</th>
                    <th scope="col">Email</th>
                    {/* <th scope="col">Phone</th> */}
                    <th scope="col">Location</th>
                    <th scope="col">Company</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {enquiryList.length ?
                    enquiryList.map((value, i) => (
                      <tr key={i}>
                        <td>{value.id}</td>
                        <td>{value.name}</td>
                        <td><a href={`mailto:${value.email}`}>{value.email}</a></td>
                        {/* <td><a href={`tel:${value.phone}`}>{value.phone}</a></td> */}
                        <td>{value.country?.name}</td>
                        <td>{value.companyName}</td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            {can(['view-enquiry']) ?
                              <Link
                                href={`/contacts/view/${value.uuid}`}
                                className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                title="View Enquiry"
                              >
                                <i className="material-symbols-outlined fs-16 text-primary">visibility</i>
                              </Link>
                            : ''}
                            {can(['delete-enquiry']) ?
                              <button className="ps-0 border-0 bg-transparent lh-1 position-relative top-2" onClick={e => handleDelete(e, value.uuid)} title="Delete Enquiry">
                                <span className="material-symbols-outlined fs-16 text-danger">
                                  delete
                                </span>
                              </button>
                            : ''}
                          </div>
                        </td>
                      </tr>
                    )) 
                  : <tr key="0"><td colSpan={6} className="text-center">No enquiries are available</td></tr> }
                  
                </tbody>
              </Table>

              {/* Pagination */}
              {/* <Pagination /> */}
            </div>
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default Contacts;
