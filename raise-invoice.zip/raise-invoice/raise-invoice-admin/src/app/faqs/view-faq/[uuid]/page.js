"use client";

import { Breadcrumb } from "react-bootstrap";
import ViewFaq from "@/components/Faqs/ViewFaq";
import { useParams } from 'next/navigation';

export default function Page() {
  const { uuid } = useParams();
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">View FAQ</h3>
 
        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/">
            <div className="d-flex text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item href="/faqs/faq-list/">
            <span className="text-secondary fw-medium hover">FAQs</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item active>
            <span className="fw-medium">View FAQ</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div> 

      <ViewFaq uuid={uuid} />
    </>
  );
}
