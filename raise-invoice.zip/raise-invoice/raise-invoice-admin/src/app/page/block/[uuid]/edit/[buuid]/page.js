"use client";

import React, { useState, useEffect } from 'react';
import { Breadcrumb } from "react-bootstrap";
import EditBlock from "@/components/Block/EditBlock";
import { useParams } from 'next/navigation';
import apiConnection from "../../../../../../utils/apiConnection";

export default function Page() {

  const { uuid, buuid } = useParams();
  const [pageTitle, setPageTitle] = useState('');
  const getPageDetails = async () => {
    try {
      const pageResponse = await apiConnection.post('get-page-details', { uuid: uuid });
      if (pageResponse?.data?.status) {
        let pageData = pageResponse?.data?.data;
        setPageTitle(pageData.page_title);
      }
    } catch (error) {
      console.log('error', error);
    }
  };
  useEffect(() => {
    if (uuid) {
      getPageDetails();
    }
  }, []);
  return (
    <>
      <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h3 className="mb-0">{pageTitle} Edit Block</h3>

        <Breadcrumb className="breadcrumb-page-list align-items-center mb-0 lh-1">
          <Breadcrumb.Item href="/dashboard/" aria-label="Dashboard">
            <div className="d-flex text-decoration-none">
              <i className="ri-home-4-line fs-18 text-primary me-1"></i>
              <span className="text-secondary fw-medium hover">Dashboard</span>
            </div>
          </Breadcrumb.Item>

          <Breadcrumb.Item href="/page/list/">
            <span className="text-secondary fw-medium hover">Pages</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item href={`/page/block/${uuid}/list/`} aria-label="Block List">
            <span className="text-secondary fw-medium hover">Blocks</span>
          </Breadcrumb.Item>

          <Breadcrumb.Item active aria-current="page">
            <span className="fw-medium">Edit Block</span>
          </Breadcrumb.Item>
        </Breadcrumb>
      </div>

      <EditBlock uuid={uuid} buuid={buuid} />
    </>
  );
}