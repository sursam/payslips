import ResetPasswordForm from "@/components/Authentication/ResetPasswordForm";

export default function Page({uuid}) {
  return (
    <>    
      <ResetPasswordForm uuid={uuid} />
    </>
  );
}
