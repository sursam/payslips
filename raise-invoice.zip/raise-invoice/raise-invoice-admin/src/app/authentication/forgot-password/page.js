import ForgotPasswordForm from "@/components/Authentication/ForgotPasswordForm";

export default function Page() {
  return (
    <>
      <ForgotPasswordForm />
    </>
  );
}
