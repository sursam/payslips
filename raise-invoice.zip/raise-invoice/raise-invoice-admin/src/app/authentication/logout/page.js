import Logout from "@/components/Authentication/Logout";

export default function Page() {
  return (
    <>
      <Logout />
    </>
  );
}
