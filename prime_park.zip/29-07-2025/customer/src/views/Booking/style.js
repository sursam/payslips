import { styled, TextField } from "@mui/material";

export const CustomTextField = styled(TextField)({
    '& .MuiOutlinedInput-root': {
      borderRadius: '50px',
      padding: '8px 16px',
      '&.Mui-focused': {
        borderColor: '#ccc',
      },
      '& fieldset': {
        borderColor: '#ccc',
      },
      '&:hover fieldset': {
        borderColor: '#aaa',
      },
    },
    '& .MuiInputAdornment-root': {
      marginRight: '8px',
    },
    '& input::placeholder': {
      color: '#999',
      fontWeight: '500',
    },
  });