import React from "react";
import { image } from "../common/Theme";
import { useState } from 'react'
import { RadioButton } from "../component/Radio";
import FlagDropdown from "../component/FlagDropdown";



export default function Login() {
  const [email, setEmail] = useState('') // useState to store Email address of the user
  const [phone, setPhone] = useState('') // useState to store Mobile Number

  function validateForm() {

    if (email.length == 0) {
      alert('Invalid Form, Email Address can not be empty')
      return
    }
    if (email.length == 0) {
      // invalid form, 0 lowercase characters
      alert('Invalid Form, 0 lower case characters in password')
      return
    }
    alert('Form is Invalid')
  }
  return (
    <>
      <div className="login-sec">
        <div className="row align-items-center">
          <div className="col-lg-5">
            <div className="login-frm">
              <div className="login-top">
                <img src={image.logo} alt="" />
                <div className="choose-type">
                  <div className="guest-login">
                   <RadioButton onClick={()=>{
                  
                   }}/>
                   
                  </div>
                  
                </div>
              </div>

              <div className="login-form-sec">
                <form action="">
                  <div className="container">
                    <div className="row">

                      <div className="col-md-12">
                        <div className="form-group mb-4">
                          <span> <img src={image.mail} alt="" /></span>
                          <input className="form-control" type="email"
                            placeholder="Your Email ID" onChange={(e) => setEmail(e.target.value)} />
                        </div>
                      </div>
                      <div className="col-md-12">
                        <div className="form-group mb-4">
                        <FlagDropdown />
                          <input className="form-control" type="text" placeholder="Your Mobile Number"
                            onChange={(e) => setPhone(e.target.value)} />
                        </div>
                      </div>

                      <div className="col-12">
                        <div className="form-group mb-4">
                          <button className="mb-3 btn btn_primary" type="submit"
                            onClick={() => { validateForm() }}>CONTINUE </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
                <a href="#" className="create-btn">Create New Account</a>
              </div>


            </div>
          </div>
          <div className="col-lg-7">
            <div className="right-side">
              <img src={image.bg} alt="" class="bg-img" />
              <img src={image.car} alt="" class="car-img" />
            </div>
          </div>
        </div>

      </div>

    </>
  )
}