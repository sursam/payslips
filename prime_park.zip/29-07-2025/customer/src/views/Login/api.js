import Service from "../../service";
import { buildUrl } from "../../service/urlBuilder";

export const loginWithCredential = async (payload) => {
    const url = buildUrl('login');
    return Service.post(url, payload)
}