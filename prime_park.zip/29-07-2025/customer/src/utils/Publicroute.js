import { Outlet, Navigate } from 'react-router-dom'

const Publicroute = () => {
    const token = localStorage.getItem('prime_access_token');
    return token ? <Navigate to="/booking-list" /> : <Outlet />;
}

export default Publicroute