import { combineReducers } from '@reduxjs/toolkit';
import userReducer from '../views/Login/userSlice';

const rootReducer = combineReducers({
  user: userReducer
});

export default rootReducer;
