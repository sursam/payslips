export const buildUrl = (path) => {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    if (!baseUrl) {
      throw new Error('Server Error.');
    }
    return `${baseUrl}/${path}`;
  };
  