import axios from 'axios';
import store from '../store';

const Service = {

  get: async (url) => {
    const state = store.getState();
    const { user } = state?.user;
    try {
      const apiData = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        }
      });

      return apiData;
    } catch (error) {
      throw error;
    }
  },
  getWithoutToken: async (url) => {
    try {
      const apiData = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      return apiData;
    } catch (error) {
      throw error; // Re-throw the error to be handled by the calling code
    }
  },
  getWithParams: (url, key, value) => {
    const state = store.getState();
    const { user } = state;
    try {
      const apiData = axios.get(
        url,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${user?.webLogin}`
          },
          params: {
            [key]: value
          }
        }
      );

      return apiData;
    } catch (error) {
      throw error; // Re-throw the error to be handled by the calling code
    }
  },
  post: (url, data) => {
    const state = store.getState();
    const { user } = state;
    const apiData = axios.post(
      url,
      data,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        }
      }
    );
    return apiData;
  },
  patch: (url, data) => {
    const state = store.getState();
    const { user } = state;
    const apiData = axios.patch(
      url,
      data,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        }
      }
    );
    return apiData;
  },
  getWithData: (url, data) => {
    const state = store.getState();
    const { user } = state;
    try {
      const apiData = axios.get(
        url,
        data,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${user?.webLogin}`
          }
        }
      );

      return apiData;
    } catch (error) {
      throw error; // Re-throw the error to be handled by the calling code
    }
  },
  delete: (url) => {
    const state = store.getState();
    const { user } = state;
    const apiData = axios.delete(
      url,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        }
      }
    );
    return apiData;
  },
  deleteWithBody: (url, data) => {
    const state = store.getState();
    const { user } = state;
    const apiData = axios.delete(
      url,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        },
        data,
      }
    );
    return apiData;
  },
  put: (url, data) => {
    const state = store.getState();
    const { user } = state;
    const apiData = axios.put(
      url,
      data,
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${user?.webLogin}`
        }
      }
    );
    return apiData;
  },
  postWithFile: (url, data) => axios.post(
    url,
    data,
    {
      headers: { 'Content-Type': 'multipart/form-data' }
    }
  ),
  postTokenWithFile: (url, data) => {
    const token = '';
    return axios.post(
      url,
      data,
      {
        headers: {
          'Access-Control-Allow-Origin': '*', Accept: 'application/json', 'Content-Type': 'multipart/form-data', Authorization: `Bearer ${token}`
        }
      }
    );
  },
  postToken: async (url, data) => {
    const token = '';
    return axios.post(
      url,
      data,
      {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Access-Control-Allow-Origin': '*',
          Authorization: `Bearer ${token}`
        }
      }
    );
  },
  updateLead: async (url, headers, data) => axios({
    method: 'put',
    url,
    headers,
    data
  }),
  custom: async ({
    url, method, headers, responseType, data
  }) => axios({
    method,
    url,
    headers,
    responseType,
    data
  }),
  // initInterceptors: () => {
  //   useAxiosInterceptors();
  //   // }
  // },
};

// Service.initInterceptors();

export default Service;
