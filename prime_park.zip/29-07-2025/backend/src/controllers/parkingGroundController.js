const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const parkingBusinessesModel = db.ParkingBusinesses;
const parkingGroundsModel = db.ParkingGrounds;

class ParkingGroundController extends BaseController {
  constructor() {
    super();
  }

  static parkingGroundsList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      where: {
        isActive: true,
        deletedAt: null,
      },
      include: [
        {
          model: parkingBusinessesModel,
        },
      ],
    };
    let parkingGrounds = await super.getList(req, parkingGroundsModel, options);

		if(parkingGrounds.length > 0){
			return res.status(200).json({
				status: true,
				message: "Parking grounds found.",
				data: parkingGrounds,
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "No parking grounds found.",
				data: [],
			});
		}
  });
}

module.exports = ParkingGroundController;
