const axios = require("axios");
const BaseController = require("./BaseController.js");
const catchAsyncErrors = require("../middleware/catchAsyncErrors.js");
const ErrorHandler = require("../utils/errorHandler.js");
const RequestHandler = require("../utils/RequestHandler.js");
const fileUploaderSingle = require("../utils/fileUpload.js").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken.js");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config/index.js").JWT;
const { Op, Sequelize } = require("sequelize");
const APPURL = require("../config/index.js").APPURL;
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer");
const sendPushNotification = require("../helpers/sendPushNotification.js");

const timeZone = require("../config/index.js").Timezone;
const moment = require("moment-timezone");
const ccEmail = process.env.CC_EMAIL;

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities.js");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants.js");
const sendMail = require("../helpers/email.js");
const requestHandler = new RequestHandler();

const db = require("../models/index.js");
const userModel = db.Users;
const roleModel = db.Roles;
const modulePermissionsModel = db.ModulePermissions;
const vendorModel = db.Vendors;
const priceChartsModel = db.PriceCharts;
const staticChargesModel = db.StaticCharges;
const parkingLotsModel = db.ParkingLots;
const slotsModel = db.Slots;
const bookingRequestsModel = db.BookingRequests;
const vehicleTypesModel = db.VehicleTypes;
const agentModel = db.Agents;
const agentBookingMappingsModel = db.AgentBookingMappings;
const carMovementsModel = db.CarMovements;
const invoiceModel = db.Invoices;
const notificationModel = db.Notifications;
const policiesModel = db.Policies;
const transactionModel = db.Transactions;
const transactionLogsModel = db.TransactionLogs;
const transactionHistoryModel = db.TransactionHistory;

class DashboardController extends BaseController {
  constructor() {
    super();
  }

  static newBookingsListForDashboard = catchAsyncErrors(async (req, res, next) => {
      let { parkingGroundId } = req.body;

      if (!parkingGroundId) {
        return res.status(422).json({
          status: false,
          message: "Parking ground id is required.",
          data: {},
        });
      }

      let loggedUserId = req.user.id;

      let loggedUserDetail = await super.getByCustomOptionsSingle(
        req,
        userModel,
        {
          where: {
            id: loggedUserId,
          },
          include: [
            {
              model: roleModel,
            },
          ],
        }
      );

      let roleOfLoggedUser = await super.getByCustomOptionsSingle(
        req,
        roleModel,
        {
          where: {
            id: loggedUserDetail?.roleId,
          },
        }
      );

      let options = {
        include: [
          {
            model: userModel,
            attributes: {
              exclude: [
                "password",
                "webLogin",
                "appLogin",
                "fcmToken",
                "OTP",
                "macAddress",
              ],
            },
            required: false,
          },
          {
            model: slotsModel,
            required: false,
          },
          {
            model: agentBookingMappingsModel,
            include: [
              {
                model: agentModel,
                required: false,
              },
            ],
          },
        ],
        where: {
          parkingGroundId: parkingGroundId,

          bookingStatus: "Booked",

          isActive: true,
          deletedAt: null,
        },
        order: [["createdAt", "DESC"]],
      };

      let totalCount = await bookingRequestsModel.count({ where: options.where });
      // let totalCount = await bookingRequestsModel.count();
      let bookingRequests = await super.getList(
        req,
        bookingRequestsModel,
        options
      );

      let filteredBookingRequestsUserWise = [];
      filteredBookingRequestsUserWise = bookingRequests;

      // if(roleOfLoggedUser.roleName == "Super Admin"){
      // 	filteredBookingRequestsUserWise = bookingRequests;
      // }

      // if(roleOfLoggedUser.roleName == "Agent"){
      // 	// --------- agent can only see the bookings he is tagged in ---------
      // 	// filteredBookingRequestsUserWise = bookingRequests.filter(async (bookingRequest)=>{
      // 	// 	if(bookingRequest?.agentBookingMapping?.agent?.userId == loggedUserId){
      // 	// 		return bookingRequest;
      // 	// 	}
      // 	// });
      // }

      if (filteredBookingRequestsUserWise.length > 0) {
        return res.status(200).json({
          status: true,
          message: "Data found.",
          data: filteredBookingRequestsUserWise,
          totalCount: totalCount,
        });
      } else {
        return res.status(200).json({
          status: false,
          message: "No data found.",
          data: [],
					totalCount: totalCount,
        });
      }
	});

  static monthlyRevenue = catchAsyncErrors(async (req, res, next) => {
    let { date, timezone } = req.body;

    if (!date) {
      return res.status(422).json({
        status: false,
        message: "Date is required.",
        data: {},
      });
    }

    timezone = timezone || "UTC"; // Default to UTC if timezone is not provided

    let startDate = moment
      .tz(date, "YYYY-MM-DD", timezone)
      .startOf("month")
      .toDate();
    let endDate = moment
      .tz(date, "YYYY-MM-DD", timezone)
      .endOf("month")
      .toDate();

    let transactionHistoriesForMonth = await transactionHistoryModel.findAll({
      where: {
        isSuccess: true,
        createdAt: { [Op.between]: [startDate, endDate] },
      },
      attributes: [
        [Sequelize.fn("SUM", Sequelize.col("paidAmount")), "totalAmountPaid"],
      ],
			raw: true,
    });

    let totalAmountPaid = Number(transactionHistoriesForMonth[0].totalAmountPaid)/100;

    return res.status(200).json({
      status: true,
      message: `Successfully fetched total amount paid for current month in dollars.`,
      data: totalAmountPaid,
    });
  });

  static getMonthlyCheckInsAndCheckOuts = catchAsyncErrors(async (req, res, next) => {
		let { parkingGroundId } = req.body;
		const currentDate = moment.tz("Asia/Kolkata");

		// Adjust timezone if necessary
		const pastSixMonths = [];
		for (let i = 0; i < 6; i++) {
			const date = currentDate.clone().subtract(i, "months").startOf("month");
			pastSixMonths.push(date.format("YYYY-MM"));
		}

		const results = await bookingRequestsModel.findAll({
			where: {
				parkingGroundId: parkingGroundId,
				createdAt: {
					[Op.gte]: moment().subtract(6, "months").startOf("month").toDate(),
				},
				bookingStatus: { [Op.or]: ["Checked In", "Checked Out"] },
			},
			attributes: [
				[
					Sequelize.fn("DATE_FORMAT", Sequelize.col("createdAt"), "%Y-%m"),
					"month",
				],
				[
					Sequelize.fn("COUNT", Sequelize.col("bookingStatus")), "totalCount"
				],
				"bookingStatus",
			],
			group: ["month", "bookingStatus"],
			order: [["month", "ASC"]],
		});

		const monthlyData = {};

		pastSixMonths.forEach((month) => {
			monthlyData[month] = { checkIns: 0, checkOuts: 0 };
		});

		results.forEach((result) => {
			const month = result.get("month");
			const status = result.get("bookingStatus");
			const count = result.get("totalCount");

			if (status === "Checked In") {
				monthlyData[month].checkIns = count;

			} else if (status === "Checked Out") {
				monthlyData[month].checkOuts = count;

			}
		});

		return res.status(200).json({
			status: true,
			message: "Total check-ins and check-outs for the past six months",
			data: monthlyData,
		});
		
	});
}

module.exports = DashboardController;
