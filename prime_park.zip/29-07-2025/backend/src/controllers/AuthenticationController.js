const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const Mailable = require("../helpers/email");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const pkg = require("getmac").default;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const userModel = db.Users;
const roleModel = db.Roles;
const modulesModel = db.Modules;

// const rollModel = require('../models/rollModel');
// const rolePermissionModel = require('../models/rolePermissionModel');
// const rolePermissionUserwiseModel = require('../models/rolePermissionUserwiseModel');

class AuthenticationController extends BaseController {
  constructor() {
    super();
  }

  // ===================== Park Prime APIs WEB =====================
  static login = catchAsyncErrors(async (req, res, next) => {
    const { email, dialcode, phone, password, deviceType, fcmToken, deviceId, platform, } = req.body;

    // deviceType => 1-App, 2-web
    // platform => "AdminPanel" <OR> "CustomerPanel"

    let rolesNotAllowedIdsArr = [];
    if(
      (deviceType == 2)
      && (platform == "AdminPanel")
    ){
      let rolesNotAllowedToLoginFromAdminPanel = await super.getByCustomOptions(req, roleModel, {
        where: {
          roleName: {
            [Op.in]: ["Customer", "Guest"]
          }
        },
      });

      rolesNotAllowedToLoginFromAdminPanel.forEach((role)=>{
        rolesNotAllowedIdsArr.push(role.id);
      });
    } else if (
      (deviceType == 1)
      && (platform == "CustomerPanel")
    ){
      let rolesNotAllowedToLoginFromCustomerPanel = await super.getByCustomOptions(req, roleModel, {
        where: {
          roleName: {
            [Op.in]: ["Super Admin", "Agent", "Vendor", "Supervisor", "Manager", "Corporate"]
          }
        },
      });

      rolesNotAllowedToLoginFromCustomerPanel.forEach((role)=>{
        rolesNotAllowedIdsArr.push(role.id);
      });
    } else if (
      (deviceType == 2)
      && (platform == "CustomerPanel")
    ){
      let rolesNotAllowedToLoginFromCustomerPanel = await super.getByCustomOptions(req, roleModel, {
        where: {
          roleName: {
            [Op.in]: ["Super Admin", "Agent", "Vendor", "Supervisor", "Manager", "Corporate"]
          }
        },
      });

      rolesNotAllowedToLoginFromCustomerPanel.forEach((role)=>{
        rolesNotAllowedIdsArr.push(role.id);
      });
    }
    
    let condition = {
      isVerified: true,
    };
    if (email) {
      condition["email"] = email;
    } else if (phone) {
      condition["phone"] = phone;
    }

    // if (deviceType == 1) {
    //   if (!dialcode) {
    //     return next(new ErrorHandler("Please enter dialcode.", 403));
    //   } else {
    //     condition["dialcode"] = dialcode;
    //   }
    // }

    let user = await userModel.findOne({
      where: {
        ...condition,
        isActive: true,
      },
    });

    if (user) {
      if(rolesNotAllowedIdsArr.includes(user.roleId)){
        return res.status(401).json({
          status: false,
          message: "You are not authorized to use this panel with these credentials. If you are an admin user or employee, please use specific panel. If you are a customer, head to the customer panel to book a spot. If you think, you are seeing this message by mistake, please contact the admin.",
          data: {},
        });
      }
      // Password comparison
      if (!bcrypt.compareSync(password, user.password)) {
        return res.status(400).json({
          status: false,
          message: "Password does not match..!!",
          data: {},
        });
      } else {
        // Destructure user properties to exclude password
        const { id, roleId, firstName, lastName, email, dialCode, phone, ...rest } = user;

        let MAC = pkg();
        // console.log(MAC);

        let token = JWTAuth.ClientSign({
          id: id,
          roleId: roleId,
          firstName: firstName,
          lastName: lastName,
          email: email,
          phone: phone,
          deviceType: deviceType,
          macAddress: MAC,
        });

        let time = new Date();
        time.setDate(time.getDate() + 30);
        time = new Date(time);

        let conditions = { email: email };
        let updateFields = {
          loginFlag: true,
          macAddress: MAC,
        };
        
        if (Number(deviceType) == 2) {
          updateFields.webLogin = token;
          updateFields.deviceId = deviceId ? deviceId : "";
        } else {
          updateFields.appLogin = token;
          updateFields.fcmToken = fcmToken ? fcmToken : "";
          updateFields.deviceId = deviceId ? deviceId : "";
        }

        let userDetailsUpdate = await super.updateByCustomOptions(
          userModel,
          conditions,
          updateFields
        );
        
        let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
          where: { email: email },
        });
        
        let userDetails = JSON.parse(JSON.stringify(userDetail));

        // Add necessary fields to userDetails and remove password ====
        let userDetailsToBeSent = {
          id,
          roleId,
          firstName,
          lastName,
          email,
          dialCode,
          phone,
          loginFlag: userDetails.loginFlag,
          isActive: userDetails.isActive,
          isVerified: userDetails.isVerified,
          webLogin: userDetails.webLogin,
          appLogin: userDetails.appLogin,
          fcmToken: userDetails.fcmToken,
          macAddress: userDetails.macAddress,
          deviceId: userDetails.deviceId,
          name: `${firstName} ${lastName}`,
          userImageUrl: process.env.API_URL + "uploads/userImages/",
          profileImage: userDetails.profileImage
            ? `${process.env.API_URL}uploads/userImages/${userDetails.profileImage}`
            : `${process.env.API_URL}uploads/userImages/demo_image.jpg`,
        };

        if (userDetailsUpdate) {
          return res.status(200).json({
            status: true,
            message: "Logged in.",
            data: {
              user: userDetailsToBeSent,
            },
          });
        } else {
          return res.status(500).json({
            status: false,
            message: "Oops.. Something went terribly wrong..",
            data: {},
          });
        }
      }
    } else {
      return res.status(400).json({
        status: false,
        message: "No user with these credentials found..!!",
        data: {},
      });
    }
  });

  static logout = catchAsyncErrors(async (req, res, next) => {
    let time = new Date();
    time.setDate(time.getDate() - 1);
    time = new Date(time);
    let data = {};
    if (Number(req.user.deviceType) == 2) {
      data = {
        webLogin: null,
      };
    } else {
      data = {
        appLogin: null,
      };
    }

    // turning login flag off =====
    data.loginFlag = false
    // turning login flag off =====
    
    let updated = await super.updateById(
      userModel,
      req.user.id.toString(),
      data
    );
    if (updated) {
      return res.status(200).json({
        status: true,
        message: "Logged out successfully",
      });
    }
  });

  static roleList = catchAsyncErrors(async (req, res, next) => {
    let roles = [];
    let queryConditions = {};

    if (req.method == "POST") {
      queryConditions = {
        where: {
          deletedAt: null,
          roleName: {
            [Op.notIn]: ["Super Admin", "Vendor", "Guest", "Agent",]
          },
        }
      };
    } else if (req.method == "GET"){
      queryConditions = {
        where: {
          deletedAt: null,
          roleName: {
            [Op.not]: "Super Admin",
          },
        }
      };
    }

    roles = await roleModel.findAll(queryConditions);
  
    if(roles){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roles
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found..!!",
        data: {}
      });
    }
  });

  static moduleList = catchAsyncErrors(async (req, res, next) => {
    let modules = [];
    const queryConditions = {
      where: {
        deletedAt: null,
      }
    };

    modules = await modulesModel.findAll(queryConditions);
  
    let userWithModules = [];
    let moduleAccessIdArr = [];
    let filteredModules = modules;
    if(req.user.id != 1){
      userWithModules = await userModel.findByPk(req.user.id, {
        include: modulesModel
      });
      userWithModules.modules.forEach((item)=>{
        moduleAccessIdArr.push(item.id);
      });
      filteredModules = modules.filter((item)=>{
        if(moduleAccessIdArr.includes(item.id)){
          return item;
        }
      });
    }

    if(filteredModules){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: filteredModules
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found..!!",
        data: {}
      });
    }
  });

  // static roleWiseModuleList = catchAsyncErrors(async (req, res, next) => {
  //   let { roleId } = req.body;
  //   let modules = [];
  //   const queryConditions = {
  //     where: {
  //       deletedAt: null,
  //     }
  //   };

  //   modules = await modulesModel.findAll(queryConditions);
  
  //   let userWithModules = [];
  //   let moduleAccessIdArr = [];
  //   let filteredModules = modules;
  //   if(req.user.id != 1){
  //     userWithModules = await userModel.findByPk(req.user.id, {
  //       include: modulesModel
  //     });
  //     userWithModules.modules.forEach((item)=>{
  //       moduleAccessIdArr.push(item.id);
  //     });
  //     filteredModules = modules.filter((item)=>{
  //       if(moduleAccessIdArr.includes(item.id)){
  //         return item;
  //       }
  //     });
  //   }

  //   if(filteredModules){
  //     return res.status(200).json({
  //       status: true,
  //       message: "Success",
  //       data: filteredModules
  //     });
  //   } else{
  //     return res.status(200).json({
  //       status: false,
  //       message: "No records found..!!",
  //       data: {}
  //     });
  //   }
  // });
  // ===================== Park Prime APIs WEB =====================


  static socialLogin = catchAsyncErrors(async (req, res, next) => {
    const { email, deviceType, userType, provider } = req.body;
    if (!email) {
      return next(new ErrorHandler("Email Required", 400));
    }
    let isRegistered = false;
    let condition = { email: email };
    if (userType && userType != "" && userType != null) {
      let roles = [];
      let role = await rollModel.find({
        name: "Driver",
      });
      if (userType == "Customer") {
        role = await rollModel.find({
          name: { $in: ["Corporate User", "Customer"] },
        });
      } else if (userType == "Corporate") {
        role = await rollModel.find({
          name: { $in: ["Corporate", "Vendor", "School"] },
        });
      }
      if (role.length > 0) {
        role.forEach((val) => {
          roles.push(val._id.toString());
        });
      }

      condition["roleId"] = { $in: roles };
    }
    const userExists = await userModel.findOne(condition);
    if (userExists) {
      isRegistered = true;
    }
    const currentDateTime = new Date();
    // const expirationDateTime = new Date(userExists.otp.expiration);
    if (
      // userExists.otp.expiration
      // && currentDateTime < expirationDateTime
      isRegistered == true
    ) {
      await userModel
        .findOne({
          email: email,
        })
        .then(async (user) => {
          if (user) {
            const { _id, firstName, lastName, email } = user;
            let token = JWTAuth.ClientSign({
              _id,
              firstName,
              lastName,
              email,
              deviceType,
              userType,
            });
            let time = new Date();
            time.setDate(time.getDate() + 30);
            time = new Date(time);
            let data = {};
            if (Number(deviceType, userType) == 2) {
              data = {
                webLogin: {
                  provider: provider ? provider : null,
                  accessToken: token,
                },
              };
            } else {
              data = {
                appLogin: {
                  provider: provider ? provider : null,
                  accessToken: token,
                },
              };
            }
            let userDetailUpdate = await userModel.findByIdAndUpdate(
              userExists._id,
              data
            );
            let userDetail = await userModel.findOne({ email: email });

            let userDetails = JSON.parse(JSON.stringify(userDetail));
            userDetails.name =
              userDetails.firstName + " " + userDetails.lastName;

            if (userDetailUpdate) {
              return requestHandler.sendSuccess(
                res,
                "Login Successfully"
              )({
                token,
                isRegistered: isRegistered,
                user: userDetails,
              });
            } else {
              return requestHandler.customError(
                res,
                500,
                "Something went wrong..!!"
              );
            }
          } else {
            return requestHandler.customError(res, 400, "User not found..!!");
          }
        })
        .catch((error) => {
          console.log(error);
          return requestHandler.customError(res, 500, error);
        });
    } else {
      return requestHandler.customError(res, 404, "User not found.");
    }
  });

  static rolePermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let rolePermissionChecker = [];
    let roleId = req.body.roleId;

    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({
      isActive: true,
      isDeleted: false,
    });
    let modulesArr = [];
    modules.forEach((module) => {
      modulesArr.push(module._id);
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({ roleId: super_admin._id })
        .then(async (item) => {
          await rolePermissionModel.findByIdAndUpdate(item._id, {
            roleId: super_admin._id,
            moduleId: modulesArr,

            updatedBy: super_admin._id,
          });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========

    await rolePermissionModel
      .findOne({
        roleId: roleId,
      })
      .then(async (item) => {
        if (item != null) {
          item?.moduleId.forEach((item) => {
            rolePermissionChecker.push(item.toString());
          });
        }
        if (rolePermissionChecker.length > 0) {
          return res.status(200).json({
            status: true,
            message: "Success, permissions found.",
            data: rolePermissionChecker,
          });
        } else {
          return res.status(401).json({
            status: false,
            message:
              "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
            data: rolePermissionChecker,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        return res.status(500).json({
          status: false,
          message: "Oops..!! Something went terribly wrong..!!",
          data: rolePermissionChecker,
        });
      });
  });
  static userPermissionChecker = catchAsyncErrors(async (req, res, next) => {
    let userPermissionChecker = [];
    let roleId = req.body.roleId;
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    const modules = await moduleModel.find({
      isActive: true,
      isDeleted: false,
    });
    let modulesArr = [];

    modules.forEach((module) => {
      modulesArr.push(module._id);
    });
    const super_admin = await rollModel.findOne({ name: "Super Admin" });
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({ roleId: super_admin._id })
        .then(async (item) => {
          await rolePermissionModel.findByIdAndUpdate(item._id, {
            roleId: super_admin._id,
            moduleId: modulesArr,
            updatedBy: super_admin._id,
          });
        });
    }
    // ============== if superAdmin is trying to logIn give all module permissions by default ==========
    if (roleId == super_admin._id) {
      await rolePermissionModel
        .findOne({
          roleId: roleId,
        })
        .then(async (item) => {
          if (item != null) {
            item?.moduleId.forEach((item) => {
              userPermissionChecker.push(item.toString());
            });
          }
          if (userPermissionChecker.length > 0) {
            return res.status(200).json({
              status: true,
              message: "Success, permissions found.",
              data: userPermissionChecker,
            });
          } else {
            return res.status(401).json({
              status: false,
              message:
                "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
              data: userPermissionChecker,
            });
          }
        })
        .catch((error) => {
          return res.status(500).json({
            status: false,
            message: "Oops..!! Something went terribly wrong..!!",
            data: userPermissionChecker,
          });
        });
    } else {
      await rolePermissionUserwiseModel
        .findOne({
          userId: req.user._id,
        })
        .then(async (item) => {
          if (item != null) {
            item?.moduleId.forEach((item) => {
              userPermissionChecker.push(item.toString());
            });
          }
          if (userPermissionChecker.length > 0) {
            return res.status(200).json({
              status: true,
              message: "Success, permissions found.",
              data: userPermissionChecker,
            });
          } else {
            return res.status(401).json({
              status: false,
              message:
                "Oops..!! Looks like your role has no module permissions set yet. Please contact admin.",
              data: userPermissionChecker,
            });
          }
        })
        .catch((error) => {
          return res.status(500).json({
            status: false,
            message: "Oops..!! Something went terribly wrong..!!",
            data: userPermissionChecker,
          });
        });
    }
  });

  static forgetPassword = catchAsyncErrors(async (req, res, next) => {
    const { email, otp, password, userType } = req.body;
    if (!email) {
      return next(new ErrorHandler("Please enter email", 400));
    }
    if (otp && otp != "" && otp != null) {
      const userExists = await userModel.findOne({ email: email });
      if (userExists.otp && userExists.otp.code == otp) {
        // return res.status(200).json({
        //   status: true,
        //   message: "OTP matched",
        // });
      } else {
        return requestHandler.customError(res, 404, "OTP doesn't match");
      }
    } else {
      let isRegistered = false;
      let condition = { email: email };
      if (userType && userType != "" && userType != null) {
        let roles = [];
        let role = await rollModel.find({
          name: "Driver",
        });
        if (userType == "Customer") {
          role = await rollModel.find({
            name: { $in: ["Corporate User", "Customer"] },
          });
        } else if (userType == "Corporate") {
          role = await rollModel.find({
            name: { $in: ["Corporate", "Vendor", "School"] },
          });
        }
        if (role.length > 0) {
          role.forEach((val) => {
            roles.push(val._id.toString());
          });
        }
        condition["roleId"] = { $in: roles };
      }
      const userExists = await userModel.findOne(condition);
      if (userExists) {
        isRegistered = true;
      }

      if (isRegistered == true) {
        if (password && password != "" && password != null) {
          let pass = await bcrypt.hash(password, 10);

          let updated = await super.updateById(
            userModel,
            userExists._id.toString(),
            { password: pass }
          );
          if (updated) {
            return res.status(200).json({
              status: true,
              message: "Password changed successfully",
            });
          }
        } else {
          const otpcode = Math.floor(1000 + Math.random() * 9000);
          const currentDateTime = new Date();
          const expirationDateTime = new Date(
            currentDateTime.setMinutes(currentDateTime.getMinutes() + 5)
          );
          let userDetail = await userModel.findByIdAndUpdate(userExists._id, {
            otp: {
              code: otpcode,
              expiration: expirationDateTime,
            },
          });

          return res.status(200).json({
            status: true,
            message: "OTP sent to your email",
            otp: otpcode,
          });
        }
      } else {
        return requestHandler.customError(res, 404, "User not found.");
      }
    }
  });

  static changePassword = catchAsyncErrors(async (req, res, next) => {
    const { old_password, password } = req.body;
    if (!old_password) {
      return next(new ErrorHandler("Old password required", 400));
    }
    if (!password) {
      return next(new ErrorHandler("New password required", 400));
    }
    let userExists = await userModel
      .findOne({ _id: req.user._id.toString() })
      .select("password");
    const isPasswordMatched = await userExists.comparePassword(old_password);
    if (!isPasswordMatched) {
      return res.status(400).json({
        status: false,
        message: "Old password does not match!",
        data: {},
      });
    } else {
      let pass = await bcrypt.hash(password, 10);
      let updated = await super.updateById(userModel, req.user._id.toString(), {
        password: pass,
      });
      if (updated) {
        return res.status(200).json({
          status: true,
          message: "Password changed successfully",
        });
      } else {
        return res.status(500).json({
          status: false,
          message: "Something went wrong",
        });
      }
    }
  });

  static deactivateAccount = catchAsyncErrors(async (req, res, next) => {
    const { isActive } = req.body;
    let data = {
      isActive: isActive,
    };
    if (isActive == false) {
      data["webLogin"] = null;
      data["appLogin"] = null;
    }

    let updated = await super.updateById(
      userModel,
      req.user._id.toString(),
      data
    );
    if (updated) {
      return res.status(200).json({
        status: true,
        message: "Updated successfully",
      });
    }
  });

  // =============================== App APIs ===========================
  static roleListForApp = catchAsyncErrors(async (req, res, next) => {
    let roles = [];
    let appRoles = [];
    let serviceRolesIdArr = [];
    if (req.method == "GET") {
      let userServices = await customerModel.find({
        userId: req.user._id,
      });
      userServices.forEach((userService) => {
        serviceRolesIdArr.push(userService.roleId.toString());
      });
      // for dropdown =====
      roles = await rollModel.find({
        isDeleted: { $ne: true },
        name: { $ne: "Super Admin" },
      });

      roles.forEach((role) => {
        if (serviceRolesIdArr.includes(role._id.toString())) {
          if (role.name == "Customer") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Individual",
            };
            appRoles.push(roleObj);
          } else if (role.name == "Employee") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Corporate Employee",
            };
            appRoles.push(roleObj);
          } else if (role.name == "Student") {
            let roleObj = {
              _id: role._id,
              name: role.name,
              displayName: "Student/Parent",
            };
            appRoles.push(roleObj);
          }
        }
      });
    } else if (req.method == "POST") {
      // roles = await rollModel.find({ isDeleted: { $ne: true }, name: { $ne: 'Super Admin'} });
    }

    if (appRoles.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: appRoles,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No Roles Found.",
        data: [],
      });
    }
  });
  // =============================== App APIs ===========================
}

module.exports = AuthenticationController;
