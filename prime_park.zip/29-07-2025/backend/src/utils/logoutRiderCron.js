const cron = require('node-cron');
const moment = require('moment-timezone');

// Define your logout times (14:00 and 14:10) in the Asia/Kolkata timezone
const logoutTime1 = moment.tz('14:00', 'HH:mm', 'Asia/Kolkata');
const logoutTime2 = moment.tz('14:10', 'HH:mm', 'Asia/Kolkata');

// Create a cron job that runs daily at the specified times in the Asia/Kolkata timezone
const job = cron.schedule('0 14 * * *', () => {
    const currentTime = moment.tz('Asia/Kolkata');

    // Check if the current time matches either of the logout times
    if (currentTime.isSame(logoutTime1) || currentTime.isSame(logoutTime2)) {
        // Implement your rider logout logic here
        // For example, you can call a function to log out riders here
        logoutRiders();
    }
}, {
    scheduled: true,
    timezone: 'Asia/Kolkata',
});

// Start the cron job
job.start();

// Function to log out riders
function logoutRiders() {
    // Implement your rider logout logic here
    // This is where you should write the code to log out the riders
    // For example, you can make API requests to the rider accounts to log them out.
    // Make sure to handle errors and perform the necessary logout actions.
    console.log('For Testing Purpose ------------------------------------>>>>> Performing rider logout...');
}
