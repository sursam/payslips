const utils = require('./utilities')
const APPURL = require("../config/index").APPURL
const userDetails = (datas, rolePermissionsUserWise) => {
    if(Array.isArray(datas)){
        let users = []
        for(const data of datas){
            data._id = data._id.toString()
            data.role = data?.roleId?.name
            data.name = data.firstName+" "+data.lastName
            data.roleId = datas.roleId
            data.profileImage = data.profileImage? APPURL + "uploads/userImages/" + data.profileImage : APPURL + "uploads/userImages/" + 'demo_image.jpg'
            let moduleIdArr = []
            rolePermissionsUserWise.forEach((item)=>{
                item.moduleId.forEach((id)=>{
                    moduleIdArr.push(id.toString())
                });
            })
            data.moduleId = moduleIdArr

            users.push(data)
        }
        return users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['role'] = datas.roleId.name
        data['name'] = datas.firstName+" "+datas.lastName
        data['roleId'] = datas.roleId._id.toString()
        data.profileImage = data.profileImage? APPURL + "uploads/userImages/" + data.profileImage : APPURL + "uploads/userImages/" + 'demo_image.jpg'
        let moduleIdArr = []
        rolePermissionsUserWise?.moduleId.forEach((id)=>{
            moduleIdArr.push(id)
        });
        data['moduleId'] = moduleIdArr

        return data
    }
};
const vehicleCategoryDetails = (datas) => {
    if(Array.isArray(datas)){
        let vehicleModels = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['type'] = data.type.type
            vehicleModels.push(obj)
        }
        return vehicleModels.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['type'] = datas.type.type
        
        return data
    }
};
const vehicleModelDetails = (datas) => {
    if(Array.isArray(datas)){
        let vehicleModels = []
        for(const data of datas){
            let assetArr = []
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['model'] = data.modelId.model
            data.assets.forEach((asset)=>{
                assetArr.push(asset.assetType + " (" + asset.brand + ")");
            })
            obj['assets'] = assetArr
            obj['registrationNumber'] = data.registrationNumber
            obj['manufacturerDate'] = utils.dateFormatDDMMYYYY(data.manufacturerDate)
            obj['chassisNumber'] = data.chassisNumber

            vehicleModels.push(obj)
        }
        return vehicleModels.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        let assetArr = []
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['model'] = datas.modelId.model
        datas.assets.forEach((asset)=>{
            assetArr.push(asset.assetType + " (" + asset.brand + ")");
        })
        data['assets'] = assetArr
        data['registrationNumber'] = datas.registrationNumber
        data['manufacturerDate'] = utils.dateFormatDDMMYYYY(datas.manufacturerDate)
        data['chassisNumber'] = datas.chassisNumber

        return data
    }
};
const getPermissionDetails = (datas) => {
    if(Array.isArray(datas)){
        let role = []
        for(const data of datas){
            let modulesArr = []
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['roleName'] = data.roleId.name
            obj['roleId'] = datas.roleId
            data.moduleId.forEach((item)=>{
                modulesArr.push(item.moduleName + " (" + item?.moduleSlug + ")" + " (Parent: " + (item?.parentModuleId?.moduleSlug == undefined? "N/A":item?.parentModuleId?.moduleSlug) + ")")
            });
            obj['moduleName'] = modulesArr

            role.push(obj)
        }
        return role
    }else{
        let modulesArr = []
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['roleName'] = datas.roleId.name
        data['roleId'] = datas.roleId._id.toString()
        datas.moduleId.forEach((item)=>{
            modulesArr.push(item.moduleName + " (" + item?.moduleSlug + ")" + " (Parent: " + (item?.parentModuleId?.moduleSlug == undefined? "N/A":item?.parentModuleId?.moduleSlug) + ")")
        });
        obj['moduleName'] = modulesArr

        return data
    }
};
const corporateDetails = (datas) => {
    if(Array.isArray(datas)){
        let corporates = []
        for(const data of datas){
            data._id = data._id.toString()
            data.name = data.name
            data.countryCode = data.countryCode._id
            data.parentCorporateId = data.parentCorporateId
            data.payer = data.payment.payer
            data.paymentType = data.payment.paymentType
            data.organizations = []
            data.image = data.logoImage
            data.url = APPURL + "uploads/userImages/"
            data.logoImage = APPURL+"uploads/userImages/"+data.logoImage
            data.locations.forEach((branch)=>{
                let obj = {};
                obj.orgBranch = (branch.branchName)
                obj.orgAddress = (branch.locationName)
                obj.orgLatitude = (branch.location.coordinates[0])
                obj.orgLongitude = (branch.location.coordinates[1])

                data.organizations.push(obj)
            })
            data.roleOfCorporateType = data.userId.roleId;

            corporates.push(data)
        }
        return corporates.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['name'] = datas.name
        data['countryCode'] = datas.countryCode._id
        data['parentCorporateId'] = datas.parentCorporateId
        data['payer'] = datas.payment.payer
        data['paymentType'] = datas.payment.paymentType
        data['organizations'] = []
        data.image = data.logoImage
        data.url = APPURL + "uploads/userImages/"
        data.logoImage = APPURL+"uploads/userImages/"+data.logoImage
        datas.locations.forEach((branch)=>{
            let obj = {};
            obj.orgBranch = (branch.branchName)
            obj.orgAddress = (branch.locationName)
            obj.orgLatitude = (branch.location.coordinates[0])
            obj.orgLongitude = (branch.location.coordinates[1])

            data['organizations'].push(obj)
        });
        data['holidaysArr'] = []
        datas.holidays.forEach((holiday)=>{
            data['holidaysArr'].push(utils.dateFormatYYYYMMDD(holiday))
        });
        data['roleOfCorporateType'] = datas.userId.roleId;

        return data
    }
};
const vendorDriverMapDetails = (datas) => {
    if(Array.isArray(datas)){
        let vendorDriverMap = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['vendorName'] = data.vendorId.name + " (" + data.vendorId.supportEmail + ")" + " (" + data.vendorId.phoneNumber + ")"
            obj['driverName'] = data.driverId.userId.firstName + " " + data.driverId.userId.lastName + " (" + data.driverId.userId.email + ")" + " (" + data.driverId.userId.phone + ")"

            vendorDriverMap.push(obj)
        }
        return vendorDriverMap.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['vendorName'] = datas.vendorId.name + " (" + datas.vendorId.supportEmail + ")" + " (" + datas.vendorId.phoneNumber + ")"
        data['driverName'] = datas.driverId.userId.firstName + " " + datas.driverId.userId.lastName + " (" + datas.driverId.userId.email + ")" + " (" + datas.driverId.userId.phone + ")"

        return data
    }
};
const vendorCorporateMapDetails = (datas) => {
    if(Array.isArray(datas)){
        let vendorCorporateMap = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['vendorName'] = data.vendorId.name + " (" + data.vendorId.supportEmail + ")" + " (" + data.vendorId.phoneNumber + ")"
            obj['corporateName'] = data.corporateId.name + " (" + data.corporateId.supportEmail + ")" + " (" + data.corporateId.phoneNumber + ")"

            vendorCorporateMap.push(obj)
        }
        return vendorCorporateMap.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['vendorName'] = datas.vendorId.name + " (" + datas.vendorId.supportEmail + ")" + " (" + datas.vendorId.phoneNumber + ")"
        data['corporateName'] = datas.corporateId.name + " (" + datas.corporateId.supportEmail + ")" + " (" + datas.corporateId.phoneNumber + ")"

        return data
    }
};
const vendorVehicleMapDetails = (datas) => {
    if(Array.isArray(datas)){
        let vendorVehicleMap = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['vendorName'] = data.vendorId.name + " (" + data.vendorId.supportEmail + ")" + " (" + data.vendorId.phoneNumber + ")"
            obj['vehicleName'] = data.vehicleId.modelId.model + " (Reg No.- " + data.vehicleId.registrationNumber + ")" + " (Chassis No.- " + data.vehicleId.chassisNumber + ")" + " (" + data.vehicleId.capacity + " Seater)"

            vendorVehicleMap.push(obj)
        }
        return vendorVehicleMap.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['vendorName'] = datas.vendorId.name + " (" + datas.vendorId.supportEmail + ")" + " (" + datas.vendorId.phoneNumber + ")"
        data['vehicleName'] = datas.vehicleId.modelId.model + " (Reg No.- " + datas.vehicleId.registrationNumber + ")" + " (Chassis No.- " + datas.vehicleId.chassisNumber + ")" + " (" + datas.vehicleId.capacity + " Seater)"

        return data
    }
};
const tripStopDetails = (datas) => {
    if(Array.isArray(datas)){
        let tripStops = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['countryDetail'] = data.countryCode.name + " (" + data.countryCode.native + ")" + " (" + data.countryCode.currency + ")"
            obj['stopDetail'] = data.stopName + " (Addr.: " + data.address + ")" + " (Co-ordinates: [" + data.location.coordinates[0] + ", " + data.location.coordinates[1] + "])"
            obj['isDanger'] = data.dangerZone.status? "Yes":"No"

            tripStops.push(obj)
        }
        return tripStops.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['countryDetail'] = datas.countryCode.name + " (" + datas.countryCode.native + ")" + " (" + datas.countryCode.currency + ")"
        data['stopDetail'] = datas.stopName + " (Addr.: " + datas.address + ")" + " (Co-ordinates: [" + datas.location.coordinates[0] + ", " + datas.location.coordinates[1] + "])"
        data['isDanger'] = datas.dangerZone.status? "Yes":"No"

        return data
    }
};
const routeMapDetails = (datas) => {
    if(Array.isArray(datas)){
        let routeMap = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['countryDetail'] = data.countryCode.name + " (" + data.countryCode.native + ")" + " (" + data.countryCode.currency + ")"
            obj['routeDetail'] = data.routeName + " (" + data.routeDistance + " km.)" + " (" + data.routeTime + " hr)" + " (" + data.routeType + ")"
            obj['stopsDetail'] = []
            obj['firstStop'] = data.routeStops[0]
            obj['lastStop'] = data.routeStops[data.routeStops.length - 1]
            data.routeStops.forEach((stop)=>{
                obj['stopsDetail'].push(stop.stopId.stopType + " - " + stop.stopId.stopName + " (Addr.: " + stop.stopId.address +")" + " (Accessibility: " + stop.stopId.accessibility +")")
            });
            routeMap.push(obj)
        }
        return routeMap.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['countryDetail'] = data.countryCode.name + " (" + data.countryCode.native + ")" + " (" + data.countryCode.currency + ")"
        data['routeDetail'] = datas.routeName + " (" + datas.routeDistance + " km.)" + " (" + datas.routeTime + " hr.)" + " (" + datas.routeType + ")"
        data['stopsDetail'] = []
        datas.routeStops.forEach((stop)=>{
            data['stopsDetail'].push(stop.stopId.stopType + " - " + stop.stopId.stopName + " (Addr.: " + stop.stopId.address +")" + " (Accessibility: " + stop.stopId.accessibility +")")
        });

        return data
    }
};
const routeVehicleMapDetails = (datas) => {
    if(Array.isArray(datas)){
        let routeVehicleMappings = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            obj['countryDetail'] = data.routeId.countryCode.name + " (" + data.routeId.countryCode.native + ")" + " (" + data.routeId.countryCode.currency + ")"
            obj['routeDetail'] = data.routeId.routeName + " (" + data.routeId.routeDistance + " km.)" + " (" + data.routeId.routeTime + " hr)" + " (" + data.routeId.routeType + ")"
            obj['vehicleDetail'] = data.vehicleId.modelId.model + " (Reg. No.: " + data.vehicleId.registrationNumber + ")" + " (Chassis No.: " + data.vehicleId.chassisNumber + ")" + " (" + data.vehicleId.capacity + " Seater)"
        
            routeVehicleMappings.push(obj)
        }
        return routeVehicleMappings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        data['countryDetail'] = datas.routeId.countryCode.name + " (" + datas.routeId.countryCode.native + ")" + " (" + datas.routeId.countryCode.currency + ")"
        data['routeDetail'] = datas.routeId.routeName + " (" + datas.routeId.routeDistance + " km.)" + " (" + datas.routeId.routeTime + " hr)" + " (" + datas.routeId.routeType + ")"
        data['vehicleDetail'] = datas.vehicleId.modelId.model + " (Reg. No.: " + datas.vehicleId.registrationNumber + ")" + " (Chassis No.: " + datas.vehicleId.chassisNumber + ")" + " (" + datas.vehicleId.capacity + " Seater)"

        return data
    }
};
const couponDetails = (datas) => {
    if(Array.isArray(datas)){
        let coupons = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            obj['_id'] = data._id.toString()
            // obj['effectiveFrom'] = data.effectiveFrom.toISOString().split('T')[0]
            // obj['expiry'] = data.expiry.toISOString().split('T')[0]
            obj['effectiveFrom'] = utils.dateFormatDDMMYYYY(data.effectiveFrom)
            obj['expiry'] = utils.dateFormatDDMMYYYY(data.expiry)
            if(data?.corporateId?.userId?.firstName){
                obj['corporateDetail'] = data?.corporateId?.userId?.firstName + " " + data?.corporateId?.userId?.lastName + " (" + data?.corporateId?.userId?.email + ")" + " (" + data?.corporateId?.userId?.phone + ")" + " (" + data?.corporateId?.userId?.roleId?.name + ")"
            } else { 
                obj['corporateDetail'] = "N/A"
            }
        
            coupons.push(obj)
        }
        return coupons.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        data['_id'] = datas._id.toString()
        // data['effectiveFrom'] = utils.dateFormatDDMMYYYY(datas.effectiveFrom)
        // data['expiry'] = utils.dateFormatDDMMYYYY(datas.expiry)
        data['effectiveFrom'] = datas.effectiveFrom.toISOString().split('T')[0]
        data['expiry'] = datas.expiry.toISOString().split('T')[0]
        if(datas?.corporateId?.userId?.firstName){
            data['corporateDetail'] = datas?.corporateId?.userId?.firstName + " " + datas?.corporateId?.userId?.lastName + " (" + datas?.corporateId?.userId?.email + ")" + " (" + datas?.corporateId?.userId?.phone + ")" + " (" + datas?.corporateId?.userId?.roleId?.name + ")"
        } else { 
            data['corporateDetail'] = "N/A"
        }

        return data
    }
};
const tripPlanDetails = (datas) => {
    if(Array.isArray(datas)){
        let trips = []
        for(const data of datas){
            let obj = JSON.parse(JSON.stringify(data))
            let scheduleArr = []
            obj['_id'] = data._id.toString()
            data.schedule.forEach((item)=>{
                scheduleArr.push((item.dayName == "false")
                ? "Daily" + " (Start : " + item.startTime + ")" + " (End: " + item.endTime + ")"
                : item.dayName + " (Start : " + item.startTime + ")" + " (End: " + item.endTime + ")")
            });
            obj['scheduleDetails'] = scheduleArr
            obj['routeDetails'] = data.routeId.routeName + " (Distance: " +data.routeId.routeDistance + ")" + " (Stops: " + data.routeId.routeStops.length + ")"
            obj['vendorDetails'] = data?.vendorId?.name + " (Email: " + data?.vendorId?.supportEmail + ")" + " (Phone: " + data?.vendorId?.phoneNumber + ")"


            trips.push(obj)
        }
        return trips.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    } else{
        const data = JSON.parse(JSON.stringify(datas))
        let scheduleArr = []
        data['_id'] = datas._id.toString()
        datas.schedule.forEach((item)=>{
            scheduleArr.push((item.dayName == "false")
            ? "Daily" + " (Start : " + item.startTime + ")" + " (End: " + item.endTime + ")"
            : item.dayName + " (Start : " + item.startTime + ")" + " (End: " + item.endTime + ")")
        });
        data['scheduleDetails'] = scheduleArr
        data['routeDetails'] = datas.routeId.routeName + " (Distance: " +datas.routeId.routeDistance + ")" + " (Stops: " + datas.routeId.routeStops.length + ")"
        data['vendorDetails'] = datas?.vendorId?.name + " (Email: " + datas?.vendorId?.supportEmail + ")" + " (Phone: " + datas?.vendorId?.phoneNumber + ")"

        return data
    }
}

module.exports = {
    userDetails,
    vehicleCategoryDetails,
    vehicleModelDetails,
    getPermissionDetails,
    corporateDetails,
    vendorDriverMapDetails,
    vendorCorporateMapDetails,
    vendorVehicleMapDetails,
    tripStopDetails,
    routeMapDetails,
    routeVehicleMapDetails,
    couponDetails,
    tripPlanDetails,
}