module.exports = (sequelize, DataTypes) => {
  const usersSchema = sequelize.define("users", {
    roleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'roles',
        key: 'id'
      },
      allowNull: false,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dialCode: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    phone: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    dob: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    gender: {
      type: DataTypes.ENUM("Male", "Female", "Others"),
      allowNull: true,
      defaultValue: "Others",
    },
    profileImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    // reportingId: {
    //   type: DataTypes.INTEGER,
    //   allowNull: true,
    // },
    
    address: {
      type: DataTypes.TEXT("medium"),
      allowNull: true,
    },
    
    webLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    appLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    fcmToken: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    OTP: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },

    macAddress: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null,
      comment: "MAC Address of Currently Logged In Device",
    },
    deviceId: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null,
      comment: "Device ID of device being used; For mobile devices only."
    },

    loginFlag: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: false, // false for Offline, true for Online
      comment: "false-Off, true-On",
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return usersSchema;
};

