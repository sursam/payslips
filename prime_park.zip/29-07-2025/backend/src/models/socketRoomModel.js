module.exports = (sequelize, DataTypes) => {
  const socketRoomsSchema = sequelize.define("socketRooms", {
    roomId: { 
      type: DataTypes.INTEGER, 
      references: {
        model: "users",
        key: "id",
      }, 
      allowNull: false, 
    },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return socketRoomsSchema;
};
