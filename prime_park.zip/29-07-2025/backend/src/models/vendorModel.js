module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for MARKETING VENDORS ONLY ----
  // ========================================================================
  const vendorsSchema = sequelize.define("vendors", {
    parkingGroundId: { type: DataTypes.INTEGER,  required: false, },
    
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users",
        key: "id",
      },
      allowNull: false,
    },

    initials: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    isOnsiteChargeApplicable: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return vendorsSchema;
};
