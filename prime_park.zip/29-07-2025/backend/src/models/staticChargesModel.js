module.exports = (sequelize, DataTypes) => {
  const staticChargesSchema = sequelize.define("staticCharges", {
    parkingGroundId: { type: DataTypes.INTEGER, required: true, allowNull: false },
    
    reservationCharge: { type: DataTypes.DOUBLE, required: true, defaultValue: 0 },

    defaultPassengerCount: { type: DataTypes.INTEGER, required: true, defaultValue: 0 },
    extraPassengerChargePerHead: { type: DataTypes.DOUBLE, required: true, defaultValue: 0 },

    createdAt: { field: "created_at", type: DataTypes.DATE,},
    updatedAt: { field: "updated_at", type: DataTypes.DATE,},

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    deletedAt: { field: "deleted_at", type: DataTypes.DATE,},
  });

  return staticChargesSchema;
};
