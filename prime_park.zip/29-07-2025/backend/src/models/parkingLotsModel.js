module.exports = (sequelize, DataTypes) => {
	const parkingLotsSchema = sequelize.define("parkingLots", {
    parkingGroundId: { type: DataTypes.INTEGER, allowNull: false, },

		lotName : { type: DataTypes.STRING, allowNull: false, },
		noOfBays : { type: DataTypes.INTEGER, allowNull: false, },
		noOfRows : { type: DataTypes.INTEGER, allowNull: false, },
		bayPosition : { type: DataTypes.ENUM("L", "R", "M"), allowNull: false, defaultValue: "L" },

		minDays: { type: DataTypes.INTEGER, allowNull: false, default: 0 },
		maxDays: { type: DataTypes.INTEGER, allowNull: false, default: 0 },

		isLotFull: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for "Full", false for "Not Full"
      comment: "false-No, true-Yes",
    },

		isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

		deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
		deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
	}, {
    indexes: [
      {
        // ---- 'parkingGroundId', 'lotName' ---- 
        // ---- combination of these 2-fields must be unique in order to prevent duplicate entry of a same lot ----
        unique: true,
        fields: ['parkingGroundId', 'lotName',]
      },
    ]
  });

	return parkingLotsSchema;
};
