module.exports = (sequelize, DataTypes) => {
  // =====================================================================================
  // ---- this schema is intended to be used for assigning an agent to a booking ONLY ----
  // =====================================================================================
  const agentBookingMappingsSchema = sequelize.define("agentBookingMappings", {
    agentId: {
      type: DataTypes.INTEGER,
      references: {
        model: "agents",
        key: "id",
      },
      allowNull: false,
    },

    bookingRequestId: { type: DataTypes.INTEGER, allowNull: false, },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return agentBookingMappingsSchema;
};
