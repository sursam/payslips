module.exports = (sequelize, DataTypes) => {
  const transactionHistorySchema = sequelize.define("transactionHistory", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users",
        key: "id",
      },
      allowNull: false,
    },
    transactionId: {
      type: DataTypes.INTEGER,
      references: {
        model: "transactions",
        key: "id",
      },
      allowNull: false,
    },

    paidAmount: { type: DataTypes.DOUBLE, defaultValue: 0 },
    paidCurrency: { type: DataTypes.STRING, defaultValue: null },
    
    gatewayName: { type: DataTypes.STRING, defaultValue: null },
    paymentType: {
      type: DataTypes.ENUM("Wallet Recharge", "Reservation Fees"),
      allowNull: false,
      defaultValue: "Reservation Fees",
    },

    isSuccess: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Success, false for Fail
      comment: "false-Fail, true-Success",
    },

    remarks: { type: DataTypes.STRING, defaultValue: null },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return transactionHistorySchema;
};
