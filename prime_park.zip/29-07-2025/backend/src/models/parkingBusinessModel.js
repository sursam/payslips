module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ------ these schema is intended to be used for PARKING BUSINESSES ------
  // ========================================================================
	const parkingBusinessSchema = sequelize.define("parkingBusinesses", {
    businessName : { type: DataTypes.STRING, allowNull: false, },

		noOfGrounds : { type: DataTypes.INTEGER, allowNull: false, },
		parkingCapacity : { type: DataTypes.INTEGER, allowNull: true, },

		isAquired: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for 'Aquired', false for 'Not Aquired'
      comment: "false-Not Aquired, true-Aquired",
    },

		isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

		deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
		deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
	});

	return parkingBusinessSchema;
};
