module.exports = (sequelize, DataTypes) => {
	const parkingGroundsSchema = sequelize.define("parkingGrounds", {
    parkingBusinessId : { type: DataTypes.INTEGER, allowNull: false, },

    groundName : { type: DataTypes.STRING, allowNull: false, },

		noOfLots : { type: DataTypes.INTEGER, allowNull: false, },
		parkingCapacity : { type: DataTypes.INTEGER, allowNull: true, },

		isGroundFull: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for "Full", false for "Not Full"
      comment: "false-Not Full, true-Full",
    },

		isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

		deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
		deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
	}, {
    indexes: [
      {
        // ---- 'parkingBusinessId', 'groundName' ---- 
        // ---- combination of these 2-fields must be unique in order to prevent duplicate entry of a same ground ----
        unique: true,
        fields: ['parkingBusinessId', 'groundName',]
      },
    ]
  });

	return parkingGroundsSchema;
};
