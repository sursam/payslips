module.exports = (sequelize, DataTypes) => {
  const invoicesSchema = sequelize.define("invoices", {
    bookingRequestId: { type: DataTypes.INTEGER, allowNull: false },

    // ============= reservation charge non-refundable $25.00/- =============
    reservationAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    // ============= reservation charge non-refundable $25.00/- =============
    
    // ============= parking-charges =============
    parkingChargeTotal: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    overSizeChargeTotal: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // lateFeesTotal: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // ============= parking-charges =============
    
    // ============= extra passenger fees =============
    extraPassengers: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
    extraPassengerChargesTotal: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // ============= extra passenger fees =============

    // ============= early check-in =============
    // earlyCheckinDays: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
    earlyCheckinAmountTotal: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // ============= early check-in =============

    // ============= overstay =============
    overstayDays: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
    overstayAmountTotal: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // ============= overstay =============
    
    // ============= onSiteCharges =============
    onSiteChargeForVendor: { type: DataTypes.DOUBLE, allowNull: true, defaultValue: 0 },
    // ============= onSiteCharges =============

    // ============= TOTAL AMOUNT =============

    // ===== payableAmount = parkingCharge + overSizeCharge + extraPassengerChargesTotal + overstayAmountTotal + onSiteChargeForVendor =====
    payableAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    // ===== payableAmount = parkingCharge + overSizeCharge + extraPassengerChargesTotal + overstayAmountTotal + onSiteChargeForVendor =====

    paidAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },

    // ============= (DUE AMOUNT = dueAmount = payableAmount - paidAmount) =============
    dueAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    // ============= (DUE AMOUNT = dueAmount = payableAmount - paidAmount) =============

    // ============= TOTAL AMOUNT =============

    paymentType: { type: DataTypes.STRING, allowNull: true },
    paymentStatus: { type: DataTypes.ENUM("Due", "Booking Charges Paid", "Fully Paid", "Full Due",  "Onsite Charges Due", "Failed"), allowNull: false, defaultValue: "Due" },

    // isEligibleForRefund: {
    //   type: DataTypes.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: true, // true for Yes, false for No
    //   comment: "false-No, true-Yes",
    // },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return invoicesSchema;
};
