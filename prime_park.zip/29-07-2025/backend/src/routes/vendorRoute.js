const express = require('express');
const router = express.Router();
const vendorController = require('../controllers/vendorController')
const {
    isAuthenticated,
  } = require('../middleware/auth')


router.route('/vendor-add-update').post(isAuthenticated, vendorController.vendorAddUpdate);
router.route('/vendor-details').post(isAuthenticated, vendorController.vendorDetails);
router.route('/vendor-list').post(isAuthenticated, vendorController.vendorList);

module.exports = router;