const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController')
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/new-bookings-list-for-dashboard').post(isAuthenticated, dashboardController.newBookingsListForDashboard);

router.route('/monthly-revenue').post(isAuthenticated, dashboardController.monthlyRevenue);

router.route('/checkin-checkouts-graph').post(isAuthenticated, dashboardController.getMonthlyCheckInsAndCheckOuts);

module.exports = router;