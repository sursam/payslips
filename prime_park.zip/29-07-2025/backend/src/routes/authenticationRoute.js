const express = require('express');
const router = express.Router();
const authenticationController = require('../controllers/AuthenticationController')
const {
  isAuthenticated,
} = require('../middleware/auth');

// login =======
router.route('/login').post(authenticationController.login);
router.route('/logout').post(isAuthenticated, authenticationController.logout);

router.route('/role-list').get(isAuthenticated, authenticationController.roleList);
router.route('/role-list').post(isAuthenticated, authenticationController.roleList);

router.route('/module-list').post(isAuthenticated, authenticationController.moduleList);
// router.route('/role-wise-module-list').post(isAuthenticated, authenticationController.roleWiseModuleList);


// router.route('/social-login').post(authenticationController.socialLogin)
// router.route('/role-permission-checker').post(isAuthenticated, authenticationController.rolePermissionChecker);
// router.route('/user-permission-checker').post(isAuthenticated, authenticationController.userPermissionChecker);
// router.route('/forget-password').post(authenticationController.forgetPassword);
// router.route('/change-password').post(isAuthenticated, authenticationController.changePassword);
// router.route('/logout').post(isAuthenticated, authenticationController.logout);
// router.route('/deactivate-account').post(isAuthenticated, authenticationController.deactivateAccount);

module.exports = router;