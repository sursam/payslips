const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/create-payment-intent-with-stripe').post(transactionController.createPaymentIntentWithStripe);
router.route('/verify-payment-via-stripe').post(transactionController.verifyPaymentViaStripe);

module.exports = router;