const express = require('express');
const router = express.Router();
const parkingGroundController = require('../controllers/parkingGroundController');
const {
    isAuthenticated,
  } = require('../middleware/auth');


router.route('/parking-grounds-list').post(parkingGroundController.parkingGroundsList);

module.exports = router;