<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Broadcasting\DatabaseChannel;

class RequisitionApproveNotification extends Notification
{
    use Queueable;
    protected $approvalData;
    public function __construct($data)
    {
        $this->approvalData = $data;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toDatabase($notifiable)
    {
        return [
            'form_name' => $this->approvalData['form_name'],
            'requisition_uuid' => $this->approvalData['requisition_uuid'],
        ];
    }
}
