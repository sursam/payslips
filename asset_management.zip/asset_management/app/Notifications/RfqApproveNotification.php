<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
class RfqApproveNotification extends Notification
{
    use Queueable;
    protected $approvalData;
    public function __construct($data)
    {
        $this->approvalData = $data;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toDatabase($notifiable)
    {
        return [
            'form_name' => $this->approvalData['form_name'],
            'rfq_uuid' => $this->approvalData['rfq_uuid'],
        ];
    }
}
