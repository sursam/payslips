<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Broadcasting\DatabaseChannel;

class PoInvoiceApproveNotification extends Notification
{
    use Queueable;
    protected $approvalData;
    public function __construct($data)
    {
        $this->approvalData = $data;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toDatabase($notifiable)
    {
        return [
            'form_name' => $this->approvalData['form_name'],
            'po_invoice_uuid' => $this->approvalData['po_invoice_uuid'],
            'po_uuid' => $this->approvalData['po_uuid'],
        ];
    }
}
