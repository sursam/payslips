<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Broadcasting\DatabaseChannel;

class TicketNotification extends Notification
{
    use Queueable;
    protected $ticketData;
    public function __construct($data)
    {
        $this->ticketData = $data;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toDatabase($notifiable)
    {
        return [
            'form_name' => $this->ticketData['form_name'],
            'ticket_uuid' => $this->ticketData['ticket_uuid'],
            // 'form_slug' => $this->formdata['form_slug'],
            // 'user_id' => $this->formdata['user_uuid'],
            // 'form_id' => $this->formdata['form_uuid'],
            // 'opportunity_id' => $this->formdata['opportunity_id'],
        ];
    }
}
