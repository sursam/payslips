<?php

namespace App\Http\Controllers\Admin\Master;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Imports\AddMasterImport;
use App\Imports\User\AddVendorImport;
use App\Services\Asset\AssetService;
use App\Services\Category\CategoryService;
use App\Services\User\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Facades\Excel;

class MasterController extends BaseController
{
    public function __construct(protected CategoryService $categoryService, protected AssetService $assetService, protected UserService $userService)
    {
        $this->categoryService = $categoryService;
        $this->assetService = $assetService;
        $this->userService = $userService;
    }
    #brand
    public function masterview(Request $request, $type)
    {
        /*switch (true) {
            case ($type == 'brand'):
                $this->setPageTitle('Brand');
                // dd(Route::currentRouteName());
                $condition = [['type', '=', 'brand']];
                if ($request->brand != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->brand . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.brand.list', compact('data'));
                break;

            case ($type == 'entity'):
                $this->setPageTitle('Entity');
                $condition = [['type', '=', 'entity']];
                if ($request->entity != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->entity . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.entity.list', compact('data'));
                break;

            case ($type == 'sbu'):
                $this->setPageTitle('SBU');
                $condition = [['type', '=', 'sbu']];
                if ($request->sbu != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->sbu . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.sbu.list', compact('data'));
                break;

            case ($type == 'division'):
                $this->setPageTitle('Division');
                $condition = [['type', '=', 'division']];
                if ($request->division != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->division . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.division.list', compact('data'));
                break;

            case ($type == 'designation'):
                $this->setPageTitle('Designation');
                $condition = [['type', '=', 'designation']];
                if ($request->designation != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->designation . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.designation.list', compact('data'));
                break;

            case ($type == 'office-location'):
                $this->setPageTitle('Office Location');
                $condition = [['type', '=', 'officelocation']];
                if ($request->officelocation != '') {
                    array_push($condition, ['name', 'LIKE', '%' . $request->officelocation . '%']);
                }
                $data = $this->categoryService->listCategories($condition, 'id', 'DESC');
                return view('admin.master.officelocation.list', compact('data'));
                break;


            case ($type == 'department'):
                $this->setPageTitle('Department');
                $condition = ['is_active' => 1];
                $search = [];
                if ($request->department != '') {
                    $search['search_text'] = $request->department;
                }
                $data = $this->assetService->listDepartments($condition, 'id', 'DESC', null, $search);
                return view('admin.master.department.list', compact('data'));
                break;


            case ($type == 'terms-condition'):
                $this->setPageTitle('Terms & condition');
                $condition = [];
                // if($request->department != ''){
                //     array_push($condition, ['name', 'LIKE', '%'.$request->department.'%']);
                // }
                $data = $this->categoryService->listTermAndConditions($condition, 'id', 'DESC');
                return view('admin.master.terms-condition.list', compact('data'));
                break;

            default:
                abort(404);
                break;
        }*/

        switch ($type) {
            case 'brand':
                $pageTitle = 'Brand List';
                $singularTitle = 'Brand';
                break;
            case 'entity':
                $pageTitle = 'Entity List';
                $singularTitle = 'Entity';
                break;
            case 'sbu':
                $pageTitle = 'SBU List';
                $singularTitle = 'SBU';
                break;
            case 'division':
                $pageTitle = 'Division List';
                $singularTitle = 'Division';
                break;
            case 'designation':
                $pageTitle = 'Designation List';
                $singularTitle = 'Designation';
                break;
            case 'department':
                $this->setPageTitle('Department List');
                $condition = [];
                $search = [];
                if ($request->department != '') {
                    $search['search_text'] = $request->department;
                }
                $data = $this->assetService->listDepartments($condition, 'id', 'DESC', null, $search);
                return view('admin.master.department.list', compact('data'));
                break;
            case 'terms-condition':
                $this->setPageTitle('Terms & conditions');
                $condition = [];
                $data = $this->categoryService->listTermAndConditions($condition, 'id', 'DESC');
                return view('admin.master.terms-condition.list', compact('data'));
                break;
            default:
                abort(404);
                break;
        }
        $this->setPageTitle($pageTitle);
        return view('admin.master.list', compact('type', 'singularTitle'));
    }
    public function masterAdd(Request $request, $type)
    {
        switch ($type) {
            case 'brand':
                $this->setPageTitle('Brand Add');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'brand_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->brand_name]);
                        if (!empty($request->uuid)):
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'brand_name'), uuidtoid($request->uuid, 'categories'));
                        else:
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'brand_name'));
                        endif;
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'Brand created.' : 'Brand Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'brand'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.brand.add');
                break;

            case 'entity':
                $this->setPageTitle('Entity Add');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'entity_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->entity_name]);
                        if (!empty($request->uuid))
                        {
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'entity_name'), uuidtoid($request->uuid, 'categories'));
                        }else{
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'entity_name'));
                            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => 'New Entity Creation',
                                'task_description' => $request->entity_name,
                                'task_url' => 'masters/entity/list',
                                'added_by' => auth()->user()->id,
                                'type' => 'add-entity',
                                'related_id' => $isCreated->id
                            ]);
                        }
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'Entity created.' : 'Entity Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'entity'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.entity.add');
                break;

            case 'sbu':
                $this->setPageTitle('SBU Add');
                if ($request->ajax()) {
                    $rules = [
                        'sbu_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ];
                    $messages = [
                        'sbu_name.required' => "The SBU name is required.",
                    ];
                    $validator = Validator::make($request->all(), $rules, $messages);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->sbu_name]);
                        if (!empty($request->uuid)){
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'sbu_name'), uuidtoid($request->uuid, 'categories'));
                        }
                        else{
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'sbu_name'));
                            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => 'New SBU Creation',
                                'task_description' => $request->sbu_name,
                                'task_url' => 'masters/sbu/list',
                                'added_by' => auth()->user()->id,
                                'type' => 'add-sbu',
                                'related_id' => $isCreated->id
                            ]);
                        }
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'SBU created.' : 'SBU Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'sbu'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.sbu.add');
                break;

            case 'division':
                $this->setPageTitle('Division Add');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'division_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->division_name]);
                        if (!empty($request->uuid)):
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'division_name'), uuidtoid($request->uuid, 'categories'));
                        else:
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'division_name'));
                        endif;
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'Division created.' : 'Division Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'division'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.division.add');
                break;

            case 'designation':
                $this->setPageTitle('Add Designation');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'designation_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->designation_name]);
                        if (!empty($request->uuid)):
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'designation_name'), uuidtoid($request->uuid, 'categories'));
                        else:
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'designation_name'));
                        endif;
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'Designation created.' : 'Designation Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'designation'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.designation.add');
                break;

            case 'office-location':
                $this->setPageTitle('Office Location Add');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'officelocation_name' => 'required|min:2|unique:categories,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->officelocation_name]);
                        if (!empty($request->uuid)):
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'officelocation_name'), uuidtoid($request->uuid, 'categories'));
                        else:
                            $isCreated = $this->categoryService->createOrUpdateCategory($request->except('_token', 'officelocation_name'));
                        endif;
                        if ($isCreated) {
                            DB::commit();
                            $msg = $isCreated->wasRecentlyCreated ? 'Office Location created.' : 'Office Location Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'office-location'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.officelocation.add');
                break;


            case 'department':

                $this->setPageTitle('Add Department');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'department_name' => 'required|min:2|unique:departments,name,' . $request->uuid . ',uuid',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }

                    DB::beginTransaction();
                    try {
                        $request->merge(['name' => $request->department_name]);
                        if (!empty($request->uuid)){
                            $isCreated = $this->assetService->createOrUpdateDepartment($request->except('_token', 'department_name'), uuidtoid($request->uuid, 'departments'));
                        }
                        else{
                            $isCreated = $this->assetService->createOrUpdateDepartment($request->except('_token', 'department_name'));
                            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => 'New Department Creation',
                                'task_description' => $request->department_name,
                                'task_url' => 'masters/department/list',
                                'added_by' => auth()->user()->id,
                                'type' => 'add-department',
                                'related_id' => $isCreated->id
                            ]);
                        }
                        if ($isCreated) {
                            DB::commit();
                            $msg = $request->uuid ? 'Department updated' : 'Department created';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'department'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                $departments = $this->assetService->listDepartments([], 'id', 'DESC');
                $employees = $this->userService->getEmployees();
                $editdata = null;
                return view('admin.master.department.add', compact('editdata', 'employees', 'departments'));
                break;



            case 'terms-condition':
                $this->setPageTitle('Terms Condition Add');
                if ($request->ajax()) {
                    $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:2|unique:term_and_conditions,name,' . $request->uuid . ',uuid',
                        'type' => 'required',
                        'description' => 'required|string|min:2',
                    ]);
                    if ($validator->fails()) {
                        return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                    }
                    DB::beginTransaction();
                    try {
                        if (!empty($request->uuid)):
                            $isCreated = $this->categoryService->createOrUpdateTermAndCondition($request->except('_token'), uuidtoid($request->uuid, 'term_and_conditions'));

                        else:
                           // dd($request->all());
                            $isCreated = $this->categoryService->createOrUpdateTermAndCondition($request->except('_token'));
                            //dd($isCreated);
                        endif;
                        if ($isCreated) {
                            DB::commit();
                            // dd("Aa1");
                            $msg = $isCreated->wasRecentlyCreated ? 'Terms & condition created.' : 'Terms & condition Update';
                            return $this->responseJson(true, 200, $msg, [
                                'redirect_url' => route('admin.master-list', ['type' => 'terms-condition'])
                            ]);
                        }
                    } catch (\Throwable $e) {
                        DB::rollBack();
                        logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                        return $this->responseJson(false, 500, $e->getMessage(), '');
                    }
                }
                return view('admin.master.terms-condition.add');
                break;

            default:
                abort(404);
                break;
        }
    }
    public function masterEdit(Request $request, $type, $uuid)
    {
        switch ($type) {
            case 'brand':
                $this->setPageTitle('Brand Edit');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.brand.add', compact('editdata'));
                break;

            case 'entity':
                $this->setPageTitle('Entity Edit');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.entity.add', compact('editdata'));
                break;

            case 'sbu':
                $this->setPageTitle('SBU Edit');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.sbu.add', compact('editdata'));
                break;

            case 'division':
                $this->setPageTitle('Division Edit');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.division.add', compact('editdata'));
                break;

            case 'designation':
                $this->setPageTitle('Edit Designation');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.designation.add', compact('editdata'));
                break;

            case 'office-location':
                $this->setPageTitle('Office Location Edit');
                $editdata = $this->categoryService->findCategoryById(uuidtoid($uuid, 'categories'));
                return view('admin.master.officelocation.add', compact('editdata'));
                break;


            case 'department':
                $this->setPageTitle('Edit Department');
                $employees = $this->userService->getEmployees();
                $editdata = $this->assetService->findDepartmentById(uuidtoid($uuid, 'departments'));
                $departments = $this->assetService->listDepartments([], 'id', 'DESC');
                return view('admin.master.department.add', compact('editdata', 'employees', 'departments'));
                break;

            case 'terms-condition':
                $this->setPageTitle('Term & condition Edit');
                $editdata = $this->categoryService->findTermAndConditionById(uuidtoid($uuid, 'term_and_conditions'));
                // dd($editdata);
                return view('admin.master.terms-condition.add', compact('editdata'));
                break;

            default:
                abort(404);
                break;
        }
    }


    public function downloadSampleMasterExcel(Request $request, $type)
    {

        // $permission = "{$type}-import";
        // if ($request->user()->can($permission)) {
            switch ($type) {
                case 'brand':
                    $file = public_path() . "/assets/documents/sample-format-of-brands.xlsx";
                    return response()->download($file, 'brand-import-sample-data.xlsx');
                    break;
                case 'entity':
                    $file = public_path() . "/assets/documents/sample-format-of-entities.xlsx";
                    return response()->download($file, 'entity-import-sample-data.xlsx');
                    break;
                case 'department':
                        $file = public_path() . "/assets/documents/sample-format-of-departments.xlsx";
                        return response()->download($file, 'department-import-sample-data.xlsx');
                        break;
                default:
                    abort(404);
                    break;
            }
        // }
        // abort(404);


    }

    public function addMasterByExcel(Request $request, $type)
    {

        $request->validate([
            'excel_file' => 'required|file'
        ]);
        try {
            $isExcelImported = Excel::import(new AddMasterImport($type), $request->file('excel_file'));
            if ($isExcelImported){
                return $this->responseJson(true, 200, 'Data Imported Successfully', [
                    'redirect_url' => route('admin.master-list', ['type' => $type])
                ]);
            }else{
                return $this->responseJson(false, 200, 'Something went Wrong', '');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }



    }
}
