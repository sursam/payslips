<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Services\Workflow\WorkflowService;

class WorkflowController extends BaseController
{
    public function __construct(protected WorkflowService $workflowService) {
        $this->workflowService = $workflowService;
    }
    public function listWorkflow(Request $request)
    {
        $this->setPageTitle('Workflow List');
        $workflows = $this->workflowService->listWorkflows();
        return view('admin.workflow.list', compact('workflows'));
    }
    public function addWorkflow(Request $request)
    {
        $this->setPageTitle('Add Workflow');
        $lastId = $this->workflowService->listWorkflows()->pluck('id')->first();
        $workflowId = 'WRKF' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'type' => 'required',
                'module' => 'required' ,
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isCreated = $this->workflowService->addOrUpdateWorkflow([
                    'uuid' => null
                ], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Workflow successfully created.', [
                        'redirect_url' => route('admin.workflow.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.workflow.add', compact('workflowId'));
    }
    public function editWorkflow(Request $request, $uuid)
    {
        $this->setPageTitle('Edir Workflow');
        $workflow = $this->workflowService->findWorkflowById(uuidtoid($uuid, 'workflows'));
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|unique:workflows,name,' . $uuid . ',uuid',
                'type' => 'required',
                'module' => 'required' ,
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isCreated = $this->workflowService->addOrUpdateWorkflow([
                    'uuid' => $uuid
                ], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Workflow successfully updated.', [
                        'redirect_url' => route('admin.workflow.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.workflow.edit', compact('workflow'));
    }
}
