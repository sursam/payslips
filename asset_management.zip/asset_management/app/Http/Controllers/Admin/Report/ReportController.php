<?php

namespace App\Http\Controllers\Admin\Report;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Services\Asset\AssetService;
use App\Services\Report\ReportService;
use App\Http\Controllers\BaseController;
use App\Services\Asset\AssetTypeService;
use Illuminate\Support\Facades\Validator;
use App\Services\Category\CategoryService;
use App\Services\Inventory\AssetStockService;

class ReportController extends BaseController
{
    public function __construct(
        protected ReportService $reportService,
        protected CategoryService $categoryService,
        protected AssetTypeService $assetTypeService,
        protected AssetStockService $assetStockService,
        protected AssetService $assetService,
        protected UserService $userService,
    ) {
        $this->reportService = $reportService;
        $this->categoryService = $categoryService;
        $this->assetTypeService = $assetTypeService;
        $this->assetStockService = $assetStockService;
        $this->assetService = $assetService;
        $this->userService = $userService;
    }
    public function listDepreciationReports(Request $request)
    {
        $this->setPageTitle('Depreciation Report');
        $nonConsumableCategory = $this->categoryService->findCategoryBySlug('non-consumable');
        $assetTypes = $this->getAssetTypesTree([], null, $nonConsumableCategory->id);
        if ($request->ajax()) {
            $rules = [
                'financial_year' => 'required',
                'asset_type_id' => 'required'
            ];
            $messages = [
                'financial_year' => 'Please select any financial year',
                'asset_type_id' => 'Please select the nature of asset'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reports = '';
                $reportHead = '';
                $reportBody = '';
                $totalRow = '';
                $tableWidth = 0;
                $assetTypeId = $request->asset_type_id;
                $filterConditions = ['asset_type_id' => $assetTypeId];
                $depreSettingsData = $this->reportService->getDepreciationSettings($filterConditions);
                if($depreSettingsData){
                    $assetInventories = $this->assetStockService->findInventories($filterConditions);

                    $reportHead .= '<thead>
                                    <tr>
                                        <th rowspan="2">Asset Name / Model No.</th>
                                        <th rowspan="2">Date of Put to Use</th>
                                        <th rowspan="2">End of Life</th>
                                        <th rowspan="2">Year of Put to Use</th>
                                        <th rowspan="2">Value</th>
                                        <th rowspan="2">Value at the End of Life</th>';
                    if($assetInventories->count()){
                        $tableWidth += 800;
                        $minDate = min(array_column($assetInventories->toArray(), 'purchase_date'));
                        $minYear = Carbon::parse($minDate)->format('Y') - 1;
                        $maxYear = $request->financial_year;
                        $totalValue = 0;
                        $totalEndOfLifeValue = 0;
                        $accumulatedDepreciationArr = [];
                        $depreciationArr = [];
                        $bookValueArr = [];

                        foreach($assetInventories as $assetInventory){
                            $reportBody .= '<tr>';
                            $reportBody .= '<td>
                                            <label><strong>Model:</strong> '.$assetInventory->asset?->asset_name.'</label><br>
                                            <label><strong>Serial No.:</strong> '.$assetInventory->unique_id.'</label><br>
                                            <label><strong>Identification No.:</strong> '.$assetInventory->identification_no.'</label>
                                        </td>';
                            $reportBody .= '<td>'.Carbon::parse($assetInventory->purchase_date)->format('d-m-Y').'</td>';
                            $reportBody .= '<td>'.Carbon::parse(date_format($assetInventory->purchase_date,'d-m-Y'))->addYears($depreSettingsData->useful_years)->format('d-m-Y').'</td>';

                            $yearOfPutToUse = Carbon::parse($assetInventory->purchase_date)->format('Y');
                            $financialYearOfPutToUse = Carbon::parse($assetInventory->purchase_date)->format('y') + 1;
                            if(strtotime($assetInventory->purchase_date) <= strtotime($yearOfPutToUse.'-03-31')){
                                $yearOfPutToUse = Carbon::parse($assetInventory->purchase_date)->format('Y') - 1;
                                $financialYearOfPutToUse = Carbon::parse($assetInventory->purchase_date)->format('y');
                            }
                            $maxYearToShow = $yearOfPutToUse + $depreSettingsData->useful_years;
                            $reportBody .= '<td>'.$yearOfPutToUse . '-' . $financialYearOfPutToUse.'</td>';
                            $value = $assetInventory->amount;
                            $totalValue += $value;
                            $reportBody .= '<td>'.number_format($value, 2, '.', ',').'</td>';
                            $endOfLifeValue = $value * $depreSettingsData->salvage_value / 100;
                            $totalEndOfLifeValue += $endOfLifeValue;
                            $reportBody .= '<td>'.number_format($endOfLifeValue, 2, '.', ',').'</td>';

                            $accumulatedDepreciation = 0;
                            $depreciation = 0;
                            $bookValue = 0;
                            $dayDiff = 0;
                            for($i = ($minYear + 1); $i <= ($maxYear + 1); $i++){
                                if(strtotime('31-03-'.$i) >= strtotime($assetInventory->purchase_date)){
                                    $dateDiff = !$dayDiff ? strtotime('31-03-'.$i) - strtotime($assetInventory->purchase_date) : strtotime('31-03-'.$i) - strtotime('31-03-'.($i-1));
                                    $dayDiff = round($dateDiff / (60 * 60 * 24)) + 1;
                                }
                                if($dayDiff && $i <= $maxYearToShow){
                                    $reportBody .= '<td>'.$dayDiff.'</td>';
                                    $accumulatedDepreciationArr[$i][] = $accumulatedDepreciation;
                                    $reportBody .= '<td>'.($accumulatedDepreciation ? number_format($accumulatedDepreciation, 2, '.', ',') : '-').'</td>';
                                    $depreciation = !$depreciation ? (($value - $endOfLifeValue) * $depreSettingsData->effective_rate * $dayDiff / 36500) : ($value * $depreSettingsData->effective_rate * $dayDiff / 36500);
                                    $accumulatedDepreciation += $depreciation;
                                    $depreciationArr[$i][] = $depreciation;
                                    $reportBody .= '<td>'.number_format($depreciation, 2, '.', ',').'</td>';
                                    $value = $value - $depreciation;
                                    $bookValueArr[$i][] = $value;
                                    $reportBody .= '<td>'.number_format($value, 2, '.', ',').'</td>';
                                }else{
                                    $accumulatedDepreciationArr[$i][] = 0;
                                    $depreciationArr[$i][] = 0;
                                    $bookValueArr[$i][] = 0;
                                    $reportBody .= '<td></td><td></td><td></td><td></td>';
                                }
                            }

                            $reportBody .= '</tr>';

                        }

                        $reportHeadSub1 = '';
                        $reportHeadSub2 = '';
                        for($i = ($minYear + 1); $i <= ($maxYear + 1); $i++){
                            $tableWidth += 500;
                            $reportHeadSub1 .= '<th rowspan="1" colspan="4" class="text-center">31-03-'.$i.'</th>';
                            $reportHeadSub2 .= '<th rowspan="1">No of Days</th>
                                                <th rowspan="1">Accumulated Depreciation</th>
                                                <th rowspan="1">Depreciation</th>
                                                <th rowspan="1">Book Value</th>';
                        }

                        $totalRow .= '<tr>';
                        $totalRow .= '<td></td><td></td><td></td>';
                        $totalRow .= '<td class="text-center"><strong>Total</strong></td>';
                        $totalRow .= '<td><strong>'.number_format($totalValue, 2, '.', ',').'</strong></td>';
                        $totalRow .= '<td><strong>'.number_format($totalEndOfLifeValue, 2, '.', ',').'</strong></td>';
                        if($bookValueArr){
                            foreach($bookValueArr as $k => $bookValue){
                                $totalRow .= '<td></td><td><strong>'.number_format(array_sum($accumulatedDepreciationArr[$k]), 2, '.', ',').'</strong></td><td><strong>'.number_format(array_sum($depreciationArr[$k]), 2, '.', ',').'</strong></td><td><strong>'.number_format(array_sum($bookValue), 2, '.', ',').'</strong></td>';
                            }
                        }
                        $totalRow .= '</tr>';
                        $reportHead .= $reportHeadSub1 . '</tr>';
                        $reportHead .= '<tr>'.$reportHeadSub2.'</tr>';
                    }else{
                        $reportHead = '<thead><tr><th></th></tr></thead>';
                        $reportBody = '<tr><td class="text-center">No Records Found</td></tr>';
                        $totalRow = '';
                    }
                    $reports = $reportHead . '<tbody>' . $reportBody . $totalRow . '</tbody>';
                    return $this->responseJson(true, 200, 'Report successfully fetched', [
                        "report" => $reports,
                        "tableWidth" => $tableWidth,
                        "dataCount" => $assetInventories->count()
                    ]);
                }
                $reportHead .= '<thead><tr><th></th></tr></thead>';
                $reportBody .= '<tr><td class="text-center">No Records Found</td></tr>';
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(false, 200, 'Please update depreciation settings first', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => 0
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.report.depreciation-list', compact('assetTypes'));
    }
    public function depreciationSettings(Request $request, $uuid)
    {
        $assetTypeId = uuidtoid($uuid, 'asset_types');
        $assetType = $this->assetTypeService->findById($assetTypeId);
        $this->setPageTitle('Depreciation Settings for ' . $assetType->name);
        $filterConditions = ['asset_type_id' => $assetTypeId];
        $depreSettingsData = $this->reportService->getDepreciationSettings($filterConditions);
        $nonConsumableCategory = $this->categoryService->findCategoryBySlug('non-consumable');
        $assetTypes = $this->getAssetTypesTree([], null, $nonConsumableCategory->id);
        if ($request->ajax()) {
            $rules = [
                'asset_type_id' => 'required',
                'useful_years' => 'required',
                'effective_rate' => 'required',
                'salvage_value' => 'required',
            ];
            $messages = [
                'asset_type_id' => 'Nature of asset is required',
                'useful_years' => 'Useful life in years is required',
                'effective_rate' => 'Effective rate as per SLM is required',
                'salvage_value' => 'Salvage value is required',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isSettings = $this->reportService->addOrUpdateSettings(['id' => $request->settings_id], $request->except(['_token', 'settings_id']));
                if ($isSettings) {
                    DB::commit();
                    $msg = $request->settings_id ? 'Depreciation settings updated successfully.' : 'Depreciation settings added successfully.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.assettype.depreciation.settings', $isSettings->assetType->uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.report.depreciation-settings', compact('assetType', 'assetTypes', 'depreSettingsData'));
    }
    protected function getAssetTypesTree($assetTypes = array(), $parent_id = null, $category_id = null, $isParentSelectable = false)
    {
        $args = ['parent_id' => $parent_id];
        if ($category_id) {
            $args['category_id'] = $category_id;
        }
        $astTypes = $this->assetTypeService->listAssets($args, 'id', 'asc');
        $subTypes = [];
        $types = [];
        if ($astTypes->count()) {
            foreach ($astTypes as $k => $type) {
                $types[$k]['id'] = $type->id;
                $types[$k]['title'] = $type->name;
                if ($category_id) {
                    $subTypes = $this->getAssetTypesTree($assetTypes, $type->id, $category_id, $isParentSelectable);
                } else {
                    $subTypes = $this->getAssetTypesTree($assetTypes, $type->id, null, $isParentSelectable);
                }
                if ($subTypes) {
                    $types[$k]['isSelectable'] = $isParentSelectable;
                    $types[$k]['subs'] = $subTypes;
                }
            }
            $assetTypes = array_merge($assetTypes, $types);
        }
        return $assetTypes;
    }
    protected function getAssetCategoryTree($categories = array(), $parent_id = null, $isParentSelectable = false)
    {
        $typeCats = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'asset_type', 'parent_id' => $parent_id]);
        $subCategories = [];
        $cats = [];
        if ($typeCats->count()) {
            foreach ($typeCats as $k => $category) {
                $cats[$k]['id'] = $category->id;
                $cats[$k]['title'] = $category->name;
                $subCategories = $this->getAssetCategoryTree($categories, $category->id, $isParentSelectable);
                if ($subCategories) {
                    $cats[$k]['isSelectable'] = $isParentSelectable;
                    $cats[$k]['subs'] = $subCategories;
                }
            }
            $categories = array_merge($categories, $cats);
        }
        return $categories;
    }
    public function assetRegisterReports_back(Request $request)
    {
        $this->setPageTitle('Asset Register');
        if ($request->ajax()) {
            $rules = [
                'category_id' => 'required',
                'asset_type_id' => 'required',
                'asset_id' => 'required',
            ];
            $messages = [
                'category_id' => 'Please select any asset category',
                'asset_type_id' => 'Please select any asset type',
                'asset_id' => 'Please select any asset',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reports = '';
                $reportHead = '<thead><tr><th></th></tr></thead>';
                $reportBody = '<tr><td class="text-center">No Records Found</td></tr>';
                $tableWidth = 0;
                $currentDate = Carbon::now();
                $filterConditions = ['asset_id' => $request->asset_id];
                $assetStocks = $this->assetStockService->findAssetStock($filterConditions);
                if($assetStocks->count()){
                    $tableWidth = 5000;
                    $reportBody = '';
                    $reportHead = '<thead>
                        <tr>
                            <th colspan="4">Asset Informations</th>
                            <th colspan="69">Stock Informations</th>
                        </tr>
                        <tr>
                            <th>Asset Category</th>
                            <th>Asset Type</th>
                            <th>Asset</th>
                            <th>Asset ID</th>
                            <th>Stock ID</th>
                            <th>Location</th>
                            <th>Entity</th>
                            <th>Total Stock</th>
                            <th colspan="7">Current Stock</th>
                            <th colspan="13">Issued</th>
                            <th colspan="23">Leased</th>
                            <th colspan="13">Under Maintenance</th>
                            <th colspan="9">Disposed</th>
                        </tr>
                        <tr>
                            <th colspan="8"></th>

                            <th>Serial Number</th>
                            <th>Identification Number</th>
                            <th>Capacity / Specifications</th>
                            <th>Asset Condition</th>
                            <th>Purchase Date</th>
                            <th>Warranty Date</th>
                            <th>Age Of Asset</th>

                            <th>Serial Number</th>
                            <th>Identification Number</th>
                            <th>Capacity / Specifications</th>
                            <th>Asset Condition</th>
                            <th>Purchase Date</th>
                            <th>Warranty Date</th>
                            <th>Age Of Asset</th>
                            <th>Issued To</th>
                            <th>Issued Date</th>
                            <th>Comments</th>
                            <th>Issued Image</th>
                            <th>Allotment Letter</th>
                            <th>Acceptance Status</th>

                            <th>Lease ID</th>
                            <th>Serial Number</th>
                            <th>Identification Number</th>
                            <th>Capacity / Specifications</th>
                            <th>Asset Condition</th>
                            <th>Purchase Date</th>
                            <th>Warranty Date</th>
                            <th>Age Of Asset</th>
                            <th>Lease Type</th>
                            <th>Leased User</th>
                            <th>User Comments</th>
                            <th>Leased Vendor</th>
                            <th>Vendor Phone</th>
                            <th>Vendor Email</th>
                            <th>Vendor Address</th>
                            <th>Lease Start Date</th>
                            <th>Lease End Date</th>
                            <th>Lease Term (Month)</th>
                            <th>Lease Type</th>
                            <th>Payment Amount (Monthly)</th>
                            <th>Added By</th>
                            <th>Lease Agreement File</th>
                            <th>Renewal options and terms</th>

                            <th>Maintenance ID</th>
                            <th>Serial Number</th>
                            <th>Identification Number</th>
                            <th>Capacity / Specifications</th>
                            <th>Asset Condition</th>
                            <th>Purchase Date</th>
                            <th>Warranty Date</th>
                            <th>Age Of Asset</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Added By</th>
                            <th>Start Date</th>
                            <th>End Date</th>

                            <th>Serial Number</th>
                            <th>Identification Number</th>
                            <th>Capacity / Specifications</th>
                            <th>Asset Condition</th>
                            <th>Purchase Date</th>
                            <th>Warranty Date</th>
                            <th>Age Of Asset</th>
                            <th>Maintenance ID</th>
                            <th>Disposed Date</th>

                        </tr>
                    </thead>';
                    foreach($assetStocks as $stock){
                        $maxRowArr = [];
                        $reportBody .= '<tr>';
                        $reportBody .= '<td>'.$stock->asset?->category?->name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->assettype?->name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->asset_name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->asset_id.'</td>';
                        $reportBody .= '<td>'.$stock->unique_id.'</td>';
                        $reportBody .= '<td>'.$stock->location?->street_address.'</td>';
                        $reportBody .= '<td>'.$stock->entity?->name.'</td>';

                        $issued_qty = $stock->assetIssue?->where('is_surrender', '0')->sum('quantity');
                        $leased_qty = 0;
                        $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);
                        if ($leased_agreements) {
                            foreach ($leased_agreements as $leased_agreement) {
                                $leased_qty += $leased_agreement->leaseItems->where('is_completed', '0')->count();
                            }
                        }
                        $maintenance_qty = 0;
                        $disposed_qty = 0;
                        $asset_maintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $stock->id]);
                        if ($asset_maintenances) {
                            foreach ($asset_maintenances as $asset_maintenance) {
                                $maintenance_qty += $asset_maintenance->maintenanceItems->where('status', '0')->count();
                                $disposed_qty += $asset_maintenance->maintenanceItems->where('status', '2')->count();
                            }
                        }
                        $reportBody .= '<td>'. ($stock->current_stock + $issued_qty + $leased_qty + $maintenance_qty + $disposed_qty).'</td>';
                        $maxRowArr[] = $stock->current_stock;
                        $maxRowArr[] = $issued_qty ? $issued_qty : 0;
                        $reportBody .= '<td colspan="7" class="text-center">'.$stock->current_stock.'</td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';
                        $reportBody .= '<td colspan="13" class="text-center">'.($issued_qty ? $issued_qty : 0).'</td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';
                        if($stock->asset->has_unique_number){
                            if($leased_qty){
                                $maxRowArr[] = $leased_qty;
                            }
                            if($maintenance_qty){
                                $maxRowArr[] = $maintenance_qty;
                            }
                            if($disposed_qty){
                                $maxRowArr[] = $disposed_qty;
                            }
                            $reportBody .= '<td colspan="23" class="text-center">'.($leased_qty ? $leased_qty : 0).'</td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';
                            $reportBody .= '<td colspan="13" class="text-center">'.($maintenance_qty ? $maintenance_qty : 0).'</td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';
                            $reportBody .= '<td colspan="9" class="text-center">'.($disposed_qty ? $disposed_qty : 0).'</td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';
                        }else{
                            $reportBody .= '<td></td><td></td><td></td>';
                        }
                        $reportBody .= '</tr>';

                        $inStockInventories = $this->assetStockService->findInStockItems(['inventories.asset_stock_id' => $stock->id]);
                        $issuedItems = $this->assetStockService->listAssetIssues(['asset_stock_id' => $stock->id]);

                        for($i = 0; $i < max($maxRowArr); $i++){
                            $reportBody .= '<tr>';
                            $reportBody .= '<td colspan="8"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td><td class="hidden-td"></td>';

                            /***** Current Stock *****/
                            if(isset($inStockInventories[$i])){
                                $ageOfAsset = '';
                                $purchaseDate = Carbon::parse($inStockInventories[$i]->purchase_date);
                                $age = $purchaseDate->diff($currentDate);
                                if($age->y){
                                    $ageOfAsset .= $age->y . ' Year ';
                                }
                                if($age->m){
                                    $ageOfAsset .= $age->m . ' Month ';
                                }
                                if($age->d){
                                    $ageOfAsset .= $age->d . ' Day';
                                }
                                $reportBody .= '<td>'.$inStockInventories[$i]->unique_id.'</td>';
                                $reportBody .= '<td>'.$inStockInventories[$i]->identification_no.'</td>';
                                $reportBody .= '<td>'.$inStockInventories[$i]->capacity_specs.'</td>';
                                $reportBody .= '<td>'.$inStockInventories[$i]->asset_condition.'</td>';
                                $reportBody .= '<td>'.Carbon::parse($inStockInventories[$i]->purchase_date)->format('d-m-Y').'</td>';
                                $reportBody .= '<td>'.Carbon::parse($inStockInventories[$i]->warranty_licence_date)->format('d-m-Y').'</td>';
                                $reportBody .= '<td>'.$ageOfAsset.'</td>';
                            }else{
                                $reportBody .= '<td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
                            }

                            /***** Issued Items *****/
                            if(isset($issuedItems[$i])){
                                $ageOfAsset = '';
                                $purchaseDate = Carbon::parse($issuedItems[$i]->inventory?->purchase_date);
                                $age = $purchaseDate->diff($currentDate);
                                if($age->y){
                                    $ageOfAsset .= $age->y . ' Year ';
                                }
                                if($age->m){
                                    $ageOfAsset .= $age->m . ' Month ';
                                }
                                if($age->d){
                                    $ageOfAsset .= $age->d . ' Day';
                                }
                                $acceptanceStatus = 'NA';
                                if($issuedItems[$i]->is_accepted !== null){
                                    if($issuedItems[$i]->is_accepted == '1'){
                                        $acceptanceStatus = 'Accepted';
                                    }else{
                                        $acceptanceStatus = 'Rejected';
                                    }
                                }
                                $reportBody .= '<td>'.$issuedItems[$i]->inventory?->unique_id.'</td>';
                                $reportBody .= '<td>'.$issuedItems[$i]->inventory?->identification_no.'</td>';
                                $reportBody .= '<td>'.$issuedItems[$i]->inventory?->capacity_specs.'</td>';
                                $reportBody .= '<td>'.$issuedItems[$i]->inventory?->asset_condition.'</td>';
                                $reportBody .= '<td>'.Carbon::parse($issuedItems[$i]->inventory?->purchase_date)->format('d-m-Y').'</td>';
                                $reportBody .= '<td>'.Carbon::parse($issuedItems[$i]->inventory?->warranty_licence_date)->format('d-m-Y').'</td>';
                                $reportBody .= '<td>'.$ageOfAsset.'</td>';
                                $reportBody .= '<td>'.$issuedItems[$i]->user?->first_name . " " . $issuedItems[$i]->user?->last_name.'</td>';
                                $reportBody .= '<td>'.Carbon::parse($issuedItems[$i]->issued_date)->format('d-m-Y').'</td>';
                                $reportBody .= '<td>'.$issuedItems[$i]->inventory?->comments.'</td>';
                                $reportBody .= '<td>'.($issuedItems[$i]->issuedImage->count() ? asset('storage/images/documents/' . $issuedItems[$i]->issuedImage[0]->file) : '').'</td>';
                                $reportBody .= '<td>'. asset('storage/images/documents/' . $issuedItems[$i]->allotment_letter) .'</td>';
                                $reportBody .= '<td>'.$acceptanceStatus.'</td>';
                            }else{
                                $reportBody .= '<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
                            }

                            /***** Leased Items *****/
                            $reportBody .= '<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';

                            /***** Maintenance Items *****/
                            $reportBody .= '<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';

                            /***** Disposed Items *****/
                            $reportBody .= '<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
                            $reportBody .= '</tr>';
                        }
                    }
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => $assetStocks->count()
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $typeCategories = $this->getAssetCategoryTree();
        return view('admin.report.asset-register-list', compact('typeCategories'));
    }

    public function assetRegisterReports(Request $request)
    {
        $this->setPageTitle('Asset Register');
        if ($request->ajax()) {
            $rules = [
                'category_id' => 'required',
                'asset_type_id' => 'required',
                'asset_id' => 'required',
            ];
            $messages = [
                'category_id' => 'Please select any asset category',
                'asset_type_id' => 'Please select any asset type',
                'asset_id' => 'Please select any asset',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reports = '';
                $reportHead = '<thead><tr><th></th></tr></thead>';
                $reportBody = '<tr><td class="text-center">No Records Found</td></tr>';
                $tableWidth = 0;
                $currentDate = Carbon::now();
                $filterConditions = ['asset_id' => $request->asset_id];
                $assetStocks = $this->assetStockService->findAssetStock($filterConditions);
                if($assetStocks->count()){
                    $tableWidth = 1500;
                    $reportBody = '';
                    $reportHead = '<thead>
                        <tr>
                            <th colspan="4">Asset Informations</th>
                            <th colspan="9">Stock Informations</th>
                        </tr>
                        <tr>
                            <th>Asset Category</th>
                            <th>Asset Type</th>
                            <th>Asset</th>
                            <th>Asset ID</th>
                            <th>Stock ID</th>
                            <th>Location</th>
                            <th>Entity</th>
                            <th>Total Stock</th>
                            <th>Current Stock</th>
                            <th>Issued</th>
                            <th>Leased</th>
                            <th>Under Maintenance</th>
                            <th>Disposed</th>
                        </tr>
                    </thead>';
                    foreach($assetStocks as $stock){
                        $maxRowArr = [];
                        $reportBody .= '<tr>';
                        $reportBody .= '<td>'.$stock->asset?->category?->name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->assettype?->name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->asset_name.'</td>';
                        $reportBody .= '<td>'.$stock->asset?->asset_id.'</td>';
                        $reportBody .= '<td>'.$stock->unique_id.'</td>';
                        $reportBody .= '<td>'.$stock->location?->street_address.'</td>';
                        $reportBody .= '<td>'.$stock->entity?->name.'</td>';

                        $issued_qty = $stock->assetIssue?->where('is_surrender', '0')->sum('quantity');
                        $leased_qty = 0;
                        $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);
                        if ($leased_agreements) {
                            foreach ($leased_agreements as $leased_agreement) {
                                $leased_qty += $leased_agreement->leaseItems->where('is_completed', '0')->count();
                            }
                        }
                        $maintenance_qty = 0;
                        $disposed_qty = 0;
                        $asset_maintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $stock->id]);
                        if ($asset_maintenances) {
                            foreach ($asset_maintenances as $asset_maintenance) {
                                $maintenance_qty += $asset_maintenance->maintenanceItems->where('status', '0')->count();
                                $disposed_qty += $asset_maintenance->maintenanceItems->where('status', '2')->count();
                            }
                        }
                        $reportBody .= '<td>'. ($stock->current_stock + $issued_qty + $leased_qty + $maintenance_qty + $disposed_qty).'</td>';
                        $maxRowArr[] = $stock->current_stock;
                        $maxRowArr[] = $issued_qty ? $issued_qty : 0;
                        $reportBody .= '<td class="text-center">'.$stock->current_stock.'</td>';
                        $reportBody .= '<td class="text-center">'.($issued_qty ? $issued_qty : 0).'</td>';
                        if($stock->asset->has_unique_number){
                            if($leased_qty){
                                $maxRowArr[] = $leased_qty;
                            }
                            if($maintenance_qty){
                                $maxRowArr[] = $maintenance_qty;
                            }
                            if($disposed_qty){
                                $maxRowArr[] = $disposed_qty;
                            }
                            $reportBody .= '<td class="text-center">'.($leased_qty ? $leased_qty : 0).'</td>';
                            $reportBody .= '<td class="text-center">'.($maintenance_qty ? $maintenance_qty : 0).'</td>';
                            $reportBody .= '<td class="text-center">'.($disposed_qty ? $disposed_qty : 0).'</td>';
                        }else{
                            $reportBody .= '<td>NA</td><td>NA</td><td>NA</td>';
                        }
                        $reportBody .= '</tr>';

                        $inStockInventories = $this->assetStockService->findInStockItems(['inventories.asset_stock_id' => $stock->id]);
                        $issuedItems = $this->assetStockService->listAssetIssues(['asset_stock_id' => $stock->id]);

                    }
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => $assetStocks->count()
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $typeCategories = $this->getAssetCategoryTree();
        return view('admin.report.asset-register-list', compact('typeCategories'));
    }
    public function assetAgeingReports(Request $request)
    {
        $this->setPageTitle('Asset Ageing Report');
        return view('admin.report.asset-ageing-list');
    }
    public function locationWiseAssetReports(Request $request)
    {
        $this->setPageTitle('Location Wise Asset Report');
        if ($request->ajax()) {
            $rules = [
                'location_id' => 'required',
                'entity_id' => 'required'
            ];
            $messages = [
                'location_id' => 'Please select any location',
                'entity_id' => 'Please select any entity'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reportHead = '<thead>
                                <tr>
                                    <th></th>
                                </tr>
                            </thead>';
                $reports = '';
                $reportBody = '';
                $tableWidth = 0;
                $filterConditions = ['location_id' => $request->location_id, 'entity_id' => $request->entity_id];
                $assetStocks = $this->assetStockService->findAssetStock($filterConditions);
                $hasData = false;
                $dataCount = 0;
                // dd($assetStock);
                if($assetStocks->count()){
                    foreach($assetStocks as $assetStock){
                        $assetInventories = $this->assetStockService->findInventories(['inventories.asset_stock_id' => $assetStock->id]);
                        if($assetInventories->count()){
                            $hasData = true;
                            $dataCount += $assetInventories->count();
                            foreach($assetInventories as $inventory){
                                $reportBody .= '<tr>';
                                $reportBody .= '<td>'.$inventory->asset?->asset_id.'</td>';
                                $reportBody .= '<td>'.$inventory->assetStock?->arn?->purchaseOrder?->entity?->name.'</td>';
                                $reportBody .= '<td>'.$inventory->issue?->user?->profile?->entity?->name.'</td>';
                                $reportBody .= '<td>'.$inventory->assetStock?->location?->street_address.'</td>';
                                $reportBody .= '<td>'.$inventory->asset?->asset_name.'</td>';
                                $reportBody .= '<td>'.$inventory->asset?->asset_name.'</td>';
                                $reportBody .= '<td>'.Carbon::parse($inventory->purchase_date)->format('Y-m-d').'</td>';
                                $purchaseDate = Carbon::parse($inventory->purchase_date);
                                $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                                $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                                $warranty_in_years = $diffInMonths / 12;
                                $reportBody .= '<td>'.number_format($warranty_in_years, 1).'</td>';
                                $reportBody .= '<td>'.Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d').'</td>';
                                $currentDate = Carbon::now();
                                $age = $purchaseDate->diff($currentDate);
                                $reportBody .= '<td>'.$age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days'.'</td>';
                                // $reportBody .= '<td><a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a></td>';
                                $reportBody .= '<td>' . $inventory->unique_id . '</td>';
                                $employeeCode = $inventory->issue ? $inventory->issue?->user?->unique_id : '';
                                $employeeDetails = $inventory->issue ? $inventory->issue?->user?->full_name : '';
                                $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                                if($inventory->lease){
                                    if($inventory->lease->leaseAgreement->type == 'internal'){
                                        $employeeCode = $inventory->lease->leasedUser->unique_id;
                                        $employeeDetails = $inventory->lease->leasedUser->full_name;
                                    }else{
                                        $employeeCode = '';
                                        $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                        $employeeDetails .= '<strong>Name: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_name'].'<br>';
                                        $employeeDetails .= '<strong>Phone Number: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_phone'].'<br>';
                                        $employeeDetails .= '<strong>Email: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_email'].'</div>';
                                    }
                                    $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                                }
                                $reportBody .= '<td>'.$employeeCode.'</td>';
                                $reportBody .= '<td>'.$employeeDetails.'</td>';
                                $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '').'</td>';
                                $reportBody .= '<td>'.($inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '').'</td>';
                                $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '').'</td>';
                                $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '').'</td>';
                                $reportBody .= '<td>'.$inventory->identification_no.'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.($inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '').'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.$inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name.'</td>';
                                $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                                $reportBody .= '<td>'.($invoice_nos ? implode(', ', $invoice_nos) : '').'</td>';
                                $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->comments : '').'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.($inventory->is_active == '1' ? 'Active' : 'In-Active').'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.Carbon::parse($inventory->purchase_date)->format('Y').'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.$inventory->capacity_specs.'</td>';
                                $reportBody .= '<td></td>';
                                $reportBody .= '<td>'.$allocationDate.'</td>';
                                $reportBody .= '</tr>';
                            }
                            $tableWidth = 4000;
                        }
                    }
                    if($hasData){
                        $reportHead = '<thead>
                            <tr>
                                <th>Serial No.</th>
                                <th>Purchase Entity</th>
                                <th>User Entity</th>
                                <th>Asset Location </th>
                                <th>Description</th>
                                <th>Model No</th>
                                <th>Date Of Purchase</th>
                                <th>Warranty in number of years</th>
                                <th>Warranty Expire</th>
                                <th>Age of Asset</th>
                                <th>Asset Id</th>
                                <th>Employee Code</th>
                                <th>Employee Name</th>
                                <th>Designation</th>
                                <th>SBU</th>
                                <th>Division</th>
                                <th>User Location</th>
                                <th>Asset Tag</th>
                                <th>Previous User</th>
                                <th>Issue with Laptop (if any)</th>
                                <th>Date of Scraping</th>
                                <th>Scrap Rate (in Rs.)</th>
                                <th>Scrap Vendor Details </th>
                                <th>Purchase Price (In Rs.) Excluding GST</th>
                                <th>Vendor</th>
                                <th>Invoice no.</th>
                                <th>Remark</th>
                                <th>Lost / Stolen - Year</th>
                                <th>Status</th>
                                <th>Others Specifications</th>
                                <th>Year of Purchase</th>
                                <th>Years Description</th>
                                <th>Capacity / Specifications</th>
                                <th>Accessories given at the time of allotment </th>
                                <th>Allotment Date</th>
                            </tr>
                        </thead>';
                    }else{
                        $reportBody .= '<tr><td class="text-center">No Records Found</td></tr>';
                    }
                }else{
                    $reportBody .= '<tr><td class="text-center">No Records Found</td></tr>';
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" =>  $dataCount
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $typeCategories = $this->getAssetCategoryTree();
        $locations = $this->assetService->listLocations();
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        return view('admin.report.location-asset-list', compact('locations', 'entities'));
    }
    public function userWiseAssetReports(Request $request)
    {
        $this->setPageTitle('User Wise Assets Report');
        if ($request->ajax()) {
            $rules = [
                'user_id' => 'required'
            ];
            $messages = [
                'user_id' => 'Please select any user'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reportHead = '<thead>
                                <tr>
                                    <th></th>
                                </tr>
                            </thead>';
                $reports = '';
                $reportBody = '';
                $tableWidth = 0;
                $filterConditions = ['user_id' => $request->user_id, 'is_surrender' => 0];
                $assetIssuedList = $this->assetStockService->listAssetIssues($filterConditions);
                // dd($assetStock);
                if($assetIssuedList->count()){
                    $reportHead = '<thead>
                        <tr>
                            <th>Serial No.</th>
                            <th>Purchase Entity</th>
                            <th>User Entity</th>
                            <th>Asset Location </th>
                            <th>Description</th>
                            <th>Model No</th>
                            <th>Date Of Purchase</th>
                            <th>Warranty in number of years</th>
                            <th>Warranty Expire</th>
                            <th>Age of Asset</th>
                            <th>Asset Id</th>
                            <th>Employee Code</th>
                            <th>Employee Name</th>
                            <th>Designation</th>
                            <th>SBU</th>
                            <th>Division</th>
                            <th>User Location</th>
                            <th>Asset Tag</th>
                            <th>Previous User</th>
                            <th>Issue with Laptop (if any)</th>
                            <th>Date of Scraping</th>
                            <th>Scrap Rate (in Rs.)</th>
                            <th>Scrap Vendor Details </th>
                            <th>Purchase Price (In Rs.) Excluding GST</th>
                            <th>Vendor</th>
                            <th>Invoice no.</th>
                            <th>Remark</th>
                            <th>Lost / Stolen - Year</th>
                            <th>Status</th>
                            <th>Others Specifications</th>
                            <th>Year of Purchase</th>
                            <th>Years Description</th>
                            <th>Capacity / Specifications</th>
                            <th>Accessories given at the time of allotment </th>
                            <th>Allotment Date</th>
                        </tr>
                    </thead>';
                    foreach($assetIssuedList as $assetIssued){
                        $assetStock = $this->assetStockService->findById($assetIssued->asset_stock_id);
                        $inventory = $assetIssued->inventory;
                        if($inventory){
                            $reportBody .= '<tr>';
                            $reportBody .= '<td>'.$inventory->asset?->asset_id.'</td>';
                            $reportBody .= '<td>'.$inventory->assetStock?->arn?->purchaseOrder?->entity?->name.'</td>';
                            $reportBody .= '<td>'.$inventory->issue?->user?->profile?->entity?->name.'</td>';
                            $reportBody .= '<td>'.$inventory->assetStock?->location?->street_address.'</td>';
                            $reportBody .= '<td>'.$inventory->asset?->asset_name.'</td>';
                            $reportBody .= '<td>'.$inventory->asset?->asset_name.'</td>';
                            $reportBody .= '<td>'.Carbon::parse($inventory->purchase_date)->format('Y-m-d').'</td>';
                            $purchaseDate = Carbon::parse($inventory->purchase_date);
                            $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                            $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                            $warranty_in_years = $diffInMonths / 12;
                            $reportBody .= '<td>'.number_format($warranty_in_years, 1).'</td>';
                            $reportBody .= '<td>'.Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d').'</td>';
                            $currentDate = Carbon::now();
                            $age = $purchaseDate->diff($currentDate);
                            $reportBody .= '<td>'.$age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days'.'</td>';
                            // $reportBody .= '<td><a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a></td>';
                            $reportBody .= '<td>' . $inventory->unique_id . '</td>';
                            $employeeCode = $inventory->issue ? $inventory->issue?->user?->unique_id : '';
                            $employeeDetails = $inventory->issue ? $inventory->issue?->user?->full_name : '';
                            $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                            if($inventory->lease){
                                if($inventory->lease->leaseAgreement->type == 'internal'){
                                    $employeeCode = $inventory->lease->leasedUser->unique_id;
                                    $employeeDetails = $inventory->lease->leasedUser->full_name;
                                }else{
                                    $employeeCode = '';
                                    $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                    $employeeDetails .= '<strong>Name: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_name'].'<br>';
                                    $employeeDetails .= '<strong>Phone Number: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_phone'].'<br>';
                                    $employeeDetails .= '<strong>Email: </strong>'.$inventory->lease->leaseAgreement->vendor_information['vendor_email'].'</div>';
                                }
                                $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                            }
                            $reportBody .= '<td>'.$employeeCode.'</td>';
                            $reportBody .= '<td>'.$employeeDetails.'</td>';
                            $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '').'</td>';
                            $reportBody .= '<td>'.($inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '').'</td>';
                            $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '').'</td>';
                            $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '').'</td>';
                            $reportBody .= '<td>'.$inventory->identification_no.'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.($inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '').'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.$inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name.'</td>';
                            $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                            $reportBody .= '<td>'.($invoice_nos ? implode(', ', $invoice_nos) : '').'</td>';
                            $reportBody .= '<td>'.($inventory->issue ? $inventory->issue?->comments : '').'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.($inventory->is_active == '1' ? 'Active' : 'In-Active').'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.Carbon::parse($inventory->purchase_date)->format('Y').'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.$inventory->capacity_specs.'</td>';
                            $reportBody .= '<td></td>';
                            $reportBody .= '<td>'.$allocationDate.'</td>';
                            $reportBody .= '</tr>';
                        }
                    }
                    $tableWidth = 4000;
                }else{
                    $reportBody .= '<tr><td class="text-center">No Records Found</td></tr>';
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => $assetIssuedList->count()
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $employees = $this->userService->getEmployees();
        return view('admin.report.user-asset-list', compact('employees'));
    }
    public function assetUsageHistoryReports(Request $request)
    {
        $this->setPageTitle('Asset Usage History Report');
        if ($request->ajax()) {
            $rules = [
                'category_id' => 'required',
                'asset_type_id' => 'required',
                'asset_id' => 'required',
            ];
            $messages = [
                'category_id' => 'Please select any asset category',
                'asset_type_id' => 'Please select any asset type',
                'asset_id' => 'Please select any asset',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reports = '';
                $reportHead = '<thead><tr><th></th></tr></thead>';
                $reportBody = '<tr><td class="text-center">No Records Found</td></tr>';
                $tableWidth = 0;
                $filterConditions = ['asset_id' => $request->asset_id];
                $issuedAssets = $this->assetStockService->getUsedAssets($filterConditions);
                // dd($usedAssets);
                if($issuedAssets->count()){
                    $tableWidth = 2000;
                    $reportBody = '';
                    $reportHead = '<thead>
                        <tr>
                            <th colspan="4">Asset Informations</th>
                            <th colspan="12">Usage Details</th>
                        </tr>
                        <tr>
                            <th>Asset Category</th>
                            <th>Asset Type</th>
                            <th>Asset</th>
                            <th width="12%">Specificatrions</th>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Designation</th>
                            <th>Department</th>
                            <th>Role</th>
                            <th>Date Of Joining</th>
                            <th>Entity</th>
                            <th>Issued Date</th>
                            <th>Status</th>
                            <th>Surrendered Date</th>
                        </tr>
                    </thead>';
                    foreach($issuedAssets as $issuedAsset){
                        foreach($issuedAsset as $k => $usedAsset){
                            $reportBody .= '<tr>';
                            if($k == 0){
                                $tdStyle = (count($issuedAsset) > 1) ? 'style="border-bottom-color: #fff;"' : '';
                                $reportBody .= '<td '.$tdStyle.'>'.$usedAsset->asset?->category?->name.'</td>';
                                $reportBody .= '<td '.$tdStyle.'>'.$usedAsset->asset?->assettype?->name.'</td>';
                                $reportBody .= '<td '.$tdStyle.'>
                                                    <label><strong>Model:</strong> '.$usedAsset->asset?->asset_name.'</label><br>
                                                    <label><strong>Serial No.:</strong> '.$usedAsset->inventory?->unique_id.'</label><br>
                                                    <label><strong>Identification No.:</strong> '.$usedAsset->inventory?->identification_no.'</label>
                                                </td>';
                                $reportBody .= '<td '.$tdStyle.'>'.$usedAsset->inventory?->capacity_specs.'</td>';
                            }else{
                                $reportBody .= '<td></td><td></td><td></td><td></td>';
                            }
                            $reportBody .= '<td>'.$usedAsset->user?->unique_id.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->full_name.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->mobile_number.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->email.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->profile?->designation?->name.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->profile?->department?->name.'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->roles?->first()->name.'</td>';
                            $reportBody .= '<td>'.Carbon::parse($usedAsset->user?->profile?->date_of_joining)->format('d-m-Y').'</td>';
                            $reportBody .= '<td>'.$usedAsset->user?->profile?->entity?->name.'</td>';
                            $reportBody .= '<td>'.Carbon::parse($usedAsset->issued_date)->format('d-m-Y').'</td>';
                            $reportBody .= '<td>'.($usedAsset->is_surrender == '0' ? 'Issued' : 'Surrendered').'</td>';
                            $reportBody .= '<td>'.($usedAsset->is_surrender == '1'
                            ? Carbon::parse($usedAsset->updated_at)->format('d-m-Y')
                            : 'NA').'</td>';
                            $reportBody .= '</tr>';
                        }
                    }
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => $issuedAssets->count()
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $typeCategories = $this->getAssetCategoryTree();
        return view('admin.report.usage-history-list', compact('typeCategories'));
    }
    public function purchaseHistoryReports(Request $request)
    {
        $this->setPageTitle('Purchase History Report');
        if ($request->ajax()) {
            $rules = [
                'category_id' => 'required',
                'asset_type_id' => 'required',
                'asset_id' => 'required',
            ];
            $messages = [
                'category_id' => 'Please select any asset category',
                'asset_type_id' => 'Please select any asset type',
                'asset_id' => 'Please select any asset',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $reports = '';
                $reportHead = '<thead><tr><th></th></tr></thead>';
                $reportBody = '<tr><td class="text-center">No Records Found</td></tr>';
                $tableWidth = 0;
                $filterConditions = ['asset_id' => $request->asset_id];
                $purchaseOrderItems = $this->assetService->findPoItems($filterConditions);
                if($purchaseOrderItems->count()){
                    $tableWidth = 4000;
                    $reportBody = '';
                    $reportHead = '<thead>
                        <tr>
                            <th colspan="18">Purchase Order Details</th>
                            <th colspan="11">Asset Informations</th>
                        </tr>
                        <tr>
                            <th>Order ID</th>
                            <th>Quotation ID</th>
                            <th>Entity</th>
                            <th>Order Date</th>
                            <th width="3%">Status</th>
                            <th>Vendor</th>
                            <th>Vendor Approval Status</th>
                            <th>Vendor State</th>
                            <th>Delivery State</th>
                            <th>Valid Date From</th>
                            <th>Valid Date To</th>
                            <th>Delivery Terms (in days)</th>
                            <th>Service Terms</th>
                            <th>Payment Terms (in days)</th>
                            <th>Warranty/ADP Terms (in months)</th>
                            <th width="8%">Descriptions</th>
                            <th>Delivery Address</th>
                            <th>Billing Address</th>
                            <th>Asset Category</th>
                            <th>Asset Type</th>
                            <th>Asset</th>
                            <th width="8%">Specificatrions</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Unit Rate</th>
                            <th>Discount</th>
                            <th>Tax</th>
                            <th>Total Amount</th>
                            <th width="8%">Remarks</th>
                        </tr>
                    </thead>';
                    foreach($purchaseOrderItems as $purchaseOrderItem){
                        $poData = $purchaseOrderItem->purchaseOrder;
                        if($poData){
                            $reportBody .= '<tr>';
                            $reportBody .= '<td>'.$poData->unique_id.'</td>';
                            $reportBody .= '<td>'.$poData->quotations?->unique_id.'</td>';
                            $reportBody .= '<td>'.$poData->entity?->name.'</td>';
                            $reportBody .= '<td>'.Carbon::parse($poData->po_date)->format('d-m-Y').'</td>';
                            switch ($poData->status) {
                                case '0':
                                    $statClass = 'text_pending';
                                    $status = 'Pending';
                                    break;
                                case '1':
                                    $statClass = 'text_green';
                                    $status = 'Approved';
                                    break;
                                case '2':
                                    $statClass = 'text_danger';
                                    $status = 'Rejected';
                                    break;
                                case '3':
                                    $statClass = 'text_danger';
                                    $status = 'Cancelled';
                                    break;
                                case '4':
                                    $statClass = 'text_black';
                                    $status = 'Closed';
                                    break;
                                case '5':
                                    $statClass = 'text_blue';
                                    $status = 'Ongoing Approval';
                                    break;
                                default:
                                    $statClass = 'text_black';
                                    $status = 'Not Sent For Approval';
                                    break;
                            }
                            $reportBody .= '<td><span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title="Status"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span></td>';
                            $reportBody .= '<td>'.$poData->vendor?->full_name.'</td>';
                            $vendor_approval = 'NA';
                            if($poData->status == '1'){
                                if($poData->is_vendor_approved !== null){
                                    $vendor_approval = ($poData->is_vendor_approved == '1') ? '<span class="text_green"><i class="fa-solid fa-circle mr-1"></i> Approved</span>' : '<span class="text_danger"><i class="fa-solid fa-circle mr-1"></i> Rejected</span>';
                                }
                            }
                            $reportBody .= '<td>'.$vendor_approval.'</td>';
                            $reportBody .= '<td>'.$poData->vendorState?->name.'</td>';
                            $reportBody .= '<td>'.$poData->deliveryState?->name.'</td>';
                            $reportBody .= '<td>'.$poData->valid_date_from->format('Y-m-d').'</td>';
                            $reportBody .= '<td>'. $poData->valid_date_to->format('Y-m-d') . '</td>';
                            $reportBody .= '<td>'. $poData->delivery_terms ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $poData->service_terms ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $poData->payment_terms ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $poData->warranty_terms ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $poData->descriptions ?? 'N/A' . '</td>';
                            $deliveryAddress = '';
                            foreach ($poData->delivery_address as $delivery_address){
                                $deliveryAddress .= '<p>' . @$delivery_address['delivery_street_address'] . ', ' . getLocationDetails((@$delivery_address['delivery_location_id']))?->street_address . ', ' . getStateDetails(@$delivery_address['delivery_state_id'])?->name .'</p>';
                            }
                            $reportBody .= '<td>'. $deliveryAddress ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $poData->billing_address['billing_street_address'] . ', ' . getLocationDetails(@$poData->billing_address['billing_location_id'])?->street_address . ', ' . getStateDetails(@$poData->billing_address['billing_state_id'])?->name . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->assetCategory?->name ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->assetType?->name ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->asset?->asset_name ?? 'N/A' . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->specifications . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->quantity . '</td>';
                            $reportBody .= '<td>'. ucfirst($purchaseOrderItem->unit) . '</td>';
                            $reportBody .= '<td>₹'. number_format($purchaseOrderItem->amount, 2, '.', ',') . '</td>';
                            $reportBody .= '<td>-'. (($purchaseOrderItem->discount_type == 'percentage') ? $purchaseOrderItem->discount . '%' : '₹' . $purchaseOrderItem->discount) . '</td>';
                            $reportBody .= '<td>'. ($purchaseOrderItem->tax ?? 0) . ' (' . $purchaseOrderItem->tax_type . ')' . '</td>';
                            $reportBody .= '<td>₹'. number_format($purchaseOrderItem->total_amount, 2, '.', ',') . '</td>';
                            $reportBody .= '<td>'. $purchaseOrderItem->description . '</td>';
                            $reportBody .= '</tr>';
                        }
                    }
                }
                $reports = $reportHead . '<tbody>' . $reportBody . '</tbody>';
                return $this->responseJson(true, 200, 'Report successfully fetched', [
                    "report" => $reports,
                    "tableWidth" => $tableWidth,
                    "dataCount" => $purchaseOrderItems->count()
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $typeCategories = $this->getAssetCategoryTree();
        return view('admin.report.purchase-history-list', compact('typeCategories'));
    }
    public function vendorPerformanceReports(Request $request)
    {
        $this->setPageTitle('Vendor Performance Report');
        return view('admin.report.vendor-performance-list');
    }
}
