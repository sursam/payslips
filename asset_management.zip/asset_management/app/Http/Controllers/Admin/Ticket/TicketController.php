<?php

namespace App\Http\Controllers\Admin\Ticket;

use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Mail\SendMailable;
use App\Models\Site\EntityDepartmentSetting;
use App\Models\Ticket\TicketActivity;
use App\Notifications\TicketNotification;
use App\Services\Asset\AssetService;
use App\Services\Category\CategoryService;
use App\Services\Inventory\AssetStockService;
use App\Services\Ticket\TicketService;
use App\Services\User\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class TicketController extends BaseController
{
    public function __construct(protected TicketService $ticketService, protected CategoryService $categoryService, protected AssetService $assetService, protected UserService $userService, protected AssetStockService $assetStockService)
    {
        $this->ticketService = $ticketService;
        $this->categoryService = $categoryService;
        $this->assetService = $assetService;
        $this->userService = $userService;
        $this->assetStockService = $assetStockService;
    }
    public function listTicket(Request $request, $type = '')
    {
        $this->setPageTitle('E-Ticket Management');
        // $tickets = $this->ticketService->listTickets();
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $deparmentAdmins = [];
        if ($departments && $departments->count()) {
            foreach ($departments as $key => $department) {
                $ticketSettings = $department->getTicketSettingsByEntity(auth()->user()->profile->entity?->id);
                if($ticketSettings->count()){
                    foreach($ticketSettings as $ticketSettingsData){
                        $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;
                        $deparmentAdmins[] = $departmentAdminId;
                        $concernedPersons = $ticketSettingsData && $ticketSettingsData->concerned_persons ? $ticketSettingsData->concerned_persons : [];
                        $deparmentAdmins = array_merge($deparmentAdmins, $concernedPersons);
                    }
                }
            }
        }
        $deparmentAdmins = array_unique(array_map('intval', $deparmentAdmins));
        // dd(auth()->user()->profile->entity);
        // echo auth()->user()->id;
        // dd($deparmentAdmins);
        $ticketsRaisedByMe = $this->ticketService->listTickets([], 'raised-by-me')->count();
        return view('admin.ticket.list', compact('type', 'entities', 'departments', 'deparmentAdmins', 'ticketsRaisedByMe'));
    }
    public function addTicket(Request $request)
    {
        // dd(auth()->user()->profile->location_id);
        $this->setPageTitle('Raise New Ticket');
        $lastId = $this->ticketService->listTickets()->pluck('id')->first();
        $ticketId = 'TKT' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        if ($request->ajax()) {
            $rules = [
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'parent_category' => 'required',
                'mobile_number' => 'required',
                'subject' => 'required',
                'description' => 'required',
                'priority' => 'required',
            ];
            $messages = [
                'entity_id.required' => 'The Entity field is required.',
                'entity_id.exists' => 'The selected entity is not found.',
                'department_id.required' => 'The department field is required.',
                'department_id.exists' => 'The selected department is not found.',
                'parent_category' => 'The ticket category field is required.',
                'mobile_number' => 'The mobile number field is required.',
                'subject' => 'The subject field is required.',
                'description' => 'The description field is required.',
                'priority' => 'The priority field is required.'
            ];
            $ticketCategories = $this->ticketService->listTicketCategories([
                'department_id' => $request->department_id,
                'parent_id' => $request->parent_category
            ]);
            if ($ticketCategories->count()) {
                $rules['ticket_category_id'] = 'required';
                $messages['ticket_category_id'] = 'The ticket sub category field is required.';
            }
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if ($request->priority == 1)
                    $priority = 'High';
                elseif ($request->priority == 2)
                    $priority = 'Medium';
                else
                    $priority = 'Low';

                $department = $this->assetService->findDepartmentById($request->department_id);
                if (!$request->ticket_category_id) {
                    $ticketCategoryId = $request->parent_category;
                    $request->merge(['ticket_category_id' => $ticketCategoryId]);
                } else {
                    $ticketCategoryId = $request->ticket_category_id;
                }
                $ticketCategory = $this->ticketService->findTicketCategoryById($ticketCategoryId);
                $ticketRaiserDept = auth()->user()->profile?->department?->name ? ' - ' . auth()->user()->profile?->department?->name : '';

                $openedTickets = $this->ticketService->listTicketsWithActivities(['department_id' => $department->id, 'status' => '1']);
                $isCreated = $this->ticketService->addOrUpdateTicket([
                    'uuid' => null
                ], $request->except('_token', 'parent_category'));

                if ($isCreated) {
                    $isRaiseActivityCreated = $this->ticketService->addTicketActivity([
                        'ticket_id' => $isCreated->id,
                        'message' => 'Ticket raised.',
                        'user_id' => auth()->user()->id,
                    ]);

                    $ticketAssignmentsCount = [];
                    if ($openedTickets) {
                        foreach ($openedTickets as $openedTicket) {
                            if ($openedTicket->activities->count()) {
                                if (array_key_exists($openedTicket->activities[0]->user_id, $ticketAssignmentsCount)) {
                                    $ticketAssignmentsCount[$openedTicket->activities[0]->user_id] += 1;
                                } else {
                                    $ticketAssignmentsCount[$openedTicket->activities[0]->user_id] = 1;
                                }
                            }
                        }
                    }
                    $ticketSettingsData = $department->getTicketSettingsData($ticketCategory->id, $request->entity_id, auth()->user()->profile->location_id);
                    $concerned_persons = $ticketSettingsData ? $ticketSettingsData->concerned_persons : [];
                    if (!empty($concerned_persons) && empty($ticketAssignmentsCount)){
                        foreach ($concerned_persons as $personId) {
                            $ticketAssignmentsCount[$personId] = 0;
                        }
                    }

                    if (!empty($concerned_persons) && !empty($ticketAssignmentsCount)){
                        foreach ($concerned_persons as $personId) {
                            if (!array_key_exists($personId, $ticketAssignmentsCount)) {
                                $ticketAssignmentsCount[$personId] = 0;
                            }
                        }
                    }

                    if ($concerned_persons) {
                        $ticketAssignUserId = $this->getUserForAssignment($concerned_persons, $ticketAssignmentsCount);
                    } else {
                        $ticketAssignUserId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;
                    }
                    $concernedPerson = $this->userService->findUserById($ticketAssignUserId);

                    $isPrimaryAssignActivityCreated = $this->ticketService->addTicketActivity([
                        'ticket_id' => $isCreated->id,
                        'message' => 'Ticket assigned to ' . $concernedPerson?->full_name . '.',
                        'type' => '1',
                        'user_id' => $concernedPerson->id,
                    ]);

                    $notiData = [
                        'form_name' => "#" . $isCreated->unique_id . " This new ticket has been raised and assigned to you. Please check.",
                        'ticket_uuid' => $isCreated->uuid,
                    ];

                    $concernedPerson->notify(new TicketNotification($notiData));
                    // $mailData = [
                    //     'to' => $concernedPerson->email,
                    //     'from' => env('MAIL_FROM_ADDRESS'),
                    //     'mail_type' => 'general',
                    //     'line' => 'A new ticket has been assigned to you. Please find the details below:<br><br><br>',
                    //     'content' => 'Ticket ID: #' . $isCreated->unique_id . '<br>Subject: ' . $request->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory->name . '<br>Raised By: ' . auth()->user()->full_name . $ticketRaiserDept . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are requested to review and take appropriate action at the earliest.<br><br><br>To view or update the ticket, please visit: <a href="' . route('admin.ticket.view', $isCreated->uuid) . '" class="edit_icon">' . $isCreated->unique_id . '</a>',
                    //     'subject' => 'New Ticket Assigned - Ticket #' . $isCreated->unique_id,
                    //     'greetings' => 'Dear ' . $concernedPerson->full_name . ',',
                    //     'end_greetings' => 'Best Regards,<br>DHC',
                    //     'from_user' => env('MAIL_FROM_NAME')
                    // ];

                    $entityDepartmentSetting = EntityDepartmentSetting::where(['entity_id' => $request->entity_id, 'department_id' => $request->department_id])->first();
                    $mailData = [
                        'to' => $concernedPerson->email,
                        'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => 'A new ticket has been assigned to you. Please find the details below:<br><br><br>',
                        'content' => 'Ticket ID: #' . $isCreated->unique_id . '<br>Subject: ' . $request->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory->name . '<br>Raised By: ' . auth()->user()->full_name . $ticketRaiserDept . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are requested to review and take appropriate action at the earliest.<br><br><br>To view or update the ticket, please visit: <a href="' . route('admin.ticket.view', $isCreated->uuid) . '" class="edit_icon">' . $isCreated->unique_id . '</a>',
                        'subject' => 'New Ticket Assigned - Ticket #' . $isCreated->unique_id,
                        'greetings' => 'Dear ' . $concernedPerson->full_name . ',',
                        'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                        'from_user' =>  $entityDepartmentSetting?->from_name
                    ];

                    // dd($mailData);
                    Mail::send(new SendMailable($mailData));
                    if ($request->cc_to) {
                        foreach ($request->cc_to as $ccTo) {
                            $isCcToCreated = $this->ticketService->addCcToUser([
                                'ticket_id' => $isCreated->id,
                                'user_id' => $ccTo,
                            ]);
                            if ($isCcToCreated) {
                                $ccToUser = $this->userService->findUserById($ccTo);
                                $ccNotiData = [
                                    'form_name' => "#" . $isCreated->unique_id . " This new ticket has been raised.",
                                    'ticket_uuid' => $isCreated->uuid,
                                ];
                                $ccToUser->notify(new TicketNotification($ccNotiData));
                                // $notiMailData = [
                                //     'to' => $ccToUser->email,
                                //     'from' => env('MAIL_FROM_ADDRESS'),
                                //     'mail_type' => 'general',
                                //     'line' => ' A new ticket has been raised and has been assigned to ' . $concernedPerson->fullname . '. Below are the ticket details',
                                //     'content' => 'Ticket ID: #' . $isCreated->unique_id . '<br>Subject: ' . $request->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory->name . '<br>Raised By: ' . auth()->user()->full_name . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are receiving this email for your information. You can monitor the ticket status or provide input if necessary.<br><br><br>To view the ticket, please visit: <a href="' . route('admin.ticket.view', $isCreated->uuid) . '" class="edit_icon">' . $isCreated->unique_id . '</a>',
                                //     'subject' => 'New Ticket Raised - Ticket #' . $isCreated->unique_id,
                                //     'greetings' => 'Dear ' . $ccToUser->full_name . ',',
                                //     'end_greetings' => 'Best Regards,<br>DHC',
                                //     'from_user' => env('MAIL_FROM_NAME')
                                // ];

                                $notiMailData = [
                                    'to' => $ccToUser->email,
                                    'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                                    'mail_type' => 'general',
                                    'line' => 'A new ticket has been assigned to you. Please find the details below:<br><br><br>',
                                    'content' => 'Ticket ID: #' . $isCreated->unique_id . '<br>Subject: ' . $request->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory->name . '<br>Raised By: ' . auth()->user()->full_name . $ticketRaiserDept . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are requested to review and take appropriate action at the earliest.<br><br><br>To view or update the ticket, please visit: <a href="' . route('admin.ticket.view', $isCreated->uuid) . '" class="edit_icon">' . $isCreated->unique_id . '</a>',
                                    'subject' => 'New Ticket Assigned - Ticket #' . $isCreated->unique_id,
                                    'greetings' => 'Dear ' . $concernedPerson->full_name . ',',
                                   'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                                    'from_user' =>  $entityDepartmentSetting?->from_name
                                ];
                                Mail::send(new SendMailable($notiMailData));
                            }
                        }
                    }
                    DB::commit();
                    return $this->responseJson(true, 200, 'Ticket successfully created.', [
                        'redirect_url' => route('admin.ticket.list', ['type' => 'raised-by-me'])
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        // $departments = getDepartmentWithManagerTree();
        $departments = getDepartmentWithManagerList();
        // $employees = $this->userService->getEmployees();


        $employees = auth()->user()->reportingPersons()->get();


        // $issuedAssets = $this->assetStockService->getAssetIssueByCondition(['user_id' => auth()->user()->id, 'is_surrender' => '0'])?->get();
        $issuedAssets = $this->assetStockService->getAssetIssueByCondition(['user_id' => auth()->user()->id, 'is_surrender' => '0']);

        return view('admin.ticket.add', compact('ticketId', 'entities', 'departments', 'employees', 'issuedAssets'));
    }
    private function getUserForAssignment($concernedPersons = [], $assignedArr = [])
    {
        if (count($assignedArr)) {
            $minValueKey = array_keys($assignedArr, min($assignedArr));
            if (in_array((string) $minValueKey[0], $concernedPersons)) {
                $userId = $minValueKey[0];
            } else {
                unset($assignedArr[$minValueKey[0]]);
                $userId = $this->getUserForAssignment($concernedPersons, $assignedArr);
            }
        } else {
            $userId = $concernedPersons[0];
        }
        return $userId;
    }
    public function editTicket(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Ticket');
        $ticket = $this->ticketService->findTicketById(uuidtoid($uuid, 'tickets'));
        // dd($ticket);
        $ticketCategories = $ticket->ticketCategory?->parent_id ? $this->ticketService->listTicketCategories([
            'department_id' => $ticket->department_id,
            'parent_id' => $ticket->ticketCategory?->parent_id
        ]) : null;
        if ($request->ajax()) {
            $rules = [
                // 'entity_id' => 'required|exists:categories,id',
                // 'department_id' => 'required|exists:departments,id',
                'parent_category' => 'required',
                // 'ticket_category_id' => 'required',
                'mobile_number' => 'required',
                'subject' => 'required',
                'description' => 'required',
                'priority' => 'required',
            ];
            $messages = [
                // 'entity_id.required' => 'The Entity field is required.',
                // 'entity_id.exists' => 'The selected entity is not found.',
                // 'department_id.required' => 'The department field is required.',
                // 'department_id.exists' => 'The selected department is not found.',
                'parent_category' => 'The ticket category field is required.',
                // 'ticket_category_id' => 'The ticket sub category field is required.',
                'mobile_number' => 'The mobile number field is required.',
                'subject' => 'The subject field is required.',
                'description' => 'The description field is required.',
                'priority' => 'The priority field is required.'
            ];
            $ticketCategories = $this->ticketService->listTicketCategories([
                'department_id' => $request->department_id,
                'parent_id' => $request->parent_category
            ]);
            if ($ticketCategories->count()) {
                $rules['ticket_category_id'] = 'required';
                $messages['ticket_category_id'] = 'The ticket sub category field is required.';
            }
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if (!$request->ticket_category_id) {
                    $ticketCategoryId = $request->parent_category;
                    $request->merge(['ticket_category_id' => $ticketCategoryId]);
                } else {
                    $ticketCategoryId = $request->ticket_category_id;
                }
                $ticketCategory = $this->ticketService->findTicketCategoryById($ticketCategoryId);
                // $request->merge(['priority' => $ticketCategory->priority]);
                $isUpdated = $this->ticketService->addOrUpdateTicket([
                    'uuid' => $uuid
                ], $request->except(['_token', 'entity_id', 'department_id', 'cc_to']));
                if ($isUpdated) {
                    /*if($request->cc_to){
                        $ticketCcTo = $ticket->ccTo->pluck('user_id')->toArray();
                        $ticket->ccTo->each->forceDelete();
                        foreach($request->cc_to as $ccTo){
                            $isCcToCreated = $this->ticketService->addCcToUser([
                                'ticket_id' => $ticket->id,
                                'user_id' => $ccTo,
                            ]);
                            if($isCcToCreated){
                                if(!in_array($ccTo, $ticketCcTo)){
                                    $ccToUser = $this->userService->findUserById($ccTo);
                                    $ccNotiData = [
                                        'form_name' => "#".$ticket->unique_id." This new ticket has been raised.",
                                        'ticket_uuid' => $ticket->uuid,
                                    ];
                                    $ccToUser->notify(new TicketNotification($ccNotiData));
                                    $notiMailData = [
                                        'to' => $ccToUser->email,
                                        'from' => env('MAIL_FROM_ADDRESS'),
                                        'mail_type' => 'general',
                                        'line' => $ticket->unique_id . ' This new ticket has been raised.',
                                        'content' => '',
                                        'subject' => 'New Ticket Raised',
                                        'greetings' => 'Hello Sir/Madam',
                                        'end_greetings' => 'Regards,',
                                        'from_user' => env('MAIL_FROM_NAME')
                                    ];
                                    Mail::send(new SendMailable($mailData));
                                }
                            }
                        }
                    }*/
                    DB::commit();
                    return $this->responseJson(true, 200, 'Ticket successfully updated.', [
                        'redirect_url' => route('admin.ticket.list', ['type' => 'raised-by-me'])
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        // $departments = getDepartmentWithManagerTree();
        $departments = getDepartmentWithManagerList();
        $employees = auth()->user()->reportingPersons()->get();
        // $employees = $this->userService->getEmployees();
        // $issuedAssets = $this->assetStockService->getAssetIssueByCondition(['user_id' => auth()->user()->id, 'is_surrender' => '0'])?->get();

        $issuedAssets = $this->assetStockService->getAssetIssueByCondition(['user_id' => auth()->user()->id, 'is_surrender' => '0']);

        $parentTicketCategories = $this->ticketService->listTicketCategories([
            'department_id' => $ticket->department_id,
            'parent_id' => null
        ]);

        $assignedUserId = null;
        if ($ticket->activity(3)) {
            $assignedUserId = $ticket->activity(3)->user_id;
        } elseif ($ticket->activity(2)) {
            $assignedUserId = $ticket->activity(2)->user_id;
        } else {
            $assignedUserId = $ticket->activity(1)->user_id;
        }
        $type = '';
        if ($assignedUserId == auth()->user()->id) {
            $type = 'assigned-to-me';
        } else if (auth()->user()->id == $ticket->activity(0)->user_id) {
            $type = 'raised-by-me';
        } else {
            $type = 'cc-to-me';
        }

        return view('admin.ticket.edit', compact('ticket', 'entities', 'departments', 'employees', 'issuedAssets', 'parentTicketCategories', 'ticketCategories', 'type'));
    }
    public function transferTicket(Request $request, $uuid)
    {
        $ticket = $this->ticketService->findTicketById(uuidtoid($uuid, 'tickets'));
        if ($request->ajax()) {
            $rules = [
                //'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
            ];
            $messages = [
                // 'entity_id.required' => 'The Entity field is required.',
                // 'entity_id.exists' => 'The selected entity is not found.',
                'department_id.required' => 'The department field is required.',
                'department_id.exists' => 'The selected department is not found.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if ($ticket->priority == 1)
                    $priority = 'High';
                elseif ($ticket->priority == 2)
                    $priority = 'Medium';
                else
                    $priority = 'Low';

                $ticketCategory = $ticket->ticketCategory?->name ?? 'NA';

                $ticketRaisedBy = $this->userService->findUserById($ticket->activity(0)->user_id);
                $ticketRaiserDept = $ticketRaisedBy->profile?->department?->name ?? 'N/A';


                $assignedUserId = null;
                if ($ticket->activity(3)) {
                    $assignedUserId = $ticket->activity(3)?->user_id;
                } elseif ($ticket->activity(2)) {
                    $assignedUserId = $ticket->activity(2)?->user_id;
                } else {
                    $assignedUserId = $ticket->activity(1)?->user_id;
                }
                $assignedTo = '';
                if ($assignedUserId) {
                    $previousAssignee = $this->userService->findUserById($assignedUserId);
                }






                if ($ticket->department_id != $request->department_id) {
                    $isUpdated = $this->ticketService->addOrUpdateTicket([
                        'uuid' => $uuid
                    ], $request->except(['_token']));
                    if ($isUpdated) {
                        $isRaiseActivityCreated = $this->ticketService->addTicketActivity([
                            'ticket_id' => $ticket->id,
                            'message' => 'Ticket transferred.',
                            'user_id' => auth()->user()->id,
                            'type' => '9',
                        ]);

                        $department = $this->assetService->findDepartmentById($request->department_id);

                        $openedTickets = $this->ticketService->listTicketsWithActivities(['department_id' => $department->id, 'status' => '1']);



                        $ticketAssignmentsCount = [];
                        if ($openedTickets) {
                            foreach ($openedTickets as $openedTicket) {
                                if ($openedTicket->activities->count()) {
                                    if (array_key_exists($openedTicket->activities[0]->user_id, $ticketAssignmentsCount)) {
                                        $ticketAssignmentsCount[$openedTicket->activities[0]->user_id] += 1;
                                    } else {
                                        $ticketAssignmentsCount[$openedTicket->activities[0]->user_id] = 1;
                                    }
                                }
                            }
                        }


                        // if (!empty($department->concerned_persons) && empty($ticketAssignmentsCount))
                        //     foreach ($department->concerned_persons as $personId) {
                        //         $ticketAssignmentsCount[$personId] = 0;
                        //     }

                        // if (!empty($department->concerned_persons) && !empty($ticketAssignmentsCount))
                        //     foreach ($department->concerned_persons as $personId) {
                        //         if (!array_key_exists($personId, $ticketAssignmentsCount)) {
                        //             $ticketAssignmentsCount[$personId] = 0;
                        //         }
                        //     }



                        // if ($department->concerned_persons) {
                        //     $ticketAssignUserId = $this->getUserForAssignment($department->concerned_persons, $ticketAssignmentsCount);
                        // } else {
                        //     $ticketAssignUserId = $department->department_manager;
                        // }


                        $ticketSettingsData = $department->getTicketSettingsData($ticketCategory->id, $request->entity_id, auth()->user()->profile->location_id);
                        $concerned_persons = $ticketSettingsData ? $ticketSettingsData->concerned_persons : [];
                        if (!empty($concerned_persons) && empty($ticketAssignmentsCount)){
                            foreach ($concerned_persons as $personId) {
                                $ticketAssignmentsCount[$personId] = 0;
                            }
                        }

                        if (!empty($concerned_persons) && !empty($ticketAssignmentsCount)){
                            foreach ($concerned_persons as $personId) {
                                if (!array_key_exists($personId, $ticketAssignmentsCount)) {
                                    $ticketAssignmentsCount[$personId] = 0;
                                }
                            }
                        }

                        if ($concerned_persons) {
                            $ticketAssignUserId = $this->getUserForAssignment($concerned_persons, $ticketAssignmentsCount);
                        } else {
                            $ticketAssignUserId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;
                        }

                        $concernedPerson = $this->userService->findUserById($ticketAssignUserId);

                        // $departmentAdminData = $this->userService->findUserById($department->department_manager);

                        $isPrimaryAssignActivityCreated = $this->ticketService->addTicketActivity([
                            'ticket_id' => $ticket->id,
                            'message' => 'Ticket assigned to ' . $concernedPerson->full_name . '.',
                            'type' => '1',
                            'user_id' => $concernedPerson->id,
                        ]);

                        $notiData = [
                            'form_name' => "#" . $ticket->unique_id . " This ticket has been transferred. Please assign to someone.",
                            'ticket_uuid' => $ticket->uuid,
                        ];
                        $concernedPerson->notify(new TicketNotification($notiData));


                        // $mailData = [
                        //     'to' => $concernedPerson->email,
                        //     'from' => env('MAIL_FROM_ADDRESS'),
                        //     'mail_type' => 'general',
                        //     'line' => 'The following helpdesk ticket has been transferred to you for further action:<br><br><br>Ticket Details:<br><br><br>',
                        //     'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-' . $ticketRaiserDept . 'Previous Assignee' . $previousAssignee->full_name . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are requested to review the ticket and take the necessary steps.<br><br><br>To access or update the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                        //     'subject' => 'Ticket Transferred: Ticket #' . $ticket->unique_id,
                        //     'greetings' => 'Dear ' . $concernedPerson->full_name . ',',
                        //     'end_greetings' => 'Best Regards,<br>DHC',
                        //     'from_user' => env('MAIL_FROM_NAME')
                        // ];

                        $entityDepartmentSetting=EntityDepartmentSetting::where(['entity_id'=>$ticket->entity_id,'department_id'=>$ticket->department_id])->first();
                        $mailData = [
                            'to' => $concernedPerson->email,
                            'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                                 'mail_type' => 'general',
                            'line' => 'The following helpdesk ticket has been transferred to you for further action:<br><br><br>Ticket Details:<br><br><br>',
                            'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-' . $ticketRaiserDept . 'Previous Assignee' . $previousAssignee->full_name . '<br><br><br>Description: ' . $request->description . '<br><br><br>You are requested to review the ticket and take the necessary steps.<br><br><br>To access or update the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                             'subject' => 'Ticket Transferred: Ticket #' . $ticket->unique_id,
                             'greetings' => 'Dear ' . $concernedPerson->full_name . ',',
                           'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                        'from_user' =>  $entityDepartmentSetting?->from_name
                        ];



                        Mail::send(new SendMailable($mailData));
                        DB::commit();
                        return $this->responseJson(true, 200, 'Ticket successfully transferred.', [
                            'redirect_url' => route('admin.ticket.list', ['type' => 'assigned-to-me'])
                        ]);
                    }
                } else {
                    return $this->responseJson(false, 500, 'Please choose different department', ['department_id' => 'Please choose different department']);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        // $departments = getDepartmentWithManagerTree();
        $departments = getDepartmentWithManagerList();
        $employees = $this->userService->getEmployees();

        $assignedUserId = null;
        if ($ticket->activity(3)) {
            $assignedUserId = $ticket->activity(3)->user_id;
        } elseif ($ticket->activity(2)) {
            $assignedUserId = $ticket->activity(2)->user_id;
        } else {
            $assignedUserId = $ticket->activity(1)->user_id;
        }
        $type = '';
        if ($assignedUserId == auth()->user()->id) {
            $type = 'assigned-to-me';
        } else if (auth()->user()->id == $ticket->activity(0)->user_id) {
            $type = 'raised-by-me';
        } else {
            $type = 'cc-to-me';
        }

        return view('admin.ticket.edit', compact('ticket', 'entities', 'departments', 'employees', 'type'));
    }
    public function viewTicket(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('E-Ticket Management');

        $ticket = $this->ticketService->findTicketById(uuidtoid($uuid, 'tickets'));

        $ticketSettingsData = $ticket->department?->getTicketSettingsData($ticket->ticketCategory->id, $ticket->entity->id, auth()->user()->profile->location_id);
        $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;

        //dd(auth()->user()->id,$ticket->department?->department_manager);
        if (auth()->user()->hasRole('super-admin') || auth()->user()->id == $ticket->activity(0)->user_id || auth()->user()->id == $ticket->activity(1)->user_id || auth()->user()->id == $ticket->activity(2)?->user_id || auth()->user()->id == $ticket->activity(3)?->user_id || in_array(auth()->user()->id, $ticket->ccTo->pluck('user_id')->toArray()) || auth()->user()->id == $departmentAdminId) {
            $assignedUserId = null;
            if ($ticket->activity(3)) {
                $assignedUserId = $ticket->activity(3)->user_id;
            } elseif ($ticket->activity(2)) {
                $assignedUserId = $ticket->activity(2)->user_id;
            } else {
                $assignedUserId = $ticket->activity(1)->user_id;
            }
            if ($notiuuid != null) {
                $this->notificationMarkRead($notiuuid);
            }
            $type = 'assigned-to-me';
            if ($assignedUserId == auth()->user()->id) {
                $type = 'assigned-to-me';
            } else if (auth()->user()->id == $ticket->activity(0)->user_id) {
                $type = 'raised-by-me';
            } else if (in_array(auth()->user()->id, $ticket->ccTo->pluck('user_id')->toArray())) {
                $type = 'cc-to-me';
            }
            $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
            // $departments = getDepartmentWithManagerTree();
            $departments = getDepartmentWithManagerList();
            return view('admin.ticket.view', compact('ticket', 'assignedUserId', 'type', 'entities', 'departments'));
        }
        abort(401);
        //return view('errors.custom-403');

    }

    public function assignTicket(Request $request)
    {
        if ($request->ajax()) {
            $rules = [
                'user_uuid' => 'required|exists:users,uuid',
            ];
            $messages = [
                'user_uuid.required' => 'The employee field is required.',
                'user_uuid.exists' => 'The employee is not found.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $ticket = $this->ticketService->findTicketById(uuidtoid($request->ticket_uuid, 'tickets'));
                if ($ticket->priority == 1)
                    $priority = 'High';
                elseif ($ticket->priority == 2)
                    $priority = 'Medium';
                else
                    $priority = 'Low';



                $ticketCategory = $ticket->ticketCategory?->name ?? 'NA';

                $ticketRaisedBy = $this->userService->findUserById($ticket->activity(0)->user_id);
                $ticketRaiserDept = $ticketRaisedBy->profile?->department?->name ?? 'N/A';



                $employee = $this->userService->findUserById(uuidtoid($request->user_uuid, 'users'));

                $isTicketAssigned = $ticket->activity(2);
                $message = 'Ticket assigned to ' . $employee->full_name;
                $type = 2;
                $successMessage = 'Ticket successfully assigned.';
                if ($isTicketAssigned) {
                    $message = 'Ticket re-assigned to ' . $employee->full_name . '.';
                    $type = 3;
                    $successMessage = 'Ticket successfully re-assigned.';
                }

                $isActivityCreated = $this->ticketService->addTicketActivity([
                    'ticket_id' => $ticket->id,
                    'message' => $message,
                    'type' => $type,
                    'user_id' => $employee->id,
                ]);
                if ($isActivityCreated) {
                    $notiData = [
                        'form_name' => "#" . $ticket->unique_id . " This ticket has been assigned to you",
                        'ticket_uuid' => $ticket->uuid,
                    ];
                    $employee->notify(new TicketNotification($notiData));
                    // $mailData = [
                    //     'to' => $employee->email,
                    //     'from' => env('MAIL_FROM_ADDRESS'),
                    //     'mail_type' => 'general',
                    //     'line' => 'A new ticket has been assigned to you. Please find the details below:<br><br><br>',
                    //     'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-'.$ticketRaiserDept.'<br><br><br>Description: ' . $ticket->description . '<br><br><br>You are requested to review and take appropriate action at the earliest.<br><br><br>To view or update the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                    //     'subject' => 'New Ticket Assigned to You - Ticket #' . $ticket->unique_id,
                    //     'greetings' => 'Dear ' . $employee->full_name . ',',
                    //     'end_greetings' => 'Best Regards,<br>DHC',
                    //     'from_user' => env('MAIL_FROM_NAME')
                    // ];

                    $entityDepartmentSetting = EntityDepartmentSetting::where(['entity_id' => $ticket->entity_id, 'department_id' => $ticket->department_id])->first();


                    $mailData = [
                        'to' => $employee->email,
                        'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => 'A new ticket has been assigned to you. Please find the details below:<br><br><br>',
                        'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-' . $ticketRaiserDept . '<br><br><br>Description: ' . $ticket->description . '<br><br><br>You are requested to review and take appropriate action at the earliest.<br><br><br>To view or update the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                        'subject' => 'New Ticket Assigned to You - Ticket #' . $ticket->unique_id,
                        'greetings' => 'Dear ' . $employee->full_name . ',',
                       'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                        'from_user' =>  $entityDepartmentSetting?->from_name
                    ];

                    Mail::send(new SendMailable($mailData));
                    DB::commit();
                    return $this->responseJson(true, 200, $successMessage, [
                        'redirect_url' => route('admin.ticket.list', ['type' => 'assigned-to-me'])
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        abort(403);
    }
    public function ticketReply(Request $request)
    {
        if ($request->ajax()) {
            $rules = [
                //'message' => 'required',
                //'status' => 'required|in:0,1',
            ];
            $messages = [
                //'message' => 'The reply field is required.',
                // 'status.in' => 'The selected status is invalid. Please choose either Accept or Deny.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {



                $ticket = $this->ticketService->findTicketById($request->ticket_id);
                $entityDepartmentSetting = EntityDepartmentSetting::where(['entity_id' => $ticket->entity_id, 'department_id' => $ticket->department_id])->first();

                if ($ticket->priority == 1)
                    $priority = 'High';
                elseif ($ticket->priority == 2)
                    $priority = 'Medium';
                else
                    $priority = 'Low';

                switch ($ticket->status) {
                    case -1:
                        $currentStatus = 'Request-For-Close';
                        break;
                    case 0:
                        $currentStatus = 'Closed';
                        break;
                    case 1:
                        $currentStatus = 'Open';
                        break;
                    case 2:
                        $currentStatus = 'Cancelled';
                        break;
                    default:
                        $currentStatus = 'Open';
                        break;
                }

                $ticketCategory = $ticket->ticketCategory?->name ?? 'NA';

                $ticketRaisedBy = $this->userService->findUserById($ticket->activity(0)->user_id);
                $ticketRaiserDept = $ticketRaisedBy->profile?->department?->name ?? 'N/A';

                if ($request->status != null || $request->message != null || $request->attachment_document != null) {

                    $completed_at = now();

                    $request->merge(['user_id' => auth()->user()->id, 'type' => 4]);

                    if (isset($request->status) && $request->status !== "") {
                        $data = $this->ticketService->addOrUpdateTicket(['id' => $request->ticket_id], ['status' => $request->status, 'completed_at' => $completed_at]);
                    }
                    if ($request->status == "0" || $request->status == "1" || $request->status == "-1" || $request->status == "2") {

                        switch ($request->status) {
                            case '-1':
                                $activityMessage = 'A request has been sent to close this ticket.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been requested for close.";
                                $type = '6';
                                break;
                            case '0':
                                $activityMessage = 'Closing request accepted. Ticket has been closed.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been closed.";
                                $type = '7';
                                break;
                            case '1':
                                $activityMessage = 'Closing request denied. Ticket remains open.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket remains open.";
                                $type = '10';
                                break;
                            case '2':
                                $activityMessage = 'Ticket cancelled.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been cancelled.";
                                $type = '8';
                                break;
                        }

                        $latestActivity = TicketActivity::where('ticket_id', $request->ticket_id)->orderBy('id', 'DESC')->first();
                        $isClosedActivityCreated = $this->ticketService->addTicketActivity([
                            'ticket_id' => $ticket->id,
                            'message' => $activityMessage,
                            'type' => $type,
                            'user_id' => auth()->user()->id,
                            'created_at' => $completed_at,
                        ]);


                        if ($isClosedActivityCreated && ($request->status == "0" || $request->status == "1")) {
                            if ($latestActivity) {
                                $this->ticketService->updateTicketActivity([
                                    'is_updated' => 1
                                ], $latestActivity->id);
                            }
                        }
                        $notiData = [
                            'form_name' => $notiMessage,
                            'ticket_uuid' => $ticket->uuid,
                        ];



                        $ticketRaisedUser = $ticket->activity(0)->user;
                        $ticketRaisedUser->notify(new TicketNotification($notiData));
                        // $mailData = [
                        //     'to' => $ticketRaisedUser->email,
                        //     'from' => env('MAIL_FROM_ADDRESS'),
                        //     'mail_type' => 'general',
                        //     'line' => 'An update has been provided for your ticket. Please find the details below:<br><br>Ticket Details:<br>',
                        //     'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Helpdesk Reply: ' . $request->message . '<br><br><br>If the provided resolution addresses your concern, kindly mark the ticket as closed. If further assistance is required, you can update the ticket using the link below:<br><br><br>To view the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                        //     'subject' => 'Update on Your Ticket - Ticket #' . $ticket->unique_id,
                        //     'greetings' => 'Dear ' . $ticketRaisedUser->full_name . ',',
                        //     'end_greetings' => 'Best Regards,<br>DHC',
                        //     'from_user' => env('MAIL_FROM_NAME')
                        // ];


                        $mailData = [
                            'to' => $ticketRaisedUser->email,
                            'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'An update has been provided for your ticket. Please find the details below:<br><br>Ticket Details:<br>',
                            'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Helpdesk Reply: ' . $request->message . '<br><br><br>If the provided resolution addresses your concern, kindly mark the ticket as closed. If further assistance is required, you can update the ticket using the link below:<br><br><br>To view the ticket, please visit: <a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>',
                            'subject' => 'Update on Your Ticket - Ticket #' . $ticket->unique_id,
                            'greetings' => 'Dear ' . $ticketRaisedUser->full_name . ',',
                            'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                            'from_user' =>  $entityDepartmentSetting?->from_name
                        ];
                        Mail::send(new SendMailable($mailData));
                    }

                    if (isset($request->message) && $request->message !== "") {
                        $isActivityCreated = $this->ticketService->addTicketActivity($request->except('_token'));

                        if ($isActivityCreated) {
                            $notiData = [
                                'form_name' => auth()->user()->full_name . " has replied in the ticket #" . $ticket->unique_id,
                                'ticket_uuid' => $ticket->uuid,
                            ];
                            $ticketRaisedActivity = $ticket->activity(0);
                            $notiUser = $ticketRaisedActivity->user;
                            $ticketAssignedActivity = $ticket->activity(3) ? $ticket->activity(3) : $ticket->activity(2);
                            if (!$ticketAssignedActivity) {
                                $ticketAssignedActivity = $ticket->activity(1);
                            }
                            if ($ticketAssignedActivity->user_id != auth()->user()->id) {
                                $notiUser = $ticketAssignedActivity->user;
                            }
                            $notiUser->notify(new TicketNotification($notiData));
                            // $mailData = [
                            //     'to' => $notiUser->email,
                            //     'from' => env('MAIL_FROM_ADDRESS'),
                            //     'mail_type' => 'general',
                            //     'line' => 'The ticket raised by ' . $ticketRaisedBy->full_name . ' has been updated with additional feedback or queries.',
                            //     'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-' . $ticketRaiserDept . '<br>Current Status: ' . $currentStatus . '<br>Users Update: ' . $request->message . '<br><br><br>Please review the users input and take the necessary action to address the concern. Ensure the user is notified once the issue has been resolved or additional support has been provided.<br><br><br>To view or update the ticket, click here' . '<a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a><br><br><br>For any clarifications, feel free to reach out to the user directly',
                            //     'subject' => 'Ticket Reply - #' . $ticket->unique_id,
                            //     'greetings' => 'Dear ' . $notiUser->full_name . ', ',
                            //     'end_greetings' => 'Best Regards,<br>DHC',
                            //     'from_user' => env('MAIL_FROM_NAME')
                            // ];


                            $mailData = [
                                'to' => $notiUser->email,
                                'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'The ticket raised by ' . $ticketRaisedBy->full_name . ' has been updated with additional feedback or queries.',
                                'content' => 'Ticket ID: #' . $ticket->unique_id . '<br>Subject: ' . $ticket->subject . '<br>Priority: ' . $priority . '<br>Category: ' . $ticketCategory . '<br>Raised By: ' . $ticketRaisedBy->full_name . '-' . $ticketRaiserDept . '<br>Current Status: ' . $currentStatus . '<br>Users Update: ' . $request->message . '<br><br><br>Please review the users input and take the necessary action to address the concern. Ensure the user is notified once the issue has been resolved or additional support has been provided.<br><br><br>To view or update the ticket, click here' . '<a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a><br><br><br>For any clarifications, feel free to reach out to the user directly',
                                'subject' => 'Ticket Reply - #' . $ticket->unique_id,
                                'greetings' => 'Dear ' . $notiUser->full_name . ', ',
                               'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                                'from_user' =>  $entityDepartmentSetting?->from_name
                            ];
                            Mail::send(new SendMailable($mailData));
                        }
                    }
                    DB::commit();
                    return $this->responseJson(true, 200, "Reply successfully submitted", [
                        'redirect_url' => route('admin.ticket.view', $ticket->uuid)
                    ]);
                } else {
                    return $this->responseJson(false, 500, 'Please choose any option or write some text or upload file', ['errormessagetextid' => 'Please choose any option or write some text or upload file']);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        abort(405);
    }

    public function ticketSettings(Request $request)
    {
        $this->setPageTitle('E-Ticket Settings');
        $departments = $this->assetService->listDepartments(['is_active' => 1, 'parent_id' => null], 'id', 'DESC');

        return view('admin.ticket.settings', compact('departments'));
    }
    public function updateDepartment(Request $request)
    {
        $rules = [
            'location_ids' => 'required',
            'department_admin' => 'required',
            'concerned_persons' => 'required',
        ];
        $messages = [
            'location_ids' => 'Location is required.',
            'department_admin' => 'Department admin is required.',
            'concerned_persons' => 'Concerned person is required.',
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
        }
        DB::beginTransaction();
        try {
            $departmentId = uuidtoid($request->uuid, 'departments');
            $ticketCategoryId = uuidtoid($request->ticket_category_uuid, 'ticket_categories');
            $entityId = uuidtoid($request->entity_uuid, 'categories');
            // $isDepartmentUpdated = $this->assetService->createOrUpdateTicketSettings($request->except('_token'), ['department_id' => $departmentId, 'entity_id' => $entityId, 'ticket_category_id' => $ticketCategoryId]);
            $data = [
                'entity_id' => $entityId,
                'department_id' => $departmentId,
                'ticket_category_id' => $ticketCategoryId,
                'location_ids' => $request->location_ids,
                'department_admin' => $request->department_admin,
                'concerned_persons' => $request->concerned_persons
            ];
            $isDepartmentUpdated = $this->assetService->createOrUpdateTicketSettings($data, ['id' => $request->settings_id]);
            if ($isDepartmentUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, 'Settings successfully updated.', [
                    'redirect_url' => route('admin.settings.ticket.category.concerned', [$request->uuid, $request->ticket_category_uuid])
                ]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }



    public function updateSla(Request $request)
    {
        if ($request->ajax()) {
            $rules = [
                'high' => 'required|integer',
                'medium' => 'required|integer',
                'low' => 'required|integer',
            ];
            $messages = [
                'high.required' => 'The high duration is required.',
                'high.integer' => 'The high duration must be integer.',
                'medium.required' => 'The medium duration is required.',
                'medium.integer' => 'The medium duration must be integer..',
                'low.required' => 'The low duration is required.',
                'low.integer' => 'The low duration must be integer.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isDepartmentUpdated = $this->assetService->createOrUpdateSla($request->except('_token'), uuidtoid($request->uuid, 'departments'));
                if ($isDepartmentUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'SLA Time successfully updated.', [
                        'redirect_url' => route('admin.settings.ticket.settings')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function ticketCategories(Request $request, $duuid, $uuid = null)
    {
        $ticketCategory = null;
        if ($uuid) {
            $categoryId = uuidtoid($uuid, 'ticket_categories');
            $ticketCategory = $this->ticketService->findTicketCategoryById($categoryId);
        }
        $departmentId = uuidtoid($duuid, 'departments');
        $department = $this->assetService->findDepartmentById($departmentId);
        $pageTitle = !$ticketCategory ? 'Ticket Categories' : 'Sub Categories Of ' . $ticketCategory->name;
        $this->setPageTitle($pageTitle);
        $filterConditions = [
            'department_id' => $departmentId,
            'parent_id' => null
        ];
        // $categories = $this->ticketService->listTicketCategories($filterConditions);

        // $categoryList = $this->getTicketCategoryList($categories, $department->uuid);

        return view('admin.ticket.category.list', compact('uuid', 'department', 'ticketCategory'));
    }
    /*private function getTicketCategoryList($categories, $departmentUuid, $isChildRow = false, $categoryList = ''){
        if($categories->count()){
            foreach ($categories as $key => $category) {
                $priority = '';
                switch($category->priority){
                    case '1': $priority = 'High'; break;
                    case '2': $priority = 'Medium'; break;
                    case '3': $priority = 'Low'; break;
                }
                $rowClass = $isChildRow ? 'child-row' : '';
                $categoryList .= '<tr class="'.$rowClass.'">';
                $categoryList .= '<td><p class="table-con category-name">' . $category->name . '</p></td>';
                $categoryList .= '<td><p class="table-con">' . $category->description . '</p></td>';
                $categoryList .= '<td><p class="table-con">' . $priority . '</p></td>';
                $categoryList .= '<td><div class="action_sec">
                    <div class="status_box">
                        <div class="dropdown">
                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="' . (($category->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($category->is_active == '1') ? 'Active' : 'Inactive') . '
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                <li><a class="dropdown-item text_green" ' . (($category->is_active != '1') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                <li><a class="dropdown-item text_danger" ' . (($category->is_active != '0') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                            </ul>
                        </div>
                    </div>
                </div></td>';

                $categoryList .= '<td><div class="action_sec">
                    <div class="action_box">
                        <a href="' . route('admin.settings.ticket.category.edit', [$departmentUuid, $category->uuid]) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>
                        <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="ticket_categories" data-uuid="' . $category->uuid . '"><i class="fa-solid fa-trash-can"></i></a>
                    </div>
                </div></td>';
                $categoryList .= '</tr>';

                if($category->children->count()){
                    // $categoryList .= '<tr class="sub-row-head"><td colspan="5"><strong>Sub-Categories of ' . $category->name . '</strong></td></tr>';
                    $categoryList .= $this->getTicketCategoryList($category->children, $departmentUuid, true);
                }
            }
        }else{
            $categoryList .= '<tr><td colspan="3">No data available</td></tr>';
        }
        return $categoryList;
    }*/
    public function addTicketCategory(Request $request, $duuid)
    {
        $this->setPageTitle('Add Ticket Category');
        $departmentId = uuidtoid($duuid, 'departments');
        $department = $this->assetService->findDepartmentById($departmentId);
        $filterConditions = [
            'department_id' => $departmentId,
        ];
        $categories = $this->ticketService->listTicketCategories($filterConditions);
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|min:2',
                'priority' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $data = ['department_id' => $departmentId];
                if ($request->parent_uuid) {
                    $parentId = uuidtoid($request->parent_uuid, 'ticket_categories');
                    $data['parent_id'] = $parentId;
                }
                $request->merge($data);
                $isCategoryCreated = $this->ticketService->addOrUpdateTicketCategory([
                    'uuid' => null
                ], $request->except('_token', 'parent_uuid'));
                if ($isCategoryCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Ticket category added successfully.', [
                        'redirect_url' => route('admin.settings.ticket.categories', $duuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.ticket.category.add', compact('department', 'categories'));
    }
    public function editTicketCategory(Request $request, $duuid, $uuid)
    {
        $this->setPageTitle('Edit Ticket Category');
        $departmentId = uuidtoid($duuid, 'departments');
        $department = $this->assetService->findDepartmentById($departmentId);
        $categoryId = uuidtoid($uuid, 'ticket_categories');
        $ticketCategory = $this->ticketService->findTicketCategoryById($categoryId);
        $filterConditions = [
            'department_id' => $departmentId,
        ];
        $categories = $this->ticketService->listTicketCategories($filterConditions);
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|min:2',
                'priority' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if ($request->parent_uuid) {
                    $parentId = uuidtoid($request->parent_uuid, 'ticket_categories');
                    $request->merge(['parent_id' => $parentId]);
                }
                $isCategoryUpdated = $this->ticketService->addOrUpdateTicketCategory([
                    'uuid' => $uuid
                ], $request->except('_token', 'parent_uuid'));
                if ($isCategoryUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Ticket category updated successfully.', [
                        'redirect_url' => route('admin.settings.ticket.categories', $duuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.ticket.category.edit', compact('uuid', 'department', 'ticketCategory', 'categories'));
    }
    public function ticketConcernedPersons(Request $request, $uuid)
    {
        $departmentId = uuidtoid($uuid, 'departments');
        $department = $this->assetService->findDepartmentById($departmentId);
        $this->setPageTitle("Concerned Persons");
        if ($request->ajax()) {
            $rules = [
                'concerned_persons' => 'required',
            ];
            $messages = [
                'concerned_persons' => 'Please select any concerned persons.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isUpdated = $this->assetService->createOrUpdateDepartment($request->except('_token'), $departmentId);

                if ($isUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Department concerned persons updated successfully.', [
                        'redirect_url' => route('admin.settings.ticket.concerned.persons', $uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.ticket.concerned-persons', compact('department'));
    }
    public function ticketCategoryConcernedPersons(Request $request, $duuid, $uuid)
    {
        $departmentId = uuidtoid($duuid, 'departments');
        $department = $this->assetService->findDepartmentById($departmentId);
        $categoryId = uuidtoid($uuid, 'ticket_categories');
        $ticketCategory = $this->ticketService->findTicketCategoryById($categoryId);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        $this->setPageTitle("Concerned Persons");
        if ($request->ajax()) {
            $rules = [
                'concerned_persons' => 'required',
            ];
            $messages = [
                'concerned_persons' => 'Please select any concerned persons.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isUpdated = $this->assetService->createOrUpdateDepartment($request->except('_token'), $departmentId);

                if ($isUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Department concerned persons updated successfully.', [
                        'redirect_url' => route('admin.settings.ticket.category.concerned', [$duuid, $uuid])
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.ticket.concerned-persons', compact('department', 'ticketCategory', 'entities', 'locations'));
    }
}
