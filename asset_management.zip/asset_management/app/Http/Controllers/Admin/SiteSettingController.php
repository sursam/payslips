<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\BaseController;
use App\Models\Site\EntityDepartmentSetting;
use App\Models\Site\Setting;
use App\Services\Asset\AssetService;
use App\Services\Category\CategoryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SiteSettingController extends BaseController
{
    // public function __construct(){
    //     $this->setPageTitle('Site Settings');
    // }

    public function __construct(
        protected CategoryService $categoryService,
        protected AssetService $assetService,
    ) {
        $this->setPageTitle('Site Settings');
        $this->categoryService = $categoryService;
        $this->assetService = $assetService;
    }

    public function index(Request $request)
    {
        if ($request->post()) {
            $data = $request->except('_token');
            DB::beginTransaction();
            try {
                foreach ($data as $key => $value) {
                    Setting::updateOrCreate(['key' => $key], [
                        'value' => $value
                    ]);
                }
                DB::commit();
                return $this->responseRedirectBack('Settings updated successfully', 'success', false);
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something went wrong.', 'error', true, true);
            }
        }
        //return view('admin.settings.site-settings.index');
        return view('admin.settings.site-settings.index');
    }



    public function departmentEntitySettings(Request $request, $departmentUuid)
    {


        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $department = $this->assetService->findDepartmentById(uuidtoid($departmentUuid, 'departments'));

        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                $deparmentId=uuidtoid($request->departmentUuid,'departments');
                $entityId=uuidtoid($request->entity_uuid,'categories');
                $request->merge(['department_id' => $deparmentId,'entity_id' => $entityId]);

                $isExists=EntityDepartmentSetting::where(['department_id'=>$deparmentId,'entity_id'=>$entityId])->first();
                if($isExists)
                    $isUpdated=$isExists->update($request->except('_token'));
                else
                    $isCreated= EntityDepartmentSetting::create($request->except('_token'));
                DB::commit();
                return $this->responseJson(true, 200, 'Department Entity Setting submitted successfully.', [
                    'redirect_url' => route('admin.settings.department.entity', ['departmentUuid'=> $request->departmentUuid])
                ]);
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        //return view('admin.settings.site-settings.index');
        return view('admin.settings.site-settings.department-entity', compact('entities', 'department'));
    }
}
