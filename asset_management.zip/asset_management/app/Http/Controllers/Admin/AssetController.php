<?php

namespace App\Http\Controllers\Admin;

use App\Exports\Inventory\AssetDetailsExport;
use App\Exports\Inventory\AssetStockDetailsExport;
use App\Exports\Inventory\InventoryStockDetailsExport;
use App\Exports\Inventory\PhysicalVerificationExport;
use App\Exports\QuotationComparisionExport;
use App\Exports\QuotationComparisonExport;
use App\Exports\SubmissionExport;
use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Imports\AddAssetImport;
use App\Imports\AddAssetInventoryImport;
use App\Imports\AddAssetStockImport;
use App\Imports\AddAssetStockSheetSelection;
use App\Imports\AddLocationImport;
use App\Imports\BulkAssetAllocationImport;
use App\Imports\User\AddVendorImport;
use App\Mail\SendMailable;
use App\Models\Budget\Budget;
use App\Models\Budget\BudgetApproval;
use App\Models\Budget\BudgetItem;
use App\Models\Company\Location;
use App\Models\Inventory\Inventory;
use App\Models\Lease\LeaseAgreement;
use App\Models\Lease\LeaseItem;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\TermAndCondition;
use App\Models\Purchase\PoInvoiceApproval;
use App\Models\Purchase\PurchaseOrderApproval;
use App\Models\Purchase\PurchaseOrderInvoice;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Requisition\Quotation;
use App\Models\Requisition\QuotationItem;
use App\Models\Requisition\Requisition;
use App\Models\Requisition\RequisitionApproval;
use App\Models\Requisition\Rfq;
use App\Models\Requisition\RfqApproval;
use App\Models\Requisition\RfqVendor;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Ticket\Ticket;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Notifications\BudgetApproveNotification;
use App\Notifications\IssueFromLeaseNotification;
use App\Notifications\IssueNotification;
use App\Notifications\PoApproveNotification;
use App\Notifications\PoInvoiceApproveNotification;
use App\Notifications\ReminderNotification;
use App\Notifications\RequisitionApproveNotification;
use App\Notifications\RfqApproveNotification;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Services\Category\CategoryService;
use App\Services\Inventory\AssetStockService;
use App\Services\Inventory\InwardStockService;
use App\Services\Inventory\OutwardStockService;

use App\Services\Location\CityService;
use App\Services\Location\CountryService;
use App\Services\Location\StateService;
use App\Services\User\UserService;
use App\Services\User\VendorService;
use Barryvdh\DomPDF\PDF;
use Carbon\Carbon;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Http\Request;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Facades\Excel;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Shared\Html;
use PhpOffice\PhpWord\SimpleType\Jc;

class AssetController extends BaseController
{
    public function __construct(
        protected AssetService $assetService,
        protected AssetTypeService $assetTypeService,
        protected CategoryService $categoryService,
        protected UserService $userService,
        protected VendorService $vendorService,
        protected AssetStockService $assetStockService,
        protected InwardStockService $inwardStockService,
        protected OutwardStockService $outwardStockService,
        protected CountryService $countryService,
        protected StateService $stateService,
        protected CityService $cityService,

    ) {
        $this->assetTypeService = $assetTypeService;
        $this->assetService = $assetService;
        $this->categoryService = $categoryService;
        $this->userService = $userService;
        $this->vendorService = $vendorService;
        $this->assetStockService = $assetStockService;
        $this->inwardStockService = $inwardStockService;
        $this->outwardStockService = $outwardStockService;
        $this->countryService = $countryService;
        $this->stateService = $stateService;
        $this->cityService = $cityService;
    }
    #asset type#
    public function assettype(Request $request)
    {
        $this->setPageTitle('Asset Type');
        // $condition = array();
        // if ($request->entity != '') {
        //     $condition = [['entity_id', '=', uuidtoid($request->entity, 'categories')]];
        // }
        // if ($request->assetType != '') {
        //     $condition = [['name', 'LIKE', '%' . $request->assetType . '%']];
        // }
        // $assets = $this->assetTypeService->listAssets($condition, 'id', 'desc');
        // $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        return view('admin.asset.type.list');
    }

    public function assettypeAdd(Request $request)
    {
        $this->setPageTitle('Add Asset Type');
        $lastId = $this->assetTypeService->listAssets([], 'id', 'desc', 1)->pluck('id')->first();
        $typeId = 'ASTP' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        // $typeId = substr(sha1(mt_rand()), 17, 6);
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'type_id' => 'required',
                // 'entity' => 'required|exists:categories,id',
                'asset_name' => 'required|min:2|unique:asset_types,name,' . $request->uuid . ',uuid',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // $request->merge(['name' => $request->asset_name, 'entity_id' => $request->entity, 'type' => 'asset']);
                // $request->replace(array_merge($request->all(), ['entity' => $this->categoryService->findCategoryById($request->entity)?->name ?? '']));
                $request->merge(['name' => $request->asset_name, 'type' => 'asset']);
                $isCreated = $this->assetTypeService->addOrUpdate([
                    'uuid' => $request->uuid
                ], $request->except('_token', 'asset_name'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Asset Type Creation',
                    'task_description' => $request->asset_name . '(' . $request->type_id . ')',
                    'task_url' => 'masters/asset-type/list',
                    'added_by' => auth()->user()->id,
                    'type' => 'add-asset-type',
                    'related_id' => $isCreated->id
                ]);

                if ($isCreated) {
                    DB::commit();
                    $msg = $isCreated->wasRecentlyCreated ? 'Asset Type created' : 'Asset Type updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.assettype.attributes', $isCreated->uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        // $typeCategories = $this->categoryService->listCategories(['is_active'=> 1, 'type'=> 'asset_type']);
        $typeCategories = $this->getAssetCategoryTree();

        // $assetTypes = $this->assetTypeService->listAssets([], 'id', 'desc');
        $assetTypes = $this->getAssetTypesTree([], null, null, true);
        // dd($assetTypes);
        return view('admin.asset.type.add', compact('typeId', 'typeCategories', 'assetTypes'));
    }
    protected function getAssetCategoryTree($categories = array(), $parent_id = null, $isParentSelectable = false, $excludes = array())
    {
        $typeCats = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'asset_type', 'parent_id' => $parent_id]);
        $subCategories = [];
        $cats = [];
        if ($typeCats->count()) {
            foreach ($typeCats as $k => $category) {
                if (!$excludes || ($excludes && !in_array($category->name, $excludes))) {
                    $cats[$k]['id'] = $category->id;
                    $cats[$k]['title'] = $category->name;
                    $subCategories = $this->getAssetCategoryTree($categories, $category->id, $isParentSelectable, $excludes);
                    if ($subCategories) {
                        $cats[$k]['isSelectable'] = $isParentSelectable;
                        $cats[$k]['subs'] = $subCategories;
                    }
                }
            }
            $categories = array_merge($categories, $cats);
        }
        return $categories;
    }
    protected function getAssetTypesTree($assetTypes = array(), $parent_id = null, $category_id = null, $isParentSelectable = false)
    {
        $args = ['parent_id' => $parent_id];
        if ($category_id) {
            $args['category_id'] = $category_id;
        }

        $astTypes = $this->assetTypeService->listAssets($args, 'id', 'asc');

        // dd($astTypes);
        $subTypes = [];
        $types = [];
        if ($astTypes->count()) {
            foreach ($astTypes as $k => $type) {
                $types[$k]['id'] = $type->id;
                $types[$k]['title'] = $type->name;
                if ($category_id) {
                    $subTypes = $this->getAssetTypesTree($assetTypes, $type->id, $category_id, $isParentSelectable);
                } else {
                    $subTypes = $this->getAssetTypesTree($assetTypes, $type->id, null, $isParentSelectable);
                }
                if ($subTypes) {
                    $types[$k]['isSelectable'] = $isParentSelectable;
                    $types[$k]['subs'] = $subTypes;
                }
            }
            $assetTypes = array_merge($assetTypes, $types);
        }
        return $assetTypes;
    }
    private function listAssetsTypes($category_id)
    {
        // $allAssets = array_replace($assets, $assetType->assets->pluck('asset_name', 'id')->toArray());
        // if ($assetType->children()->get()) {
        //     foreach ($assetType->children()->get() as $subAssetType) {
        //         $allAssets = $this->assetLists($subAssetType, $allAssets);
        //     }
        // }
        // return $allAssets;
    }
    public function assettypeEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Type Edit');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                // 'entity' => 'required|exists:categories,id',
                'asset_name' => 'required|min:2|unique:asset_types,name,' . $uuid . ',uuid',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // $request->merge(['name' => $request->asset_name, 'entity_id' => $request->entity]);
                // $request->replace(array_merge($request->all(), ['entity' => $this->categoryService->findCategoryById($request->entity)?->name ?? '']));
                $request->merge(['name' => $request->asset_name]);
                $isUpdateed = $this->assetTypeService->updateTable([
                    'uuid' => $uuid
                ], $request->except('_token', 'asset_name'));
                if ($isUpdateed) {
                    DB::commit();
                    $msg = 'Asset Type Updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.assettype.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assettype = $this->assetTypeService->findById(uuidtoid($uuid, 'asset_types'));
        // $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        // $typeCategories = $this->categoryService->listCategories(['is_active'=> 1, 'type'=> 'asset_type']);
        $typeCategories = $this->getAssetCategoryTree();
        // $assetTypes = $this->assetTypeService->listAssets([], 'id', 'desc');
        $assetTypes = $this->getAssetTypesTree([], null, null, true);
        return view('admin.asset.type.edit', compact('assettype', 'typeCategories', 'assetTypes'));
    }

    #asset type category#
    public function assetTypeCategory(Request $request)
    {
        $this->setPageTitle('Asset Type Category');
        return view('admin.asset.type.category.list');
    }
    public function assetTypeCategoryAdd(Request $request)
    {
        $this->setPageTitle('Add Asset Type Category');
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|min:2',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['type' => 'asset_type']);
                //dd($request->all());
                $isCategoryCreated = $this->categoryService->createOrUpdateCategory($request->except('_token'));
                if ($isCategoryCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Asset Type Category Successfully Created.', [
                        'redirect_url' => route('admin.assettype.category.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $typeCategories = $this->categoryService->listCategories(['is_active'=> 1, 'type'=> 'asset_type']);
        $typeCategories = $this->getAssetCategoryTree([], null, true);
        return view('admin.asset.type.category.add', compact('typeCategories'));
    }
    public function assetTypeCategoryEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Asset Type Category');
        $categoryId = uuidtoid($uuid, 'categories');
        $categoryData = $this->categoryService->findCategoryById($categoryId);
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|min:2',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $iscategoryUpdated = $this->categoryService->createOrUpdateCategory($request->except('_token'), $categoryId);
                if ($iscategoryUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Asset Type Category Successfully Updated.', [
                        'redirect_url' => route('admin.assettype.category.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $typeCategories = $this->categoryService->listCategories(['is_active'=> 1, 'type'=> 'asset_type']);
        $typeCategories = $this->getAssetCategoryTree([], null, true);
        return view('admin.asset.type.category.edit', compact('categoryData', 'typeCategories'));
    }

    public function bulkupload(Request $request)
    {
        if ($request->ajax()) {
            if ($request->hasFile('upload_asset')) {
                // $filename = storage_path('/app/data.csv');
                // $file = fopen($filename, "r");
                // $all_data = array();
                // while ( ($data = fgetcsv($file, 200, ",")) !==FALSE) {
                //     array_push($all_data, $data);
                // };
            }
        }
    }

    #asset#
    public function asset(Request $request, $type = null)
    {
        $this->setPageTitle('Asset');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        //$vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $assetCategories = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'asset_type']);
        $typeCategories = $this->getAssetCategoryTree();
        // array_unshift($typeCategories , ['id' => 0, 'title' => 'All']);

        return view('admin.asset.list', compact('entities', 'assetCategories', 'assetTypes', 'type', 'typeCategories'));
    }
    public function assetAdd(Request $request)
    {
        $this->setPageTitle('Asset Add');
        $condition = [['is_active', '=', '1']];
        if ($request->ajax()) {
            // $validator = Validator::make($request->all(), [
            //     'category_id' => 'required|exists:categories,id',
            //     'asset_type_id' => 'required|exists:asset_types,id',
            //     'asset_id' => 'required|min:2|unique:assets,asset_id,' . $request->uuid . ',uuid',
            //     'asset_name' => 'required|min:2|unique:assets,asset_name,' . $request->uuid . ',uuid',
            //    'category_id' => 'required|exists:categories,id',
            //     'purchase_date' => 'required|date_format:Y-m-d',
            //     'expiry_date' => 'nullable|date_format:Y-m-d|after:purchase_date',
            //     'vendor_name' => 'nullable|exists:vendors,id',
            //     'price' => 'required|numeric|gt:0',
            //     'assetimage' => 'nullable|sometimes|image|mimes:png,jpg,jpeg,gif,svg,webp'
            // ]);
            $rules = [
                'category_id' => 'required|exists:categories,id',
                'asset_type_id' => 'required|exists:asset_types,id',
                'asset_name' => 'required|min:2|unique:assets,asset_name,',

            ];
            $messages = [
                'category_id' => 'Asset Category field is required.',
                'asset_type_id' => 'Asset Type field is required.',
            ];

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                #file upload#
                if ($request->hasFile('assetimage')) {
                    $image = uniqid() . "." . $request->file('assetimage')->getClientOriginalExtension();
                    $request->file('assetimage')->move(public_path('storage/asset_image'), $image);
                }
                $request->merge(['slug' => str()->slug($request->asset_name), 'asset_image' => $image ?? 'noimg.png']);

                $isCreated = $this->assetService->addOrUpdate([
                    'uuid' => $request->uuid
                ], $request->except('_token', 'asset_type', 'assetimage'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Asset Creation',
                    'task_description' => $request->asset_name . '(' . $request->asset_id . ')',
                    'task_url' => 'masters/asset/list',
                    'added_by' => auth()->user()->id,
                    'type' => 'add-asset',
                    'related_id' => $isCreated->id
                ]);

                if ($isCreated) {
                    DB::commit();
                    $msg = $isCreated->wasRecentlyCreated ? 'Asset created' : 'Asset Updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.asset.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $asset = $this->assetService->listAssets([], 'id', 'desc', 1)->first();
        // $assetid = $asset?->assetid;
        // $assetid = substr(sha1(mt_rand()), 17, 6);
        $lastId = $this->assetService->findAssets([], 'id', 'desc', 1, 0, false)->pluck('id')->first();
        $assetid = 'ASST' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        $assettypes = $this->assetTypeService->listAssets($condition, 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        $typeCategories = $this->getAssetCategoryTree();
        // dd($typeCategories);
        return view('admin.asset.add', compact('assettypes', 'assetid', 'vendors', 'typeCategories'));
    }
    public function assetEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Edit');
        $asset = $this->assetService->findById(uuidtoid($uuid, 'assets'));
        if ($request->ajax()) {
            $rules = [
                'category_id' => 'required|exists:categories,id',
                'asset_type_id' => 'required|exists:asset_types,id',
                'asset_name' => 'required|min:2|unique:assets,asset_name,' . $request->uuid . ',uuid',
                'assetimage' => 'nullable|sometimes|image|mimes:png,jpg,jpeg,gif,svg,webp'
            ];
            $messages = [
                'category_id' => 'Asset Category field is required.',
                'asset_type_id' => 'Asset Type field is required.',
            ];

            $validator = Validator::make($request->all(), $rules, $messages);

            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $image = $asset->asset_image;
                #file upload#
                if ($request->hasFile('assetimage')) {
                    $image = uniqid() . "." . $request->file('assetimage')->getClientOriginalExtension();
                    $request->file('assetimage')->move(public_path('storage/asset_image'), $image);
                }
                $request->merge(['slug' => str()->slug($request->asset_name), 'asset_image' => $image ?? 'noimg.png']);
                $isUpdated = $this->assetService->updateTable([
                    'uuid' => $uuid
                ], $request->except('_token', 'asset_type', 'assetimage'));
                if ($isUpdated) {
                    DB::commit();
                    $msg = 'Asset Updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.asset.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $typeCategories = $this->getAssetCategoryTree();
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);

        $assettypes = $this->getAssetTypesTree([], null, $asset->category_id);

        $assetCategory = $this->categoryService->findCategoryById($asset->category_id);
        $assetTypes = $this->getAssetTypesTree([], null, $asset->category_id);
        if (!$assetTypes && $assetCategory->children()->count()) {
            foreach ($assetCategory->children()->get() as $assetCategorySub) {
                $assetTypes = array_merge($assetTypes, $this->getAssetTypesTree([], null, $assetCategorySub->id));
            }
        }

        // $assettypes = $this->getAssetTypesTree([],null,null);

        // dd($assetTypes);

        return view('admin.asset.edit', compact('asset', 'assetTypes', 'vendors', 'typeCategories'));
    }

    #assetstock#
    public function assetstock($uuid = null)
    {
        $this->setPageTitle('Asset Stock');
        $asset = $this->assetService->findById(uuidtoid($uuid, 'assets'));
        //$assetCategories = $this->getAssetCategoryTree();
        // $assetCategories = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'asset_type']);
        // $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.list', compact('asset', 'locations', 'uuid', 'entities'));
    }
    public function assetstockAdd(Request $request)
    {
        $this->setPageTitle('Stock Add');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'unit' => 'required',
                'opening_stock' => 'required|numeric',
                'inward_qty' => 'required|numeric|gt:0',
                'outward_qty' => 'required|numeric|gt:0',
                'lost' => 'required|numeric',
                'balance_stock' => 'required|numeric',
                'reorder_level' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset]);
                $isCreated = $this->assetStockService->create($request->except('_token', 'asset'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Stock Created Successfully.', [
                        'redirect_url' => route('admin.assetstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        return view('admin.asset.stock.add', compact('assets', 'vendors'));
    }
    public function assetstockEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Stock Edit');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'unit' => 'required',
                'opening_stock' => 'required|numeric',
                'inward_qty' => 'required|numeric|gt:0',
                'outward_qty' => 'required|numeric|gt:0',
                'lost' => 'required|numeric',
                'balance_stock' => 'required|numeric',
                'reorder_level' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset]);
                $isCreated = $this->assetStockService->updateTable(['id' => uuidtoid($uuid, 'asset_stocks')], $request->except('_token', 'asset'),);
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Stock Updated.', [
                        'redirect_url' => route('admin.assetstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $stock = $this->assetStockService->findById(uuidtoid($uuid, 'asset_stocks'));
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        return view('admin.asset.stock.edit', compact('assets', 'vendors', 'stock'));
    }
    public function assetstockInventorybk(Request $request, $uuid)
    {
        $this->setPageTitle('Stock Inventory');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        if ($request->ajax()) {
            $rules = [
                // 'user_id' => 'required|exists:users,id',
                // 'issued_date' => 'required|date',
            ];
            $messages = [
                // 'user_id' => 'Please select an employee to issue',
                // 'issued_date' => 'Please select Issued Date'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $acceptance_otp = rand(1000, 9999);
                $request->merge(['asset_id' => $request->asset_id, 'asset_stock_id' => $asset_stock_id, 'acceptance_otp' => $acceptance_otp]);
                $msg = $request->issue_uuid ? 'This Item has been re-issued' : "This Item has been issued";
                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));
                if ($isIssued) {
                    if (is_null($request->issue_uuid)) {
                        $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], $request->quantity, 'decrease');
                        if ($isUpdated) {
                            $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id];
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                            $logData = [
                                'asset_stock_id' => $assetStockData->id,
                                'asset_id' => $request->asset_id,
                                'location_id' => $request->location_id,
                                'entity_id' => $request->entity_id,
                                'type' => 'substruct',
                                'quantity' => $request->quantity
                            ];
                            $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                        }
                    }
                    $asset = $this->assetService->findById($request->asset_id);
                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                        ['id' => null],
                        [
                            'task_name' => 'An Asset has been Issued',
                            'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-issue',
                            'related_id' => $isIssued->id,
                            'inventory_id' => $request->inventory_id ?? null
                        ]
                    );

                    $userData = $this->userService->findUserById($request->user_id);
                    $userDept = $userData->profile?->department?->name ?? 'N/A';
                    if ($request->inventory_id) {
                        $inventoryData = $this->assetService->findInventoryById($request->inventory_id);
                        $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                    } else {
                        $notificationContent = $asset->asset_name . '(' . $asset->asset_id . ') with quantity ' . $request->quantity . ' has been allocated to you.';
                    }

                    $notiData = [
                        'form_name' => $notificationContent,
                        'issue_uuid' => $isIssued->uuid,
                    ];
                    $userData->notify(new IssueNotification($notiData));
                    $mailData = [
                        'to' => $userData->email,
                        'from' => env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => "We are pleased to inform you that a new system has been allocated to you. Below are the details of the allocated system:<br><br><br>System Details:",
                        //'content' => 'Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                        'content' => 'System Type: #' . $asset_stock->assettype?->name . '<br>Brand/Model: ' . $asset_stock->asset?->asset_name  . '<br>Serial Number: ' . $inventoryData->unique_id . '<br>Asset Tag Number: ' . $inventoryData->identification_no . '<br>Capacity/specification: ' . strip_tags($inventoryData->capacity_specs) . '<br>Allocation Date: ' . $request->issued_date . '<br>Allocated By: ' . $userData->full_name . '-' . $userDept . '<br>Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                        'subject' => 'New System Allocated to You',
                        'greetings' => 'Dear ' . $userData->full_name . ',',
                        'end_greetings' => 'Best Regards,<br>DHC',
                        'from_user' => env('MAIL_FROM_NAME')
                    ];
                    Mail::send(new SendMailable($mailData));
                }
                DB::commit();
                return $this->responseJson(true, 200, $msg, [
                    'redirect_url' => route('admin.assetstock.inventory', [$uuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $entityId = $asset_stock->entity_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.inventory', compact('uuid', 'asset_stock', 'employees', 'locationId', 'entityId', 'assetIssues', 'locations', 'entities', 'leaseUuid'));
    }




    public function assetstockInventorybk1(Request $request, $uuid, $leaseUuid = null)
    {

        $this->setPageTitle('Stock Inventory');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);

        if ($leaseUuid != null)
            $leasedAgreement = $this->assetStockService->findLeaseAgreementById(uuidtoid($leaseUuid, 'lease_agreements'));

        if ($request->ajax()) {
            $rules = [
                // 'user_id' => 'required|exists:users,id',
                // 'issued_date' => 'required|date',
            ];
            $messages = [
                // 'user_id' => 'Please select an employee to issue',
                // 'issued_date' => 'Please select Issued Date'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                // dd($request->all());
                $acceptance_otp = rand(1000, 9999);
                $request->merge(['asset_id' => $request->asset_id, 'asset_stock_id' => $asset_stock_id, 'acceptance_otp' => $acceptance_otp]);
                $msg = $request->issue_uuid ? 'This Item has been re-issued' : "This Item has been issued";
                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));



                if ($isIssued) {
                    if (is_null($request->issue_uuid)) {
                        $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], $request->quantity, 'decrease');
                        if ($isUpdated) {
                            $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id];
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                            $logData = [
                                'asset_stock_id' => $assetStockData->id,
                                'asset_id' => $request->asset_id,
                                'location_id' => $request->location_id,
                                'entity_id' => $request->entity_id,
                                'type' => 'substruct',
                                'quantity' => $request->quantity
                            ];
                            $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                        }
                    }
                    $asset = $this->assetService->findById($request->asset_id);
                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                        ['id' => null],
                        [
                            'task_name' => 'An Asset has been Issued',
                            'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-issue',
                            'related_id' => $isIssued->id,
                            'inventory_id' => $request->inventory_id ?? null
                        ]
                    );

                    $userData = $this->userService->findUserById($request->user_id);
                    $userDept = $userData->profile?->department?->name ?? 'N/A';
                    if ($request->inventory_id) {
                        $inventoryData = $this->assetService->findInventoryById($request->inventory_id);
                        $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                    } else {
                        $notificationContent = $asset->asset_name . '(' . $asset->asset_id . ') with quantity ' . $request->quantity . ' has been allocated to you.';
                    }

                    $notiData = [
                        'form_name' => $notificationContent,
                        'issue_uuid' => $isIssued->uuid,
                    ];
                    $userData->notify(new IssueNotification($notiData));
                    $mailData = [
                        'to' => $userData->email,
                        'from' => env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => "We are pleased to inform you that a new system has been allocated to you. Below are the details of the allocated system:<br><br><br>System Details:",
                        'content' => 'System Type: #' . $asset_stock->assettype?->name . '<br>Brand/Model: ' . $asset_stock->asset?->asset_name  . '<br>Serial Number: ' . $inventoryData->unique_id . '<br>Asset Tag Number: ' . $inventoryData->identification_no . '<br>Capacity/specification: ' . strip_tags($inventoryData->capacity_specs) . '<br>Allocation Date: ' . $request->issued_date . '<br>Allocated By: ' . $userData->full_name . '-' . $userDept . '<br>Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                        'subject' => 'New System Allocated to You',
                        'greetings' => 'Dear ' . $userData->full_name . ',',
                        'end_greetings' => 'Best Regards,<br>DHC',
                        'from_user' => env('MAIL_FROM_NAME')
                    ];
                    Mail::send(new SendMailable($mailData));
                }
                DB::commit();
                return $this->responseJson(true, 200, $msg, [
                    'redirect_url' => route('admin.assetstock.inventory', [$uuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $entityId = $asset_stock->entity_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.inventory', compact('uuid', 'asset_stock', 'employees', 'locationId', 'entityId', 'assetIssues', 'locations', 'entities', 'leaseUuid'));
    }


    public function assetstockInventory_bk(Request $request, $uuid, $leaseUuid = null)
    {

        $this->setPageTitle('Stock Inventory');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);

        if ($leaseUuid != null)
            $leasedAgreement = $this->assetStockService->findLeaseAgreementById(uuidtoid($leaseUuid, 'lease_agreements'));

        if ($request->ajax()) {
            // $rules = [

            // ];
            // $messages = [

            // ];
            // $validator = Validator::make($request->all(), $rules, $messages);
            // if ($validator->fails()) {
            //     return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            // }
            DB::beginTransaction();
            try {

                // dd($request->all());
                // if($request->hiddenAssetUuid && $request->inventoryUuid){





                $acceptance_otp = rand(1000, 9999);
                $request->merge(['asset_id' => $request->asset_id, 'asset_stock_id' => $asset_stock_id, 'acceptance_otp' => $acceptance_otp]);
                $msg = $request->issue_uuid ? 'This Item has been re-issued' : "This Item has been issued";
                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));


                if ($isIssued) {
                    if (is_null($request->issue_uuid)) {
                        $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], $request->quantity, 'decrease');

                        if ($isUpdated) {
                            $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id];
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);

                            $logData = [
                                'asset_stock_id' => $assetStockData->id,
                                'asset_id' => $request->asset_id,
                                'location_id' => $request->location_id,
                                'entity_id' => $request->entity_id,
                                'type' => 'substruct',
                                'quantity' => $request->quantity
                            ];
                            $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                        }
                    }
                    $asset = $this->assetService->findById($request->asset_id);
                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                        ['id' => null],
                        [
                            'task_name' => 'An Asset has been Issued',
                            'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-issue',
                            'related_id' => $isIssued->id,
                            'inventory_id' => $request->inventory_id ?? null
                        ]
                    );


                    $userData = $this->userService->findUserById($request->user_id);
                    if ($request->inventory_id) {
                        $inventoryData = $this->assetService->findInventoryById($request->inventory_id);
                        $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                    } else {
                        $notificationContent = $asset->asset_name . '(' . $asset->asset_id . ') with quantity ' . $request->quantity . ' has been allocated to you.';
                    }

                    $notiData = [
                        'form_name' => $notificationContent,
                        'issue_uuid' => $isIssued->uuid,
                    ];
                    $userData->notify(new IssueNotification($notiData));
                    $mailData = [
                        'to' => $userData->email,
                        'from' => env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => $notificationContent,
                        'content' => 'Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                        'subject' => 'Allocation Of Asset',
                        'greetings' => 'Hello Sir/Madam',
                        'end_greetings' => 'Regards,',
                        'from_user' => env('MAIL_FROM_NAME')
                    ];
                    Mail::send(new SendMailable($mailData));
                }

                // }





                if ($request->lease_item_uuid) {
                    // Lease Submission code
                    $itemData = [
                        'user_id' => $request->user_id ? $request->user_id : null,
                        'leased_date' => $request->leased_date ? Carbon::createFromFormat('m/d/Y', $request->leased_date)->format('Y-m-d') : null,
                        'comments' => $request->comments ? $request->comments : null,
                        'document' => $request->document ? $request->document : null,
                    ];
                    $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => $request->lease_item_uuid], $itemData);
                    $findLeaseItem = $this->assetStockService->findLeasedItemById(uuidtoid($request->lease_item_uuid, 'lease_items'));
                    if ($leaseUuid != null)
                        $asset = $this->assetService->findById($leasedAgreement->asset_id);


                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                        ['id' => null],
                        [
                            'task_name' => 'An Asset has been Allocated',
                            'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-issue',
                            'related_id' => $isLeaseItems->id,
                            'inventory_id' => $findLeaseItem->inventory_id ?? null
                        ]
                    );
                }




                DB::commit();
                return $this->responseJson(true, 200, "Item has been allocated", [
                    'redirect_url' => route('admin.assetstock.inventory', [$uuid, 'leaseUuid' => $request->lease_uuid])
                ]);


                // return $this->responseJson(true, 200, "Item has been allocated", [
                //     'redirect_url' => route('admin.assetstock.inventory', ['uuid'=>$uuid,'leaseUuid'=>$request->lease_uuid])
                // ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $entityId = $asset_stock->entity_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.inventory', compact('uuid', 'asset_stock', 'employees', 'locationId', 'entityId', 'assetIssues', 'locations', 'entities', 'leaseUuid'));
    }





    public function assetstockInventory(Request $request, $uuid, $leaseUuid = null)
    {

        $this->setPageTitle('Stock Inventory');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);

        if ($leaseUuid != null)
            $leasedAgreement = $this->assetStockService->findLeaseAgreementById(uuidtoid($leaseUuid, 'lease_agreements'));

        if ($request->ajax()) {
            // $rules = [

            // ];
            // $messages = [

            // ];
            // $validator = Validator::make($request->all(), $rules, $messages);
            // if ($validator->fails()) {
            //     return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            // }
            DB::beginTransaction();
            try {

                $userData = $this->userService->findUserById($request->user_id);

                if ($request->lease_item_uuid) {
                    // Lease Submission code
                    $itemData = [
                        'user_id' => $request->user_id ? $request->user_id : null,
                        'leased_date' => $request->leased_date ? Carbon::createFromFormat('m/d/Y', $request->leased_date)->format('Y-m-d') : null,
                        'comments' => $request->comments ? $request->comments : null,
                        'document' => $request->document ? $request->document : null,
                    ];
                    $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => $request->lease_item_uuid], $itemData);
                    $findLeaseItem = $this->assetStockService->findLeasedItemById(uuidtoid($request->lease_item_uuid, 'lease_items'));
                    $leasedAgreement = $this->assetStockService->findLeaseAgreementById($findLeaseItem->lease_id);




                    if ($leaseUuid != null)
                        $asset = $this->assetService->findById($leasedAgreement->asset_id);


                    $findInventory=$this->assetStockService->getInventoryById($findLeaseItem->inventory_id);
                    // inserting data also asset issue table
                    $acceptance_otp = rand(1000, 9999);
                    $request->merge(['asset_id' => $asset->id, 'asset_stock_id' => $leasedAgreement->asset_stock_id,'inventory_id'=>$findInventory->id, 'location_id'=>$leasedAgreement->location_id, 'user_id'=>$request->user_id,'expiry'=>$findInventory->warranty_licence_date,'quantity'=>null,'issued_date'=>$request->leased_date, 'acceptance_otp' => $acceptance_otp]);
                    $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));

                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                        ['id' => null],
                        [
                            'task_name' => 'An Asset has been Allocated',
                            'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-issue',
                            'related_id' => $isLeaseItems->id,
                            'inventory_id' => $findLeaseItem->inventory_id ?? null
                        ]
                    );
                    // $userData = $this->userService->findUserById($request->user_id);
                    if ($findLeaseItem->inventory_id !=null) {
                        $inventoryData = $this->assetService->findInventoryById($findLeaseItem->inventory_id);
                        $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                    }



                } else {
                    $acceptance_otp = rand(1000, 9999);
                    $request->merge(['asset_id' => $request->asset_id, 'asset_stock_id' => $asset_stock_id, 'acceptance_otp' => $acceptance_otp]);
                    $msg = $request->issue_uuid ? 'This Item has been re-issued' : "This Item has been issued";

                    // dd($request->all());
                    $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));

                    if ($isIssued) {
                        if (is_null($request->issue_uuid)) {
                            $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], $request->quantity, 'decrease');

                            if ($isUpdated) {
                                $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id];
                                $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);

                                $logData = [
                                    'asset_stock_id' => $assetStockData->id,
                                    'asset_id' => $request->asset_id,
                                    'location_id' => $request->location_id,
                                    'entity_id' => $request->entity_id,
                                    'type' => 'substruct',
                                    'quantity' => $request->quantity
                                ];
                                $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                            }
                        }
                        $asset = $this->assetService->findById($request->asset_id);
                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                            ['id' => null],
                            [
                                'task_name' => 'An Asset has been Issued',
                                'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                                'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                                'added_by' => auth()->user()->id,
                                'type' => 'add-issue',
                                'related_id' => $isIssued->id,
                                'inventory_id' => $request->inventory_id ?? null
                            ]
                        );
                        if ($request->inventory_id) {
                            $inventoryData = $this->assetService->findInventoryById($request->inventory_id);
                            $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                        } else {
                            $notificationContent = $asset->asset_name . '(' . $asset->asset_id . ') with quantity ' . $request->quantity . ' has been allocated to you.';
                        }
                    }
                }

                $notiData = [
                    'form_name' => $notificationContent,
                    'issue_uuid' => $isIssued->uuid,
                ];
                $userData->notify(new IssueNotification($notiData));
                $mailData = [
                    'to' => $userData->email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => $notificationContent,
                    'content' => 'Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                    'subject' => 'Allocation Of Asset',
                    'greetings' => 'Hello Sir/Madam',
                    'end_greetings' => 'Regards,',
                    'from_user' => env('MAIL_FROM_NAME')
                ];
                // dd($userData->email,$mailData);
                Mail::send(new SendMailable($mailData));

                DB::commit();
                return $this->responseJson(true, 200, "Item has been allocated", [
                    'redirect_url' => route('admin.assetstock.inventory', [$uuid, 'leaseUuid' => $request->lease_uuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $entityId = $asset_stock->entity_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.inventory', compact('uuid', 'asset_stock', 'employees', 'locationId', 'entityId', 'assetIssues', 'locations', 'entities', 'leaseUuid'));
    }









    #inward stock#
    public function inwardstock(Request $request, $asset_uuid = null)
    {
        $this->setPageTitle('Inward Stock');
        return view('admin.asset.inwardstock.list', compact('asset_uuid'));
    }
    public function inwardstockAdd(Request $request)
    {
        $this->setPageTitle('Inward Stock Add');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'vendor' => 'required|exists:vendors,id',
                'vendor_invoice' => 'required|unique:inward_stocks,vendor_invoice',
                'unit' => 'required',
                'date' => 'required|date',
                'qty' => 'required|numeric',
                'requisition_person' => 'required|exists:users,id',
                'requisition_department' => 'required',
                'ordering_by' => 'required|exists:users,id',
                'approved_by' => 'required|exists:users,id',
                'qty_rejected_by' => 'nullable|exists:users,id',
                'rejection_reason' => 'nullable'
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset, 'vendor_id' => $request->vendor]);
                $isCreated = $this->inwardStockService->create($request->except('_token', 'asset', 'vendor'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Inward Stock Created.', [
                        'redirect_url' => route('admin.inwardstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        $users = $this->userService->getAllUsers([], 'employee');
        return view('admin.asset.inwardstock.add', compact('assets', 'vendors', 'users'));
    }
    public function inwardstockEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Inward Stock Edit');
        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'inward_stocks');
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'vendor' => 'required|exists:vendors,id',
                'vendor_invoice' => 'required|unique:inward_stocks,vendor_invoice,' . $id,
                'unit' => 'required',
                'date' => 'required|date',
                'qty' => 'required|numeric',
                'requisition_person' => 'required|exists:users,id',
                'requisition_department' => 'required',
                'ordering_by' => 'required|exists:users,id',
                'approved_by' => 'required|exists:users,id',
                'qty_rejected_by' => 'nullable|exists:users,id',
                'rejection_reason' => 'nullable'
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset, 'vendor_id' => $request->vendor]);
                $isCreated = $this->inwardStockService->updateTable(['id' => $id], $request->except('_token', 'asset', 'vendor'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Inward Stock Updated.', [
                        'redirect_url' => route('admin.inwardstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        $users = $this->userService->getAllUsers([], 'employee');
        $inward = $this->inwardStockService->findById(uuidtoid($uuid, 'inward_stocks'));
        return view('admin.asset.inwardstock.edit', compact('assets', 'vendors', 'users', 'inward'));
    }

    #outward stock#
    public function outwardstock(Request $request, $asset_uuid = null)
    {
        $this->setPageTitle('Outward Stock');
        return view('admin.asset.outwardstock.list', compact('asset_uuid'));
    }
    public function outwardstockAdd(Request $request)
    {
        $this->setPageTitle('Outward Stock Add');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'vendor' => 'required|exists:vendors,id',
                'unit' => 'required',
                'date' => 'required|date',
                'qty' => 'required|numeric',
                'issuing_by' => 'required|exists:users,id',
                'receiving_department' => 'nullable',
                'receiving_by' => 'required|exists:users,id',
                'qty_issued' => 'required|numeric',
                'qty_rejected' => 'required|numeric',
                'rejection_reason' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset, 'vendor_id' => $request->vendor]);
                $isCreated = $this->outwardStockService->create($request->except('_token', 'asset', 'vendor'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Outward Stock Created.', [
                        'redirect_url' => route('admin.outwardstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        $users = $this->userService->getAllUsers([], 'employee');
        return view('admin.asset.outwardstock.add', compact('assets', 'vendors', 'users'));
    }
    public function outwardstockEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Outward Stock Edit');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'asset' => 'required|exists:assets,id',
                'vendor' => 'required|exists:vendors,id',
                'unit' => 'required',
                'date' => 'required|date',
                'qty' => 'required|numeric',
                'issuing_by' => 'required|exists:users,id',
                'receiving_department' => 'nullable',
                'receiving_by' => 'required|exists:users,id',
                'qty_issued' => 'required|numeric',
                'qty_rejected' => 'required|numeric',
                'rejection_reason' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['asset_id' => $request->asset, 'vendor_id' => $request->vendor]);
                $isCreated = $this->outwardStockService->updateTable(['id' => uuidtoid($uuid, 'outward_stocks')], $request->except('_token', 'asset', 'vendor'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Outward Stock Updated.', [
                        'redirect_url' => route('admin.outwardstock.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assets = $this->assetService->listAssets([], 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');
        $users = $this->userService->getAllUsers([], 'employee');
        $outward = $this->outwardStockService->findById(uuidtoid($uuid, 'outward_stocks'));
        return view('admin.asset.outwardstock.edit', compact('assets', 'vendors', 'users', 'outward'));
    }
    public function listRequisition()
    {
        $this->setPageTitle('Requisition List');
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();
        return view('admin.requisition.index', compact('entities', 'departments', 'employees'));
    }
    public function addRequisition(Request $request)
    {
        $this->setPageTitle('Add Requisition');
        if ($request->ajax()) {
            $rules = [
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'created_by' => 'required|exists:users,id',
                'category_id' => 'required|exists:categories,id',
                'priority' => 'required'
            ];
            $messages = [
                'entity_id' => 'Entity field is required.',
                'department_id' => 'Department field is required.',
                'created_by' => 'Created by field is required.',
                'category_id' => 'Asset Category field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);

            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['added_by' => auth()->user()->id]);
                $isCreated = $this->assetService->addOrUpdateRequisition(['uuid' => $request->uuid], $request->except('_token'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Requisition Creation',
                    'task_description' => $isCreated->unique_id,
                    'task_url' => 'modules/requisition/view/' . $isCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-requisition',
                    'related_id' => $isCreated->id
                ]);

                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Requisition created.', [
                        'redirect_url' => route('admin.requisition.item.list', $isCreated->uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();
        $typeCategories = $this->getAssetCategoryTree();

        return view('admin.requisition.add', compact('entities', 'departments', 'employees', 'typeCategories'));
    }
    public function editRequisition(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Requisition');
        $requisition = $this->assetService->findRequisitionById(uuidtoid($uuid, 'requisitions'));
        if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $requisition->created_by) && ($requisition->status != '1' || ($requisition->status == '1' && auth()->user()->hasRole('super-admin')))) {
            if ($request->ajax()) {
                $rules = [
                    'entity_id' => 'required|exists:categories,id',
                    'department_id' => 'required|exists:departments,id',
                    'created_by' => 'required|exists:users,id',
                    'category_id' => 'required|exists:categories,id',
                    'priority' => 'required'
                ];
                $messages = [
                    'entity_id' => 'Entity field is required.',
                    'department_id' => 'Department field is required.',
                    'created_by' => 'Created by field is required.',
                    'category_id' => 'Asset Category field is required.',

                ];
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                }
                DB::beginTransaction();
                try {
                    if ($requisition->status == '2') {
                        $this->assetService->createRequisitionVersion($requisition);
                        $request->merge(['status' => null]);
                    }
                    //dd($request->all());
                    $isUpdated = $this->assetService->addOrUpdateRequisition(['uuid' => $uuid], $request->except('_token'));
                    if ($isUpdated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'Requisition updated.', [
                            'redirect_url' => route('admin.requisition.view', $uuid)
                        ]);
                    }
                } catch (\Throwable $e) {
                    DB::rollBack();
                    logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                    return $this->responseJson(false, 500, $e->getMessage(), '');
                }
            }
            $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
            $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
            $employees = $this->userService->getEmployees();
            $assetTypes = $this->getAssetTypesTree();
            $reqid = $request->uuid ? uuidtoid($uuid, 'requisitions') : null;
            $limit = 9999;
            $start = 0;
            $order = 'id';
            $dir = 'desc';
            $index = $start;
            $requisitionItems = $this->assetService->findRequisitionItems(['requisition_id' => $reqid], $order, $dir, $limit, $index, false);
            $typeCategories = $this->getAssetCategoryTree();
            return view('admin.requisition.edit', compact('entities', 'departments', 'employees', 'requisition', 'uuid', 'assetTypes', 'requisitionItems', 'typeCategories'));
        } else {
            abort(401);
        }
    }

    public function viewRequisition(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('View Requisition');
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();
        $requisition = $this->assetService->findRequisitionById(uuidtoid($uuid, 'requisitions'));
        $assetTypes = $this->getAssetTypesTree();
        $requisitionid = $request->uuid ? uuidtoid($uuid, 'requisitions') : null;
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;

        // $lastApproval = RequisitionApproval::where(['requisition_id' => $requisitionid])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();

        // switch ($requisition->status) {
        //     case '0':
        //         $statClass = 'text_pending';
        //         $status = 'Pending';
        //         break;
        //     case '1':
        //         $statClass = 'text_green';
        //         $status = 'Approved';
        //         break;
        //     case '2':
        //         $statClass = 'text_danger';
        //         $status = 'Rejected';
        //         break;
        //     case '3':
        //         $statClass = 'text_danger';
        //         $status = 'Cancelled';
        //         break;
        //     case '4':
        //         $statClass = 'text_black';
        //         $status = 'Closed';
        //         break;
        //     case '5':
        //         $statClass = 'text_blue';
        //         $status = 'Ongoing Approval';
        //         break;
        //     default:
        //         $statClass = 'text_black';
        //         $status = 'Not Sent For Approval';
        //         break;
        // }

        $checkRequisitionApproval = $this->assetService->checkRequisitionApproval($requisition->id, auth()->user()->id);

        ///notification read
        // $this->notificationMarkRead($formDetails->slug, $userData);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        //dd($notifications);

        $requisitionItemsArr = $requisition->items->pluck('asset_id')->toArray();
        $relatedBudgets = $this->assetService->getRelatedBudgets($requisitionItemsArr);

        return view('admin.requisition.requisition-detail', compact('entities', 'departments', 'employees', 'requisition', 'uuid', 'checkRequisitionApproval', 'relatedBudgets'));
    }

    public function listRequisitionItem($uuid)
    {
        $this->setPageTitle('Requisition Item List');
        $requisitionId = uuidtoid($uuid, 'requisitions');
        $requisition = $this->assetService->findRequisitionById($requisitionId);
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;
        $requisitionItems = $this->assetService->findRequisitionItems(['requisition_id' => $requisitionId], $order, $dir, $limit, $index, false);
        $assetTypes = $this->getAssetTypesTree([], null, $requisition->category_id);
        $assetCategory = $this->categoryService->findCategoryById($requisition->category_id);
        if (!$assetTypes && $assetCategory->children()->count()) {
            foreach ($assetCategory->children()->get() as $assetCategorySub) {
                $assetTypes = array_merge($assetTypes, $this->getAssetTypesTree([], null, $assetCategorySub->id));
            }
        }
        $requisitionItemsArr = $requisition->items->pluck('asset_id')->toArray();
        // $relatedBudgets = $this->assetService->getRelatedBudgets($requisitionItemsArr);
        $itemsNotInBudget = $this->assetService->getItemsNotInBudget($requisitionItemsArr);

        $typeCategories = $this->getAssetCategoryTree();
        //dd($assetTypes);
        $checkRequisitionApproval = $this->assetService->checkRequisitionApproval($requisition->id, auth()->user()->id);
        return view('admin.requisition.items.index', compact('uuid', 'requisition', 'requisitionItems', 'assetTypes', 'typeCategories', 'itemsNotInBudget', 'checkRequisitionApproval'));
    }
    public function addRequisitionItem(Request $request, $reqid)
    {
        $this->setPageTitle('Add Requisition Item');
        if ($request->ajax()) {
            $rules = [
                // 'asset_type_id' => 'required|exists:categories,id',
                'asset_type_id' => 'required|exists:asset_types,id',
                'asset_id' => 'required',
                'quantity' => 'required|integer',
                'unit' => 'required',
            ];
            $messages = [
                'asset_type_id' => 'Asset type field is required',
                'asset_id' => 'Asset field is required',
                'quantity' => 'Quantity field is required',
                'unit' => 'Unit field is required',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $requisitionId = uuidtoid($reqid, 'requisitions');
                $requisitionDetail = $this->assetService->findRequisitionById($requisitionId);
                if ($requisitionDetail->status == '2') {
                    $this->assetService->createRequisitionVersion($requisitionDetail);
                }
                $asset_id = ($request->asset_id == '-1') ? null : $request->asset_id;
                $request->merge(['requisition_id' => uuidtoid($reqid, 'requisitions'), 'asset_id' => $asset_id,]);
                // dd($request->except('_token'));
                $isCreated = $this->assetService->addOrUpdateRequisitionItem(['uuid' => $request->uuid], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    $msg = $request->uuid ? 'Requisition item updated.' : 'Requisition item added.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.requisition.item.list', $reqid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $requisition = $this->assetService->findRequisitionById(uuidtoid($reqid, 'requisitions'));
        $assetTypes = $this->getAssetTypesTree();
        // $assetTypes = $this->assetTypeService->listAssets([['entity_id', '=', uuidtoid($requisition->entity_id, 'categories')]], 'id', 'desc');
        // $assets = $this->assetService->listAssets([['asset_type_id', '=', uuidtoid($requisition->entity_id, 'categories')]], 'id', 'desc');
        return view('admin.requisition.items.add', compact('assetTypes', 'reqid'));
    }
    // public function editRequisitionItem(Request $request, $reqid, $uuid){
    //     $this->setPageTitle('Edit Requisition Item');
    //     if($request->ajax()){
    //         $validator = Validator::make($request->all(), [
    //             'asset_type_id' => 'required|exists:categories,id',
    //             'asset_id' => 'required|exists:assets,id',
    //             'quantity' => 'required|integer',
    //             'specifications' => 'required|string'
    //         ]);
    //         if($validator->fails()) {
    //             return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
    //         }
    //         DB::beginTransaction();
    //         try {
    //             $isUpdated = $this->assetService->addOrUpdateRequisitionItem(['uuid' => $uuid], $request->except('_token'));
    //             if($isUpdated){
    //                 DB::commit();
    //                 return $this->responseJson(true, 200, 'Requisition item updated.', [
    //                     'redirect_url' => route('admin.requisition.edit', $reqid)
    //                 ]);
    //             }
    //         } catch (\Throwable $e) {
    //             DB::rollBack();
    //             logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
    //             return $this->responseJson(false, 500, $e->getMessage(), '');
    //         }
    //     }
    //     $requisitionItem = $this->assetService->findRequisitionItemById(uuidtoid($uuid, 'requisition_assets'));
    //     $assetTypes = $this->getAssetTypesTree();
    //     return view('admin.requisition.items.edit', compact('requisitionItem', 'assetTypes', 'uuid', 'reqid'));
    // }

    public function listBudget()
    {
        $this->setPageTitle('Budget List');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');

        $notifications = auth()->user()->notifications()->latest()->where('read_at', NULL)->limit(5)->get();

        //dd(gettype($notifications));
        $processedNotifications = $notifications->map(function ($notification) {
            $data = json_decode(json_encode($notification->data), true); // Correctly decode the JSON data
            $notification->form_name = $data['form_name'] ?? 'Default value if key not exists';
            $notification->budget_uuid = $data['budget_uuid'] ?? '';
            return $notification;
        });
        //dd($processedNotifications);
        return view('admin.budget.index', compact('entities', 'assetTypes', 'vendors', 'departments', 'processedNotifications'));
    }
    public function addBudget(Request $request)
    {
        $this->setPageTitle('Add Budget');
        if ($request->ajax()) {
            $rules = [
                'name' => 'required|string',
                'project_title' => 'required|string',
                'entity_id' => 'required|exists:categories,id',
                'location_id' => 'required|exists:locations,id',
                'department_id' => 'required|exists:departments,id',
                'budget_for' => 'required|string',
                'amount' => 'required',
                'budget_type' => 'required|string',
                'start_date' => 'required|date',
                'end_date' => 'required|date',
                'created_by' => 'required|exists:users,id',
                'category_id' => 'required|exists:categories,id',
            ];
            $messages = [
                'entity_id' => 'Entity field is required.',
                'location_id' => 'Location field is required.',
                'department_id' => 'Department field is required.',
                'category_id' => 'Asset Category field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $month = date('m', strtotime($request->start_date));
                $year = date('Y', strtotime($request->start_date));
                $findEntity = $this->categoryService->findCategoryById($request->entity_id);
                $findDepartment = $this->assetService->findDepartmentById($request->department_id);
                $findCategory = $this->categoryService->findCategoryById($request->category_id);
                $totalBudgetCount = $this->assetService->getTotalBudgets([]);
                $totalBudgetCountPlusOne = str_pad($totalBudgetCount + 1, 4, '0', STR_PAD_LEFT);
                //dd($categoryId);

                $uniqueBudgetId = $this->generateBudgetCode($findEntity->name, $findDepartment->name, $findCategory->name, $month, $year, str_pad($totalBudgetCount + 1, 4, '0', STR_PAD_LEFT));

                $amount = str_replace('₹ ', '', $request->amount);
                $amount = str_replace(',', '', $amount);
                $request->merge(['added_by' => auth()->user()->id, 'unique_id' => $uniqueBudgetId, 'category_id' => $request->category_id, 'amount' => $amount]);
                // dd($request->all());
                $isCreated = $this->assetService->addOrUpdateBudget(['uuid' => $request->uuid], $request->except('_token'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Budget Creation',
                    'task_description' => $request->name . '(' . $uniqueBudgetId . ')',
                    'task_url' => 'modules/budget/view/' . $isCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-budget',
                    'related_id' => $isCreated->id
                ]);

                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Budget created.', [
                        // 'redirect_url' => route('admin.budget.edit', $isCreated->uuid)
                        'redirect_url' => route('admin.budget.item.list', $isCreated->uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $locations = $this->assetService->listLocations();
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();
        $typeCategories = $this->getAssetCategoryTree();
        //  dd($typeCategories);
        return view('admin.budget.add', compact('entities', 'departments', 'employees', 'locations', 'typeCategories'));
    }
    public function editBudget(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Budget Detail');
        $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));
        if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $budget->created_by) && ($budget->status != '1' || ($budget->status == '1' && auth()->user()->hasRole('super-admin')))) {
            if ($request->ajax()) {
                $rules = [
                    'name' => 'required|string',
                    'project_title' => 'required|string',
                    'entity_id' => 'required|exists:categories,id',
                    // 'location_id' => 'required|exists:locations,id',
                    'department_id' => 'required|exists:departments,id',
                    'budget_for' => 'required|string',
                    'amount' => 'required',
                    'budget_type' => 'required|string',
                    'start_date' => 'required|date',
                    'end_date' => 'required|date',
                    'created_by' => 'required|exists:users,id',
                    'category_id' => 'required|exists:categories,id',


                ];
                $messages = [
                    'entity_id' => 'Entity field is required.',
                    'location_id' => 'Location field is required.',
                    'department_id' => 'Department field is required.',
                    'category_id' => 'Category field is required.',
                ];
                // dd($request->all());
                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                }
                DB::beginTransaction();
                try {
                    $amount = str_replace('₹ ', '', $request->amount);
                    $amount = str_replace(',', '', $amount);
                    $request->merge(['amount' => $amount]);
                    if ($budget->status == '2') {
                        $this->assetService->createBudgetVersion($budget);
                        $request->merge(['status' => null]);
                    }


                    $isUpdated = $this->assetService->addOrUpdateBudget(['uuid' => $uuid], $request->except('_token'));
                    if ($isUpdated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'Budget updated.', [
                            'redirect_url' => route('admin.budget.view', $uuid)
                        ]);
                    }
                } catch (\Throwable $e) {
                    DB::rollBack();
                    logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                    return $this->responseJson(false, 500, $e->getMessage(), '');
                }
            }
            $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
            $locations = $this->assetService->listLocations();
            $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
            $employees = $this->userService->getEmployees();
            $assetTypes = $this->getAssetTypesTree();
            $budgetid = $request->uuid ? uuidtoid($uuid, 'budgets') : null;
            $limit = 9999;
            $start = 0;
            $order = 'id';
            $dir = 'desc';
            $index = $start;
            $budgetItems = $this->assetService->findBudgetItems(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
            $budgetNotes = $this->assetService->findBudgetNotes(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
            //dd($budgetNotes);
            $typeCategories = $this->getAssetCategoryTree();

            return view('admin.budget.edit', compact('entities', 'departments', 'employees', 'budget', 'uuid', 'assetTypes', 'budgetItems', 'budgetNotes', 'locations', 'typeCategories'));
        } else {
            abort(401);
        }
    }

    public function addBudgetItem(Request $request, $reqid)
    {
        //dd($request->all());
        $this->setPageTitle('Add Budget Item');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                // 'asset_type_id' => 'required|exists:categories,id',
                'asset_type_id' => 'required|exists:asset_types,id',
                'asset_id' => 'required',
                'amount' => 'required',

            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $asset_id = ($request->asset_id == '-1') ? null : $request->asset_id;
                $amount = str_replace('₹ ', '', $request->amount);
                $amount = str_replace(',', '', $amount);
                $request->merge(['budget_id' => uuidtoid($reqid, 'budgets'), 'asset_id' => $asset_id, 'amount' => $amount]);

                $budgetDetail = $this->assetService->findBudgetById((uuidtoid($reqid, 'budgets')));
                if ($budgetDetail->status == '2') {
                    $this->assetService->createBudgetVersion($budgetDetail);
                }
                if ($request->uuid) {
                    $budgetItemId = uuidtoid($request->uuid, 'budget_items');
                    $budgetItemTotalAmount = BudgetItem::where('budget_id', $budgetDetail->id)->where('id', '<>', $budgetItemId)->sum('quantity');
                } else {
                    $budgetItemTotalAmount = BudgetItem::where('budget_id', $budgetDetail->id)->sum('quantity');
                }

                if ($budgetDetail->amount < ($budgetItemTotalAmount + $request->amount)) {
                    return $this->responseJson(false, 500, "You are exceeding the budget limit", ['amount' => 'You are exceeding the budget limit']);
                } else {
                    $isCreated = $this->assetService->addOrUpdateBudgetItem(['uuid' => $request->uuid], $request->except('_token'));
                    if ($isCreated) {
                        DB::commit();
                        $msg = $request->uuid ? 'Budget item updated.' : 'Budget item added.';
                        return $this->responseJson(true, 200, $msg, [
                            'redirect_url' => route('admin.budget.item.list', $reqid)
                        ]);
                    }
                }

                //$budgetItemDetail=$this->assetService->findBudgetItemTotalAmount((uuidtoid($reqid, 'budgets')));
                //dd($budgetItemDetail);
                //dd("ASqqq");
                // dd(int($request->amount));
                // dd($budgetDetail->amount);
                //$budgetDetail=Budget::where('id',uuidtoid($reqid, 'budgets'))->first();
                //dd($budgetDetail);
                // return $this->responseJson(true, 200, "Unable to add", [
                //     'redirect_url' => route('admin.budget.item.list', $reqid)
                // ]);

            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assetTypes = $this->getAssetTypesTree();
        return view('admin.budget.items.add', compact('assetTypes', 'reqid'));
    }


    public function addBudgetNote(Request $request, $reqid)
    {
        $this->setPageTitle('Add Budget Note');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'title' => 'required|string',
                'content' => 'required|string',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $budgetId = uuidtoid($reqid, 'budgets');
                $budgetDetail = $this->assetService->findBudgetById($budgetId);
                if ($budgetDetail->status == '2') {
                    $this->assetService->createBudgetVersion($budgetDetail);
                }
                $request->merge(['budget_id' => $budgetId]);
                $isCreated = $this->assetService->addOrUpdateBudgetNote(['uuid' => $request->uuid], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    $msg = $request->uuid ? 'Budget note updated.' : 'Budget note added.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.budget.note.list', $reqid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assetTypes = $this->getAssetTypesTree();
        return view('admin.budget.items.add', compact('assetTypes', 'reqid'));
    }

    public function viewBudget(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('View Budget');
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();
        $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));
        $assetTypes = $this->getAssetTypesTree();
        $budgetid = $request->uuid ? uuidtoid($uuid, 'budgets') : null;
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;


        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);

        ///notification read
        // $this->notificationMarkRead($formDetails->slug, $userData);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        //dd($notifications);
        return view('admin.budget.budget-detail', compact('entities', 'departments', 'employees', 'budget', 'uuid', 'checkBudgetApproval'));
    }


    // public function budgetDetailEdit(Request $request, $uuid)
    // {
    //     $this->setPageTitle('Edit Budget Detail');
    //     $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));
    //     if((auth()->user()->hasRole('super-admin') || auth()->user()->id == $budget->created_by) && ($budget->status != '1' || ($budget->status == '1' && auth()->user()->hasRole('super-admin')))){
    //         if ($request->ajax()) {
    //             $validator = Validator::make($request->all(), [
    //                 'name' => 'required|string',
    //                 'entity_id' => 'required|exists:categories,id',
    //                 'department_id' => 'required|exists:departments,id',
    //                 'created_by' => 'required|exists:users,id'
    //             ]);
    //             if ($validator->fails()) {
    //                 return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
    //             }
    //             DB::beginTransaction();
    //             try {
    //                 $isUpdated = $this->assetService->addOrUpdateBudget(['uuid' => $uuid], $request->except('_token'));
    //                 if ($isUpdated) {
    //                     DB::commit();
    //                     return $this->responseJson(true, 200, 'Budget updated.', [
    //                         'redirect_url' => route('admin.budget.list')
    //                     ]);
    //                 }
    //             } catch (\Throwable $e) {
    //                 DB::rollBack();
    //                 logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
    //                 return $this->responseJson(false, 500, $e->getMessage(), '');
    //             }
    //         }
    //         $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
    //         $departments = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'department']);
    //         $employees = $this->userService->getEmployees();
    //         $assetTypes = $this->getAssetTypesTree();
    //         $budgetid = $request->uuid ? uuidtoid($uuid, 'budgets') : null;
    //         $limit = 9999;
    //         $start = 0;
    //         $order = 'id';
    //         $dir = 'desc';
    //         $index = $start;
    //         $budgetItems = $this->assetService->findBudgetItems(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
    //         $budgetNotes = $this->assetService->findBudgetNotes(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
    //         //dd($budgetNotes);
    //         return view('admin.budget.edit', compact('entities', 'departments', 'employees', 'budget', 'uuid', 'assetTypes', 'budgetItems', 'budgetNotes'));
    //     }else{
    //         abort(401);
    //     }
    // }



    public function listBudgetItem($uuid)
    {
        //dd($reqid);
        $this->setPageTitle('Budget Item List');
        $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));
        $budgetid = uuidtoid($uuid, 'budgets');
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;
        $budgetItems = $this->assetService->findBudgetItems(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
        $assetTypes = $this->getAssetTypesTree([], null, $budget->category_id);
        $assetCategory = $this->categoryService->findCategoryById($budget->category_id);
        if (!$assetTypes && $assetCategory->children()->count()) {
            foreach ($assetCategory->children()->get() as $assetCategorySub) {
                $assetTypes = array_merge($assetTypes, $this->getAssetTypesTree([], null, $assetCategorySub->id));
            }
        }

        $typeCategories = $this->getAssetCategoryTree();
        // dd($assetTypes);
        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);
        $allBudgets = $this->assetService->findBudgets();
        return view('admin.budget.items.index', compact('uuid', 'budget', 'budgetItems', 'assetTypes', 'typeCategories', 'checkBudgetApproval', 'allBudgets'));
    }



    public function listBudgetNote($uuid)
    {
        $this->setPageTitle('Budget Note List');
        $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));
        $budgetid = uuidtoid($uuid, 'budgets');
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;
        $budgetItems = $this->assetService->findBudgetItems(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
        $assetTypes = $this->getAssetTypesTree();
        $budgetNotes = $this->assetService->findBudgetNotes(['budget_id' => $budgetid], $order, $dir, $limit, $index, false);
        //dd($budgetNotes);
        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);
        return view('admin.budget.notes.index', compact('uuid', 'budget', 'budgetNotes', 'assetTypes', 'checkBudgetApproval'));
    }



    public function listBudgetDocument($uuid)
    {
        $this->setPageTitle('Budget Document List');
        $budgetid = uuidtoid($uuid, 'budgets');
        $budget = $this->assetService->findBudgetById($budgetid);
        $budgetDocuments = $budget->document()->get();
        // dd($budgetDocuments);
        $budgetApprovals = $budget->budgetApproval->where('status', '>=', '0')->pluck('user_id')->toArray();
        //dd($budgetApprovals);
        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);
        return view('admin.budget.document.index', compact('uuid', 'budget', 'budgetDocuments', 'budgetApprovals', 'checkBudgetApproval'));
    }



    public function addBudgetDocument(Request $request, $uuid)
    {
        $this->setPageTitle('Add Budget Document');
        $budgetId = uuidtoid($uuid, 'budgets');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'title' => [
                    'required',
                    Rule::unique('documents', 'title')->where('documentable_id', $budgetId),
                ],
                'document' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $budgetDetail = $this->assetService->findBudgetById($budgetId);
                if ($budgetDetail->status == '2') {
                    $this->assetService->createBudgetVersion($budgetDetail);
                }
                $request->merge(['budget_id' => $budgetId]);
                $isCreated = $this->assetService->createBudgetDocument(['budgetId' => $budgetId], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    $msg = $request->uuid ? 'Budget document updated.' : 'Budget document added.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.budget.document.list', $uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }



    public function sendForApprovalNew(Request $request, $uuid)
    {
        $this->setPageTitle('Budget Send For Approval');
        $budgetId = uuidtoid($uuid, 'budgets');
        $budget = $this->assetService->findBudgetById($budgetId);
        if ($request->ajax()) {
            // $rules = [
            //     'level_user[*]' => 'required',
            // ];
            // $messages = [
            //     'level_user[*]' => 'The level user field is required.',
            // ];
            // $validator = Validator::make($request->all(), $rules, $messages);
            // if ($validator->fails()) {
            //     return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            // }
            DB::beginTransaction();
            try {
                if (count($request->level_user)) {
                    $count = 0;
                    foreach ($request->level_user as $k => $level_user) {
                        $data = [
                            'budget_id' => $budgetId,
                            'user_id' => $level_user,
                            'level' => $k,
                            'status' => ($count == 0) ? 0 : null
                        ];
                        $count++;
                        $isApprovalCreated = $this->assetService->createOrUpdateBudgetApproval($data);
                    }
                    if (count($request->level_user) == $count && $isApprovalCreated) {
                        $attributes = ['status' => '5'];
                        $isSendForApproval = $this->assetService->updateBudgetStatus($attributes, $budgetId);
                        DB::commit();
                        $userData = $this->userService->findUserById($request->level_user[1]);
                        $mailData = [
                            'to' => $userData->email,
                            'from' => env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'Please be informed that the budget proposal for ' . $budget->project_title . ' this project has been submitted for internal approval. Below are the key details:<br><br><br>',
                            //'content' => 'Please check and approve the Budget.',
                            'content' => 'Project/Department: #' . $budget->project_title . '-' . $budget->department?->name . '<br>Total Budget Amount: RS ' . $budget->amount . '<br>Submitted By: ' . $budget->createdBy?->full_name . '<br>Submission Date: ' . $budget->created_at->format('Y-m-d') . '<br><br><br>Kindly review the proposal and provide feedback or approval as necessary.' . '<br><br><br>To approve or reject the requisition, kindly use the following link: ' .  '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>',
                            'subject' => ' Budget Proposal Sent for Approval',
                            'greetings' => 'Dear ' . $userData->full_name . ',',
                            'end_greetings' => 'Best Regards,<br>DHC',
                            'from_user' => env('MAIL_FROM_NAME')
                        ];
                        Mail::send(new SendMailable($mailData));
                        return $this->responseJson(true, 200, 'Budget Send For Approval.', [
                            'redirect_url' => route('admin.budget.send.for.approval', $uuid)
                        ]);
                    }
                }
                // dd($request->all());
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        // $users = User::where(['is_approve'=>'1','is_blocked'=>'0'])->where('id','!=',Auth()->user()->id)->get();
        $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('full_name', 'id')->toArray();
        unset($levelUsers[auth()->user()->id]);

        $budgetApprovals = $this->assetService->getBudgetApprovals(['budget_id' => $budgetId]);
        // dd($budgetApprovals);



        return view('admin.budget.send-for-approval', compact('uuid', 'levelUsers', 'budgetApprovals'));
    }


    public function testViewBudget(Request $request)
    {
        $this->setPageTitle('Test View Budget');
        return view('admin.budget.test-budget-detail');
    }


    public function sendForApproval(Request $request, $uuid)
    {

        $this->setPageTitle('Budget Approval Status');
        $budgetId = uuidtoid($uuid, 'budgets');
        $budget = $this->assetService->findBudgetById($budgetId);
        // if ($budget->created_by == auth()->user()->id || auth()->user()->hasRole('super-admin')) {
        if ($request->ajax()) {

            if (!$request->level_user[array_key_last($request->level_user)]) {
                return $this->responseJson(false, 299, 'Approver field is required.', '');
            }

            DB::beginTransaction();
            try {
                if (count($request->level_user)) {
                    $count = 0;
                    $addUserData = $this->userService->findUserById($budget->added_by);
                    $creatUserData = $this->userService->findUserById($budget->created_by);
                    foreach ($request->level_user as $k => $level_user) {
                        $data = [
                            'budget_id' => $budgetId,
                            'user_id' => $level_user,
                            'level' => $k,
                            'status' => ($count == 0) ? 0 : null
                        ];

                        $userData = $this->userService->findUserById($request->level_user[$k]);
                        $notiUser = $this->userService->findUserById($request->level_user[1]);

                        if ($k == 1) {
                            $notiData = [
                                'form_name' => "You got a budget approval request for budget ID #" . $budget->unique_id,
                                'budget_uuid' => $budget->uuid,
                            ];
                            $userData->notify(new BudgetApproveNotification($notiData));
                        } else {
                            $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                            $notiData = [
                                'form_name' => $fullname . " got a budget approval request for budget ID #" . $budget->unique_id,
                                'budget_uuid' => $budget->uuid,
                            ];
                            $userData->notify(new BudgetApproveNotification($notiData));
                            $addUserData->notify(new BudgetApproveNotification($notiData));
                            $creatUserData->notify(new BudgetApproveNotification($notiData));
                        }

                        $count++;
                        $isApprovalCreated = $this->assetService->createOrUpdateBudgetApproval($data);
                    }
                    if (count($request->level_user) == $count && $isApprovalCreated) {
                        $attributes = ['status' => 0];
                        $isSendForApproval = $this->assetService->updateBudgetStatus($attributes, $budgetId);

                        // dd($notiUser->email);

                        DB::commit();

                        $mailData = [
                            'to' => $notiUser->email,
                            'from' => env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'Please be informed that the budget proposal for ' . $budget->project_title . ' this project has been submitted for internal approval. Below are the key details:<br><br><br>',
                            'content' => 'Project/Department: ' . $budget->project_title . '/ ' . $budget->department?->name . '<br>Total Budget Amount: RS ' . $budget->amount . '<br>Submitted By: ' . $budget->createdBy?->full_name . '<br>Submission Date: ' . $budget->created_at->format('Y-m-d') . '<br><br><br>Kindly review the proposal and provide feedback or approval as necessary.' . '<br><br><br>To approve or reject the requisition, kindly use the following link: ' .  '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>',
                            'subject' => ' Budget Proposal Sent for Approval',
                            'greetings' => 'Dear ' . $notiUser->full_name . ',',
                            'end_greetings' => 'Best Regards,<br>DHC',
                            'from_user' => env('MAIL_FROM_NAME')
                        ];
                        Mail::send(new SendMailable($mailData));
                        return $this->responseJson(true, 200, 'Budget successfully sent for approval.', [
                            'redirect_url' => route('admin.budget.send.for.approval', $uuid)
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        // dd($budget->amount);

        $filterCondition = [
            'max_amount' => $budget->amount,
            'is_available' => 1,
        ];

        $levelUsers = $this->userService->findUserByRole($filterCondition, null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();

        // dd($levelUsers);

        // $levelUsers = $this->userService->findUserByRole([], 'employee', 'id', 'desc', 999999, 0, false)->pluck('full_name', 'id')->toArray();


        unset($levelUsers[$budget->created_by]);

        $budgetApprovals = $this->assetService->getBudgetApprovals(['budget_id' => $budgetId]);
        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);

        return view('admin.budget.send-for-approval', compact('uuid', 'budget', 'levelUsers', 'budgetApprovals', 'checkBudgetApproval'));
    }


    public function location(Request $request)
    {
        $this->setPageTitle('Location');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        return view('admin.location.list', compact('entities', 'assetTypes', 'vendors'));
    }
    public function locationAdd(Request $request)
    {
        $this->setPageTitle('Location Add');
        $condition = [['is_active', '=', '1']];
        //dd($locationid);
        if ($request->ajax()) {
            $rules = [
                'location_name' => 'required',
                'street_address' => 'required',
                'state' => 'required',
                'city' => 'required',
            ];
            $messages = [
                'location_name' => 'The location name is required.',
                'street_address' => 'The street address is required.',
                'state' => 'The state is required.',
                'city' => 'The city is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd($request->all());
                $isCreated = $this->assetService->addOrUpdateLocation([
                    'uuid' => $request->uuid
                ], $request->except('_token',));
                if ($isCreated) {
                    DB::commit();
                    $msg = $isCreated->wasRecentlyCreated ? 'Location created' : 'Location updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.location.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        // $asset = $this->assetService->listAssets([], 'id', 'desc', 1)->first();
        // $assetid = $asset?->assetid;
        $assetid = substr(sha1(mt_rand()), 17, 6);
        $assettypes = $this->assetTypeService->listAssets($condition, 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');

        $countries = $this->countryService->getCountries();
        $states = $this->stateService->findStates(['country_id' => 101]);

        // if($uuid){
        //    $locationData=Location::where('id',$locationid)->first();
        // //    $locationData['zipcode']=Location::where('id',$locationid)->firtst();
        // //    $locationData['street_address']=Location::where('id',$locationid)->firtst();
        // //    $locationData['street_address']=Location::where('id',$locationid)->firtst();
        // //    $locationData['street_address']=Location::where('id',$locationid)->firtst();
        // }
        // dd($locationData);

        //dd($countries);
        // $states = $this->stateService->findStates(['country_id'=> 101]);
        return view('admin.location.add', compact('assettypes', 'assetid', 'vendors', 'states',));
    }


    public function locationEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Location Edit');
        $condition = [['is_active', '=', '1']];
        $locationid = uuidtoid($uuid, 'locations');
        //dd($locationid);
        if ($request->ajax()) {
            $rules = [
                'location_name' => 'required',
                'street_address' => 'required',
                'state' => 'required',
                'city' => 'required',
            ];
            $messages = [
                'location_name' => 'The location name is required.',
                'street_address' => 'The street address is required.',
                'state' => 'The state is required.',
                'city' => 'The city is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                $isCreated = $this->assetService->addOrUpdateLocation([
                    'uuid' => $request->uuid
                ], $request->except('_token',));
                if ($isCreated) {
                    DB::commit();
                    $msg = $isCreated->wasRecentlyCreated ? 'Location created' : 'Location Updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.location.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $assetid = substr(sha1(mt_rand()), 17, 6);
        $assettypes = $this->assetTypeService->listAssets($condition, 'id', 'desc');
        $vendors = $this->vendorService->getAllUsers([], 'vendor');

        $countries = $this->countryService->getCountries();
        $states = $this->stateService->findStates(['country_id' => 101]);
        if ($uuid) {
            $locationData = Location::where('id', $locationid)->first();
        }
        $states = $this->stateService->getStateByCountry($locationData->country_id);

        $cities = $this->cityService->getCityByState($locationData->state_id);

        // dd($states[4851]);
        // dd($cities);

        return view('admin.location.edit', compact('uuid', 'assettypes', 'assetid', 'vendors', 'countries', 'states', 'cities', 'locationData'));
    }


    public function importItem(Request $request)
    {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'budgetid' => 'required|string|exists:budgets,unique_id',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {



                $findBudget = Budget::where('unique_id', '=', $request->budgetid)->first();

                if ($findBudget->status == '2') {
                    $this->assetService->createBudgetVersion($findBudget);
                }

                $budgetItems = BudgetItem::where('budget_id', $findBudget->id)->get();
                $currentBudgetuuid = $request->currentbudgetid;  ///uuid comming


                $currentBudgetId = uuidtoid($request->currentbudgetid, 'budgets');
                $currentBudget = Budget::where('id', $currentBudgetId)->first();
                $totalAmount = 0;
                if ($currentBudget->items->count()) {
                    foreach ($currentBudget->items as $currentBudgetItem) {
                        $totalAmount += (int) $currentBudgetItem->quantity;
                    }
                }
                $isAmountExceeded = false;
                foreach ($budgetItems as $item) {
                    $totalAmount += (int) $item->quantity;
                    if ($totalAmount <= (int) $currentBudget->amount) {
                        $newItem = new BudgetItem();
                        $newItem->budget_id = $currentBudgetId;
                        $newItem->category_id = $item->category_id;
                        $newItem->asset_type_id = $item->asset_type_id;
                        $newItem->asset_id = $item->asset_id;
                        $newItem->quantity = $item->quantity;
                        $newItem->specifications = $item->specifications;
                        $newItem->save();
                    } else {
                        $isAmountExceeded = true;
                    }
                }
                DB::commit();
                $limit = 9999;
                $start = 0;
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $uuid = $currentBudgetuuid;
                $this->setPageTitle('Budget Item List');
                $budget = $this->assetService->findBudgetById(uuidtoid($uuid, 'budgets'));

                $budgetItems = $this->assetService->findBudgetItems(['budget_id' => $currentBudgetId], $order, $dir, $limit, $index, false);

                $assetTypes = $this->getAssetTypesTree();
                $msg = !$isAmountExceeded ? "Previous data loaded" : "Previous data loaded but not all items added as budget amount exceeded";
                return $this->responseJson(true, 200, $msg, [
                    'redirect_url' => route('admin.budget.item.list', $uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }


    public function getAssetTypeByCategory(Request $request)
    {

        try {
            $assetCategory = $this->categoryService->findCategoryById($request->assetCategoryId);
            $assetTypes = $this->getAssetTypesTree([], null, $request->assetCategoryId);
            if (!$assetTypes && $assetCategory->children()->count()) {
                foreach ($assetCategory->children()->get() as $assetCategorySub) {
                    $assetTypes = array_merge($assetTypes, $this->getAssetTypesTree([], null, $assetCategorySub->id));
                }
            }
            return $this->responseJson(true, 200, 'Assets Type Fetched.', $assetTypes);
        } catch (\Throwable $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }


    protected function generateBudgetCode($entity = null, $department = null, $category = null, $month = null, $year = null, $totalBudgetCountPlusOne = null)
    {
        $budgetCode = substr(strtoupper((preg_replace('/[^a-zA-Z0-9]/', '', $entity))), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $department)), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $category)), 0, 3) . '/' . $month . '/' . $year . '-' . $totalBudgetCountPlusOne;
        return $budgetCode;
    }

    public function listRequisitionDocument($uuid)
    {
        $this->setPageTitle('Requisition Document List');
        $requisitionid = uuidtoid($uuid, 'requisitions');
        $requisition = $this->assetService->findRequisitionById($requisitionid);
        $requisitionDocuments = $requisition->document()->get();
        // dd($requisitionDocuments);
        $requisitionApprovals = $requisition->requisitionApproval->where('status', '>=', '0')->pluck('user_id')->toArray();
        //dd($requisitionApprovals);
        $checkRequisitionApproval = $this->assetService->checkRequisitionApproval($requisition->id, auth()->user()->id);
        return view('admin.requisition.document.index', compact('uuid', 'requisition', 'requisitionDocuments', 'requisitionApprovals', 'checkRequisitionApproval'));
    }
    public function addRequisitionDocument(Request $request, $uuid)
    {
        $this->setPageTitle('Add Requisition Document');
        $requisitionId = uuidtoid($uuid, 'requisitions');
        if ($request->ajax()) {
            $validator = Validator::make($request->all(), [
                'title' => [
                    'required',
                    Rule::unique('documents', 'title')->where('documentable_id', $requisitionId),
                ],
                'document' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['requisition_id' => $requisitionId]);

                $requisitionDetail = $this->assetService->findRequisitionById($requisitionId);
                if ($requisitionDetail->status == '2') {
                    $this->assetService->createRequisitionVersion($requisitionDetail);
                }
                $isCreated = $this->assetService->createRequisitionDocument(['requisitionId' => $requisitionId], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    $msg = $request->uuid ? 'Requisition document updated.' : 'Requisition document added.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.requisition.document.list', $uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function sendRequisitionForApproval(Request $request, $uuid)
    {

        $this->setPageTitle('Requisition Approval Status');
        $requisitionId = uuidtoid($uuid, 'requisitions');
        $requisition = $this->assetService->findRequisitionById($requisitionId);
        // if ($requisition->created_by == auth()->user()->id || auth()->user()->hasRole('super-admin')) {
        if ($request->ajax()) {

            // $rules = [
            //     'level_user[*]' => 'required',
            // ];
            // $messages = [
            //     'level_user[*]' => 'The level user field is required.',
            // ];
            // $validator = Validator::make($request->all(), $rules, $messages);
            // if ($validator->fails()) {
            //     return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            // }

            if (!$request->level_user[array_key_last($request->level_user)]) {
                return $this->responseJson(false, 299, 'Approver field is required.', '');
            }

            DB::beginTransaction();
            try {
                if (count($request->level_user)) {
                    $count = 0;
                    $addUserData = $this->userService->findUserById($requisition->added_by);
                    $creatUserData = $this->userService->findUserById($requisition->created_by);
                    foreach ($request->level_user as $k => $level_user) {
                        $data = [
                            'requisition_id' => $requisitionId,
                            'user_id' => $level_user,
                            'level' => $k,
                            'status' => ($count == 0) ? 0 : null
                        ];

                        $userData = $this->userService->findUserById($request->level_user[$k]);
                        $notiUser = $this->userService->findUserById($request->level_user[1]);

                        if ($k == 1) {
                            $notiData = [
                                'form_name' => "You got a requisition approval request for requisition ID #" . $requisition->unique_id,
                                'requisition_uuid' => $requisition->uuid,
                            ];
                            $userData->notify(new RequisitionApproveNotification($notiData));
                        } else {
                            $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                            $notiData = [
                                'form_name' => $fullname . " got a requisition approval request for requisition ID #" . $requisition->unique_id,
                                'requisition_uuid' => $requisition->uuid,
                            ];
                            $userData->notify(new RequisitionApproveNotification($notiData));
                            $addUserData->notify(new RequisitionApproveNotification($notiData));
                            $creatUserData->notify(new RequisitionApproveNotification($notiData));
                        }

                        $count++;
                        $isApprovalCreated = $this->assetService->createOrUpdateRequisitionApproval($data);
                    }
                    if (count($request->level_user) == $count && $isApprovalCreated) {
                        $attributes = ['status' => 0];
                        $isSendForApproval = $this->assetService->updateRequisitionStatus($attributes, $requisitionId);



                        DB::commit();
                        $statContent = 'Requisition ID: #' . $requisition->unique_id . '<br>Requested By: ' . $requisition->createdBy?->full_name . '<br>Requested Items/Services:<br>';
                        $table = '
                        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                            <thead>
                                <tr>
                                    <th style="text-align: left;">Name</th>
                                    <th style="text-align: left;">Quantity</th>
                                </tr>
                            </thead>
                            <tbody>';
                        if ($requisition->items != null && count($requisition->items) > 0) {
                            foreach ($requisition->items as $itemDetail) {
                                $findAsset = Asset::find($itemDetail['asset_id']);
                                $productName = $findAsset->asset_name;
                                $quantity = $itemDetail['quantity'];
                                $table .= '
                                <tr>
                                    <td>' . htmlspecialchars($productName) . '</td>
                                    <td>' . htmlspecialchars($quantity) . '</td>
                                </tr>';
                            }
                        } else {
                            $table .= '
                            <tr>
                                <td colspan="2" style="text-align: center;">No data found</td>
                            </tr>';
                        }

                        $table .= '
                            </tbody>
                        </table>';
                        $endContent = '<br>We kindly request your approval to proceed with this requisition.<br>To approve or reject the requisition, kindly use the following link:, please visit: <a href="' . route('admin.requisition.view', $requisition->uuid) . '" class="edit_icon">' . $requisition->unique_id . '</a>';



                        $mailData = [
                            'to' => $notiUser->email,
                            'from' => env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'I hope this message finds you well. Please find below the details for the requisition that requires your approval:<br><br><br>Requisition Details:',
                            //'content' => 'Requisition ID: #' . $requisition->unique_id . '<br>Requested By: ' . $requisition->createdBy?->full_name . '<br>Asset Category: ' . $requisition->category?->name . '<br><br><br>We kindly request your approval to proceed with this requisition. <br><br><br>To approve or reject the requisition, kindly use the following link:<br><br><br>Link to Requisition Approval Portal, please visit: <a href="' . route('admin.requisition.view', $requisition->uuid) . '" class="edit_icon">' . $requisition->unique_id . '</a>',
                            'content' => $statContent . $table . $endContent,
                            'subject' => ' Request for Requisition Approval -#' . $requisition->unique_id,
                            'greetings' => 'Dear ' . $notiUser->full_name . ',',
                            'end_greetings' => 'Best Regards,<br>DHC',
                            'from_user' => env('MAIL_FROM_NAME')
                        ];
                        Mail::send(new SendMailable($mailData));
                        return $this->responseJson(true, 200, 'Requisition successfully sent for approval.', [
                            'redirect_url' => route('admin.requisition.send.for.approval', $uuid)
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();

        // $levelUsers = $this->userService->findUserByRole([], 'employee', 'id', 'desc', 999999, 0, false)->pluck('full_name', 'id')->toArray();


        unset($levelUsers[$requisition->created_by]);

        $requisitionApprovals = $this->assetService->getRequisitionApprovals(['requisition_id' => $requisitionId]);


        return view('admin.requisition.send-for-approval', compact('uuid', 'requisition', 'levelUsers', 'requisitionApprovals'));
        // } else {
        //     abort(401);
        // }
    }


    public function listRfq()
    {
        $this->setPageTitle('RFQ List');
        $limit = 9999;
        $start = 0;
        $order = 'id';
        $dir = 'desc';
        $index = $start;
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $rfqs = $this->assetService->findRfqs([], $order, $dir, $limit, $index, false);

        //dd($rfqs);
        $rfqs = $this->assetService->findRfqs(['status' => '1']);

        return view('admin.requisition.rfq.index', compact('rfqs'));
    }
    public function addRfq(Request $request)
    {
        $this->setPageTitle('Add Requisition');
        if ($request->ajax()) {
            $rules = [
                'requisition_id' => 'required|exists:requisitions,uuid',
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'created_by' => 'required|exists:users,id',
                'request_date' => 'required|date',
                'validity_date' => 'required|date',
                'request_subject' => 'required|string',
                'location_id' => 'required|exists:locations,id',
                // 'vendor_id' => 'required|exists:vendors,id',
                'vendor_id' => 'required|array',
                'vendor_id.*' => 'exists:vendors,id',
            ];
            $messages = [
                'requisition_id' => 'Requisition ID field is required.',
                'entity_id' => 'Entity field is required.',
                'created_by' => 'Created by field is required.',
                'request_date' => 'Request Date field is required.',
                'validity_date' => 'Validity Date field is required.',
                'request_subject' => 'Subject field is required.',
                'location_id' => 'Loaction field is required.',
                'department_id' => 'Department field is required.',
                'vendor_id' => 'Vendor field is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd($request->all(),$request->items);
                $msg = 'RFQ created';
                $requisition_id = uuidtoid($request->requisition_id, 'requisitions');
                $request->merge(['status' => '1', 'requisition_id' => $requisition_id]);
                $isRfqCreated = $this->assetService->addOrUpdateRfq(['uuid' => null], $request->except('_token'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New RFQ Creation',
                    'task_description' => $request->request_subject . '(' . $isRfqCreated->unique_id . ')',
                    'task_url' => 'modules/rfq/list',
                    'added_by' => auth()->user()->id,
                    'type' => 'add-rfq',
                    'related_id' => $isRfqCreated->id
                ]);

                if ($isRfqCreated) {
                    if ($request->items) {
                        $itemDetailsArray = [];
                        foreach ($request->items as $item) {
                            if (isset($item['item_id'])) {
                                $itemData = [
                                    'status' => '1',
                                    'request_id' => $isRfqCreated->id,
                                    'category_id' => $item['category_id'],
                                    'asset_type_id' => $item['asset_type_id'],
                                    'asset_id' => $item['asset_id'],
                                    'quantity' => $item['quantity'],
                                    'unit' => $item['unit'],
                                    'specifications' => $item['specifications'],
                                    'description' => $item['description'],
                                ];
                                $itemDetailsArray[] = $itemData;
                                $this->assetService->addOrUpdateRfqItems(['uuid' => null], $itemData);
                            }
                        }
                    }
                    if ($request->vendor_id) {
                        foreach ($request->vendor_id as $vendor_id) {
                            $vendor = $this->vendorService->findUserById($vendor_id);
                            $otp = rand(1000, 9999);
                            $vendorData = [
                                'status' => '1',
                                'request_id' => $isRfqCreated->id,
                                'vendor_id' => $vendor_id,
                                'request_url' => route('quotation.submit', [$vendor->uuid, $isRfqCreated->uuid]),
                                'otp' => $otp
                            ];
                            if ($request->is_sent == '1') {
                                $location = $this->assetService->findLocationById($request->location_id);
                                $deliveryLocationName = $location->street_address;
                                $table = '
                                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                                    <thead>
                                        <tr>
                                            <th style="text-align: left;">Product/Service Name</th>
                                            <th style="text-align: left;">Quantity</th>
                                            <th style="text-align: left;">Specifications/Requirements</th>
                                            <th style="text-align: left;">Delivery Location</th>
                                        </tr>
                                    </thead>
                                    <tbody>';


                                foreach ($itemDetailsArray as $itemDetail) {
                                    $findAsset = Asset::find($itemDetail['asset_id']);
                                    $productName = $findAsset->asset_name;
                                    $quantity = $itemDetail['quantity'];
                                    $specifications = strip_tags($itemDetail['specifications']);

                                    $table .= '
                                    <tr>
                                        <td>' . htmlspecialchars($productName) . '</td>
                                        <td>' . htmlspecialchars($quantity) . '</td>
                                        <td>' . htmlspecialchars($specifications) . '</td>
                                        <td>' . $deliveryLocationName . '</td>
                                    </tr>';
                                }

                                $table .= '
                                    </tbody>
                                </table>';

                                $endContent = "<br>Please submit your quotation via the following link:<br><br><br>Your OTP is: " . $otp . "<br>Quotation submission link: <a href=\"" . htmlspecialchars($vendorData['request_url']) . "\">click here</a><br><br><br>When submitting, kindly ensure that your quotation includes the following:<br><br><br>Pricing details<br>Payment terms<br>Delivery timelines<br>Any additional relevant information<br>We would appreciate receiving your quotation by " . htmlspecialchars($request->validity_date) . ". Should you need any further information or clarification, feel free to contact me directly.<br><br><br>Thank you for your time and we look forward to your prompt response.";

                                //$content = $table . "<br><br><br>Your OTP is: " . $otp . "<br>Quotation submission link: " . $vendorData['request_url'] . "<br><br><br>When submitting, kindly ensure that your quotation includes the following:<br><br><br>Pricing details<br>Payment terms<br>Delivery timelines<br>Any additional relevant information<br>We would appreciate receiving your quotation by .$request->validity_date.' Should you need any further information or clarification, feel free to contact me directly.<br><br><br>Thank you for your time and we look forward to your prompt response.";

                                $mailData = [
                                    'to' => $vendor->email,
                                    'from' => env('MAIL_FROM_ADDRESS'),
                                    'mail_type' => 'general',
                                    'line' => 'We are reaching out to request a formal quotation for the following products/services<br><br><br>RFQ Details:',
                                    //'content' => "Please check RFQ details.<br>Your OTP is: " . $otp . "<br>Quotation submission link: " . $vendorData['request_url'],
                                    'content' => $table . $endContent,
                                    'subject' => 'Request for Quotation (RFQ) - for ' . $request->request_subject,
                                    'greetings' => 'Dear ' . $vendor->first_name . ' ' . $vendor->last_name . ',',
                                    'end_greetings' => 'Best Regards,<br>DHC',
                                    'from_user' => env('MAIL_FROM_NAME')
                                ];
                                Mail::send(new SendMailable($mailData));
                                $msg = "RFQ Added & Email Sent";
                            }
                            $this->assetService->addOrUpdateRfqVendor(['uuid' => null], $vendorData);
                        }
                    }


                    //////////////mail send code///////
                    //$vendorMailLists=['shankhadeep07@gmail.com','shankhadeep20@gmail.com'];
                    // if ($request->is_sent == '1') {
                    //     $vendorLists = $this->userService->findVendorByIds($request->vendor_id, []);
                    //     $vendorMailLists = $vendorLists->pluck('email')->toArray();
                    //     $mailData = [
                    //         'to' => $vendorMailLists,
                    //         'from' => env('MAIL_FROM_ADDRESS'),
                    //         'mail_type' => 'general',
                    //         'line' => 'You got a RFQ',
                    //         'content' => 'Please check Item Details',
                    //         'subject' => 'RFQ',
                    //         'greetings' => 'Hello Sir/Madam',
                    //         'end_greetings' => 'Regards,',
                    //         'from_user' => env('MAIL_FROM_NAME')
                    //     ];
                    //     //Mail::send(new SendMailable($mailData));
                    //     $msg = "RFQ Added & Email Sent";
                    // }

                    DB::commit();
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.rfq.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');

        $requisitions = $this->assetService->findRequisitions(['status' => '1', 'items' => 1]);

        // dd($requisitions);

        $locations = $this->assetService->listLocations();
        $employees = $this->userService->getEmployees();
        $typeCategories = $this->getAssetCategoryTree();
        $assetTypes = $this->getAssetTypesTree();
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);

        // dd($requisitions[1]->items->count());

        return view('admin.requisition.rfq.add', compact('requisitions', 'entities', 'departments', 'employees', 'locations', 'typeCategories', 'assetTypes', 'vendors'));
    }

    public function editRfq(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Requisition');
        $rfqId = uuidtoid($uuid, 'rfqs');
        if ($request->ajax()) {
            // dd($request->uuid);
            $rules = [
                //'requisition_id' => 'required|exists:requisitions,uuid',
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'created_by' => 'required|exists:users,id',
                'request_date' => 'required|date',
                'validity_date' => 'required|date',
                'request_subject' => 'required|string',
                'location_id' => 'required|exists:locations,id',
                // 'vendor_id' => 'required|exists:vendors,id',
                'vendor_id' => 'required|array',
                'vendor_id.*' => 'exists:vendors,id',
            ];
            $messages = [
                //'requisition_id' => 'Requisition ID field is required.',
                'entity_id' => 'Entity field is required.',
                'created_by' => 'Created by field is required.',
                'request_date' => 'Request Date field is required.',
                'validity_date' => 'Validity Date field is required.',
                'request_subject' => 'Subject field is required.',
                'location_id' => 'Loaction field is required.',
                'department_id' => 'Department field is required.',
                'vendor_id' => 'Vendor field is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                // $requisition_id = $rfqData->requisition_id;
                // $request->merge(['status' =>'1','requisition_id'=>$requisition_id]);
                $isRfqCreated = $this->assetService->addOrUpdateRfq(['uuid' => $request->uuid], $request->except('_token'));
                if ($isRfqCreated) {
                    $is_rfqitems_deleted = $this->assetService->getAllRfqItems(['request_id' => $rfqId])->each->forceDelete();
                    if ($request->items) {
                        foreach ($request->items as $item) {
                            if (isset($item['item_id'])) {
                                $itemData = [
                                    'status' => '1',
                                    'request_id' => $isRfqCreated->id,
                                    'category_id' => $item['category_id'],
                                    'asset_type_id' => $item['asset_type_id'],
                                    'asset_id' => $item['asset_id'],
                                    'quantity' => $item['quantity'],
                                    'unit' => $item['unit'],
                                    'specifications' => $item['specifications'],
                                    'description' => $item['description'],
                                ];
                                $this->assetService->addOrUpdateRfqItems(['uuid' => null], $itemData);
                            }
                        }
                    }

                    // dd($request->vendor_id);
                    $msg = "RFQ Updated";
                    $is_vendors_deleted = $this->userService->getAllAddedVendors(['request_id' => $rfqId])->each->forceDelete();
                    if ($request->vendor_id) {
                        foreach ($request->vendor_id as $vendor_id) {
                            $otp = rand(1000, 9999);
                            $vendor = $this->vendorService->findUserById($vendor_id);
                            $vendorData = [
                                'status' => '1',
                                'request_id' => $isRfqCreated->id,
                                'vendor_id' => $vendor_id,
                                'request_url' => route('quotation.submit', [$vendor->uuid, $isRfqCreated->uuid]),
                                'otp' => $otp
                            ];
                            $this->assetService->addOrUpdateRfqVendor(['uuid' => null], $vendorData);
                            if ($request->is_sent == '1') {
                                // dd($vendor->email,$otp);
                                $mailData = [
                                    'to' => $vendor->email,
                                    'from' => env('MAIL_FROM_ADDRESS'),
                                    'mail_type' => 'general',
                                    'line' => 'You got a RFQ',
                                    'content' => "Please check RFQ details.<br>Your OTP is: " . $otp . "<br>Quotation submission link: " . $vendorData['request_url'],
                                    'subject' => 'RFQ',
                                    'greetings' => 'Hello Sir/Madam',
                                    'end_greetings' => 'Regards,',
                                    'from_user' => env('MAIL_FROM_NAME')
                                ];
                                // Mail::send(new SendMailable($mailData));
                                $msg = "RFQ Updated & Email Sent";
                            }
                        }
                    }
                    DB::commit();

                    //////////////mail send code///////
                    //$vendorMailLists=['shankhadeep07@gmail.com','shankhadeep20@gmail.com'];
                    // if ($request->is_sent == '1') {
                    //     $vendorLists = $this->userService->findVendorByIds($request->vendor_id, []);
                    //     $vendorMailLists = $vendorLists->pluck('email')->toArray();
                    //     $mailData = [
                    //         'to' => $vendorMailLists,
                    //         'from' => env('MAIL_FROM_ADDRESS'),
                    //         'mail_type' => 'general',
                    //         'line' => 'You got a RFQ',
                    //         'content' => 'Please check Item Details',
                    //         'subject' => 'RFQ',
                    //         'greetings' => 'Hello Sir/Madam',
                    //         'end_greetings' => 'Regards,',
                    //         'from_user' => env('MAIL_FROM_NAME')
                    //     ];
                    //     //Mail::send(new SendMailable($mailData));
                    //     $msg = "RFQ Updated & Email Sent";
                    // }

                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.rfq.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $rfqData = $this->assetService->findRfqById($rfqId);
        $vendorIds = $rfqData->rqfVendor->pluck('vendor_id')->toArray(); /////fetching selected vendor ids
        //dd($vendorIds);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $requisitions = $this->assetService->findRequisitions(['status' => '1']);
        $locations = $this->assetService->listLocations();
        $employees = $this->userService->getEmployees();
        $typeCategories = $this->getAssetCategoryTree();
        $assetTypes = $this->getAssetTypesTree();
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);



        // $rfqItems = $this->assetService->getAllRfqItems(['request_id'=>2]);
        $rfqItems = $this->assetService->getAllRfqItems(['request_id' => $rfqId]); /////fetching items from rft_items table on the basis of request_id
        //dd($rfqItems);
        return view('admin.requisition.rfq.edit', compact('requisitions', 'entities', 'departments', 'employees', 'locations', 'vendors', 'rfqData', 'vendorIds', 'uuid', 'rfqItems'));
    }
    public function sendForQuotation(Request $request, $uuid)
    {
        $rfqId = uuidtoid($uuid, 'rfqs');
        if ($request->ajax()) {
            $rules = [
                'vendor_id' => 'required|array',
                'vendor_id.*' => 'exists:vendors,id',
            ];
            $messages = [
                'vendor_id' => 'Please select any Vendor.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $rfqData = $this->assetService->findRfqById($rfqId);
                foreach ($request->vendor_id as $vendor_id) {
                    $otp = rand(1000, 9999);
                    $vendor = $this->vendorService->findUserById($vendor_id);
                    $vendorData = [
                        'status' => '1',
                        'request_id' => $rfqData->id,
                        'vendor_id' => $vendor_id,
                        'request_url' => route('quotation.submit', [$vendor->uuid, $rfqData->uuid]),
                        'otp' => $otp
                    ];
                    $this->assetService->addOrUpdateRfqVendor(['uuid' => null], $vendorData);

                    $location = $this->assetService->findLocationById($rfqData->location_id);
                    $deliveryLocationName = $location->street_address;

                    $table = '
                    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                        <thead>
                            <tr>
                                <th style="text-align: left;">Product/Service Name</th>
                                <th style="text-align: left;">Quantity</th>
                                <th style="text-align: left;">Specifications/Requirements</th>
                                <th style="text-align: left;">Delivery Location</th>
                            </tr>
                        </thead>
                        <tbody>';

                    // Check if there are items in the RFQ data
                    if ($rfqData->items != null && count($rfqData->items) > 0) {
                        foreach ($rfqData->items as $itemDetail) {
                            $findAsset = Asset::find($itemDetail['asset_id']);
                            $productName = $findAsset->asset_name;
                            $quantity = $itemDetail['quantity'];
                            $specifications = strip_tags($itemDetail['specifications']);


                            $table .= '
                            <tr>
                                <td>' . htmlspecialchars($productName) . '</td>
                                <td>' . htmlspecialchars($quantity) . '</td>
                                <td>' . htmlspecialchars($specifications) . '</td>
                                <td>' . $deliveryLocationName . '</td>
                            </tr>';
                        }
                    } else {
                        $table .= '
                        <tr>
                            <td colspan="4" style="text-align: center;">No data found</td>
                        </tr>';
                    }

                    $table .= '
                        </tbody>
                    </table>';
                    $endContent = "<br>Please submit your quotation via the following link:<br><br><br>Your OTP is: " . htmlspecialchars($otp) . "<br>Quotation submission link: <a href=\"" . htmlspecialchars($vendorData['request_url']) . "\">click here</a><br><br><br>When submitting, kindly ensure that your quotation includes the following:<br><br><br>Pricing details<br>Payment terms<br>Delivery timelines<br>Any additional relevant information<br>We would appreciate receiving your quotation by " . htmlspecialchars($rfqData->validity_date->format('Y-m-d')) . ". Should you need any further information or clarification, feel free to contact me directly.<br><br><br>Thank you for your time and we look forward to your prompt response.";


                    //$content = $itemDetailsString . "<br><br><br>Your OTP is: " . $otp . "<br>Quotation submission link: " . $vendorData['request_url'] . "<br><br><br>When submitting, kindly ensure that your quotation includes the following:<br><br><br>Pricing details<br>Payment terms<br>Delivery timelines<br>Any additional relevant information<br>We would appreciate receiving your quotation by .$rfqData->validity_date.' Should you need any further information or clarification, feel free to contact me directly.<br><br><br>Thank you for your time and we look forward to your prompt response.";

                    // dd($vendor->email);
                    $mailData = [
                        'to' => $vendor->email,
                        'from' => env('MAIL_FROM_ADDRESS'),
                        'mail_type' => 'general',
                        'line' => 'We are reaching out to request a formal quotation for the following products/services<br><br><br>RFQ Details:',
                        'content' => $table . $endContent,
                        'subject' => 'Request for Quotation (RFQ) - for ' . $rfqData->request_subject,
                        'greetings' => 'Dear ' . $vendor->first_name . ' ' . $vendor->last_name . ',',
                        'end_greetings' => 'Best Regards,<br>DHC',
                        'from_user' => env('MAIL_FROM_NAME')
                    ];






                    Mail::send(new SendMailable($mailData));
                }
                DB::commit();
                return $this->responseJson(true, 200, "RFQ vendor added & email sent successfully", [
                    'redirect_url' => route('admin.rfq.view', $uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }

    public function viewRfq(Request $request, $uuid)
    {
        $this->setPageTitle('View Requisition');
        $rfqId = uuidtoid($uuid, 'rfqs');

        $rfqData = $this->assetService->findRfqById($rfqId);
        $vendorIds = $rfqData->rqfVendor->pluck('vendor_id')->toArray();
        $requisition = $this->assetService->findRequisitionById($rfqData->requisition_id);
        $entity = $this->categoryService->findCategoryById($rfqData->entity_id);
        $location = $this->assetService->findLocationById($rfqData->location_id);
        $department = $this->assetService->findDepartmentById($rfqData->department_id);
        $user = $this->userService->findUserById($rfqData->created_by);
        $rfqItems = $this->assetService->getAllRfqItems(['request_id' => $rfqId]);
        $availableVendors = $this->vendorService->findVendorsExceptIds($vendorIds);
        $isVendorSelected = $rfqData->quotations->contains('is_selected', '1');
        $isRfqRejected = $this->assetService->checkRfqApproval($rfqId, null, null, 2);
        // dd($isVendorSelected);

        return view('admin.requisition.rfq.rfq-detail', compact('requisition', 'entity', 'location', 'department', 'user', 'rfqData', 'rfqItems', 'availableVendors', 'isVendorSelected', 'isRfqRejected'));
    }

    public function submitQuotation(Request $request, $vendorUuid, $reqUuid)
    {
        $this->setPageTitle('Submit Quotation');
        $showDiv = false;
        if ($request->ajax()) {
            // dd($request->all());
            $rules = [
                'otp' => 'required_if:otp,preset|integer|digits:4',
                'items[.*][amount]' => 'required|numeric',
            ];
            $messages = [];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd($request->all());
                if ($request->otp) {
                    $rfqId = uuidtoid($reqUuid, 'rfqs');
                    $vendorId = uuidtoid($vendorUuid, 'vendors');
                    $vendorData = RfqVendor::where(['request_id' => $rfqId, 'vendor_id' => $vendorId])->first();
                    if ($request->otp == $vendorData->otp) {
                        return $this->responseJson(true, 200, 'OTP Successfully Verified.', $showDiv = true);
                    } else {
                        return $this->responseJson(false, 500, "Otp Does not Match", ['otp' => 'Otp Does not Match']);
                    }
                } else {
                    $advance_amount = str_replace('₹ ', '', $request->advance_amount);
                    $advance_amount = str_replace(',', '', $advance_amount);
                    $request->merge(['is_editable' => '0', 'advance_amount' => $advance_amount]);
                    $isQuotationCreated = $this->assetService->addOrUpdateQuotation(['uuid' => $request->quotation_uuid], $request->except('_token'));

                    $rfqId = uuidtoid($reqUuid, 'rfqs');
                    $findRfq = $this->assetService->findRfqById($rfqId);
                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                        'task_name' => 'New Quotation Creation',
                        'task_description' => $isQuotationCreated?->unique_id,
                        'task_url' => 'modules/rfq/quotation/view/' . $isQuotationCreated?->uuid,
                        'added_by' => $findRfq->created_by ?? '',
                        'type' => 'add-quotation',
                        'related_id' => $isQuotationCreated?->id
                    ]);


                    if ($request->items) {
                        foreach ($request->items as $item) {
                            $quotationItemData = [
                                'quotation_id' => $isQuotationCreated?->id,
                                'category_id' => $item['category_id'],
                                'asset_type_id' => $item['asset_type_id'],
                                'asset_id' => $item['asset_id'],
                                'unique_id' => $item['unique_id'],
                                'amount' => $item['amount'],
                                'discount_type' => $item['discount_type'],
                                'discount' => $item['discount'],
                                'tax_type' => $item['tax_type'],
                                'tax' => $item['tax'],
                                'quantity' => $item['quantity'],
                                'unit' => $item['unit'],
                                'total_amount' => $item['total_amount'],
                                'specifications' => $item['specifications'],
                                'description' => $item['description'],
                            ];
                            $this->assetService->addOrUpdateQuotationItems(['uuid' => $item['uuid']], $quotationItemData);
                        }
                    }
                }

                DB::commit();
                return $this->responseJson(true, 200, 'Quotation Submitted.', [
                    'redirect_url' => route('quotation.submit', ['uuid1' => $vendorUuid, 'uuid2' => $reqUuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $rfqId = uuidtoid($reqUuid, 'rfqs');
        $rfq = $this->assetService->findRfqById($rfqId);
        $rfqItems = $rfq->items;
        $vendorId = uuidtoid($vendorUuid, 'vendors');
        $vendor = $this->vendorService->findUserById($vendorId);

        $lastId = Quotation::orderBy('id', 'desc')->pluck('id')->first();
        $quotationNo = 'QUOT' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);

        $quotation = $this->assetService->getAllQuotations(['request_id' => $rfqId, 'vendor_id' => $vendorId])->first();
        // dd($rfqId, $vendorId);
        $states = $this->stateService->findStates(['country_id' => 101]);

        $isFormEditable = false;
        $isVendorSelected = false;
        if ($quotation) {
            $isVendorSelected = $quotation->rfq->quotations->contains('is_selected', '1');
        }
        if (!$quotation || ($quotation && $quotation->is_editable) && !$isVendorSelected) {
            $isFormEditable = true;
        }

        $vendorData = RfqVendor::where(['request_id' => $rfqId, 'vendor_id' => $vendorId])->first();
        $testOtp = $vendorData->otp;
        return view('admin.requisition.quotation.form', compact('vendor', 'rfq', 'rfqItems', 'quotationNo', 'vendorUuid', 'reqUuid', 'quotation', 'states', 'showDiv', 'isFormEditable', 'isVendorSelected', 'testOtp'));
    }


    public function sentRfqToEmail(Request $request, $rfqUuid)      ///////function for sending email via sent icon from listing page
    {
        $this->setPageTitle('Sent Quotation');
        DB::beginTransaction();
        try {
            $rfqId = uuidtoid($rfqUuid, 'rfqs');
            $rfqData = $this->assetService->findRfqById($rfqId);
            $vendorList = RfqVendor::where('request_id', $rfqData->id)->get();

            foreach ($vendorList as $vendor) {
                $vendor_id = $vendor->vendor_id;
                $otp = rand(1000, 9999);
                $vendor = $this->vendorService->findUserById($vendor_id);
                $vendorData = [
                    'status' => '1',
                    'request_id' => $rfqData->id,
                    'vendor_id' => $vendor_id,
                    'request_url' => route('quotation.submit', [$vendor->uuid, $rfqData->uuid]),
                    'otp' => $otp
                ];
                $this->assetService->addOrUpdateRfqVendor(['uuid' => null], $vendorData);

                //////////////////////////////////
                $location = $this->assetService->findLocationById($rfqData->location_id);
                $deliveryLocationName = $location->street_address;

                $table = '
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Product/Service Name</th>
                            <th style="text-align: left;">Quantity</th>
                            <th style="text-align: left;">Specifications/Requirements</th>
                            <th style="text-align: left;">Delivery Location</th>
                        </tr>
                    </thead>
                    <tbody>';

                // Check if there are items in the RFQ data
                if ($rfqData->items != null && count($rfqData->items) > 0) {
                    foreach ($rfqData->items as $itemDetail) {
                        $findAsset = Asset::find($itemDetail['asset_id']);
                        $productName = $findAsset->asset_name;
                        $quantity = $itemDetail['quantity'];
                        $specifications = strip_tags($itemDetail['specifications']);


                        $table .= '
                        <tr>
                            <td>' . htmlspecialchars($productName) . '</td>
                            <td>' . htmlspecialchars($quantity) . '</td>
                            <td>' . htmlspecialchars($specifications) . '</td>
                            <td>' . $deliveryLocationName . '</td>
                        </tr>';
                    }
                } else {
                    $table .= '
                    <tr>
                        <td colspan="4" style="text-align: center;">No data found</td>
                    </tr>';
                }

                $table .= '
                    </tbody>
                </table>';
                $endContent = "<br>Please submit your quotation via the following link:<br><br><br>Your OTP is: " . htmlspecialchars($otp) . "<br>Quotation submission link: <a href=\"" . htmlspecialchars($vendorData['request_url']) . "\">click here</a><br><br><br>When submitting, kindly ensure that your quotation includes the following:<br><br><br>Pricing details<br>Payment terms<br>Delivery timelines<br>Any additional relevant information<br>We would appreciate receiving your quotation by " . htmlspecialchars($rfqData->validity_date->format('Y-m-d')) . ". Should you need any further information or clarification, feel free to contact me directly.<br><br><br>Thank you for your time and we look forward to your prompt response.";



                // dd($vendor->email);
                $mailData = [
                    'to' => $vendor->email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => 'We are reaching out to request a formal quotation for the following products/services<br><br><br>RFQ Details:',
                    //'content' => "Please check RFQ details.<br>Your OTP is: " . $otp . "<br>Quotation submission link: " . $vendorData['request_url'],
                    'content' => $table . $endContent,
                    'subject' => 'Request for Quotation (RFQ) - for ' . $rfqData->request_subject,
                    'greetings' => 'Dear ' . $vendor->first_name . ' ' . $vendor->last_name . ',',
                    'end_greetings' => 'Best Regards,<br>DHC',
                    'from_user' => env('MAIL_FROM_NAME')
                ];

                Mail::send(new SendMailable($mailData));
            }


            $is_sent_status_update = $this->assetService->addOrUpdateRfq(['uuid' => $rfqUuid], ['is_sent' => '1']);
            DB::commit();
            return $this->responseRedirectBack('Email sent successfully', 'success');
        } catch (\Throwable $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function rfqQuotationsbk(Request $request, $rfqUuid, $notiuuid = null)
    {
        $this->setPageTitle('Received Quotation');
        $rfqId = uuidtoid($rfqUuid, 'rfqs');
        $rfqData = $this->assetService->findRfqById($rfqId);
        if ($request->ajax()) {

            DB::beginTransaction();
            try {
                $vendor = Vendor::find($request->vendor_id);
                $receiverMailLists = ['super.admin@dhc.com,', $vendor?->email];
                $findQuotation = Quotation::where(['request_id' => $rfqId, 'vendor_id' => $request->vendor_id])->first();


                $location = $this->assetService->findLocationById($rfqData->location_id);
                $deliveryLocationName = $location->street_address;

                $table = '
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Product/Service Name</th>
                            <th style="text-align: left;">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>';
                if ($rfqData->items != null && count($rfqData->items) > 0) {
                    foreach ($rfqData->items as $itemDetail) {
                        $findAsset = Asset::find($itemDetail['asset_id']);
                        $productName = $findAsset->asset_name;
                        $quantity = $itemDetail['quantity'];
                        $table .= '
                        <tr>
                            <td>' . htmlspecialchars($productName) . '</td>
                            <td>' . htmlspecialchars($quantity) . '</td>
                        </tr>';
                    }
                } else {
                    $table .= '
                    <tr>
                        <td colspan="2" style="text-align: center;">No data found</td>
                    </tr>';
                }

                $table .= '
                    </tbody>
                </table>';

                $endContent = '<br>RFQ ID: #' . htmlspecialchars($rfqData->unique_id) . '<br>Requested By: ' . htmlspecialchars($rfqData->createdBy?->full_name) . '<br>Quotation Details: <br>Vendor Name: ' . htmlspecialchars($vendor->full_name) . '<br>Quoted Price: ' . htmlspecialchars($findQuotation->item_total) . '<br>Payment Terms: ' . htmlspecialchars($findQuotation->payment_days) . '<br>Delivery Timeline: ' . htmlspecialchars($findQuotation->delivery_days) . '<br>Additional Notes: ' . htmlspecialchars($findQuotation->terms_conditions) . '<br>You may review and approve this quotation by clicking the link below: <br><a href="' . htmlspecialchars(route('login')) . '">login</a>';

                $mailData = [
                    'to' => $receiverMailLists,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => 'We have received a quotation for the RFQ No :#' . $rfqData->unique_id . ' and it has been submitted for your approval. Below are the key details of the quotation<br><br><br>RFQ Details:',
                    // 'content' => 'Product/Service Name: ' . $productName . '<br>RFQ ID: #' . $rfqData->unique_id . '<br>Requested By: ' . $rfqData->createdBy?->full_name . '<br>Quotation Details: <br>Vendor Name: ' . $vendor->full_name . '<br>Quoted Price: ' . $findQuotation->item_total . '<br>Payment Days: ' . $findQuotation->payment_days . '<br>Delivery Days' . $findQuotation->delivery_days . '<br>Additional Notes ' . $findQuotation->terms_conditions . '<br>You may review and approve this quotation by clicking the link below: <br>' . route('login'),
                    'content' => $table . $endContent,
                    'subject' => 'Quotation Submitted for Approval -#' . $rfqData->unique_id,
                    'greetings' => 'Dear ' . $vendor->first_name . ' ' . $vendor->last_name . ',',
                    'end_greetings' => 'Best Regards,<br>DHC',
                    'from_user' => env('MAIL_FROM_NAME')
                ];


                Mail::send(new SendMailable($mailData));
                $msg = 'Something went wrong.';
                $prevQuotationUpadate = $this->assetService->addOrUpdateQuotation(['request_id' => $rfqId], ['is_selected' => '0']);
                $isQuotationUpadate = $this->assetService->addOrUpdateQuotation(['request_id' => $rfqId, 'vendor_id' => $request->vendor_id], ['is_selected' => '1']);
                $lastId = RfqApproval::orderBy('id', 'desc')->pluck('id')->first();
                $rfqUpadate = $this->assetService->addOrUpdateRfq(['uuid' => $rfqUuid], ['quotation_comments' => $request->quotation_comments]);

                //dd($rfqUpadate);
                if ($isQuotationUpadate) {
                    $count = 0;
                    foreach ($request->level_user as $k => $level_user) {
                        $data = [
                            'request_id' => $rfqId,
                            'unique_id' => 'RFQA' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT),
                            'user_id' => $level_user,
                            'level' => $k,
                            'status' => ($count == 0) ? 0 : null
                        ];
                        $userData = $this->userService->findUserById($request->level_user[$k]);
                        $notiUser = $this->userService->findUserById($request->level_user[1]);
                        if ($k == 1) {
                            $notiData = [
                                'form_name' => "You got a RFQ approval request for RFQ ID #" . $rfqData->unique_id,
                                'rfq_uuid' => $rfqData->uuid,
                            ];
                        } else {
                            $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                            $notiData = [
                                'form_name' => $fullname . " got a RFQ approval request for RFQ ID #" . $rfqData->unique_id,
                                'rfq_uuid' => $rfqData->uuid,
                            ];
                        }
                        $userData->notify(new RfqApproveNotification($notiData));
                        $count++;
                        $isApprovalCreated = $this->assetService->createOrUpdateRfqApproval($data);
                        if ($isApprovalCreated) {
                            $msg = 'Quotation successfully sent for approval.';
                        }
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, $msg, [
                    'redirect_url' => route('admin.rfq.quotations', $rfqUuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $quotations = $this->assetService->getAllQuotations(['request_id' => $rfqId])->unique('vendor_id'); ////fetching all the submitted quotations for a specefic rfq id ///

        $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();
        $userId = !auth()->user()->hasRole('super-admin') ? auth()->user()->id : null;
        // $checkRfqApproval = $this->assetService->checkRfqApproval($rfqId, $userId);
        $isRfqRejected = $this->assetService->checkRfqApproval($rfqId, null, null, 2);
        //$isApply = $this->assetService->checkRfqApprovalByLatestOrder($rfqId, null, null, '0');
        // $isApproved = $this->assetService->checkRfqApproval($rfqId, null, null, '1');
        $currentRfqApproval = $this->assetService->checkRfqApproval($rfqId, null, null, '0');
        $latest = $this->assetService->checkRfqApprovalByLatestOrder($rfqId, null, null, null);

        $rfqApprovals = $this->assetService->getRfqApprovals(['request_id' => $rfqId]);
        $findRfqApproval = RfqApproval::where('request_id', $rfqId)->orderBy('id', 'desc')->first();
        $isRejectedInStep = '';
        if ($findRfqApproval)
            $isRejectedInStep = RfqApproval::where('request_id', $rfqId)->where('unique_id', $findRfqApproval->unique_id)->where('status', 2)->first();
        //dd($currentRfqApproval->user_id , auth()->user()->id);
        //dd($isRejectedInStep);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }

        return view('admin.requisition.quotation.comparison', compact('quotations', 'rfqData', 'rfqUuid', 'levelUsers', 'rfqApprovals', 'isRfqRejected', 'currentRfqApproval', 'latest', 'isRejectedInStep'));
    }





    public function rfqQuotations(Request $request, $rfqUuid, $notiuuid = null)
    {
        $this->setPageTitle('Received Quotation');
        $rfqId = uuidtoid($rfqUuid, 'rfqs');
        $rfqData = $this->assetService->findRfqById($rfqId);
        if ($request->ajax()) {

            DB::beginTransaction();
            try {
                $vendor = Vendor::find($request->vendor_id);
                $receiverMailLists = ['super.admin@dhc.com,', $vendor?->email];
                $findQuotation = Quotation::where(['request_id' => $rfqId, 'vendor_id' => $request->vendor_id])->first();
                $location = $this->assetService->findLocationById($rfqData->location_id);
                $deliveryLocationName = $location->street_address;
                $table = '
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Product/Service Name</th>
                            <th style="text-align: left;">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>';
                if ($rfqData->items != null && count($rfqData->items) > 0) {
                    foreach ($rfqData->items as $itemDetail) {
                        $findAsset = Asset::find($itemDetail['asset_id']);
                        $productName = $findAsset->asset_name;
                        $quantity = $itemDetail['quantity'];
                        $table .= '
                        <tr>
                            <td>' . htmlspecialchars($productName) . '</td>
                            <td>' . htmlspecialchars($quantity) . '</td>
                        </tr>';
                    }
                } else {
                    $table .= '
                    <tr>
                        <td colspan="2" style="text-align: center;">No data found</td>
                    </tr>';
                }
                $table .= '
                    </tbody>
                </table>';

                $endContent = '<br>RFQ ID: #' . htmlspecialchars($rfqData->unique_id) . '<br>Requested By: ' . htmlspecialchars($rfqData->createdBy?->full_name) . '<br>Quotation Details: <br>Vendor Name: ' . htmlspecialchars($vendor->full_name) . '<br>Quoted Price: ' . htmlspecialchars($findQuotation->item_total) . '<br>Payment Terms: ' . htmlspecialchars($findQuotation->payment_days) . '<br>Delivery Timeline: ' . htmlspecialchars($findQuotation->delivery_days) . '<br>Additional Notes: ' . htmlspecialchars($findQuotation->terms_conditions) . '<br>You may review and approve this quotation by clicking the link below: <br><a href="' . htmlspecialchars(route('login')) . '">login</a>';
                $msg = 'Something went wrong.';
                $prevQuotationUpadate = $this->assetService->addOrUpdateQuotation(['request_id' => $rfqId], ['is_selected' => '0']);
                $isQuotationUpadate = $this->assetService->addOrUpdateQuotation(['request_id' => $rfqId, 'vendor_id' => $request->vendor_id], ['is_selected' => '1']);
                $lastId = RfqApproval::orderBy('id', 'desc')->pluck('id')->first();
                $rfqUpadate = $this->assetService->addOrUpdateRfq(['uuid' => $rfqUuid], ['quotation_comments' => $request->quotation_comments]);
                if ($isQuotationUpadate) {
                    $count = 0;
                    foreach ($request->level_user as $k => $level_user) {
                        $data = [
                            'request_id' => $rfqId,
                            'unique_id' => 'RFQA' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT),
                            'user_id' => $level_user,
                            'level' => $k,
                            'status' => ($count == 0) ? 0 : null
                        ];
                        $userData = $this->userService->findUserById($request->level_user[$k]);
                        $notiUser = $this->userService->findUserById($request->level_user[1]);
                        if ($k == 1) {
                            $notiData = [
                                'form_name' => "You got a RFQ approval request for RFQ ID #" . $rfqData->unique_id,
                                'rfq_uuid' => $rfqData->uuid,
                            ];
                            $mailData = [
                                'to' => $notiUser->email,
                                'from' => env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'We have received a quotation for the RFQ No :#' . $rfqData->unique_id . ' and it has been submitted for your approval. Below are the key details of the quotation<br><br><br>RFQ Details:',
                                'content' => $table . $endContent,
                                'subject' => 'Quotation Submitted for Approval -#' . $rfqData->unique_id,
                                // 'greetings' => 'Dear ' . $vendor->first_name . ' ' . $vendor->last_name . ',',
                                'greetings' => 'Dear ' . $notiUser?->fullname . ',',
                                'end_greetings' => 'Best Regards,<br>DHC',
                                'from_user' => env('MAIL_FROM_NAME')
                            ];
                            Mail::send(new SendMailable($mailData));
                        } else {
                            $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                            $notiData = [
                                'form_name' => $fullname . " got a RFQ approval request for RFQ ID #" . $rfqData->unique_id,
                                'rfq_uuid' => $rfqData->uuid,
                            ];
                        }
                        $userData->notify(new RfqApproveNotification($notiData));
                        $count++;
                        $isApprovalCreated = $this->assetService->createOrUpdateRfqApproval($data);
                        if ($isApprovalCreated) {
                            $msg = 'Quotation successfully sent for approval.';
                        }
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, $msg, [
                    'redirect_url' => route('admin.rfq.quotations', $rfqUuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $quotations = $this->assetService->getAllQuotations(['request_id' => $rfqId])->unique('vendor_id'); ////fetching all the submitted quotations for a specefic rfq id ///

        $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();
        $userId = !auth()->user()->hasRole('super-admin') ? auth()->user()->id : null;
        // $checkRfqApproval = $this->assetService->checkRfqApproval($rfqId, $userId);

        $isRfqRejected = $this->assetService->checkRfqApproval($rfqId, null, null, 2);

        $currentRfqApproval = $this->assetService->checkRfqApproval($rfqId, null, null, '0');

        $latest = $this->assetService->checkRfqApprovalByLatestOrder($rfqId, null, null, null);

        $rfqApprovals = $this->assetService->getRfqApprovals(['request_id' => $rfqId]);
        $findRfqApproval = RfqApproval::where('request_id', $rfqId)->orderBy('id', 'desc')->first();
        $isRejectedInStep = '';
        if ($findRfqApproval)
            $isRejectedInStep = RfqApproval::where('request_id', $rfqId)->where('unique_id', $findRfqApproval->unique_id)->where('status', 2)->first();

        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        return view('admin.requisition.quotation.comparison', compact('quotations', 'rfqData', 'rfqUuid', 'levelUsers', 'rfqApprovals', 'isRfqRejected', 'currentRfqApproval', 'latest', 'isRejectedInStep'));
    }







    public function pdfDownload(Request $request, $rfqUuid)
    {
        try {
            $rfqId = uuidtoid($rfqUuid, 'rfqs');
            $rfqData = $this->assetService->findRfqById($rfqId);
            $quotations = $this->assetService->getAllQuotations(['request_id' => $rfqId])->unique('vendor_id'); ////fetching all the submitted quotations for a specefic rfq id ///
            //return view('admin.requisition.quotation.pdf',compact('quotations','rfqData'));
            $dompdf = new Dompdf();
            $html = view('admin.requisition.quotation.pdf', compact('rfqData', 'quotations'));

            $dompdf->loadHtml($html);
            $dompdf->setPaper('A2', 'landscape');
            $dompdf->render();
            $pdfOutput = $dompdf->output();
            $filename = 'Quotation_comparison_' . time() . '.pdf';
            return Response::make($pdfOutput, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function excelDownload(Request $request, $rfqUuid)
    {
        $rfqId = uuidtoid($rfqUuid, 'rfqs');
        $rfqData = $this->assetService->findRfqById($rfqId);
        $quotations = $this->assetService->getAllQuotations(['request_id' => $rfqId])->unique('vendor_id');; ////fetching all the submitted quotations for a specefic rfq id ///
        $filename = 'Quotation_' . time() . '.xlsx';
        return Excel::download(new QuotationComparisonExport($rfqData, $quotations), $filename);
    }

    public function rfqQuotationList(Request $request, $rfqUuid = null)
    {
        $this->setPageTitle('Quotation List');
        $args = ['status' => '1'];
        $rfqs = $this->assetService->findRfqs($args);
        if ($rfqUuid) {
            $rfqId = uuidtoid($rfqUuid, 'rfqs');
            $args['request_id'] = $rfqId;
        }
        $quotations = $this->assetService->getAllQuotations($args);
        return view('admin.requisition.quotation.list', compact('rfqUuid', 'rfqs', 'quotations'));
    }
    public function viewQuotation(Request $request, $uuid)
    {
        $this->setPageTitle('View Quotation');
        $quotationId = uuidtoid($uuid, 'quotations');
        $quotation = $this->assetService->findQuotationById($quotationId);
        return view('admin.requisition.quotation.view', compact('quotation'));
    }

    public function otp(Request $request, $vendorUuid, $reqUuid)
    {

        if ($request->ajax()) {

            $rules = [
                'otp' => 'required|integer|digits:4',
            ];
            $messages = [
                'otp' => 'OTP field is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }

            try {
                $rfqId = uuidtoid($reqUuid, 'rfqs');
                $vendorData = RfqVendor::where('request_id', $rfqId)->first();
                if ($request->otp == $vendorData->otp) {

                    RfqVendor::where(['request_id' => $rfqId, 'vendor_id' => $vendorData->vendor_id])->update(['otp' => null]);

                    return $this->responseJson(true, 200, 'OTP Successfully Verified.', [
                        'redirect_url' => route('quotation.submit', ['uuid1' => $vendorUuid, 'uuid2' => $reqUuid])
                    ]);
                } else {
                    return $this->responseJson(false, 500, "Otp Does not Match", ['otp' => 'Otp Does not Match']);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        return view('admin.requisition.quotation.otp', compact('vendorUuid', 'reqUuid'));
    }

    public function listPurchaseOrder()
    {
        $this->setPageTitle('Purchase Order List');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        return view('admin.purchase-order.index', compact('entities', 'vendors'));
    }
    public function addPurchaseOrder(Request $request)
    {
        $this->setPageTitle('Add Purchase Order');
        // dd($request->delivery_address[1]['delivery_location_id']);
        if ($request->ajax()) {
            $rules = [
                'po_date' => 'required',
                'valid_date_from' => 'required',
                'valid_date_to' => 'required',
            ];
            $messages = [
                'po_date'=>"Order Date is required",
                'valid_date_from'=>"Valid Date From is required",
                'valid_date_to'=>"Valid Date To is required",
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if(!$request->delivery_address[1]['delivery_state_id'] || !$request->delivery_address[1]['delivery_street_address']){
                $validator->after(function ($validator) {
                    $validator->errors()->add('delivery_address', 'Delivery address is required');
                });
            }
            if(!$request->billing_address['billing_state_id'] || !$request->billing_address['billing_street_address']){
                $validator->after(function ($validator) {
                    $validator->errors()->add('billing_address', 'Billing address is required');
                });
            }
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $is_gst_checked = ($request->is_gst_checked == 'on') ? 1 : 0;
                $termsConditions = [];
                if ($request->terms_conditions) {
                    foreach ($request->terms_conditions as $terms_condition) {
                        if (isset($terms_condition['id'])) {
                            $termsConditions[] = [
                                'id' => $terms_condition['id'],
                                'title' => $terms_condition['title'],
                                'type' => $terms_condition['type'],
                                'description' => $terms_condition['description'],
                            ];
                        }
                    }
                }
                $request->merge(['is_gst_checked' => $is_gst_checked, 'added_by' => auth()->user()->id, 'terms_conditions' => $termsConditions]);
                $isPoCreated = $this->assetService->addOrUpdatePurchaseOrder(['uuid' => $request->po_uuid], $request->except('_token'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New PO Creation',
                    'task_description' => $isPoCreated->unique_id,
                    'task_url' => 'modules/purchase-order/view/' . $isPoCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-purchase-order',
                    'related_id' => $isPoCreated->id
                ]);

                if ($request->items) {
                    foreach ($request->items as $item) {
                        if (isset($item['item_id'])) {
                            $poItemData = [
                                'purchase_order_id' => $isPoCreated->id,
                                'category_id' => $item['category_id'],
                                'asset_type_id' => $item['asset_type_id'],
                                'asset_id' => $item['asset_id'],
                                'unique_id' => $item['unique_id'],
                                'amount' => $item['amount'],
                                'discount_type' => $item['discount_type'],
                                'discount' => $item['discount'],
                                'tax_type' => $item['tax_type'],
                                'tax' => $item['tax'],
                                'quantity' => $item['quantity'],
                                'unit' => $item['unit'],
                                'total_amount' => $item['total_amount'],
                                'specifications' => $item['specifications'],
                                'description' => $item['description'],
                            ];
                            $this->assetService->addOrUpdatePurchaseOrderItems(['uuid' => $item['uuid']], $poItemData);
                        }
                    }
                }
                if ($request->payment_schedule) {
                    foreach ($request->payment_schedule as $ps_item) {
                        $psItemData = [
                            'purchase_order_id' => $isPoCreated->id,
                            'percent' => $ps_item['percent'],
                            'payment_type' => $ps_item['payment_type'],
                            'payment_credit_days' => $ps_item['payment_credit_days'],
                            'notify_days' => $ps_item['notify_days'],
                            'descriptions' => $ps_item['descriptions'],
                            'amount' => $ps_item['amount'],
                            'attachment_document' => $ps_item['attachment_document'] ?? null,
                        ];
                        $this->assetService->addOrUpdatePaymentSchedules(['uuid' => null], $psItemData);
                    }
                }

                DB::commit();
                return $this->responseJson(true, 200, 'Purchase Order submitted successfully.', [
                    'redirect_url' => route('admin.po.list')
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $quotations = $this->assetService->getAllQuotations(['is_selected' => 1]);
        $typeCategories = $this->getAssetCategoryTree();
        $assetTypes = $this->getAssetTypesTree();
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $employees = $this->userService->getEmployees();
        $locations = $this->assetService->listLocations();
        $termsConditions = $this->assetService->findTermAndConditions(['is_active' => '1']);

        return view('admin.purchase-order.add', compact('entities', 'quotations', 'typeCategories', 'assetTypes', 'vendors', 'states', 'employees', 'locations', 'termsConditions'));
    }


    public function viewPurchaseOrder(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('View Purchase Order');
        $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
        //dd($poData);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $quotations = $this->assetService->getAllQuotations(['is_selected' => 1]);
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
        // dd($poItems);
        $employees = $this->userService->getEmployees();
        $locations = $this->assetService->listLocations();
        $paymentScheduleList = $this->assetService->listPaymentSchedules(['purchase_order_id' => $poData->id]);

        // dd($poData->billing_address['billing_state_id']);
        //    dd($poData->delivery_address['delivery_state_id'] ?? 0);
        $deliveryCities = $this->cityService->getCityByState($poData->delivery_address['delivery_state_id'] ?? 4853);

        $billingCities = $this->cityService->getCityByState($poData->billing_address['billing_state_id'] ?? 4853);
        // dd($cities);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }

        $checkPOApproval = $this->assetService->checkPurchaseOrderApproval($poData->id, auth()->user()->id);

        return view('admin.purchase-order.details', compact('entities', 'quotations', 'vendors', 'states', 'poData', 'poItems', 'employees', 'locations', 'billingCities', 'deliveryCities', 'paymentScheduleList', 'uuid', 'checkPOApproval'));
    }



    public function editPurchaseOrder(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Purchase Order');

        if ($request->ajax()) {

            $rules = [
                'po_date' => 'required',
                'valid_date_from' => 'required',
                'valid_date_to' => 'required',
            ];
            $messages = [
                'po_date'=>"Order Date is required",
                'valid_date_from'=>"Valid Date From is required",
                'valid_date_to'=>"Valid Date To is required",
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if(!$request->delivery_address[1]['delivery_state_id'] || !$request->delivery_address[1]['delivery_street_address']){
                $validator->after(function ($validator) {
                    $validator->errors()->add('delivery_address', 'Delivery address is required');
                });
            }
            if(!$request->billing_address['billing_state_id'] || !$request->billing_address['billing_street_address']){
                $validator->after(function ($validator) {
                    $validator->errors()->add('billing_address', 'Billing address is required');
                });
            }
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd($request->terms_conditions);
                $is_gst_checked = ($request->is_gst_checked == 'on') ? 1 : 0;

                $termsConditions = [];
                if ($request->terms_conditions) {
                    foreach ($request->terms_conditions as $terms_condition) {
                        if (isset($terms_condition['id'])) {
                            $termsConditions[] = [
                                'id' => $terms_condition['id'],
                                'title' => $terms_condition['title'],
                                'type' => $terms_condition['type'],
                                'description' => $terms_condition['description'],
                            ];
                        }
                    }
                }

                // dd($termsConditions);
                $request->merge(['is_gst_checked' => $is_gst_checked,'terms_conditions' => $termsConditions]);

                $isPoCreated = $this->assetService->addOrUpdatePurchaseOrder(['uuid' => $request->uuid], $request->except('_token'));


                if ($request->items) {
                    foreach ($request->items as $item) {
                        $poItemData = [
                            'purchase_order_id' => $isPoCreated->id,
                            'category_id' => $item['category_id'],
                            'asset_type_id' => $item['asset_type_id'],
                            'asset_id' => $item['asset_id'],
                            'unique_id' => $item['unique_id'],
                            'amount' => $item['amount'],
                            'discount_type' => $item['discount_type'],
                            'discount' => $item['discount'],
                            'tax_type' => $item['tax_type'],
                            'tax' => $item['tax'],
                            'quantity' => $item['quantity'],
                            'unit' => $item['unit'],
                            'total_amount' => $item['total_amount'],
                            'specifications' => $item['specifications'],
                            'description' => $item['description'],
                        ];
                        $this->assetService->addOrUpdatePurchaseOrderItems(['uuid' => $item['uuid']], $poItemData);
                    }

                    $psItems = $this->assetService->findPsItems(['purchase_order_id' => $isPoCreated->id])->each(function ($item) {
                        $item->forceDelete();
                    });

                    if ($request->payment_schedule) {
                        foreach ($request->payment_schedule as $ps_item) {
                            $psItemData = [
                                'purchase_order_id' => $isPoCreated->id,
                                'percent' => $ps_item['percent'],
                                'payment_type' => $ps_item['payment_type'],
                                'payment_credit_days' => $ps_item['payment_credit_days'],
                                'notify_days' => $ps_item['notify_days'],
                                'descriptions' => $ps_item['descriptions'],
                                'amount' => $ps_item['amount'],
                                'attachment_document' => $ps_item['attachment_document'] ?? null,
                            ];
                            $this->assetService->addOrUpdatePaymentSchedules(['uuid' => null], $psItemData);
                        }
                    }
                }

                DB::commit();
                return $this->responseJson(true, 200, 'Purchase Order Updated successfully.', [
                    'redirect_url' => route('admin.po.list')
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }


        $quotationId = uuidtoid($uuid, 'purchase_orders');
        //dd($quotationId);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $quotations = $this->assetService->getAllQuotations(['is_selected' => 1]);
        $typeCategories = $this->getAssetCategoryTree();
        $assetTypes = $this->getAssetTypesTree();
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
        $quotationData = $this->assetService->findQuotationById($poData->quotation_id);
        $employees = $this->userService->getEmployees();
        $locations = $this->assetService->listLocations();

        $deliveryCities = $this->cityService->getCityByState($poData->delivery_address['delivery_state_id'] ?? 4853);

        $billingCities = $this->cityService->getCityByState($poData->billing_address['billing_state_id'] ?? 4853);
        $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');

        $paymentScheduleList = $this->assetService->listPaymentSchedules(['purchase_order_id' => $poData->id]);

        $termsConditions = $this->assetService->findTermAndConditions(['is_active' => '1']);

        $existingTermsConditionIds=[];
        return view('admin.purchase-order.edit', compact('entities', 'quotations', 'typeCategories', 'assetTypes', 'vendors', 'states', 'quotationData', 'poData', 'poItems', 'employees', 'locations', 'deliveryCities', 'billingCities', 'paymentScheduleList', 'uuid','termsConditions','existingTermsConditionIds'));
    }


    public function sendPurchaseOrderForApproval(Request $request, $uuid)
    {

        $this->setPageTitle('Purchase Order Approval Status');
        $purchaseOrderId = uuidtoid($uuid, 'purchase_orders');
        $purchaseOrder = $this->assetService->findPurchaseOrderById($purchaseOrderId);
        $quotation = $this->assetService->findQuotationById($purchaseOrder->quotation_id);
        if ($purchaseOrder->created_by == auth()->user()->id || auth()->user()->hasRole('super-admin')) {
            if ($request->ajax()) {
                if (!$request->level_user[array_key_last($request->level_user)]) {
                    return $this->responseJson(false, 299, 'Approver field is required.', '');
                }
                DB::beginTransaction();
                try {
                    if (count($request->level_user)) {
                        $count = 0;
                        $addUserData = $this->userService->findUserById($purchaseOrder->added_by);
                        $creatUserData = $this->userService->findUserById($purchaseOrder->created_by);
                        foreach ($request->level_user as $k => $level_user) {
                            $data = [
                                'purchase_order_id' => $purchaseOrderId,
                                'user_id' => $level_user,
                                'level' => $k,
                                'status' => ($count == 0) ? 0 : null
                            ];
                            $userData = $this->userService->findUserById($request->level_user[$k]);
                            $notiUser = $this->userService->findUserById($request->level_user[1]);
                            if ($k == 1) {
                                $notiData = [
                                    'form_name' => "You got a PO approval request for PO ID #" . $purchaseOrder->unique_id,
                                    'po_uuid' => $purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoApproveNotification($notiData));
                            } else {
                                $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                                $notiData = [
                                    'form_name' => $fullname . " got a PO approval request for PO ID #" . $purchaseOrder->unique_id,
                                    'po_uuid' => $purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoApproveNotification($notiData));
                                $addUserData->notify(new PoApproveNotification($notiData));
                                $creatUserData->notify(new PoApproveNotification($notiData));
                            }
                            $count++;
                            $isApprovalCreated = $this->assetService->createOrUpdatePoApproval($data);
                        }
                        if (count($request->level_user) == $count && $isApprovalCreated) {
                            $attributes = ['status' => 0];
                            $isSendForApproval = $this->assetService->updatePoStatus($attributes, $purchaseOrderId);


                            // $productName = '';
                            // if ($purchaseOrder->items != null)
                            //     foreach ($purchaseOrder->items as $itemDetail) {
                            //         $findAsset = Asset::find($itemDetail['asset_id']);
                            //         $productName .= "{$findAsset->asset_name}, ";
                            //     }
                            // $productName = rtrim($productName, ', ');



                            $table = '
                            <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">Name</th>
                                        <th style="text-align: left;">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>';
                            if ($purchaseOrder->items != null && count($purchaseOrder->items) > 0) {
                                foreach ($purchaseOrder->items as $itemDetail) {
                                    $findAsset = Asset::find($itemDetail['asset_id']);
                                    $productName = $findAsset->asset_name;
                                    $quantity = $itemDetail['quantity'];
                                    $table .= '
                                    <tr>
                                        <td>' . htmlspecialchars($productName) . '</td>
                                        <td>' . htmlspecialchars($quantity) . '</td>
                                    </tr>';
                                }
                            } else {
                                $table .= '
                                <tr>
                                    <td colspan="2" style="text-align: center;">No data found</td>
                                </tr>';
                            }

                            $table .= '
                                </tbody>
                            </table>';




                            // dd($notiUser->email);
                            DB::commit();
                            $mailData = [
                                'to' => $notiUser->email,
                                'from' => env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'A Purchase Order (PO) has been generated based on the approved quotation for the RFQ Number: #' . $quotation->rfq?->unique_id . ' Below are the details of the PO submitted for your approval:<br><br><br>Purchase Order Details:',
                                'content' => 'PO Number: #' . $purchaseOrder->unique_id . '<br>RFQ ID: ' . $quotation->rfq?->unique_id . '<br>Vendor Name: ' . $purchaseOrder->vendor?->full_name . ' <br>Product Name:<br>' . $table . ' <br>Total Amount: ' . $purchaseOrder->total_amount . ' <br>Payment Terms: ' . $purchaseOrder->payment_terms . '<br>Delivery Timeline: ' . $purchaseOrder->delivery_terms . '<br><br><br>To review and approve the Purchase Order, kindly click on the link below: <a href="' . route('admin.po.view', $purchaseOrder->uuid) . '" class="edit_icon">' . $purchaseOrder->unique_id . '</a>',
                                'subject' => 'Purchase Order Generated and Submitted for Approval - PO #' . $purchaseOrder->unique_id,
                                'greetings' => 'Dear ' . $notiUser->full_name . ',',
                                'end_greetings' => 'Best Regards,<br>DHC',
                                'from_user' => env('MAIL_FROM_NAME')
                            ];
                            Mail::send(new SendMailable($mailData));
                            return $this->responseJson(true, 200, 'PO successfully sent for approval.', [
                                'redirect_url' => route('admin.po.send.for.approval', $uuid)
                            ]);
                        }
                    }
                } catch (\Throwable $e) {
                    DB::rollBack();
                    logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                    return $this->responseJson(false, 500, $e->getMessage(), '');
                }
            }

            $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();
            // dd($levelUsers);
            unset($levelUsers[$purchaseOrder->created_by]);
            $purchaseOrderApprovals = $this->assetService->getPoApprovals(['purchase_order_id' => $purchaseOrderId]);

            //dd($purchaseOrderApprovals);
            return view('admin.purchase-order.send-for-approval', compact('uuid', 'purchaseOrder', 'levelUsers', 'purchaseOrderApprovals'));
        } else {
            abort(401);
        }
    }

    public function listAssetReceiptNote()
    {
        $this->setPageTitle('Asset Receipt Notes List');

        $locations = $this->assetService->listLocations();
        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $employees = $this->userService->getEmployees();
        $arns = $this->assetService->findAssetReceiptNotes([]);

        return view('admin.asset-receipt-note.index', compact('purchaseOrders', 'employees', 'locations', 'arns'));
    }

    public function addAssetReceiptNote(Request $request)
    {
        $this->setPageTitle('Add Asset Receipt Note');
        if ($request->ajax()) {
            $rules = [
                'po_id' => 'required|exists:purchase_orders,uuid',
                'challan_no' => 'required',
                // 'challan_no' => 'required|unique:asset_receipt_notes,challan_no,',
                'receiver_id' => 'required|exists:users,id',
                'received_location_id' => 'required|exists:locations,id',
                'received_date' => 'required|date',
            ];
            $messages = [
                'po_id' => 'PO ID field is required.',
                'challan_no.required' => 'Challan No/Way-bill No/In-ward document number is required',
                // 'challan_no.unique' => 'This No already taken',
                'receiver_id' => 'Receiver Name is required.',
                'received_location_id' => 'Receiver Location is required.',
                'received_date' => 'Received Date is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                //dd($request->all());
                $request->merge(['purchase_order_id' => uuidtoid($request->po_id, 'purchase_orders'), 'added_by' => auth()->user()->id]);
                $isArnCreated = $this->assetService->addOrUpdateAssetReceiptNote(['uuid' => null], $request->except('_token'));

                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New ARN Creation',
                    'task_description' => $isArnCreated->unique_id,
                    'task_url' => 'modules/asset-receipt-note/view/' . $isArnCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-arn',
                    'related_id' => $isArnCreated->id
                ]);


                if ($request->items) {
                    foreach ($request->items as $item) {
                        if (isset($item['item_id'])) {
                            $arnItemData = [
                                'asset_receipt_note_id' => $isArnCreated->id,
                                'category_id' => $item['category_id'],
                                'asset_type_id' => $item['asset_type_id'],
                                'asset_id' => $item['asset_id'],
                                'unit' => $item['unit'],
                                'amount' => $item['amount'],
                                'po_quantity' => $item['po_quantity'],
                                'received_quantity' => $item['received_quantity'],
                                'remaining_quantity' => $item['received_quantity'],
                                'description' => $item['description'],
                                'specifications' => $item['specifications'],
                            ];
                            $this->assetService->addOrUpdateAssetReceiptNoteItems(['uuid' => $item['uuid']], $arnItemData);
                        }
                    }
                }

                DB::commit();
                return $this->responseJson(true, 200, 'ARN submitted successfully.', [
                    'redirect_url' => route('admin.arn.list')
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $locations = $this->assetService->listLocations();
        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $employees = $this->userService->getEmployees();
        $lastId = AssetReceiptNote::orderBy('id', 'desc')->pluck('id')->first();
        $unique_id = 'ARNI' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        //dd($purchaseOrders);
        return view('admin.asset-receipt-note.add', compact('employees', 'locations', 'purchaseOrders', 'unique_id'));
    }

    public function editAssetReceiptNote(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Asset Receipt Note');

        if ($request->ajax()) {
            $id = uuidtoid($uuid, 'asset_receipt_notes');
            $rules = [
                'challan_no' => 'required',
                // 'challan_no' => 'required|unique:asset_receipt_notes,challan_no,' . $id,
                'receiver_id' => 'required|exists:users,id',
                'received_location_id' => 'required|exists:locations,id',
                'received_date' => 'required|date',
            ];
            $messages = [
                'challan_no' => 'Challan No/Way-bill No/In-ward document number is required.',
                'receiver_id' => 'Receiver Name is required.',
                'received_location_id' => 'Receiver Location is required.',
                'received_date' => 'Received Date is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['added_by' => auth()->user()->id]);
                $isArnUpdated = $this->assetService->addOrUpdateAssetReceiptNote(['uuid' => $uuid], $request->except('_token'));
                $is_arnitems_deleted = $this->assetService->getAllAssetReceiptNoteItems(['asset_receipt_note_id' => $isArnUpdated->id])->each->forceDelete();
                if ($request->items) {
                    foreach ($request->items as $item) {
                        if (isset($item['item_id'])) {
                            $arnItemData = [
                                'asset_receipt_note_id' => $isArnUpdated->id,
                                'category_id' => $item['category_id'],
                                'asset_type_id' => $item['asset_type_id'],
                                'asset_id' => $item['asset_id'],
                                'unit' => $item['unit'],
                                'amount' => $item['amount'],
                                'po_quantity' => $item['po_quantity'],
                                'received_quantity' => $item['received_quantity'],
                                'remaining_quantity' => $item['received_quantity'],
                                'description' => $item['description'],
                                //'specifications' => $item['specifications'],
                            ];
                            // $this->assetService->addOrUpdateAssetReceiptNoteItems(['uuid' => $item['uuid']], $arnItemData);
                            $this->assetService->addOrUpdateAssetReceiptNoteItems(['uuid' => null], $arnItemData);
                        }
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, 'ARN Updated successfully.', [
                    'redirect_url' => route('admin.arn.list')
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        //dd($arnData);
        $arnData = $this->assetService->findAssetReceiptNoteById(uuidtoid($uuid, 'asset_receipt_notes'));
        $locations = $this->assetService->listLocations();
        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $employees = $this->userService->getEmployees();
        $arnItems = $this->assetService->findAssetReceiptNoteItems(['asset_receipt_note_id' => $arnData->id], 'id', 'asc');
        $purchaseOrderData = $this->assetService->findPoId($arnData->purchase_order_id);
        return view('admin.asset-receipt-note.edit', compact('employees', 'locations', 'purchaseOrders', 'arnData', 'purchaseOrderData', 'arnItems', 'uuid'));
    }


    public function viewAssetReceiptNote(Request $request, $uuid,)
    {
        $this->setPageTitle('View Asset Receipt Note');
        $arnData = $this->assetService->findAssetReceiptNoteById(uuidtoid($uuid, 'asset_receipt_notes'));
        $arnItems = $this->assetService->findAssetReceiptNoteItems(['asset_receipt_note_id' => $arnData->id]);
        $purchaseOrderData = $this->assetService->findPoId($arnData->purchase_order_id);
        $employeeData = $this->userService->findUserById($arnData->receiver_id);
        $locationData = $this->assetService->findLocationById($arnData->received_location_id);
        return view('admin.asset-receipt-note.details', compact('arnData', 'purchaseOrderData', 'arnItems', 'employeeData', 'locationData', 'uuid'));
    }
    public function manageArnItemStock(Request $request, $arn_uuid, $arn_item_uuid)
    {
        $this->setPageTitle('Manage Asset Stock');
        $arnData = $this->assetService->findAssetReceiptNoteById(uuidtoid($arn_uuid, 'asset_receipt_notes'));
        $arnItemData = $this->assetService->findAssetReceiptNoteItemById(uuidtoid($arn_item_uuid, 'asset_receipt_note_items'));
        $assetData = $this->assetService->findById($arnItemData->asset_id);

        $assetStock = $this->assetService->getAssetStock(['asset_id' => $assetData->id, 'location_id' => $arnData->received_location_id]);

        // dd($request->all());
        $locations = $this->assetService->listLocations();
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        //dd($assetStock);
        if ($request->ajax()) {
            $rules = [
                'location_id' => 'required',
                'entity_id' => 'required',
                'new_stock' => 'required',
                'inventories.*.unique_id' => 'required',
                'inventories.*.capacity_specs' => 'required',
                'inventories.*.asset_condition' => 'required',
                'inventories.*.purchase_date' => 'required',
                //'inventories.*.warranty_licence_date' => 'required',
                'inventories.*.duration' => 'required',
            ];
            $messages = [
                'location_id' => 'Location is required.',
                'entity_id' => 'Entity is required.',
                'new_stock' => 'New Stock is required.',
                'inventories.*.unique_id' => ($assetData->assettype?->unique_number_type == 'license') ? 'License Number is required.' : 'Serial Number is required.',
                'inventories.*.capacity_specs' => ($assetData->assettype?->unique_number_type == 'license') ? 'Specifications is required.' : 'Capacity / Specifications is required.',
                'inventories.*.asset_condition' => 'Asset Condition is required.',
                'inventories.*.purchase_date' => 'Purchase Date is required.',
                //'inventories.*.warranty_licence_date' => ($assetData->assettype?->unique_number_type == 'license') ? 'License Expiry Date is required' : 'Warranty Date is required',

                'inventories.*.duration' => 'Duration is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                // dd($request->all());

                $assetLocationStock = $this->assetService->getAssetStock(['asset_id' => $assetData->id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id]);
                $assetData = $this->assetService->findById($request->asset_id);
                $assetTypeData = $this->assetTypeService->findById($assetData->asset_type_id); //entity and assetType name
                $locationData = $this->assetService->findLocationById($request->location_id);

                // dd($request->all());
                $isStockUpdated = $this->assetService->addOrUpdateAssetStock(['uuid' => $assetLocationStock?->uuid ?? null], $request->except(['_token', 'new_stock', 'inventories', 'amount']));
                // dd($isStockUpdated);
                if ($isStockUpdated) {
                    if ($request->inventories) {
                        foreach ($request->inventories as $inventory) {
                            $month = date('m', strtotime($inventory['purchase_date']));
                            $year = date('Y', strtotime($inventory['purchase_date']));
                            $lastId = Inventory::orderBy('id', 'desc')->pluck('id')->first();
                            // $entity = $arnData->purchaseOrder->entity->name;
                            $entity = $this->categoryService->findCategoryById($request->entity_id);
                            $identification_no = $this->generateIdentificationCode($entity->name, $locationData->street_address, $assetTypeData->name, $month, $year, str_pad($lastId + 1, 4, '0', STR_PAD_LEFT));
                            $inventory['identification_no'] = $identification_no;
                            $inventory['amount'] = $request->amount;



                            $purchaseDate = Carbon::parse($inventory['purchase_date']);
                            // $warrantyLicenceDate = $purchaseDate->addDays((int)$inventory['duration'] * 30);
                            $warrantyLicenceDate = $purchaseDate->addMonths((int)$inventory['duration']);
                            $inventory['warranty_licence_date'] = $warrantyLicenceDate->toDateString();

                            //dd($inventory);




                            $isInventoryCreated = $isStockUpdated->inventories()->updateOrCreate(['unique_id' => $inventory['unique_id']], $inventory);

                            // dd($isInventoryCreated->id);
                            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => 'New Stock Addition',
                                'task_description' => $isStockUpdated->unique_id,
                                'task_url' => 'modules/assetstock/inventory/' . $isStockUpdated->uuid,
                                'added_by' => auth()->user()->id,
                                'type' => 'add-stock',
                                'related_id' => $isStockUpdated->id,
                                'inventory_id' => $isInventoryCreated->id
                            ]);
                        }
                    }

                    $arnIData = [
                        'remaining_quantity' => $arnItemData['remaining_quantity'] - $request->new_stock,
                    ];
                    $isArnItemUpdated = $this->assetService->addOrUpdateAssetReceiptNoteItems(['uuid' => $arnItemData->uuid], $arnIData);

                    if ($isArnItemUpdated) {
                        $logData = [
                            'asset_stock_id' => $isStockUpdated?->id,
                            'asset_id' => $arnItemData->asset_id,
                            'location_id' => $arnData->received_location_id,
                            'entity_id' => $request->entity_id,
                            'type' => 'add',
                            'quantity' => $request->new_stock
                        ];
                        $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                    }
                }


                DB::commit();
                return $this->responseJson(true, 200, 'Asset Stock Added successfully.', [
                    'redirect_url' => route('admin.arn.view', $arnData->uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        return view('admin.asset.stock.manage', compact('arnData', 'arnItemData', 'assetData', 'assetStock', 'locations', 'entities'));
    }
    public function poPdfDownload(Request $request, $uuid)
    {

        try {
            $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
            $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
            $vendorData = $this->vendorService->findUserById($poData->vendor_id);
            $dompdf = new Dompdf();
            $html = view('admin.purchase-order.pdf', compact('poData', 'vendorData', 'poItems'));
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'potrait');
            $dompdf->render();
            $pdfOutput = $dompdf->output();
            $filename = 'Purchase_order_details_' . time() . '.pdf';
            return Response::make($pdfOutput, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }





    public function poWordDownload(Request $request, $uuid)
    {
        try {
            $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
            $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
            $vendorData = $this->vendorService->findUserById($poData->vendor_id);

            $phpWord = new PhpWord();
            $sectionStyle = [
                'orientation' => 'portrait',
                'paperSize' => 'A4'
            ];
            $section = $phpWord->addSection($sectionStyle);

            $imagePath = public_path('assets/images/logo.png');
            $section->addImage($imagePath, [
                'width' => 120,
                'height' => 55,
                'alignment' => Jc::CENTER
            ]);

            $headingStyle = [
                'name' => 'Arial',
                'size' => 24, // H1 size
                'color' => '0000FF', // Blue color
                'bold' => true,
                'alignment' => Jc::CENTER
            ];
            $section->addText('Purchase Order', $headingStyle, ['alignment' => Jc::CENTER]);
            $createdAt = $vendorData->created_at->format('jS F Y');
            $vendorName = $vendorData->full_name ?? '';
            $vendorAddress = $vendorData->address ?? '';

            $textStyle = [
                'name' => 'Arial',
                'size' => 12,
                'color' => '000000'
            ];
            $paragraphStyle = [
                'alignment' => Jc::LEFT,
                'spaceBefore' => 0,
                'spaceAfter' => 0
            ];
            $headingStyle = [
                'name' => 'Arial',
                'size' => 12,
                'color' => '000000', // Blue color
                'bold' => true,
                'alignment' => Jc::LEFT
            ];
            $section->addText("Purchase Order Number: #$poData->unique_id ", $headingStyle, ['alignment' => Jc::LEFT]);

            $section->addText("Created at: $createdAt", $textStyle, $paragraphStyle);
            $section->addText("Vendor Name: $vendorName", $textStyle, $paragraphStyle);
            $section->addText("Vendor Address: $vendorAddress", $textStyle, $paragraphStyle);

            $section->addTextBreak(1);
            $line_before_items = str_replace('&', 'and', strip_tags($poData->line_before_items));

            $section->addText($line_before_items, $textStyle, $paragraphStyle);


            $headingStyle = [
                'name' => 'Arial',
                'size' => 18,
                'color' => '000000', // Blue color
                'bold' => true,
                'alignment' => Jc::LEFT
            ];
            $section->addText('Item Name and Model ', $headingStyle, ['alignment' => Jc::LEFT]);
            $tableStyle = [
                'borderSize' => 6,
                'borderColor' => '999999',
                'cellMargin' => 80
            ];
            $firstRowStyle = ['bgColor' => 'FFFF00'];
            $phpWord->addTableStyle('Fancy Table', $tableStyle, $firstRowStyle);
            $table = $section->addTable('Fancy Table');


            $table->addRow();
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Sr No');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Asset Name / Model No');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Capacity / Specifications');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Qty');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Unit');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Unit Rate');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Amount');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Tax ');
            $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Final Price ');

            foreach ($poItems as $index => $poItem) {
                $taxType = $poItem->tax_type;
                $tax = $poItem->tax ? $poItem->tax : 0;
                $text = "($taxType) + $tax";

                $table->addRow();
                $table->addCell(2000)->addText(++$index);

                $table->addCell(2000)->addText(
                    ($poItem->asset?->assettype?->name ?? '') . ' - ' . ($poItem->asset?->asset_name ?? '')
                );

                $table->addCell(2000)->addText(str_replace('&', 'and', strip_tags($poItem->specifications)));
                $table->addCell(2000)->addText($poItem->quantity); // Replace 'property4' with actual property name
                $table->addCell(2000)->addText($poItem->unit); // Replace 'property5' with actual property name
                $table->addCell(2000)->addText($poItem->amount); // Replace 'property6' with actual property name
                $table->addCell(2000)->addText($poItem->quantity * $poItem->amount); // Replace 'property7' with actual property name
                $table->addCell(2000)->addText($text); // Replace 'property8' with actual property name
                $table->addCell(2000)->addText($poItem->total_amount);
            }


            $table->addRow();
            $table->addCell(12000, ['gridSpan' => 7])->addText('Total:', ['bold' => true], ['alignment' => Jc::RIGHT]);

            $totalValue = number_format((float) $poData->item_total, 2, '.', ',');
            $table->addCell(4000, ['gridSpan' => 2])->addText(
                "Rs $totalValue",
                ['bold' => true],
                ['alignment' => Jc::CENTER]
            );

            $discountType = $poData->discount_type == 'fixed' ? 'fixed' : '%';
            $discountedValue = $poData->discount_type == 'percentage'
                ? ($poData->item_total * $poData->discount) / 100
                : $poData->discount;


            $formattedDiscountedValue = number_format((float) $discountedValue, 2, '.', ',');



            $table->addRow();
            $table->addCell(12000, ['gridSpan' => 7])->addText(
                "Discount ($discountType):",
                ['bold' => true],
                ['alignment' => Jc::RIGHT]
            );

            $table->addCell(4000, ['gridSpan' => 2])->addText(
                "Rs - $formattedDiscountedValue",
                ['bold' => true],
                ['alignment' => Jc::CENTER]
            );


            if ($poData && $poData->discount) {
                if ($poData->discount_type == 'percentage') {
                    $discountedTotalValue = $poData->item_total - ($poData->item_total * $poData->discount) / 100;
                } else {
                    $discountedTotalValue = $poData->item_total - $poData->discount;
                }
            } else {
                $discountedTotalValue = $poData?->item_total ?? 0;
            }

            $formattedDiscountedTotalValue = number_format((float) $discountedTotalValue, 2, '.', ',');

            $table->addRow();
            $table->addCell(12000, ['gridSpan' => 7])->addText('Discounted Total:', ['bold' => true], ['alignment' => Jc::RIGHT]);
            $table->addCell(4000, ['gridSpan' => 2])->addText("Rs $formattedDiscountedTotalValue", ['bold' => true], ['alignment' => Jc::CENTER]);


            if ($poData->tax != null) {
                $taxType = $poData->tax_type == 'CGST/SGST' ? 'CGST/SGST' : 'IGST';
                $taxValue = $poData->tax ?? 0;

                $table->addRow();
                $table->addCell(12000, ['gridSpan' => 7])->addText(
                    'Tax:',
                    ['bold' => true],
                    ['alignment' => Jc::RIGHT]
                );

                $table->addCell(4000, ['gridSpan' => 2])->addText(
                    "$taxType $taxValue (%)",
                    ['bold' => true],
                    ['alignment' => Jc::CENTER]
                );
            }


            $table->addRow();
            $table->addCell(12000, ['gridSpan' => 7])->addText('Grand Total(Including GST)', ['bold' => true], ['alignment' => Jc::RIGHT]);
            $formattedGrandTotalValue = number_format((float) $poData->total_amount, 2, '.', ',');
            $table->addCell(4000, ['gridSpan' => 2])->addText("Rs $formattedGrandTotalValue", ['bold' => true], ['alignment' => Jc::CENTER]);


            $section->addTextBreak(1);
            $headingStyle = [
                'name' => 'Arial',
                'size' => 16,
                'color' => 'BLACK',
                'bold' => true,
                'alignment' => Jc::LEFT
            ];
            $section->addText('Terms and condition', $headingStyle, ['alignment' => Jc::LEFT]);
            $section->addTextBreak(1);

            $headingStyle = [
                'name' => 'Arial',
                'size' => 12,
                'color' => 'BLACK',
                'bold' => true,
                'alignment' => Jc::LEFT
            ];




            foreach ($poData->terms_conditions as $tnc) {
                $title = str_replace('&', 'and', strip_tags($tnc['title']));
                $content = str_replace('&', 'and', strip_tags($tnc['description']));

                $section->addText($title, $headingStyle, ['alignment' => Jc::LEFT]);
                $section->addText($content, $textStyle, ['alignment' => Jc::LEFT]);
            }


            $filename = 'Purchase_order_details' . time() . '.docx';
            $tempFile = tempnam(sys_get_temp_dir(), 'phpword');
            $phpWord->save($tempFile, 'Word2007');

            return response()->download($tempFile, $filename)->deleteFileAfterSend(true);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }
    public function manageReturn(Request $request, $arn_uuid, $arn_item_uuid)
    {
        $this->setPageTitle('Manage Return');
        if ($request->ajax()) {
            $msg = 'Something went wrong';
            $rules = [
                'return_quantity' => 'required',
            ];
            $messages = [
                'return_quantity' => 'Return Qty is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                //dd($request->all());

                $arnItemData = [
                    'return_quantity' => $request->return_quantity,
                    'return_reasons' => $request->return_reasons,
                    // 'remaining_quantity' => $request->received_quantity - $request->return_quantity
                    'remaining_quantity' => $request->remaining_quantity - $request->return_quantity
                ];
                // dd($arn_item_uuid);
                //dd($arnItemData);
                $this->assetService->addOrUpdateAssetReceiptNoteItems(['uuid' => $arn_item_uuid], $arnItemData);

                // $arnItemData = $this->assetService->findAssetReceiptNoteItemById(uuidtoid($arn_item_uuid, 'asset_receipt_note_items'));
                // $arnData = $arnItemData->arn;
                // // $arnData = $this->assetService->findAssetReceiptNoteById($arnItemData->asset_receipt_note_id);
                // $request->merge(['asset_id' => $arnItemData->asset_id]);
                // $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => null], $request->except('_token'));

                // if($isIssued){
                //     $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $arnItemData->asset_id,'location_id' => $arnData->received_location_id ], $request->quantity,'decrease' );
                //     if($isUpdated){
                //         $filterConditions = ['asset_id' => $arnItemData->asset_id,'location_id' => $arnData->received_location_id ];
                //         $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                //         $logData = [
                //             'asset_stock_id' => $assetStockData->id,
                //             'asset_id' => $arnItemData->asset_id,
                //             'location_id' => $arnData->received_location_id,
                //             'type' => 'substruct',
                //             'quantity' => $request->quantity
                //         ];
                //         $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                //         $msg = 'This Item has been issued';
                //     }
                // }

                DB::commit();
                return $this->responseJson(true, 200, "Return submitted", [
                    'redirect_url' => route('admin.arn.view', [$arn_uuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }



        $arnItemData = $this->assetService->findAssetReceiptNoteItemById(uuidtoid($arn_item_uuid, 'asset_receipt_note_items'));
        // $arnData = $this->assetService->findAssetReceiptNoteById(uuidtoid($arn_uuid, 'asset_receipt_notes'));
        $arnData = $this->assetService->findAssetReceiptNoteById($arnItemData->asset_receipt_note_id);
        //$assetData = $this->assetService->findById($arnItemData->asset_id);
        $employees = $this->userService->getEmployees();

        //dd($arnItemData);////item id
        $inventories = $this->assetService->getInventories(['asset_id' => $arnItemData->asset_id]);

        $assetStock = $this->assetService->getAssetStock(['asset_id' => $arnItemData->asset_id, 'location_id' => $arnData->received_location_id]);
        $locations = $this->assetService->listLocations();
        $locationData = $this->assetService->findLocationById($arnData->received_location_id);
        $locationId = $arnData->received_location_id;
        $assetIssues = (!$arnItemData->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $arnItemData->asset_id, 'location_id' => $arnData->received_location_id]) : null;
        // dd($inventories);
        return view('admin.asset.stock.return', compact('arnData', 'assetStock', 'employees', 'inventories', 'locationData', 'arnItemData', 'arn_item_uuid', 'arn_uuid', 'locationId', 'assetIssues'));
    }





    /*********************** Invoice ***********************/

    public function listInvoices($uuid = null)
    {
        $this->setPageTitle('Invoice List');
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        return view('admin.purchase-order.invoice.index', compact('uuid', 'vendors'));
    }
    public function addInvoice(Request $request, $poUuid = null)
    {
        $this->setPageTitle('Add Invoice');
        if ($request->ajax()) {
            $rules = [
                'purchase_order_id' => 'required|exists:purchase_orders,uuid',
                'vendor_id' => 'required|exists:vendors,id',
                'created_by' => 'required|exists:users,id',
                'party_invoice_number' => 'required|string',
                'invoice_date' => 'required|date',
                'challan_no' => 'required',
                'billing_from_location' => 'required',
                'billing_location' => 'required'
            ];
            $messages = [
                'purchase_order_id' => 'Purchase order ID is required.',
                'vendor_id' => 'Vendor is required.',
                'created_by' => 'Created By is required.',
                'party_invoice_number' => 'Party invoice number is required.',
                'invoice_date' => 'Invoice Date is required.',
                'challan_no' => 'Challan No/Way-bill No/In-ward document number is required.',
                'billing_from_location' => 'Billing From Address is required.',
                'billing_location' => 'Billing To Address is required.'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd($request->all());
                $request->merge(['purchase_order_id' => uuidtoid($request->purchase_order_id, 'purchase_orders')]);
                $isInvoiceCreated = $this->assetService->addOrUpdateInvoice(['uuid' => null], $request->except('_token'));
                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Invoice Creation',
                    'task_description' => $isInvoiceCreated->unique_id,
                    'task_url' => 'modules/invoice/view/' . $isInvoiceCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-invoice',
                    'related_id' => $isInvoiceCreated->id
                ]);

                if ($isInvoiceCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Purchase Order Invoice created successfully.', [
                        'redirect_url' => $poUuid ? route('admin.po.invoice.list', $poUuid) : route('admin.invoice.inv.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $poData = $poUuid ? $this->assetService->findPoId(uuidtoid($poUuid, 'purchase_orders')) : null;

        $employees = $this->userService->getEmployees();
        $lastId = PurchaseOrderInvoice::orderBy('id', 'desc')->pluck('id')->first() ?? 0;
        $unique_id = 'INVC' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);

        return view('admin.purchase-order.invoice.add', compact('poUuid', 'purchaseOrders', 'employees', 'vendors', 'states', 'poData', 'unique_id'));
    }

    public function editInvoice_bk(Request $request, $uuid, $poUuid = null)
    {
        $this->setPageTitle('Edit Invoice');
        $invoiceData = $this->assetService->findInvoiceById(uuidtoid($uuid, 'purchase_order_invoices'));
        $purchase_order_id = $invoiceData->purchaseOrder->id;
        $invoiceDocuments = $invoiceData->document()->get();
        if ($request->ajax()) {
            $rules = [
                'purchase_order_id' => 'required|exists:purchase_orders,uuid',
                'vendor_id' => 'required|exists:vendors,id',
                'created_by' => 'required',
                'party_invoice_number' => 'required|string',
                'invoice_date' => 'required|date',
                'challan_no' => 'required',
                'billing_from_location' => 'required',
                'billing_location' => 'required',
            ];
            $messages = [
                'purchase_order_id' => 'Purchase order ID is required.',
                'vendor_id' => 'Vendor is required.',
                'created_by' => 'Created By is required.',
                'party_invoice_number' => 'Party invoice number is required.',
                'invoice_date' => 'Invoice Date is required.',
                'challan_no' => 'Challan No/Way-bill No/In-ward document number is required.',
                'billing_from_location' => 'Billing From Address is required.',
                'billing_location' => 'Billing To Address is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['purchase_order_id' => $purchase_order_id]);
                $isInvoiceCreated = $this->assetService->addOrUpdateInvoice(['uuid' => $uuid], $request->except('_token'));
                if ($isInvoiceCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Purchase Order Invoice updated successfully.', [
                        'redirect_url' => $poUuid ? route('admin.po.invoice.list', $poUuid) : route('admin.invoice.inv.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $poData = $purchase_order_id ? $this->assetService->findPoId($purchase_order_id) : null;
        $employees = $this->userService->getEmployees();
        $lastId = PurchaseOrderInvoice::orderBy('id', 'desc')->pluck('id')->first() ?? 0;
        $unique_id = 'INVC' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);

        return view('admin.purchase-order.invoice.edit', compact('invoiceData', 'uuid', 'poUuid', 'purchaseOrders', 'employees', 'vendors', 'states', 'poData', 'unique_id', 'invoiceDocuments'));
    }




    public function editInvoice(Request $request, $uuid, $poUuid = null)
    {
        $this->setPageTitle('Edit Invoice');
        $invoiceData = $this->assetService->findInvoiceById(uuidtoid($uuid, 'purchase_order_invoices'));
        $purchase_order_id = $invoiceData->purchaseOrder->id;
        $invoiceDocuments = $invoiceData->document()->get();
        if ($request->ajax()) {
            $rules = [
                'purchase_order_id' => 'required|exists:purchase_orders,uuid',
                'vendor_id' => 'required|exists:vendors,id',
                'created_by' => 'required',
                'party_invoice_number' => 'required|string',
                'invoice_date' => 'required|date',
                'challan_no' => 'required',
                'billing_from_location' => 'required',
                'billing_location' => 'required',
            ];
            $messages = [
                'purchase_order_id' => 'Purchase order ID is required.',
                'vendor_id' => 'Vendor is required.',
                'created_by' => 'Created By is required.',
                'party_invoice_number' => 'Party invoice number is required.',
                'invoice_date' => 'Invoice Date is required.',
                'challan_no' => 'Challan No/Way-bill No/In-ward document number is required.',
                'billing_from_location' => 'Billing From Address is required.',
                'billing_location' => 'Billing To Address is required.',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['purchase_order_id' => $purchase_order_id]);


                // if ($invoiceData->status == '2') {
                //     // dd($invoiceData);
                //     $this->assetService->createInvoiceVersion($invoiceData);
                //     $request->merge(['status' => null]);
                // }

                // dd("asdfghj");

                $isInvoiceCreated = $this->assetService->addOrUpdateInvoice(['uuid' => $uuid], $request->except('_token'));

                // dd($isInvoiceCreated);
                if ($isInvoiceCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Purchase Order Invoice updated successfully.', [
                        'redirect_url' => $poUuid ? route('admin.po.invoice.list', $poUuid) : route('admin.invoice.inv.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $purchaseOrders = $this->assetService->findPurchaseOrders(['status' => 1]);
        $vendors = $this->userService->getAllVendors(['is_active' => '1']);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $poData = $purchase_order_id ? $this->assetService->findPoId($purchase_order_id) : null;
        $employees = $this->userService->getEmployees();
        $lastId = PurchaseOrderInvoice::orderBy('id', 'desc')->pluck('id')->first() ?? 0;
        $unique_id = 'INVC' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);

        return view('admin.purchase-order.invoice.edit', compact('invoiceData', 'uuid', 'poUuid', 'purchaseOrders', 'employees', 'vendors', 'states', 'poData', 'unique_id', 'invoiceDocuments'));
    }


    public function viewInvoice(Request $request, $uuid, $poUuid = null, $notiuuid = null)
    {
        $this->setPageTitle('View Invoice');
        $invoiceData = $this->assetService->findInvoiceById(uuidtoid($uuid, 'purchase_order_invoices'));
        $poData = $this->assetService->findPoId($invoiceData->purchase_order_id);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        $invoiceDocuments = $invoiceData->document()->get();


        $checkInvoiceApproval = $this->assetService->checkPoInvoiceApproval($invoiceData->id, auth()->user()->id);

        //$checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);
       // $checkInvoiceApproval = $this->assetService->checkPoInvoiceApprovalLatestOrder($invoiceData->id, auth()->user()->id);


        $lastApproval = PoInvoiceApproval::where(['po_invoice_id' => $invoiceData->id])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();
        // dd($invoiceData);
        switch ($invoiceData->status) {
            case '0':
                $statClass = 'text_pending';
                $status = 'Pending';
                break;
            case '1':
                $statClass = 'text_green';
                $status = 'Approved';
                break;
            case '2':
                $statClass = 'text_danger';
                $status = 'Rejected';
                break;
            case '3':
                $statClass = 'text_danger';
                $status = 'Cancelled';
                break;
            case '4':
                $statClass = 'text_black';
                $status = 'Closed';
                break;
            case '5':
                $statClass = 'text_blue';
                $status = 'Ongoing Approval';
                break;

            case null:
                $statClass = 'text_danger';
                $status='';
                $invoiceData = $this->assetService->findInvoiceById($invoiceData->id);
                // dd($invoiceData);
                if($invoiceData)
                $isRejectedCheck=$invoiceData->isRejectedCheck()->get();
                // dd($isRejectedCheck);
                if($isRejectedCheck && $isRejectedCheck->contains('status',2))
                $status = 'Rejected';
                break;

            default:
                $statClass = 'text_black';
                $status = 'Not Sent For Approval';
                break;
        }
        return view('admin.purchase-order.invoice.details', compact('invoiceData', 'uuid', 'poUuid', 'poData', 'checkInvoiceApproval', 'lastApproval', 'statClass', 'status', 'invoiceDocuments'));
    }


    public function sendInvoiceForApproval_bk(Request $request, $uuid, $poUuid = null)
    {

        $this->setPageTitle('Invoice Approval Status');
        $poInvoiceId = uuidtoid($uuid, 'purchase_order_invoices');
        $invoiceData = $this->assetService->findInvoiceById($poInvoiceId);
        $poData = $this->assetService->findPoId($invoiceData->purchase_order_id);
        if ($invoiceData->created_by == auth()->user()->id || auth()->user()->hasRole('super-admin')) {
            if ($request->ajax()) {
                // dd($request->all());
                if (!$request->level_user[array_key_last($request->level_user)]) {
                    return $this->responseJson(false, 299, 'Approver field is required.', '');
                }
                DB::beginTransaction();
                try {
                    if (count($request->level_user)) {

                        $count = 0;
                        $creatUserData = $this->userService->findUserById($invoiceData->created_by);
                        foreach ($request->level_user as $k => $level_user) {
                            $data = [
                                'po_invoice_id' => $poInvoiceId,
                                'user_id' => $level_user,
                                'level' => $k,
                                'status' => ($count == 0) ? 0 : null
                            ];
                            $userData = $this->userService->findUserById($request->level_user[$k]);
                            $notiUser = $this->userService->findUserById($request->level_user[1]);
                            if ($k == 1) {
                                $notiData = [
                                    'form_name' => "You got a PO Invoice approval request for PO Invoice ID #" . $invoiceData->unique_id,
                                    'po_invoice_uuid' => $invoiceData->uuid,
                                    'po_uuid' => $invoiceData->purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoInvoiceApproveNotification($notiData));
                            } else {
                                $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                                $notiData = [
                                    'form_name' => $fullname . " got a PO Invoice approval request for PO Invoice ID #" . $invoiceData->unique_id,
                                    'po_invoice_uuid' => $invoiceData->uuid,
                                    'po_uuid' => $invoiceData->purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoInvoiceApproveNotification($notiData));
                                $creatUserData->notify(new PoInvoiceApproveNotification($notiData));
                            }
                            $count++;
                            //dd($data);
                            $isApprovalCreated = $this->assetService->createOrUpdateInvoiceApproval($data);
                        }


                        if ($request->remarks) {
                            $request->merge(['descriptions' => $request->remarks]);
                            $isInvoiceUpdated = $this->assetService->addOrUpdateInvoice(['uuid' => $uuid], $request->except('_token'));
                        }




                        if (count($request->level_user) == $count && $isApprovalCreated) {
                            $attributes = ['status' => 0];
                            $isSendForApproval = $this->assetService->updateInvoiceStatus($attributes, $poInvoiceId);



                            $table = '
                            <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">Name</th>
                                        <th style="text-align: left;">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>';
                            if ($invoiceData->purchase_order_items != null && count($invoiceData->purchase_order_items) > 0) {
                                foreach ($invoiceData->purchase_order_items as $itemDetail) {
                                    $findAsset = Asset::find($itemDetail['asset_id']);
                                    $productName = $findAsset->asset_name;
                                    $quantity = $itemDetail['quantity'];
                                    $table .= '
                                    <tr>
                                        <td>' . htmlspecialchars($productName) . '</td>
                                        <td>' . htmlspecialchars($quantity) . '</td>
                                    </tr>';
                                }
                            } else {
                                $table .= '
                                <tr>
                                    <td colspan="2" style="text-align: center;">No data found</td>
                                </tr>';
                            }

                            $table .= '
                                </tbody>
                            </table>';



                            DB::commit();
                            $mailData = [
                                'to' => $notiUser->email,
                                'from' => env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'The invoice for the recently delivered Product/Service  has been submitted in the system. Below are the details:<br><br><br>Invoice Details:',
                                'content' => 'Invoice Number: #' . $invoiceData->unique_id . '<br>PO Number: ' . $poData->unique_id . '<br>Vendor Name: ' . $invoiceData->vendor?->full_name . '<br>Product/services:<br>' . $table . '<br>Invoice Date: ' . $invoiceData->invoice_date->format('Y-m-d') . '<br>Invoice Amount: RS' . $invoiceData->grand_total . '<br>Challan no: ' . $invoiceData->challan_no . '<br><br><br>To review and approve the invoice, please click on the following link:<a href="' . route('admin.po.invoice.view', $invoiceData->uuid) . '" class="edit_icon">' . $invoiceData->unique_id . '</a>',
                                'subject' => 'Invoice Submitted for Approval - Invoice #' . $invoiceData->unique_id,
                                'greetings' => 'Dear ' . $notiUser->full_name . ',',
                                'end_greetings' => 'Best Regards,<br>DHC',
                                'from_user' => env('MAIL_FROM_NAME')
                            ];
                            Mail::send(new SendMailable($mailData));
                            return $this->responseJson(true, 200, 'PO Invoice successfully sent for approval.', [
                                'redirect_url' => $poUuid ? route('admin.po.invoice.sendForApproval', [$uuid, $poUuid]) : route('admin.invoice.inv.sendForApproval', $uuid)
                            ]);
                        }

                        // dd($request->all());




                    }
                } catch (\Throwable $e) {
                    DB::rollBack();
                    logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                    return $this->responseJson(false, 500, $e->getMessage(), '');
                }
            }

            $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();
            //dd($levelUsers);
            unset($levelUsers[$invoiceData->created_by]);
            $poInvoiceApprovals = $this->assetService->getPoInvoiceApprovals(['po_invoice_id' => $poInvoiceId]);

            //dd($poInvoiceApprovals);
            return view('admin.purchase-order.invoice.send-for-approval', compact('uuid', 'poUuid', 'invoiceData', 'levelUsers', 'poInvoiceApprovals'));
        } else {
            abort(401);
        }
    }






    public function sendInvoiceForApproval(Request $request, $uuid, $poUuid = null)
    {

        $this->setPageTitle('Invoice Approval Status');
        $poInvoiceId = uuidtoid($uuid, 'purchase_order_invoices');


        $invoiceData = $this->assetService->findInvoiceById($poInvoiceId);


        $poData = $this->assetService->findPoId($invoiceData->purchase_order_id);

        if ($invoiceData->created_by == auth()->user()->id || auth()->user()->hasRole('super-admin')) {
            if ($request->ajax()) {
                if (!$request->level_user[array_key_last($request->level_user)]) {
                    return $this->responseJson(false, 299, 'Approver field is required.', '');
                }
                DB::beginTransaction();
                try {


                    // dd($request->all());


                    if (count($request->level_user)) {

                        $count = 0;
                        $creatUserData = $this->userService->findUserById($invoiceData->created_by);


                        foreach ($request->level_user as $k => $level_user) {
                            $data = [
                                'po_invoice_id' => $poInvoiceId,
                                'user_id' => $level_user,
                                'level' => $k,
                                'status' => ($count == 0) ? 0 : null
                            ];
                            $userData = $this->userService->findUserById($request->level_user[$k]);
                            $notiUser = $this->userService->findUserById($request->level_user[1]);
                            if ($k == 1) {
                                $notiData = [
                                    'form_name' => "You got a PO Invoice approval request for PO Invoice ID #" . $invoiceData->unique_id,
                                    'po_invoice_uuid' => $invoiceData->uuid,
                                    'po_uuid' => $invoiceData->purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoInvoiceApproveNotification($notiData));
                            } else {
                                $fullname = $notiUser->first_name . " " . $notiUser->last_name;
                                $notiData = [
                                    'form_name' => $fullname . " got a PO Invoice approval request for PO Invoice ID #" . $invoiceData->unique_id,
                                    'po_invoice_uuid' => $invoiceData->uuid,
                                    'po_uuid' => $invoiceData->purchaseOrder->uuid,
                                ];
                                $userData->notify(new PoInvoiceApproveNotification($notiData));
                                $creatUserData->notify(new PoInvoiceApproveNotification($notiData));
                            }
                            $count++;
                            // dd($data);
                            $isApprovalCreated = $this->assetService->createOrUpdateInvoiceApproval($data);
                            // $isApprovalCreated = $this->assetService->createInvoiceApproval($data);
                        }


                        if ($request->remarks) {
                            $request->merge(['descriptions' => $request->remarks]);
                            $isInvoiceUpdated = $this->assetService->addOrUpdateInvoice(['uuid' => $uuid], $request->except('_token'));
                        }




                        if (count($request->level_user) == $count && $isApprovalCreated) {
                            $attributes = ['status' => 0];
                            $isSendForApproval = $this->assetService->updateInvoiceStatus($attributes, $poInvoiceId);
                            $table = '
                            <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">Name</th>
                                        <th style="text-align: left;">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>';
                            if ($invoiceData->purchase_order_items != null && count($invoiceData->purchase_order_items) > 0) {
                                foreach ($invoiceData->purchase_order_items as $itemDetail) {
                                    $findAsset = Asset::find($itemDetail['asset_id']);
                                    $productName = $findAsset->asset_name;
                                    $quantity = $itemDetail['quantity'];
                                    $table .= '
                                    <tr>
                                        <td>' . htmlspecialchars($productName) . '</td>
                                        <td>' . htmlspecialchars($quantity) . '</td>
                                    </tr>';
                                }
                            } else {
                                $table .= '
                                <tr>
                                    <td colspan="2" style="text-align: center;">No data found</td>
                                </tr>';
                            }

                            $table .= '
                                </tbody>
                            </table>';
                            DB::commit();
                            $mailData = [
                                'to' => $notiUser->email,
                                'from' => env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'The invoice for the recently delivered Product/Service  has been submitted in the system. Below are the details:<br><br><br>Invoice Details:',
                                'content' => 'Invoice Number: #' . $invoiceData->unique_id . '<br>PO Number: ' . $poData->unique_id . '<br>Vendor Name: ' . $invoiceData->vendor?->full_name . '<br>Product/services:<br>' . $table . '<br>Invoice Date: ' . $invoiceData->invoice_date->format('Y-m-d') . '<br>Invoice Amount: RS' . $invoiceData->grand_total . '<br>Challan no: ' . $invoiceData->challan_no . '<br><br><br>To review and approve the invoice, please click on the following link:<a href="' . route('admin.po.invoice.view', $invoiceData->uuid) . '" class="edit_icon">' . $invoiceData->unique_id . '</a>',
                                'subject' => 'Invoice Submitted for Approval - Invoice #' . $invoiceData->unique_id,
                                'greetings' => 'Dear ' . $notiUser->full_name . ',',
                                'end_greetings' => 'Best Regards,<br>DHC',
                                'from_user' => env('MAIL_FROM_NAME')
                            ];
                            Mail::send(new SendMailable($mailData));
                            return $this->responseJson(true, 200, 'PO Invoice successfully sent for approval.', [
                                'redirect_url' => $poUuid ? route('admin.po.invoice.sendForApproval', [$uuid, $poUuid]) : route('admin.invoice.inv.sendForApproval', $uuid)
                            ]);
                        }

                    }
                } catch (\Throwable $e) {
                    DB::rollBack();
                    logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                    return $this->responseJson(false, 500, $e->getMessage(), '');
                }
            }

            $levelUsers = $this->userService->findUserByRole(['is_available' => 1], null, 'name', 'asc', 999999, 0, false)->pluck('id', 'full_name')->toArray();
            //dd($levelUsers);
            unset($levelUsers[$invoiceData->created_by]);

            $poInvoiceApprovals = $this->assetService->getPoInvoiceApprovals(['po_invoice_id' => $poInvoiceId]);

            $poInvoiceApprovalsIncludingDeleted = PoInvoiceApproval::withTrashed()
            ->where('po_invoice_id', $poInvoiceId)
            ->get();
            // dd($poInvoiceApprovalsIncludingDeleted);

            return view('admin.purchase-order.invoice.send-for-approval', compact('uuid', 'poUuid', 'invoiceData', 'levelUsers', 'poInvoiceApprovals','poInvoiceApprovalsIncludingDeleted'));
        } else {
            abort(401);
        }
    }
    public function listTicket()
    {
        $this->setPageTitle('E-Ticket Management');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');

        $notifications = auth()->user()->notifications()->latest()->where('read_at', NULL)->limit(5)->get();

        //dd(gettype($notifications));
        $processedNotifications = $notifications->map(function ($notification) {
            $data = json_decode(json_encode($notification->data), true); // Correctly decode the JSON data
            $notification->form_name = $data['form_name'] ?? 'Default value if key not exists';
            $notification->budget_uuid = $data['budget_uuid'] ?? '';
            return $notification;
        });
        //dd($processedNotifications);
        return view('admin.ticket.index', compact('entities', 'assetTypes', 'vendors', 'departments', 'processedNotifications'));
    }


    /*public function addTicket(Request $request)
    {
        $this->setPageTitle('Raise New Ticket');
        if ($request->ajax()) {
            //dd("sdfghbkm");
            $rules = [
                'subject' => 'required|string',
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'priority' => 'required|string',
                'mobile_number' => 'required|integer|digits:10',
                'cc_to' => 'required|exists:users,id',
                'attachment_document' => 'nullable|sometimes|image|mimes:jpg,jpeg,png,webp,gif,svg|max:5120',
            ];
            $messages = [
                'entity_id' => 'Entity field is required.',
                'department_id' => 'Department field is required.',
            ];

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            // dd($request->all());
            DB::beginTransaction();
            try {
                $request->merge(['raised_id' => auth()->user()->id]);
                $isCreated = $this->assetService->addOrUpdateTicket(['uuid' => null], $request->except('_token'));
                if ($isCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Ticket Successfully Raised .', [
                        'redirect_url' => route('admin.ticket.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }


        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);

        $departments = $this->assetService->listDepartments(['is_active' => 1], 'id', 'DESC');
        $employees = $this->userService->getEmployees();

        $lastId = Ticket::orderBy('id', 'desc')->pluck('id')->first();
        $unique_id = 'TICK' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);

        // return view('admin.Ticket.add', compact('entities', 'departments', 'employees', 'locations', 'typeCategories','unique_id'));

        return view('admin.ticket.add', compact('entities', 'employees', 'departments', 'unique_id'));
    }*/
    public function invoicePdfDownload(Request $request, $uuid)
    {
        try {
            $invoiceData = $this->assetService->findInvoiceById(uuidtoid($uuid, 'purchase_order_invoices'));
            $poData = $this->assetService->findPoId($invoiceData->purchase_order_id);
            $invoiceDocuments = $invoiceData->document()->get();
            $dompdf = new Dompdf();
            $html = view('admin.purchase-order.invoice.pdf', compact('invoiceData', 'poData', 'invoiceDocuments'));
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A2', 'landscape');
            $dompdf->render();
            $pdfOutput = $dompdf->output();
            $filename = 'Invoice_' . time() . '.pdf';
            return Response::make($pdfOutput, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }
    public function assetstockInventoryEdit(Request $request, $uuid)
    {
        $this->setPageTitle('Stock Inventory');


        //dd($uuid);
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');


        if ($request->ajax()) {
            $rules = [
                'capacity_specs' => 'required|string',
                'purchase_date' => 'required|date',
                'asset_condition' => 'required',
                'warranty_licence_date' => 'required|date',
            ];
            $messages = [
                'capacity_specs' => 'Capacity or Specification is required',
                'purchase_date' => 'Purcahse Date is required',
                'warranty_licence_date' => 'Warranty or License Date is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                if ($request->inventory_uuid) {
                    $isIssued = $this->assetService->addOrUpdateInventory(['uuid' => $request->inventory_uuid], $request->except('_token'));
                }

                DB::commit();
                return $this->responseJson(true, 200, 'This Item has been updated', [
                    'redirect_url' => route('admin.assetstock.inventory', [$uuid])
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;
        return view('admin.asset.stock.inventory', compact('uuid', 'asset_stock', 'employees', 'locationId', 'assetIssues'));
    }

    // private function generateIdentificationCode($inventoryId)
    // {
    //     $code = Str::upper(Str::random(10, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'));

    //     $remainingInventories = $this->assetService->getInventories([])->whereNotIn('id', [$inventoryId]);

    //     if ($remainingInventories->contains('identification_no', $code)) {
    //         return $this->generateIdentificationCode($inventoryId);
    //     }
    //     return $code;
    // }



    public function assetLease(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Lease');
        $asset_stock_id = $request->stock_uuid ? uuidtoid($request->stock_uuid, 'asset_stocks') : uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $assets = $this->assetService->listAssets([]);
        $locations = $this->assetService->listLocations();
        $vendors = $this->vendorService->getAllUsers(['is_active' => 1]);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $employees = $this->userService->getEmployees('', ['entity_id' => $asset_stock->entity_id]);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        if ($request->ajax()) {
            //dd($request->all());
            $rules = [
                'location_id' => 'required',
                'type' => 'required',
                'asset_items' => 'required',
                'start_date' => 'required|date',
                'end_date' => 'required|date',
                'lease_term' => 'required',
                'lease_term_frequency' => 'required',
                'lease_type' => 'required',
                // 'payment_amount' => 'required',
                //'entity_id' => 'required',
                //'to_entity_id' => 'required|different:entity_id',
                'payment_frequency' => 'required',
                'created_by' => 'required',
                'vendor_id' => [
                    Rule::requiredIf($request->type == 'external' && ($request->vendor_name == '' || $request->vendor_phone == '' || $request->vendor_email == '')),
                ],
                'renewal_terms' => 'required',
                'attachment_document' => 'required'
            ];
            $messages = [
                'location_id' => 'Location is required',
                'type' => 'Type is required',
                'asset_items' => 'Asset item is required',
                'start_date' => 'Start date is required',
                'end_date' => 'End date is required',
                'lease_term' => 'Lease term is required',
                'lease_term_frequency' => 'Lease term frequency is required',
                'lease_type' => 'Lease type is required',
                // 'payment_amount' => 'Lease payment amount is required',
                'payment_frequency' => 'Lease payment frequency is required',
                'created_by' => 'Created by is required',
                'vendor_id' => 'Vendor information is required',
                'renewal_terms' => 'Renewal options and terms are required',
                'attachment_document' => 'Lease agreement file is required',

                'to_entity_id.different' => 'From Entity and To Entity must be different',
                'entity_id.required' => 'From Entity is required',
                'to_entity_id.required' => 'To Entity is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if (!$request->asset_items) {
                $validator->getMessageBag()->add('leaseItemList', 'Select any item to lease');
            }
            // dd($validator->errors());
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $vendor_information = [];
                if ($request->type == 'external') {
                    if ($request->vendor_id) {
                        $vendor = $this->vendorService->findUserById($request->vendor_id);
                        $vendor_information['vendor_id'] = $vendor->id;
                        $vendor_information['vendor_name'] = $vendor->full_name;
                        $vendor_information['vendor_phone'] = $vendor->mobile_number;
                        $vendor_information['vendor_email'] = $vendor->email;
                        $vendor_information['vendor_state'] = $vendor->state_id;
                        $vendor_information['vendor_city'] = $vendor->city_id;
                        $vendor_information['vendor_address'] = $vendor->address;
                    } else {
                        $vendor_information['vendor_id'] = '';
                        $vendor_information['vendor_name'] = $request->vendor_name;
                        $vendor_information['vendor_phone'] = $request->vendor_phone;
                        $vendor_information['vendor_email'] = $request->vendor_email;
                        $vendor_information['vendor_state'] = $request->vendor_state;
                        $vendor_information['vendor_city'] = $request->vendor_city;
                        $vendor_information['vendor_address'] = $request->vendor_address;
                    }
                }
                $request->merge(['asset_stock_id' => $asset_stock->id, 'vendor_information' => $vendor_information, 'entity_id' => $asset_stock->entity_id, 'payment_amount' => number_format((float) $asset_stock->payment_amount, 2, '.', ',')]);

                $isLeased = $this->assetStockService->addOrUpdateLease(['uuid' => null], $request->except([
                    '_token',
                    'asset_items',
                    'stock_uuid'
                ]));

                if ($isLeased) {
                    foreach ($request->asset_items as $k => $lease_item) {
                        $itemData = [
                            'lease_id' => $isLeased->id,
                            'inventory_id' => $lease_item,
                            'user_id' => $request->user_id ? $request->user_id[$k] : null,
                            'leased_date' => $request->leased_date ? $request->leased_date[$k] : null,
                            'amount' => $request->amount ? number_format((float) $request->amount[$k], 2, '.', ',') : 0,
                            'comments' => $request->comments ? $request->comments[$k] : null
                        ];
                        $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => null], $itemData);
                        if ($isLeaseItems) {
                            $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $isLeased->entity_id], 1, 'decrease');
                            if ($isUpdated) {
                                $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $asset_stock->entity_id];
                                $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                                $logData = [
                                    'asset_stock_id' => $assetStockData->id,
                                    'asset_id' => $request->asset_id,
                                    'location_id' => $request->location_id,
                                    'entity_id' => $assetStockData->entity_id,
                                    'type' => 'substruct',
                                    'quantity' => 1
                                ];
                                $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                            }
                        }

                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'New Lease Creation',
                            'task_description' => $isLeased->unique_id,
                            'task_url' => 'modules/lease/view/' . $isLeased->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-lease',
                            'related_id' => $isLeased->id,
                            'inventory_id' => $lease_item
                        ]);
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, 'Lease has been submitted successfully', [
                    'redirect_url' => route('admin.assetstock.list', $asset_stock->asset->uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.asset.stock.lease', compact('uuid', 'asset_stock', 'assets', 'locations', 'vendors', 'states', 'employees', 'entities'));
    }
    public function assetLeasedList(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Leased Details');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $locations = $this->assetService->listLocations();
        $leasedAgreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $asset_stock_id]);
        //dd($leasedAgreements);
        // $leasedAgreement = $this->assetStockService->findLeaseAgreementById($asset_lease_id);



        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                $itemData = [
                    'user_id' => $request->user_id ? $request->user_id : null,
                    'leased_date' => $request->leased_date ? Carbon::createFromFormat('m/d/Y', $request->leased_date)->format('Y-m-d') : null,
                    'comments' => $request->comments ? $request->comments : null,
                    'document' => $request->document ? $request->document : null,
                ];
                $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => $request->lease_item_uuid], $itemData);
                $leasedAgreement = $this->assetStockService->findLeaseAgreementById(uuidtoid($request->lease_uuid, 'lease_agreements'));
                $assetStock = $this->assetStockService->findById($leasedAgreement->asset_stock_id);

                $findLeaseItem = $this->assetStockService->findLeasedItemById(uuidtoid($request->lease_item_uuid, 'lease_items'));
                $asset = $this->assetService->findById($leasedAgreement->asset_id);

                // dd($request->all());

                $findInventory=$this->assetStockService->getInventoryById($findLeaseItem->inventory_id);
                // inserting data also asset issue table
                $acceptance_otp = rand(1000, 9999);
                $request->merge(['asset_id' => $asset->id, 'asset_stock_id' => $leasedAgreement->asset_stock_id,'inventory_id'=>$request->inventory_id, 'location_id'=>$leasedAgreement->location_id, 'user_id'=>$request->user_id,'expiry'=>$findInventory->warranty_licence_date,'quantity'=>null,'issued_date'=>$request->leased_date, 'acceptance_otp' => $acceptance_otp]);
                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));

                // dd($isIssued);


                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                    ['id' => null],
                    [
                        'task_name' => 'An Asset has been Allocated',
                        'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                        'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                        'added_by' => auth()->user()->id,
                        'type' => 'add-issue',
                        'related_id' => $isLeaseItems->id,
                        'inventory_id' => $findLeaseItem->inventory_id ?? null
                    ]
                );

                if ($findLeaseItem->inventory_id !=null) {
                    $inventoryData = $this->assetService->findInventoryById($findLeaseItem->inventory_id);
                    $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                }
                $userData = $this->userService->findUserById($request->user_id);

                $notiData = [
                    'form_name' => $notificationContent,
                    'issue_uuid' => $isIssued->uuid,
                ];
                $userData = $this->userService->findUserById($request->user_id);
                $userData->notify(new IssueNotification($notiData));
                $mailData = [
                    'to' => $userData->email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => $notificationContent,
                    'content' => 'Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                    'subject' => 'Allocation Of Asset',
                    'greetings' => 'Hello Sir/Madam',
                    'end_greetings' => 'Regards,',
                    'from_user' => env('MAIL_FROM_NAME')
                ];

                // dd($userData->email,$mailData);
                Mail::send(new SendMailable($mailData));

                DB::commit();
                // return $this->responseJson(true, 200, 'Lease has been submitted successfully', [
                //     'redirect_url' => route('admin.lease.view', $request->lease_uuid)
                // ]);






                return $this->responseJson(true, 200, 'Lease has been submitted successfully', [
                    'redirect_url' => route('admin.assetstock.leased.list', $assetStock->uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }




        $employees = $this->userService->getEmployees();

        //$employees = $this->userService->getEmployees('', ['entity_id' => $leasedAgreement->to_entity_id]);
        return view('admin.asset.stock.leased-list', compact('uuid', 'asset_stock', 'locations', 'leasedAgreements', 'employees'));
    }

    public function assetMaintenance(Request $request, $uuid)
    {
        $this->setPageTitle('Add Asset For Maintenance');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $assets = $this->assetService->listAssets([]);
        $locations = $this->assetService->listLocations();
        $employees = $this->userService->getEmployees();
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        if ($request->ajax()) {
            $rules = [
                'location_id' => 'required',
                'asset_items' => 'required',
                'title' => 'required',
                'description' => 'required',
                'start_date' => 'required|date',
                'end_date' => 'required|date',
                'status' => 'required',
                'created_by' => 'required'
            ];
            $messages = [
                'location_id' => 'Location is required',
                'asset_items' => 'Asset item is required',
                'title' => 'Title is required',
                'description' => 'Description is required',
                'start_date' => 'Start date is required',
                'end_date' => 'End date is required',
                'status' => 'Status is required',
                'created_by' => 'Created by is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if (!$request->asset_items) {
                $validator->getMessageBag()->add('maintenanceItemList', 'Select any item to lease');
            }
            // dd($validator->errors());
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {

                // $request->merge(['asset_stock_id' => $asset_stock_id]);
                $assetStockId = uuidtoid($request->stock_uuid, 'asset_stocks');
                $request->merge(['asset_stock_id' => $assetStockId]);

                $isInMaintenance = $this->assetStockService->addOrUpdateMaintenance(['uuid' => null], $request->except([
                    '_token',
                    'asset_items'
                ]));

                if ($isInMaintenance) {
                    foreach ($request->asset_items as $asset_item) {
                        $itemData = ['asset_maintenance_id' => $isInMaintenance->id, 'inventory_id' => $asset_item];
                        $isMaintenanceItems = $this->assetStockService->addOrUpdateMaintenanceItems(['uuid' => null], $itemData);
                        $inventory = $this->assetStockService->getInventoryById($asset_item);
                        if ($isMaintenanceItems) {
                            if (!$inventory->issue) {
                                $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], 1, 'decrease');
                                if ($isUpdated) {
                                    $filterConditions = ['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $isInMaintenance->stock->entity_id];
                                    $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                                    $logData = [
                                        'asset_stock_id' => $assetStockData->id,
                                        'asset_id' => $request->asset_id,
                                        'location_id' => $request->location_id,
                                        'entity_id' => $isInMaintenance->stock->entity_id,
                                        'type' => 'substruct',
                                        'quantity' => 1
                                    ];
                                    $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                                    $this->assetService->addOrUpdateInventory(['id' => $asset_item], ['under_maintenance' => '1']);
                                }
                            } else {
                                $this->assetService->addOrUpdateInventory(['id' => $asset_item], ['under_maintenance' => '1']);
                            }
                        }


                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'New Maintenance Creation',
                            'task_description' => $isInMaintenance->unique_id,
                            'task_url' => 'modules/maintenance/view/' . $isInMaintenance->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-maintenance',
                            'related_id' => $isInMaintenance->id,
                            'inventory_id' => $asset_item
                        ]);
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, 'Asset successfully has been submitted for maintenance', [
                    'redirect_url' => route('admin.assetstock.list', $asset_stock->asset->uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.asset.stock.maintenance', compact('uuid', 'asset_stock', 'assets', 'locations', 'employees', 'entities'));
    }
    public function assetMaintenanceList(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Maintenance List');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $locations = $this->assetService->listLocations();
        $assetMaintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $asset_stock_id]);
        return view('admin.asset.stock.maintenance-list', compact('uuid', 'asset_stock', 'locations', 'assetMaintenances'));
    }

    public function assetIssuedList(Request $request, $uuid, $notiuuid = null)
    {
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $asset_stock = $this->assetStockService->findById($asset_stock_id);
        $employees = $this->userService->getEmployees();
        $locationId = $asset_stock->location_id;
        $assetIssues = (!$asset_stock->asset->has_unique_number) ? $this->assetStockService->listAssetIssues(['asset_id' => $asset_stock->asset_id, 'location_id' => $asset_stock->location_id]) : null;

        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        return view('admin.asset.stock.issued-list', compact('uuid', 'asset_stock', 'employees', 'locationId', 'assetIssues'));
    }

    public function lease(Request $request)
    {
        $this->setPageTitle('Lease');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $assetCategories = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'asset_type']);
        $locations = $this->assetService->listLocations();
        $leases = $this->assetStockService->findLeases([]);
        $stocks = $this->assetStockService->listAssetStocks([]);






        //$uuid='0d5a554b-6d0b-467a-af29-79d11190833b';
        //$uuid='8356b34a-c1d3-4c93-8b60-a7f5eeb9235c';
        // $asset = $this->assetService->findById(uuidtoid($uuid, 'assets'));
        // $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        // $locations = $this->assetService->listLocations();

        return view('admin.asset.stock.lease.list', compact('entities', 'assetCategories', 'assetTypes', 'locations', 'leases', 'stocks'));

        // return view('admin.asset.stock.lease.list',  compact('asset', 'locations', 'uuid', 'entities'));



    }
    public function leaseAdd(Request $request)
    {
        $this->setPageTitle('Lease Add');
        $condition = [['is_active', '=', '1']];
        if ($request->ajax()) {
            // $validator = Validator::make($request->all(), [
            //     'category_id' => 'required|exists:categories,id',
            // ]);
            $rules = [
                'category_id' => 'required|exists:categories,id',

            ];
            $messages = [
                'category_id' => 'Asset Category field is required.',
            ];

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                #file upload#
                if ($request->hasFile('assetimage')) {
                    $image = uniqid() . "." . $request->file('assetimage')->getClientOriginalExtension();
                    $request->file('assetimage')->move(public_path('storage/asset_image'), $image);
                }
                $request->merge(['slug' => str()->slug($request->asset_name), 'asset_image' => $image ?? 'noimg.png']);
                $isCreated = $this->assetService->addOrUpdate([
                    'uuid' => $request->uuid
                ], $request->except('_token', 'asset_type', 'assetimage'));
                if ($isCreated) {
                    DB::commit();
                    $msg = $isCreated->wasRecentlyCreated ? 'Asset created' : 'Asset updated';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.asset.list')
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        // $lastId = $this->assetService->findAssets([], 'id', 'desc', 1, 0, false)->pluck('id')->first();
        // $assetid = 'ASST' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        // $assettypes = $this->assetTypeService->listAssets($condition, 'id', 'desc');
        // $vendors = $this->vendorService->getAllUsers([], 'vendor');
        // $typeCategories = $this->getAssetCategoryTree();
        // dd($typeCategories);


        $assetTypes = $this->getAssetTypesTree([], null, null);

        //$assetCategory = $this->categoryService->findCategoryById($budget->category_id);

        // if (!$assetTypes && $assetCategory->children()->count()) {
        //     foreach ($assetCategory->children()->get() as $assetCategorySub) {
        //         $assetTypes = array_merge($assetTypes, $this->getAssetTypesTree([], null, $assetCategorySub->id));
        //     }
        // }

        $typeCategories = $this->getAssetCategoryTree();
        //    dd($assetTypes);
        $locations = $this->assetService->listLocations();
        return view('admin.asset.stock.lease.add', compact('typeCategories', 'assetTypes', 'locations'));
    }


    public function maintenance(Request $request)
    {
        $this->setPageTitle('Lease');
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $assetTypes = $this->assetTypeService->listAssets(['is_active' => 1]);
        $stocks = $this->assetStockService->listAssetStocks(['is_active' => '1']);
        $locations = $this->assetService->listLocations();
        $maintenances = $this->assetStockService->findMaintenances([]);
        //dd($stocks);
        return view('admin.asset.stock.maintenance.list', compact('maintenances', 'stocks', 'locations'));
    }

    public function maintenanceView(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Maintenance Details');
        $maintenanceId = uuidtoid($uuid, 'asset_maintenances');
        $assetMaintenance = $this->assetStockService->findMaintenanceById($maintenanceId);

        $asset_stock = $this->assetStockService->findById($assetMaintenance->asset_stock_id);
        //dd($asset_stock);
        return view('admin.asset.stock.maintenance.detail', compact('asset_stock', 'assetMaintenance'));
    }
    public function assetDisposalList(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Disposal List');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $assetStock = $this->assetStockService->findById($asset_stock_id);
        $disposedItems = $this->assetStockService->findMaintenanceItemsByStockId($asset_stock_id, ['status' => '2']);
        // dd($disposedItems);
        return view('admin.asset.stock.disposal-list', compact('uuid', 'assetStock', 'disposedItems'));
    }
    public function bulkdispose(Request $request)
    {
        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                // dd($request->all());
                if ($request->itemUuids)
                    foreach ($request->itemUuids as $uuid) {
                        $id = uuidtoid($uuid, 'maintenance_items');
                        $maintenanceItem = $this->assetStockService->findMaintenanceItemById($id);
                        $data = $this->assetStockService->updateMaintenanceItemStatus(['status' => 2, 'repaired_comments' => $request->repaired_comments], $id);
                        $underMaintenanceStatus = '2';

                        $this->assetService->addOrUpdateInventory(['id' => $maintenanceItem->inventory_id], ['under_maintenance' => $underMaintenanceStatus]);
                        if ($data && $request->is_active != '0') {
                            $filterConditions = ['id' => $maintenanceItem->maintenance->asset_stock_id];

                            $asset_stock = $this->assetStockService->findById($maintenanceItem->maintenance->asset_stock_id);
                            $approveOrReject = ["task_name" => "Multiple Assets have been Disposed", "task_description" => $maintenanceItem->maintenance->unique_id,];

                            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => $approveOrReject['task_name'],
                                'task_description' => $approveOrReject['task_description'],
                                'task_url' => 'modules/maintenance/view/' . $maintenanceItem->maintenance?->uuid,
                                'added_by' => auth()->user()->id,
                                'type' => 'status-maintenance',
                                'related_id' => $maintenanceItem->asset_maintenance_id,
                                'inventory_id' => $maintenanceItem->inventory_id
                            ]);
                            $totalIncompleteItems = $maintenanceItem->maintenance->maintenanceItems->where('status', '0')->count();
                            if (!$totalIncompleteItems) {
                                $this->assetStockService->updateMaintenanceStatus(['status' => '1'], $maintenanceItem->maintenance->id);
                            }
                        }
                    }
                else
                    return $this->responseJson(false, 200, 'Please select an asset',);


                DB::commit();
                if ($request->stockUuid)
                    return $this->responseJson(true, 200, 'Asset successfully disposed', [
                        'redirect_url' => route('admin.assetstock.maintenance.list', $request->stockUuid)
                    ]);
                else
                    return $this->responseJson(true, 200, 'Asset successfully disposed', [
                        'redirect_url' => route('admin.maintenance.view', $request->maintenanceUuid)
                    ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }

    public function leaseDetail(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('Asset Leased Details');
        $asset_lease_id = uuidtoid($uuid, 'lease_agreements');

        if ($request->ajax()) {
            // $rules = [
            //     'location_id' => 'required',
            // ];
            // $messages = [
            //     'location_id' => 'Location is required',
            // ];
            // $validator = Validator::make($request->all(), $rules, $messages);
            DB::beginTransaction();
            try {

                // dd($request->all());

                $itemData = [
                    'user_id' => $request->user_id ? $request->user_id : null,
                    'leased_date' => $request->leased_date ? Carbon::createFromFormat('m/d/Y', $request->leased_date)->format('Y-m-d') : null,
                    'comments' => $request->comments ? $request->comments : null,
                    'document' => $request->document ? $request->document : null,
                ];

                $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => $request->lease_item_uuid], $itemData);


                $findLease = LeaseAgreement::find($asset_lease_id);
                $findLeaseItem = LeaseItem::find(uuidtoid($request->lease_item_uuid, 'lease_items'));
                $asset = $this->assetService->findById($findLease->asset_id);



                $findInventory=$this->assetStockService->getInventoryById($findLeaseItem->inventory_id);
                // inserting data also asset issue table
                $acceptance_otp = rand(1000, 9999);
                $request->merge(['asset_id' => $asset->id, 'asset_stock_id' => $findLease->asset_stock_id,'inventory_id'=>$request->inventory_id, 'location_id'=>$findLease->location_id, 'user_id'=>$request->user_id,'expiry'=>$findInventory->warranty_licence_date,'quantity'=>null,'issued_date'=>$request->leased_date, 'acceptance_otp' => $acceptance_otp]);


                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $request->issue_uuid ?? null], $request->except('_token'));



                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                    ['id' => null],
                    [
                        'task_name' => 'An Asset has been Allocated',
                        'task_description' => $asset->asset_name . '(' . $asset->asset_id . ')',
                        'task_url' => 'modules/assetstock/issued/list/' . $uuid,
                        'added_by' => auth()->user()->id,
                        'type' => 'add-issue',
                        'related_id' => $isLeaseItems->id,
                        'inventory_id' => $findLeaseItem->inventory_id ?? null
                    ]
                );


                if ($findLeaseItem->inventory_id !=null) {
                    $inventoryData = $this->assetService->findInventoryById($findLeaseItem->inventory_id);
                    $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                }





                $notiData = [
                    'form_name' => $notificationContent,
                    'issue_uuid' => $isIssued->uuid,
                ];
                // $notiData = [
                //     'form_name' => $notificationContent,
                //     'lease_uuid' => $findLease->uuid,
                // ];
                $userData = $this->userService->findUserById($request->user_id);

               $userData->notify(new IssueNotification($notiData));

            //    $userData->notify(new IssueFromLeaseNotification($notiData));
                $mailData = [
                    'to' => $userData->email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => $notificationContent,
                    'content' => 'Please check the allocated asset details and provide your receive acknowledgment from the <a href="' . route('assetstock.item.allocation.acceptance', $isIssued->uuid) . '" target="_blank">Acceptance Link.</a><br>Your OTP is ' . $acceptance_otp,
                    'subject' => 'Allocation Of Asset',
                    'greetings' => 'Hello Sir/Madam',
                    'end_greetings' => 'Regards,',
                    'from_user' => env('MAIL_FROM_NAME')
                ];
                // dd($userData->email,$mailData);
                Mail::send(new SendMailable($mailData));





                DB::commit();
                return $this->responseJson(true, 200, 'Lease has been submitted successfully', [
                    'redirect_url' => route('admin.lease.view', $request->lease_uuid)
                ]);
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }

        $locations = $this->assetService->listLocations();
        $leasedAgreement = $this->assetStockService->findLeaseAgreementById($asset_lease_id);
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        $employees = $this->userService->getEmployees('', ['entity_id' => $leasedAgreement->to_entity_id]);

        $asset_stock = $leasedAgreement->assetStock;

        return view('admin.asset.stock.lease.detail', compact('uuid', 'asset_stock', 'locations', 'leasedAgreement', 'employees'));
    }

    protected function generateIdentificationCode($entity = null, $location = null, $assetType = null, $month = null, $year = null, $lastId = null)
    {
        $budgetCode = substr(strtoupper((preg_replace('/[^a-zA-Z0-9]/', '', $entity))), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $location)), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $assetType)), 0, 3) . '/' . $month . '/' . $year . '-' . $lastId;
        return $budgetCode;
    }

    public function listPhysicalVerifications(Request $request)
    {
        $this->setPageTitle('Physical Verification List');
        return view('admin.asset.stock.verification.list');
    }

    public function inventoryHistory(Request $request, $uuid = null)
    {
        // dd($uuid);
        $this->setPageTitle('Asset History');

        $inventoryData = $this->assetService->findInventoryById(uuidtoid($request->uuid, 'inventories'));
        $asset = $this->assetService->findById($inventoryData->asset_id);

        $inventoryLogs = $this->assetService->findRecentActivities(['inventory_id' => $inventoryData->id], ['add-stock', 'add-issue', 'add-surrender', 'add-lease', 'complete-lease', 'add-maintenance', 'status-maintenance']);
        // dd($inventoryLogs);

        $locations = $this->assetService->listLocations();
        return view('admin.asset.history', compact('uuid', 'asset', 'locations', 'inventoryLogs', 'inventoryData'));
    }
    public function addPhysicalVerification(Request $request, $uuid = null)
    {
        $this->setPageTitle('Add Physical Verification');
        $verificationData = null;
        $entityList = [];
        if ($uuid) {
            $verificationData = $this->assetStockService->findVerificationById(uuidtoid($uuid, 'asset_verifications'));
            if ($verificationData->step == '2') {
                $isVerificationUpdated = $this->assetStockService->addOrUpdatePhysicalVerification([
                    'uuid' => $verificationData->uuid
                ], ['step' => 1]);
            }
            // dd($verificationData->entity_id);
            if ($verificationData->entity_id != null) {
                foreach ($verificationData->entity_id as $entityId) {
                    $entity = Category::find($entityId);
                    if ($entity) {
                        $entityList[] = $entity->name;
                    }
                }
            }
        }
        if ($request->ajax()) {
            $rules = [];
            $messages = [];
            if (!$uuid) {
                $rules = [
                    // 'name' => 'required|min:2|unique:asset_verifications,name,' . $uuid . ',uuid',
                    'name' => 'required',
                    'start_date' => 'required|date',
                    'end_date' => 'required|date',
                    'location_id' => 'required|exists:locations,id',
                    'entity_id' => 'required|exists:categories,id',
                    'category_id' => 'required|exists:categories,id',
                    'asset_type_id' => 'required|exists:asset_types,id',
                    'asset_id' => 'required|exists:assets,id',
                ];
                $messages = [
                    'start_date' => 'Start date field is required.',
                    'end_date' => 'End date field is required.',
                    'category_id' => 'Asset category field is required.',
                    'location_id' => 'Location field is required.',
                    'entity_id' => 'Entity field is required.',
                    'asset_type_id' => 'Asset type field is required.',
                    'asset_id' => 'Asset field is required.',
                ];
            } else {
                if ($request->submit_type == 'add') {
                    $uniqueNumber = ($verificationData->assetType?->unique_number_type == 'license') ? 'License Number' : 'Serial Number';
                    $capacitySpecs = ($verificationData->assetType?->unique_number_type == 'license') ? 'Specifications' : 'Capacity';
                    $warrantyLicenceDate = ($verificationData->assetType?->unique_number_type == 'license') ? 'License expiry date' : 'Warranty Date';

                    $rules = [
                        // 'identification_no' => 'required|unique:verified_assets,identification_no',
                        // 'unique_id' => 'required|unique:verified_assets,unique_id',
                        'identification_no' => 'required',
                        'unique_id' => 'required',
                        'capacity_specs' => 'required',
                        'asset_condition' => 'required',
                        'purchase_date' => 'required|date',
                        'warranty_licence_date' => 'required|date',
                    ];
                    $messages = [
                        // 'identification_no.required' => 'Barcode field is required.',
                        // 'identification_no.unique' => 'Barcode must be unique.',
                        // 'unique_id.required' => $uniqueNumber.' field is required.',
                        // 'unique_id.unique' => $uniqueNumber.' must be unique.',
                        'identification_no' => 'Barcode field is required.',
                        'unique_id' => $uniqueNumber . ' field is required.',
                        'capacity_specs' => $capacitySpecs . ' field is required.',
                        'asset_condition' => 'Asset condition field is required.',
                        'purchase_date' => 'Purchase date field is required.',
                        'warranty_licence_date' => $warrantyLicenceDate . ' field is required.',
                    ];
                }
            }

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if (!$uuid) {
                    $request->merge(['verified_by' => auth()->user()->id]);
                    $isCreated = $this->assetStockService->addOrUpdatePhysicalVerification([
                        'uuid' => null
                    ], $request->except('_token'));
                    if ($isCreated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'Physical verification successfully created', [
                            'redirect_url' => route('admin.verification.add', $isCreated->uuid)
                        ]);
                    }
                } else {
                    if ($request->submit_type == 'add') {
                        $identificationNo = preg_replace('/\s+/', '', strtoupper($request->identification_no));
                        $isUpdated = 0;
                        $status = null;
                        if ($request->inventory_id) {
                            $status = 0;
                            $inventoryData = $this->assetService->findInventoryById($request->inventory_id);
                            if ($inventoryData->assetStock->location_id != $verificationData->location_id || $inventoryData->assetStock->entity_id != $verificationData->entity_id || $inventoryData->asset_id != $verificationData->asset?->id) {
                                $isUpdated = 1;
                            }

                            if (trim(strtoupper($request->unique_id)) != strtoupper($inventoryData->unique_id) || trim(strtoupper($request->capacity_specs)) != strtoupper($inventoryData->capacity_specs) || trim(strtoupper($request->asset_condition)) != strtoupper($inventoryData->asset_condition) || trim($request->purchase_date) != Carbon::parse($inventoryData->purchase_date)->format('Y-m-d') || trim($request->warranty_licence_date) != Carbon::parse($inventoryData->warranty_licence_date)->format('Y-m-d')) {
                                $isUpdated = 1;
                            }
                            if ($inventoryData->dispose) {
                                $status = 3;
                            } elseif ($inventoryData->underMaintenance) {
                                $status = 2;
                            } elseif ($inventoryData->issue || $inventoryData->lease) {
                                $status = 1;
                            }
                        }
                        $request->merge(['identification_no' => $identificationNo, 'is_updated' => $isUpdated, 'status' => $status]);

                        $isCreated = $this->assetStockService->addOrUpdateVerifiedAsset([
                            'unique_id' => null
                        ], $request->except(['_token']));
                        if ($isCreated) {
                            DB::commit();
                            // return $this->responseJson(true, 200, 'Asset successfully added for verification', [
                            //     'redirect_url' => route('admin.verification.add', $uuid)
                            // ]);
                            return $this->responseJson(true, 200, 'Asset successfully added for verification', [
                                'redirect_url' => ""
                            ]);
                        }
                    } else {
                        if ($request->verified_asset_id) {
                            $isVerificationUpdated = $this->assetStockService->addOrUpdatePhysicalVerification([
                                'uuid' => $uuid
                            ], ['step' => 2]);
                            if ($isVerificationUpdated) {
                                DB::commit();
                                return $this->responseJson(true, 200, 'Assets are verifying', [
                                    'redirect_url' => route('admin.verification.verify', $uuid)
                                ]);
                            }
                        } else {
                            return $this->responseJson(false, 200, 'Please add asset to verify.', '');
                        }
                    }
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $locations = $this->assetService->listLocations();
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        $typeCategories = $this->getAssetCategoryTree([], null, false, ['Consumable']);
        // dd($typeCategories);
        $employees = $this->userService->getEmployees();

        return view('admin.asset.stock.verification.add', compact('locations', 'entities', 'typeCategories', 'employees', 'uuid', 'verificationData', 'entityList'));
    }

    public function verifyPhysicalVerification(Request $request, $uuid)
    {
        $this->setPageTitle('Verify Assets');
        $verificationData = $this->assetStockService->findVerificationById(uuidtoid($uuid, 'asset_verifications'));
        $entityList = [];
        if ($verificationData->entity_id != null) {
            foreach ($verificationData->entity_id as $entityId) {
                $entity = Category::find($entityId);
                if ($entity) {
                    $entityList[] = $entity->name;
                }
            }
        }

        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                $updateCount = 0;
                $totalAssetCount = 0;
                // dd($request->verified_asset);
                /*if ($request->verified_asset) {
                    foreach ($request->verified_asset as $key => $verified_asset) {
                        $totalAssetCount += count($verified_asset);
                        foreach ($verified_asset as $verified_asset_id) {
                            switch ($key) {
                                case 'add':
                                    $verifiedAsset = $this->assetStockService->findVerifiedAssetById($verified_asset_id);
                                    $assetStockData = $this->assetStockService->findById($request->asset_stock_id);
                                    $inventoryData = [
                                        'asset_stock_id'        => $assetStockData->id,
                                        'category_id'           => $verifiedAsset->category_id,
                                        'asset_type_id'         => $verifiedAsset->asset_type_id,
                                        'asset_id'              => $verifiedAsset->asset_id,
                                        'unique_id'             => $verifiedAsset->unique_id,
                                        'identification_no'     => $verifiedAsset->identification_no,
                                        'capacity_specs'        => $verifiedAsset->capacity_specs,
                                        'asset_condition'       => $verifiedAsset->asset_condition,
                                        'purchase_date'         => $verifiedAsset->purchase_date,
                                        'warranty_licence_date' => $verifiedAsset->warranty_licence_date,
                                    ];
                                    $isInevntoryUpdated = $this->assetStockService->addOrUpdateInventory(['id' => null], $inventoryData);
                                    if ($isInevntoryUpdated) {
                                        $isVerifiedAssetUpdated = $this->assetStockService->addOrUpdateVerifiedAsset([
                                            'id' => $verified_asset_id
                                        ], ['inventory_id' => $isInevntoryUpdated->id]);
                                        if ($isVerifiedAssetUpdated) {
                                            if ($verifiedAsset->allocation_info) {
                                                $isIssued = $this->assetStockService->addOrUpdateAssetIssue(
                                                    ['uuid' => null],
                                                    [
                                                        'asset_id' => $verifiedAsset->asset_id,
                                                        'asset_stock_id' => $assetStockData->id,
                                                        'inventory_id' => $isInevntoryUpdated->id,
                                                        'location_id' => $assetStockData->location_id,
                                                        'user_id' => $verifiedAsset->allocation_info['user_id'],
                                                        'issued_date' => $verifiedAsset->allocation_info['issued_date'],
                                                        'quantity' => $verifiedAsset->allocation_info['quantity'],
                                                        'comments' => $verifiedAsset->allocation_info['comments'],
                                                    ]
                                                );
                                                if ($isIssued) {
                                                    $isUpdated = $this->assetStockService->alterStockTable(['asset_id' => $request->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id], 1, 'decrease');
                                                    if ($isUpdated) {
                                                        $logData = [
                                                            'asset_stock_id' => $assetStockData->id,
                                                            'asset_id' => $assetStockData->asset_id,
                                                            'location_id' => $assetStockData->location_id,
                                                            'entity_id' => $assetStockData->entity_id,
                                                            'type' => 'substruct',
                                                            'quantity' => 1
                                                        ];
                                                        $this->assetStockService->addAssetStockLog($logData);
                                                        $updateCount++;
                                                    }

                                                    $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(
                                                        ['id' => null],
                                                        [
                                                            'task_name' => 'An Asset has been Issued',
                                                            'task_description' => $assetStockData->asset->asset_name . '(' . $assetStockData->asset_id . ')',
                                                            'task_url' => 'modules/assetstock/issued/list/' . $assetStockData->uuid,
                                                            'added_by' => auth()->user()->id,
                                                            'type' => 'add-issue',
                                                            'related_id' => $isIssued->id,
                                                            'inventory_id' => $isInevntoryUpdated->id
                                                        ]
                                                    );
                                                    $updateCount++;
                                                }
                                            } else {
                                                $isStockUpdated = $this->assetStockService->alterStockTable(['id' => $assetStockData->id], 1, 'increase');
                                                if ($isStockUpdated) {
                                                    $logData = [
                                                        'asset_stock_id' => $assetStockData->id,
                                                        'asset_id' => $assetStockData->asset_id,
                                                        'location_id' => $assetStockData->location_id,
                                                        'entity_id' => $assetStockData->entity_id,
                                                        'type' => 'add',
                                                        'quantity' => 1
                                                    ];
                                                    $this->assetStockService->addAssetStockLog($logData);
                                                    $updateCount++;
                                                }
                                            }
                                        }
                                    }
                                    break;
                                case 'update':
                                    $verifiedAsset = $this->assetStockService->findVerifiedAssetById($verified_asset_id);
                                    $inventory = $this->assetService->findInventoryById($verifiedAsset->inventory_id);
                                    $inventoryData = [
                                        'unique_id' => $verifiedAsset->unique_id,
                                        'capacity_specs' => $verifiedAsset->capacity_specs,
                                        'asset_condition' => $verifiedAsset->asset_condition,
                                        'purchase_date' => $verifiedAsset->purchase_date,
                                        'warranty_licence_date' => $verifiedAsset->warranty_licence_date,
                                    ];
                                    $isAssetUpdated = $inventory->update($inventoryData);
                                    if ($isAssetUpdated) {
                                        $updateCount++;
                                    }
                                    break;
                                case 'update-other':
                                    $assetStockData = $this->assetStockService->findById($request->asset_stock_id);
                                    $verifiedAsset = $this->assetStockService->findVerifiedAssetById($verified_asset_id);
                                    $inventory = $this->assetService->findInventoryById($verifiedAsset->inventory_id);
                                    $previousAssetStockData = $inventory->assetStock;
                                    $inventoryData = [
                                        'unique_id' => $verifiedAsset->unique_id,
                                        'capacity_specs' => $verifiedAsset->capacity_specs,
                                        'asset_condition' => $verifiedAsset->asset_condition,
                                        'purchase_date' => $verifiedAsset->purchase_date,
                                        'warranty_licence_date' => $verifiedAsset->warranty_licence_date,
                                        'category_id' => $verifiedAsset->category_id,
                                        'asset_type_id' => $verifiedAsset->asset_type_id,
                                        'asset_id' => $verifiedAsset->asset_id,
                                        'asset_stock_id' => $assetStockData->id,
                                    ];
                                    $isAssetUpdated = $inventory->update($inventoryData);
                                    if ($isAssetUpdated) {
                                        $isPrevUpdated = $this->assetStockService->alterStockTable(['id' => $previousAssetStockData->id], 1, 'decrease');
                                        if ($isPrevUpdated) {
                                            $prevLogData = [
                                                'asset_stock_id' => $previousAssetStockData->id,
                                                'asset_id' => $previousAssetStockData->asset_id,
                                                'location_id' => $previousAssetStockData->location_id,
                                                'entity_id' => $previousAssetStockData->entity_id,
                                                'type' => 'substruct',
                                                'quantity' => 1
                                            ];
                                            $this->assetStockService->addAssetStockLog($prevLogData);
                                            $isStockUpdated = $this->assetStockService->alterStockTable(['id' => $assetStockData->id], 1, 'increase');
                                            if ($isStockUpdated) {
                                                $logData = [
                                                    'asset_stock_id' => $assetStockData->id,
                                                    'asset_id' => $assetStockData->asset_id,
                                                    'location_id' => $assetStockData->location_id,
                                                    'entity_id' => $assetStockData->entity_id,
                                                    'type' => 'add',
                                                    'quantity' => 1
                                                ];
                                                $this->assetStockService->addAssetStockLog($logData);
                                                $updateCount++;
                                            }
                                        }
                                    }
                                    break;
                                case 'delete':
                                    $inventory = $this->assetService->findInventoryById($verified_asset_id);
                                    $inventoryData = [
                                        'under_maintenance'     => 3,
                                    ];
                                    $isAssetUpdated = $inventory->update($inventoryData);
                                    if ($isAssetUpdated) {
                                        $isUpdated = $this->assetStockService->alterStockTable(['id' => $inventory->assetStock->id], 1, 'decrease');
                                        if ($isUpdated) {
                                            $logData = [
                                                'asset_stock_id' => $inventory->assetStock->id,
                                                'asset_id' => $inventory->assetStock->asset_id,
                                                'location_id' => $inventory->assetStock->location_id,
                                                'entity_id' => $inventory->assetStock->entity_id,
                                                'type' => 'substruct',
                                                'quantity' => 1
                                            ];
                                            $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                                            $updateCount++;
                                        }
                                    }
                                    break;
                            }
                        }
                    }
                }*/
                // dd($totalAssetCount.'----'.$updateCount);



                if ($totalAssetCount == $updateCount) {
                    $isVerificationUpdated = $this->assetStockService->addOrUpdatePhysicalVerification(['id' => $request->verification_id], ['status' => 1]);
                    if ($isVerificationUpdated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'Physical verification successfully done', [
                            'redirect_url' => route('admin.verification.list')
                        ]);
                    }
                } else {
                    return $this->responseJson(false, 500, 'Something went wrong', '');
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $filterConditions = [
            'asset_id' => $verificationData->asset_id,
            'location_id' => $verificationData->location_id,
            'entity_id' => $verificationData->entity_id,
        ];
        $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
        $assetStockInventories = [];
        $assetStockId = '';
        if ($assetStockData) {
            $assetStockId = $assetStockData->id;
            $assetStockInventories = $assetStockData->inventories->pluck('id')->toArray();
        }
        $verifiedInventoryAssets = $verificationData->verifiedInventoryAssets->pluck('inventory_id')->toArray();
        $mismatchedInventoryIds = array_diff($assetStockInventories, $verifiedInventoryAssets);
        $mismatchedInventoryIds = array_values($mismatchedInventoryIds);
        $mismatchedInventories = $this->assetStockService->findInventoriesByIds($mismatchedInventoryIds);
        $employees = $this->userService->getEmployees();
        // dd($mismatchedInventories);
        return view('admin.asset.stock.verification.verify', compact('uuid', 'verificationData', 'mismatchedInventories', 'employees', 'assetStockId', 'entityList'));
    }
    public function allocateAsset(Request $request)
    {
        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                $verifiedAsset = $this->assetStockService->findVerifiedAssetById($request->verified_asset_id);
                if ($request->allocation_type == 'allocate') {
                    $isVerifiedAssetUpdated = $this->assetStockService->addOrUpdateVerifiedAsset(
                        [
                            'id' => $request->verified_asset_id
                        ],
                        [
                            'allocation_info' =>
                            [
                                'user_id' => $request->user_id,
                                'user_name' => $request->user_name,
                                'issued_date' => $request->issued_date,
                                'quantity' => $request->quantity,
                                'comments' => $request->comments
                            ]
                        ]
                    );
                    $msg = 'Asset successfully added for allocation';
                } else {
                    $isVerifiedAssetUpdated = $this->assetStockService->addOrUpdateVerifiedAsset(
                        [
                            'id' => $request->verified_asset_id
                        ],
                        ['allocation_info' => null]
                    );
                    $msg = 'Asset allocation successfully removed';
                }
                if ($isVerifiedAssetUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.verification.verify', $verifiedAsset->assetVerification->uuid)
                    ]);
                } else {
                    return $this->responseJson(false, 500, 'Something went wrong', '');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function updateVerifiedAsset(Request $request)
    {
        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                if ($request->id) {
                    $verifiedAsset = $this->assetStockService->findVerifiedAssetById($request->id);
                    $isUpdated = 0;
                    if ($verifiedAsset->inventory_id) {
                        $inventoryData = $this->assetService->findInventoryById($verifiedAsset->inventory_id);
                        if (trim(strtoupper($request->unique_id)) != strtoupper($inventoryData->unique_id) || trim(strtoupper($request->capacity_specs)) != strtoupper($inventoryData->capacity_specs) || trim(strtoupper($request->asset_condition)) != strtoupper($inventoryData->asset_condition) || trim($request->purchase_date) != Carbon::parse($inventoryData->purchase_date)->format('Y-m-d') || trim($request->warranty_licence_date) != Carbon::parse($inventoryData->warranty_licence_date)->format('Y-m-d')) {
                            $isUpdated = 1;
                        }
                    }
                    $request->merge(['identification_no' => $verifiedAsset->identification_no, 'is_updated' => $isUpdated]);

                    if (isset($request->picture) && $request->picture) {
                        $verifiedAsset->document()->forceDelete();
                    }

                    $isUpdated = $this->assetStockService->addOrUpdateVerifiedAsset([
                        'id' => $request->id
                    ], $request->except(['_token']));
                    if ($isUpdated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'Asset successfully updated', []);
                    } else {
                        return $this->responseJson(false, 500, 'Something went wrong', '');
                    }
                } else {
                    return $this->responseJson(false, 500, 'Something went wrong', '');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function viewPhysicalVerification(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Verification Details');
        $verificationData = $this->assetStockService->findVerificationById(uuidtoid($uuid, 'asset_verifications'));

        $filterConditions = [
            'asset_id' => $verificationData->asset_id,
            'location_id' => $verificationData->location_id,
            'entity_id' => $verificationData->entity_id,
        ];
        $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
        $assetStockInventories = [];
        if ($assetStockData) {
            $assetStockInventories = $assetStockData->inventories->pluck('id')->toArray();
        }
        $verifiedInventoryAssets = $verificationData->verifiedInventoryAssets->pluck('inventory_id')->toArray();
        $mismatchedInventoryIds = array_diff($assetStockInventories, $verifiedInventoryAssets);
        $mismatchedInventoryIds = array_values($mismatchedInventoryIds);
        $mismatchedInventories = $this->assetStockService->findInventoriesByIds($mismatchedInventoryIds);


        $entityList = [];
        if ($verificationData && $verificationData->entity_id != null)
            foreach ($verificationData->entity_id as $entityId) {
                $entity = Category::find($entityId);
                if ($entity) {
                    $entityList[] = $entity->name;
                }
            }
        return view('admin.asset.stock.verification.view', compact('uuid', 'verificationData', 'mismatchedInventories', 'entityList'));
    }

    public function physicalVerificationPdfDownload(Request $request, $uuid)
    {
        try {
            $verificationData = $this->assetStockService->findVerificationById(uuidtoid($uuid, 'asset_verifications'));

            $filterConditions = [
                'asset_id' => $verificationData->asset_id,
                'location_id' => $verificationData->location_id,
                'entity_id' => $verificationData->entity_id,
            ];
            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
            $assetStockInventories = [];
            if ($assetStockData) {
                $assetStockInventories = $assetStockData->inventories->pluck('id')->toArray();
            }
            $verifiedInventoryAssets = $verificationData->verifiedInventoryAssets->pluck('inventory_id')->toArray();
            $mismatchedInventoryIds = array_diff($assetStockInventories, $verifiedInventoryAssets);
            $mismatchedInventoryIds = array_values($mismatchedInventoryIds);
            $mismatchedInventories = $this->assetStockService->findInventoriesByIds($mismatchedInventoryIds);
            $dompdf = new Dompdf();
            $html = view('admin.asset.stock.verification.pdf', compact('uuid', 'verificationData', 'mismatchedInventories'));
            $dompdf->loadHtml($html);
            // $dompdf->setPaper('A4', 'portrait');
            $dompdf->setPaper('A4', 'landscape');
            $dompdf->render();
            $pdfOutput = $dompdf->output();
            $filename = 'Asset_verification_details_' . time() . '.pdf';
            return Response::make($pdfOutput, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }


    public function physicalVerificationExcelDownload(Request $request, $uuid)
    {
        try {
            $filename = 'Asset_verification_details_' . time() . '.xlsx';
            $verificationData = $this->assetStockService->findVerificationById(uuidtoid($uuid, 'asset_verifications'));
            $filterConditions = [
                'asset_id' => $verificationData->asset_id,
                'location_id' => $verificationData->location_id,
                'entity_id' => $verificationData->entity_id,
            ];
            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);

            $assetStockInventories = [];
            if ($assetStockData) {
                $assetStockInventories = $assetStockData->inventories->pluck('id')->toArray();
            }
            $verifiedInventoryAssets = $verificationData->verifiedInventoryAssets->pluck('inventory_id')->toArray();

            $mismatchedInventoryIds = array_diff($assetStockInventories, $verifiedInventoryAssets);
            $mismatchedInventoryIds = array_values($mismatchedInventoryIds);
            $mismatchedInventories = $this->assetStockService->findInventoriesByIds($mismatchedInventoryIds);
            return Excel::download(new PhysicalVerificationExport($verificationData, $mismatchedInventories), $filename);
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }

    public function viewPOVendorApproval(Request $request, $uuid)
    {
        $this->setPageTitle('View Purchase Order');
        $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
        $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
        $paymentScheduleList = $this->assetService->listPaymentSchedules(['purchase_order_id' => $poData->id]);
        return view('admin.purchase-order.vendor-approval', compact('poData', 'poItems', 'paymentScheduleList'));
    }

    public function inventoryExcelDownload(Request $request, $uuid)
    {

        $filename = 'Inventory_stock_details' . time() . '.xlsx';
        // dd($uuid);
        // $asset_id = uuidtoid($uuid, 'assets');
        $asset_stock = $this->assetStockService->findById(uuidtoid($uuid, 'asset_stocks'));
        $filterConditions = ['asset_stock_id' => $asset_stock->id];
        $inventories = $this->assetStockService->findInventories($filterConditions);
        return Excel::download(new InventoryStockDetailsExport($asset_stock, $inventories), $filename);
    }

    public function sendPoToVendor(Request $request)
    {
        if ($request->ajax()) {
            $rules = [
                'vendor_email' => 'required|email',
                'approval_subject' => 'required',
                'approval_mail_body' => 'required',
            ];
            $messages = [
                'vendor_email.required' => "vendor's email is required.",
                'vendor_email.email' => "vendor's email format is not valid.",
                'approval_subject' => "Subject is required.",
                'approval_mail_body' => "Mail body is required.",
            ];

            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $approval_mail_body = $request->approval_mail_body;
                $approval_mail_body .= '<p>Please check the below link of purchase order</p> <a href="' . route('po.vendor.approval', $request->po_uuid) . '" target="_blank">Acceptance Link</a>';

                $purchaseOrder = $this->assetService->findPurchaseOrderById(uuidtoid($request->po_uuid, 'purchase_orders'));
                $findVendor = Vendor::find($purchaseOrder->vendor_id);


                // $productName = '';
                // if ($purchaseOrder->items != null)
                //     foreach ($purchaseOrder->items as $itemDetail) {
                //         $findAsset = Asset::find($itemDetail['asset_id']);
                //         $productName .= "{$findAsset->asset_name}, ";
                //     }
                // $productName = rtrim($productName, ', ');


                $table = '
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Name</th>
                            <th style="text-align: left;">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>';
                if ($purchaseOrder->items != null && count($purchaseOrder->items) > 0) {
                    foreach ($purchaseOrder->items as $itemDetail) {
                        $findAsset = Asset::find($itemDetail['asset_id']);
                        $productName = $findAsset->asset_name;
                        $quantity = $itemDetail['quantity'];

                        // Append each row to the table
                        $table .= '
                        <tr>
                            <td>' . htmlspecialchars($productName) . '</td>
                            <td>' . htmlspecialchars($quantity) . '</td>
                        </tr>';
                    }
                } else {
                    $table .= '
                    <tr>
                        <td colspan="2" style="text-align: center;">No data found</td>
                    </tr>';
                }

                $table .= '
                    </tbody>
                </table>';


                $po_details_mail_body='PO No: #' . $purchaseOrder->unique_id . '<br>Product/Service Name Listed Below:' . $table . '<br>Total Amount: ' . $purchaseOrder->item_total . '<br>Delivery Timeline(in days): ' . $purchaseOrder->delivery_terms . '<br>Payment Timeline(in days): ' . $purchaseOrder->payment_terms.'<br>';
                $mailData = [
                    'to' => $request->vendor_email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => 'We are pleased to inform you that the Purchase Order (PO) #' . $purchaseOrder->unique_id . ' has been approved and confirmed. Please find the details of the order below:',
                    // 'content' => 'PO Number:# ' . $purchaseOrder->unique_id,
                    // 'subject' => 'Purchase Order Confirmation - PO #' . $purchaseOrder->unique_id . 'Product/Service Name ' . $table . 'Total Amount ' . $purchaseOrder->item_total . 'Delivery Timeline ' . $purchaseOrder->delivery_terms . 'Payment Timeline ' . $purchaseOrder->payment_terms . 'We kindly request you to review the Purchase Order and confirm your acceptance of the order and terms through the following link:<br><a href="' . route('admin.po.view', $purchaseOrder->uuid) . '</a>',
                    'subject' => $request->approval_subject,
                    //'content' => 'PO No: #' . $purchaseOrder->unique_id . ' Product/Service Name Listed Below' . $table . 'Total Amount ' . $purchaseOrder->item_total . ' Delivery Timeline ' . $purchaseOrder->delivery_terms . ' Payment Timeline ' . $purchaseOrder->payment_terms . ' We kindly request you to review the Purchase Order and confirm your acceptance of the order and terms through the following link:<br><a href="' . route('admin.po.view', $purchaseOrder->uuid) . '"> Acceptance  Link</a>',
                    'content'=>$po_details_mail_body .'Additional Mail Body:<br>'.$approval_mail_body,
                    'greetings' => 'Dear ' . $findVendor->full_name . ',',
                    'end_greetings' => 'Best Regards,<br>DHC',
                    'from_user' => env('MAIL_FROM_NAME')

                ];

                // dd($request->vendor_email,$mailData);

                Mail::send(new SendMailable($mailData));
                return $this->responseJson(true, 200, 'Mail sent to vendor successfully', [
                    'redirect_url' => route('admin.po.list')
                ]);
            } catch (\Exception $e) {
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function surrenderLetterDownload(Request $request, $type, $uuid = null)
    {
        try {

            $issuedItem = $this->assetStockService->findAssetIssueById(uuidtoid($uuid, 'asset_issues'));
            $assetData = $this->assetService->findById($issuedItem->asset_id);
            $inventoryData = $this->assetService->findInventoryById($issuedItem->inventory_id);
            $userData = $this->userService->findUserById($issuedItem->user_id);
            if ($type == "pdf") {
                $dompdf = new Dompdf();
                $html = view('admin.asset.stock.issue.surrender', compact('assetData', 'inventoryData', 'issuedItem', 'userData'));
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();
                $pdfOutput = $dompdf->output();
                $filename = 'Sample_surrender_letter_' . time() . '.pdf';
                return Response::make($pdfOutput, 200, [
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'attachment; filename="' . $filename . '"',
                ]);
            } else {

                $phpWord = new PhpWord();
                $sectionStyle = [
                    'orientation' => 'portrait',
                    'paperSize' => 'A4'
                ];
                $section = $phpWord->addSection($sectionStyle);

                $imagePath = public_path('assets/images/logo.png');
                $section->addImage($imagePath, [
                    'width' => 280,
                    'height' => 80,
                    'alignment' => Jc::CENTER
                ]);
                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 18,
                    'color' => '0000FF', // Blue color
                    'bold' => true,
                    'alignment' => Jc::CENTER
                ];
                $phpWord = new PhpWord();
                $sectionStyle = [
                    'orientation' => 'portrait',
                    'paperSize' => 'A4'
                ];
                $section = $phpWord->addSection($sectionStyle);

                $imagePath = public_path('assets/images/logo.png');
                $section->addImage($imagePath, [
                    'width' => 280,
                    'height' => 80,
                    'alignment' => Jc::CENTER
                ]);
                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 14, // Reduced font size
                    'color' => '000000', // Black color
                    'bold' => true,
                    'alignment' => Jc::CENTER
                ];
                $headingText = 'FORM FOR SURRENDER OF ' . $assetData->asset_name . ' ( #' . $inventoryData->unique_id . ').';
                $section->addText($headingText, $headingStyle, ['alignment' => Jc::CENTER]);

                $tableStyle = [
                    'borderSize' => 6,
                    'borderColor' => '999999',
                    'cellMargin' => 80
                ];
                $firstRowStyle = [];
                $phpWord->addTableStyle('Fancy Table', $tableStyle, $firstRowStyle);
                $table = $section->addTable('Fancy Table');
                $cellWidth = 4500;

                $table->addRow();
                $table->addCell($cellWidth)->addText('Name');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $userData->full_name));

                $table->addRow();
                $table->addCell($cellWidth)->addText('Designation');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $userData->profile?->designation?->name ?? 'N/A'));

                $table->addRow();
                $table->addCell($cellWidth)->addText('Department');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $userData->profile?->department?->name ?? 'N/A'));

                $table->addRow();
                $table->addCell($cellWidth)->addText('Location');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $userData->profile?->location?->street_address ?? 'N/A'));


                $table->addRow();
                $table->addCell($cellWidth)->addText('Entity');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $userData->profile?->entity?->name ?? 'N/A'));

                $table->addRow();
                $table->addCell($cellWidth)->addText('Partner Name');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('Reason for Surrender Laptop');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('Signature of user');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('Approval by');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('Respective Partner');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('Respective Partner');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('IT Head');
                $table->addCell($cellWidth)->addText();
                $table->addRow();
                $table->addCell($cellWidth)->addText('HR');
                $table->addCell($cellWidth)->addText();

                $section->addTextBreak(1);

                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 14, // Reduced font size
                    'color' => '000000', // Black color
                    'bold' => true,
                    'alignment' => Jc::CENTER
                ];
                $headingText = 'TO BE FILLED BY IT HELPDESK';
                $section->addText($headingText, $headingStyle, ['alignment' => Jc::CENTER]);



                $tableStyle = [
                    'borderSize' => 6,
                    'borderColor' => '999999',
                    'cellMargin' => 80
                ];
                $firstRowStyle = [];
                $phpWord->addTableStyle('Fancy Table', $tableStyle, $firstRowStyle);
                $table = $section->addTable('Fancy Table');
                $cellWidth = 4500;

                $table->addRow();
                $table->addCell($cellWidth)->addText('Asset Tag No');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $inventoryData->identification_no ?? 'N/A'));

                $table->addRow();
                $table->addCell($cellWidth)->addText('Serial No');
                $table->addCell($cellWidth)->addText(str_replace('&', 'and', $inventoryData->unique_id ?? 'N/A'));


                $table->addRow();
                $table->addCell($cellWidth)->addText('Accessories received along with Laptop Remarks');
                $table->addCell($cellWidth)->addText();

                $table->addRow();
                $table->addCell($cellWidth)->addText('Any issues noticed in the laptop');
                $table->addCell($cellWidth)->addText();

                $table->addRow();
                $table->addCell($cellWidth)->addText('Date of Surrender');
                $table->addCell($cellWidth)->addText();

                $table->addRow();
                $table->addCell($cellWidth)->addText('Signature of IT Helpdesk');
                $table->addCell($cellWidth)->addText();


                //<h3>FORM FOR SURRENDER OF {{ $assetData->asset_name }}(Serial No: # {{$inventoryData->unique_id  }})</h3>
                // $createdAt = $vendorData->created_at->format('jS F Y');
                // $vendorName = $vendorData->full_name ?? '';
                // $vendorAddress = $vendorData->address ?? '';

                // $textStyle = [
                //     'name' => 'Arial',
                //     'size' => 12,
                //     'color' => '000000'
                // ];
                // $paragraphStyle = [
                //     'alignment' => Jc::LEFT,
                //     'spaceBefore' => 0,
                //     'spaceAfter' => 0
                // ];

                // $section->addText("Created at: $createdAt", $textStyle, $paragraphStyle);
                // $section->addText("Vendor Name: $vendorName", $textStyle, $paragraphStyle);
                // $section->addText("Vendor Address: $vendorAddress", $textStyle, $paragraphStyle);

                // $section->addTextBreak(1);

                $filename = 'Sample_surrender_letter_' . time() . '.docx';
                $tempFile = tempnam(sys_get_temp_dir(), 'phpword');
                $phpWord->save($tempFile, 'Word2007');

                return response()->download($tempFile, $filename)->deleteFileAfterSend(true);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }



    public function allotmentDownload(Request $request, $type, $uuid = null, $assetUuid = null, $inventoryUuid = null, $issued_date = null)
    {

        try {

            $userData = $this->userService->findUserById(uuidtoid($uuid, 'users'));
            $assetData = $this->assetService->findById(uuidtoid($assetUuid, 'assets'));
            $inventoryData = $this->assetService->findInventoryById(uuidtoid($inventoryUuid, 'inventories'));
            $assets = $this->assetService->listAssets([]);
            $attributes = Asset::where(['asset_type_id' => $inventoryData->asset_type_id])->first();
            $current_date = Carbon::now()->toDateString();
            if ($type == "pdf") {
                $dompdf = new Dompdf();
                $html = view('admin.asset.stock.issue.pdf', compact('userData', 'assetData', 'inventoryData', 'issued_date', 'current_date', 'attributes'));
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();
                $pdfOutput = $dompdf->output();
                $filename = 'Allotment_letter_of_' . $userData->full_name . '_' . time() . '.pdf';
                return Response::make($pdfOutput, 200, [
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'attachment; filename="' . $filename . '"',
                ]);
            } else {
                $phpWord = new PhpWord();
                $section = $phpWord->addSection();
                $html = view('admin.asset.stock.issue.issue', compact('userData', 'assetData', 'inventoryData', 'issued_date', 'current_date', 'attributes'));
                Html::addHtml($section, $html);
                $filename = 'Allotment_letter_of_' . $userData->full_name . '_' . time() . '.docx';
                $tempFile = tempnam(sys_get_temp_dir(), 'phpword');
                $phpWord->save($tempFile, 'Word2007');
                return response()->download($tempFile, $filename)->deleteFileAfterSend(true);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 500, $e->getMessage(), '');
        }
    }
    public function assetSingleTransfer(Request $request)
    {
        $this->setPageTitle('Stock Inventory');
        if ($request->ajax()) {
            $assetStock = $this->assetStockService->findById($request->asset_stock_id);
            if ($assetStock->location->id == $request->location_id && $assetStock->entity->id == $request->entity_id) {
                return $this->responseJson(false, 200, 'Please choose different location or entity', '');
            }
            DB::beginTransaction();
            try {
                $newAssetStock = $this->assetService->getAssetStock(['asset_id' => $assetStock->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id]);
                if (!$newAssetStock) {
                    $newAssetStock = $this->assetService->addOrUpdateAssetStock(['uuid' => null], [
                        'asset_receipt_note_id' => $assetStock->asset_receipt_note_id,
                        'arn_item_id' => $assetStock->arn_item_id,
                        'category_id' => $assetStock->category_id,
                        'asset_type_id' => $assetStock->asset_type_id,
                        'asset_id' => $assetStock->asset_id,
                        'location_id' => $request->location_id,
                        'entity_id' => $request->entity_id,
                        'previous_stock' => 0,
                        'current_stock' => 0
                    ]);
                }
                $isNewStockUpdated = $this->assetStockService->alterStockTable(['id' => $newAssetStock->id], 1, 'increase');
                if ($isNewStockUpdated) {
                    $logData = [
                        'asset_stock_id' => $newAssetStock->id,
                        'asset_id' => $newAssetStock->asset_id,
                        'location_id' => $newAssetStock->location_id,
                        'entity_id' => $newAssetStock->entity_id,
                        'type' => 'add',
                        'quantity' => 1
                    ];
                    $this->assetStockService->addAssetStockLog($logData);
                    $isPrevStockUpdated = $this->assetStockService->alterStockTable(['id' => $assetStock->id], 1, 'decrease');
                    if ($isPrevStockUpdated) {
                        $prevLogData = [
                            'asset_stock_id' => $assetStock->id,
                            'asset_id' => $assetStock->asset_id,
                            'location_id' => $assetStock->location_id,
                            'entity_id' => $assetStock->entity_id,
                            'type' => 'substruct',
                            'quantity' => 1
                        ];
                        $this->assetStockService->addAssetStockLog($prevLogData);
                        $inventory = $this->assetService->findInventoryById($request->inventory_id);
                        $inventoryData = [
                            'asset_stock_id' => $newAssetStock->id,
                        ];
                        $isInventoryUpdated = $inventory->update($inventoryData);
                        if ($isInventoryUpdated) {
                            DB::commit();
                            return $this->responseJson(true, 200, "Asset Transferred Successfully", [
                                'redirect_url' => route('admin.assetstock.inventory', [$request->asset_stock_uuid],)
                            ]);
                        }
                    }
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }




    public function serverCronJob(Request $request, $type)
    {
        switch ($type) {
            case 'lease':
                $day = 5;
                $expiringLeases = $this->assetStockService->getExpiringLeases($day);
                $dayText = ($day > 1) ? 'days' : 'day';
                if ($expiringLeases) {
                    foreach ($expiringLeases as $expiringLease) {
                        foreach ($expiringLease->onGoingLeaseItems as $leaseItem) {
                            if ($expiringLease->type == 'internal') {
                                $userData = $leaseItem->leasedUser;
                                $notiData = [
                                    'form_name' => "Your leased item #" . $leaseItem->inventory->unique_id . " is expiring in " . $day . " " . $dayText,
                                    'uuid' => $expiringLease->uuid,
                                    'type' => 'lease'
                                ];
                                $userData->notify(new ReminderNotification($notiData));
                                $toEmail = $userData->email;
                            } else {
                                $toEmail = $expiringLease->vendor_information['vendor_email'];
                            }

                            $findAsset = Asset::find($leaseItem->inventory->asset_id);
                            $parentLease = LeaseAgreement::find($leaseItem->lease_id);
                            $mailData = [
                                'to' => $toEmail,
                                'from' => env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => 'This is to inform you that the lease agreement for the following asset is approaching its expiry date:<br><br><br>Lease Details:',
                                'content' => 'Asset Name: #' . $findAsset->asset_name . '<br>Asset ID: ' . $findAsset->asset_id . '<br>Leased To: ' . $userData->full_name . '<br>Lease Start Date: ' . $parentLease->start_date->format('Y-m-d') . '<br>Lease Expiry Date: ' . $parentLease->start_date->format('Y-m-d') . '<br><br><br>As the lease expiry date is 30 days away, we request you to review the current lease arrangement and take the necessary action<br><br><br>Renew the Lease if required, by initiating the process before<br><br><br>Return the Asset if renewal is not planned, ensuring all return protocols are followed<br><br><br>For further assistance or to proceed with the renewal,  access the asset management portal using the following link',
                                'subject' => 'Advance Notification: Lease Expiry for ' . $findAsset->asset_name,
                                'greetings' => 'Dear ' . $userData->full_name . ',',
                                'end_greetings' => 'Best Regards,<br>DHC',
                                'from_user' => env('MAIL_FROM_NAME')
                            ];
                            Mail::send(new SendMailable($mailData));
                        }
                    }
                }
                break;


            case 'ticket':
                $expiringTickets = $this->assetStockService->getExpiringTickets();
                if ($expiringTickets) {
                    foreach ($expiringTickets as $expiringTicket) {
                        $toEmail = [];
                        $concernedPersons = $expiringTicket?->department?->concerned_persons;
                        if ($concernedPersons) {
                            foreach ($concernedPersons as $concerned_person) {
                                $findUser = User::find($concerned_person);
                                if ($findUser) {
                                    $toEmail[] = $findUser->email;
                                }
                            }
                        }
                        if (empty($toEmail)) {
                            $toEmail[] = 'admin@gmail.com';
                        }
                        $mailData = [
                            'to' => $toEmail,
                            'from' => env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'Ticket expiring',
                            'content' => "Your Ticket #" . $expiringTicket->unique_id . "is expiring today. Kindly take an action",
                            'subject' => 'Ticket expiring',
                            'greetings' => 'Hello Sir/Madam',
                            'end_greetings' => 'Regards,',
                            'from_user' => env('MAIL_FROM_NAME')
                        ];
                        Mail::send(new SendMailable($mailData));
                    }
                }

                break;
        }
        return $this->responseJson(true, 200, 'Cron job done', '');
    }
    public function assetTransfer(Request $request, $uuid)
    {
        $this->setPageTitle('Transfer Assets');
        $asset_stock_id = uuidtoid($uuid, 'asset_stocks');
        $assetStock = $this->assetStockService->findById($asset_stock_id);
        $assets = $this->assetService->listAssets([]);
        $locations = $this->assetService->listLocations();
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        if ($request->ajax()) {
            $rules = [
                'asset_items' => 'required',
                'location_id' => 'required',
                'entity_id' => 'required'
            ];
            $messages = [
                'asset_items' => 'Asset item is required',
                'location_id' => 'Location is required',
                'entity_id' => 'Entity is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if (!$request->asset_items) {
                $validator->getMessageBag()->add('maintenanceItemList', 'Select any item to lease');
            }
            // dd($validator->errors());
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            if ($assetStock->location->id == $request->location_id && $assetStock->entity->id == $request->entity_id) {
                return $this->responseJson(false, 200, 'Please choose different location or entity', '');
            }
            DB::beginTransaction();
            try {
                $newAssetStock = $this->assetService->getAssetStock(['asset_id' => $assetStock->asset_id, 'location_id' => $request->location_id, 'entity_id' => $request->entity_id]);
                if (!$newAssetStock) {
                    $newAssetStock = $this->assetService->addOrUpdateAssetStock(['uuid' => null], [
                        'asset_receipt_note_id' => $assetStock->asset_receipt_note_id,
                        'arn_item_id' => $assetStock->arn_item_id,
                        'category_id' => $assetStock->category_id,
                        'asset_type_id' => $assetStock->asset_type_id,
                        'asset_id' => $assetStock->asset_id,
                        'location_id' => $request->location_id,
                        'entity_id' => $request->entity_id,
                        'previous_stock' => 0,
                        'current_stock' => 0
                    ]);
                }
                $updateCount = 0;
                foreach ($request->asset_items as $asset_item) {
                    $isNewStockUpdated = $this->assetStockService->alterStockTable(['id' => $newAssetStock->id], 1, 'increase');
                    if ($isNewStockUpdated) {
                        $logData = [
                            'asset_stock_id' => $newAssetStock->id,
                            'asset_id' => $newAssetStock->asset_id,
                            'location_id' => $newAssetStock->location_id,
                            'entity_id' => $newAssetStock->entity_id,
                            'type' => 'add',
                            'quantity' => 1
                        ];
                        $this->assetStockService->addAssetStockLog($logData);
                        $isPrevStockUpdated = $this->assetStockService->alterStockTable(['id' => $assetStock->id], 1, 'decrease');
                        if ($isPrevStockUpdated) {
                            $prevLogData = [
                                'asset_stock_id' => $assetStock->id,
                                'asset_id' => $assetStock->asset_id,
                                'location_id' => $assetStock->location_id,
                                'entity_id' => $assetStock->entity_id,
                                'type' => 'substruct',
                                'quantity' => 1
                            ];
                            $this->assetStockService->addAssetStockLog($prevLogData);
                            $inventory = $this->assetService->findInventoryById($asset_item);
                            $inventoryData = [
                                'asset_stock_id' => $newAssetStock->id,
                            ];
                            $isInventoryUpdated = $inventory->update($inventoryData);
                            if ($isInventoryUpdated) {
                                $updateCount++;
                            }
                        }
                    }
                }
                if (count($request->asset_items) == $updateCount) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Asset successfully transferred', [
                        'redirect_url' => route('admin.assetstock.list', $assetStock->asset->uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.asset.stock.transfer', compact('uuid', 'assetStock', 'assets', 'locations', 'entities'));
    }
    public function listAttributes(Request $request, $uuid)
    {
        $this->setPageTitle('Asset Type Attributes');
        $assetTypeId = uuidtoid($uuid, 'asset_types');
        $assetType = $this->assetTypeService->findById($assetTypeId);
        $filterConditions = ['asset_type_id' => $assetTypeId];
        $attributes = $this->assetService->getAttributes($filterConditions);
        if ($request->ajax()) {
            $rules = [
                'name' => 'required',
            ];
            $messages = [
                'name' => 'Attribute name is required',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $attributeId = null;
                if ($request->uuid) {
                    $attributeId = uuidtoid($request->uuid, 'attributes');
                }
                $filterConditions = ['asset_type_id' => $assetTypeId];
                $attributes = $this->assetService->getAttributes($filterConditions);
                // if($attributes->contains('name',$request->name) && $attributeId == null){
                //     return $this->responseJson(false, 500, "This attribute name already taken", ['name' => 'This attribute name already taken']);
                // }

                if ($attributeId != null) {
                    $isAttributeExists = $attributes->filter(function ($attribute) use ($request, $attributeId) {
                        return $attribute['id'] != $attributeId && strtolower($attribute['name']) == strtolower($request->name);
                    });
                } else {
                    $isAttributeExists = $attributes->filter(function ($attribute) use ($request) {
                        return strtolower($attribute['name']) == strtolower($request->name);
                    });
                }
                if ($isAttributeExists->isNotEmpty()) {
                    return $this->responseJson(false, 500, "This attribute name is already taken", ['name' => 'This attribute name is already taken']);
                }

                $request->merge(['asset_type_id' => $assetTypeId, 'created_by' => auth()->user()->id, 'updated_by' => auth()->user()->id]);


                $isAttribute = $this->assetService->addOrUpdateAttribute($request->except(['_token', 'uuid']), $attributeId);


                if ($isAttribute) {
                    DB::commit();
                    $msg = $request->uuid ? 'Attribute updated successfully.' : 'Attribute added successfully.';
                    return $this->responseJson(true, 200, $msg, [
                        'redirect_url' => route('admin.assettype.attributes', $uuid)
                    ]);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.asset.type.attributes', compact('uuid', 'assetType', 'attributes'));
    }
    public function itemAllocationAcceptance(Request $request, $uuid, $notiuuid = null)
    {
        $this->setPageTitle('Accept Allocation Asset');
        $issuedItem = $this->assetStockService->findAssetIssueById(uuidtoid($uuid, 'asset_issues'));
        if ($request->ajax()) {
            $rules = [
                'otp' => 'required_if:otp,preset|integer|digits:4',
            ];
            $messages = [];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                if ($request->otp == $issuedItem->acceptance_otp) {
                    $isIssueUpdated = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => $uuid], $request->except('_token'));
                    if ($isIssueUpdated) {
                        DB::commit();
                        return $this->responseJson(true, 200, 'The asset acceptance status has been updated', [
                            'redirect_url' => route('assetstock.item.allocation.acceptance', $uuid)
                        ]);
                    }
                } else {
                    return $this->responseJson(false, 500, "Otp Does not Match", ['otp' => 'Otp Does not Match']);
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        if ($notiuuid != null) {
            $this->notificationMarkRead($notiuuid);
        }
        return view('admin.asset.stock.issue.acceptance', compact('issuedItem'));
    }


    public function downloadSampleExcel(Request $request)
    {
        $fileName = public_path() . "/assets/documents/sample-format-of-locations.xlsx";
        return response()->download($fileName, 'location-import-sample-data.xlsx');
    }
    public function addLocationsByExcel(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|file'
        ]);
        try {
            $isExcelImported = Excel::import(new AddLocationImport, $request->file('excel_file'));
            if ($isExcelImported) {
                return $this->responseJson(true, 200, 'Location Data Imported Successfully', [
                    'redirect_url' => route('admin.location.list')
                ]);
            } else {
                return $this->responseJson(false, 200, 'Something went Wrong', '');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }
    public function downloadAssetSampleExcel(Request $request, $type = null)
    {

        try {
            switch ($type) {
                case 'asset-type-category':
                    $file = public_path() . "/assets/documents/sample-format-of-asset-type-categories.xlsx";
                    return response()->download($file, 'asset-type-category-sample-data.xlsx');
                    // break;
                case 'asset-type':
                    $file = public_path() . "/assets/documents/sample-format-of-asset-types.xlsx";
                    return response()->download($file, 'asset-type-sample-data.xlsx');
                    // break;
                case 'assetstock':
                    $file = public_path() . "/assets/documents/sample-format-of-assetstocks.xlsx";
                    return response()->download($file, 'assetstock-sample-data.xlsx');
                    // break;
                default:
                    $file = public_path() . "/assets/documents/sample-format-of-assets.xlsx";
                    return response()->download($file, 'asset-sample-data.xlsx');
                    // break;
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }



    public function downloadAssetStockSampleExcel(Request $request)
    {
        try {
            $file = public_path() . "/assets/documents/sample-format-of-assetstocks.xlsx";
            return response()->download($file, 'asset-sample-data.xlsx');
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }




    public function downloadBulkAllocationSampleExcel(Request $request)
    {
        try {
            $file = public_path() . "/assets/documents/sample-format-of-bulk-allocation.xlsx";
            return response()->download($file, 'bulk-asset-allocation-sample-data.xlsx');
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }


    public function addAssetsByExcel(Request $request, $type = null)
    {

        try {
            switch ($type) {
                case 'asset-type-category':
                    $isExcelImported = Excel::import(new AddAssetImport($type), $request->file('excel_file'));
                    if ($isExcelImported) {
                        return $this->responseJson(true, 200, 'Asset Type Category Successfully Created.', [
                            'redirect_url' => route('admin.assettype.category.list')
                        ]);
                    }
                    break;
                case 'asset-type':
                    $isExcelImported = Excel::import(new AddAssetImport($type), $request->file('excel_file'));
                    if ($isExcelImported) {
                        return $this->responseJson(true, 200, 'Asset Type Successfully Created.', [
                            'redirect_url' => route('admin.assettype.list')
                        ]);
                    }
                    break;
                case 'assetstock':
                    // $isExcelImported = Excel::import(new AddAssetStockImport($type), $request->file('excel_file'));
                    $isExcelImported = Excel::import(new AddAssetImport($type), $request->file('excel_file'));
                    if ($isExcelImported) {
                        $redirectUrl = route('admin.asset.list');
                        return $this->responseJson(true, 200, 'Asset Successfully Created.', [
                            'redirect_url' => $redirectUrl
                        ]);
                    }
                    break;


                case 'inventory':

                    $isInventoryExcelImported = Excel::import(new AddAssetInventoryImport($type), $request->file('excel_file'));
                    if ($isInventoryExcelImported) {
                        $redirectUrl = route('admin.asset.list');
                        return $this->responseJson(true, 200, 'Asset Successfully Created3.', [
                            'redirect_url' => $redirectUrl
                        ]);
                    }
                    break;


                    // case 'assetstock':
                    //     // $isExcelImported = Excel::import(new AddAssetStockImport($type), $request->file('excel_file'));
                    //     $isExcelImported = Excel::import(new AddAssetImport($type), $request->file('excel_file'));
                    //     if ($isExcelImported) {
                    //         $redirectUrl = route('admin.asset.list');
                    //         return $this->responseJson(true, 200, 'Asset Successfully Created.', [
                    //             'redirect_url' => $redirectUrl
                    //         ]);
                    //     }
                    //     break;

                default:
                    $isExcelImported = Excel::import(new AddAssetImport($type), $request->file('excel_file'));
                    if ($isExcelImported) {
                        return $this->responseJson(true, 200, 'Asset Successfully Created.', [
                            'redirect_url' => route('admin.asset.list')
                        ]);
                    }
                    break;
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }






    public function addAssetStockByExcel(Request $request)
    {

        try {
            // dd($request->arn_uuid);
            $isExcelImported = Excel::import(new AddAssetStockImport($request,$this->assetService,$this->assetTypeService), $request->file('excel_file'));
            //$isExcelImported = Excel::import(new AddAssetStockSheetSelection($request,$this->assetService,$this->assetTypeService), $request->file('excel_file'));
            if ($isExcelImported) {
                return $this->responseJson(true, 200, 'Asset Stock Added successfully.', [
                    'redirect_url' => route('admin.arn.view', $request->arn_uuid)
                ]);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }




    public function bulkAssetAllocation(Request $request)
    {

        try {

            $isExcelImported = Excel::import(new BulkAssetAllocationImport($request,$this->assetService,$this->assetTypeService,$this->assetStockService), $request->file('excel_file'));

            if ($isExcelImported) {
                return $this->responseJson(true, 200, 'Asset Stock Added successfully.', [
                    'redirect_url' => route('admin.assetstock.inventory', [$request->inventory_uuid, 'leaseUuid' => $request->lease_uuid])
                ]);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }




    public function downloadAassetLease(Request $request, $type, $uuid)
    {

        if ($request->inventories) {
            $asset_stock = $this->assetStockService->findById(uuidtoid($uuid, 'asset_stocks'));
            $amounts = explode(',', $request->amounts);
            $inventoryIds = explode(',', $request->inventories);
            $inventories = $this->assetStockService->findInventoryItems($inventoryIds);
            $userIds = $request->userIds ? explode(',', $request->userIds) : [];
            $vendor_information = [];
            $user_informations = [];
            if (!$userIds) {
                if ($request->vendorId != null) {
                    $vendor = $this->vendorService->findUserById($request->vendorId);
                    $vendor_information['vendor_id'] = $vendor->id;
                    $vendor_information['vendor_name'] = $vendor->full_name;
                    $vendor_information['vendor_phone'] = $vendor->mobile_number;
                    $vendor_information['vendor_email'] = $vendor->email;
                } else {
                    $vendor_information['vendor_id'] = '';
                    $vendor_information['vendor_name'] = $request->vendorName;
                    $vendor_information['vendor_phone'] = $request->vendorPhone;
                    $vendor_information['vendor_email'] = $request->vendorEmail;
                }
            } else {
                foreach ($userIds as $key => $userId) {
                    $user = $this->userService->findUserById($userId);
                    $user_informations[$key]['user_name'] = $user->full_name;
                    $user_informations[$key]['user_phone'] = $user->mobile_number;
                    $user_informations[$key]['user_email'] = $user->email;
                }
            }
            if ($type == 'pdf') {
                $dompdf = new Dompdf();
                $html = view('admin.asset.stock.lease-pdf', compact('asset_stock', 'amounts', 'inventories', 'vendor_information', 'user_informations'));
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'potrait');
                $dompdf->render();
                $pdfOutput = $dompdf->output();
                $filename = 'lease_agreement_' . time() . '.pdf';
                return Response::make($pdfOutput, 200, [
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'attachment; filename="' . $filename . '"',
                ]);
            } else {

                $phpWord = new PhpWord();
                $sectionStyle = [
                    'orientation' => 'portrait',
                    'paperSize' => 'A4'
                ];
                $section = $phpWord->addSection($sectionStyle);
                $imagePath = public_path('assets/images/logo.png');
                $section->addImage($imagePath, [
                    'width' => 280,
                    'height' => 80,
                    'alignment' => Jc::CENTER
                ]);

                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 24, // H1 size
                    'color' => '0000FF', // Blue color
                    'bold' => true,
                    'alignment' => Jc::CENTER
                ];

                $section->addText('EQUIPMENT RENTAL AGREEMENT', $headingStyle, ['alignment' => Jc::CENTER]);

                $section->addText('This Agreement for Providing Services (For Short “Agreement”) is made and executed at Kolkata
                on this the Friday 13th December, 2024 between Constantia Corporate Shared Services Pvt Ltd
                , a company having its registered office at Constantia 7th Floor, B-Wing, 11, Dr. U. N. Brahmachari
                Street, Kolkata - 700017 (hereinafter referred to as “CCSSPL” which expression shall mean and
                include its Authorised Representatives, Successors-in-Interest, Agents and Assigns) on the one
                part');


                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 18, // H1 size
                    'color' => '000000', // Blue color
                    'bold' => true,
                    'alignment' => Jc::CENTER
                ];

                $section->addText('And', $headingStyle, ['alignment' => Jc::CENTER]);


                $section->addText('Haribhakti and Co LLP, with registered office at 705, Leela Business Park, Andheri Kurla Road,
                Andheri (East), Mumbai - 400059 (hereinafter referred to as “Client” which expression shall mean
                and include its representatives, successors-in-interest and assigns of the other part.');


                $section->addText('WHEREAS CCSSPL has represented and warranted to Client that it has the requisite expertise
                and skill to effectively perform the Services (which are elaborated below in this Agreement and in
                the applicable and relevant statement of work duly executed by and between the parties from time
                to time)');


                $section->addText('WHEREAS Client has been satisfied with various representations and warranties made by
                CCSSPL with regard to the various services that CCSSPL offers and proposes to provide using its
                expertise in the field of Equipment/Laptops which include but are not limited to Laptops,
                Computers, Hardware Products and Software Products and Client having satisfied itself with the
                expertise of the Service Provider and has agreed to this agreement which also subsumes all the
                previous agreement in relation to Laptops and Other Equipments entered into. The Services
                agreed are mentioned in the terms herein contained in the “Statement of Work” appended to this
                Agreement as Annexure - .');


                $section->addText('WHEREAS the Parties herein above having satisfied themselves with the negotiations
                between them and having arrived with their respective terms to which they have agreed abide by,
                both the Parties to this Agreement have decided to reduce into writing the said terms and
                conditions as follows:');


                $headingStyle = [
                    'name' => 'Arial',
                    'size' => 18, // H1 size
                    'color' => '000000', // Blue color
                    'bold' => true,
                    'alignment' => Jc::LEFT
                ];

                $section->addText('NOW THIS DEED OF EQUIPMENT RENTAL AGREEMENT WITNESSETH AS FOLLOWS', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('1. STATEMENT OF WORK FOR SERVICES', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('1.1 Contract Components : Subject to the terms and conditions of this Agreement, CCSSPL shall
                provide services, as elaborated in the Statement of Work attached hereto as Annexure - I (For
                Short “Services”). A Statement of Work will set forth the services to be provided, the time
                schedules for services and all fees, costs, invoicing guidelines and related expenses to be paid by
                the Client, for all the works done and services rendered. The parties may enter into any such
                additional statements of work, if any, so required, and, if so, each will constitute a separate contract
                subject to the terms and conditions of this Agreement.');


                $section->addText('2. TERM AND TERMINATION', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('2.1 Term : This Agreement shall be effective from the date of execution of this Agreement and
                    shall be valid and in force unless terminated in terms of this Agreement for a period of Thirty Six(36) months commencing on the Effective date and upon expiry of the said term. Upon this
                    agreement, Client will be able to place requests for multiple consignments as per the scope of work
                    detailed in Annexure - I. The start date for each consignment shall begin afresh from the date of
                    delivery. Replacements will not be considered as new consignments. In case the contract is
                    required to be extended, the same shall be so extended upon the same or such terms and
                    conditions as agreed to mutually between the Parties. In such a case, the revised period of this
                    agreement shall have to be added as an Addendum in writing as mutually decided by both the
                    Parties. A lock-in period of 3(three) months shall apply to the term of this Agreement during which
                    Client shall not be able to terminate the contract, other than in the specific circumstances described
                    herein (“Lock In Period”).
                    ');



                $section->addText('2.2 Termination for Breach by either Party : If either party defaults in the performance of any
                material provision of this Agreement (“Material Breach”), the non-defaulting party may terminate
                this Agreement upon thirty (30) days’ written notice thereof duly assigning the reason. CCSSPL
                may also terminate this Agreement in case of non-material default by Client by serving Client a
                prior notice in writing of 30 (thirty) days’. In both of the above cases, the notice serving Party may
                provide the defaulting Party with a cure period of 15 (Fifteen) days to rectify the breach (“Cure
                Period”). The Cure Period may be provided at the sole discretion of the non-defaulting Party.”).
                    ');


                $section->addText('2.3 Termination during the Lock In Period: If Client wishes to return the items during the Lock-In
                Period, as mentioned in the Annexure -I of this agreement, this shall be treated as a termination
                event and any termination of this nature, other than that of a material breach of this Agreement by
                CCSSPL or due to Force Majeure, within the Lock-in- Period shall be liable to a minimum advance
                notice period, in writing, of 30 (thirty) days. Further, any failure to serve the notice period specified
                in this provision shall make Client liable for payment of rent equivalent to such period in lieu of
                notice.');


                $section->addText('2.4 Force Majeure : Either party may terminate this Agreement forthwith in case the performance
                of the agreement is adversely affected by a Force Majeure Events such as natural disaster, riots or
                law and order problems, etc. for a successive period of 30 (Thirty) days or a cumulative period of
                45 (Forty Five) days during the term.');


                $section->addText('2.5 Without prejudice to the foregoing, the termination of this Agreement pursuant to any of the
                provisions contained hereinabove shall not limit or otherwise affect any other remedy (including a
                claim for damages) which either party may have, arising out of the right which may give rise to the
                right of termination.
                ');


                $section->addText('2.6 Consequences of Termination: Notwithstanding the termination of this Agreement, Client
                shall not be entitled to withhold any payments which are due to CCSSPL for Services already
                rendered and those which are in process on the date of termination. CCSSPL shall not be liable to
                render or complete the services that are in process at any time when the agreement is terminated
                in any manner mentioned above, unless expressly agreed to, in writing, between the Parties to the
                contrary. In such an event, the parties shall cease to use the confidential information or the
                intellectual property rights of the other party.All products and equipment shall be returned by Client to CCSSPL as on the date of termination.
                CCSSPL shall be entitled to survey said equipment upon its return and to make a determination in
                respect of any damaged caused. Such damage shall be set-off against the Security Deposit
                wherever required. Where such Security Deposit is not sufficient to cover the extent of damage,
                Client shall be liable to pay the amount determined as damage recompense or repair costs within a
                period of 14 (fourteen) days from the date of the damage notice issued by CCSSPL. Any failure to
                pay such amounts due shall make Client liable to pay on the amount due at the rate of interest of
                18 percent p.a. from the date of expiry of the above period uptil the date of remittance of the entire amount due.');


                $section->addText('3. CONFIDENTIALITY', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('Each party to this Agreement recognizes the importance of maintaining appropriate safeguards
                against improper disclosure of the Confidential Information of each Party hereto and recognizes
                that such disclosure may result in damage to each of them. Accordingly, both the parties agree to
                maintain the confidentiality with respect to all the Confidential Information and to use such
                Confidential Information only in furtherance of the purposes of this Agreement so as to maintain
                cordial and professional reciprocity. “Confidential Information” shall include but not be limited to:
                financials, bank details, techniques, schematics, designs, contracts, financial information, sales and
                marketing plans, business plans, business affairs, operations, strategies, inventions,
                methodologies, technologies, employees, subcontractors, pricing, methods of operations,
                procedures, products and/or services.
                Further, both the Parties hereto agree that they shall treat all the Confidential Information of either
                Party with atleast the same degree of care as it accords to its own Confidential Information, and
                each of them assure the other that it shall exercise all reasonable care to protect its Confidential
                Information, which includes and at a minimum, limiting access of Confidential Information solely to
                the Authorized Personnel of either Companies. Both the Parties undertake that neither of them
                shall publicize, or disclose the presence of this Agreement nor use in any manner the name or
                logos of either without the prior written permission of authorized representative of the other. The
                obligations of the Confidentiality under this Agreement shall survive any expiry or termination of this
                Agreement.
                These confidentiality obligations shall not apply in the following circumstances:
                a. such Confidential Information has come into the public domain (other than as a result of breach
                of any obligation of confidentiality by either Party); or
                b. any disclosure of such Confidential Information has been authorised in writing by either Party; or
                c. disclosure of the Confidential Information concerned is required under law or under order of a
                competent authority.');

                $section->addText('4. PRICING AND PAYMENT TERMS :', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('4.1 Client agrees to accept the Services, as per the rates mentioned in Annexure - I.
                    4.2 Client shall make all the payments upon the servicing being rendered as per the agreed
                    schedule and shall not withhold any payment or portion thereof towards fees on the ground of any
                    dispute even in good faith; and all such disputes, if any, shall be notified and resolved by the
                    Parties before any further service is provided.
                    ');


                $section->addText('5. REPRESENTATIONS, WARRANTIES AND UNDERTAKINGS', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('5.1 Authority and Performance by the Parties:
                    (i) They have the legal right to enter this Agreement and perform their respective obligations
                    hereunder;
                    (ii) The performance of their respective obligations will not violate any applicable laws or
                    regulations, or cause a breach of any agreements, with any third parties;
                    (iii) The performance of their respective obligations will not infringe upon intellectual Property rights
                    of any third parties and
                    (iv) Both the Parties herein above assure that they have obtained all regulatory approvals/ licenses
                    to seek and/or perform the Services covered by this Agreement. In the event of a breach of
                    representations, either Party may terminate this Agreement with immediate effect, notwithstanding
                    any other rights/s to seek for other specific or equitable remedies including but not limited to legal
                    action.');


                $section->addText('6. INTELLECTUAL PROPERTY AND OWNERSHIP', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('6.1 All intellectual property rights (“IPR”) existing prior to the Effective Date of this Agreement will
                belong to the party that owned such rights immediately prior to the Effective Date (“Background IP
                ”). Parties shall not gain by virtue of this Agreement, any rights of ownership of copyrights, patents,
                design, trade secrets, trademarks or any other IPR owned by the other party. Any IPR created
                during the term of this Agreement by way of Services rendered shall always vest in CCSSPL and
                where additional documentation is required for such IPR to vest in CCSSPL, Client shall execute
                the necessary documentation to facilitate such transfer.
                6.2 Client shall at no point of time acquire title or ownership to the products provided to it under this
                Agreement. The title or ownership to the products shall at all times continue to vest in CCSSPL or
                the owner of the products. Where Client becomes aware of a threat of seizure of the
                equipment/products it shall immediately inform CCSSPL of the possible threat of such seizure. A
                failure to do so will be considered a material breach of this Agreement and may make Client liable
                to compensate CCSSPL for the cost of equipment/products so seized.
                6.3 Client shall not be authorized to sub-lease or in any other manner alienate or dispose of the
                equipment/products to any third-parties.
                ');


                $section->addText('7. INDEMNITY', $headingStyle, ['alignment' => Jc::LEFT]);




                $section->addText('Both the Parties herein above assure each other that they shall indemnify, defend and hold each
                other harmless from and against any claim, liability, obligation, loss, damage, deficiency,
                assessment, judgement, cost or expense (including, without limitation to costs and expenses
                incurred in preparing and defending against or prosecuting any litigation, claim, action, suit
                proceeding or demand) of any kind or character, arising out of or attributable to any inaccuracy,
                breach, or failure occasioned on account of any act or omission on the part of either of them in
                relation to the other in performance of the obligation of each of them arising out of this agreement.
                ');



                $section->addText('8. LIMITATION OF LIABILITY', $headingStyle, ['alignment' => Jc::LEFT]);




                $section->addText('Both the Parties herein above agree and assure that they shall be liable for any damages against
                the other and shall be entitled to make any claim in that regard against the other only to the extent
                of the value of the Services performed or the actual loss suffered, whichever is lower. In case of
                any dispute as to the value worth of the loss suffered each party hereto shall mutually resolve the
                issue based on the market rates of such service and/or based upon the agreed terms in that regard
                which the Parties may reduce into writing in a separately executed Supplementary Agreement as
                and when it is so made during the currency of this Agreement and shall form part hereof as
                Annexure - II.
                Further, CCSSPL is neither the manufacturer, dealer nor supplier of the products/equipment and
                makes no warranties, express or implied, as to any matter whatsoever, including but not limited to
                the condition of the equipment, its merchantability, design, workmanship or its fitness for any
                particular purpose. CCSSPL also disclaims all liability for damage, loss or injury to Client, its
                employees, officers, directors etc., or any third parties as a result of any defects latent in the
                equipment/products. The products/equipment are provided to Client on an “as is” basis. CCSSPL
                shall not be liable for any loss, delay or damage of any kind to Client resulting from defects or
                inefficiency in the equipment/products. CCSSPL shall also not be liable for any loss or damage to
                property, material or equipment belonging to Client or third-parties while such equipment/products
                are in the care, custody or control of Client.');


                $section->addText('9. ASSIGNMENT', $headingStyle, ['alignment' => Jc::LEFT]);
                $section->addText('Neither party may transfer or assign any of its rights or obligations under this Agreement without
                prior written consent of the other party, which consent shall not be unreasonably withheld.');


                $section->addText('10. FORCE MAJEURE', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('10.1 A “Force Majeure Event” means:
                10.1.1 Any event or circumstance or combination of events or circumstances affecting a Party (the
                “Affected Party”), such as to prevent or delay the Affected Party in the performance of its
                obligations under this Agreement, where such delay or failure was due to an event which is not
                substantially attributable to any Party and is beyond the Affected Party’s control and which could
                not reasonably have provided for, by the Affected Party, before entering into the Agreement and
                which, having arisen, such Party could not reasonably have overcome or avoided, and shall
                include:
                a. War, hostilities (whether war be declared or not), invasion, act of foreign enemies;
                b. Rebellion, terrorism, revolution, insurrection, political unrest, military or unsurped power, or civil
                war;
                c. Riot, commotion, disorder, strike or lock-out by employees of either Party; and
                d. Natural catastrophes such as earthquake, cyclone floods, tsunamis or volcanic activity');





                $section->addText('11. INFORMATION SHARING', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('Client shall ensure to share with and not withhold the necessary information from CCSSPL as
                listed below:
                11.1 Rental Tenure (Rental Duration of products as described in the ANNEXURE - I of this
                agreement).
                11.2 Any Complaints or Service Requests (scheduled or otherwise)
                11.3 Inform in writing regarding the relocation of products to locations other than where they were
                originally installed.
                11.4 Any damage caused to the products, physical, technical, or otherwise.
                As defined in the Annexure -I of this Agreement, CCSSPL shall be notified of all information within
                a reasonable period of time. With respect to 11.4, the prior written consent of CCSSPL and the
                relocation fees applicable shall be pre-requisites to any relocation of the products by Client. Failure
                to keep CCSSPL informed in respect of all matters dealt with under this provision shall be treated
                as a material breach of this Agreement.');

                $section->addText('12. MISCELLANEOUS', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('12.1 The schedule of payments shall be as per the details agreed and mentioned is annexed as
                Annexure -I.
                12.2 Both the Parties shall agree to make and execute a separate Non-Disclosure Agreement if it is
                found desirable which shall cover exhaustively the issues of the confidentiality obligations of the
                parties herein, which shall bind both the parties.
                12.3 Maintenance: CCSSPL shall be responsible for the periodic maintenance of all
                equipment/products rented by Client under this Agreement at CCSSPL’s own cost. It shall include
                repair and support in respect of any hardware related problems that may be encountered in respect
                of the equipment/products. CCSSPL shall endeavour to undertake all maintenance activity within a
                24 (twenty four) hour timeframe from the time of receipt of the complaint. CCSSPL shall not repair
                or replace at its own cost any equipment/products to which breakage or damage has been caused,
                for any reason whatsoever, after such equipment/products have been installed at the location
                specified by Client. For all such damage Client shall be wholly liable to bear the entire cost of
                repair/replacement. The provisions of this Agreement dealing with outstanding dues from Client
                shall apply to all such repair/replacement and amounts outstanding in that respect.
                12.4 Notices. Any notice required to be served by either party shall be deemed to have been
                served if the same is sent by e-mail or by registered post acknowledgement due addressed to the
                other party at the address indicated first herein above.
                12.5 Governing Law: This Agreement shall be governed in all respects by the substantive laws of
                India. Parties shall endeavour to resolve all disputes amicably at first, failing which the courts in
                Calcutta shall have exclusive jurisdiction to adjudicate any matter involved hereunder.
                12.6 Severability. If any provision of this Agreement is held by a court of competent jurisdiction to
                be invalid, void or unenforceable, the remaining provisions shall continue in full force and effect.
                12.7 Entire Agreement. This Agreement embodies the entire agreement and understanding of the
                parties hereto, and shall be read along with all the Annexure appended hereto including the
                Proposal Letter and shall supersede all prior or contemporaneous oral communications or
                arrangements between the Parties, regarding the subject matter hereof.
                12.8 Waivers. The failure of either party to insist upon the performance of any of the terms,
                covenants, or conditions of this Agreement or to exercise any right hereunder, shall not be
                construed as a waiver or relinquishment of the future performance of any rights, and the obligations
                of the party with respect to such future performance shall continue in full force and effect.
                12.9 Counterparts. This Agreement may be executed in one or more counterparts each of which
                shall be an original and all of which together shall constitute one and the same instrument.
                12.10 Independent Contractor Status. The relationship created by this Agreement is one of
                independent contractors, and not partners, franchisees or joint ventures. No employees,
                consultants, sub-contractors or agents of one party are employees, consultants, contractors, or
                agents of the other party, nor do they shall have any authority to bind the other party by contract or
                otherwise to any obligation, except as expressly set forth herein. Neither party will represent to the
                contrary, either expressly, implicitly or otherwise.
                12.11 Point of Contact: The following shall serve as the POC for respective companies subjected to
                their employment with their firms. In case of any change, the same shall be informed and intimated by both the parties immediately to facilitate a smooth association.');


                $boldStyle = ['bold' => true];
                $normalStyle = [];

                if ($vendor_information) {
                    $section->addText('For CCSSPL:', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Name: ' . $vendor_information['vendor_name'], $normalStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Phone: ' . $vendor_information['vendor_phone'], $normalStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Email: ' . $vendor_information['vendor_email'], $normalStyle, ['alignment' => Jc::LEFT]);
                }

                if ($user_informations) {
                    foreach ($user_informations as $user_information) {
                        $section->addText('For Client:', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Name: ' . $user_information['user_name'], $normalStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Phone: ' . $user_information['user_phone'], $normalStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Email: ' . $user_information['user_email'], $normalStyle, ['alignment' => Jc::LEFT]);
                    }
                }



                $section->addText('All disputes or differences between the parties arising out of this agreement will subject to jurisdiction of Courts of Calcutta only.IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the day and year first set forth above.');

                if ($vendor_information) {
                    $section->addText('For Constantia Corporate Shared Services Pvt Ltd:', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Signature of Authorised Signatory: ', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Name: ' . $vendor_information['vendor_name'], $normalStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Desgination : Director: ', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Witness 1.', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Name : ', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Address : ', $boldStyle, ['alignment' => Jc::LEFT]);
                    $section->addText('Phone No. ', $boldStyle, ['alignment' => Jc::LEFT]);
                }

                if ($user_informations) {
                    $section->addText('For Client', $boldStyle, ['alignment' => Jc::LEFT]);

                    foreach ($user_informations as $user_information) {
                        $section->addText('Signature of Authorised Signatory: ', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Name: ' . $user_information['user_name'], $normalStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Desgination : Director: ', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Witness 1.', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Name : ', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Address : ', $boldStyle, ['alignment' => Jc::LEFT]);
                        $section->addText('Phone No. ', $boldStyle, ['alignment' => Jc::LEFT]);
                    }
                }
                $section->addText('ANNEXURE - I', $boldStyle, ['alignment' => Jc::LEFT]);
                $section->addText('Statement of Product/Equipment', $boldStyle, ['alignment' => Jc::LEFT]);
                $section->addText('CCSSPL would supply the following items on rental basis in a time and material engagement with the Client.', $boldStyle, ['alignment' => Jc::LEFT]);



                $tableStyle = [
                    'borderSize' => 6,
                    'borderColor' => '999999',
                    'cellMargin' => 80
                ];
                $firstRowStyle = ['bgColor' => 'FFFF00'];
                $phpWord->addTableStyle('', $tableStyle, $firstRowStyle);
                $table = $section->addTable('');


                $table->addRow();
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Asset Info');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Serial Number');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Capacity / Specifications');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Asset Condition');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Purchase Date');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Warranty Date');
                $table->addCell(2000, ['bgColor' => 'cceeff'])->addText('Rent / Lease Amount');


                foreach ($inventories as $k => $inventory) {

                    $table->addRow();

                    $category = $asset_stock->category?->name ?? '';
                    $type = $asset_stock->assettype?->name ?? '';
                    $assetName = $asset_stock->asset?->asset_name ?? '';
                    $assetId = $asset_stock->asset?->asset_id ?? '';
                    $serialNo = $inventory->unique_id ?? '';
                    $identificationNo = $inventory->identification_no ?? '';

                    $table->addCell(2000)->addText(
                        'Category: ' . $category .
                            ' || Type: ' . $type .
                            ' || Asset: ' . $assetName . ' (' . $assetId . ')' .
                            ' || Serial No: ' . $serialNo .
                            ' || Identification No.: ' . $identificationNo
                    );



                    $table->addCell(2000)->addText($inventory->unique_id);;
                    $table->addCell(2000)->addText(str_replace('&', 'and', strip_tags($inventory->capacity_specs)));
                    $table->addCell(2000)->addText($inventory->asset_condition);

                    $table->addCell(2000)->addText(
                        $inventory->purchase_date
                            ? Carbon::parse($inventory->purchase_date)->format('d-m-Y')
                            : ''
                    );
                    $table->addCell(2000)->addText(
                        $inventory->warranty_licence_date
                            ? Carbon::parse($inventory->warranty_licence_date)->format('d-m-Y')
                            : ''
                    );

                    $table->addCell(2000)->addText('Rs ' . number_format((float) $amounts[$k], 2, '.', ','));
                }



                $section->addText('All the prices are exclusive of applicable GST');
                $section->addText('Any amount recovered towards damage / loss made to the equipment shall also be subjected to
                applible GST');


                $section->addText('Effective Date: ' . Carbon::now()->format('l jS F, Y'), ['alignment' => Jc::LEFT]);


                $section->addText('DOCUMENTS OF PROOF AND IDENTIFICATION', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('Following Documents needs to be furnished at the time of delivery of each consignment :');
                $section->addText('Certificate of Incorporation.');

                $section->addText('Registered Office and Head Office Address Proof');

                $section->addText('Identification Proof of the Owner/Partner/Director of the Company');


                $section->addText('QUALITY CONTROL', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('CCSSPL shall ensure that the quality of each product being shipped is up to the industry
                standard. In the case of Client wishing to evaluate the quality of the products, CCSSP shall
                invite their concerned team of members for the same to our storage location/locations before
                delivery or showcase a sample of the concerned products, whichever is mutually agreed by
                the parties. The evaluation of the items will be on sole discretion of CCSSPL only');


                $section->addText('In case of the products/items reaching the agreed upon location are physically damaged,
                CCSSPL shall take full responsibility to replace the products with appropriate alternates with
                no extra charges. This shall be subject to Client informing CCSSPL in writing - with images -
                regarding such damaged products within 12 (Twelve) hours of receipt of said products by
                Client. Any such claims thereafter shall not be entertained by CCSSPL');


                $section->addText('In case the products provided are not physically damaged and the Client expresses its desire
                of Disliking the product the replacement on this ground wouldn’t be entertained.');


                $section->addText('COST OF RELOCATION', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('Any change in the scope of work would be adjusted by quantifying the corresponding changes with
                respect to pricing as provided on the Rate Card above.');


                $section->addText('CCSSPL discourages the relocation of products at any point in time and in case a situation arises,
                Client agrees and will make sure that a notice in writing is shared with CCSSPL 15 (Fifteen) days
                prior to any such event seeking permission for relocation. CCSSPL will then approve the relocation
                where deemed reasonable. Such relocation shall only be within a 10km radius of the original
                installation location. Further, CCSSPL shall not bear the charges for re-locating and re-installing
                the items during the rental tenure. All relocation activities shall be carried as per CCSSPL
                standards and only under the supervision of CCSSPL representatives at the site of relocation.
                Relocation of items does not affect the package tenure and the tenure will continue as per the initial
                order. In case Client wishes to get the items moved from one location to another by using CCSSPL
                Logistics, then the transportation and installation charges will be applicable. The relocation charges
                payable to CCSSPL by Client shall be Rs. 500/- (Rupees Five Hundred Only) per equipment.');


                $section->addText('COST OF SERVICING', $headingStyle, ['alignment' => Jc::LEFT]);





                $firstRowStyle = ['bgColor' => 'FFFF00'];
                $phpWord->addTableStyle('', $tableStyle, $firstRowStyle);
                $table = $section->addTable('');


                $table->addRow();
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('Free Service for Products');
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('Only for Technical Issues');


                $table->addRow();
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('Free Replacement of Products');
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('Only for Technical Issues');


                $table->addRow();
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('To be paid by Client as per Actual ');
                $table->addCell(4000, ['bgColor' => 'FFFFFF'])->addText('Physical Damages to Products');



                $section->addText('TERMINATION OR RETURN OF ITEMS', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('1. CCSSPL shall cease to continue its services to Client upon termination of the Agreement and
                shall pick up the items within 2 (two) days of the date of termination, “Pick-up Period”.
                2. During the Pickup Period, Client warrants to grant support and ensure that none of the
                products/equipment is lost or damaged and that these are returned in good and working
                condition to CCSSPL. In case of any damage or loss of products/equipment by Client during
                this period or otherwise, Client agrees to bear the cost of such damage/loss as per the actual
                MRP of the items that are reported as missing/damaged by CCSSPL.
                ');


                $section->addText('EXTENSION OF ITEMS', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('If Client wishes to extend the term of this Agreement, they can do so by requesting over email at
                least 30 (thirty) days before the Agreement’s end date. The subsequent extensions can be done
                only for whole months (multiple of 30 days) and not on a pro-rata basis');


                $section->addText('ANNEXURE - II', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('PAYMENT', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('1. An advance payment of the following need to be made before the items are delivered :
                1.1. First Month’s Rent
                2. Rent payments are to be made at the beginning of each month.
                2.1 Monthly advance rent invoices will be generated in the First week of every Month and the
                same is to be paid within 7 (seven) Days of raising the invoice.
                2.2. In case of late payment i.e. after 7 (seven) Days of raising the invoice, 1.5% interest per
                month (pro-rated for shorter periods) shall start to apply as late fees.
                ');


                $section->addText('BANK ACCOUNT DETAILS', $headingStyle, ['alignment' => Jc::LEFT]);


                $section->addText('Name: Constantia Corporate Shared Services Pvt Ltd', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('Bank/Branch: Kotak Mahindra Bank/Park Street', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('Bank A/c No. : 9414561817', $headingStyle, ['alignment' => Jc::LEFT]);

                $section->addText('IFSC Code: KKBK0000322', $headingStyle, ['alignment' => Jc::LEFT]);

                $filename = 'lease_agreement_' . time() . '.docx';
                $tempFile = tempnam(sys_get_temp_dir(), 'phpword');
                $writer = IOFactory::createWriter($phpWord, 'Word2007');
                $writer->save($tempFile);

                return response()->download($tempFile, $filename)->deleteFileAfterSend(true);
            }
        } else {
            return $this->responseJson(false, 200, 'Please select any asset inventory', '');
        }
    }
}
