<?php

namespace App\Http\Controllers\Admin\User;

use Illuminate\Http\Request;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Services\Role\RolePermissionService;

class RolePermissionController extends BaseController
{
    public function __construct(protected RolePermissionService $rolePermissionService, protected UserService $userService)
    {
        $this->rolePermissionService= $rolePermissionService;
        $this->userService= $userService;
    }

    public function roles(Request $request){
        $this->setPageTitle('Manage Roles');
        return view('admin.settings.role.index');
    }

    public function permissions(Request $request){
        $this->setPageTitle('All Permissions');
        return view('admin.settings.permission.index');
    }

    public function addRole(Request $request){
        $this->setPageTitle('Add Role');
        if($request->ajax()){
            $rules = [
                'name'=> 'required|unique:roles,name',
                'level'=> 'required'
            ];
            $messages = [
                'name' => 'Name field is required.',
                'level' => 'Level field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try{
                $isRoleCreated= $this->rolePermissionService->addRole($request->except('_token'));
                if($isRoleCreated){
                    DB::commit();
                    return $this->responseJson(true, 200, 'Role added successfully.', [
                        'redirect_url' => route('admin.settings.role.attach.permission', ['id' => $isRoleCreated->id])
                    ]);
                }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.settings.role.add');
    }
    public function EditRole(Request $request, $id){
        $this->setPageTitle('Edit Role');
        $roleData = $this->rolePermissionService->findRoleById($id);
        if($request->ajax()){
            $rules = [
                'name'=> 'required',
                'level'=> 'required'
            ];
            $messages = [
                'name' => 'Name field is required.',
                'level' => 'Level field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try{
                $isRoleUpdated = $this->rolePermissionService->updateRole($request->except('_token'), $id);
                if($isRoleUpdated){
                    DB::commit();
                    return $this->responseJson(true, 200, 'Role updated successfully.', [
                        'redirect_url' => route('admin.settings.role.list')
                    ]);
                }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.settings.role.edit', compact('roleData'));
    }

    public function addPermission(Request $request){
        $this->setPageTitle('Add Permission');
        if($request->post()){
            $request->validate([
                'name'=> 'required|unique:permissions,name'
            ]);
            DB::beginTransaction();
            try{
                $isPermissionCreated= $this->rolePermissionService->addPermission($request->only(['name']));
                if($isPermissionCreated){
                    DB::commit();
                    return $this->responseRedirect('admin.permission.list',"Permission Added Successfully",'success');
                }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something Went Wrong','error',true);
            }
        }
        return view('admin.settings.permission.add');
    }

    public function attachPermissions(Request $request,$id){
        $this->setPageTitle('Attach Role Permissions');
        $roleData = $this->rolePermissionService->findRoleById($id);
        $permissions = $this->rolePermissionService->getAllPermissions();

        // $permissions= $this->rolePermissionService->getAllPermissions();
        //$count= count($permissions);
        //$chunk= $count/5;
        //$permissions= $permissions->chunk(ceil($permissions->count()/$chunk));
       // $type= "masters";

        // $mastersPermissions = $this->rolePermissionService->getAllPermissions("masters");
        // if(count($mastersPermissions)){
        //     $count = count($mastersPermissions);
        //     $chunk = $count/5;
        //     $mastersPermissions = $mastersPermissions->chunk(ceil($mastersPermissions->count()/$chunk));
        // }

        // $modulesPermissions = $this->rolePermissionService->getAllPermissions("modules");
        // if(count($modulesPermissions)){
        //     $count = count($modulesPermissions);
        //     $chunk = $count/5;
        //     $modulesPermissions = $modulesPermissions->chunk(ceil($modulesPermissions->count()/$chunk));
        // }

        // $settingsPermissions = $this->rolePermissionService->getAllPermissions("settings");
        // if(count($settingsPermissions)){
        //     $count = count($settingsPermissions);
        //     $chunk = $count/3;
        //     $settingsPermissions = $settingsPermissions->chunk(ceil($settingsPermissions->count()/$chunk));
        // }

        // dd($permissions);
        if($request->post()){
            DB::begintransaction();
            try{
                // if($roleData->slug != 'super-admin'){
                    $roleData->permissions()->detach();
                    $isPermissionAttached = $roleData->givePermissionsTo( (array) $request->permission);
                    if($isPermissionAttached){
                        $users = $this->userService->findUserByRole([], $roleData?->slug);
                        if($roleData->slug != 'super-admin' && $users && $users->count()){
                            foreach ($users as $key => $user) {
                                $user->permissions()->detach();
                                $user->givePermissionsTo((array) $request->permission);
                            }
                        }
                        DB::commit();
                        return $this->responseRedirect('admin.settings.role.list','Permission attached successfully','success');
                    }
                // }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something Went Wrong','error',true);
            }
        }

        return view('admin.settings.role.attach-permission',compact('roleData','permissions'));
    }

    public function siteModules(Request $request){
        $this->setPageTitle('Site Modules');
        return view('admin.settings.module.index');
    }
    public function addModule(Request $request){
        $this->setPageTitle('Add Module');
        if($request->ajax()){
            $rules = [
                'title'=> 'required',
                'type'=> 'required',
                'activities'=> 'required'
            ];
            $messages = [
                'title' => 'Title field is required.',
                'type' => 'Type field is required.',
                'activities' => 'Activity field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try{
                $request->merge(['slug' => str()->slug($request->title)]);
                $isModuleCreated= $this->rolePermissionService->addOrUpdateModule(['uuid' => null], $request->except([
                    '_token',
                    'activities'
                ]));
                if($isModuleCreated){
                    if ($request->activities) {
                        $allPermissions = [];
                        foreach ($request->activities as $activity) {
                            $permissionData = [
                                'module_id' => $isModuleCreated->id,
                                'name' => ucwords(str_replace("_"," ",$activity)) . ' ' . $isModuleCreated->title,
                                'slug' => $activity . '-' . $isModuleCreated->slug,
                                'type' => $isModuleCreated->type,
                            ];
                            $this->rolePermissionService->addOrUpdatePermissions(['module_id' => null], $permissionData);
                            $allPermissions[] = $activity . '-' . $isModuleCreated->slug;
                        }
                        // dd($allPermissions);
                        $adminRoleData = $this->rolePermissionService->findRoleBySlug('super-admin');
                        if($adminRoleData){
                            $adminRoleData->givePermissionsTo($allPermissions);
                        }
                        // $superAdmins = $this->userService->findUserByRole([], 'super-admin');
                        // if($superAdmins){
                        //     foreach($superAdmins as $superAdmin){
                        //         $superAdmin->givePermissionsTo($allPermissions);
                        //     }
                        // }
                        $employees = $this->userService->getEmployees();
                        if($employees){
                            foreach($employees as $employee){
                                $employee->givePermissionsTo($allPermissions);
                            }
                        }
                    }
                    DB::commit();
                    return $this->responseJson(true, 200, 'Module Added Successfully', [
                        'redirect_url' => route('admin.settings.module.list')
                    ]);
                }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.settings.module.add');
    }
    public function editModule(Request $request, $uuid){
        $this->setPageTitle('Edit Module');
        $superAdmins = $this->userService->findUserByRole([], 'super-admin');
        $moduleData = $this->rolePermissionService->findModuleById(uuidtoid($uuid, 'modules'));
        $permissions = $moduleData->modulePermissions->pluck('slug')->toArray();
        if($request->ajax()){
            $rules = [
                'title'=> 'required',
                'type'=> 'required',
                'activities'=> 'required'
            ];
            $messages = [
                'title' => 'Title field is required.',
                'type' => 'Type field is required.',
                'activities' => 'Activity field is required.',

            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try{
                $moduleSlug = str()->slug($request->title);
                $request->merge(['slug' => $moduleSlug]);
                $isModuleUpdated= $this->rolePermissionService->addOrUpdateModule(['uuid' => $uuid], $request->except([
                    '_token',
                    'activities'
                ]));
                if($isModuleUpdated){
                    $allActivities = ['add', 'edit', 'view', 'status', 'delete', 'import', 'export', 'attach', 'detach', 'customize', 'advance_search'];
                    if ($request->activities) {
                        $allPermissions = [];
                        foreach ($allActivities as $activity) {
                            if(in_array($activity, $request->activities)){
                                $permissionData = [
                                    'name' => ucwords(str_replace("_"," ",$activity)) . ' ' . $request->title,
                                    'slug' => $activity . '-' . $moduleSlug,
                                    'type' => $request->type,
                                ];
                                $allPermissions[] = $activity . '-' . $moduleSlug;
                                $this->rolePermissionService->addOrUpdatePermissions(['module_id' => $moduleData->id, 'slug' => $activity.'-'], $permissionData);
                            }else{
                                $isPermissionDeleted = $this->rolePermissionService->listPermissions(['module_id' => $moduleData->id, 'slug' => $activity.'-'])->each->forceDelete();
                            }
                        }
                        $adminRoleData = $this->rolePermissionService->findRoleBySlug('super-admin');
                        if($adminRoleData){
                            $adminRoleData->deletePermissions(...$permissions);
                            $adminRoleData->givePermissionsTo($allPermissions);
                        }
                        $superAdmins = $this->userService->findUserByRole([], 'super-admin');
                        if($superAdmins){
                            foreach($superAdmins as $superAdmin){
                                $superAdmin->deletePermissions(...$permissions);
                                $superAdmin->givePermissionsTo($allPermissions);
                            }
                        }
                        // $employees = $this->userService->getEmployees();
                        // if($employees){
                        //     foreach($employees as $employee){
                        //         $employee->deletePermissions(...$permissions);
                        //         $employee->givePermissionsTo($allPermissions);
                        //     }
                        // }
                    }
                    DB::commit();
                    return $this->responseJson(true, 200, 'Module Updated Successfully', [
                        'redirect_url' => route('admin.settings.module.list')
                    ]);
                }
            }catch(\Exception $e){
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        return view('admin.settings.module.edit', compact('moduleData', 'permissions'));
    }
}
