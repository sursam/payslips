<?php

namespace App\Http\Controllers\Admin\User;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Exports\CustomExport;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Exports\CustomDeletedExport;
use App\Services\Asset\AssetService;
use App\Services\User\VendorService;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\User\AddVendorImport;
use App\Traits\PushNotificationTrait;
use App\Services\Location\CityService;
use App\Imports\User\AddEmployeeImport;
use App\Services\Location\StateService;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Services\Category\CategoryService;
use App\Notifications\SendPushNotification;
use App\Notifications\PoApproveNotification;
use App\Services\Role\RolePermissionService;
use App\Notifications\RfqApproveNotification;
use App\Notifications\BudgetApproveNotification;
use App\Notifications\PoInvoiceApproveNotification;
use App\Imports\User\AddEmployeeRepotingPersonImport;
use App\Notifications\RequisitionApproveNotification;

class UserController extends BaseController
{
    use PushNotificationTrait;
    public function __construct(
        protected UserService $userService,
        protected VendorService $vendorService,
        protected StateService $stateService,
        protected CityService $cityService,
        protected RolePermissionService $rolePermissionService,
        protected CategoryService $categoryService,
        protected AssetService $assetService
    ) {
        $this->userService = $userService;
        $this->vendorService = $vendorService;
        $this->rolePermissionService = $rolePermissionService;
        $this->categoryService = $categoryService;
        $this->stateService = $stateService;
        $this->cityService = $cityService;
    }

    public function index(Request $request, $userType = 'admin')
    {
        $pageTitle = 'Employee List';
        $this->setPageTitle($pageTitle);
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $designations = $this->categoryService->listCategories(['type' => 'designation', 'is_active' => 1], 'id', 'DESC');
        $sbus = $this->categoryService->listCategories(['type' => 'sbu', 'is_active' => 1], 'id', 'DESC');
        $divisions = $this->categoryService->listCategories(['type' => 'division', 'is_active' => 1], 'id', 'DESC');
        $officelocations = $this->assetService->listLocations();
        // $officelocations = $this->categoryService->listCategories(['type'=> 'officelocation', 'is_active'=> 1], 'id', 'DESC');
        $roles = $this->rolePermissionService->getList()->where('slug', '<>', 'super-admin');
        $departments = getDepartmentTree();
        $employees = $this->userService->getEmployees();
        return view('admin.users.index', compact('pageTitle', 'entities', 'designations', 'sbus', 'divisions', 'officelocations', 'roles', 'departments', 'employees'));
    }
    #suman#
    public function add(Request $request)
    {
        $this->setPageTitle('Add Employee');
        if ($request->post()) {

            $validator = Validator::make($request->all(), [
                'first_name' => 'required|string|min:1',
                'last_name' => 'required|string|min:1',
                'mobile_number' => 'required|integer|digits:10|unique:users,mobile_number,NULL,id,deleted_at,NULL',
                'email' => 'required|email|unique:users,email,NULL,id,deleted_at,NULL',
                'date_of_joining' => 'required|date_format:Y-m-d',
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'sbu_id' => 'required|exists:categories,id',
                'role' => 'required|exists:roles,slug',
                // 'division_id' => 'required|exists:categories,id',
                'designation_id' => 'required|exists:categories,id',
                'profile_image' => 'nullable|sometimes|image|mimes:jpg,jpeg,png,webp,gif,svg|max:5120',
                'max_amount' => 'required|numeric',
                'reporting_partner' => 'nullable|different:reporting_manager',

            ], [
                'entity_id.required' => 'The Entity field is required.',
                'entity_id.exists' => 'The selected entity is not found.',
                'department_id.required' => 'The department field is required.',
                'department_id.exists' => 'The selected department is not found.',
                'sbu_id.required' => 'The SBU field is required.',
                'sbu_id.exists' => 'The selected SBU is not found.',
                // 'division_id.required' => 'The Division field is required.',
                //'division_id.exists' => 'The selected division is not found.',
                'role.required' => 'The role field is required.',
                'role.exists' => 'The selected role is not found.',
                'designation_id.required' => 'The Designation field is required.',
                'designation_id.exists' => 'The selected Designation is not found.',
                'max_amount.required' => 'The Maximum budget amount is required.',
                'reporting_partner.different' => 'Reporting Partner cannot be the same as reporting manager.',

            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            $request->merge(['password' => bcrypt($request->mobile_number), 'is_registered' => 1]);
            DB::beginTransaction();
            try {
                //dd($request->all());
                $isUserCreated = $this->userService->createUser($request->except('_token'));
                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Employee Creation',
                    'task_description' => $request->first_name . ' ' . $request->last_name . '(' . $isUserCreated->unique_id . ')',
                    'task_url' => 'masters/employee/view/' . $isUserCreated->uuid,
                    'added_by' => auth()->user()->id,
                    'type' => 'add-employee',
                    'related_id' => $isUserCreated->id
                ]);
                if ($isUserCreated) {
                    $isUserCreated->markEmailAsVerified();
                    $widgets = $this->userService->getAllWidgets();
                    if($widgets){
                        foreach($widgets as $widget){
                            $isUserCreated->widgets()->updateOrCreate([
                                'widget_id' => $widget->id,
                                'position' => $widget->position,
                            ]);
                        }
                    }
                    DB::commit();
                    return $this->responseJson(true, 200, 'Employee created successfully', [
                        'redirect_url' => route('admin.employee.list')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $designations = $this->categoryService->listCategories(['type' => 'designation', 'is_active' => 1], 'id', 'DESC');
        $sbus = $this->categoryService->listCategories(['type' => 'sbu', 'is_active' => 1], 'id', 'DESC');
        $divisions = $this->categoryService->listCategories(['type' => 'division', 'is_active' => 1], 'id', 'DESC');
        $officelocations = $this->assetService->listLocations();
        // $officelocations = $this->categoryService->listCategories(['type'=> 'officelocation', 'is_active'=> 1], 'id', 'DESC');
        $reporting_employee = $this->userService->getEmployeesByLevel();
        $roles = $this->rolePermissionService->getList();
        $departments = getDepartmentTree();
        return view('admin.users.add', compact('entities', 'designations', 'sbus', 'divisions', 'officelocations', 'reporting_employee', 'roles', 'departments'));
    }
    public function edit(Request $request, $uuid)
    {
        $this->setPageTitle('Edit Employee');
        $id = uuidtoid($uuid, 'users');
        $userData = $this->userService->findUserById($id);
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'first_name' => 'required|string|min:1',
                'last_name' => 'required|string|min:1',
                'mobile_number' => 'required|numeric|integer|digits:10|unique:users,mobile_number,' . $uuid . ',uuid',
                'email' => 'required|email|unique:users,email,' . $uuid . ',uuid',
                'date_of_joining' => 'required|date_format:Y-m-d',
                'entity_id' => 'required|exists:categories,id',
                'department_id' => 'required|exists:departments,id',
                'sbu_id' => 'required|exists:categories,id',
               // 'division_id' => 'required|exists:categories,id',
                'role' => 'required|exists:roles,slug',
                'designation_id' => 'required|exists:categories,id',
                'profile_image' => 'nullable|sometimes|image|mimes:jpg,jpeg,png,webp,gif,svg|max:5120',
                'max_amount' => 'required|numeric',
                'reporting_partner' => 'nullable|different:reporting_manager',
            ], [
                'entity_id.required' => 'The Entity field is required.',
                'entity_id.exists' => 'The selected entity is not found.',
                'department_id.required' => 'The department field is required.',
                'department_id.exists' => 'The selected department is not found.',
                'sbu_id.required' => 'The SBU field is required.',
                'sbu_id.exists' => 'The selected SBU is not found.',
                // 'division_id.required' => 'The Division field is required.',
                //'division_id.exists' => 'The selected division is not found.',
                'role.required' => 'The role field is required.',
                'role.exists' => 'The selected role is not found.',
                'designation_id.required' => 'The Designation field is required.',
                'designation_id.exists' => 'The selected Designation is not found.',
                'max_amount.required' => 'The Maximum budget amount is required.',
                'reporting_partner.different' => 'Reporting Partner cannot be the same as reporting manager.',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $isUserCreated = $this->userService->updateUser($request->except('_token'), $id);
                if ($isUserCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Employee Information Updated', [
                        'redirect_url' => route('admin.employee.list')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $designations = $this->categoryService->listCategories(['type' => 'designation', 'is_active' => 1], 'id', 'DESC');
        $sbus = $this->categoryService->listCategories(['type' => 'sbu', 'is_active' => 1], 'id', 'DESC');
        $divisions = $this->categoryService->listCategories(['type' => 'division', 'is_active' => 1], 'id', 'DESC');
        $officelocations = $this->assetService->listLocations();
        // $officelocations = $this->categoryService->listCategories(['type'=> 'officelocation', 'is_active'=> 1], 'id', 'DESC');
        $reporting_managers = $this->userService->getEmployeesByLevel($userData->roles->first()->level, [['uuid', '<>', $uuid]]);
        // dd($reporting_managers);
        $reporting_employee = $this->userService->getEmployeesByLevel(null, [['uuid', '<>', $uuid]]);
        $selected_manager = $userData->reportingPersons()->where('role_type', 'manager')->first()?->pivot;
        $selected_partner = $userData->reportingPersons()->where('role_type', 'partner')->first()?->pivot;
        $roles = $this->rolePermissionService->getList();
        $departments = getDepartmentTree();
        return view('admin.users.edit', compact('userData', 'entities', 'designations', 'sbus', 'divisions', 'officelocations', 'reporting_employee', 'selected_manager', 'selected_partner', 'roles', 'reporting_managers', 'departments'));
    }
    public function updatePassword(Request $request, $uuid)
    {
        $this->setPageTitle('Update Password');
        $id = uuidtoid($uuid, 'users');
        $userData = $this->userService->findUserById($id);
        if ($request->ajax()) {
            $rules = [
                'password' => 'required|string|min:6',
                'password_confirmation' => 'required|same:password'
            ];
            $messages = [
                'password.required'=>'Password is required',
                'password_confirmation.required'=>'Confirmation password is required',
                'password_confirmation.same'=>'Password and confirmation password does not match',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $password = bcrypt($request->password);
                $isUserPasswordUpdated = $userData->update([
                    'password' => $password
                ]);
                if ($isUserPasswordUpdated) {
                    DB::commit();
                    return $this->responseJson(true, 200, "Password successfully updated", [
                        'redirect_url' => route('admin.employee.list')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error');
            }
        }
        return view('admin.users.update-password', compact('userData'));
    }
    // public function attachPermissions(Request $request, $role = 'admin', $uuid)
    // {
    //     ///dd("sss");
    //     $this->setPageTitle('Admin Users');

    //     $id = uuidtoid($uuid, 'users');

    //     $user = $this->userService->findUser($id);

    //     $permissions = $this->rolePermissionService->getAllPermissions();

    //     $count= count($permissions);
    //     $chunk= $count/4;
    //     $permissions= $permissions->chunk(ceil($permissions->count()/$chunk));

    //     //dd($permissions);

    //     if ($request->post()) {

    //         DB::begintransaction();

    //         try {

    //             $user->permissions()->detach();

    //             $isPermissionAttached = $user->givePermissionsTo($request->permission);

    //             if ($isPermissionAttached) {

    //                 DB::commit();

    //                 return $this->responseRedirect('admin.user.list', 'Permission attached to user successfully', 'success');

    //             }

    //         } catch (\Exception$e) {

    //             DB::rollBack();

    //             logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());

    //             return $this->responseRedirectBack('Something Went Wrong', 'error', true);

    //         }

    //     }

    //     return view('admin.users.attach-permission', compact('user', 'permissions'));

    // }
    public function export($role, $vehicleType, $isRegistered = 1, $orderBy = 'id', $sortBy = 'DESC')
    {
        return Excel::download(new CustomExport($role, $vehicleType, $isRegistered, $orderBy, $sortBy), $role . ',list-export-' . time() . '.xlsx');
    }
    public function exportDeleted($role, $orderBy = 'id', $sortBy = 'DESC')
    {
        return Excel::download(new CustomDeletedExport($role, $orderBy, $sortBy), $role . '-deleted-list-export-' . time() . '.xlsx');
    }


    #vendor#
    public function vendor(Request $request, $userType = 'vendor')
    {
        $pageTitle = 'Vendor List';
        $this->setPageTitle($pageTitle);
        $entities = $this->categoryService->listCategories(['type' => 'entity', 'is_active' => 1], 'id', 'DESC');
        $designations = $this->categoryService->listCategories(['type' => 'designation', 'is_active' => 1], 'id', 'DESC');
        $sbus = $this->categoryService->listCategories(['type' => 'sbu', 'is_active' => 1], 'id', 'DESC');
        $divisions = $this->categoryService->listCategories(['type' => 'division', 'is_active' => 1], 'id', 'DESC');
        $officelocations = $this->assetService->listLocations();
        // $officelocations = $this->categoryService->listCategories(['type'=> 'officelocation', 'is_active'=> 1], 'id', 'DESC');
        return view('admin.users.vendor.index', compact('pageTitle', 'entities', 'designations', 'sbus', 'divisions', 'officelocations'));
    }
    public function vendorAdd(Request $request, $userType = 'vendor')
    {
        $this->setPageTitle('Add ' . ucwords($userType));
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'first_name' => 'required|string|min:1',
                'last_name' => 'required|string|min:1',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number,NULL,id,deleted_at,NULL',
                'email' => 'required|email|unique:users,email,NULL,id,deleted_at,NULL',
                'type' => 'required',
                'company_name' => 'nullable',
                'state' => 'required|exists:states,id',
                'city' => 'required|exists:cities,id',
                'address' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['state_id' => $request->state, 'city_id' => $request->city, 'created_by' => auth()->id()]);
                $isUserCreated = $this->vendorService->createVendor($request->except(['state', 'city']));
                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'New Vendor Creation',
                    'task_description' => $request->first_name . ' ' . $request->last_name,
                    'task_url' => 'masters/vendor/list',
                    'added_by' => auth()->user()->id,
                    'type' => 'add-vendor',
                    'related_id' => $isUserCreated->id
                ]);
                if ($isUserCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, ucwords($userType) . ' created successfully', [
                        'redirect_url' => route('admin.vendor.list')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $states = $this->stateService->findStates(['country_id' => 101]);
        return view('admin.users.vendor.add', compact('userType', 'states'));
    }
    public function vendorEdit(Request $request, $uuid, $userType = 'vendor')
    {
        $this->setPageTitle('Edit ' . ucwords($userType));
        $id = uuidtoid($uuid, 'vendors');
        if ($request->post()) {
            $validator = Validator::make($request->all(), [
                'first_name' => 'required|string|min:1',
                'last_name' => 'required|string|min:1',
                'mobile_number' => 'required|numeric|min:1000000000|unique:users,mobile_number,' . $uuid . ',uuid',
                'email' => 'required|email|unique:users,email,' . $uuid . ',uuid',
                'company_name' => 'nullable',
                'type' => 'required',
                'state' => 'required|exists:states,id',
                'city' => 'required|exists:cities,id',
                'address' => 'nullable',
            ]);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $request->merge(['state_id' => $request->state, 'city_id' => $request->city]);
                $isUserCreated = $this->vendorService->updateVendor($request->except(['state', 'city','_token']), $id);
                if ($isUserCreated) {
                    DB::commit();
                    return $this->responseJson(true, 200, ucwords($userType) . ' Information Updated', [
                        'redirect_url' => route('admin.vendor.list')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        $userData = $this->vendorService->findUserById($id);
        $states = $this->stateService->findStates(['country_id' => 101]);
        $cities = $this->cityService->getCityByState($userData->state_id);
        return view('admin.users.vendor.edit', compact('userType', 'userData', 'states','cities'));
    }

    public function attachPermissions(Request $request, $uuid)
    {
        $this->setPageTitle('Attach User Permissions');
        $id = uuidtoid($uuid, 'users');
        $user = $this->userService->findUser($id);
        $permissions = $this->rolePermissionService->getAllPermissions();
        // dd($user);
        //$permissions = $this->rolePermissionService->getAllPermissions();
        // $count= count($permissions);
        // $chunk= $count/5;
        // $permissions= $permissions->chunk(ceil($permissions->count()/$chunk));


        //    $mastersPermissions= $this->rolePermissionService->getAllPermissions("masters");
        //    $count= count($mastersPermissions);
        //    $chunk= $count/5;
        //    $mastersPermissions= $mastersPermissions->chunk(ceil($mastersPermissions->count()/$chunk));


        //    $modulesPermissions= $this->rolePermissionService->getAllPermissions("modules");
        //    $count= count($modulesPermissions);
        //    $chunk= $count/5;
        //    $modulesPermissions= $modulesPermissions->chunk(ceil($modulesPermissions->count()/$chunk));

        //    $settingsPermissions= $this->rolePermissionService->getAllPermissions("settings");
        //    $count= count($settingsPermissions);
        //    $chunk= $count/3;
        //    $settingsPermissions= $settingsPermissions->chunk(ceil($settingsPermissions->count()/$chunk));



        //dd($mastersPermissions);
        if ($request->post()) {
            DB::begintransaction();
            try {
                $user->permissions()->detach();
                $isPermissionAttached = $user->givePermissionsTo((array) $request->permission);
                if ($isPermissionAttached) {
                    DB::commit();
                    return $this->responseRedirect('admin.employee.list', 'Permission attached to user successfully', 'success');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());

                return $this->responseRedirectBack('Something Went Wrong', 'error', true);
            }
        }
        return view('admin.users.attach-permission', compact('user', 'permissions'));
    }

    public function notifications(Request $request)
    {
        $this->setPageTitle('Notifications');
        //return view('customer.dashboard.notifications');
        $notifications = auth()->user()->notifications()->where('deleted_at',null)->paginate();
        return view('admin.dashboard.notifications', compact('notifications'));
    }


    public function viewEmployee(Request $request, $uuid)
    {
        $this->setPageTitle('Employee Details');
        $employee = $this->userService->findUser(uuidtoid($uuid, 'users'));
        $roles = $this->rolePermissionService->getList();
        $selected_manager = $employee->reportingPersons()->where('role_type', 'manager')->first()?->pivot;
        $selected_partner = $employee->reportingPersons()->where('role_type', 'partner')->first()?->pivot;
        $manager = $selected_manager ? $this->userService->findUser($selected_manager->person_id) : '';
        $partner = $selected_partner ? $this->userService->findUser($selected_partner->person_id) : '';

        return view('admin.users.employee-detail', compact('employee', 'roles', 'manager', 'partner'));
    }
    public function setApprover(Request $request)
    {
        if ($request->ajax()) {
            if($request->set_approver == '1'){
                $rules = [
                    'module_type' => 'required',
                    // 'module_type[budget]' => 'required',
                    // 'module_type[requisition]' => 'required',
                    // 'module_type[rfq]' => 'required',
                    // 'module_type[po]' => 'required',
                    // 'module_type[invoice]' => 'required',
                ];
                $messages = [
                    'module_type' => "Please select all approver.",
                    // 'module_type[budget]' => "Budget approver is required.",
                    // 'module_type[requisition]' => "Requisition approver is required.",
                    // 'module_type[rfq]' => "Rfq approver is required.",
                    // 'module_type[po]' => "Po approver is required.",
                    // 'module_type[invoice]' => "Invoice approver is required.",
                ];

                $validator = Validator::make($request->all(), $rules, $messages);
                if ($validator->fails()) {
                    return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
                }
            }
            DB::beginTransaction();
            try {
                $user_id = uuidtoid($request->user_uuid, 'users');
                $update_count = 0;
                if($request->set_approver == '1'){
                    foreach($request->module_type as $type => $approver_uuid){
                        $approver_id = uuidtoid($approver_uuid, 'users');
                        $approver = $this->userService->findUserById($approver_id);
                        $isAdded = $this->userService->addOrUpdateAlternateApprover([
                            'user_id' => $user_id,
                            'module_type' => $type
                        ], [
                            'user_id' => $user_id,
                            'approver_id' => $approver_id,
                            'module_type' => $type
                        ]);
                        if ($isAdded) {
                            switch($type){
                                case 'budget':
                                        $pendingBudgetApprovals = $this->assetService->getPendingBudgetApprovalsByUser($user_id);
                                        if($pendingBudgetApprovals){
                                            foreach($pendingBudgetApprovals as $pendingBudgetApproval){
                                                $isApprovalUpdated = $pendingBudgetApproval->update(['user_id' => $approver_id]);
                                                if($isApprovalUpdated && $pendingBudgetApproval->status == '0'){
                                                    $budget = $this->assetService->findBudgetById($pendingBudgetApproval->budget_id);
                                                    $notiData = [
                                                        'form_name' => "You got a budget approval request for the ID #" . $budget->unique_id,
                                                        'budget_uuid' => $budget->uuid,
                                                    ];
                                                    $approver->notify(new BudgetApproveNotification($notiData));

                                                    $requestparam = (object) [
                                                        'title' => "Budget approval request",
                                                        'body' => "You got a budget approval request for the ID #" . $budget->unique_id,
                                                    ];
                                                    $this->sendPushNotification($approver->id, $requestparam);
                                                }
                                            }
                                        }
                                    break;
                                case 'requisition':
                                    $pendingRequisitionApprovals = $this->assetService->getPendingRequisitionApprovalsByUser($user_id);
                                    if($pendingRequisitionApprovals){
                                        foreach($pendingRequisitionApprovals as $pendingRequisitionApproval){
                                            $isApprovalUpdated = $pendingRequisitionApproval->update(['user_id' => $approver_id]);
                                            if($isApprovalUpdated && $pendingRequisitionApproval->status == '0'){
                                                $requisition = $this->assetService->findRequisitionById($pendingRequisitionApproval->requisition_id);
                                                $notiData = [
                                                    'form_name' => "You got a requisition approval request for the ID #" . $requisition->unique_id,
                                                    'requisition_uuid' => $requisition->uuid,
                                                ];
                                                $approver->notify(new RequisitionApproveNotification($notiData));

                                                $requestparam = (object) [
                                                    'title' => "Requisition approval request",
                                                    'body' => "You got a requisition approval request for the ID #" . $requisition->unique_id,
                                                ];
                                                $this->sendPushNotification($approver->id, $requestparam);
                                            }
                                        }
                                    }
                                    break;
                                case 'rfq':
                                    $pendingRfqApprovals = $this->assetService->getPendingRequisitionApprovalsByUser($user_id);
                                    if($pendingRfqApprovals){
                                        foreach($pendingRfqApprovals as $pendingRfqApproval){
                                            $isApprovalUpdated = $pendingRfqApproval->update(['user_id' => $approver_id]);
                                            if($isApprovalUpdated && $pendingRfqApproval->status == '0'){
                                                $rfqData = $this->assetService->findRfqById($pendingRfqApproval->request_id);
                                                $notiData = [
                                                    'form_name' => "You got a RFQ approval request for the ID #" . $rfqData->unique_id,
                                                    'rfq_uuid' => $rfqData->uuid,
                                                ];
                                                $approver->notify(new RfqApproveNotification($notiData));

                                                $requestparam = (object) [
                                                    'title' => "RFQ approval request",
                                                    'body' => "You got a RFQ approval request for the ID #" . $rfqData->unique_id,
                                                ];
                                                $this->sendPushNotification($approver->id, $requestparam);
                                            }
                                        }
                                    }
                                    break;
                                case 'po':
                                    $pendingPoApprovals = $this->assetService->getPendingPoApprovalsByUser($user_id);
                                    if($pendingPoApprovals){
                                        foreach($pendingPoApprovals as $pendingPoApproval){
                                            $isApprovalUpdated = $pendingPoApproval->update(['user_id' => $approver_id]);
                                            if($isApprovalUpdated && $pendingPoApproval->status == '0'){
                                                $purchaseOrder = $this->assetService->findPurchaseOrderById($pendingPoApproval->purchase_order_id);
                                                $notiData = [
                                                    'form_name' => "You got a Purchase Order approval request for the ID #" . $purchaseOrder->unique_id,
                                                    'po_uuid' => $purchaseOrder->uuid,
                                                ];
                                                $approver->notify(new PoApproveNotification($notiData));

                                                $requestparam = (object) [
                                                    'title' => "Purchase Order approval request",
                                                    'body' => "You got a Purchase Order approval request for the ID #" . $purchaseOrder->unique_id,
                                                ];
                                                $this->sendPushNotification($approver->id, $requestparam);
                                            }
                                        }
                                    }
                                    break;
                                case 'invoice':
                                    $pendingPoInvoiceApprovals = $this->assetService->getPendingPoInvoiceApprovalsByUser($user_id);
                                    if($pendingPoInvoiceApprovals){
                                        foreach($pendingPoInvoiceApprovals as $pendingPoInvoiceApproval){
                                            $isApprovalUpdated = $pendingPoInvoiceApproval->update(['user_id' => $approver_id]);
                                            if($isApprovalUpdated && $pendingPoInvoiceApproval->status == '0'){
                                                $invoiceData = $this->assetService->findInvoiceById($pendingPoInvoiceApproval->po_invoice_id);
                                                $notiData = [
                                                    'form_name' => "You got a PO Invoice approval request for the ID #" . $invoiceData->unique_id,
                                                    'po_invoice_uuid' => $invoiceData->uuid,
                                                    'po_uuid' => $invoiceData->purchaseOrder->uuid,
                                                ];
                                                $approver->notify(new PoInvoiceApproveNotification($notiData));

                                                $requestparam = (object) [
                                                    'title' => "PO Invoice approval request",
                                                    'body' => "You got a PO Invoice approval request for the ID #" . $invoiceData->unique_id,
                                                ];
                                                $this->sendPushNotification($approver->id, $requestparam);
                                            }
                                        }
                                    }
                                    break;
                            }
                            $update_count++;
                        }
                    }
                }
                if (!$request->module_type || ($request->module_type && count($request->module_type) == $update_count)) {
                    $data = $this->userService->updateUser(['is_available' => 0], $user_id);
                    if($data){
                        DB::commit();
                        return $this->responseJson(true, 200, 'User availability updated successfully', [
                            'redirect_url' => route('admin.employee.list')
                        ]);
                    } else {
                        return $this->responseJson(false, 500, 'Something went wrong', '');
                    }
                } else {
                    return $this->responseJson(false, 500, 'Something went wrong', '');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function downloadSampleExcelFormat(Request $request)
    {
        $file = public_path() . "/assets/documents/sample-format-of-employees.xlsx";
        return response()->download($file, 'employee-sample-data.xlsx');
    }
    public function downloadSampleExcel(Request $request)
    {
        //dd("asdfg");
        $fileName = public_path() . "/assets/documents/sample-format-of-vendors.xlsx";
        return response()->download($fileName, 'vendor-import-sample-data.xlsx');
    }
    public function addEmployeesByExcel(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|file'
        ]);
        try {
            $isExcelImported = Excel::import(new AddEmployeeImport, $request->file('excel_file'));
            if ($isExcelImported){
                $isReportingPersonAttached = Excel::import(new AddEmployeeRepotingPersonImport, $request->file('excel_file'));
                if($isReportingPersonAttached){
                    return $this->responseJson(true, 200, 'Employee Data Imported Successfully', [
                        'redirect_url' => route('admin.employee.list')
                    ]);
                }
            }else{
                return $this->responseJson(false, 200, 'Something went Wrong', '');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }



    public function addVendorsByExcel(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|file'
        ]);
        try {
            $isExcelImported = Excel::import(new AddVendorImport, $request->file('excel_file'));
            if ($isExcelImported){
                return $this->responseJson(true, 200, 'Vendor Data Imported Successfully', [
                    'redirect_url' => route('admin.vendor.list')
                ]);
            }else{
                return $this->responseJson(false, 200, 'Something went Wrong', '');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
            return $this->responseJson(false, 200, $e->getMessage(), '');
        }
    }
}
