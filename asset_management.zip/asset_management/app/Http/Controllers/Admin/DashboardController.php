<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\BaseController;
use App\Models\Inventory\AssetIssue;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Site\RecentActivity;
use App\Models\User\User;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Services\Category\CategoryService;
use App\Services\Inventory\AssetStockService;
use App\Services\Ticket\TicketService;
use App\Services\User\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class DashboardController extends BaseController
{
    public function __construct(
        protected UserService $userService,
        protected CategoryService $categoryService,
        protected AssetService $assetService,
        protected AssetStockService $assetStockService,
        protected TicketService $ticketService,
        protected AssetTypeService $assetTypeService,
    ) {
        $this->userService = $userService;
    }
    public function index_bk()
    {
        $this->setPageTitle('Admin Dashboard');

        // $toatalAssets = $this->assetService->getAssetsByCatyegoryId(null, ['is_active' => 1])->count();
        $intangiableCategoryData = $this->categoryService->findCategoryBySlug('intangible');
        $intangibleAssetsCount = 0;
        $unUsedIntangibleAssetsCount = 0;
        if ($intangiableCategoryData) {
            $intangibleAssets = $this->assetService->getAssetsByCatyegoryId($intangiableCategoryData->id, ['is_active' => 1]);
            // $intangibleAssetsCount = $intangibleAssets->count();

            if ($intangibleAssets) {
                foreach ($intangibleAssets as $intangibleAsset) {
                    if ($intangibleAsset->assetStock) {
                        foreach ($intangibleAsset->assetStock as $intangibleAssetStock) {
                            $intangibleAssetsCount += $intangibleAssetStock->inventories->count();
                            $unUsedIntangibleAssetsCount += $intangibleAssetStock->current_stock;
                        }
                    }
                }
            }
            // dd($unUsedIntangibleAssetsCount);

            // dd($intangibleAssets->each->assetStock?->sum('current_stock'));
        }
        $tangiableCategoryData = $this->categoryService->findCategoryBySlug('tangible');
        $tangibleAssetsCount = 0;
        $unUsedTangibleAssetsCount = 0;
        $tangibleAssets = null;
        if ($tangiableCategoryData) {
            // $tangibleAssetsCount = $this->assetService->getAssetsByCatyegoryId($tangiableCategoryData->id, ['is_active' => 1])->count();
            $tangibleAssets = $this->assetService->getAssetsByCatyegoryId($tangiableCategoryData->id, ['is_active' => 1], 4, null, 'id', 'desc', false);

            if ($tangibleAssets) {
                foreach ($tangibleAssets as $tangibleAsset) {
                    if ($tangibleAsset->assetStock) {
                        foreach ($tangibleAsset->assetStock as $tangibleAssetStock) {
                            $tangibleAssetsCount += $tangibleAssetStock->inventories->count();
                            $unUsedTangibleAssetsCount += $tangibleAssetStock->current_stock;
                        }
                    }
                }
            }

            // dd($tangibleAssets->each->assetStock?->sum('inventories'));
            // dd($tangibleAssets->each->assetStock?->sum('current_stock'));
        }

        $newAssetRequisitionCount = $this->assetService->findRequisitions([], 'id', 'desc')->where('created_at', '>', Carbon::now()->subDays(30))->count();
        $softwareLicenseRenewalCount = $this->assetStockService->getRenewalListByDays(30)->count();
        $softwareLicenseRenewalList = $this->assetStockService->getRenewalListByDays(30, [], 'id', 'desc', 7);
        $unassignedTickets =  $this->ticketService->listTicketsForDashboard([], '', 'id', 'desc', null, null, false, 'filterBy=unassigned');

        // dd($unassignedTickets);
        //$unassignedTickets =  $unassignedTickets[0]->;
        // dd($unassignedTickets);
        $args = [];
        if (!auth()->user()->hasRole('super-admin')) {
            $args['added_by'] = auth()->user()->id;
        }
        $recentActivities = $this->assetService->findRecentActivities($args, [], 'id', 'desc', 7);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);

        $widget1 = '<div class="single_statbox orange_box widget_box" id="widget1" data-id="1">
            <h6>Total Assets</h6>
            <h3><a href="'.route('admin.asset.list').'" title="Total Assets">' . ($intangibleAssetsCount + $tangibleAssetsCount) . '</a></h3>
            <div class="tangible_box">
                <div class="single_tangible">
                    <h6>Tangible (' . $tangibleAssetsCount . ')</h6>
                    <ul class="used_list">
                        <li>Used: ' . ($tangibleAssetsCount - $unUsedTangibleAssetsCount) . '</li>
                        <li>Unused: ' . $unUsedTangibleAssetsCount . '</li>
                    </ul>
                </div>
                <div class="single_tangible">
                    <h6>Intangible (' . $intangibleAssetsCount . ')</h6>
                    <ul class="used_list">
                        <li>Used: ' . ($intangibleAssetsCount - $unUsedIntangibleAssetsCount) . '</li>
                        <li>Unused: ' . $unUsedIntangibleAssetsCount . '</li>
                    </ul>
                </div>
            </div>
        </div>';
        $widget2 = '<div class="single_statbox singstat_img pink_box widget_box" id="widget2" data-id="2">
            <h6>New Assets Requisitions</h6>
            <h3>' . $newAssetRequisitionCount . '</h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';
        $widget3 = '<div class="single_statbox singstat_img green_box widget_box" id="widget3" data-id="3">
            <h6>New Tickets Assigned</h6>
            <h3>' . $unassignedTickets->count() . '</h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';
        $widget4 = '<div class="single_statbox singstat_img violet_box widget_box" id="widget4" data-id="4">
            <h6>Upcoming Renewals</h6>
            <h3>' . $softwareLicenseRenewalCount . '</h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';

        $widget5 = '<div class="card card-body unassign_box widget_box" id="widget5" data-id="5">
            <div class="card_topbar">
                <h6>Todays Tickets</h6>';
        if ($unassignedTickets->count()) {
            $widget5 .= '<a href="' . route('admin.ticket.list', ['type' => 'raised-by-me']) . '" target="_blank">View All</a>';
        }
        $widget5 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Ticket Id#</th>
                                <th scope="col">Subject</th>
                                <th scope="col">Department</th>
                                <th scope="col">Mobile No</th>
                                <th scope="col">Date</th>
                                <th scope="col">Priority</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($unassignedTickets->count()) {
            foreach ($unassignedTickets->take(4) as $key => $ticket) {
                $widget5 .= '<tr>
                                        <th scope="row">' . $ticket->unique_id . '</th>
                                        <td>' . ucfirst($ticket->subject) . '</td>
                                        <td>' . $ticket->department?->name . '</td>
                                        <td>+91 ' . $ticket->mobile_number . '</td>
                                        <td>' . (Carbon::parse($ticket->created_at)->format('d-m-Y')) . '</td>
                                        <td>
                                            <p class="text-secondary">' . ucfirst($ticket->priority) . '</p>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary" href="' . route('admin.ticket.view', $ticket->uuid) . '"><i class="fa fa-eye" aria-hidden="true"></i> View</a>
                                        </td>
                                    </tr>';
            }
        } else {
            $widget5 .= '<tr><td colspan="7" class="text-center">No data found.</td></tr>';
        }
        $widget5 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget6 = '<div class="card card-body stock_box widget_box" id="widget6" data-id="6">
            <div class="card_topbar">
                <h6>Tangible Assets Stock</h6>';
        if ($tangibleAssetsCount) {
            $widget6 .= '<a href="' . route('admin.asset.list') . '" target="_blank">View All</a>';
        }
        $widget6 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">SL</th>
                                <th scope="col">Name.</th>
                                <th scope="col">Entity</th>
                                <th scope="col">Total Stock</th>
                                <th scope="col">Current Stock</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($tangibleAssetsCount) {
            foreach ($tangibleAssets as $key => $asset) {
                $widget6 .= '<tr>
                                        <td scope="row">' . ($key + 1) . '</td>
                                        <td>' . ucwords($asset->asset_name) . '</td>
                                        <td>' . ucwords($asset->assettype?->entity) . '</td>
                                        <td></td>
                                        <td>' . $asset->assetStock?->sum('current_stock') . '</td>
                                        <td><a class="btn btn-primary" href="' . route('admin.assetstock.list', $asset->uuid) . '"><i class="fa fa-eye" aria-hidden="true"></i> View</a></td>
                                    </tr>';
            }
        } else {
            $widget6 .= '<tr><td colspan="6" class="text-center">No data found.</td></tr>';
        }
        $widget6 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget7 = '<div class="card card-body stat_box widget_box" id="widget7" data-id="7">
            <div class="stats_top">
                <p>Entity</p>
                <select name="" class="form-control" id="">';
        foreach ($entities as $entity) {
            $widget7 .= '<option value="' . $entity->id . '">' . $entity->name . '</option>';
        }
        $widget7 .= '</select>
            </div>
            <div class="dash_chartbox">
                <canvas id="courseChart" width="600" height="400"></canvas>
            </div>
        </div>';
        $widget8 = '<div class="card card-body unassign_box widget_box" id="widget8" data-id="8">
            <div class="card_topbar">
                <h6>Software License Renewal</h6>';
        if ($softwareLicenseRenewalCount) {
            $widget8 .= '<a href="' . route('admin.software.license.list') . '" target="_blank">View All</a>';
        }
        $widget8 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Licence Key</th>
                                <th scope="col">Capacity/Specification</th>
                                <th scope="col">Asset Condition</th>
                                <th scope="col">Purchase Date</th>
                                <th scope="col">Warranty/License Date</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($softwareLicenseRenewalCount) {
            foreach ($softwareLicenseRenewalList as $list) {
                $widget8 .= '<tr>
                                        <td>' . $list->identification_no . '</td>
                                        <td>' . $list->capacity_specs . '</td>
                                        <td>' . $list->asset_condition . '</td>
                                        <td>' . (Carbon::parse($list->purchase_date)->format('Y-m-d')) . '</td>
                                        <td>' . (Carbon::parse($list->warranty_licence_date)->format('Y-m-d')) . '</td>
                                    </tr>';
            }
        } else {
            $widget8 .= '<tr><td colspan="5" class="text-center">No data found.</td></tr>';
        }
        $widget8 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget9 = '<div class="card card-body recentactivity_box" id="widget9" data-id="9">
            <div class="card_topbar">
                <h6>Recent Activity</h6>';
        if ($recentActivities->count()) {
            $widget9 .= '<a href="' . route('admin.recent.activity') . '" target="_blank">View All</a>';
        }
        $widget9 .= '</div>';

        if ($recentActivities->count()) {
            foreach ($recentActivities as $recentActivity) {
                $widget9 .= '<div class="single_activitybox">
                    <h6 class="txt_bold">' . $recentActivity->task_name . '</h6>
                    <a href="' . url($recentActivity->task_url) . '"><h6>' . $recentActivity->task_description . '</h6>
                    <p class="text_blue">' . $this->formatTimeDifference($recentActivity->created_at) . '</p></a>
                    </div>';
            }
        } else {
            $widget9 .= '<div class="single_activitybox">
                No Data Found
                </div>';
        }
        $widget9 .= '</div>';
        $widgets = $this->userService->getAllWidgets();
        $userWidgets = auth()->user()->widgets->toArray();
        $allWidgets = [$widget1, $widget2, $widget3, $widget4, $widget5, $widget6, $widget7, $widget8, $widget9];
        $dashboardWidgets = [];
        foreach ($widgets as $k => $widget) {
            if ($userWidgets) {
                $dashboardWidgets[] = $allWidgets[$userWidgets[$k]['widget_id'] - 1];
            } else {
                $dashboardWidgets[] = $allWidgets[$widget['position'] - 1];
            }
        }

        return view('admin.dashboard.index', compact('widgets', 'userWidgets', 'dashboardWidgets'));
    }




    public function index(Request $request )
    {
        $this->setPageTitle('Admin Dashboard');
        $intangiableCategoryData = $this->categoryService->findCategoryBySlug('intangible');
        $intangibleAssetsCount = 0;
        $unUsedIntangibleAssetsCount = 0;
        if ($intangiableCategoryData) {
            $intangibleAssets = $this->assetService->getAssetsByCatyegoryId($intangiableCategoryData->id, ['is_active' => 1]);
            if ($intangibleAssets) {
                foreach ($intangibleAssets as $intangibleAsset) {
                    if ($intangibleAsset->assetStock) {
                        foreach ($intangibleAsset->assetStock as $intangibleAssetStock) {
                            $intangibleAssetsCount += $intangibleAssetStock->inventories->count();
                            $unUsedIntangibleAssetsCount += $intangibleAssetStock->current_stock;
                        }
                    }
                }
            }
        }
        $tangiableCategoryData = $this->categoryService->findCategoryBySlug('tangible');
        $tangibleAssetsCount = 0;
        $unUsedTangibleAssetsCount = 0;
        $tangibleAssets = null;
        if ($tangiableCategoryData) {
            $tangibleAssets = $this->assetService->getAssetsByCatyegoryId($tangiableCategoryData->id, ['is_active' => 1], 4, null, 'id', 'desc', false);

            if ($tangibleAssets) {
                foreach ($tangibleAssets as $tangibleAsset) {
                    if ($tangibleAsset->assetStock) {
                        foreach ($tangibleAsset->assetStock as $tangibleAssetStock) {
                            $tangibleAssetsCount += $tangibleAssetStock->inventories->count();
                            $unUsedTangibleAssetsCount += $tangibleAssetStock->current_stock;
                        }
                    }
                }
            }
        }

        $newAssetRequisitionCount = $this->assetService->findRequisitions([], 'id', 'desc')->where('created_at', '>', Carbon::now()->subDays(30))->count();
        $softwareLicenseRenewalCount = $this->assetStockService->getRenewalListByDays(30)->count();
        $softwareLicenseRenewalList = $this->assetStockService->getRenewalListByDays(30, [], 'id', 'desc', 7);
        $unassignedTickets =  $this->ticketService->listTicketsForDashboard([], '', 'id', 'desc', null, null, false, 'filterBy=unassigned');

        $args = [];
        if (!auth()->user()->hasRole('super-admin')) {
            $args['added_by'] = auth()->user()->id;
        }
        $recentActivities = $this->assetService->findRecentActivities($args, [], 'id', 'desc', 7);
        $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);

        $widget1 = '<div class="single_statbox orange_box widget_box" id="widget1" data-id="1">
            <h6>Total Assets</h6>
            <h3><a href="'.route('admin.asset.list').'" title="Total Assets" class="text-white">' . ($intangibleAssetsCount + $tangibleAssetsCount) . '</a></h3>
            <div class="tangible_box">
                <div class="single_tangible">
                    <h6>Tangible (' . $tangibleAssetsCount . ')</h6>
                    <ul class="used_list">
                        <li>Used: ' . ($tangibleAssetsCount - $unUsedTangibleAssetsCount) . '</li>
                        <li>Unused: ' . $unUsedTangibleAssetsCount . '</li>
                    </ul>
                </div>
                <div class="single_tangible">
                    <h6>Intangible (' . $intangibleAssetsCount . ')</h6>
                    <ul class="used_list">
                        <li>Used: ' . ($intangibleAssetsCount - $unUsedIntangibleAssetsCount) . '</li>
                        <li>Unused: ' . $unUsedIntangibleAssetsCount . '</li>
                    </ul>
                </div>
            </div>
        </div>';
        $widget2 = '<div class="single_statbox singstat_img pink_box widget_box" id="widget2" data-id="2">
            <h6>New Assets Requisitions</h6>
            <h3><a href="'.route('admin.requisition.list').'" title="New Assets Requisitions" class="text-white">' . $newAssetRequisitionCount . '</a></h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';
        $widget3 = '<div class="single_statbox singstat_img green_box widget_box" id="widget3" data-id="3">
            <h6>New Tickets Assigned</h6>
            <h3><a href="'.route('admin.ticket.list').'" title="New Tickets Assigned" class="text-white">' . $unassignedTickets->count() . '</a></h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';
        $widget4 = '<div class="single_statbox singstat_img violet_box widget_box" id="widget4" data-id="4">
            <h6>Upcoming Renewals</h6>
            <h3><a href="'.route('admin.software.license.list').'" title="Upcoming Renewals" class="text-white">' . $softwareLicenseRenewalCount . '</a></h3>
            <div class="stat_icon">
                <img src="' . asset('assets/images/new-assets.svg') . '" class="img-fluid" alt="">
            </div>
        </div>';

        $widget5 = '<div class="card card-body unassign_box widget_box" id="widget5" data-id="5">
            <div class="card_topbar">
                <h6>Todays Tickets</h6>';
        if ($unassignedTickets->count()) {
            $widget5 .= '<a href="' . route('admin.ticket.list', ['type' => 'raised-by-me']) . '" target="_blank">View All</a>';
        }
        $widget5 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Ticket Id#</th>
                                <th scope="col">Subject</th>
                                <th scope="col">Department</th>
                                <th scope="col">Mobile No</th>
                                <th scope="col">Date</th>
                                <th scope="col">Priority</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($unassignedTickets->count()) {
            foreach ($unassignedTickets->take(4) as $key => $ticket) {
                $widget5 .= '<tr>
                                        <th scope="row">' . $ticket->unique_id . '</th>
                                        <td>' . ucfirst($ticket->subject) . '</td>
                                        <td>' . $ticket->department?->name . '</td>
                                        <td>+91 ' . $ticket->mobile_number . '</td>
                                        <td>' . (Carbon::parse($ticket->created_at)->format('d-m-Y')) . '</td>
                                        <td>
                                            <p class="text-secondary">' . ucfirst($ticket->priority) . '</p>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary" href="' . route('admin.ticket.view', $ticket->uuid) . '"><i class="fa fa-eye" aria-hidden="true"></i> View</a>
                                        </td>
                                    </tr>';
            }
        } else {
            $widget5 .= '<tr><td colspan="7" class="text-center">No data found.</td></tr>';
        }
        $widget5 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget6 = '<div class="card card-body stock_box widget_box" id="widget6" data-id="6">
            <div class="card_topbar">
                <h6>Tangible Assets Stock</h6>';
        if ($tangibleAssetsCount) {
            $widget6 .= '<a href="' . route('admin.asset.list') . '" target="_blank">View All</a>';
        }
        $widget6 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">SL</th>
                                <th scope="col">Name.</th>
                                <th scope="col">Entity</th>
                                <th scope="col">Total Stock</th>
                                <th scope="col">Current Stock</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($tangibleAssetsCount) {
            foreach ($tangibleAssets as $key => $asset) {
                $widget6 .= '<tr>
                                        <td scope="row">' . ($key + 1) . '</td>
                                        <td>' . ucwords($asset->asset_name) . '</td>
                                        <td>' . ucwords($asset->assettype?->entity) . '</td>
                                        <td></td>
                                        <td>' . $asset->assetStock?->sum('current_stock') . '</td>
                                        <td><a class="btn btn-primary" href="' . route('admin.assetstock.list', $asset->uuid) . '"><i class="fa fa-eye" aria-hidden="true"></i> View</a></td>
                                    </tr>';
            }
        } else {
            $widget6 .= '<tr><td colspan="6" class="text-center">No data found.</td></tr>';
        }
        $widget6 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget7 = '<div class="card card-body stat_box widget_box" id="widget7" data-id="7">
            <div class="stats_top">
                <p>Entity</p>
                <select name="" class="form-control entity_name" id="entity_id">';
        foreach ($entities as $entity) {
            $widget7 .= '<option value="' . $entity->id . '">' . $entity->name . '</option>';
        }
        $widget7 .= '</select>
            </div>
            <div class="dash_chartbox canvasCustomSize">
                <canvas id="courseChart" width="600" height="400" class="chartjs-render-monitor"></canvas>
                <div class="loader">
                    <div class="loading"></div>
                </div>
            </div>
        </div>';
        $widget8 = '<div class="card card-body unassign_box widget_box" id="widget8" data-id="8">
            <div class="card_topbar">
                <h6>Software License Renewal</h6>';
        if ($softwareLicenseRenewalCount) {
            $widget8 .= '<a href="' . route('admin.software.license.list') . '" target="_blank">View All</a>';
        }
        $widget8 .= '</div>
            <div class="card_table">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Licence Key</th>
                                <th scope="col">Capacity/Specification</th>
                                <th scope="col">Asset Condition</th>
                                <th scope="col">Purchase Date</th>
                                <th scope="col">Warranty/License Date</th>
                            </tr>
                        </thead>
                        <tbody>';
        if ($softwareLicenseRenewalCount) {
            foreach ($softwareLicenseRenewalList as $list) {
                $widget8 .= '<tr>
                                        <td>' . $list->identification_no . '</td>
                                        <td>' . $list->capacity_specs . '</td>
                                        <td>' . $list->asset_condition . '</td>
                                        <td>' . (Carbon::parse($list->purchase_date)->format('Y-m-d')) . '</td>
                                        <td>' . (Carbon::parse($list->warranty_licence_date)->format('Y-m-d')) . '</td>
                                    </tr>';
            }
        } else {
            $widget8 .= '<tr><td colspan="5" class="text-center">No data found.</td></tr>';
        }
        $widget8 .= '</tbody>
                    </table>
                </div>
            </div>
        </div>';
        $widget9 = '<div class="card card-body recentactivity_box" id="widget9" data-id="9">
            <div class="card_topbar">
                <h6>Recent Activity</h6>';
        if ($recentActivities->count()) {
            $widget9 .= '<a href="' . route('admin.recent.activity') . '" target="_blank">View All</a>';
        }
        $widget9 .= '</div>';

        if ($recentActivities->count()) {
            foreach ($recentActivities as $recentActivity) {
                $widget9 .= '<div class="single_activitybox">
                    <h6 class="txt_bold">' . $recentActivity->task_name . '</h6>
                    <a href="' . url($recentActivity->task_url) . '"><h6>' . $recentActivity->task_description . '</h6>
                    <p class="text_blue">' . $this->formatTimeDifference($recentActivity->created_at) . '</p></a>
                    </div>';
            }
        } else {
            $widget9 .= '<div class="single_activitybox">
                No Data Found
                </div>';
        }
        $widget9 .= '</div>';
        $widgets = $this->userService->getAllWidgets();
        $userWidgets = auth()->user()->widgets->toArray();
        $allWidgets = [$widget1, $widget2, $widget3, $widget4, $widget5, $widget6, $widget7, $widget8, $widget9];
        $dashboardWidgets = [];
        foreach ($widgets as $k => $widget) {
            if ($userWidgets) {
                $dashboardWidgets[] = $allWidgets[$userWidgets[$k]['widget_id'] - 1];
            } else {
                $dashboardWidgets[] = $allWidgets[$widget['position'] - 1];
            }
        }


        // $firstEntity=Category::where('type','entity')->first();
        // $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
        // $filterCondition = [];
        // // $filterCondition = ['entity_id'=>$firstEntity->id,'status'=>'1'];

        // $type = $request->type ?? '';
        // $limit = $request->input('length');
        // $start = $request->input('start');
        // $order = 'id';
        // $dir = 'desc';
        // $index = $start;
        // $search = $request->filterData;


        // // $specificDate = Carbon::createFromDate(2023, 10, 1);
        // $today = Carbon::today();
        // // $today = $specificDate;

        // $opentickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->where('entity_id', $firstEntity->id)->where('status', '1')->where('created_at','>=',$today);;
        // $inprogresstickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->where('entity_id', $firstEntity->id)->where('status','-1')->where('created_at','>=',$today);;
        // $closedtickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->where('entity_id', $firstEntity->id)->where('status', '0');


        // $openValue = $opentickets->count();
        // $inprogressValue = $inprogresstickets->count();
        // $closedValue = $closedtickets->count();
        return view('admin.dashboard.index', compact('widgets', 'userWidgets', 'dashboardWidgets'));
    }
    public function profile(Request $request)
    {
        $this->setPageTitle('Admin Profile');
        if ($request->post()) {
            $request->validate([
                'username' => 'required|string|unique:users,username,' . auth()->user()->id,
                'first_name' => 'required|string',
                'last_name' => 'sometimes|string',
                'mobile_number' => 'required|numeric|unique:users,mobile_number,' . auth()->user()->id,
                'gender' => 'sometimes|string|in:male,female,other',
                'birthday' => 'sometimes|nullable|date|date_format:Y-m-d'
            ]);
            DB::beginTransaction();
            try {
                $isUserUpdated = auth()->user()->update($request->only(['first_name', 'last_name', 'mobile_number']));
                if ($isUserUpdated) {
                    $isUserProfileUpdated = auth()->user()->profile()->update($request->only(['gender', 'birthday']));
                    if ($isUserProfileUpdated) {
                        DB::commit();
                        return $this->responseRedirectBack('Profile updated successfully', 'success');
                    }
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error');
            }
        }

        return view('admin.dashboard.profile');
    }
    public function changePassword(Request $request)
    {
        $this->setPageTitle('Change password');
        if ($request->post()) {
            $user = auth()->user();
            // $request->validate([
            //     'current_password' => ['required', function ($key, $value, $fail) use ($user) {
            //         if (!Hash::check($value, $user->password)) {
            //             return $fail(__('The current password is incorrect.'));
            //         }
            //     }],
            //     'password' => 'required|string|min:6|different:current_password|confirmed',
            //     'current_password' =>'required',
            // ]);
            // dd(auth()->user()->mobile_number== $request->current_password);
            //dd($request->password_confirmation,$request->password);
            $rules = [
                'old_password' => 'required',
                'password' => 'required|string|min:6|different:old_password',
                'password_confirmation' => 'required|same:password'
            ];
            $messages = [
                'old_password.required' => 'Old password is required',
                'password.required' => 'New password is required',
                'password_confirmation.required' => 'Confirmation password is required',
                'password_confirmation.same' => 'New password and confirmation password does not match',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                // dd([
                //     'stored_password_hash' => auth()->user()->password,
                //     'old_password_check' => Hash::check($request->old_password, auth()->user()->password)
                // ]);

                // if (auth()->user()->password != bcrypt($request->old_password)) {
                if (!Hash::check($request->old_password, auth()->user()->password)) {
                    return $this->responseJson(false, 500, "Old Password does not match", ['old_password' => 'Old password does not match']);
                } else {
                    $password = bcrypt($request->password);
                    $isUserPasswordUpdated = $user->update([
                        'password' => $password
                    ]);
                    if ($isUserPasswordUpdated) {
                        DB::commit();
                        //return $this->responseRedirectBack('Password Changed Successfully', 'success');
                        return $this->responseJson(true, 200, "Password Successfully Changed", [
                            'redirect_url' => route('admin.home')
                        ]);
                    }
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error');
            }
        }
        return view('admin.dashboard.change-password');
    }
    public function softwareLicenseList(Request $request)
    {
        $this->setPageTitle('Software License List Details');

        $limit = "";
        $start = "";
        $order = 'id';
        $dir = 'desc';
        $index = $start;
        $search = '';
        $toatalAssetsIds = $this->assetService->findAssets(['has_unique_number' => 1])->pluck('id')->toArray();
        $softwareLicenseRenewalList = $this->assetStockService->findInventories([], $order, $dir, $limit, $index, false, $search)->whereIn('asset_id', $toatalAssetsIds)->whereBetween('warranty_licence_date', [Carbon::today(), Carbon::today()->addDays(30)]);

        return view('admin.dashboard.software-license-list', compact('softwareLicenseRenewalList'));
    }
    public function updateDashboardWidget(Request $request)
    {
        if ($request->post()) {
            DB::beginTransaction();
            try {
                $user = auth()->user();
                $widgets = $this->userService->getAllWidgets();
                $userWidgets = $user->widgets->toArray();
                if ($widgets) {
                    foreach ($widgets as $k => $widget) {
                        $status = $request->widget_id ? in_array($widget->id, $request->widget_id) : 0;
                        $user->widgets()->updateOrCreate([
                            'widget_id' => $widget->id,
                        ], [
                            'status' => $status,
                            'position' => $userWidgets ? $userWidgets[$k]['position'] : $widget->position,
                        ]);
                    }
                }
                DB::commit();
                return $this->responseJson(true, 200, 'Dashboard view updated successfully', [
                    'redirect_url' => route('admin.home')
                ]);
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }
    public function recentActivity(Request $request)
    {
        $this->setPageTitle('Recent Activities');
        $args = [];
        if (!auth()->user()->hasRole('super-admin')) {
            $args['added_by'] = auth()->user()->id;
        }
        $recentActivities = $this->assetService->findRecentActivities($args);
        return view('admin.dashboard.recent-activity', compact('recentActivities'));
    }

    protected function formatTimeDifference($createdAt)
    {
        $now = Carbon::now();
        $created = Carbon::parse($createdAt);
        $diff = $created->diffInMinutes($now);

        if ($diff < 60) {
            return $diff . ' mins ago';
        } elseif ($diff < 1440) {
            $hours = floor($diff / 60);
            return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 2880) {
            return 'yesterday';
        } else {
            return $created->format('Y-m-d');
        }
    }
    public function keywordSearch(Request $request)
    {
        $this->setPageTitle('Search Page');
        if ($request->post()) {
            $rules = [
                's' => 'required',
            ];
            $messages = [
                's' => 'Search keywork is required'
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            try {
                $redirect_url = '';
                switch ($request->s_type) {
                    case 'asset_tag':
                        $filterConditions = ['identification_no' => trim(strtoupper($request->s))];
                        $assetInventoery = $this->assetService->findInventoryByCondition($filterConditions);
                        if ($assetInventoery) {
                            // $redirect_url = route('admin.assetstock.history', [$assetInventoery->uuid, 's' => $request->s, 's_type' => $request->s_type]);
                            $redirect_url = route('admin.asset.history', [$assetInventoery->uuid, 's' => $request->s, 's_type' => $request->s_type]);
                        }
                        break;
                    case 'asset_serial_no':
                        $filterConditions = ['unique_id' => trim($request->s)];
                        $assetInventoery = $this->assetService->findInventoryByCondition($filterConditions);
                        if ($assetInventoery) {
                            // $redirect_url = route('admin.assetstock.history', [$assetInventoery->uuid, 's' => $request->s, 's_type' => $request->s_type]);
                            $redirect_url = route('admin.asset.history', [$assetInventoery->uuid, 's' => $request->s, 's_type' => $request->s_type]);
                        }
                        break;
                    case 'asset_id':
                        $filterConditions = ['asset_id' => trim($request->s)];
                        $asset = $this->assetService->findAssetByCondition($filterConditions);
                        if ($asset) {
                            $redirect_url = route('admin.assetstock.list', [$asset->uuid, 's' => $request->s, 's_type' => $request->s_type]);
                        }
                        break;
                }
                if ($redirect_url) {
                    return $this->responseJson(true, 200, 'Asset found successfully', [
                        'redirect_url' => $redirect_url
                    ]);
                } else {
                    return $this->responseJson(false, 200, 'No results are found', '');
                }
            } catch (\Exception $e) {
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error');
            }
        }
        return view('admin.dashboard.search');
    }
    public function resetPassword(Request $request)
    {
        $this->setPageTitle('Reset Password');
        if ($request->post()) {
            $user = auth()->user();
            $rules = [
                'password' => 'required|string|min:8|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@$!%*#?&]).*$/',
                'password_confirmation' => 'required|same:password'
            ];
            $messages = [
                'password.required' => 'Password is required',
                'password.regex' => 'Password format is invalid',
                'password_confirmation.required' => 'Confirmation password is required',
                'password_confirmation.same' => 'Password and confirmation password does not match',
            ];
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
            }
            DB::beginTransaction();
            try {
                $password = bcrypt($request->password);
                $isUserPasswordUpdated = $user->update([
                    'password' => $password,
                ]);
                if ($isUserPasswordUpdated) {
                    User::where('id', $user->id)->update([
                        'last_login_at' => Carbon::now()->toDateTimeString(),
                        'last_login_ip' => $request->getClientIp(),
                    ]);
                    DB::commit();
                    return $this->responseJson(true, 200, 'Password Successfully Changed', [
                        'redirect_url' => route('admin.home')
                    ]);
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseRedirectBack('Something went wrong', 'error', true, true);
            }
        }
        return view('admin.dashboard.reset-password');
    }
}
