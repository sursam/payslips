<?php

namespace App\Http\Controllers\Api\Patient;

// use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\AuthPatientResource;

class AuthController extends BaseController
{
    public function __construct(protected UserService $userService)
    {
        $this->userService = $userService;
    }
    public function signup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'phone' => 'required|numeric|digits:10',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        try {
            $isUser = $this->userService->findUserBy(['mobile_number' => $request->phone]);
            $verificationCode = generateOtp();

            $text = "Your%20Natural%27Fitness%20Patient%20App%20Verification%20Otp%20is%20{CODE}.%20Thank%20you.";
            $text = str_replace('{CODE}',$verificationCode,$text);

            $nameArr = explode(' ',$request->name);
            $first_name = $nameArr[0];
            $last_name = (count($nameArr) > 1) ? $nameArr[1] : '';
            if($isUser){
                if ($isUser->hasRole('patient')) {
                    if(!$isUser->is_approve){
                        $isUserUpdated = $isUser->update([
                            'verification_code' => $verificationCode,
                            'first_name' => $first_name,
                            'last_name' => $last_name
                        ]);
                        if($isUserUpdated){
                            // $smsResponse = sendSms($request->phone, $text);
                            // if($smsResponse->ok()){
                                // dd($smsResponse->body());
                                $data = ['otp' => $verificationCode];
                                return $this->responseJson(true, 200, "Otp sent successfully", $data);
                            // }
                        }
                    }else{
                        return $this->responseJson(false, 200, 'Sorry this mobile number has been already registered', (object)[]);
                    }
                    /*if ($isUser->is_active) {
                        $isUserUpdated = $isUser->update([
                            'verification_code' => $verificationCode,
                            'first_name' => $first_name,
                            'last_name' => $last_name
                        ]);
                        if($isUserUpdated){
                            // $smsResponse = sendSms($request->phone, $text);
                            // if($smsResponse->ok()){
                                // dd($smsResponse->body());
                                $data = ['otp' => $verificationCode];
                                return $this->responseJson(true, 200, "Otp sent successfully", $data);
                            // }
                        }
                    }else{
                        return $this->responseJson(false, 200, 'Sorry your account has been suspended', (object)[]);
                    }*/

                }else{
                    return $this->responseJson(false, 200, 'Sorry you are not a patient', (object)[]);
                }
            }else{
                $isUserCreated = $this->userService->createUser([
                    'mobile_number' => $request->phone,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'verification_code' => $verificationCode,
                    'is_active' => true,
                    'is_approve' => false,
                    'is_blocked' => false,
                    'role' => 'patient',
                ]);
                if($isUserCreated){
                    // $smsResponse = sendSms($request->phone, $text);
                    // if($smsResponse->ok()){
                        $data = ['otp' => $verificationCode];
                        return $this->responseJson(true, 200, "Otp sent successfully", $data);
                    // }
                }
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|numeric|digits:10',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        try {
            $isUser = $this->userService->findUserBy(['mobile_number' => $request->phone]);
            if($isUser){
                if ($isUser->hasRole('patient')) {
                    if ($isUser->is_active) {
                        $verificationCode = generateOtp();
                        $text = "Your%20Natural%27Fitness%20Patient%20App%20Verification%20Otp%20is%20{CODE}.%20Thank%20you.";
                        $text = str_replace('{CODE}',$verificationCode,$text);
                        $isUserUpdated = $isUser->update([
                            'verification_code' => $verificationCode
                        ]);
                        if($isUserUpdated){
                            // $smsResponse = sendSms($request->phone, $text);
                            // if($smsResponse->ok()){
                                // dd($smsResponse->body());
                                $data = ['otp' => $verificationCode];
                                return $this->responseJson(true, 200, "Otp sent successfully", $data);
                            // }
                        }else{
                            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
                        }
                    }else{
                        return $this->responseJson(false, 200, 'Sorry your account has been suspended', (object)[]);
                    }
                }else{
                    return $this->responseJson(false, 200, 'Sorry you are not a patient', (object)[]);
                }
            }else{
                return $this->responseJson(false, 200, 'Sorry patient not found', (object)[]);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|numeric|exists:users,mobile_number',
            'otp'   => 'required|numeric|exists:users,verification_code',
        ]);
        if ($validator->fails()) return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        DB::beginTransaction();
        try {
            $user = $this->userService->findUserBy(['mobile_number' => $request->phone, 'verification_code' => $request->otp]);
            // dd($user);
            if($user){
                $dataToUpdate = [
                    'last_login_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    'is_approve' => true
                ];
                if($request->fcm_token){
                    $dataToUpdate['fcm_token'] = $request->fcm_token;
                }
                if(is_null($user->mobile_number_verified_at)){
                    $dataToUpdate['mobile_number_verified_at'] = Carbon::now()->format('Y-m-d H:i:s');
                }

                $user->update($dataToUpdate);

                DB::commit();
                return $this->responseJson(true, 200, "OTP verified successfully",new AuthPatientResource($user));
            }else{
                return $this->responseJson(false, 200, "Please enter a valid OTP",(object)[]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
    public function resendOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|numeric|digits:10',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        }

        try {
            $isUser = $this->userService->findUserBy(['mobile_number' => $request->phone]);
            $verificationCode = generateOtp();

            $text = "Your%20Natural%27Fitness%20Patient%20App%20Verification%20Otp%20is%20{CODE}.%20Thank%20you.";
            $text = str_replace('{CODE}',$verificationCode,$text);

            if($isUser){
                if ($isUser->hasRole('patient')) {
                    if ($isUser->is_active) {
                        $isUserUpdated = $isUser->update([
                            'verification_code' => $verificationCode
                        ]);
                        if($isUserUpdated){
                            // $smsResponse = sendSms($request->phone, $text);
                            // if($smsResponse->ok()){
                                // dd($smsResponse->body());
                                $data = ['otp' => $verificationCode];
                                return $this->responseJson(true, 200, "Otp sent successfully", $data);
                            // }
                        }
                    }else{
                        return $this->responseJson(false, 200, 'Sorry your account has been suspended', (object)[]);
                    }
                }else{
                    return $this->responseJson(false, 200, 'Sorry you are not a patient', (object)[]);
                }
            }else{
                return $this->responseJson(false, 200, 'Invalid mobile number', (object)[]);
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
}
