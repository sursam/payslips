<?php

namespace App\Http\Controllers\Api\Patient;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use App\Services\Category\CategoryService;
use App\Http\Resources\Api\PatientResource;
use App\Http\Resources\Api\ReferralSourcesResource;
use App\Models\Site\Category;

class UserController extends BaseController
{
    public function __construct(
        protected UserService $userService,
        protected CategoryService $categoryService,
    )
    {
        $this->userService = $userService;
        $this->categoryService = $categoryService;
    }
    public function getReferralSources()
    {
        try {
            $referralSources = $this->categoryService->listCategories(['type' => 'referral']);
            $message = $referralSources ? "Referral sources found successfully" : "Referral sources not found";
            return $this->responseJson(true, 200, $message, ReferralSourcesResource::collection($referralSources));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function addReferral(Request $request)
    {
        $category_id = uuidtoid($request->source_uuid, 'categories');
        $reference_type = $request->reference_type;
        $validator = Validator::make($request->all(), [
            'source_uuid' => 'required',
            'referral_name' => Rule::requiredIf(function() use ($category_id, $reference_type){
                $referralSource = Category::find($category_id);
                return ($referralSource->slug == 'dsr-ibd' && $reference_type == 'other');
            }),
            'referral_phone' => Rule::requiredIf(function() use ($category_id, $reference_type){
                $referralSource = Category::find($category_id);
                return ($referralSource->slug == 'dsr-ibd' && $reference_type == 'other');
            }),
            'ibd_number' => Rule::requiredIf(function() use ($category_id){
                $referralSource = Category::find($category_id);
                return ($referralSource->slug == 'dsr-ibd');
            })
        ]);
        if ($validator->fails()) return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
        try {
            DB::beginTransaction();
            $data = [
                'user_id' => auth()->user()->id,
                'category_id' => $category_id,
                'type' => $request->reference_type,
                'name' => $request->referral_name,
                'mobile_number' => $request->referral_phone,
                'ibd_number' => $request->ibd_number
            ];
            if($request->type == 'self'){
                $data['name'] = auth()->user()->full_name;
                $data['mobile_number'] = auth()->user()->mobile_number;
            }
            $isReferralCreated = $this->userService->createOrUpdateReferral($data);

            $message = $isReferralCreated ? "Referral successfully added" : "Referral not added";
            DB::commit();
            return $this->responseJson(true, 200, $message, (object)[]);

        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
    public function getPatientDetails()
    {
        try {
            $userDetails = auth()->user();

            $message = $userDetails ? "Profile found successfully" : "Profile not found";
            return $this->responseJson(true, 200, $message, new PatientResource($userDetails));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function updatePatientDetails(Request $request)
    {
        try {
            $userDetails = auth()->user();
            $validator = Validator::make($request->all(), [
                'name' => 'required|string',
                'email' => 'required|email|unique:users,email,'.$userDetails->id.',id,deleted_at,NULL',
                'occupation' => 'nullable|string',
                'gender' => 'required|string',
            ]);
            if ($validator->fails()) return $this->responseJson(false, 200, $validator->errors()->first(), (object)[]);
            DB::beginTransaction();
            $nameArr = explode(' ', $request->name);
            $firstName = $nameArr[0];
            $lastName = (count($nameArr) > 1) ? $nameArr[1] : '';
            $request->merge(['first_name' => $firstName, 'last_name' => $lastName, 'role' => 'patient', 'is_registered' => 1]);
            $isUserUpdated = $this->userService->updateUser($request->except(['_token', 'name']), $userDetails->id);

            $message = $isUserUpdated ? "Profile updated successfully" : "Profile not updated";
            DB::commit();
            return $this->responseJson(true, 200, $message, new PatientResource($userDetails->fresh()));

        } catch (\Exception $e) {
            DB::rollBack();
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something Went Wrong", (object)[]);
        }
    }
}
