<?php

namespace App\Http\Controllers\Api\Patient;

use Illuminate\Http\Request;
use App\Services\Fare\FareService;
use App\Services\User\UserService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\BaseController;
use App\Services\Booking\BookingService;
use App\Services\Medical\MedicalService;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\Api\IssuesResource;
use App\Services\Category\CategoryService;
use App\Http\Resources\Api\BookingResource;
use App\Http\Resources\Api\DoctorLevelResource;
use App\Http\Resources\Api\QuestionResource;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class BookingController extends BaseController
{
    public function __construct(
        protected BookingService $bookingService,
        protected UserService $userService,
        protected FareService $fareService,
        protected MedicalService $medicalService,
        protected CategoryService $categoryService
    )
    {
        $this->bookingService = $bookingService;
        $this->userService = $userService;
        $this->fareService = $fareService;
        $this->medicalService = $medicalService;
        $this->categoryService = $categoryService;
    }
    public function getIssues(Request $request)
    {
        try {
            $issues = $this->medicalService->listIssues([]);
            $message = $issues ? "Issues found successfully" : "Issues not found";
            return $this->responseJson(true, 200, $message, IssuesResource::collection($issues));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function addBooking(Request $request)
    {
        if ($request->post()) {
            $bookingId = $request->booking_uuid ? uuidtoid($request->booking_uuid,'bookings') : null;
            $validator = Validator::make($request->all(),
            [
                'step' => 'required|string|in:first,second,third',
                "issue_uuid" => 'required_if:step,first|string',
                "booking_for" => 'required_if:step,first|string',
                "other_name" => 'string',
                "other_age" => 'numeric',
                "relationship" => 'string',
                "gender" => 'required_if:step,first|string',
                "consultaion_type" => 'required_if:step,first|string',
                "doctor_level_uuid" => 'required_if:step,first|string',
                "survey_results" => 'required_if:step,second|array',
                "booking_datetime" => 'required_if:step,third|date|date_format:Y-m-d H:i:s',
            ],
            [
                'step' => 'Step is required',
                "issue_uuid" => 'Please select an issue',
                "booking_for" => 'Please select whom do you booking for',
                "other_name" => 'Name is required',
                "other_age" => 'Age is required',
                "relationship" => 'Please enter relationship with the patient',
                "gender" => 'Gender is required',
                "consultaion_type" => 'Please select type of consultation',
                "doctor_level_uuid" => 'Please select whom you want',
                "survey_results" => 'Please answer the questions',
                "booking_datetime" => 'Booking time is required',
            ]);
            $validator->sometimes('other_name', 'required', function($request) {
                return ($request->step == 'first' && $request->booking_for == 'other');
            });
            $validator->sometimes('other_age', 'required', function($request) {
                return ($request->step == 'first' && $request->booking_for == 'other');
            });
            $validator->sometimes('relationship', 'required', function($request) {
                return ($request->step == 'first' && $request->booking_for == 'other');
            });
            if ($validator->fails()) return $this->responseJson(false, 200, $validator->errors(), (object)[]);
            DB::beginTransaction();
            try{
                $data = [
                    "step" => strtolower($request->step)
                ];
                switch (strtolower($request->step)){
                    case 'first':
                        $issueId = uuidtoid($request->issue_uuid,'issues');
                        $doctorLevelId = uuidtoid($request->doctor_level_uuid,'categories');
                        $data["issue_id"]           = $issueId;
                        $data["patient_id"]         = auth()->user()->id;
                        $data["booking_for"]        = strtolower($request->booking_for);
                        $data["other_name"]         = $request->other_name ?? null;
                        $data["other_age"]          = $request->other_age ?? null;
                        $data["other_relationship"] = $request->relationship ?? null;
                        $data["gender"]             = strtolower($request->gender);
                        $data["consultaion_type"]   = strtolower($request->consultaion_type);
                        $data["doctor_level_id"]    = $doctorLevelId;
                        break;
                    case 'second':
                        $data["survey_results"]     = $request->survey_results;
                        break;
                    case 'third':
                        $data["booking_datetime"]   = $request->booking_datetime;
                        $data["other_info"]         = $request->other_info ?? null;
                        $data["status"]             = 1;
                        break;
                }
                //dd($data);
                $isBookingCreated= $this->bookingService->createOrUpdateBooking($data, $bookingId);
                if($isBookingCreated){
                    DB::commit();
                    return $this->responseJson(true, 200, "Booking successfully done.", new BookingResource($isBookingCreated));
                }
            }catch(\Exception $e){
                DB::rollback();
                dd($e);
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
    }
    public function listBookings(Request $request, $status = null)
    {
        try {
            $filterCondition = [];
            switch($status){
                case 'booked': $filterCondition['status'] = 1; break;
                case 'cancelled': $filterCondition['status'] = 2; break;
                case 'attended': $filterCondition['status'] = 3; break;
                case 'absent': $filterCondition['status'] = 4; break;
            }
            $bookings = $this->bookingService->listBookings($filterCondition, $status);
            $message = $bookings ? "Bookings found successfully" : "Bookings not found";
            return $this->responseJson(true, 200, $message, BookingResource::collection($bookings));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function viewBookingDetails(Request $request, $uuid)
    {
        try {
            $id = uuidtoid($uuid, 'bookings');
            $bookingData = $this->bookingService->findById($id);
            $message = $bookingData ? "Booking details found successfully" : "Booking details not found";
            return $this->responseJson(true, 200, $message, new BookingResource($bookingData));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function cancelBookingApi(Request $request)
    {
        try {
            $id = uuidtoid($request->uuid, 'bookings');
            $bookingData = $this->bookingService->findById($id);
            if($bookingData->count()){
                if(Carbon::today()->format('Y-m-d H:i:s') <= $bookingData->booking_datetime){
                    if($bookingData->status != 2){
                        $filterConditions = [
                            'status' => 2
                        ];
                        $data = $this->bookingService->updateBooking($filterConditions, $id);
                        if (isset($data)) {
                            return $this->responseJson(true, 200, 'Booking cancelled');
                        } else {
                            return $this->responseJson(false, 500, 'Something wrong happened');
                        }
                    }else{
                        return $this->responseJson(false, 200, 'Booking has already been cancelled');
                    }
                }else{
                    return $this->responseJson(false, 200, 'Booking date expired');
                }
            }else{
                return $this->responseJson(false, 200, 'Invalid booking');
            }
        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function getDoctorLevels(Request $request)
    {
        try {
            $filterConditionsCategory = ['type' => 'doctor_level'];
            $doctorLevels = $this->categoryService->listCategories($filterConditionsCategory);
            $message = $doctorLevels ? "Doctor Levels found successfully" : "Doctor Levels not found";
            return $this->responseJson(true, 200, $message, DoctorLevelResource::collection($doctorLevels));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function getQuestions(Request $request)
    {
        try {
            $issueUuid = $request->issue_uuid;
            $issueId = uuidtoid($issueUuid, 'issues');
            $issue = $this->medicalService->findIssueById($issueId);
            $questions = $issue->questions;
            $message = $questions ? "Questions found successfully" : "Questions not found";
            return $this->responseJson(true, 200, $message, QuestionResource::collection($questions));

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
    public function rescheduleBookingApi(Request $request){
        $bookingUuid = $request->uuid;
        $bookingId = uuidtoid($bookingUuid,'bookings');
        if($request->post()){
            $request->validate(
                [
                    "booking_datetime" => 'required|date|date_format:Y-m-d H:i:s',
                ],
                [
                    "booking_datetime" => 'Booking time is required',
                ]
            );
            DB::beginTransaction();
            try{
                $isBookingUpdated= $this->bookingService->createOrUpdateBooking($request->except('_token'), $bookingId);
                if($isBookingUpdated){
                    $bookingData = $this->bookingService->findById($bookingId);
                    DB::commit();
                    return $this->responseJson(true, 200, "Booking successfully rescheduled.", new BookingResource($bookingData));
                }
            }catch(\Exception $e){
                DB::rollback();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseRedirectBack('Something went wrong','error',true);
            }
        }
    }
    public function getAvailableSlots(Request $request)
    {
        try {
            $doctorUuid     = $request->doctor_uuid;
            $doctorId       = $doctorUuid ? uuidtoid($doctorUuid,'users') : null;
            $selectedDate   = $request->selected_date;
            $selectedSlot   = $request->selected_slot;
            $selectedDay    = Carbon::parse($selectedDate)->format('l');
            $startPeriod    = Carbon::parse($selectedDate.' 8:00:00');
            $endPeriod      = Carbon::parse($selectedDate.' 18:00:00');
            $period         = CarbonPeriod::create($startPeriod, '15 minutes', $endPeriod);
            if(!$doctorId){
                $bookedTimes = $this->bookingService->getAllUnavailableTimesByDate($selectedDate);
                // dd($bookedTimes);
            }else{
                $doctor = $this->userService->findById($doctorId);
                $bookedTimes = $doctor->bookedTimesByDate($selectedDate);
            }

            $slots = [];
            foreach ($period as $k => $time){
                if(!$doctorId){
                    $disabled = (in_array($time, $bookedTimes) && ($selectedSlot != $time)) ? true : false;
                    if($disabled){
                        // dd($time->format('Y-m-d h:i:s'));
                    }
                }else{
                    $availabilities = $doctor->availabilitiesByDay($selectedDay, $time);
                    $disabled = ((!$availabilities->count() || in_array($time, $bookedTimes))  && $selectedSlot != $time) ? true : false;

                    $disabled = (!$disabled && !$availabilities->count()) ? true : $disabled;
                }
                $booked = ($selectedSlot && $selectedSlot == $time && !$disabled) ? true : false;

                $slots[$k]['time'] = $time->format('Y-m-d h:i:s');
                $slots[$k]['disabled'] = $disabled;
                $slots[$k]['booked'] = $booked;
            }
            // dd($slots);

            return $this->responseJson(true, 200, "Available slots fetched successfully.", (Array) $slots);

        } catch (\Exception $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", (object)[]);
        }
    }
}
