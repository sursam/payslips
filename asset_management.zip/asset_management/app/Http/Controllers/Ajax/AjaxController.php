<?php

namespace App\Http\Controllers\Ajax;

use App\Exports\Inventory\AssetDetailsExport;
use App\Exports\Inventory\AssetStockDetailsExport;
use App\Http\Controllers\BaseController;
use App\Mail\SendMailable;
use App\Models\Budget\Budget;
use App\Models\Budget\BudgetApproval;
use App\Models\Budget\BudgetItem;
use App\Models\Budget\BudgetVersion;
use App\Models\Company\Location;
use App\Models\Lease\LeaseItem;
use App\Models\Location\State;
use App\Models\Maintenance\MaintenanceItem;
use App\Models\Master\Asset;
use App\Models\Purchase\PoInvoiceApproval;
use App\Models\Purchase\PurchaseOrderApproval;
use App\Models\Requisition\Quotation;
use App\Models\Requisition\Requisition;
use App\Models\Requisition\RequisitionApproval;
use App\Models\Requisition\RfqApproval;
use App\Models\Site\Department;
use App\Models\Site\EntityDepartmentSetting;
use App\Models\Ticket\SlaTime;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Notifications\BudgetApproveNotification;
use App\Notifications\PoApproveNotification;
use App\Notifications\PoInvoiceApproveNotification;
use App\Notifications\RequisitionApproveNotification;
use App\Notifications\RfqApproveNotification;
use App\Notifications\TicketNotification;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Services\Brand\BrandService;
use App\Services\Category\CategoryService;
use App\Services\Inventory\AssetStockService;
use App\Services\Inventory\InwardStockService;
use App\Services\Inventory\OutwardStockService;
use App\Services\Location\CityService;
use App\Services\Location\StateService;
use App\Services\Report\ReportService;
use App\Services\Role\RolePermissionService;
use App\Services\Ticket\TicketService;
use App\Services\User\UserService;
use App\Services\User\VendorService;
use App\Services\Workflow\WorkflowService;
use App\Traits\PushNotificationTrait;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Dompdf\Dompdf;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class AjaxController extends BaseController
{
    use PushNotificationTrait;
    public function __construct(
        protected CategoryService $categoryService,
        protected StateService $stateService,
        protected BrandService $brandService,
        protected AssetService $assetService,
        protected AssetTypeService $assetTypeService,
        protected UserService $userService,
        protected CityService $cityService,
        protected VendorService $vendorService,
        protected AssetStockService $assetStockService,
        protected InwardStockService $inwardStockService,
        protected OutwardStockService $outwardStockService,
        protected RolePermissionService $rolePermissionService,
        protected WorkflowService $workflowService,
        protected TicketService $ticketService,
        protected ReportService $reportService,
    ) {
        $this->categoryService = $categoryService;
        $this->stateService = $stateService;
        $this->brandService = $brandService;
        $this->assetService = $assetService;
        $this->assetTypeService = $assetTypeService;
        $this->userService = $userService;
        $this->cityService = $cityService;
        $this->vendorService = $vendorService;
        $this->assetStockService = $assetStockService;
        $this->inwardStockService = $inwardStockService;
        $this->outwardStockService = $outwardStockService;
        $this->rolePermissionService = $rolePermissionService;
        $this->workflowService = $workflowService;
        $this->ticketService = $ticketService;
        $this->reportService = $reportService;
    }

    public function setStatus(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            $id = uuidtoid($request->uuid, $table);
            $data = null;
            switch ($table) {
                case 'categories':
                    $data = $this->categoryService->updateStatus($request->only('is_active'), $id);
                    $message = 'Category status updated';
                    break;

                case 'users':
                    $data = $this->userService->updateUserStatus($request->only('is_active'), $id);
                    $message = 'Employee status updated';
                    break;

                case 'vendors':
                    $data = $this->vendorService->updateVendorStatus($request->only('is_active'), $id);
                    $message = 'Vendor status updated';
                    break;

                case 'asset_types':
                    $data = $this->assetTypeService->updateStatus($request->only('is_active'), $id);
                    $message = 'Asset Type status updated';
                    break;

                case 'assets':
                    $data = $this->assetService->updateStatus($request->only('is_active'), $id);
                    $message = 'Asset status updated';
                    break;

                case 'asset_stocks':
                    $data = $this->assetStockService->updateStatus($request->only('is_active'), $id);
                    $message = 'Asset Stock status updated';
                    break;

                case 'departments':
                    $data = $this->assetService->updateDepartmentStatus($request->only('is_active'), $id);
                    $message = 'Department status updated';
                    break;

                case 'inward_stocks':
                    $data = $this->inwardStockService->updateStatus($request->only('is_active'), $id);
                    $message = 'Asset Stock status updated';
                    break;

                case 'outward_stocks':
                    $data = $this->outwardStockService->updateStatus($request->only('is_active'), $id);
                    $message = 'Asset Stock status updated';
                    break;
                case 'requisitions':
                    // $data = $this->assetService->updateRequisitionStatus($request->only('status'), $id);
                    $status = (int) $request->is_active;
                    $level = (int) $request->level;
                    $requisition = $this->assetService->findRequisitionById($id);
                    $approvalLevels = RequisitionApproval::where('requisition_id', $requisition->id)->where('level', '<>', $level)->get();
                    $fullname = Auth::user()->first_name . " " . Auth::user()->last_name;
                    if ($status == 1) {
                        $currentData = [
                            'requisition_id' => $id,
                            'level' => $level,
                            'status' => $status,
                            'comments' => $request->comments ?? null
                        ];
                        $isApprovalUpdated = $this->assetService->createOrUpdateRequisitionApproval($currentData);
                        if ($isApprovalUpdated) {
                            $checkRequisitionApproval = $this->assetService->checkRequisitionApproval($id, null, ($level + 1));
                            $data = false;
                            if ($checkRequisitionApproval) {
                                $nextData = [
                                    'requisition_id' => $id,
                                    'level' => ($level + 1),
                                    'status' => 0
                                ];
                                $isApprovalUpdatedNext = $this->assetService->createOrUpdateRequisitionApproval($nextData);

                                if ($isApprovalUpdatedNext) {
                                    $data = $this->assetService->updateRequisitionStatus(['status' => 5], $id);
                                }
                            } else {
                                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                    'task_name' => 'Requisition Approval',
                                    'task_description' => $requisition->unique_id,
                                    'task_url' => 'modules/requisition/view/' . $requisition->uuid,
                                    'added_by' => auth()->user()->id,
                                    'type' => 'approve-requisition',
                                    'related_id' => $requisition->id
                                ]);
                                $data = $this->assetService->updateRequisitionStatus(['status' => $status], $id);
                            }

                            if ($data) {
                                $addUserData = $this->userService->findUserById($requisition->added_by);
                                $creatUserData = $this->userService->findUserById($requisition->created_by);
                                $notiData = [
                                    'form_name' => "#" . $requisition->unique_id . " this requisition has been approved by " . $fullname,
                                    'requisition_uuid' => $requisition->uuid,
                                ];
                                $addUserData->notify(new RequisitionApproveNotification($notiData));
                                $creatUserData->notify(new RequisitionApproveNotification($notiData));
                                if ($checkRequisitionApproval) {
                                    $nextLevelUser = $this->userService->findUserById($checkRequisitionApproval->user_id);
                                    $nextLevelUserFullname = $nextLevelUser->first_name . " " . $nextLevelUser->last_name;
                                    $notifyData = [
                                        'form_name' => $nextLevelUserFullname . " got a requisition approval request for requisition ID #" . $requisition->unique_id,
                                        'requisition_uuid' => $requisition->uuid,
                                    ];
                                    $addUserData->notify(new RequisitionApproveNotification($notifyData));
                                    $creatUserData->notify(new RequisitionApproveNotification($notifyData));
                                }
                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new RequisitionApproveNotification($notiData));

                                    /***** Next level notification *****/
                                    if ($checkRequisitionApproval) {
                                        if ($approvallevel->level == ($level + 1)) {
                                            $notiData = [
                                                'form_name' => "You got a requisition approval request for the ID #" . $requisition->unique_id,
                                                'requisition_uuid' => $requisition->uuid,
                                            ];
                                            $userData->notify(new RequisitionApproveNotification($notiData));

                                            $requestparam = (object) [
                                                'title' => "Requisition approval request",
                                                'body' => "You got a requisition approval request for the ID #" . $requisition->unique_id,
                                            ];
                                            $this->sendPushNotification($userData->id, $requestparam);
                                        } else {
                                            $userData->notify(new RequisitionApproveNotification($notifyData));
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        $currentData = [
                            'requisition_id' => $id,
                            'level' => $level,
                            'status' => 2,
                            'comments' => $request->comments
                        ];
                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'Requisition Rejection',
                            'task_description' => $requisition->unique_id,
                            'task_url' => 'modules/requisition/view/' . $requisition->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'reject-requisition',
                            'related_id' => $requisition->id

                        ]);
                        $isApprovalUpdated = $this->assetService->createOrUpdateRequisitionApproval($currentData);
                        if ($isApprovalUpdated) {
                            $data = $this->assetService->updateRequisitionStatus(['status' => $status], $id);
                            if ($data) {
                                $requisitionData = $this->assetService->findRequisitionById($requisition->id);
                                $notiData = [
                                    'form_name' => "#" . $requisition->unique_id . " this requisition has been rejected by " . $fullname,
                                    'requisition_uuid' => $requisition->uuid,
                                ];
                                $creatUserData = $this->userService->findUserById($requisitionData->created_by);
                                $creatUserData->notify(new RequisitionApproveNotification($notiData));

                                if ($requisitionData->created_by != $requisitionData->added_by) {
                                    $addUserData = $this->userService->findUserById($requisitionData->added_by);
                                    $addUserData->notify(new RequisitionApproveNotification($notiData));
                                }


                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new RequisitionApproveNotification($notiData));
                                }
                            }
                        }
                    }
                    $message = 'Requisition status updated';
                    break;


                case 'budget_items':
                    $data = $this->assetService->updateBudgetItemStatus($request->only('status'), $id);
                    $message = 'Budget Item status updated';
                    break;

                case 'budgets':
                    $status = (int) $request->is_active;
                    $level = (int) $request->level;
                    $budget = $this->assetService->findBudgetById($id);
                    $approvalLevels = BudgetApproval::where('budget_id', $budget->id)->where('level', '<>', $level)->get();
                    $fullname = Auth::user()->first_name . " " . Auth::user()->last_name;
                    if ($status == 1) {
                        $currentData = [
                            'budget_id' => $id,
                            'level' => $level,
                            'status' => $status,
                            'comments' => $request->comments ?? null
                        ];
                        $isApprovalUpdated = $this->assetService->createOrUpdateBudgetApproval($currentData);
                        if ($isApprovalUpdated) {
                            $checkBudgetApproval = $this->assetService->checkBudgetApproval($id, null, ($level + 1));
                            $data = false;
                            if ($checkBudgetApproval) {
                                $nextData = [
                                    'budget_id' => $id,
                                    'level' => ($level + 1),
                                    'status' => 0
                                ];
                                $isApprovalUpdatedNext = $this->assetService->createOrUpdateBudgetApproval($nextData);

                                if ($isApprovalUpdatedNext) {
                                    $data = $this->assetService->updateBudgetStatus(['status' => 5], $id);
                                }
                            } else {
                                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                    'task_name' => 'Budget Approval',
                                    'task_description' => $budget->name . '(' . $budget->unique_id . ')',
                                    'task_url' => 'modules/budget/view/' . $budget->uuid,
                                    'added_by' => auth()->user()->id,
                                    'type' => 'approve-budget',
                                    'related_id' => $budget->id
                                ]);
                                $data = $this->assetService->updateBudgetStatus(['status' => $status], $id);
                            }

                            if ($data) {
                                $addUserData = $this->userService->findUserById($budget->added_by);
                                $creatUserData = $this->userService->findUserById($budget->created_by);
                                $notiData = [
                                    'form_name' => "#" . $budget->unique_id . " this budget has been approved by " . $fullname,
                                    'budget_uuid' => $budget->uuid,
                                ];
                                $addUserData->notify(new BudgetApproveNotification($notiData));
                                $creatUserData->notify(new BudgetApproveNotification($notiData));
                                if ($checkBudgetApproval) {
                                    $nextLevelUser = $this->userService->findUserById($checkBudgetApproval->user_id);
                                    $nextLevelUserFullname = $nextLevelUser->first_name . " " . $nextLevelUser->last_name;
                                    $notifyData = [
                                        'form_name' => $nextLevelUserFullname . " got a budget approval request for budget ID #" . $budget->unique_id,
                                        'budget_uuid' => $budget->uuid,
                                    ];
                                    $addUserData->notify(new BudgetApproveNotification($notifyData));
                                    $creatUserData->notify(new BudgetApproveNotification($notifyData));



                                    // dd($addUserData->email,$creatUserData->email);
                                    $mailData = [
                                        'to' => [$addUserData->email, $creatUserData->email],
                                        'from' => env('MAIL_FROM_ADDRESS'),
                                        'mail_type' => 'general',
                                        'line' => 'Please be informed that the budget proposal for ' . $budget->project_title . ' this project has been submitted for internal approval. Below are the key details:<br><br><br>',
                                        'content' => 'Project/Department: ' . $budget->project_title . '/ ' . $budget->department?->name . '<br>Total Budget Amount: RS ' . $budget->amount . '<br>Submitted By: ' . $budget->createdBy?->full_name . '<br>Submission Date: ' . $budget->created_at->format('Y-m-d') . '<br><br><br>Kindly review the proposal and provide feedback or approval as necessary.' . '<br><br><br>To approve or reject the requisition, kindly use the following link: ' .  '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>',
                                        'subject' => ' Budget Proposal Sent for Approval',
                                        'greetings' => 'Dear ' . $addUserData->full_name . ',',
                                        'end_greetings' => 'Best Regards,<br>DHC',
                                        'from_user' => env('MAIL_FROM_NAME')
                                    ];
                                    Mail::send(new SendMailable($mailData));
                                }
                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);

                                    $userData->notify(new BudgetApproveNotification($notiData));

                                    /***** Next level notification *****/
                                    if ($checkBudgetApproval) {
                                        if ($approvallevel->level == ($level + 1)) {
                                            $notiData = [
                                                'form_name' => "You got a budget approval request for the ID #" . $budget->unique_id,
                                                'budget_uuid' => $budget->uuid,
                                            ];
                                            $userData->notify(new BudgetApproveNotification($notiData));



                                            $mailData = [
                                                'to' => $userData->email,
                                                'from' => env('MAIL_FROM_ADDRESS'),
                                                'mail_type' => 'general',
                                                'line' => 'Please be informed that the budget proposal for ' . $budget->project_title . ' this project has been submitted for internal approval. Below are the key details:<br><br><br>',
                                                'content' => 'Project/Department: ' . $budget->project_title . '/ ' . $budget->department?->name . '<br>Total Budget Amount: RS ' . $budget->amount . '<br>Submitted By: ' . $budget->createdBy?->full_name . '<br>Submission Date: ' . $budget->created_at->format('Y-m-d') . '<br><br><br>Kindly review the proposal and provide feedback or approval as necessary.' . '<br><br><br>To approve or reject the requisition, kindly use the following link: ' .  '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>',
                                                'subject' => ' Budget Proposal Sent for Approval',
                                                'greetings' => 'Dear ' . $userData->full_name . ',',
                                                'end_greetings' => 'Best Regards,<br>DHC',
                                                'from_user' => env('MAIL_FROM_NAME')
                                            ];
                                            Mail::send(new SendMailable($mailData));




                                            $requestparam = (object) [
                                                'title' => "Budget approval request",
                                                'body' => "You got a budget approval request for the ID #" . $budget->unique_id,
                                            ];
                                            $this->sendPushNotification($userData->id, $requestparam);
                                        } else {
                                            $userData->notify(new BudgetApproveNotification($notifyData));
                                            // dd($userData->email);
                                            $mailData = [
                                                'to' => $userData->email,
                                                'from' => env('MAIL_FROM_ADDRESS'),
                                                'mail_type' => 'general',
                                                'line' => 'Please be informed that the budget proposal for ' . $budget->project_title . ' this project has been submitted for internal approval. Below are the key details:<br><br><br>',
                                                'content' => 'Project/Department: ' . $budget->project_title . '/ ' . $budget->department?->name . '<br>Total Budget Amount: RS ' . $budget->amount . '<br>Submitted By: ' . $budget->createdBy?->full_name . '<br>Submission Date: ' . $budget->created_at->format('Y-m-d') . '<br><br><br>Kindly review the proposal and provide feedback or approval as necessary.' . '<br><br><br>To approve or reject the requisition, kindly use the following link: ' .  '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>',
                                                'subject' => ' Budget Proposal Sent for Approval',
                                                'greetings' => 'Dear ' . $userData->full_name . ',',
                                                'end_greetings' => 'Best Regards,<br>DHC',
                                                'from_user' => env('MAIL_FROM_NAME')
                                            ];
                                            Mail::send(new SendMailable($mailData));
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        $currentData = [
                            'budget_id' => $id,
                            'level' => $level,
                            'status' => 2,
                            'comments' => $request->comments
                        ];

                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'Budget Rejection',
                            'task_description' => $budget->name . '(' . $budget->unique_id . ')',
                            'task_url' => 'modules/budget/view/' . $budget->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'reject-budget',
                            'related_id' => $budget->id
                        ]);
                        //dd($currentData);
                        $isApprovalUpdated = $this->assetService->createOrUpdateBudgetApproval($currentData);
                        if ($isApprovalUpdated) {
                            $data = $this->assetService->updateBudgetStatus(['status' => $status], $id);
                            if ($data) {
                                $budgetData = $this->assetService->findBudgetById($budget->id);
                                $notiData = [
                                    'form_name' => "#" . $budget->unique_id . " this budget has been rejected by " . $fullname,
                                    'budget_uuid' => $budget->uuid,
                                ];

                                $creatUserData = $this->userService->findUserById($budgetData->created_by);
                                $creatUserData->notify(new BudgetApproveNotification($notiData));
                                if ($budgetData->created_by != $budgetData->added_by) {
                                    $addUserData = $this->userService->findUserById($budgetData->added_by);
                                    $addUserData->notify(new BudgetApproveNotification($notiData));
                                }


                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new BudgetApproveNotification($notiData));
                                }
                            }
                        }
                    }
                    $message = 'Budget status updated';
                    break;

                case 'term_and_conditions':
                    $data = $this->assetService->updateTncStatus($request->only('is_active'), $id);
                    $message = 'Terms & Condition status updated';
                    break;

                case 'locations':
                    $data = $this->assetService->updateLocationStatus($request->only('is_active'), $id);
                    $message = 'Location status updated';
                    break;

                case 'purchase_orders':
                    $status = (int) $request->is_active;
                    $level = (int) $request->level;
                    $purchaseOrder = $this->assetService->findPurchaseOrderById($id);
                    $approvalLevels = PurchaseOrderApproval::where('purchase_order_id', $purchaseOrder->id)->where('level', '<>', $level)->get();
                    $fullname = Auth::user()->first_name . " " . Auth::user()->last_name;
                    if ($status == 1) {
                        $currentData = [
                            'purchase_order_id' => $id,
                            'level' => $level,
                            'status' => $status,
                            'comments' => $request->comments ?? null
                        ];
                        //dd($currentData);
                        $isApprovalUpdated = $this->assetService->createOrUpdatePoApproval($currentData);
                        if ($isApprovalUpdated) {
                            $checkPoApproval = $this->assetService->checkPoApproval($id, null, ($level + 1));
                            $data = false;
                            if ($checkPoApproval) {
                                $nextData = [
                                    'purchase_order_id' => $id,
                                    'level' => ($level + 1),
                                    'status' => 0
                                ];
                                $isApprovalUpdatedNext = $this->assetService->createOrUpdatePoApproval($nextData);
                                if ($isApprovalUpdatedNext) {
                                    $data = $this->assetService->updatePoStatus(['status' => 5], $id);
                                }
                            } else {
                                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                    'task_name' => 'PO Approval',
                                    'task_description' => $purchaseOrder->unique_id,
                                    'task_url' => 'modules/purchase-order/view/' . $purchaseOrder->uuid,
                                    'added_by' => auth()->user()->id,
                                    'type' => 'approve-purchase-order',
                                    'related_id' => $purchaseOrder->id
                                ]);
                                $data = $this->assetService->updatePoStatus(['status' => $status], $id);
                            }

                            if ($data) {
                                $addUserData = $this->userService->findUserById($purchaseOrder->added_by);
                                $creatUserData = $this->userService->findUserById($purchaseOrder->created_by);
                                $notiData = [
                                    'form_name' => "#" . $purchaseOrder->unique_id . " this PO has been approved by " . $fullname,
                                    'po_uuid' => $purchaseOrder->uuid,
                                ];
                                $addUserData->notify(new PoApproveNotification($notiData));
                                $creatUserData->notify(new PoApproveNotification($notiData));
                                if ($checkPoApproval) {
                                    $nextLevelUser = $this->userService->findUserById($checkPoApproval->user_id);
                                    $nextLevelUserFullname = $nextLevelUser->first_name . " " . $nextLevelUser->last_name;
                                    $notifyData = [
                                        'form_name' => $nextLevelUserFullname . " got a PO approval request for PO ID #" . $purchaseOrder->unique_id,
                                        'po_uuid' => $purchaseOrder->uuid,
                                    ];
                                    $addUserData->notify(new PoApproveNotification($notifyData));
                                    $creatUserData->notify(new PoApproveNotification($notifyData));
                                }
                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new PoApproveNotification($notiData));

                                    /***** Next level notification *****/
                                    if ($checkPoApproval) {
                                        if ($approvallevel->level == ($level + 1)) {
                                            $notiData = [
                                                'form_name' => "You got a Purchase Order approval request for the ID #" . $purchaseOrder->unique_id,
                                                'po_uuid' => $purchaseOrder->uuid,
                                            ];
                                            $userData->notify(new PoApproveNotification($notiData));

                                            $requestparam = (object) [
                                                'title' => "Purchase Order approval request",
                                                'body' => "You got a Purchase Order approval request for the ID #" . $purchaseOrder->unique_id,
                                            ];
                                            $this->sendPushNotification($userData->id, $requestparam);
                                        } else {
                                            $userData->notify(new PoApproveNotification($notifyData));
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        $currentData = [
                            'purchase_order_id' => $id,
                            'level' => $level,
                            'status' => 2,
                            'comments' => $request->comments
                        ];
                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'PO Rejection',
                            'task_description' => $purchaseOrder->unique_id,
                            'task_url' => 'modules/purchase-order/view/' . $purchaseOrder->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'reject-purchase-order',
                            'related_id' => $purchaseOrder->id
                        ]);
                        $isApprovalUpdated = $this->assetService->createOrUpdatePoApproval($currentData);
                        if ($isApprovalUpdated) {
                            $data = $this->assetService->updatePoStatus(['status' => $status], $id);
                            if ($data) {
                                // $budgetData = $this->assetService->findPurchaseOrderById($purchaseOrder->id);
                                $notiData = [
                                    'form_name' => "#" . $purchaseOrder->unique_id . " this PO has been rejected by " . $fullname,
                                    'po_uuid' => $purchaseOrder->uuid,
                                ];

                                $creatUserData = $this->userService->findUserById($purchaseOrder->created_by);
                                $creatUserData->notify(new PoApproveNotification($notiData));
                                if ($purchaseOrder->created_by != $purchaseOrder->added_by) {
                                    $addUserData = $this->userService->findUserById($purchaseOrder->added_by);
                                    $addUserData->notify(new PoApproveNotification($notiData));
                                }


                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new PoApproveNotification($notiData));
                                }
                            }
                        }
                    }
                    $message = 'PO status updated';
                    break;



                case 'purchase_order_invoices':

                    $status = (int) $request->is_active;
                    $level = (int) $request->level;
                    $invoice = $this->assetService->findInvoiceById($id);
                    $approvalLevels = PoInvoiceApproval::where('po_invoice_id', $invoice->id)->where('level', '<>', $level)->get();
                    $fullname = Auth::user()->first_name . " " . Auth::user()->last_name;


                    // dd($request->all());

                    if ($status == 1) {


                        $currentData = [
                            'po_invoice_id' => $id,
                            'level' => $level,
                            'status' => $status,
                            'comments' => $request->comments ?? null
                        ];

                        // dd($currentData);

                        $isApprovalUpdated = $this->assetService->createOrUpdateInvoiceApproval($currentData);
                        // $isApprovalUpdated = $this->assetService->createOrUpdateInvoiceApprovalLatestOrder($currentData);

                        // dd($isApprovalUpdated);

                        if ($isApprovalUpdated) {

                            $checkPoInvoiceApproval = $this->assetService->checkPoInvoiceApproval($id, null, ($level + 1));

                            // dd($checkPoInvoiceApproval);

                            $data = false;

                            if ($checkPoInvoiceApproval) {

                                $nextData = [
                                    'po_invoice_id' => $id,
                                    'level' => ($level + 1),
                                    'status' => 0
                                ];
                                $isApprovalUpdatedNext = $this->assetService->createOrUpdateInvoiceApproval($nextData);
                                if ($isApprovalUpdatedNext) {
                                    $data = $this->assetService->updateInvoiceStatus(['status' => 5], $id);
                                }
                            } else {


                                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                    'task_name' => 'Invoice Approval',
                                    'task_description' => $invoice->unique_id,
                                    'task_url' => 'modules/invoice/view/' . $invoice->uuid,
                                    'added_by' => auth()->user()->id,
                                    'type' => 'approve-invoice',
                                    'related_id' => $invoice->id
                                ]);


                                $data = $this->assetService->updateInvoiceStatus(['status' => $status], $id);
                            }

                            if ($data) {

                                $creatUserData = $this->userService->findUserById($invoice->created_by);
                                $notiData = [
                                    'form_name' => "#" . $invoice->unique_id . " this PO Invoice has been approved by " . $fullname,
                                    'po_invoice_uuid' => $invoice->uuid,
                                    'po_uuid' => $invoice->purchaseOrder->uuid,
                                ];
                                $creatUserData->notify(new PoInvoiceApproveNotification($notiData));
                                if ($checkPoInvoiceApproval) {
                                    $nextLevelUser = $this->userService->findUserById($checkPoInvoiceApproval->user_id);
                                    $nextLevelUserFullname = $nextLevelUser->first_name . " " . $nextLevelUser->last_name;
                                    $notifyData = [
                                        'form_name' => $nextLevelUserFullname . " got a PO Invoice approval request for PO Invoice ID #" . $invoice->unique_id,
                                        'po_invoice_uuid' => $invoice->uuid,
                                        'po_uuid' => $invoice->purchaseOrder->uuid,
                                    ];
                                    $creatUserData->notify(new PoInvoiceApproveNotification($notifyData));
                                }
                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new PoInvoiceApproveNotification($notiData));

                                    /***** Next level notification *****/
                                    if ($checkPoInvoiceApproval) {
                                        if ($approvallevel->level == ($level + 1)) {
                                            $notiData = [
                                                'form_name' => "You got a PO Invoice approval request for the ID #" . $invoice->unique_id,
                                                'po_invoice_uuid' => $invoice->uuid,
                                                'po_uuid' => $invoice->purchaseOrder->uuid,
                                            ];
                                            $userData->notify(new PoInvoiceApproveNotification($notiData));

                                            $requestparam = (object) [
                                                'title' => "PO Invoice approval request",
                                                'body' => "You got a PO Invoice approval request for the ID #" . $invoice->unique_id,
                                            ];
                                            $this->sendPushNotification($userData->id, $requestparam);
                                        } else {
                                            $userData->notify(new PoInvoiceApproveNotification($notifyData));
                                        }
                                    }
                                }
                            }
                        }
                    } else {


                        $currentData = [
                            'po_invoice_id' => $id,
                            'level' => $level,
                            'status' => 2,
                            'comments' => $request->comments
                        ];


                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'Invoice Rejection',
                            'task_description' => $invoice->unique_id,
                            'task_url' => 'modules/invoice/view/' . $invoice->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'reject-invoice',
                            'related_id' => $invoice->id
                        ]);

                        //start  code for creating new version
                        $invoiceData = $this->assetService->findInvoiceById($invoice->id);
                        $isApprovalUpdated = $this->assetService->createInvoiceVersion($invoiceData, $currentData);
                        $request->merge(['status' => null]);

                        $data = $this->assetService->addOrUpdateInvoice(['uuid' => $invoiceData->uuid], $request->except('_token'));

                        //end  code for creating new version



                        //dd($currentData);
                        // isApprovalUpdated= $this->assetService->createOrUpdateInvoiceApproval($currentData);
                        // $isApprovalUpdated = $this->assetService->createOrUpdateInvoiceApprovalLatestOrder($currentData);

                        // dd($isApprovalUpdated);

                        if ($isApprovalUpdated) {

                            // $data = $this->assetService->updateInvoiceStatus(['status' => $status], $id); //// previously this status is used
                            // dd($data);

                            if ($data) {
                                $notiData = [
                                    'form_name' => "#" . $invoice->unique_id . " this PO Invoice has been rejected by " . $fullname,
                                    'po_invoice_uuid' => $invoice->uuid,
                                    'po_uuid' => $invoice->purchaseOrder->uuid,
                                ];

                                $creatUserData = $this->userService->findUserById($invoice->created_by);
                                $creatUserData->notify(new PoInvoiceApproveNotification($notiData));

                                foreach ($approvalLevels as $approvallevel) {
                                    $userData = $this->userService->findUserById($approvallevel->user_id);
                                    $userData->notify(new PoInvoiceApproveNotification($notiData));
                                }
                            }
                        }
                    }
                    $message = 'PO status updated';
                    break;




                case 'asset_maintenances':
                    // code for special case multi disposed //
                    if ($request->is_active == "3") {
                        $data = $this->assetStockService->updateMaintenanceStatus(['status' => 1], $id);
                        $itemStatus = '2';
                    } else {
                        $data = $this->assetStockService->updateMaintenanceStatus(['status' => $request->is_active], $id);
                        $itemStatus = ($request->is_active == '2') ? '3' : '1';
                    }
                    $maintenanceData = $this->assetStockService->findMaintenanceById($id);
                    $totalItemsNotCompleted = $maintenanceData->maintenanceItems->where('asset_maintenance_id', $id)->where('status', '0');
                    if ($totalItemsNotCompleted->count()) {

                        foreach ($totalItemsNotCompleted as $itemNotCompleted) {
                            $isItemUpdated = $this->assetStockService->updateMaintenanceItemStatus(['status' => $itemStatus], $itemNotCompleted->id);
                            if ($isItemUpdated) {
                                $this->assetService->addOrUpdateInventory(['id' => $itemNotCompleted->inventory_id], ['under_maintenance' => '0']);
                                $inventory = $this->assetStockService->getInventoryById($itemNotCompleted->inventory_id);
                                if (!$inventory->issue) {
                                    $filterConditions = ['id' => $maintenanceData->asset_stock_id];
                                    $isUpdated = $this->assetStockService->alterStockTable($filterConditions, 1, 'increase');
                                    if ($isUpdated) {
                                        $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                                        $logData = [
                                            'asset_stock_id' => $assetStockData->id,
                                            'asset_id' => $assetStockData->asset_id,
                                            'location_id' => $assetStockData->location_id,
                                            'type' => 'add',
                                            'quantity' => 1
                                        ];
                                        $this->assetStockService->addAssetStockLog($logData);
                                    }
                                }

                                $approveOrReject = ($request->is_active == "1")
                                    ? ["task_name" => "A Maintenance has been Completed", "task_description" => $maintenanceData->unique_id]
                                    : ["task_name" => "A Maintenance has been Cancelled", "task_description" => $maintenanceData->unique_id];

                                $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                    'task_name' => $approveOrReject['task_name'],
                                    'task_description' => $approveOrReject['task_description'],
                                    'task_url' => 'modules/maintenance/view/' . $maintenanceData->uuid,
                                    'added_by' => auth()->user()->id,
                                    'type' => 'status-maintenance',
                                    'related_id' => $maintenanceData->id,
                                    'inventory_id' => $itemNotCompleted->inventory_id
                                ]);
                            }
                        }
                    }


                    $message = 'Asset maintenance status updated';
                    break;
                case 'maintenance_items':
                    // dd($request->all());
                    $maintenanceItem = $this->assetStockService->findMaintenanceItemById($id);
                    $data = $this->assetStockService->updateMaintenanceItemStatus(['status' => $request->is_active, 'repaired_comments' => $request->repaired_comments], $id);
                    switch ($request->is_active) {
                        case '1':
                            $underMaintenanceStatus = '0';
                            break;
                        case '2':
                            $underMaintenanceStatus = '2';
                            break;
                        default:
                            $underMaintenanceStatus = '1';
                            break;
                    }
                    $this->assetService->addOrUpdateInventory(['id' => $maintenanceItem->inventory_id], ['under_maintenance' => $underMaintenanceStatus]);
                    if ($data && $request->is_active != '0') {
                        $filterConditions = ['id' => $maintenanceItem->maintenance->asset_stock_id];
                        if ($request->is_active == '1') {
                            $inventory = $this->assetStockService->getInventoryById($maintenanceItem->inventory_id);
                            if (!$inventory->issue) {
                                $isUpdated = $this->assetStockService->alterStockTable($filterConditions, 1, 'increase');
                                if ($isUpdated) {
                                    $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                                    // dd($assetStockData);
                                    $logData = [
                                        'asset_stock_id' => $assetStockData->id,
                                        'asset_id' => $assetStockData->asset_id,
                                        'location_id' => $assetStockData->location_id,
                                        'type' => 'add',
                                        'quantity' => 1
                                    ];
                                    $this->assetStockService->addAssetStockLog($logData);
                                }
                            }
                        }
                        $asset_stock = $this->assetStockService->findById($maintenanceItem->maintenance->asset_stock_id);
                        $approveOrReject = ($request->is_active == "1")
                            ? ["task_name" => "An Asset has been Repaired", "task_description" => $maintenanceItem->maintenance->unique_id,]
                            : ["task_name" => "An Asset has been Disposed", "task_description" => $maintenanceItem->maintenance->unique_id,];

                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => $approveOrReject['task_name'],
                            'task_description' => $approveOrReject['task_description'],
                            'task_url' => 'modules/maintenance/view/' . $maintenanceItem->maintenance?->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'status-maintenance',
                            'related_id' => $maintenanceItem->asset_maintenance_id,
                            'inventory_id' => $maintenanceItem->inventory_id
                        ]);
                        $totalIncompleteItems = $maintenanceItem->maintenance->maintenanceItems->where('status', '0')->count();
                        if (!$totalIncompleteItems) {
                            $this->assetStockService->updateMaintenanceStatus(['status' => '1'], $maintenanceItem->maintenance->id);
                        }
                    }
                    $message = 'Asset Item status updated';
                    break;
                case 'asset_issues':
                    $data = $this->assetStockService->addOrUpdateAssetIssue(['id' => $id], ['is_surrender' => $request->is_active, 'surrender_letter' => $request->surrender_letter, 'picture' => $request->picture, 'surrender_comments' => $request->surrender_comments]);

                    $issuedItem = $this->assetStockService->findAssetIssueById($id);
                    if ($data && $request->is_active == '1') {
                        $filterConditions = ['id' => $issuedItem->asset_stock_id];
                        $isUpdated = $this->assetStockService->alterStockTable($filterConditions, 1, 'increase');
                        if ($isUpdated) {
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                            $logData = [
                                'asset_stock_id' => $assetStockData->id,
                                'asset_id' => $assetStockData->asset_id,
                                'location_id' => $assetStockData->location_id,
                                'type' => 'add',
                                'quantity' => 1
                            ];
                            $this->assetStockService->addAssetStockLog($logData);
                        }
                        $assetData = $this->assetService->findById($issuedItem->asset_id);
                        $asset_stock = $this->assetStockService->findById($issuedItem->asset_stock_id);
                        $request->merge(['asset_issue_id' => $issuedItem->id]);
                        $isPhysicallyVerified = $this->assetStockService->addOrUpdateAssetSurrender(['uuid' => null], $request->except('_token'));

                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => 'An Asset has been Surrendered',
                            'task_description' => $assetData->asset_name . '(' . $assetData->asset_id . ')',
                            'task_url' => 'modules/assetstock/issued/list/' . $asset_stock->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'add-surrender',
                            'related_id' => $isPhysicallyVerified->id,
                            'inventory_id' => $issuedItem->inventory_id
                        ]);

                        $user = $this->userService->findUserById($issuedItem->user_id);
                        $receiverMailLists = ['super.admin@dhc.com,', $user->email];
                        $findLocation = Location::find($issuedItem->location_id);
                        $mailData = [
                            'to' => $receiverMailLists,
                            'from' => env('MAIL_FROM_ADDRESS'),
                            'mail_type' => 'general',
                            'line' => 'We have received a request for surrendering the following asset in the system. Please review the details below and confirm if this information is correct:<br><br><br>Asset Details:',
                            'content' => 'Asset Name: ' . $assetData->asset_name . '<br>Asset ID: #' . $assetData->asset_id . '<br>Surrender Date: ' . Carbon::now()->format('Y-m-d') . '<br>Location:: ' . $findLocation->street_address . '',
                            'subject' => 'Confirmation of Asset Surrender - ' . $assetData->asset_name,
                            'greetings' => 'Dear ' . $user->full_name . ',',
                            'end_greetings' => 'Best Regards,<br>DHC',
                            'from_user' => env('MAIL_FROM_NAME')
                        ];
                        Mail::send(new SendMailable($mailData));
                    }


                    //$deptAdmin=$this->assetService->findDepartmentByName('HR');

                    $message = 'Asset Issued Item status updated';
                    break;
                case 'lease_items':

                    if ($request->is_active == '0')
                        $data = $this->assetStockService->addOrUpdateLeaseItems(['id' => $id], ['is_completed' => $request->is_active, 'user_id' => null, 'leased_date' => null, 'comments' => null]);

                    else
                        $data = $this->assetStockService->addOrUpdateLeaseItems(['id' => $id], ['is_completed' => $request->is_active]);

                    $leasedItem = $this->assetStockService->findLeasedItemById($id);


                    if ($data && $request->is_active == '1') {
                        $filterConditions = ['id' => $leasedItem->leaseAgreement->asset_stock_id];
                        $isUpdated = $this->assetStockService->alterStockTable($filterConditions, 1, 'increase');
                        if ($isUpdated) {
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                            $logData = [
                                'asset_stock_id' => $assetStockData->id,
                                'asset_id' => $assetStockData->asset_id,
                                'location_id' => $assetStockData->location_id,
                                'type' => 'add',
                                'quantity' => 1
                            ];
                            $this->assetStockService->addAssetStockLog($logData);
                        }
                        $assetStockData = $this->assetStockService->findById($leasedItem->leaseAgreement->asset_stock_id);
                        $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                            'task_name' => "A Lease has been Completed",
                            'task_description' => $leasedItem->leaseAgreement->unique_id,
                            'task_url' => 'modules/lease/view/' . $leasedItem->leaseAgreement?->uuid,
                            'added_by' => auth()->user()->id,
                            'type' => 'complete-lease',
                            'related_id' => $leasedItem->lease_id,
                            'inventory_id' => $leasedItem->inventory_id
                        ]);
                    }
                    $message = 'Asset Leased Item status updated';
                    break;
                case 'tickets':
                    $completed_at = now();
                    $status = $request->is_active;
                    $activityId = $request->activity;
                    $data = $this->ticketService->addOrUpdateTicket(['id' => $id], ['status' => $status, 'completed_at' => $completed_at]);
                    if ($data) {
                        $ticket = $this->ticketService->findTicketById($id);
                        $activityMessage = '';
                        $notiMessage = '';
                        switch ($status) {
                            case '-1':
                                $activityMessage = 'A request has been sent to close this ticket.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been requested for close.";
                                $type = '6';
                                break;
                            case '0':
                                $activityMessage = 'Closing request accepted. Ticket has been closed.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been closed.";
                                $type = '7';
                                break;
                            case '1':
                                $activityMessage = 'Closing request denied. Ticket remains open.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket remains open.";
                                $type = '10';
                                break;
                            case '2':
                                $activityMessage = 'Ticket cancelled.';
                                $notiMessage = "#" . $ticket->unique_id . " This ticket has been cancelled.";
                                $type = '8';
                                break;
                        }
                        $isClosedActivityCreated = $this->ticketService->addTicketActivity([
                            'ticket_id' => $ticket->id,
                            'message' => $activityMessage,
                            'type' => $type,
                            'user_id' => auth()->user()->id,
                            'created_at' => $completed_at,
                        ]);
                        if ($isClosedActivityCreated) {
                            if ($activityId) {
                                $this->ticketService->updateTicketActivity([
                                    'is_updated' => 1
                                ], $activityId);
                            }
                            $notiData = [
                                'form_name' => $notiMessage,
                                'ticket_uuid' => $ticket->uuid,
                            ];
                            $ticketRaisedUser = $ticket->activity(0)->user;
                            $ticketRaisedUser->notify(new TicketNotification($notiData));

                            // $mailData = [
                            //     'to' => $ticketRaisedUser->email,
                            //     'from' => env('MAIL_FROM_ADDRESS'),
                            //     'mail_type' => 'general',
                            //     'line' => $notiMessage,
                            //     'content' => '',
                            //     'subject' => $activityMessage,
                            //     'greetings' => 'Dear ' . $ticketRaisedUser->full_name . ',',
                            //     'end_greetings' => 'Regards,',
                            //     'from_user' => env('MAIL_FROM_NAME')
                            // ];

                            $entityDepartmentSetting = EntityDepartmentSetting::where(['entity_id' => $ticket->entity_id, 'department_id' => $ticket->department_id])->first();
                            $mailData = [
                                'to' => $ticketRaisedUser->email,
                                'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                                'mail_type' => 'general',
                                'line' => $notiMessage,
                                'content' => '',
                                'subject' => $activityMessage,
                                'greetings' => 'Dear ' . $ticketRaisedUser->full_name . ',',
                                'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                                'from_user' =>  $entityDepartmentSetting?->from_name
                            ];
                            Mail::send(new SendMailable($mailData));
                            if ($status == '1') {

                                $notiData = [
                                    'form_name' => $notiMessage,
                                    'ticket_uuid' => $ticket->uuid,
                                ];
                                $ticketLatestAssigneeUser = $ticket->latestAssignee([1, 2, 3])?->user;

                                $ticketLatestAssigneeUser->notify(new TicketNotification($notiData));
                                // dd($ticketLatestAssigneeUser);
                                // $mailData = [
                                //     'to' => $ticketLatestAssigneeUser->email,
                                //     'from' => env('MAIL_FROM_ADDRESS'),
                                //     'mail_type' => 'general',
                                //     'line' => $notiMessage,
                                //     'content' => '',
                                //     'subject' => $activityMessage,
                                //     'greetings' => 'Dear ' . $ticketLatestAssigneeUser->full_name . ',',
                                //     'end_greetings' => 'Regards,',
                                //     'from_user' => env('MAIL_FROM_NAME')
                                // ];

                                $mailData = [
                                    'to' => $ticketLatestAssigneeUser->email,
                                    'from' => $entityDepartmentSetting->from_email ?? env('MAIL_FROM_ADDRESS'),
                                    'mail_type' => 'general',
                                    'line' => $notiMessage,
                                    'content' => '',
                                    'subject' => $activityMessage,
                                    'greetings' => 'Dear ' . $ticketLatestAssigneeUser->full_name . ',',
                                    'end_greetings' => 'Best Regards,<br>' . $entityDepartmentSetting?->from_name . '<br>' . $entityDepartmentSetting?->phone_number . '<br>' . $entityDepartmentSetting?->entity?->name,
                                    'from_user' =>  $entityDepartmentSetting?->from_name
                                ];
                                Mail::send(new SendMailable($mailData));
                            }
                        }
                    }
                    $message = 'Ticket status updated';
                    break;
                case 'ticket_categories':
                    $data = $this->ticketService->updateTicketCategoryStatus($request->only('is_active'), $id);
                    $message = 'Ticket Category status updated';
                    break;
                default:
                    return $this->responseJson(false, 200, 'Something Wrong Happened');
            }

            if ($data) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function deleteData(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            switch ($table) {
                case 'categories':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->categoryService->deleteCategory($id);
                    $message = 'Category Deleted';
                    break;

                case 'asset_types':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetTypeService->deleteType($id);
                    $message = 'Asset Type Deleted';
                    break;

                case 'assets':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteAsset($id);
                    $message = 'Asset Deleted';
                    break;

                case 'users':
                    $isDepartmentAdmin = Department::where('department_manager', uuidtoid($request->uuid, $table))->get();
                    $id = uuidtoid($request->uuid, $table);
                    $isUserBelongstoConcernPersons = Department::whereJsonContains('concerned_persons', (string)$id)->get();
                    if ((isset($isDepartmentAdmin) && $isDepartmentAdmin->isNotEmpty()) || (isset($isUserBelongstoConcernPersons) && $isUserBelongstoConcernPersons->isNotEmpty()))
                        $message = 'This user is admin or concern person of a dept';
                    else {
                        $data = $this->userService->deleteUser($request->except('find'));
                        $message = 'User Deleted';
                    }
                    break;

                case 'vendors':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->vendorService->deleteVendor($id);
                    $message = 'Vendor Deleted';
                    break;

                case 'asset_stocks':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetStockService->deleteAssetStock($id);
                    $message = 'Asset Stock Deleted';
                    break;

                case 'inward_stocks':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->inwardStockService->deleteInWardStock($id);
                    $message = 'Inward Stock Deleted';
                    break;

                case 'outward_stocks':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->outwardStockService->deleteOutWardStock($id);
                    $message = 'Outward Stock Deleted';
                    break;
                case 'requisitions':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteRequisition($id);
                    $message = 'Requisition Deleted';
                    break;
                case 'requisition_assets':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteRequisitionItem($id);
                    $message = 'Requisition Item Deleted';
                    break;
                case 'budget_items':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteBudgetItem($id);
                    $message = 'Budget Item Deleted';
                    break;
                case 'budget_notes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteBudgetNote($id);
                    $message = 'Budget Note Deleted';
                    break;
                case 'documents':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteBudgetDocument($id);
                    $message = 'Document Deleted';
                    break;

                case 'locations':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteLocation($id);
                    $message = 'Location Deleted';
                    break;


                case 'rfqs':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteRfq($id);
                    $message = 'RFQ Deleted';
                    break;

                case 'budgets':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteBudget($id);
                    $message = 'Budget Deleted';
                    break;

                case 'term_and_conditions':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteTermAndCondition($id);
                    $message = 'Terms & condition Deleted';
                    break;

                case 'purchase_orders':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deletePo($id);
                    $message = 'Purchase Order Deleted';
                    break;
                case 'asset_receipt_notes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteAssetReceiptNote($id);
                    $message = 'ARN Deleted';
                    break;
                case 'departments':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteDepartment($id);
                    $message = 'Department Deleted';
                    break;
                case 'purchase_order_invoices':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteInvoice($id);
                    $message = 'Invoice Deleted';
                    break;
                case 'inventories':
                    $id = uuidtoid($request->uuid, $table);
                    $inventoryData = $this->assetService->findInventoryById($id);
                    $data = $this->assetService->deleteInventory($id);
                    if ($inventoryData) {
                        $assetStockData = $this->assetService->findAssetStockById($inventoryData->asset_stock_id);
                        $this->assetStockService->alterStockTable(['id' => $inventoryData->asset_stock_id], 1, 'decrease');
                        if ($assetStockData) {
                            $this->assetService->alterArnItemRemainingQuantity(['asset_receipt_note_id' => $assetStockData->asset_receipt_note_id, 'asset_id' => $assetStockData->asset_id], 1, 'increase');
                        }
                    }
                    $message = 'Inventory Deleted';
                    break;
                case 'modules':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->rolePermissionService->deleteModule($id);
                    $this->rolePermissionService->listPermissions(['module_id' => $id])->each->forceDelete();
                    $message = 'Module Deleted';
                    break;
                case 'asset_verifications':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetStockService->deleteAssetVerifications($id);
                    $message = 'Verified Asset Deleted';
                    break;
                case 'verified_assets':
                    $id = $request->uuid;
                    $data = $this->assetStockService->deleteVerifiedAsset($id);
                    $message = 'Verified Asset Deleted';
                    break;
                case 'attributes':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->assetService->deleteAttribute($id);
                    $message = 'Attribute Deleted';
                    break;
                case 'roles':
                    $data = $this->rolePermissionService->deleteRole($request->uuid);
                    $message = 'Role Deleted';
                    break;
                case 'tickets':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->ticketService->deleteTicket($id);
                    $message = 'Ticket Deleted';
                    break;
                case 'ticket_categories':
                    $id = uuidtoid($request->uuid, $table);
                    $data = $this->ticketService->deleteTicketCategory($id);
                    $message = 'Ticket Category Deleted';
                    break;
                case 'ticket_settings':
                    $id = $request->uuid;
                    $data = $this->ticketService->deleteTicketSettings($id);
                    $message = 'Settings Deleted';
                    break;
            }
            // if (isset($data)) {
            //     return $this->responseJson(true, 200, $message);
            // } else {
            //     return $this->responseJson(false, 500, 'Something Wrong Happened');
            // }



            if (isset($data)) {
                return $this->responseJson(true, 200, $message);
            } elseif ((isset($isDepartmentAdmin) && $isDepartmentAdmin->isNotEmpty()) || (isset($isUserBelongstoConcernPersons) && $isUserBelongstoConcernPersons->isNotEmpty())) {
                return $this->responseJson(false, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        } else {
            abort(405);
        }
    }
    public function updateToken(Request $request)
    {
        DB::beginTransaction();
        try {
            //dd($request->token);
            $isUserUpdated = auth()->user()->update(['fcm_token' => $request->token]);
            if ($isUserUpdated) {
                DB::commit();
                return $this->responseJson(true, 200, [
                    'success' => true
                ]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->responseJson(false, 500, [
                'success' => false
            ]);
        }
    }
    public function getSingleRow(Request $request, $type)
    {
        switch (true) {
            case ($type == 'brand'):
                $data = $this->categoryService->findCategoryById(uuidtoid($request->uuid, $request->find));
                if ($data->isNotEmpty()) {
                    return $this->responseJson(true, 200, 'Brand Fetched.', $data);
                }
                return $this->responseJson(false, 500, 'Something went wrong!', "");
                break;

            default:
                abort(404);
                break;
        }
    }
    public function getEmployees(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $role = '';
                $search = $request->filterData;
                $totalData = $this->userService->getTotalUsers($role, $status);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'name';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $users = $this->userService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false);
                } else {
                    $users = $this->userService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->userService->getTotalUsers($role, $status, $search);
                }
                // dd($users);

                if ($users) {
                    foreach ($users as $key => $user) {
                        $index++;
                        $nestedData['id'] = $index;
                        // $nestedData['image'] = '<div class="img_box userimg">
                        //     <img src="' . $user->profile_picture . '" alt="' . $user->full_name . '" class="img-fluid" alt="">
                        // </div>';


                        $nestedData['image'] = '<div class="img_box userimg">
                        <img src="' . $user->profile_picture . '" alt="' . $user->full_name . '" class="img-fluid" alt="">
                    </div>';

                        $nestedData['unique_id'] = '<a href="' . route('admin.employee.view', $user->uuid) . '">' . $user->unique_id . '</a>';
                        $nestedData['name'] = $user->full_name;
                        $nestedData['mobile_number'] = $user->mobile_number;
                        $nestedData['email'] = '<a href="mailto:' . $user->email . '">' . $user->email . '</a>';
                        $nestedData['designation'] = $user->profile->designation?->name ?? '';
                        $nestedData['role'] = $user->roles?->first()?->name;
                        $nestedData['department'] = $user->profile->department?->name ?? '';
                        // $nestedData['level'] = $user->level ? 'Level ' . $user->level : '';
                        $nestedData['doj'] = Carbon::parse($user->profile?->date_of_joining)->format('dS M, Y') ?? '';
                        $nestedData['entity'] = $user->profile?->entity?->name ?? '';

                        $nestedData['status'] = '';
                        if (auth()->user()->canAny(['status-employee'])) {
                            $nestedData['status'] = '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($user->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($user->is_active == '1') ? 'Active' : 'Inactive') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="users" data-uuid="' . $user->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="users" data-uuid="' . $user->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>';
                        }
                        $availability = $user->is_available ? '<span class="text-success">Available</span>' : '<span class="text-danger">Unavailable</span>';
                        if (auth()->user()->hasRole('super-admin') || (auth()->user()->id == $user->id)) {
                            $availability = '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($user->is_available == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($user->is_available == '1') ? 'Available' : 'Unavailable') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green ' . (($user->is_available == '1') ? 'disabled' : '') . '" onclick="availabilityChange(this)" href="javascript:void(0)" data-table="users" data-uuid="' . $user->uuid . '" data-available="1" ><span><i class="fa-solid fa-circle"></i></span>Available</a></li>
                                        <li><a class="dropdown-item text_danger ' . (($user->is_available == '0') ? 'disabled' : '') . '" onclick="availabilityChange(this)" href="javascript:void(0)" data-table="users" data-uuid="' . $user->uuid . '" data-available="0" ><span><i class="fa-solid fa-circle"></i></span>Unavailable</a></li>
                                    </ul>
                                </div>
                            </div>';
                        }
                        $nestedData['is_available'] = $availability;
                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if (auth()->user()->canAny(['edit-employee'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.employee.edit', $user->uuid) . '" class="edit_icon" title="Edit"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }
                        if (auth()->user()->canAny(['delete-employee'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger userDeleteData" data-table="users" data-uuid="' . $user->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        /*if (auth()->user()->canAny(['attach-employee', 'detach-employee'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.employee.attach.permission', $user->uuid) . '" class="flex items-center text-dark" title="Permissions"><span class="icon"><i class="fas fa-paperclip"></i></span><span class="text"></span></a>';
                        }*/
                        if (auth()->user()->canAny(['edit-employee'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.employee.update-password', $user->uuid) . '" class="edit_icon" title="Update Password"><i class="fa fa-key" aria-hidden="true"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getVendors(Request $request, $role = 'vendor')
    {
        if ($request->ajax()) {
            try {
                //dd(if:$request->stateId);
                if ($request->stateId) {
                    //$data = Vendor::where('state_id',4853)->get();
                    $data = $this->vendorService->findUserByRole(['state_id' => $request->stateId], 'vendor',);
                    return $this->responseJson(true, 200, 'data fetched', $data);
                } else {
                    $filterCondition = [];
                    $status = 'all';
                    $role = 'vendor';
                    $search = $request->filterData;
                    $totalData = $this->vendorService->getTotalUsers();
                    $totalFiltered = $totalData;
                    $limit = $request->input('length');
                    $start = $request->input('start');
                    $order = 'id';
                    $dir = 'desc';

                    if (isset($request->order) && is_array($request->order)) {
                        $order = $request->order[0]['name'];
                        $dir = $request->order[0]['dir'];
                    }

                    $index = $start;
                    $nestedData = [];
                    $data = [];
                    if (!$search) {
                        $users = $this->vendorService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false);
                    } else {
                        $users = $this->vendorService->findUserByRole($filterCondition, $role, $order, $dir, $limit, $index, false, $search);
                        $totalFiltered = $this->vendorService->getTotalUsers($search);
                    }
                    if ($users) {
                        foreach ($users as $key => $user) {
                            $index++;
                            $nestedData['id'] = $index;
                            $nestedData['vendor_id'] = 'VDR' . str_pad($user->id, 6, 0, STR_PAD_LEFT);
                            $nestedData['name'] = $user->full_name;
                            $nestedData['mobile_number'] = $user->mobile_number;
                            $nestedData['email'] = '<a href="mailto:' . $user->email . '">' . $user->email . '</a>';
                            $nestedData['type'] = Str::title(str_replace('-', ' ', $user->type ?? 'N/A'));
                            $nestedData['company_name'] = $user->company_name;
                            $statusCode = ($user->is_active == 1) ? 0 : 1;
                            $statClass = ($user->is_active == 1) ? 'text_green' : 'text_danger';
                            $status = ($user->is_active == 1) ? 'Active' : 'Inactive';

                            $nestedData['is_active'] = '<div class="action_sec">';
                            if (auth()->user()->canAny(['status-vendor'])) {
                                $nestedData['is_active'] .= '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="vendors" data-uuid="' . $user->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="vendors" data-uuid="' . $user->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>';
                            }
                            $nestedData['is_active'] .= '</div>';
                            $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                            if (auth()->user()->canAny(['edit-vendor'])) {
                                $nestedData['action'] .= '<a href="' . route('admin.vendor.edit', $user->uuid) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>';
                            }
                            if (auth()->user()->canAny(['delete-vendor'])) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="vendors" data-uuid="' . $user->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                            }

                            $nestedData['action'] .= '</div></div>';

                            $data[] = $nestedData;
                            $nestedData = [];
                        }
                    }
                    $jsonData = array(
                        "draw" => (int) $request->input('draw'),
                        "recordsTotal" => (int) $totalData,
                        "recordsFiltered" => (int) $totalFiltered,
                        "data" => $data,
                    );

                    return response()->json($jsonData);
                }
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getCities($stateid)
    {

        $data = $this->cityService->getCityByState($stateid);
        //dd($data);
        return $this->responseJson(true, 200, 'data fetched', $data);
    }
    public function getAssets(Request $request)
    {
        if ($request->ajax()) {
            try {
                // dd($request->all());
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalAssets(null, $filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'asset_id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $assets = $this->assetService->findAssets($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assets = $this->assetService->findAssets($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalAssets($search, $filterCondition);
                }
                if ($assets) {
                    foreach ($assets as $key => $asset) {
                        $index++;
                        $issued_qty = 0;

                        $nestedData['id'] = $index;
                        $nestedData['image'] = '<div class="img_box userimg">
                            <img src="' . $asset->avatar . '" alt="' . $asset->asset_name . '" class="img-fluid" alt="">
                        </div>';

                        $nestedData['asset_id'] = $asset->asset_id;
                        //$nestedData['asset_id'] = '<a href="'.route('admin.asset.view', $asset->uuid).'">'.$asset->asset_id.'</a>';
                        $nestedData['asset_name'] = '<p>Asset Name/Model No: <strong>' . ucwords($asset->asset_name) . '</strong></p>';
                        $nestedData['asset_name'] .= '<p>Category: <strong>' . ucwords($asset->category?->name) . '</strong></p>';
                        $nestedData['asset_name'] .= '<p>Type: <strong>' . ucwords($asset->assettype?->name) . '</strong></p>';
                        // $nestedData['entity'] = ucwords($asset->assettype?->entity);


                        $nestedData['current_qty'] = $asset->assetStock?->sum('current_stock');


                        $leased_qty = 0;
                        $maintenance_qty = 0;
                        $disposed_qty = 0;
                        foreach ($asset?->assetStock as $val) {
                            $issued_qty += $val->assetIssue?->where('is_surrender', '0')->sum('quantity');
                            $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $val->id]);
                            if ($leased_agreements) {
                                foreach ($leased_agreements as $leased_agreement) {
                                    $leased_qty += $leased_agreement->leaseItems->where('is_completed', '0')->count();
                                }
                            }
                            $asset_maintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $val->id]);
                            if ($asset_maintenances) {
                                foreach ($asset_maintenances as $asset_maintenance) {
                                    $maintenance_qty += $asset_maintenance->maintenanceItems->where('status', '0')->count();
                                    $disposed_qty += $asset_maintenance->maintenanceItems->where('status', '2')->count();
                                }
                            }
                        }
                        $nestedData['issued_qty'] = $issued_qty;
                        $nestedData['leased_qty'] = $leased_qty;
                        $nestedData['maintenance_qty'] = $maintenance_qty;
                        $nestedData['disposed_qty'] = $disposed_qty;
                        $total_qty = $asset->assetStock?->sum('current_stock') + $issued_qty + $leased_qty + $maintenance_qty + $disposed_qty;
                        //$total_qty = 1;

                        $nestedData['total_qty'] = $total_qty ? '<a href="' . route('admin.assetstock.list', $asset->uuid) . '" class="edit_icon">' . $total_qty . '</a>' : $total_qty;



                        $statusCode = ($asset->is_active == 1) ? 0 : 1;
                        $statClass = ($asset->is_active == 1) ? 'text_green' : 'text_danger';
                        $status = ($asset->is_active == 1) ? 'Active' : 'Inactive';

                        // $nestedData['action'] = '<div class="action_sec">
                        //         <div class="status_box">
                        //             <div class="dropdown">
                        //                 <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                        //                 <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                        //                     <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="assets" data-uuid="' . $asset->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                        //                     <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="assets" data-uuid="' . $asset->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                        //                 </ul>
                        //             </div>
                        //         </div>

                        //     <div class="action_box">
                        //         <a href="' . route('admin.asset.edit', $asset->uuid) . '" class="edit_icon"><i
                        //                 class="fa-regular fa-pen-to-square"></i></a>
                        //         <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="assets" data-uuid="' . $asset->uuid . '"><i
                        //                 class="fa-solid fa-trash-can"></i></a>
                        //     </div>
                        // </div>';

                        $nestedData['is_active'] = '<div class="action_sec">';
                        if (auth()->user()->canAny(['status-asset'])) {
                            $nestedData['is_active'] .= '<div class="status_box">
                                    <div class="dropdown">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                            <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="assets" data-uuid="' . $asset->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                            <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="assets" data-uuid="' . $asset->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                        </ul>
                                    </div>
                                </div>';
                        }
                        $nestedData['is_active'] .= '</div>';
                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if (auth()->user()->canAny(['edit-asset'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.asset.edit', $asset->uuid) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-asset'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="assets" data-uuid="' . $asset->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }

                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getAssetStocks(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                if ($request->assetUuid) {
                    $filterCondition['asset_id'] = uuidtoid($request->assetUuid, 'assets');
                }
                $search = $request->filterData;
                $totalData = $this->assetStockService->getTotalAssetStock($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'unique_id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $assetStock = $this->assetStockService->findAssetStock($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assetStock = $this->assetStockService->findAssetStock($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetStockService->getTotalAssetStock($filterCondition, $search);
                }
                if ($assetStock) {
                    foreach ($assetStock as $key => $stock) {
                        // dd($stock->assetIssue->sum('quantity'));
                        $index++;
                        $nestedData['id'] = $index;
                        $nestedData['unique_id'] = $stock->unique_id;
                        $nestedData['location'] = $stock->location?->street_address;
                        $nestedData['entity'] = $stock->entity?->name;
                        $nestedData['current_stock'] = $stock->current_stock;
                        $issued_qty = $stock->assetIssue?->where('is_surrender', '0')->sum('quantity');
                        $nestedData['issued'] = $issued_qty ? '<a href="' . route('admin.assetstock.issued.list', $stock->uuid) . '" >' . $issued_qty . '</a>' : 0;
                        $leased_qty = 0;

                        $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);
                        if ($leased_agreements) {
                            foreach ($leased_agreements as $leased_agreement) {
                                $leased_qty += $leased_agreement->leaseItems->where('is_completed', '0')->count();
                            }
                        }

                        $maintenance_qty = 0;
                        $disposed_qty = 0;
                        $asset_maintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $stock->id]);
                        if ($asset_maintenances) {
                            foreach ($asset_maintenances as $asset_maintenance) {
                                $maintenance_qty += $asset_maintenance->maintenanceItems->where('status', '0')->count();
                                $disposed_qty += $asset_maintenance->maintenanceItems->where('status', '2')->count();
                            }
                        }
                        if ($stock->asset->has_unique_number) {
                            $nestedData['leased'] = $leased_qty ? '<a href="' . route('admin.assetstock.leased.list', $stock->uuid) . '" >' . $leased_qty . '</a>' : 0;

                            $nestedData['under_maintenance'] = $maintenance_qty ? '<a href="' . route('admin.assetstock.maintenance.list', $stock->uuid) . '" >' . $maintenance_qty . '</a>' : 0;

                            $nestedData['disposed'] = $disposed_qty ? '<a href="' . route('admin.assetstock.disposal.list', $stock->uuid) . '" >' . $disposed_qty . '</a>' : 0;
                        }

                        $nestedData['total_stock'] = $stock->current_stock + $issued_qty + $leased_qty + $maintenance_qty + $disposed_qty;

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        // $nestedData['action'] .= '<a href="' . route('admin.assetstock.inventory', $stock->uuid) . '" class="btn btn-blue btn-sm">View Inventory</a>';

                        $nestedData['action'] .= '<a href="' . route('admin.assetstock.inventory', ['uuid' => $stock->uuid, 'leaseUuid' => null]) . '" class="btn btn-blue btn-sm">View Inventory</a>';

                        if ($stock->asset->category->slug == 'non-consumable') {
                            if ($stock->current_stock > 0) {
                                if (auth()->user()->canAny(['add-lease'])) {
                                    $nestedData['action'] .= '<a href="' . route('admin.assetstock.lease', $stock->uuid) . '" class="btn btn-green btn-sm">Add Lease</a>';
                                }
                            }
                            if ($stock->current_stock > 0 || ($stock->current_stock == 0 && $stock->assetIssue->count())) {
                                if (auth()->user()->canAny(['add-maintenance'])) {
                                    $nestedData['action'] .= '<a href="' . route('admin.assetstock.maintenance', $stock->uuid) . '" class="btn btn-green btn-sm">Add Maintenance</a>';
                                }
                            }
                            if ($stock->current_stock > 0) {
                                if (auth()->user()->canAny(['edit-asset'])) {
                                    $nestedData['action'] .= '<a href="' . route('admin.assetstock.transfer', $stock->uuid) . '" class="btn btn-orange btn-sm">TRANSFER</a>';
                                }
                            }
                        }

                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getInwardStocks(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $role = '';
                $search = $request->filterData;
                $totalData = $this->inwardStockService->getTotalInwardStock();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $inwardStock = $this->inwardStockService->findInwardStock($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $inwardStock = $this->inwardStockService->findInwardStock($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->inwardStockService->getTotalInwardStock($search);
                }
                if ($inwardStock) {
                    foreach ($inwardStock as $key => $stock) {
                        $index++;
                        $nestedData['id'] = $index;
                        $nestedData['inward_id'] = $stock->inwardstockid;
                        $nestedData['item_name'] = '<strong>' . ucwords($stock->asset->asset_name) . '</strong> (' . ($stock->asset->assetid) . ')';
                        $nestedData['vendor_name'] = ucwords($stock->vendor->full_name) . ' (' . ($stock->vendor->vendorid) . ')';
                        $nestedData['invoice_no'] = $stock->vendor_invoice;
                        $nestedData['unit'] = $stock->unit;
                        $nestedData['date'] = $stock->date;
                        $nestedData['qty'] = $stock->qty;
                        $nestedData['requisition_person'] = ucwords($stock->requisition_by->full_name) . ' <br><strong>DEPT</strong>: ' . ($stock->requisition_department);
                        $nestedData['ordering_by'] = ucwords($stock->ordering_person->full_name);
                        $nestedData['approved_by'] = ucwords($stock->approved_person->full_name);
                        $nestedData['qty_rejected_by'] = ucwords($stock->qty_rejected_person?->full_name);
                        $statusCode = ($stock->is_active == 1) ? 0 : 1;
                        $statClass = ($stock->is_active == 1) ? 'text_green' : 'text_danger';
                        $status = ($stock->is_active == 1) ? 'Active' : 'Inactive';
                        $nestedData['action'] = '<div class="action_sec">
                            <div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="inward_stocks" data-uuid="' . $stock->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="inward_stocks" data-uuid="' . $stock->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="action_box">
                                <a href="' . route('admin.inwardstock.edit', $stock->uuid) . '" class="edit_icon"><i
                                        class="fa-regular fa-pen-to-square"></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inward_stocks" data-uuid="' . $stock->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getOutwardStocks(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $role = '';
                $search = $request->filterData;
                $totalData = $this->outwardStockService->getTotalOutwardStock();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $outwardStock = $this->outwardStockService->findOutwardStock($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $outwardStock = $this->outwardStockService->findOutwardStock($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->outwardStockService->getTotalOutwardStock($search);
                }
                if ($outwardStock) {
                    foreach ($outwardStock as $key => $stock) {
                        $index++;
                        $nestedData['id'] = $index;
                        $nestedData['outward_id'] = $stock->outwardstockid;
                        $nestedData['item_name'] = '<strong>' . ucwords($stock->asset->asset_name) . '</strong> (' . ($stock->asset->assetid) . ')';
                        $nestedData['unit'] = $stock->unit;
                        $nestedData['date'] = $stock->date;
                        $nestedData['qty'] = $stock->qty;
                        $nestedData['person_issuing'] = ucwords($stock->issuing_person->full_name);
                        $nestedData['person_receiving'] = ucwords($stock->receiving_person->full_name) . ' <br><strong>DEPT</strong>: ' . ($stock->receiving_department);
                        $nestedData['qty_issued'] = $stock->qty_issued;
                        $nestedData['qty_rejected'] = $stock->qty_rejected;
                        $nestedData['vendor_name'] = ucwords($stock->vendor->full_name) . ' (' . ($stock->vendor->vendorid) . ')';
                        $statusCode = ($stock->is_active == 1) ? 0 : 1;
                        $statClass = ($stock->is_active == 1) ? 'text_green' : 'text_danger';
                        $status = ($stock->is_active == 1) ? 'Active' : 'Inactive';
                        $nestedData['action'] = '<div class="action_sec">
                            <div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="outward_stocks" data-uuid="' . $stock->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="outward_stocks" data-uuid="' . $stock->uuid . '" data-status="' . $statusCode . '"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="action_box">
                                <a href="' . route('admin.outwardstock.edit', $stock->uuid) . '" class="edit_icon"><i
                                        class="fa-regular fa-pen-to-square"></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="outward_stocks" data-uuid="' . $stock->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getAssetTypeCategories(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterConditions = [
                    'type' => 'asset_type'
                ];
                $totalData = $this->categoryService->getTotalAssetTypeCategories($filterConditions);
                $totalFiltered = $totalData;
                $limit = 20;
                $start = 0;
                $order = 'name';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                $search = $request->filterData;
                if (!$search) {
                    $categories = $this->categoryService->getListofAssetTypeCategories($filterConditions, $start, $limit, $order, $dir);
                } else {
                    $categories = $this->categoryService->getListofAssetTypeCategories($filterConditions, $start, $limit, $order, $dir, $search);
                    $totalFiltered = $this->categoryService->getTotalAssetTypeCategories($filterConditions, $search);
                    // dd($categories);
                }
                if ($categories) {
                    foreach ($categories as $key => $category) {
                        $index++;
                        // $nestedData['tt_key'] = $category->id;
                        // $nestedData['tt_parent'] = $category->parent_id ? $category->parent_id : 0;

                        $nestedData['id'] = '<p class="table-con">' . $index . '</p>';
                        $nestedData['name'] = '<p class="table-con">' . $category->name . '</p>';
                        $nestedData['parent'] = '<p class="table-con">' . $category->parent?->name . '</p>';
                        $nestedData['is_active'] = '<div class="action_sec">
                            <div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($category->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($category->is_active == '1') ? 'Active' : 'Deactive') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="categories" data-uuid="' . $category->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="categories" data-uuid="' . $category->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>';

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="' . route('admin.assettype.category.edit', $category->uuid) . '" class="edit_icon"><i
                                        class="fa-regular fa-pen-to-square"></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="categories" data-uuid="' . $category->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getRoles(Request $request)
    {
        if ($request->ajax()) {
            try {
                $totalData = $this->rolePermissionService->getTotalData();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'asc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (empty($request->input('search.value'))) {
                    $roles = $this->rolePermissionService->getList($start, $limit, $order, $dir);
                } else {
                    $search = $request->input('search.value');
                    $roles = $this->rolePermissionService->getList($start, $limit, $order, $dir, $search);
                    $totalFiltered = $this->rolePermissionService->getTotalData($search);
                }
                if (!empty($roles)) {
                    foreach ($roles as $role) {
                        $index++;
                        $nestedData['sr'] = '<p>' . $index . '</p>';
                        $nestedData['name'] = $role->name;
                        $nestedData['level'] = $role->level;
                        $nestedData['slug'] = $role->slug;

                        $nestedData['action'] = '<div class="flex justify-center items-center">';
                        if ($role->slug != 'super-admin' && $role->slug != 'admin') {
                            $nestedData['action'] .= '<a href="' . route('admin.settings.role.edit', $role->id) . '" class="edit_icon" title="Edit"><span class="icon"><i class="fa-regular fa-pen-to-square"></i></span></a>
                            <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="roles" data-uuid="' . $role->id . '" title="Delete"><span class="icon"><i class="fa-solid fa-trash-can"></i></span></a>';
                        }
                        $nestedData['action'] .= '<a href="' . route('admin.settings.role.attach.permission', $role->id) . '" class="flex items-center mr-3 text-dark" title="Permissions"><span class="icon"><i class="fas fa-paperclip"></i></span></a>';
                        $nestedData['action'] .= '</div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getRequisitions(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRequisitions($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');

                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    //dd("test");
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                //dd($order,$dir);
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $requisitions = $this->assetService->findRequisitions($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $requisitions = $this->assetService->findRequisitions($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalRequisitions($filterCondition, $search);
                }
                if ($requisitions) {
                    foreach ($requisitions as $key => $requisition) {
                        $index++;
                        $nestedData['unique_id'] = '<a href="' . route('admin.requisition.view', $requisition->uuid) . '" class="edit_icon">' . $requisition->unique_id . '</a>';

                        //$nestedData['unique_id'] ='3';

                        $nestedData['version'] = $requisition->version;
                        $nestedData['entity_id'] = $requisition->entity?->name;
                        $priority = '';
                        switch ($requisition->priority) {
                            case '1':
                                $priority = 'High';
                                break;
                            case '2':
                                $priority = 'Medium';
                                break;
                            case '3':
                                $priority = 'Low';
                                break;
                        }
                        $nestedData['priority'] = $priority;
                        $nestedData['department_id'] = $requisition->department?->name;
                        // $nestedData['created_by'] = '<div class="created_by"><h6>' . $requisition->createdBy?->full_name . '</h6><p>Emp. ID: ' . $requisition->createdBy?->unique_id . '</p></div>';
                        $nestedData['created_by'] = '<a href="' . route('admin.employee.view', $requisition->createdBy?->uuid) . '  "  target="_blank" ><div class="created_by"><h6>' . $requisition->createdBy?->full_name . '</h6><p>Emp. ID: ' . $requisition->createdBy?->unique_id . '</p></div></a>';
                        $nestedData['created_at'] = Carbon::parse($requisition->created_at)->format('d-m-Y');

                        switch ($requisition->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;
                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }

                        $checkRequisitionApproval = $this->assetService->checkRequisitionApproval($requisition->id, auth()->user()->id);
                        if ($checkRequisitionApproval && $checkRequisitionApproval->status == '0') {
                            if (auth()->user()->canAny(['status-requisition'])) {
                                $nestedData['status'] = '<div class="action_sec">
                                <div class="status_box">
                                    <a class="btn btn-outline-success text_green" onclick="requisitionStatusChange(this, ' . $checkRequisitionApproval->level . ')" href="javascript:void(0)" data-table="requisitions" data-userid="' . $requisition->user_id . '" data-uuid="' . $requisition->uuid . '" data-status="1"  data-level="' . $checkRequisitionApproval->level . '"><i class="fa-solid fa-circle"></i> Approve</a>
                                    <a class="btn btn-outline-danger text_danger" onclick="requisitionStatusChange(this, ' . $checkRequisitionApproval->level . ')" href="javascript:void(0)" data-table="requisitions" data-userid="' . $requisition->user_id . '" data-uuid="' . $requisition->uuid . '" data-status="2"  data-level="' . $checkRequisitionApproval->level . '"><i class="fa-solid fa-circle"></i> Reject</a>
                                </div>
                            </div>';
                            } else {
                                $nestedData['status'] = '';
                            }
                        } else {
                            $lastApproval = RequisitionApproval::where(['requisition_id' => $requisition->id])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();
                            $nestedData['status'] = '<span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title="' . $lastApproval?->comments . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';
                        }

                        // if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $requisition->created_by) && ($requisition->status != '1' || ($requisition->status == '1' && auth()->user()->hasRole('super-admin')))) {
                        //     $nestedData['action'] = '<div class="action_sec">
                        //         <div class="action_box">
                        //             <a href="' . route('admin.requisition.edit', $requisition->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>
                        //             <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="requisitions" data-uuid="' . $requisition->uuid . '"><i
                        //                     class="fa-solid fa-trash-can"></i></a>
                        //         </div>
                        //     </div>';
                        // } else {
                        //     $nestedData['action'] = '';
                        // }


                        $nestedData['action'] = '';

                        if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $requisition->created_by)) {
                            $nestedData['action'] .= '<div class="action_sec"><div class="action_box">';

                            if (auth()->user()->canAny(['edit-requisition']) && ($requisition->status === null || $requisition->status == '2' || $requisition->status == '3')) {
                                $nestedData['action'] .= '<a href="' . route('admin.requisition.edit', $requisition->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            }

                            if (auth()->user()->canAny(['delete-requisition']) && ($requisition->status === null)) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="requisitions" data-uuid="' . $requisition->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                            }

                            $nestedData['action'] .= '</div></div>';
                        }

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getRequisitionItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $reqid = $request->reqid ? uuidtoid($request->reqid, 'requisitions') : null;
                $filterCondition = ['requisition_id' => $reqid];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRequisitionItems($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $requisitionItems = $this->assetService->findRequisitionItems($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $requisitionItems = $this->assetService->findRequisitionItems($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalRequisitionItems($filterCondition, $search);
                }
                if ($requisitionItems) {
                    foreach ($requisitionItems as $key => $requisitionItem) {
                        $index++;
                        $nestedData['item_id'] = $requisitionItem->unique_id;
                        $nestedData['req_id'] = $requisitionItem->requisition?->unique_id;
                        $nestedData['asset_type'] = $requisitionItem->assetType?->name;
                        $nestedData['asset'] = $requisitionItem->asset?->asset_name;
                        $nestedData['qty'] = (int) $requisitionItem->quantity;
                        //$nestedData['unit'] = ucfirst($requisitionItem->unit);
                        $nestedData['specs'] = $requisitionItem->specifications;
                        $nestedData['added_on'] = Carbon::parse($requisitionItem->created_at)->format('Y-m-d');

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="' . route('admin.requisition.item.edit', [$requisitionItem->requisition->uuid, $requisitionItem->uuid]) . '" class="edit_icon"><i
                                        class="fa-regular fa-pen-to-square"></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="requisition_assets" data-uuid="' . $requisitionItem->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getAssetsByTypes(Request $request)
    {
        $assetType = $this->assetTypeService->findById($request->assetTypeId);
        if ($assetType->count()) {
            $assetList = $this->assetLists($assetType);
            ksort($assetList, SORT_STRING | SORT_FLAG_CASE | SORT_NATURAL);
            // dd($assetList);
            return $this->responseJson(true, 200, 'Assets Fetched.', $assetList);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }
    public function getAssetDetails(Request $request)
    {
        $assetData = $this->assetService->findById($request->assetId);
        if ($assetData) {
            if ($assetData['specifications']) {
                $specificationList = '<ul>';
                foreach ($assetData['specifications'] as $specification) {
                    $specificationList .= '<li><strong>' . $specification['name'] . ': </strong>' . $specification['value'] . '</li>';
                }
                $specificationList .= '</ul>';
                $assetData['specifications'] = $specificationList;
            }
            return $this->responseJson(true, 200, 'Asset Details Fetched.', $assetData);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }
    private function assetLists($assetType, $assets = [])
    {
        $allAssets = array_replace($assets, $assetType->assets->pluck('id', 'asset_name')->toArray());
        if ($assetType->children()->get()) {
            foreach ($assetType->children()->get() as $subAssetType) {
                $allAssets = $this->assetLists($subAssetType, $allAssets);
            }
        }
        return $allAssets;
    }
    public function getReqItemDetails(Request $request)
    {
        $recId = uuidtoid($request->recId, 'requisition_assets');
        $recquisitionItem = $this->assetService->findRequisitionItemById($recId);
        if ($recquisitionItem) {
            return $this->responseJson(true, 200, 'Item Fetched.', $recquisitionItem);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }

    public function getBudgets(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalBudgets($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'created_at';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $budgets = $this->assetService->findBudgets($filterCondition, $order, $dir, $limit, $index, false);
                } else {

                    $budgets = $this->assetService->findBudgets($filterCondition, $order, $dir, $limit, $index, false, $search);

                    $totalFiltered = $this->assetService->getTotalBudgets($filterCondition, $search);
                }
                if ($budgets) {
                    foreach ($budgets as $key => $budget) {
                        $index++;
                        // $nestedData['budget_id'] = $budget->unique_id;
                        $nestedData['unique_id'] = '<a href="' . route('admin.budget.view', $budget->uuid) . '" class="edit_icon">' . $budget->unique_id . '</a>';
                        $nestedData['version'] = $budget->version;
                        $nestedData['name'] = $budget->name;
                        $nestedData['entity'] = $budget->entity?->name;
                        $nestedData['dept'] = $budget->department?->name;
                        $nestedData['amount'] = "₹" . number_format($budget->amount, 2, '.', ',');
                        $nestedData['date'] = Carbon::parse($budget->start_date)->format('Y-m-d') . ' To ' . Carbon::parse($budget->end_date)->format('Y-m-d');
                        //$nestedData['created_by'] = $budget->createdBy?->full_name;
                        $nestedData['created_by'] = '<a href="' . route('admin.employee.view', $budget->createdBy?->uuid) . '" target="_blank">' . $budget->createdBy?->full_name . '</a>';
                        $nestedData['created_at'] = Carbon::parse($budget->created_at)->format('Y-m-d');

                        switch ($budget->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;
                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }

                        $checkBudgetApproval = $this->assetService->checkBudgetApproval($budget->id, auth()->user()->id);
                        // dd($checkBudgetApproval);
                        if ($checkBudgetApproval && $checkBudgetApproval->status == '0') {
                            if (auth()->user()->canAny(['status-budget'])) {
                                $nestedData['status'] = '<div class="action_sec">
                                <div class="status_box">
                                    <a class="btn btn-outline-success text_green" onclick="budgetStatusChange(this, ' . $checkBudgetApproval->level . ')" href="javascript:void(0)" data-table="budgets" data-userid="' . $budget->user_id . '" data-uuid="' . $budget->uuid . '" data-status="1"  data-level="' . $checkBudgetApproval->level . '"><i class="fa-solid fa-circle"></i> Approve</a>
                                    <a class="btn btn-outline-danger text_danger" onclick="budgetStatusChange(this, ' . $checkBudgetApproval->level . ')" href="javascript:void(0)" data-table="budgets" data-userid="' . $budget->user_id . '" data-uuid="' . $budget->uuid . '" data-status="2"  data-level="' . $checkBudgetApproval->level . '"><i class="fa-solid fa-circle"></i> Reject</a>
                                </div>
                            </div>';
                            } else {
                                $nestedData['status'] = '';
                            }
                        } else {
                            $lastApproval = BudgetApproval::where(['budget_id' => $budget->id])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();
                            $nestedData['status'] = '<span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title="' . $lastApproval?->comments . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';
                        }

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $budget->created_by)) {
                            if (auth()->user()->canAny(['edit-budget']) && ($budget->status === null || $budget->status == '2' || $budget->status == '3')) {
                                $nestedData['action'] .= '<a href="' . route('admin.budget.edit', $budget->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            }
                            if (auth()->user()->canAny(['delete-budget']) && ($budget->status === null)) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="budgets" data-uuid="' . $budget->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                            }
                        }
                        $nestedData['action'] .= '</div></div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    // public function getBudgetItems(Request $request){
    //     if ($request->ajax()) {
    //         try {
    //             $budgetid = $request->budgetid ? uuidtoid($request->budgetid, 'budgets') : null;
    //             $filterCondition = ['budget_id' => $budgetid];
    //             $search = $request->filterData;
    //             $totalData = $this->assetService->getTotalBudgetItems($filterCondition);
    //             $totalFiltered = $totalData;
    //             $limit = $request->input('length');
    //             $start = $request->input('start');
    //             $order = 'id';
    //             $dir = 'desc';
    //             $index = $start;
    //             $nestedData = [];
    //             $data = [];
    //             if (!$search) {
    //                 $budgetItems = $this->assetService->findBudgetItems($filterCondition, $order, $dir, $limit, $index, false);
    //             } else {
    //                 $budgetItems = $this->assetService->findBudgetItems($filterCondition, $order, $dir, $limit, $index, false, $search);
    //                 $totalFiltered = $this->assetService->getTotalBudgetItems($filterCondition, $search);
    //             }
    //             if ($budgetItems) {
    //                 foreach ($budgetItems as $key => $budgetItem) {
    //                     $index++;
    //                     $nestedData['item_id'] = $budgetItem->unique_id;
    //                     $nestedData['budget_id'] = $budgetItem->budget?->unique_id;
    //                     $nestedData['asset_type'] = $budgetItem->assetType?->name;
    //                     $nestedData['asset'] = $budgetItem->asset?->asset_name;
    //                     $nestedData['qty'] = (int) $budgetItem->quantity;
    //                     $nestedData['specs'] = $budgetItem->specifications;
    //                     $nestedData['added_on'] = Carbon::parse($budgetItem->created_at)->format('Y-m-d');

    //                     switch ($budgetItem->status) {
    //                         case 0:
    //                             $statClass = 'text_danger';
    //                             $status = 'InActive';
    //                             break;
    //                         case 1:
    //                             $statClass = 'text_green';
    //                             $status = 'Active';
    //                             break;
    //                     }
    //                     $nestedData['status'] = '<div class="action_sec">
    //                         <div class="status_box">
    //                             <div class="dropdown">
    //                                 <button class="dropdown-toggle" type="button" id="dropdownMenuButton'.$key.'" data-bs-toggle="dropdown" aria-expanded="false"><span class="'.$statClass.'"><i class="fa-solid fa-circle"></i></span>'.$status.'</button>
    //                                 <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton'.$key.'">
    //                                     <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="'. $budgetItem->uuid .'" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
    //                                     <li><a class="dropdown-item text_pending" onclick="statusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="'. $budgetItem->uuid .'" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
    //                                 </ul>
    //                             </div>
    //                         </div>
    //                     </div>';

    //                     $nestedData['action'] = '<div class="action_sec">
    //                         <div class="action_box">
    //                             <a href="' . route('admin.budget.item.edit', [$budgetItem->budget->uuid, $budgetItem->uuid]) . '" class="edit_icon"><i
    //                                     class="fa-regular fa-pen-to-square"></i></a>
    //                             <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '"><i
    //                                     class="fa-solid fa-trash-can"></i></a>
    //                         </div>
    //                     </div>';
    //                     $data[] = $nestedData;
    //                     $nestedData = [];
    //                 }
    //             }
    //             $jsonData = array(
    //                 "draw" => (int) $request->input('draw'),
    //                 "recordsTotal" => (int) $totalData,
    //                 "recordsFiltered" => (int) $totalFiltered,
    //                 "data" => $data,
    //             );

    //             return response()->json($jsonData);
    //         } catch (\Exception $e) {
    //             logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
    //             return $jsonData = array(
    //                 "draw" => (int) $request->input('draw'),
    //                 "recordsTotal" => (int) 0,
    //                 "recordsFiltered" => (int) 0,
    //                 "data" => []
    //             );
    //         }
    //     }
    //     abort(405);
    // }



    public function getBudgetItemDetails(Request $request)
    {

        $recId = uuidtoid($request->recId, 'budget_items');

        $budgetItem = $this->assetService->findBudgetItemById($recId);
        // dd($budgetItem);
        if ($budgetItem) {
            return $this->responseJson(true, 200, 'Item Fetched.', $budgetItem);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }


    public function getBudgetNoteDetails(Request $request)
    {
        $recId = uuidtoid($request->recId, 'budget_notes');
        $budgetItem = $this->assetService->findBudgetNoteById($recId);
        //dd($budgetItem);
        if ($budgetItem) {
            return $this->responseJson(true, 200, 'Note Fetched.', $budgetItem);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }


    public function getBudgetItems(Request $request, $uuid)
    {
        if ($request->ajax()) {
            try {

                //dd($uuid);
                $budgetid = uuidtoid($uuid, 'budgets');

                //dd($budgetid);

                $filterCondition = ['budget_id' => $budgetid];

                $search = $request->filterData;

                $totalData = $this->assetService->getTotalBudgetItems($filterCondition);


                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                //dd("aaa");
                if (!$search) {
                    $budgetItems = $this->assetService->findBudgetItems($filterCondition, $order, $dir, $limit, $index, false);
                } else {

                    $budgetItems = $this->assetService->findBudgetItems($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalBudgetItems($filterCondition, $search);
                }

                //dd($budgetItems);
                if ($budgetItems) {
                    foreach ($budgetItems as $key => $budgetItem) {
                        $index++;
                        $nestedData['item_id'] = $budgetItem->unique_id;
                        $nestedData['asset_category'] = "N/A";
                        $nestedData['budget_id'] = $budgetItem->budget?->unique_id;
                        $nestedData['asset_type'] = $budgetItem->assetType?->name;
                        $nestedData['asset'] = $budgetItem->asset?->asset_name;
                        $nestedData['qty'] = (int) $budgetItem->quantity;
                        $nestedData['specs'] = $budgetItem->specifications;
                        $nestedData['added_on'] = Carbon::parse($budgetItem->created_at)->format('Y-m-d');

                        switch ($budgetItem->status) {
                            case 0:
                                $statClass = 'text_danger';
                                $status = 'InActive';
                                break;
                            case 1:
                                $statClass = 'text_green';
                                $status = 'Active';
                                break;
                        }
                        $nestedData['status'] = '<div class="action_sec">
                            <div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_pending" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>';

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="javascript:void(0)" class="edit_icon edit_budget_item" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-regular fa-pen-to-square"  ></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getBudgetNotes(Request $request, $uuid)
    {
        if ($request->ajax()) {
            try {

                //dd($uuid);
                $budgetid = uuidtoid($uuid, 'budgets');
                //dd($budgetid);
                $filterCondition = ['budget_id' => $budgetid];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalBudgetNotes($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                //dd("aaa");
                if (!$search) {
                    $budgetItems = $this->assetService->findBudgetNotes($filterCondition, $order, $dir, $limit, $index, false);
                } else {

                    $budgetItems = $this->assetService->findBudgetNotes($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalBudgetNotes($filterCondition, $search);
                }

                //dd($budgetItems);
                if ($budgetItems) {
                    foreach ($budgetItems as $key => $budgetItem) {
                        $index++;
                        $nestedData['item_id'] = $budgetItem->unique_id;
                        //    $nestedData['budget_id'] = $budgetItem->budget?->unique_id;
                        $nestedData['asset_type'] = $budgetItem->title ?? '';
                        $nestedData['asset'] = substr($budgetItem->content ?? '', 0, 10);
                        // $nestedData['qty'] = "None Qty";
                        // $nestedData['specs'] = "None specificztion";
                        // $nestedData['added_on'] = Carbon::parse($budgetItem->created_at)->format('Y-m-d');

                        switch ($budgetItem->status) {
                            case 0:
                                $statClass = 'text_danger';
                                $status = 'InActive';
                                break;
                            case 1:
                                $statClass = 'text_green';
                                $status = 'Active';
                                break;
                        }
                        // $nestedData['status'] = '<div class="action_sec">
                        //     <div class="status_box">
                        //         <div class="dropdown">
                        //             <button class="dropdown-toggle" type="button" id="dropdownMenuButton'.$key.'" data-bs-toggle="dropdown" aria-expanded="false"><span class="'.$statClass.'"><i class="fa-solid fa-circle"></i></span>'.$status.'</button>
                        //             <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton'.$key.'">
                        //                 <li><a class="dropdown-item text_green" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="'. $budgetItem->uuid .'" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                        //                 <li><a class="dropdown-item text_pending" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="'. $budgetItem->uuid .'" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                        //             </ul>
                        //         </div>
                        //     </div>
                        // </div>';

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="javascript:void(0)" class="edit_icon edit_budget_note" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-regular fa-pen-to-square"  ></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="budget_notes" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getBudgetDocuments(Request $request, $uuid)
    {
        if ($request->ajax()) {
            try {
                //dd($uuid);
                $budgetid = uuidtoid($uuid, 'budgets');
                $filterCondition = ['budget_id' => $budgetid];
                $search = $request->filterData;                //dd($search);
                $totalData = $this->assetService->getTotalBudgetDocuments($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $budgetItems = $this->assetService->findBudgetDocuments($filterCondition, $order, $dir, $limit, $index, false);
                } else {

                    $budgetItems = $this->assetService->findBudgetDocuments($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalBudgetDocuments($filterCondition, $search);
                }
                if ($budgetItems) {
                    foreach ($budgetItems as $key => $budgetItem) {
                        $index++;
                        $nestedData['item_id'] = $budgetItem->unique_id;
                        $nestedData['budget_id'] = $budgetItem->budget?->unique_id;
                        $nestedData['asset_type'] = $budgetItem->title ?? '';
                        $nestedData['asset'] = substr($budgetItem->content ?? '', 0, 10);
                        // $nestedData['qty'] = "None Qty";
                        // $nestedData['specs'] = "None specificztion";
                        $nestedData['added_on'] = Carbon::parse($budgetItem->created_at)->format('Y-m-d');

                        switch ($budgetItem->status) {
                            case 0:
                                $statClass = 'text_danger';
                                $status = 'InActive';
                                break;
                            case 1:
                                $statClass = 'text_green';
                                $status = 'Active';
                                break;
                        }

                        $nestedData['status'] = '<div class="action_sec">
                            <div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . $statClass . '"><i class="fa-solid fa-circle"></i></span>' . $status . '</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_pending" onclick="itemStatusChange(this)" href="javascript:void(0)" data-table="budget_items" data-uuid="' . $budgetItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>';

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="javascript:void(0)" class="edit_icon edit_budget_note" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-regular fa-pen-to-square"  ></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="budget_notes" data-uuid="' . $budgetItem->uuid . '"><i
                                        class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getLevelUsers(Request $request)
    {
        $levelUsers = $this->userService->findUserByRole(['level' => $request->level], null, 'name', 'asc', 999999, 0, false);
        if ($levelUsers->count()) {
            return $this->responseJson(true, 200, 'Level Users Fetched.', $levelUsers->pluck('full_name', 'id'));
        }
        return $this->responseJson(true, 200, 'Level Users Not Found!', []);
        abort(405);
    }

    public function updateApprovalStatus(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            $id = uuidtoid($request->uuid, $table);
            $level = $request->level;
            $status = $request->status;
            //dd($request->all());
            $isFirstLevelApprove = '';
            $isNextLevelUpdate = '';
            if ($request->status == '3') {
                $isFirstLevelApprove = BudgetApproval::where('budget_id', $id)->where('level', $level)->update(['status' => '2']);
                $isFinalApprove = Budget::where('id', $id)->update(['status' => '3']);
            } else {
                $isFirstLevelApprove = BudgetApproval::where('budget_id', $id)->where('level', $level)->update(['status' => '1']);
                $isNextLevelUpdate = BudgetApproval::where('budget_id', $id)->where('level', ($level + 1))->update(['status' => '0']);
                $nextLevelUserId = BudgetApproval::where('budget_id', $id)->where('level', ($level + 1))->first();
                $approvalData = [
                    'form_name' => "You got a budget approval request",
                    'budget_uuid' => $request->uuid,
                ];
                if ($isNextLevelUpdate == 0) {
                    $isFinalApprove = Budget::where('id', $id)->update(['status' => '1']);
                } else {
                    User::find($nextLevelUserId->user_id)->notify(new BudgetApproveNotification($approvalData));
                    $requestparam = (object) [
                        'title' => "Budget approval request",
                        'body' => "You got a budget approval request",
                    ];
                    $this->sendPushNotification($nextLevelUserId->user_id, $requestparam);
                }
            }
            $message = 'Budget successfully approved';
            if ($isFirstLevelApprove || $isNextLevelUpdate || $isFinalApprove) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function updateRequisitionStatus(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            $id = uuidtoid($request->uuid, $table);
            $level = $request->level;
            $status = $request->status;
            //dd($request->all());
            $isFirstLevelApprove = '';
            $isNextLevelUpdate = '';
            if ($request->status == '3') {
                $isFirstLevelApprove = RequisitionApproval::where('requisition_id', $id)->where('level', $level)->update(['status' => '2']);
                $isFinalApprove = Requisition::where('id', $id)->update(['status' => '3']);
            } else {
                $isFirstLevelApprove = RequisitionApproval::where('requisition_id', $id)->where('level', $level)->update(['status' => '1']);
                $isNextLevelUpdate = RequisitionApproval::where('requisition_id', $id)->where('level', ($level + 1))->update(['status' => '0']);
                $nextLevelUserId = RequisitionApproval::where('requisition_id', $id)->where('level', ($level + 1))->first();
                $approvalData = [
                    'form_name' => "You got a requisition approval request",
                    'requisition_uuid' => $request->uuid,
                ];
                if ($isNextLevelUpdate == 0) {
                    $isFinalApprove = Requisition::where('id', $id)->update(['status' => '1']);
                } else {
                    User::find($nextLevelUserId->user_id)->notify(new RequisitionApproveNotification($approvalData));

                    $requestparam = (object) [
                        'title' => "Requisition approval request",
                        'body' => "You got a requisition approval request",
                    ];
                    $this->sendPushNotification($nextLevelUserId->user_id, $requestparam);
                }
            }
            $message = 'Requisition Successfully Approved';
            if ($isFirstLevelApprove || $isNextLevelUpdate || $isFinalApprove) {
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function getStates($countryid)
    {
        //dd($countryid);
        $data = $this->stateService->getStateByCountry($countryid);
        //dd($data);
        return $this->responseJson(true, 200, 'data fetched', $data);
    }

    public function getLocations(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalLocations();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'city_id';
                $dir = 'asc';
                //dd($request->all());
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                //dd($order,$dir);
                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $locations = $this->assetService->findLocations($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $locations = $this->assetService->findLocations($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalLocations($search);
                }
                if ($locations) {
                    foreach ($locations as $key => $location) {
                        // dd($location);
                        $nestedData['name'] = $location->name;
                        $nestedData['street_address'] = $location->street_address;
                        $nestedData['state_id'] = $location->state?->name;
                        $nestedData['city_id'] = $location->city?->name;

                        $nestedData['status'] = '';
                        if (auth()->user()->canAny(['status-location'])) {
                            $nestedData['status'] .= '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($location->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($location->is_active == '1') ? 'Active' : 'Inactive') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="locations" data-uuid="' . $location->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="locations" data-uuid="' . $location->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>';
                        }

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        if (auth()->user()->canAny(['edit-location'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.location.edit', $location->uuid) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-location'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="locations" data-uuid="' . $location->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }






    public function resetAllBudgetItems(Request $request)
    {

        try {
            $budgetId = uuidtoid($request->uuid, 'budgets');
            $findBudgetItems = BudgetItem::where('budget_id', $budgetId)->get();
            $findBudgetItems->each(function ($item) {
                $item->forceDelete();
            });
            return $this->responseJson(true, 200, 'Budget Item Sussessfullt Reset.', [
                'redirect_url' => route('admin.budget.item.list', $request->uuid)
            ]);
        } catch (\Throwable $e) {
            logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
            return $this->responseJson(false, 500, "Something went wrong", '');
        }
    }
    public function getBudgetVersions(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = ['budget_id' => $request->budget_id];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalBudgetVersions($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $budgets = $this->assetService->findBudgetVersions($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $budgets = $this->assetService->findBudgetVersions($filterCondition, $order, $dir, $limit, $index, false, $search);

                    $totalFiltered = $this->assetService->getTotalBudgetVersions($filterCondition, $search);
                }

                //dd($budgets);

                if ($budgets) {
                    foreach ($budgets as $key => $budget) {
                        $index++;
                        // $nestedData['budget_id'] = $budget->unique_id;
                        // $nestedData['budget_id'] = '<a href="javascript:void(0);" class="edit_icon view_version" data-uuid="'.$budget->uuid.'" title="View">' . $budget->unique_id . '</a>';


                        $nestedData['budget_id'] = '<a href="javascript:void(0);" class="edit_icon view_version" data-uuid="' . $budget->uuid . '" title="View" data-all="' . htmlspecialchars(json_encode($budget), ENT_QUOTES, 'UTF-8') . '">' . $budget->unique_id . '</a>';


                        $nestedData['version'] = $budget->version;
                        // $nestedData['name'] = $budget->name;
                        // $nestedData['entity'] = $budget->entity?->name;
                        // $nestedData['dept'] = $budget->department?->name;
                        // $nestedData['amount'] = $budget->amount;
                        // $nestedData['date'] = Carbon::parse($budget->start_date)->format('Y-m-d') . ' To ' . Carbon::parse($budget->end_date)->format('Y-m-d');
                        $nestedData['created_by'] = $budget->createdBy?->full_name . '<div>' . Carbon::parse($budget->created_at)->format('Y-m-d') . '</vid>';

                        switch ($budget->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;
                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }
                        $remarks = '';
                        foreach ($budget->budget_approvals as $budget_approval) {
                            if ($budget_approval['status'] == $budget->status) {
                                $remarks = $budget_approval['comments'];
                            }
                        }
                        $nestedData['status'] = '<span class="' . $statClass . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';
                        $nestedData['remarks'] = '<p>' . $remarks . '</p>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getBudgetVersionDetails(Request $request)
    {

        if ($request->ajax()) {
            try {


                $oldBudgetId = uuidtoid($request->uuid, 'budget_versions');

                //$overViewAllData=BudgetVersion::where('id',$oldBudgetId)->with('entity')->with('department')->with('createdBy')->with('location')->with('category')->first();

                //$overViewAllData=BudgetVersion::where('id',$oldBudgetId)->with('entity')->with('department')->with('createdBy')->with('location')->with('category')->first();

                $overViewAllData = $this->assetService->findBudgetVersionById($oldBudgetId);

                //dd($overViewAllData);
                $message = '';
                $budgetItems = [];
                foreach ($overViewAllData->budget_items as $k => $item) {
                    foreach ($item as $key => $itemData) {
                        switch ($key) {
                            case 'category_id':
                                $asset_category = $itemData ? $this->categoryService->findCategoryById($itemData) : null;
                                $budgetItems[$k][$key] = $asset_category?->name;
                                break;
                            case 'asset_type_id':
                                $asset_type = $itemData ? $this->assetTypeService->findById($itemData) : null;
                                $budgetItems[$k][$key] = $asset_type?->name;
                                break;
                            case 'asset_id':
                                $asset = $itemData ? $this->assetService->findById($itemData) : null;
                                $budgetItems[$k][$key] = $asset?->asset_name;
                                break;
                            default:
                                $budgetItems[$k][$key] = $itemData;
                                break;
                        }
                    }
                }


                $overViewAllData->budget_items = $budgetItems;



                $budgetApproverNames = [];
                foreach ($overViewAllData->budget_approvals as $k => $approval) {
                    foreach ($approval as $key => $approvalData) {
                        //dd($key);
                        switch ($key) {
                            case 'user_id':
                                $asset_category = $this->userService->findUserById($approvalData);
                                $budgetApproverNames[$k][$key] = $asset_category?->first_name . " " . $asset_category?->last_name;
                                break;

                            default:
                                $budgetApproverNames[$k][$key] = $approvalData;
                                break;
                        }
                    }
                }

                $overViewAllData->approval_details = $budgetApproverNames;
                //dd($overViewAllData->approval_details);

                return $this->responseJson(true, 200, $message, $overViewAllData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getRequisitionVersionDetails(Request $request)
    {

        if ($request->ajax()) {
            try {


                $oldRequisitionId = uuidtoid($request->uuid, 'requisition_versions');
                $overViewAllData = $this->assetService->findRequisitionVersionById($oldRequisitionId);

                $message = '';
                $requisitionItems = [];
                foreach ($overViewAllData->requisition_items as $k => $item) {
                    foreach ($item as $key => $itemData) {
                        switch ($key) {
                            case 'category_id':
                                $asset_category = $itemData ? $this->categoryService->findCategoryById($itemData) : null;
                                $requisitionItems[$k][$key] = $asset_category?->name;
                                break;
                            case 'asset_type_id':
                                $asset_type = $itemData ? $this->assetTypeService->findById($itemData) : null;
                                $requisitionItems[$k][$key] = $asset_type?->name;
                                break;
                            case 'asset_id':
                                $asset = $itemData ? $this->assetService->findById($itemData) : null;
                                $requisitionItems[$k][$key] = $asset?->asset_name;
                                break;
                            default:
                                $requisitionItems[$k][$key] = $itemData;
                                break;
                        }
                    }
                }


                $overViewAllData->requisition_items = $requisitionItems;



                $requisitionApproverNames = [];
                foreach ($overViewAllData->requisition_approvals as $k => $approval) {
                    foreach ($approval as $key => $approvalData) {
                        //dd($key);
                        switch ($key) {
                            case 'user_id':
                                $asset_category = $this->userService->findUserById($approvalData);
                                $requisitionApproverNames[$k][$key] = $asset_category?->first_name . " " . $asset_category?->last_name;
                                break;

                            default:
                                $requisitionApproverNames[$k][$key] = $approvalData;
                                break;
                        }
                    }
                }

                $overViewAllData->approval_details = $requisitionApproverNames;

                return $this->responseJson(true, 200, $message, $overViewAllData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getRequisitionItemDetails(Request $request)
    {

        $recId = uuidtoid($request->recId, 'requisition_assets');

        $requisitionItem = $this->assetService->findRequisitionItemById($recId);
        // dd($requisitionItem);
        if ($requisitionItem) {
            return $this->responseJson(true, 200, 'Item Fetched.', $requisitionItem);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }

    public function getRequisitionVersions(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = ['requisition_id' => $request->requisition_id];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRequisitionVersions($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $requisitions = $this->assetService->findRequisitionVersions($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $requisitions = $this->assetService->findRequisitionVersions($filterCondition, $order, $dir, $limit, $index, false, $search);

                    $totalFiltered = $this->assetService->getTotalRequisitionVersions($filterCondition, $search);
                }

                if ($requisitions) {
                    foreach ($requisitions as $key => $requisition) {
                        $index++;
                        // $nestedData['requisition_id'] = $requisition->unique_id;
                        $nestedData['requisition_id'] = '<a href="javascript:void(0);" class="edit_icon view_version" data-uuid="' . $requisition->uuid . '" title="View">' . $requisition->unique_id . '</a>';
                        $nestedData['version'] = $requisition->version;
                        // $nestedData['name'] = $requisition->name;
                        // $nestedData['entity'] = $requisition->entity?->name;
                        // $nestedData['dept'] = $requisition->department?->name;
                        // $nestedData['amount'] = $requisition->amount;
                        // $nestedData['date'] = Carbon::parse($requisition->start_date)->format('Y-m-d') . ' To ' . Carbon::parse($requisition->end_date)->format('Y-m-d');
                        $nestedData['created_by'] = $requisition->createdBy?->full_name . '<div>' . Carbon::parse($requisition->created_at)->format('Y-m-d') . '</vid>';

                        switch ($requisition->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;
                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }
                        $remarks = '';
                        foreach ($requisition->requisition_approvals as $requisition_approval) {
                            if ($requisition_approval['status'] == $requisition->status) {
                                $remarks = $requisition_approval['comments'];
                            }
                        }
                        $nestedData['status'] = '<span class="' . $statClass . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';
                        $nestedData['remarks'] = '<p>' . $remarks . '</p>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getRfqs_bk(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRfqs($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'unique_id';
                $dir = 'desc';

                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $rfqs = $this->assetService->findRfqs($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $rfqs = $this->assetService->findRfqs($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalRfqs($filterCondition, $search);
                }
                if ($rfqs) {
                    foreach ($rfqs as $key => $rfq) {
                        $index++;
                        $count = $rfq->quotations->unique('vendor_id')->count();
                        $nestedData['SrNo'] = $index;
                        $nestedData['unique_id'] = '<a href="' . route('admin.rfq.view', $rfq->uuid) . '" class="edit_icon">' . $rfq->unique_id . '</a>';

                        $nestedData['request_subject'] = $rfq->request_subject;

                        $nestedData['request_date'] = \Carbon\Carbon::parse($rfq->request_date)->format('Y-m-d');


                        $nestedData['requisition_id'] = '<a href="' . route('admin.requisition.view', $rfq->requisition?->uuid) . '" class="edit_icon"  target="_blank">' . $rfq->requisition?->unique_id . '</a>';

                        if (auth()->user()->canAny(['view-quotation'])) {
                            $nestedData['received_quotation'] = '  <a href="' . route('admin.rfq.quotations', $rfq->uuid) . '" class="edit_icon" target="_blank"> ' . $count . '</a>';


                            if ($rfq->quotation_comments) {
                                $nestedData['received_quotation'] .= ' <a href="javascript:void(0)" class="view-remarks-btn" data-comments="' . htmlspecialchars($rfq->quotation_comments, ENT_QUOTES, 'UTF-8') . '">
                                    <i class="fas fa-info-circle info-icon " aria-hidden="true" title="View comment"></i>
                                </a>';
                            }
                        }


                        $nestedData['status'] = '';





                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        if (auth()->user()->canAny(['edit-rfq']) && ($rfq->is_sent == '0')) {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.edit', $rfq->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-rfq']) && ($rfq->is_sent == '0')) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="rfqs" data-uuid="' . $rfq->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        if (auth()->user()->canAny(['view-quotation'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.quotation.list', $rfq->uuid) . '" class="edit_icon" title="List Quotations"><i class="fa fa-list" aria-hidden="true"></i></a>';
                        }
                        if ($rfq->is_sent == '0') {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.sent', $rfq->uuid) . '" class="edit_icon" data-table="rfqs" data-uuid="' . $rfq->uuid . '"><i class="fa fa-paper-plane"></i></a>';
                        }

                        $nestedData['action'] .= '</div></div>';


                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getRfqs(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRfqs($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'unique_id';
                $dir = 'desc';

                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $rfqs = $this->assetService->findRfqs($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $rfqs = $this->assetService->findRfqs($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalRfqs($filterCondition, $search);
                }
                if ($rfqs) {
                    foreach ($rfqs as $key => $rfq) {
                        $index++;
                        $count = $rfq->quotations->unique('vendor_id')->count();
                        $nestedData['SrNo'] = $index;
                        $nestedData['unique_id'] = '<a href="' . route('admin.rfq.view', $rfq->uuid) . '" class="edit_icon">' . $rfq->unique_id . '</a>';

                        $nestedData['request_subject'] = $rfq->request_subject;

                        $nestedData['request_date'] = \Carbon\Carbon::parse($rfq->request_date)->format('Y-m-d');


                        $nestedData['requisition_id'] = '<a href="' . route('admin.requisition.view', $rfq->requisition?->uuid) . '" class="edit_icon"  target="_blank">' . $rfq->requisition?->unique_id . '</a>';

                        if (auth()->user()->canAny(['view-quotation'])) {
                            $nestedData['received_quotation'] = '  <a href="' . route('admin.rfq.quotations', $rfq->uuid) . '" class="edit_icon" target="_blank"> ' . $count . '</a>';


                            if ($rfq->quotation_comments) {
                                $nestedData['received_quotation'] .= ' <a href="javascript:void(0)" class="view-remarks-btn" data-comments="' . htmlspecialchars($rfq->quotation_comments, ENT_QUOTES, 'UTF-8') . '">
                                    <i class="fas fa-info-circle info-icon " aria-hidden="true" title="View comment"></i>
                                </a>';
                            }
                        }




                        // $checkRfqApproval = $this->assetService->checkRfqApproval($rfq->id);
                        $latest = $this->assetService->checkRfqApprovalByLatestOrder($rfq->id, null, null, null);
                        $isRfqRejected = $this->assetService->checkRfqApproval($rfq->id, null, null, 2);


                        $statClass = 'text_black';
                        $status = 'Not Sent For Approval';
                        if ($isRfqRejected != null) {
                            $statClass = 'text_danger';
                            $status = 'Rejected';
                        }
                        // if($latest != null && $isRfqRejected ==null){
                        // switch ($latest->status) {
                        //     case '0':
                        //         // $statClass = 'text_pending';
                        //         $statClass = 'text_black';
                        //         $status = 'Pending';
                        //         //$status = 'On Going';
                        //         break;
                        //     case '1':
                        //         $statClass = 'text_green';
                        //         $status = 'Approved';
                        //         break;
                        //     case '2':
                        //         $statClass = 'text_danger';
                        //         $status = 'Rejected';
                        //         break;
                        //     default:
                        //         $statClass = 'text_black';
                        //         // $status = 'Not Sent For Approval';
                        //         $status = 'Pending';
                        //         break;
                        // }
                        // }




                        $selectedQuotation = Quotation::where(['request_id' => $rfq->id, 'is_selected' => '1'])->first();
                        $currentRfqApproval = $this->assetService->checkRfqApproval($rfq->id, null, null, '0');

                        if ($selectedQuotation != null && $selectedQuotation->is_selected) {
                            if ($currentRfqApproval) {
                                $statClass = 'text_pending';
                                $status = 'Ongoing Approval';
                            }
                            if ((isset($latest)) && $latest->status == 1) {
                                $statClass = 'text_green';
                                $status = 'Accepted';
                            }
                        }
                        $nestedData['status'] = '<span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title=""><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';








                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        if (auth()->user()->canAny(['edit-rfq']) && ($rfq->is_sent == '0')) {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.edit', $rfq->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-rfq']) && ($rfq->is_sent == '0')) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="rfqs" data-uuid="' . $rfq->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        if (auth()->user()->canAny(['view-quotation'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.quotation.list', $rfq->uuid) . '" class="edit_icon" title="List Quotations"><i class="fa fa-list" aria-hidden="true"></i></a>';
                        }
                        if ($rfq->is_sent == '0') {
                            $nestedData['action'] .= '<a href="' . route('admin.rfq.sent', $rfq->uuid) . '" class="edit_icon" data-table="rfqs" data-uuid="' . $rfq->uuid . '"><i class="fa fa-paper-plane"></i></a>';
                        }

                        $nestedData['action'] .= '</div></div>';


                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }






    public function getRfqRequisitionItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $reqid = $request->reqid ? uuidtoid($request->reqid, 'requisitions') : null;
                $requisitionData = $reqid ? $this->assetService->findRequisitionById($reqid) : [];
                $filterCondition = ['requisition_id' => $reqid];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalRequisitionItems($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $requisitionItems = $this->assetService->findRequisitionItems($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $requisitionItems = $this->assetService->findRequisitionItems($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalRequisitionItems($filterCondition, $search);
                }
                if ($requisitionItems) {
                    foreach ($requisitionItems as $key => $requisitionItem) {
                        $index++;
                        $nestedData['item_id'] = '<div class="form-group"><label>' . $requisitionItem->unique_id . '</label></div>';
                        $nestedData['asset_category'] = '<div class="form-group">
                            ' . $requisitionItem->category?->name . '
                        </div>
                        <input type="hidden" name="items[' . $key . '][category_id]" id="category_id_' . $requisitionItem->id . '" value="' . $requisitionItem->category?->id . '">';
                        $nestedData['asset_type'] = '<div class="form-group">
                            ' . $requisitionItem->assetType?->name . '
                            <input type="hidden" name="items[' . $key . '][asset_type_id]" id="asset_type_id_' . $requisitionItem->id . '" value="' . $requisitionItem->assetType?->id . '">
                        </div>';
                        $nestedData['asset'] = '<div class="form-group">
                            ' . ($requisitionItem->asset?->asset_name ?? 'All') . '
                            <input type="hidden" name="items[' . $key . '][asset_id]" id="asset_id_' . $requisitionItem->id . '" value="' . $requisitionItem->asset?->id . '">
                        </div>';
                        /*$nestedData['asset_category'] = '<div class="form-group">
                            <input type="text" class="typeCategory" id="typeCategory'.$requisitionItem->id.'" placeholder="--choose one--" autocomplete="off" data-type_cat_id="'.$requisitionItem->category?->id.'" />
                        </div>
                        <input type="hidden" name="category_id" id="category_id_'.$requisitionItem->id.'" value="'.$requisitionItem->category?->id.'">';
                        $nestedData['asset_type'] = '<div class="form-group">
                            <input type="text" class="assetType" id="assetType'.$requisitionItem->id.'" placeholder="--choose one--" autocomplete="off" data-id="'.$requisitionItem->assetType?->id.'" data-type_cat_id="'.$requisitionItem->category?->id.'"/>
                            <input type="hidden" name="asset_type_id" id="asset_type_id_'.$requisitionItem->id.'" value="'.$requisitionItem->assetType?->id.'">
                        </div>';
                        $nestedData['asset'] = '<div class="form-group">
                            <select name="asset_id" class="form-control asset_id" id="asset_id_'.$requisitionItem->id.'" data-id="'.$requisitionItem->asset?->id.'">
                                <option value="">--choose one--</option>
                            </select>
                        </div>';*/
                        $nestedData['qty'] = '<div class="form-group">
                            <input type="number" name="items[' . $key . '][quantity]" class="form-control" id="quantity_' . $requisitionItem->id . '" value="' . $requisitionItem->quantity . '">
                        </div>';
                        $nestedData['unit'] = '<div class="form-group">
                            ' . ucfirst($requisitionItem->unit) . '
                            <input type="hidden" name="items[' . $key . '][unit]" id="unit_' . $requisitionItem->id . '" value="' . $requisitionItem->unit . '">
                        </div>';
                        $nestedData['specs'] = '<div class="form-group">
                            <textarea name="items[' . $key . '][specifications]" class="form-control specifications" rows="1" id="specifications_' . $requisitionItem->id . '">' . $requisitionItem->specifications . '</textarea>
                        </div>';
                        $nestedData['reason'] = '<div class="form-group">
                            <textarea name="items[' . $key . '][description]" class="form-control" rows="8" id="description_' . $requisitionItem->id . '">' . $requisitionItem->description . '</textarea>
                        </div>';
                        $nestedData['added_on'] = Carbon::parse($requisitionItem->created_at)->format('Y-m-d');

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <label for="item_id_' . $requisitionItem->unique_id . '"><input type="checkbox" name="items[' . $key . '][item_id]" id="item_id_' . $requisitionItem->id . '" value="' . $requisitionItem->id . '" checked></label>
                            </div>
                        </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                    "requisitionData" => $requisitionData,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => [],
                    "requisitionData" => []
                );
            }
        }
        abort(405);
    }

    public function getQuotations(Request $request, $rfqUuid = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                if ($rfqUuid) {
                    $rfqId = uuidtoid($rfqUuid, 'rfqs');
                    $filterCondition = ['request_id' => $rfqId];
                }
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalQuotations($filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';

                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];

                if (!$search) {
                    $quotations = $this->assetService->listQuotations($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $quotations = $this->assetService->listQuotations($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalQuotations($filterCondition, $search);
                }

                if ($quotations) {
                    //dd($isVendorSelected);
                    foreach ($quotations as $quotation) {
                        $isVendorSelected = $quotation->rfq->quotations->contains('is_selected', '1');
                        $nestedData['unique_id'] = '<a href="' . route('admin.rfq.quotation.view', $quotation->uuid) . '">' . $quotation->unique_id . '</a>';
                        // $nestedData['rfq_id'] = $quotation->rfq->unique_id;

                        $nestedData['request_id'] = '<a href="' . route('admin.rfq.view', $quotation->rfq?->uuid) . '"  target="_blank"  class="edit_icon">' . $quotation->rfq?->unique_id . '</a>';
                        $nestedData['created_at'] = \Carbon\Carbon::parse($quotation->created_at)->format('d-m-Y');
                        $nestedData['vendor_id'] = $quotation->vendor?->full_name;
                        $nestedData['comapny_name'] = $quotation->vendor?->company_name;
                        $nestedData['contact_no'] = $quotation->vendor?->mobile_number;


                        $nestedData['action'] = '<div class="action_sec">
                                                    <div class="action_box">';
                        // $nestedData['action'] .= '<a href="' . route('admin.rfq.quotation.view', $quotation->uuid) . '" class="edit_icon"><i class="fa fa-eye" aria-hidden="true"></i></a>';
                        if (auth()->user()->hasRole('super-admin')) {
                            if (!$isVendorSelected) {
                                if (!$quotation->is_editable) {
                                    $nestedData['action'] .= '<a href="javascript:void(0);" data-uuid="' . $quotation->uuid . '" class="btn btn-warning" onclick="setEditable(this)">Re-Quote</a>';
                                } else {
                                    $nestedData['action'] .= '<span class="text-success" >Sent for Re-Quotation</span>
                                  <a href="javascript:void(0)" class="view-remarks-btn" data-remarks="' . $quotation->remarks . '"><i class="fas fa-info-circle info-icon view-remarks-btn" aria-hidden="true" title="View Remarks"></i> </a>';
                                }
                            } else {
                                $nestedData['action'] .= '<span class="text-success">' . ($quotation->is_selected ? '<i class="fa fa-check" aria-hidden="true"></i> Selected' : '') . '</span>';
                            }
                        }
                        $nestedData['action'] .= '</div>
                                                </div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function updateQuotation(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'quotations');
            DB::beginTransaction();
            try {
                $isQuotationUpadated = $this->assetService->updateQuotation($request->except(['_token', 'uuid']), $id);
                if ($isQuotationUpadated) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Quotation is editable now');
                } else {
                    return $this->responseJson(false, 500, 'Something Wrong Happened');
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                logger($e->getMessage() . ' -- ' . $e->getLine() . ' -- ' . $e->getFile());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
        abort(405);
    }
    public function getPurchaseOrders(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalPurchaseOrders();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';

                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $purchaseOrders = $this->assetService->findPurchaseOrders($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $purchaseOrders = $this->assetService->findPurchaseOrders($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalPurchaseOrders($search);
                }
                // dd($purchaseOrders);
                if ($purchaseOrders) {
                    foreach ($purchaseOrders as $key => $purchaseOrder) {
                        $index++;
                        $nestedData['unique_id'] = '<a href="' . route('admin.po.view', $purchaseOrder->uuid) . '" class="edit_icon">' . $purchaseOrder->unique_id . '</a>';
                        // $nestedData['quotation_id'] = $purchaseOrder->quotations?->unique_id;
                        $nestedData['quotation_id'] = '<a href="' . route('admin.rfq.quotation.view', $purchaseOrder->quotations?->uuid) . '"  target="_blank" >' . $purchaseOrder->quotations?->unique_id . '</a>';
                        $nestedData['entity'] = $purchaseOrder->entity?->name;
                        $nestedData['asset_type'] = "";
                        $nestedData['po_date'] = Carbon::parse($purchaseOrder->po_date)->format('d-m-Y');
                        switch ($purchaseOrder->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;
                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }

                        $checkPurchaseOrderApproval = $this->assetService->checkPurchaseOrderApproval($purchaseOrder->id, auth()->user()->id);

                        if ($checkPurchaseOrderApproval && $checkPurchaseOrderApproval->status == '0') {
                            if (auth()->user()->canAny(['status-purchase-order'])) {
                                $nestedData['status'] = '<div class="action_sec">
                                    <div class="status_box">
                                        <a class="btn btn-outline-success text_green" onclick="poStatusChange(this, ' . $checkPurchaseOrderApproval->level . ')" href="javascript:void(0)" data-table="purchase_orders" data-userid="' . $purchaseOrder->user_id . '" data-uuid="' . $purchaseOrder->uuid . '" data-status="1"  data-level="' . $checkPurchaseOrderApproval->level . '"><i class="fa-solid fa-circle"></i> Approve</a>
                                        <a class="btn btn-outline-danger text_danger" onclick="poStatusChange(this, ' . $checkPurchaseOrderApproval->level . ')" href="javascript:void(0)" data-table="purchase_orders" data-userid="' . $purchaseOrder->user_id . '" data-uuid="' . $purchaseOrder->uuid . '" data-status="2"  data-level="' . $checkPurchaseOrderApproval->level . '"><i class="fa-solid fa-circle"></i> Reject</a>
                                    </div>
                                </div>';
                            } else {
                                $nestedData['status'] = '';
                            }
                        } else {
                            $lastApproval = PurchaseOrderApproval::where(['purchase_order_id' => $purchaseOrder->id])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();
                            $nestedData['status'] = '<span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title="' . $lastApproval?->comments . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span>';
                        }
                        //         if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $purchaseOrder->created_by) && ($purchaseOrder->status != '1' || ($purchaseOrder->status == '1' && auth()->user()->hasRole('super-admin')))) {
                        //     $nestedData['action'] .= '<a href="' . route('admin.po.edit', $purchaseOrder->uuid) . '" class="edit_icon h6" title="Edit"><i class="fa fa-pen" aria-hidden="true"></i></a>
                        //             <a href="javascript:;" class="edit_icon text-danger deleteData h6" data-table="purchase_orders" data-uuid="' . $purchaseOrder->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>';
                        // } else {
                        // }

                        $vendor_approval = 'NA';
                        if ($purchaseOrder->status == '1') {
                            if ($purchaseOrder->is_vendor_approved !== null) {
                                $vendor_approval = ($purchaseOrder->is_vendor_approved == '1') ? '<span class="text_green"><i class="fa-solid fa-circle mr-1"></i> Approved</span>' : '<span class="text_danger"><i class="fa-solid fa-circle mr-1"></i> Rejected</span>';

                                $vendor_approval .= ' <a href="javascript:void(0)" class="view-approval-rejection-comments-btn" data-approval-rejection-comments="' . htmlspecialchars($purchaseOrder->vendor_approval_rejection_comments, ENT_QUOTES, 'UTF-8') . '">
                                <i class="fas fa-info-circle info-icon view-remarks-btn" aria-hidden="true" title="View PO vendor approval and rejection comment"></i>
                                 </a>';
                            } else {
                                $vendor_approval = '<a href="javascript:void(0);" class="edit_icon text-primary h6 vendor_approval_btn" title="Send to vendor for approval" data-vendor-name="' . $purchaseOrder->vendor?->full_name . '" data-vendor-email="' . $purchaseOrder->vendor?->email . '" data-po-uuid="' . $purchaseOrder->uuid . '" data-po-unique-id="' . $purchaseOrder->unique_id . '"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>';
                            }
                        }
                        $nestedData['vendor_approval'] = $vendor_approval;

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        $nestedData['action'] .= '<a href="' . route('admin.po.invoice.list', $purchaseOrder->uuid) . '" class="edit_icon text-success h6" title="List Invoices"><i class="fas fa-file-invoice"></i></a>
                        <a href="javascript:void(0)" data-uuid="' . $purchaseOrder->uuid . '" class="edit_icon text-success printButton h6" title="Print"><i class="fas fa-print"></i></a>';
                        if (auth()->user()->canAny(['export-purchase-order'])) {
                            $nestedData['action'] .= ' <a href="' . route('admin.po.word.download', $purchaseOrder->uuid) . '" class="edit_icon text-primary h6" title="Word Download"><i class="fas fa-download"></i></a>';
                        }
                        if ((auth()->user()->hasRole('super-admin') || auth()->user()->id == $purchaseOrder->created_by)) {
                            if (auth()->user()->canAny(['edit-purchase-order']) && ($purchaseOrder->status === null || $purchaseOrder->status == '2' || $purchaseOrder->status == '3')) {
                                $nestedData['action'] .= '<a href="' . route('admin.po.edit', $purchaseOrder->uuid) . '" class="edit_icon h6" title="Edit"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            }
                            if (auth()->user()->canAny(['delete-purchase-order']) && ($purchaseOrder->status === null)) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData h6" data-table="purchase_orders" data-uuid="' . $purchaseOrder->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>';
                            }
                        }
                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getTnc(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalTermAndConditions();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'order';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $tncList = $this->assetService->findTermAndConditions($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $tncList = $this->assetService->findTermAndConditions($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalTermAndConditions($search);
                }
                // dd($tncList);
                if ($tncList) {
                    foreach ($tncList as $key => $tnc) {
                        $key++;
                        $nestedData['order'] = '<span class="sl_no">' . $key . '</span>';
                        $nestedData['name'] = ucfirst($tnc->name);
                        $nestedData['name'] .= '<input type="hidden" value="' . $tnc->id . '" class="tnc_id">';
                        $type = '';
                        if ($tnc->type) {
                            switch ($tnc->type) {
                                case 'terms-condition':
                                    $type = 'Terms & Conditions';
                                    break;
                                case 'other-conditions':
                                    $type = 'Other Conditions';
                                    break;
                            }
                        }
                        $nestedData['type'] = $type;
                        $nestedData['description'] = $tnc->description;
                        $nestedData['is_active'] = '<div class="status_box">';
                        if (auth()->user()->canAny(['status-terms-conditions'])) {
                            $nestedData['is_active'] .= '<div class="dropdown">
                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="' . (($tnc->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($tnc->is_active == '1') ? 'Active' : 'Inactive') . '
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                    <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="term_and_conditions" data-uuid="' . $tnc->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                    <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="term_and_conditions" data-uuid="' . $tnc->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                </ul>
                            </div>';
                        }
                        $nestedData['is_active'] .= '</div>';

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        $editUrl = route('admin.master-edit', ['type' => 'terms-condition', 'uuid' => $tnc->uuid]);

                        if (auth()->user()->canAny(['edit-terms-conditions'])) {
                            $nestedData['action'] .= '<a href="' . $editUrl . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-terms-conditions'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="term_and_conditions" data-uuid="' . $tnc->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getPoItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $quotationId = $request->quotationId ? uuidtoid($request->quotationId, 'quotations') : null;
                $quotation = $quotationId ? $this->assetService->findQuotationById($quotationId) : null;
                $filterCondition = ['quotation_id' => $quotationId];
                $quotationItems = $this->assetService->getAllQuotationItems($filterCondition);
                $totalData = $quotationItems->count();
                $totalFiltered = $totalData;
                $nestedData = [];
                $data = [];
                if ($quotationItems) {
                    foreach ($quotationItems as $k => $item) {
                        $nestedData['SrNo'] = '<div class="action_box">
                                <label for="item_id_' . $item->unique_id . '">' . ($k + 1) . ' <input type="checkbox" name="items[' . $k . '][item_id]" id="item_id_' . $item->id . '" value="' . $item->id . '" class="ml-5" checked></label>
                            </div>';
                        $nestedData['asset_type'] = '<div class="form-group">
                            <label>' . $item->assetType->name . '</label>
                            <input type="hidden" name="items[' . $k . '][asset_type_id]" id="asset_type_id_' . $k . '"value="' . $item->asset_type_id . '">
                            <input type="hidden" name="items[' . $k . '][category_id]" id="category_id_' . $k . '" value="' . $item->category_id . '">
                        </div>';
                        $nestedData['item'] = '<div class="form-group">
                            <label>' . ($item->asset?->asset_name ?? 'All') . '( ' . $item->unique_id . ' )</label>
                            <input type="hidden" name="items[' . $k . '][asset_id]" id="asset_id_' . $k . '" value="' . $item->asset_id . '">
                            <input type="hidden" name="items[' . $k . '][unique_id]" id="unique_id_' . $k . '" value="' . $item->unique_id . '">
                            <input type="hidden" name="items[' . $k . '][uuid]" class="form-control" id="uuid_' . $k . '" value="' . $item->uuid . '">
                        </div>';
                        $nestedData['specs'] = '<div class="form-group">
                            <label>' . $item->specifications . '</label>
                            <input type="hidden" name="items[' . $k . '][specifications]" id="specifications_' . $k . '" value="' . $item->specifications . '">
                        </div>';
                        $nestedData['qty'] = '<div class="form-group">
                            <input type="number" name="items[' . $k . '][quantity]" class="form-control" id="quantity_' . $k . '" value="' . $item->quantity . '">
                        </div>';
                        $nestedData['unit'] = '<div class="form-group">
                            <label>' . ucfirst($item->unit) . '</label>
                            <input type="hidden" name="items[' . $k . '][unit]" id="unit_' . $k . '"value="' . $item->unit . '">
                        </div>';
                        $nestedData['remarks'] = '<div class="form-group">
                            <textarea name="items[' . $k . '][description]" class="form-control" id="description_' . $k . '">' . $item->description . '</textarea>
                        </div>';
                        $nestedData['unit_rate'] = '<div class="form-group">
                            <input type="number" name="items[' . $k . '][amount]" class="form-control amount" id="amount_' . $k . '" data-index="' . $k . '" min="1" value="' . $item->amount . '" >
                        </div>';
                        $nestedData['total_amount'] = '<div class="form-group">
                            <label id="item_total_amount_label_before_discount_' . $k . '">₹' . number_format((float) ($item->quantity * $item->amount), 2, '.', ',') . '</label>
                        </div>';
                        $nestedData['discount'] = '<div class="form-group">
                            <div class="input-group">
                                <select class="form-control item_wise_discount_type" id="discount_type_' . $k . '"
                                    name="items[' . $k . '][discount_type]">
                                    <option value="percentage" ' . (($item->discount_type == 'percentage') ? 'selected' : '') . '>%</option>
                                    <option value="fixed" ' . (($item->discount_type == 'fixed') ? 'selected' : '') . '>Fixed</option>
                                </select>
                                <input type="number" name="items[' . $k . '][discount]" class="form-control item_wise_discount" id="discount_' . $k . '" data-index="' . $k . '" min="0" value="' . $item->discount . '">
                            </div>
                            <div class="mt-2">
                                <label id="item_discount_amount_label_' . $k . '">
                                    ' . (($item->discount_type == 'percentage') ? '- ' . $item->discount . '% ( ₹' . ($item->quantity * $item->amount * $item->discount / 100) . ' )' : '- ₹' . $item->discount) . '
                                </label>
                            </div>
                        </div>';
                        $discountedItemTotal = 0;
                        if ($item->discount) {
                            if ($item->discount_type == 'percentage') {
                                $discountedItemTotal = $item->quantity * ($item->amount - ($item->amount * $item->discount / 100));
                            } else {
                                $discountedItemTotal = $item->quantity * $item->amount - $item->discount;
                            }
                        } else {
                            $discountedItemTotal = $item->quantity * $item->amount;
                        }
                        $nestedData['tax'] = '<div class="form-group">
                            <div class="input-group">
                                <select class="form-control tax_type item_wise_tax_type" id="tax_type_' . $k . '"
                                    name="items[' . $k . '][tax_type]">
                                    <option value="CGST/SGST" ' . (($item->tax_type == 'CGST/SGST') ? 'selected' : '') . '>CGST/SGST</option>
                                    <option value="IGST" ' . (($item->tax_type == 'IGST') ? 'selected' : '') . '>IGST</option>
                                </select>
                                <input type="number" name="items[' . $k . '][tax]" class="form-control tax item_wise_tax" id="tax_' . $k . '" min="0" value="' . $item->tax . '">
                                <labe class="mt-10 ml-10">%</label>
                            </div>
                            <div class="mt-2">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <label id="item_tax_amount_label_' . $k . '">
                                            ' . ($item->tax ? '+ ' . $item->tax . '% ( ₹' . number_format((float) ($discountedItemTotal * $item->tax / 100), 2, '.', ',') . ' )' : '+ ₹0.00') . '
                                        </label>
                                    </div>
                                    <div class="col-sm-7">
                                        <div id="item_tax_break_label_' . $k . '"></div>
                                    </div>
                                </div>
                            </div>
                        </div>';
                        $nestedData['final_price'] = '<div class="form-group">
                            <label id="item_total_amount_label_' . $k . '">₹' . number_format((float) ($item->total_amount), 2, '.', ',') . '</label>
                            <input type="hidden" id="total_amount_' . $k . '" name="items[' . $k . '][total_amount]" data-index="' . $k . '" value="' . $item->total_amount . '">
                        </div>';

                        // $nestedData['action'] = '<div class="action_sec">
                        //     <div class="action_box">
                        //         <label for="item_id_' . $item->unique_id . '"><input type="checkbox" name="items[' . $k . '][item_id]" id="item_id_' . $item->id . '" value="' . $item->id . '" checked></label>
                        //     </div>
                        // </div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }

                    $summary = '';
                    $otherData = ['quotation_id' => '', 'vendor_id' => '', 'vendor_state' => '', 'delivery_state' => '', 'entity_id' => ''];
                    if ($quotation) {
                        $otherData['quotation_id'] = $quotation->id;
                        $otherData['vendor_id'] = $quotation->vendor_id;
                        $otherData['vendor_state'] = $quotation->vendorState?->id;
                        $otherData['delivery_state'] = $quotation->deliveryState?->id;
                        $otherData['entity_id'] = $quotation->rfq->requisition->entity_id;
                        $summary = '<tr>
                            <td colspan="6" rowspan="5" style="vertical-align:top;"></td>
                            <td>
                                <div class="form-group">
                                    <label>Total: </label>
                                </div>
                            </td>
                            <td colspan="2">
                                <div class="form-group">
                                    <label id="totalAmountLabel">₹' . number_format((float) ($quotation->item_total), 2, '.', ',') . '</label>
                                    <input type="hidden" id="total" name="item_total" value="' . $quotation->item_total . '">
                                </div>
                            </td>
                            <td colspan="4" rowspan="5"></td>
                        </tr>
                        <tr id="discount_section_view">
                            <td>
                                <div class="form-group">
                                    <label>Discount:</label>
                                </div>
                            </td>
                            <td colspan="2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <select class="form-control" id="discount_type"
                                            name="discount_type">
                                            <option value="percentage" ' . ($quotation->discount_type == 'percentage' ? 'selected' : '') . '>%</option>
                                            <option value="fixed" ' . ($quotation->discount_type == 'fixed' ? 'selected' : '') . '>Fixed</option>
                                        </select>
                                        <input type="number" name="discount" class="form-control discount" id="discount" min="0" value="' . $quotation->discount . '">
                                    </div>
                                    <div class="mt-2">
                                        <label id="discountAmountLabel">- ₹' . (($quotation->discount_type == 'percentage') ? number_format((float) ($quotation->item_total * $quotation->discount / 100), 2, '.', ',') : number_format((float) $quotation->discount, 2, '.', ',')) . '</label>
                                        <input type="hidden" id="totalDiscount" name="totalDiscount" value="' . (($quotation->discount_type == 'percentage') ? ($quotation->item_total * $quotation->discount / 100) : $quotation->discount) . '">
                                    </div>
                                </div>
                            </td>
                        </tr>';

                        $discountedTotal = 0;
                        if ($quotation && $quotation->discount) {
                            if ($quotation->discount_type == 'percentage') {
                                $discountedTotal = $quotation->item_total - ($quotation->item_total * $quotation->discount / 100);
                            } else {
                                $discountedTotal = $quotation->item_total - $quotation->discount;
                            }
                        } else {
                            $discountedTotal = $quotation?->item_total ?? 0;
                        }
                        $summary .= '<tr class="discountedTotalView">
                            <td>
                                <div class="form-group">
                                    <label>Discounted Total: </label>
                                </div>
                            </td>
                            <td colspan="2">
                                <div class="form-group">
                                    <label id="discountedTotalAmountLabel">₹' . number_format((float) $discountedTotal, 2, '.', ',') . '</label>
                                </div>
                            </td>
                        </tr>
                        <tr id="tax_section_view">
                            <td>
                                <div class="form-group">
                                    <label>Tax (' . $quotation->tax_type . ')</label>
                                </div>
                            </td>
                            <td colspan="2">
                                <div class="form-group">
                                    <div class="input-group">
                                        <select class="form-control tax_type" id="tax_type"
                                            name="tax_type">
                                            <option value="CGST/SGST" ' . (($quotation->tax_type == 'CGST/SGST') ? 'selected' : '') . '>CGST/SGST</option>
                                            <option value="IGST" ' . (($quotation->tax_type == 'IGST') ? 'selected' : '') . '>IGST</option>
                                        </select>
                                        <input type="number" name="tax" class="form-control tax" id="tax" min="0" value="' . $quotation->tax . '">
                                        <labe class="mt-10 ml-10">%</label>
                                    </div>
                                    <div class="mt-2">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <label id="taxAmountLabel">
                                                    ' . '+ ' . $quotation->tax . '% ( ₹' . number_format((float) ($discountedTotal * $quotation->tax / 100), 2, '.', ',') . ' )
                                                </label>
                                            </div>
                                            <div class="col-sm-7">
                                                <div id="taxBreakLabel">
                                                    <div><strong>CGST</strong>: ₹' . number_format((float) (($discountedTotal * $quotation->tax / 100) / 2), 2, '.', ',') . '</div><div><strong>SGST</strong>: ₹' . number_format(((float) ($discountedTotal * $quotation->tax / 100) / 2), 2, '.', ',') . '</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="form-group">
                                    <label>Grand Total:</label>
                                </div>
                            </td>
                            <td colspan="2">
                                <div class="form-group">
                                    <label id="grandTotalAmountLabel">₹' . number_format((float) $quotation->total_amount, 2, '.', ',') . '</label>
                                    <input type="hidden" name="total_amount" class="grand_total_amount" id="grandTotalAmount" value="' . $quotation->total_amount . '">
                                </div>
                            </td>
                        </tr>';
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                    "summary" => $summary,
                    "other" => $otherData,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getArnItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $poId = $request->po_id ? uuidtoid($request->po_id, 'purchase_orders') : null;
                // $purchaseOrder = $poId ? $this->assetService->findPoId($poId) : null;
                $filterCondition = ['purchase_order_id' => $poId];
                $poItems = $this->assetService->findPoItems($filterCondition);
                $totalData = $poItems->count();
                $totalFiltered = $totalData;
                $nestedData = [];
                $data = [];
                if ($poItems) {
                    foreach ($poItems as $k => $item) {
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['asset_type'] = '<div class="form-group">
                            <label>' . $item->assetType->name . '</label>
                            <input type="hidden" name="items[' . $k . '][asset_type_id]" id="asset_type_id_' . $k . '"value="' . $item->asset_type_id . '">
                            <input type="hidden" name="items[' . $k . '][category_id]" id="category_id_' . $k . '" value="' . $item->category_id . '">
                        </div>';
                        $nestedData['item'] = '<div class="form-group">
                            <label>' . ($item->asset?->asset_name ?? 'All') . '( ' . $item->unique_id . ' )</label>
                            <input type="hidden" name="items[' . $k . '][asset_id]" id="asset_id_' . $k . '" value="' . $item->asset_id . '">
                            <input type="hidden" name="items[' . $k . '][unique_id]" id="unique_id_' . $k . '" value="' . $item->unique_id . '">
                            <input type="hidden" name="items[' . $k . '][uuid]" class="form-control" id="uuid_' . $k . '" value="' . $item->uuid . '">
                        </div>';
                        $nestedData['unit'] = '<div class="form-group">
                            <label>' . $item->unit . '</label>
                            <input type="hidden" name="items[' . $k . '][unit]" id="unit_' . $k . '" value="' . $item->unit . '">
                        </div>';
                        $nestedData['po_qty'] = '<div class="form-group">
                            <input type="number" readonly name="items[' . $k . '][po_quantity]" class="form-control" id="po_quantity_' . $k . '" value="' . $item->quantity . '">
                        </div>';
                        $nestedData['remarks'] = '<div class="form-group">
                            <textarea name="items[' . $k . '][description]" class="form-control" id="description_' . $k . '">' . '</textarea>
                        </div>';
                        $nestedData['received_qty'] = '<div class="form-group">
                            <input type="number" name="items[' . $k . '][received_quantity]" class="form-control received_quantity" id="received_quantity_' . $k . '" data-index="' . $k . '" min="1" value="' . $item->quantity . '" >
                        </div>';
                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <input type="hidden" name="items[' . $k . '][specifications]" class="specifications" id="specifications_' . $k . '" value="' . $item->specifications . '" >
                                <input type="hidden" name="items[' . $k . '][amount]" class="amount" id="amount' . $k . '" value="' . $item->amount . '" >
                                <label for="item_id_' . $item->unique_id . '"><input type="checkbox" name="items[' . $k . '][item_id]" id="item_id_' . $item->id . '" value="' . $item->id . '" checked></label>
                            </div>
                        </div>';
                        //$nestedData['action'] = '';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getAssetReceiptNotes(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalAssetReceiptNotes();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];
                //dd($search);
                if (!$search) {
                    $assetReceiptNotes = $this->assetService->findAssetReceiptNotes($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assetReceiptNotes = $this->assetService->findAssetReceiptNotes($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalAssetReceiptNotes($search);
                }
                //dd($assetReceiptNotes);
                if ($assetReceiptNotes) {
                    foreach ($assetReceiptNotes as $key => $assetReceiptNote) {
                        //dd($assetReceiptNote->items->sum('received_quantity'));
                        $index++;
                        $nestedData['unique_id'] = '<a href="' . route('admin.arn.view', $assetReceiptNote->uuid) . '" class="edit_icon">' . $assetReceiptNote->unique_id . '</a>';

                        $nestedData['purchase_order_id'] = '<a href="' . route('admin.po.view', $assetReceiptNote->purchaseOrder?->uuid) . '" class="edit_icon"  target="_blank">' . $assetReceiptNote->purchaseOrder?->unique_id . '</a>';
                        $nestedData['challan_no'] = $assetReceiptNote->challan_no;
                        $nestedData['challan_date'] = $assetReceiptNote->challan_date ?? 'N/A';

                        // $nestedData['receiver_name'] = $assetReceiptNote->receiver?->first_name . " " . $assetReceiptNote->receiver?->last_name;

                        //$nestedData['receiver_name'] = $assetReceiptNote->receiver?->full_name;

                        $nestedData['receiver_name'] = '<a href="' . route('admin.employee.view', $assetReceiptNote->receiver?->uuid) . '"  target="_blank">' . $assetReceiptNote->receiver?->full_name . '</a>';

                        $nestedData['received_date'] = $assetReceiptNote->received_date;
                        $nestedData['receiver_location'] = $assetReceiptNote->location?->street_address;
                        $receivedQuantity = $assetReceiptNote->items->sum('received_quantity');
                        $returnQuantity = $assetReceiptNote->items->sum('return_quantity');
                        $remainingQuantity = $assetReceiptNote->items->sum('remaining_quantity');
                        $addedQuantity = $receivedQuantity - ($returnQuantity + $remainingQuantity);
                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        if (!$addedQuantity) {
                            if (auth()->user()->canAny(['edit-arn'])) {
                                $nestedData['action'] .= '<a href="' . route('admin.arn.edit', $assetReceiptNote->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            }

                            if (auth()->user()->canAny(['delete-arn'])) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="asset_receipt_notes" data-uuid="' . $assetReceiptNote->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                            }
                        }

                        $nestedData['action'] .= '</div></div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function updateRfqApprovalStatus(Request $request)
    {
        if ($request->ajax()) {
            /* $rfqData = $this->assetService->findRfqById($request->requestid);
            $currentData = [
                'request_id' => $request->requestid,
                'level' => $request->level,
                'status' => $request->status,
                'comments' => $request->comments ?? null
            ];
            $approveOrReject = ($request->status == "1")
                ? ["task_name" => "Quotation Approval", "task_description" => "A Quotation Has been approved", "type" => "approve-rfq"]
                : ["task_name" => "Quotation Rejection", "task_description" => "A Quotation Has been Rejected", "type" => "reject-rfq"];

            $isRecentActivityCreated = $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                'task_name' => $approveOrReject['task_name'],
                'task_description' => $approveOrReject['task_description'],
                'task_url' => 'modules/quotation/list',
                'added_by' => auth()->user()->id,
                'type' => $approveOrReject['type'],
                'related_id' => $request->requestid
            ]);


            $isApprovalUpdated = $this->assetService->createOrUpdateRfqApproval($currentData);
            if ($isApprovalUpdated) {
                return $this->responseJson(true, 200, 'RFQ approval status successfully updated', [
                    'redirect_url' => route('admin.rfq.quotations', $rfqData->uuid)
                ]);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }*/

            $status = (int) $request->status;
            $level = (int) $request->level;
            $rfqData = $this->assetService->findRfqById($request->requestid);
            // $approvalLevels = RfqApproval::where('request_id', $rfqData->id)->where('level', '<>', $level)->get();
            $approvalLevels = RfqApproval::where(['request_id' => $rfqData->id, 'user_id' => $request->userid])->where('level', '<>', $level)->get();
            $fullname = Auth::user()->first_name . " " . Auth::user()->last_name;
            if ($status == 1) {
                // $currentData = [
                //     'request_id' => $request->requestid,
                //     'level' => $level,
                //     'status' => $status,
                //     'comments' => $request->comments ?? null
                // ];

                $currentData = [
                    'request_id' => $request->requestid,
                    'user_id' => $request->userid,
                    'level' => $level,
                    'status' => $status,
                    'comments' => $request->comments ?? null
                ];
                $isApprovalUpdated = $this->assetService->createOrUpdateRfqApproval($currentData);
                if ($isApprovalUpdated) {
                    //$checkRfqApproval = $this->assetService->checkRfqApproval($request->requestid, null, ($level + 1));

                    $findNextUserId = RfqApproval::where(['request_id' => $rfqData->id, 'unique_id' => $request->uniqueid])->orderBy('id', 'desc')->first();
                    //dd($findNextUserId);
                    if ($findNextUserId) {

                        $checkRfqApproval = $this->assetService->checkRfqApproval($request->requestid, $findNextUserId->user_id, ($level + 1));
                        $data = false;
                        //dd($checkRfqApproval);
                        if ($checkRfqApproval) {
                            $nextData = [
                                'request_id' => $request->requestid,
                                'user_id' => $findNextUserId->user_id,
                                'level' => ($level + 1),
                                'status' => 0
                            ];
                            $isApprovalUpdatedNext = $this->assetService->createOrUpdateRfqApproval($nextData);

                            if ($isApprovalUpdatedNext) {
                                $data = $this->assetService->addOrUpdateRfq(['id' => $request->requestid], ['status' => 2]);
                            }
                        } else {
                            $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                                'task_name' => 'RFQ Approval',
                                'task_description' => 'A Quotation Has been approved',
                                'task_url' => 'modules/quotation/list',
                                'added_by' => auth()->user()->id,
                                'type' => 'approve-rfq',
                                'related_id' => $request->requestid
                            ]);
                            $data = $this->assetService->addOrUpdateRfq(['id' => $request->requestid], ['status' => $status]);
                        }

                        if ($data) {
                            $creatUserData = $this->userService->findUserById($rfqData->created_by);
                            $notiData = [
                                'form_name' => "#" . $rfqData->unique_id . " this RFQ has been approved by " . $fullname,
                                'rfq_uuid' => $rfqData->uuid,
                            ];
                            $creatUserData->notify(new RfqApproveNotification($notiData));
                            if ($checkRfqApproval) {
                                $nextLevelUser = $this->userService->findUserById($checkRfqApproval->user_id);
                                $nextLevelUserFullname = $nextLevelUser->first_name . " " . $nextLevelUser->last_name;
                                $notifyData = [
                                    'form_name' => $nextLevelUserFullname . " got a RFQ approval request for RFQ ID #" . $rfqData->unique_id,
                                    'rfq_uuid' => $rfqData->uuid,
                                ];
                                $creatUserData->notify(new RfqApproveNotification($notifyData));
                            }
                            foreach ($approvalLevels as $approvallevel) {
                                $userData = $this->userService->findUserById($approvallevel->user_id);

                                $userData->notify(new RfqApproveNotification($notiData));

                                /***** Next level notification *****/
                                if ($checkRfqApproval) {
                                    if ($approvallevel->level == ($level + 1)) {
                                        $notiData = [
                                            'form_name' => "You got a RFQ approval request for the ID #" . $rfqData->unique_id,
                                            'rfq_uuid' => $rfqData->uuid,
                                        ];
                                        $userData->notify(new RfqApproveNotification($notiData));

                                        $requestparam = (object) [
                                            'title' => "RFQ approval request",
                                            'body' => "You got a RFQ approval request for the ID #" . $rfqData->unique_id,
                                        ];
                                        $this->sendPushNotification($userData->id, $requestparam);
                                    } else {
                                        $userData->notify(new RfqApproveNotification($notifyData));
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                $currentData = [
                    'request_id' => $request->requestid,
                    'user_id' => $request->userid,
                    'level' => $level,
                    'status' => 2,
                    'comments' => $request->comments
                ];

                $this->assetService->addOrUpdateRecentActivity(['id' => null], [
                    'task_name' => 'RFQ Rejection',
                    'task_description' => 'A Quotation Has been Rejected',
                    'task_url' => 'modules/quotation/list',
                    'added_by' => auth()->user()->id,
                    'type' => 'reject-rfq',
                    'related_id' => $rfqData->id
                ]);
                //dd($currentData);
                $isApprovalUpdated = $this->assetService->createOrUpdateRfqApproval($currentData);
                if ($isApprovalUpdated) {
                    $data = $this->assetService->addOrUpdateRfq(['id' => $request->requestid], ['status' => $status]);
                    if ($data) {
                        $notiData = [
                            'form_name' => "#" . $rfqData->unique_id . " this RFQ has been rejected by " . $fullname,
                            'rfq_uuid' => $rfqData->uuid,
                        ];

                        $creatUserData = $this->userService->findUserById($rfqData->created_by);
                        $creatUserData->notify(new RfqApproveNotification($notiData));

                        foreach ($approvalLevels as $approvallevel) {
                            $userData = $this->userService->findUserById($approvallevel->user_id);
                            $userData->notify(new RfqApproveNotification($notiData));
                        }
                    }
                }
            }
            return $this->responseJson(true, 200, 'RFQ approval status successfully updated', [
                'redirect_url' => route('admin.rfq.quotations', $rfqData->uuid)
            ]);
        }
        abort(405);
    }


    // public function getInventories(Request $request)
    // {
    //     if ($request->ajax()) {
    //         try {
    //             $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');
    //             $filterConditions = ['asset_stock_id' => $asset_stock_id];
    //             $totalData = $this->assetStockService->findInventories($filterConditions)->count();
    //             $totalFiltered = $totalData;
    //             $limit = $request->input('length');
    //             $start = $request->input('start');
    //             $order = 'id';
    //             $dir = 'desc';
    //             $index = $start;
    //             $nestedData = [];
    //             $data = [];

    //             $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
    //             if ($inventories) {
    //                 foreach ($inventories as $k => $inventory) {
    //                     // dd($inventory);
    //                     $index++;
    //                     $nestedData['SrNo'] = $k + 1;
    //                     $nestedData['sl_no'] = $inventory->unique_id;
    //                     $nestedData['capacity_spec'] = $inventory->capacity_specs;
    //                     $nestedData['warranty_licence_date'] = $inventory->warranty_licence_date ? Carbon::parse($inventory->warranty_licence_date)->format('d-m-Y') : '';
    //                     ;
    //                     $nestedData['asset_condition'] = $inventory->asset_condition;
    //                     $nestedData['purchase_date'] = $inventory->purchase_date ? Carbon::parse($inventory->purchase_date)->format('d-m-Y') : '';
    //                     $nestedData['issued_to'] = $inventory->issue ? $inventory->issue->user->full_name : '';
    //                     $nestedData['issued_date'] = $inventory->issue ? Carbon::parse($inventory->issue->issued_date)->format('d-m-Y') : '';


    //                     //$btnText = $qrCodeSvg ? 'Regenerate' : 'Generate';
    //                     //$nestedData['generate_qr'] = $qrCodeSvg . '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '">' . $btnText . '</a>';


    //                     $qrCodeSvg = '';
    //                     $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';

    //                     $nestedData['generate_qr'] = $qrCodeSvg ?
    //                         '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
    //                     <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
    //                     '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


    //                     if($inventory->underMaintenance){
    //                         $statusClass = 'text_pending';
    //                         $statusText = 'Under Maintenance';
    //                     }elseif($inventory->dispose){
    //                         $statusClass = 'text-danger';
    //                         $statusText = 'Disposed';
    //                     }elseif($inventory->lease){
    //                         $statusClass = 'text-primary';
    //                         $statusText = 'Leased';
    //                     }elseif($inventory->issue){
    //                         $statusClass = 'text-primary';
    //                         $statusText = 'Issued';
    //                     }else{
    //                         $statusClass = 'text-success';
    //                         $statusText = 'In Stock';
    //                     }
    //                     $nestedData['status'] = '<div class="'.$statusClass.'">'.$statusText.'</div>';

    //                     $issueBtnText = (!$inventory->issue) ? 'Issue' : "Re-Issue";

    //                     $nestedData['action'] = '<div class="action_sec">';
    //                     if(!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease){
    //                         $nestedData['action'] .= '<a class="btn btn-blue btn-sm issue-btn"  data-issue_uuid="' . $inventory->issue?->uuid . '"  data-user_id="' . $inventory->issue?->user_id . '"  data-user_id="' . $inventory->issue?->user_id . '"  data-issued_date="' . $inventory->issue?->issued_date . '"  data-sl-no="' . $inventory->unique_id . '" data-asset-id="' . $inventory->asset_id . '"  data-inventory-id="' . $inventory->id . '"  data-expiry="' . $inventory->warranty_licence_date . '" href="javascript:void(0)"> ' . $issueBtnText . '</a>';
    //                     }

    //                     $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . $inventory->purchase_date . '" "  data-warranty_licence_date="' . $inventory->warranty_licence_date . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>
    //                                             ';
    //                     if(!$inventory->issue)
    //                         $nestedData['action'] .='<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
    //                                                     class="fa-solid fa-trash-can"></i></a>';
    //                     $nestedData['action'] .= '</div>';

    //                     $data[] = $nestedData;
    //                     $nestedData = [];
    //                 }
    //             }
    //             $jsonData = array(
    //                 "draw" => (int) $request->input('draw'),
    //                 "recordsTotal" => (int) $totalData,
    //                 "recordsFiltered" => (int) $totalFiltered,
    //                 "data" => $data,
    //             );

    //             return response()->json($jsonData);
    //         } catch (\Exception $e) {
    //             logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
    //             return $jsonData = array(
    //                 "draw" => (int) $request->input('draw'),
    //                 "recordsTotal" => (int) 0,
    //                 "recordsFiltered" => (int) 0,
    //                 "data" => []
    //             );
    //         }
    //     }
    //     abort(405);
    // }


    public function listInventoriesbk(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');

                $leaseId = uuidtoid($request->leaseUuid, 'lease_agreements');
                if ($leaseId) {
                    $findLeaseItems = LeaseItem::where('lease_id', $leaseId)->get();
                }

                $filterConditions = ['inventories.asset_stock_id' => $asset_stock_id];
                $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);

                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $backgroundClass = '';
                        $nestedData['background_class'] = $backgroundClass;

                        if ($inventory->lease)
                            $nestedData['background_class'] = 'light-yellow-background';

                        if ($inventory->issue)
                            $nestedData['background_class'] = 'green-background';

                        if ($inventory->underMaintenance)
                            $nestedData['background_class'] = 'red-background';

                        $nestedData['asset_sl_no'] = $inventory->asset?->asset_id;
                        $nestedData['purchase_entity'] = $inventory->assetStock?->arn?->purchaseOrder?->entity?->name;

                        $nestedData['user_entity'] = $inventory->issue?->user?->profile?->entity?->name;

                        $nestedData['asset_location'] = $inventory->assetStock?->location?->street_address;
                        $nestedData['description'] =  $inventory->asset?->asset_name;
                        $nestedData['model_no'] = $inventory->asset?->asset_name;
                        $nestedData['date_of_purchase'] =  Carbon::parse($inventory->purchase_date)->format('Y-m-d');


                        $purchaseDate = Carbon::parse($inventory->purchase_date);
                        $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                        $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                        $warranty_in_years = $diffInMonths / 12;
                        $nestedData['warranty_in_years'] = number_format($warranty_in_years, 1);
                        $nestedData['warranty_expire'] = Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d');
                        $currentDate = Carbon::now();
                        $age = $purchaseDate->diff($currentDate);
                        $nestedData['age_of_asset'] = $age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days';


                        $nestedData['unique_id'] = '<a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';
                        $employeeCode = $inventory->issue ? $inventory->issue?->user?->unique_id : '';
                        $employeeDetails = $inventory->issue ? $inventory->issue?->user?->full_name : '';
                        $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                        if ($inventory->lease) {
                            if ($inventory->lease->leaseAgreement->type == 'internal') {
                                $employeeCode = $inventory->lease?->leasedUser?->unique_id;
                                $employeeDetails = $inventory->lease?->leasedUser?->full_name;
                            } else {
                                $employeeCode = '';
                                $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                $employeeDetails .= '<strong>Name: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_name'] . '<br>';
                                $employeeDetails .= '<strong>Phone Number: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_phone'] . '<br>';
                                $employeeDetails .= '<strong>Email: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_email'] . '</div>';
                            }
                            $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                        }
                        $nestedData['employee_code'] =  $employeeCode;
                        $nestedData['employee_name'] = $employeeDetails;
                        $nestedData['designation'] =  $inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '';
                        $nestedData['sbu'] = $inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '';
                        $nestedData['division'] = $inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '';
                        $nestedData['user_location'] = $inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '';

                        $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';
                        $nestedData['asset_tag'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
                        <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
                            '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


                        $nestedData['previous_user'] = '';
                        $nestedData['issue_with_laptop'] = '';
                        $nestedData['date_of_scraping'] = $inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '';

                        $nestedData['scrap_rate'] = '';
                        $nestedData['scrap_vendor_details'] = '';


                        $nestedData['purchase_price'] = '';
                        $nestedData['vendor'] = $inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name;
                        $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                        $nestedData['invoice_no'] = $invoice_nos ? implode(', ', $invoice_nos) : '';
                        $nestedData['remark'] =  $inventory->issue ? $inventory->issue?->comments : '';
                        $nestedData['lost_stolen_year'] = '';
                        $nestedData['is_active'] = $inventory->is_active == '1' ? 'Active' : 'In-Active';
                        $nestedData['others_specifications'] = '';
                        $nestedData['purchase_date'] = Carbon::parse($inventory->purchase_date)->format('Y');
                        $nestedData['years_description'] = '';
                        $nestedData['specifications'] = $inventory->capacity_specs;
                        $nestedData['accessories_given_at_allotment_time'] = '';
                        $nestedData['allotment_date'] = $allocationDate;
                        $issueBtnText = (!$inventory->issue) ? 'Issue' : "Correction";
                        $nestedData['action'] = '<div class="action_sec">';
                        if (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }
                            $nestedData['action'] .= '<a class="btn btn-blue btn-sm issue-btn"  data-comments="' . $inventory->issue?->comments . '"  data-issue_uuid="' . $inventory->issue?->uuid . '"   data-user_id="' . $inventory->issue?->user_id . '"  data-issued_date="' . $inventory->issue?->issued_date . '"  data-sl-no="' . $inventory->unique_id . '" data-asset-id="' . $inventory->asset_id . '"  data-asset-uuid="' . $inventory->asset?->uuid . '"   data-inventory-uuid="' . $inventory->uuid . '" data-asset-name="' . $inventory->asset?->asset_name . '" data-inventory-id="' . $inventory->id . '"  data-expiry="' . $inventory->warranty_licence_date . '"  data-issued-image="' . $issuedImage . '" href="javascript:void(0)"> ' . $issueBtnText . '</a>';
                        }

                        if ((!$inventory->issue) && (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease))
                            $nestedData['action'] .= '<a class="btn btn-blue btn-sm transfer-btn"  data-inventory_id="' . $inventory->id . '"  data-asset_stock_id="' . $inventory->asset_stock_id . '" data-asset_stock_uuid="' . $inventory->assetStock?->uuid . '">Transfer </a>';

                        $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . Carbon::parse($inventory->purchase_date)->format('Y-m-d') . '" "  data-warranty_licence_date="' . Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>';
                        if (!$inventory->issue)
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
                                                        class="fa-solid fa-trash-can"></i></a>';
                        $nestedData['action'] .= '</div>';





                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }





    public function listInventoriesbk1(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');

                $filterConditions = ['inventories.asset_stock_id' => $asset_stock_id];
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];

                if ($request->leaseUuid != null) {
                    //dd("sdfghjkl");
                    $leaseId = uuidtoid($request->leaseUuid, 'lease_agreements');
                    $findInventoryIds = LeaseItem::where('lease_id', $leaseId)->pluck('inventory_id');
                    $totalData = $this->assetStockService->findInventories($filterConditions)->whereIn('id', $findInventoryIds)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false)->whereIn('id', $findInventoryIds);
                } else {
                    // dd("test");
                    $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
                }
                $totalFiltered = $totalData;

                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $backgroundClass = '';

                        $nestedData['background_class'] = $backgroundClass;


                        if (($request->leaseUuid == null)) {
                            if ($inventory->lease)
                                $nestedData['background_class'] = 'light-yellow-background';

                            if ($inventory->issue)
                                $nestedData['background_class'] = 'green-background';

                            if ($inventory->underMaintenance)
                                $nestedData['background_class'] = 'red-background';
                        }


                        $nestedData['asset_sl_no'] = $inventory->asset?->asset_id;
                        $nestedData['purchase_entity'] = $inventory->assetStock?->arn?->purchaseOrder?->entity?->name;

                        // $nestedData['user_entity'] = $inventory->issue?->user?->profile?->entity?->name;

                        $nestedData['user_entity'] = $inventory->lease?->leasedUser?->profile?->entity?->name;

                        $nestedData['asset_location'] = $inventory->assetStock?->location?->street_address;
                        $nestedData['description'] =  $inventory->asset?->asset_name;
                        $nestedData['model_no'] = $inventory->asset?->asset_name;
                        $nestedData['date_of_purchase'] =  Carbon::parse($inventory->purchase_date)->format('Y-m-d');


                        $purchaseDate = Carbon::parse($inventory->purchase_date);
                        $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                        $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                        $warranty_in_years = $diffInMonths / 12;
                        $nestedData['warranty_in_years'] = number_format($warranty_in_years, 1);
                        $nestedData['warranty_expire'] = Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d');
                        $currentDate = Carbon::now();
                        $age = $purchaseDate->diff($currentDate);
                        $nestedData['age_of_asset'] = $age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days';


                        $nestedData['unique_id'] = '<a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';
                        $employeeCode = $inventory->issue ? $inventory->issue?->user?->unique_id : '';
                        $employeeDetails = $inventory->issue ? $inventory->issue?->user?->full_name : '';
                        $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                        if ($inventory->lease) {
                            if ($inventory->lease->leaseAgreement->type == 'internal') {
                                $employeeCode = $inventory->lease?->leasedUser?->unique_id;
                                $employeeDetails = $inventory->lease?->leasedUser?->full_name;
                            } else {
                                $employeeCode = '';
                                $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                $employeeDetails .= '<strong>Name: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_name'] . '<br>';
                                $employeeDetails .= '<strong>Phone Number: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_phone'] . '<br>';
                                $employeeDetails .= '<strong>Email: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_email'] . '</div>';
                            }
                            $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                        }
                        $nestedData['employee_code'] =  $employeeCode;
                        $nestedData['employee_name'] = $employeeDetails;
                        $nestedData['designation'] =  $inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '';
                        $nestedData['sbu'] = $inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '';
                        $nestedData['division'] = $inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '';
                        $nestedData['user_location'] = $inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '';

                        $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';
                        $nestedData['asset_tag'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
                        <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
                            '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


                        $nestedData['previous_user'] = '';
                        $nestedData['issue_with_laptop'] = '';
                        $nestedData['date_of_scraping'] = $inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '';

                        $nestedData['scrap_rate'] = '';
                        $nestedData['scrap_vendor_details'] = '';


                        $nestedData['purchase_price'] = '';
                        $nestedData['vendor'] = $inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name;
                        $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                        $nestedData['invoice_no'] = $invoice_nos ? implode(', ', $invoice_nos) : '';
                        $nestedData['remark'] =  $inventory->issue ? $inventory->issue?->comments : '';
                        $nestedData['lost_stolen_year'] = '';
                        $nestedData['is_active'] = $inventory->is_active == '1' ? 'Active' : 'In-Active';
                        $nestedData['others_specifications'] = '';
                        $nestedData['purchase_date'] = Carbon::parse($inventory->purchase_date)->format('Y');
                        $nestedData['years_description'] = '';
                        $nestedData['specifications'] = $inventory->capacity_specs;
                        $nestedData['accessories_given_at_allotment_time'] = '';
                        $nestedData['allotment_date'] = $allocationDate;
                        // $issueBtnText = (!$inventory->issue) ? 'Issue' : "Correction";


                        $issueBtnText = (!$inventory->issue) ? 'Allocate' : "Correction";




                        $nestedData['action'] = '<div class="action_sec">';
                        // if (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease) {
                        //     $issuedImage = '';
                        //     if ($inventory->issue?->issuedImage->count()) {
                        //         $issuedImage = $inventory->issue->issuedImage[0]->file;
                        //     }
                        //     $nestedData['action'] .= '<a class="btn btn-blue btn-sm issue-btn"  data-comments="' . $inventory->issue?->comments . '"  data-issue_uuid="' . $inventory->issue?->uuid . '"   data-user_id="' . $inventory->issue?->user_id . '"  data-issued_date="' . $inventory->issue?->issued_date . '"  data-sl-no="' . $inventory->unique_id . '" data-asset-id="' . $inventory->asset_id . '"  data-asset-uuid="' . $inventory->asset?->uuid . '"   data-inventory-uuid="' . $inventory->uuid . '" data-asset-name="' . $inventory->asset?->asset_name . '" data-inventory-id="' . $inventory->id . '"  data-expiry="' . $inventory->warranty_licence_date . '"  data-issued-image="' . $issuedImage . '" href="javascript:void(0)"> ' . $issueBtnText . '</a>';
                        // }
                        // dd($inventory->leases->where('lease_id',2)->first());
                        if (!$inventory->underMaintenance && !$inventory->dispose) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }

                            if ($request->leaseUuid != null) {
                                // dd($inventory->leases->where('lease_id',$leaseId)->first());
                                switch ($inventory->leases->where('lease_id', $leaseId)->first()?->is_completed) {
                                    case '0':
                                        $itemStatusText = 'Allocated';
                                        $itemStatusClass = 'text_blue';
                                        break;
                                    case '1':
                                        $itemStatusText = 'Completed';
                                        $itemStatusClass = 'text_green';
                                        break;
                                }

                                if ($inventory?->lease?->user_id != null) {
                                    $nestedData['action'] .= $inventory->leases->where('lease_id', $leaseId)->first()?->is_completed;
                                    if ($inventory->leases->where('lease_id', $leaseId)->first()?->is_completed == '0') {
                                        $nestedData['action'] .= '<div class="dropdown">';
                                        $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                        $nestedData['action'] .= '</button>';
                                        $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';
                                        $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($inventory->leases->where('lease_id', $leaseId)->first()->user_id != null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $inventory->leases->where('lease_id', $leaseId)->first()?->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Allocate</a></li>';
                                        $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($inventory->leases->where('lease_id', $leaseId)->first()->user_id == null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $inventory->leases->where('lease_id', $leaseId)->first()?->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Unallocate</a></li>';
                                        $nestedData['action'] .= '<li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $inventory->leases->where('lease_id', $leaseId)->first()?->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Completed</a></li>';
                                        $nestedData['action'] .= '</ul>';
                                        $nestedData['action'] .= '</div>';
                                    } else {

                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    }
                                } else {

                                    if ($inventory->leases->where('lease_id', $leaseId)->first()?->leaseAgreement?->type == 'internal') {
                                        $nestedData['action'] .= '<a href="javascript:void(0)" class="' . ($inventory->leases->where('lease_id', $leaseId)->first()?->leasedUser ? '' : 'lease_item') . '" data-lease_uuid="' . $inventory->leases->where('lease_id', $leaseId)->first()?->leaseAgreement?->uuid . '" data-inventory_id="' . $inventory->leases->where('lease_id', $leaseId)->first()?->inventory_id . '" data-lease_item_uuid="' . $inventory->leases->where('lease_id', $leaseId)->first()?->uuid . '"  data-issued-image="' . $issuedImage . '" data-to_entity="' . $inventory->leases->where('lease_id', $leaseId)->first()?->leaseAgreement?->to_entity_id . '">';
                                        $nestedData['action'] .= $inventory->leases->where('lease_id', $leaseId)->first()?->leasedUser ? 'Allocated' : 'Allocate';
                                        $nestedData['action'] .= '</a>';
                                        //$nestedData['action'] .= '<a class="btn btn-blue btn-sm lease_item"  data-to_entity="' . $inventory->leases->where('lease_id',$leaseId)->first()?->leaseAgreement?->to_entity_id . '"  data-inventory_id="' . $inventory->id . '"  data-lease_uuid="' . $inventory->lease?->leaseAgreement?->uuid . '"   data-lease_item_uuid="' . $inventory->lease?->uuid . '"     data-issued-image="' . $issuedImage . '" href="javascript:void(0)"> ' . $issueBtnText . '</a>';
                                    }
                                }
                            }
                        }

                        if ($request->leaseUuid == null) {
                            if ((!$inventory->issue) && (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease))
                                $nestedData['action'] .= '<a class="btn btn-blue btn-sm transfer-btn"  data-inventory_id="' . $inventory->id . '"  data-asset_stock_id="' . $inventory->asset_stock_id . '" data-asset_stock_uuid="' . $inventory->assetStock?->uuid . '">Transfer </a>';

                            $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . Carbon::parse($inventory->purchase_date)->format('Y-m-d') . '" "  data-warranty_licence_date="' . Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            if (!$inventory->issue)
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
                                                        class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div>';





                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }





    public function listInventoriesbk2(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');

                $filterConditions = ['inventories.asset_stock_id' => $asset_stock_id];
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];

                if ($request->leaseUuid != null) {
                    $leaseId = uuidtoid($request->leaseUuid, 'lease_agreements');
                    $findInventoryIds = LeaseItem::where('lease_id', $leaseId)->pluck('inventory_id');
                    $totalData = $this->assetStockService->findInventories($filterConditions)->whereIn('id', $findInventoryIds)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false)->whereIn('id', $findInventoryIds);
                } else {
                    $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
                }
                $totalFiltered = $totalData;

                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $backgroundClass = '';
                        $nestedData['background_class'] = $backgroundClass;

                        if (($request->leaseUuid == null)) {
                            if ($inventory->lease)
                                $nestedData['background_class'] = 'light-yellow-background';

                            // if ($inventory->issue)
                            //     $nestedData['background_class'] = 'green-background';

                            if ($inventory->underMaintenance)
                                $nestedData['background_class'] = 'red-background';
                        }


                        $nestedData['asset_sl_no'] = $inventory->asset?->asset_id;
                        $nestedData['purchase_entity'] = $inventory->assetStock?->arn?->purchaseOrder?->entity?->name;

                        // $nestedData['user_entity'] = $inventory->issue?->user?->profile?->entity?->name;

                        $findLeaseItem = LeaseItem::where('inventory_id', $inventory->id)->orderBy('id', 'desc')->first();

                        $nestedData['user_entity'] = '';
                        // if ($request->leaseUuid != null)
                        if ($inventory->lease)
                            $nestedData['user_entity'] = $inventory->inventoryLeases($findLeaseItem->id)?->leasedUser?->profile?->entity?->name ?? '';

                        $nestedData['asset_location'] = $inventory->assetStock?->location?->street_address;
                        $nestedData['description'] =  $inventory->asset?->asset_name;
                        $nestedData['model_no'] = $inventory->asset?->asset_name;
                        $nestedData['date_of_purchase'] =  Carbon::parse($inventory->purchase_date)->format('Y-m-d');


                        $purchaseDate = Carbon::parse($inventory->purchase_date);
                        $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                        $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                        $warranty_in_years = $diffInMonths / 12;
                        $nestedData['warranty_in_years'] = number_format($warranty_in_years, 1);
                        $nestedData['warranty_expire'] = Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d');
                        $currentDate = Carbon::now();
                        $age = $purchaseDate->diff($currentDate);
                        $nestedData['age_of_asset'] = $age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days';


                        $nestedData['unique_id'] = '<a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';



                        $employeeCode = '';
                        $employeeDetails = '';
                        // if ($request->leaseUuid != null) {
                        //     $leaseItem = $inventory->inventoryLeases($leaseId);
                        //     $employeeCode = ($leaseItem->user_id != null && $leaseItem->is_completed == 0) ? $leaseItem->leasedUser?->unique_id : '';
                        //     $employeeDetails = ($leaseItem->user_id != null && $leaseItem->is_completed == 0) ? $leaseItem->leasedUser?->full_name : '';
                        // }




                        $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                        if ($inventory->lease) {
                            if ($inventory->lease->leaseAgreement->type == 'internal') {
                                $employeeCode = $inventory->lease?->leasedUser?->unique_id;
                                $employeeDetails = $inventory->lease?->leasedUser?->full_name;
                            } else {
                                $employeeCode = '';
                                $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                $employeeDetails .= '<strong>Name: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_name'] . '<br>';
                                $employeeDetails .= '<strong>Phone Number: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_phone'] . '<br>';
                                $employeeDetails .= '<strong>Email: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_email'] . '</div>';
                            }
                            $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                        }
                        $nestedData['employee_code'] =  $employeeCode;
                        $nestedData['employee_name'] = $employeeDetails;

                        $nestedData['designation'] =  $inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '';
                        $nestedData['sbu'] = $inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '';
                        $nestedData['division'] = $inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '';
                        $nestedData['user_location'] = $inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '';

                        $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';
                        $nestedData['asset_tag'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
                        <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
                            '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


                        $nestedData['previous_user'] = '';
                        $nestedData['issue_with_laptop'] = '';
                        $nestedData['date_of_scraping'] = $inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '';

                        $nestedData['scrap_rate'] = '';
                        $nestedData['scrap_vendor_details'] = '';


                        $nestedData['purchase_price'] = '';
                        $nestedData['vendor'] = $inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name;
                        $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                        $nestedData['invoice_no'] = $invoice_nos ? implode(', ', $invoice_nos) : '';
                        $nestedData['remark'] =  $inventory->issue ? $inventory->issue?->comments : '';
                        $nestedData['lost_stolen_year'] = '';
                        $nestedData['is_active'] = $inventory->is_active == '1' ? 'Active' : 'In-Active';
                        $nestedData['others_specifications'] = '';
                        $nestedData['purchase_date'] = Carbon::parse($inventory->purchase_date)->format('Y');
                        $nestedData['years_description'] = '';
                        $nestedData['specifications'] = $inventory->capacity_specs;
                        $nestedData['accessories_given_at_allotment_time'] = '';
                        $nestedData['allotment_date'] = $allocationDate;
                        // $issueBtnText = (!$inventory->issue) ? 'Issue' : "Correction";


                        $issueBtnText = (!$inventory->issue) ? 'Allocate' : "Correction";




                        $nestedData['action'] = '<div class="action_sec">';
                        if (!$inventory->underMaintenance && !$inventory->dispose) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }

                            if ($request->leaseUuid != null) {
                                $leaseItem = $inventory->inventoryLeases($leaseId);

                                if ($leaseItem) {
                                    // switch ($leaseItem->is_completed) {
                                    //     case '0':
                                    //         $itemStatusText = 'Allocated';
                                    //         $itemStatusClass = 'text_blue';
                                    //         break;
                                    //     case '1':
                                    //         $itemStatusText = 'Completed';
                                    //         $itemStatusClass = 'text_green';
                                    //         break;
                                    // }

                                    $itemStatusText = 'Action';
                                    $itemStatusClass = '';
                                    if ($leaseItem->user_id != null && $leaseItem->is_completed == '0') {
                                        $itemStatusText = 'Allocated';
                                        $itemStatusClass = 'text_blue';
                                    }
                                    if ($leaseItem->is_completed == '1') {
                                        $itemStatusText = 'Completed';
                                        $itemStatusClass = 'text_green';
                                    }




                                    // if ($leaseItem->user_id != null) {
                                    //     if ($leaseItem->is_completed == '0') {
                                    //         $nestedData['action'] .= '<div class="dropdown">';
                                    //         $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //         $nestedData['action'] .= '</button>';
                                    //         $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id != null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Allocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id == null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Unallocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Completed</a></li>';
                                    //         $nestedData['action'] .= '</ul>';
                                    //         $nestedData['action'] .= '</div>';
                                    //     } else {
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //     }
                                    // } else {
                                    //     if ($leaseItem->leaseAgreement?->type == 'internal') {
                                    //         $nestedData['action'] .= '<a href="javascript:void(0)" class="' . ($leaseItem->leasedUser ? '' : 'lease_item') . '" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-issued-image="' . $issuedImage . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '">';
                                    //         $nestedData['action'] .= $leaseItem->leasedUser ? 'Allocated' : 'Allocate';
                                    //         $nestedData['action'] .= '</a>';
                                    //     }
                                    // }





                                    if ($leaseItem->is_completed == '0') {
                                        $nestedData['action'] .= '<div class="dropdown">';
                                        $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                        $nestedData['action'] .= '</button>';
                                        $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';

                                        // Allocate option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_blue ' . (($leaseItem->user_id != null || $leaseItem->leaseAgreement?->type != 'internal') ? 'disabled' : '') . '" onclick="leaseStatusChange(this)" href="javascript:void(0)" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '" data-status="0">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Allocate';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        // Unallocate option
                                        if ($leaseItem->user_id != null) {
                                            $nestedData['action'] .= '<li>';
                                            $nestedData['action'] .= '<a class="dropdown-item text_blue" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0">';
                                            $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Unallocate';
                                            $nestedData['action'] .= '</a>';
                                            $nestedData['action'] .= '</li>';
                                        }

                                        // Complete option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Complete';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        $nestedData['action'] .= '</ul>';
                                        $nestedData['action'] .= '</div>';
                                    } else {
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    }
                                }
                            }
                        }

                        if ($request->leaseUuid == null) {
                            if ((!$inventory->issue) && (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease))
                                $nestedData['action'] .= '<a class="btn btn-blue btn-sm transfer-btn"  data-inventory_id="' . $inventory->id . '"  data-asset_stock_id="' . $inventory->asset_stock_id . '" data-asset_stock_uuid="' . $inventory->assetStock?->uuid . '">Transfer </a>';

                            $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . Carbon::parse($inventory->purchase_date)->format('Y-m-d') . '" "  data-warranty_licence_date="' . Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            if (!$inventory->issue)
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
                                                        class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div>';





                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }




    public function listInventoriesbk3(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');

                $filterConditions = ['inventories.asset_stock_id' => $asset_stock_id];
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];

                if ($request->leaseUuid != null) {
                    //dd("sdfghjkl");
                    $leaseId = uuidtoid($request->leaseUuid, 'lease_agreements');
                    $findInventoryIds = LeaseItem::where('lease_id', $leaseId)->pluck('inventory_id');
                    $totalData = $this->assetStockService->findInventories($filterConditions)->whereIn('id', $findInventoryIds)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false)->whereIn('id', $findInventoryIds);
                } else {
                    // dd("test");
                    $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
                }
                $totalFiltered = $totalData;

                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $backgroundClass = '';

                        $nestedData['background_class'] = $backgroundClass;


                        if (($request->leaseUuid == null)) {
                            if ($inventory->lease)
                                $nestedData['background_class'] = 'light-yellow-background';

                            if ($inventory->issue)
                                $nestedData['background_class'] = 'green-background';

                            if ($inventory->underMaintenance)
                                $nestedData['background_class'] = 'red-background';
                        }


                        $nestedData['asset_sl_no'] = $inventory->asset?->asset_id;
                        $nestedData['purchase_entity'] = $inventory->assetStock?->arn?->purchaseOrder?->entity?->name;

                        // $nestedData['user_entity'] = $inventory->issue?->user?->profile?->entity?->name;

                        $nestedData['user_entity'] = $inventory->lease?->leasedUser?->profile?->entity?->name;

                        $nestedData['asset_location'] = $inventory->assetStock?->location?->street_address;
                        $nestedData['description'] =  $inventory->asset?->asset_name;
                        $nestedData['model_no'] = $inventory->asset?->asset_name;
                        $nestedData['date_of_purchase'] =  Carbon::parse($inventory->purchase_date)->format('Y-m-d');


                        $purchaseDate = Carbon::parse($inventory->purchase_date);
                        $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                        $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                        $warranty_in_years = $diffInMonths / 12;
                        $nestedData['warranty_in_years'] = number_format($warranty_in_years, 1);
                        $nestedData['warranty_expire'] = Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d');
                        $currentDate = Carbon::now();
                        $age = $purchaseDate->diff($currentDate);
                        $nestedData['age_of_asset'] = $age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days';


                        $nestedData['unique_id'] = '<a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';
                        $employeeCode = $inventory->issue ? $inventory->issue?->user?->unique_id : '';
                        $employeeDetails = $inventory->issue ? $inventory->issue?->user?->full_name : '';
                        $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                        if ($inventory->lease) {
                            if ($inventory->lease->leaseAgreement->type == 'internal') {
                                $employeeCode = $inventory->lease?->leasedUser?->unique_id;
                                $employeeDetails = $inventory->lease?->leasedUser?->full_name;
                            } else {
                                $employeeCode = '';
                                $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                $employeeDetails .= '<strong>Name: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_name'] . '<br>';
                                $employeeDetails .= '<strong>Phone Number: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_phone'] . '<br>';
                                $employeeDetails .= '<strong>Email: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_email'] . '</div>';
                            }
                            $allocationDate = Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y');
                        }
                        $nestedData['employee_code'] =  $employeeCode;
                        $nestedData['employee_name'] = $employeeDetails;
                        $nestedData['designation'] =  $inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '';
                        $nestedData['sbu'] = $inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '';
                        $nestedData['division'] = $inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '';
                        $nestedData['user_location'] = $inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '';

                        $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';
                        $nestedData['asset_tag'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
                        <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
                            '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


                        $nestedData['previous_user'] = '';
                        $nestedData['issue_with_laptop'] = '';
                        $nestedData['date_of_scraping'] = $inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '';

                        $nestedData['scrap_rate'] = '';
                        $nestedData['scrap_vendor_details'] = '';


                        $nestedData['purchase_price'] = '';
                        $nestedData['vendor'] = $inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name;
                        $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                        $nestedData['invoice_no'] = $invoice_nos ? implode(', ', $invoice_nos) : '';
                        $nestedData['remark'] =  $inventory->issue ? $inventory->issue?->comments : '';
                        $nestedData['lost_stolen_year'] = '';
                        $nestedData['is_active'] = $inventory->is_active == '1' ? 'Active' : 'In-Active';
                        $nestedData['others_specifications'] = '';
                        $nestedData['purchase_date'] = Carbon::parse($inventory->purchase_date)->format('Y');
                        $nestedData['years_description'] = '';
                        $nestedData['specifications'] = $inventory->capacity_specs;
                        $nestedData['accessories_given_at_allotment_time'] = '';
                        $nestedData['allotment_date'] = $allocationDate;
                        // $issueBtnText = (!$inventory->issue) ? 'Issue' : "Correction";


                        $issueBtnText = (!$inventory->issue) ? 'Allocate' : "Correction";




                        $nestedData['action'] = '<div class="action_sec">';
                        if (!$inventory->underMaintenance && !$inventory->dispose) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }

                            if ($request->leaseUuid != null) {
                                $leaseItem = $inventory->inventoryLeases($leaseId);

                                if ($leaseItem) {
                                    // switch ($leaseItem->is_completed) {
                                    //     case '0':
                                    //         $itemStatusText = 'Allocated';
                                    //         $itemStatusClass = 'text_blue';
                                    //         break;
                                    //     case '1':
                                    //         $itemStatusText = 'Completed';
                                    //         $itemStatusClass = 'text_green';
                                    //         break;
                                    // }

                                    $itemStatusText = 'Action';
                                    $itemStatusClass = '';
                                    if ($leaseItem->user_id != null && $leaseItem->is_completed == '0') {
                                        $itemStatusText = 'Allocated';
                                        $itemStatusClass = 'text_blue';
                                    }
                                    if ($leaseItem->is_completed == '1') {
                                        $itemStatusText = 'Completed';
                                        $itemStatusClass = 'text_green';
                                    }




                                    // if ($leaseItem->user_id != null) {
                                    //     if ($leaseItem->is_completed == '0') {
                                    //         $nestedData['action'] .= '<div class="dropdown">';
                                    //         $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //         $nestedData['action'] .= '</button>';
                                    //         $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id != null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Allocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id == null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Unallocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Completed</a></li>';
                                    //         $nestedData['action'] .= '</ul>';
                                    //         $nestedData['action'] .= '</div>';
                                    //     } else {
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //     }
                                    // } else {
                                    //     if ($leaseItem->leaseAgreement?->type == 'internal') {
                                    //         $nestedData['action'] .= '<a href="javascript:void(0)" class="' . ($leaseItem->leasedUser ? '' : 'lease_item') . '" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-issued-image="' . $issuedImage . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '">';
                                    //         $nestedData['action'] .= $leaseItem->leasedUser ? 'Allocated' : 'Allocate';
                                    //         $nestedData['action'] .= '</a>';
                                    //     }
                                    // }





                                    if ($leaseItem->is_completed == '0') {
                                        $nestedData['action'] .= '<div class="dropdown">';
                                        $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                        $nestedData['action'] .= '</button>';
                                        $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';

                                        // Allocate option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_blue ' . (($leaseItem->user_id != null || $leaseItem->leaseAgreement?->type != 'internal') ? 'disabled' : '') . '" onclick="leaseStatusChange(this)" href="javascript:void(0)" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '" data-status="0">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Allocate';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        // Unallocate option
                                        if ($leaseItem->user_id != null) {
                                            $nestedData['action'] .= '<li>';
                                            $nestedData['action'] .= '<a class="dropdown-item text_blue" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0">';
                                            $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Unallocate';
                                            $nestedData['action'] .= '</a>';
                                            $nestedData['action'] .= '</li>';
                                        }

                                        // Complete option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Complete';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        $nestedData['action'] .= '</ul>';
                                        $nestedData['action'] .= '</div>';
                                    } else {
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    }
                                }
                            }
                        }

                        if ($request->leaseUuid == null) {
                            if ((!$inventory->issue) && (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease))
                                $nestedData['action'] .= '<a class="btn btn-blue btn-sm transfer-btn"  data-inventory_id="' . $inventory->id . '"  data-asset_stock_id="' . $inventory->asset_stock_id . '" data-asset_stock_uuid="' . $inventory->assetStock?->uuid . '">Transfer </a>';

                            $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . Carbon::parse($inventory->purchase_date)->format('Y-m-d') . '" "  data-warranty_licence_date="' . Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            if (!$inventory->issue)
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
                                                        class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div>';





                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function listInventories(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');

                $filterConditions = ['inventories.asset_stock_id' => $asset_stock_id];
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];

                if ($request->leaseUuid != null) {
                    $leaseId = uuidtoid($request->leaseUuid, 'lease_agreements');
                    $findInventoryIds = LeaseItem::where('lease_id', $leaseId)->pluck('inventory_id');
                    $totalData = $this->assetStockService->findInventories($filterConditions)->whereIn('id', $findInventoryIds)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false)->whereIn('id', $findInventoryIds);
                    // dd($leaseId,$findInventoryIds,$inventories);
                } else {
                    $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                    $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
                }
                $totalFiltered = $totalData;

                // dd($inventories);
                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $backgroundClass = '';

                        $nestedData['background_class'] = $backgroundClass;

                        $allocationDate = '';
                        if (($request->leaseUuid == null)) {
                            if ($inventory->lease)
                                $nestedData['background_class'] = 'light-yellow-background';

                            // if ($inventory->issue)
                            //     $nestedData['background_class'] = 'green-background';

                            if ($inventory->underMaintenance)
                                $nestedData['background_class'] = 'red-background';

                            $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';
                        }


                        $nestedData['asset_sl_no'] = $inventory->asset?->asset_id;
                        $nestedData['purchase_entity'] = $inventory->assetStock?->arn?->purchaseOrder?->entity?->name;

                        $nestedData['user_entity'] = $inventory->issue?->user?->profile?->entity?->name;

                        $findLeaseItem = LeaseItem::where('inventory_id', $inventory->id)->orderBy('id', 'desc')->first();

                        // $nestedData['user_entity'] = '';

                        // if ($request->leaseUuid != null)
                        //if($inventory->lease)
                        //$nestedData['user_entity'] = $inventory->inventoryLeases($findLeaseItem->id)?->leasedUser?->profile?->entity?->name ?? '';

                        $nestedData['asset_location'] = $inventory->assetStock?->location?->street_address;
                        $nestedData['description'] =  $inventory->asset?->asset_name;
                        $nestedData['model_no'] = $inventory->asset?->asset_name;
                        $nestedData['date_of_purchase'] =  Carbon::parse($inventory->purchase_date)->format('Y-m-d');


                        $purchaseDate = Carbon::parse($inventory->purchase_date);
                        $warranty_licence_date = Carbon::parse($inventory->warranty_licence_date);
                        $diffInMonths = $warranty_licence_date->diffInMonths($purchaseDate);
                        // $warranty_in_years = $diffInMonths / 12;
                        $nestedData['warranty_in_years'] = $diffInMonths;
                        $nestedData['warranty_expire'] = Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d');
                        $currentDate = Carbon::now();
                        $age = $purchaseDate->diff($currentDate);
                        $nestedData['age_of_asset'] = $age->y . ' Year ' . $age->m . ' Month ' . $age->d . ' Days';


                        // $nestedData['unique_id'] = '<a href="' . route('admin.assetstock.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';

                        $nestedData['unique_id'] = '<a href="' . route('admin.asset.history', $inventory->uuid) . '">' . $inventory->unique_id . '</a>';


                        $employeeCode = '';
                        $employeeDetails = '';
                        // if ($request->leaseUuid != null) {
                        //     $leaseItem = $inventory->inventoryLeases($leaseId);
                        //     $employeeCode = ($leaseItem->user_id != null && $leaseItem->is_completed == 0) ? $leaseItem->leasedUser?->unique_id : '';
                        //     $employeeDetails = ($leaseItem->user_id != null && $leaseItem->is_completed == 0) ? $leaseItem->leasedUser?->full_name : '';
                        // }




                        // $allocationDate = $inventory->issue ? Carbon::parse($inventory->issue?->issued_date)->format('d-m-Y') : '';

                        if ($inventory->lease) {

                            if ($inventory->lease->leaseAgreement->type == 'internal') {
                                $employeeCode = $inventory->lease?->leasedUser?->unique_id;
                                $employeeDetails = $inventory->lease?->leasedUser?->full_name;
                                $nestedData['user_entity'] = $inventory->lease?->leasedUser?->profile?->entity?->name;
                                // $allocationDate =  $inventory->lease?->leasedUser ? Carbon::parse($inventory->lease->leaseAgreement->created_at)->format('d-m-Y') : '';

                                // $allocationDate =  $inventory->lease?->leasedUser ? Carbon::parse($inventory->lease->leased_date)->format('d-m-Y') : '';
                                $allocationDate = $inventory->lease?->leasedUser && $inventory->lease->leased_date ? Carbon::parse($inventory->lease->leased_date)->format('d-m-Y') : '';
                            } else {
                                $employeeCode = '';
                                $employeeDetails = '<div><strong>Leased Vendor Info:</strong><br>';
                                $employeeDetails .= '<strong>Name: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_name'] . '<br>';
                                $employeeDetails .= '<strong>Phone Number: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_phone'] . '<br>';
                                $employeeDetails .= '<strong>Email: </strong>' . $inventory->lease->leaseAgreement->vendor_information['vendor_email'] . '</div>';
                            }
                        }
                        $employeeCode = $inventory->issue ?  $inventory->issue->user->unique_id : $employeeCode;
                        $employeeName = $inventory->issue ? $inventory->issue->user->full_name : $employeeDetails;
                        $nestedData['employee_code'] =  $employeeCode;
                        $nestedData['employee_name'] = $employeeName;

                        $nestedData['designation'] =  $inventory->issue ? $inventory->issue?->user?->profile?->designation->name : '';
                        $nestedData['sbu'] = $inventory->issue ? $inventory->issue->user?->profile?->sbu?->name : '';
                        $nestedData['division'] = $inventory->issue ? $inventory->issue?->user?->profile?->division?->name : '';
                        $nestedData['user_location'] = $inventory->issue ? $inventory->issue?->user?->profile?->location?->street_address : '';

                        $qrCodeSvg = $inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($inventory->identification_no) : '';
                        $nestedData['asset_tag'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"   data-identification_no="' . $inventory->identification_no . '"  data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>
                        <a class="regenerate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Regenerate"><i class="fa-solid fa-rotate-right"></i></a>' :
                            '<a class="btn btn-blue btn-sm generate-qr" data-uuid="' . $inventory->uuid . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate">Generate</a>';


                        $nestedData['previous_user'] = '';
                        $nestedData['issue_with_laptop'] = '';
                        $nestedData['date_of_scraping'] = $inventory->dispose ? Carbon::parse($inventory->dispose?->updated_at)->format('Y-m-d') : '';

                        $nestedData['scrap_rate'] = '';
                        $nestedData['scrap_vendor_details'] = '';


                        $nestedData['purchase_price'] = '';
                        $nestedData['vendor'] = $inventory->assetStock?->arn?->purchaseOrder?->vendor?->full_name;
                        $invoice_nos = $inventory->assetStock?->arn?->purchaseOrder?->PurchaseOrderInvoice->pluck('unique_id')->toArray();
                        $nestedData['invoice_no'] = $invoice_nos ? implode(', ', $invoice_nos) : '';
                        $nestedData['remark'] =  $inventory->issue ? $inventory->issue?->comments : '';
                        $nestedData['lost_stolen_year'] = '';
                        $nestedData['is_active'] = $inventory->is_active == '1' ? 'Active' : 'In-Active';
                        $nestedData['others_specifications'] = '';
                        $nestedData['purchase_date'] = Carbon::parse($inventory->purchase_date)->format('Y');
                        $nestedData['years_description'] = '';
                        $nestedData['specifications'] = $inventory->capacity_specs;
                        $nestedData['accessories_given_at_allotment_time'] = '';
                        $nestedData['allotment_date'] = $allocationDate;
                        $issueBtnText = (!$inventory->issue) ? 'Issue' : "Correction";


                        //$issueBtnText = (!$inventory->issue) ? 'Allocate' : "Correction";




                        $nestedData['action'] = '<div class="action_sec">';

                        // if (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease &&  $request->leaseUuid == null) {

                        // && $inventory->surrender
                        if (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease    &&  $request->leaseUuid == null) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }
                            $nestedData['action'] .= '<a class="btn btn-blue btn-sm issue-btn"  data-comments="' . $inventory->issue?->comments . '"  data-issue_uuid="' . $inventory->issue?->uuid . '"   data-user_id="' . $inventory->issue?->user_id . '"  data-issued_date="' . $inventory->issue?->issued_date . '"  data-sl-no="' . $inventory->unique_id . '" data-asset-id="' . $inventory->asset_id . '"  data-asset-uuid="' . $inventory->asset?->uuid . '"   data-inventory-uuid="' . $inventory->uuid . '" data-asset-name="' . $inventory->asset?->asset_name . '" data-inventory-id="' . $inventory->id . '"  data-expiry="' . $inventory->warranty_licence_date . '"  data-issued-image="' . $issuedImage . '" href="javascript:void(0)"> ' . $issueBtnText . '</a>';
                        }


                        if (!$inventory->underMaintenance && !$inventory->dispose) {
                            $issuedImage = '';
                            if ($inventory->issue?->issuedImage->count()) {
                                $issuedImage = $inventory->issue->issuedImage[0]->file;
                            }

                            if ($request->leaseUuid != null) {
                                $leaseItem = $inventory->inventoryLeases($leaseId);

                                if ($leaseItem) {
                                    // switch ($leaseItem->is_completed) {
                                    //     case '0':
                                    //         $itemStatusText = 'Allocated';
                                    //         $itemStatusClass = 'text_blue';
                                    //         break;
                                    //     case '1':
                                    //         $itemStatusText = 'Completed';
                                    //         $itemStatusClass = 'text_green';
                                    //         break;
                                    // }

                                    // if ($leaseItem->user_id != null) {
                                    //     if ($leaseItem->is_completed == '0') {
                                    //         $nestedData['action'] .= '<div class="dropdown">';
                                    //         $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //         $nestedData['action'] .= '</button>';
                                    //         $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id != null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Allocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_blue ' . ($leaseItem->user_id == null ? 'disabled' : '') . '" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Unallocate</a></li>';
                                    //         $nestedData['action'] .= '<li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Completed</a></li>';
                                    //         $nestedData['action'] .= '</ul>';
                                    //         $nestedData['action'] .= '</div>';
                                    //     } else {
                                    //         $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    //     }
                                    // } else {
                                    //     if ($leaseItem->leaseAgreement?->type == 'internal') {
                                    //         $nestedData['action'] .= '<a href="javascript:void(0)" class="' . ($leaseItem->leasedUser ? '' : 'lease_item') . '" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-issued-image="' . $issuedImage . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '">';
                                    //         $nestedData['action'] .= $leaseItem->leasedUser ? 'Allocated' : 'Allocate';
                                    //         $nestedData['action'] .= '</a>';
                                    //     }
                                    // }



                                    $itemStatusText = 'Action';
                                    $itemStatusClass = '';
                                    if ($leaseItem->user_id != null && $leaseItem->is_completed == '0') {
                                        $itemStatusText = 'Allocated';
                                        $itemStatusClass = 'text_blue';
                                    }
                                    if ($leaseItem->is_completed == '1') {
                                        $itemStatusText = 'Completed';
                                        $itemStatusClass = 'text_green';
                                    }

                                    if ($leaseItem->is_completed == '0') {
                                        $nestedData['action'] .= '<div class="dropdown">';
                                        $nestedData['action'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">';
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                        $nestedData['action'] .= '</button>';
                                        $nestedData['action'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">';

                                        // Allocate option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_blue ' . (($leaseItem->user_id != null || $leaseItem->leaseAgreement?->type != 'internal') ? 'disabled' : '') . '" onclick="leaseStatusChange(this)" href="javascript:void(0)" data-lease_uuid="' . $leaseItem->leaseAgreement?->uuid . '" data-inventory_id="' . $leaseItem->inventory_id . '" data-lease_item_uuid="' . $leaseItem->uuid . '" data-to_entity="' . $leaseItem->leaseAgreement?->to_entity_id . '" data-status="0">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Allocate';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        // Unallocate option
                                        if ($leaseItem->user_id != null) {
                                            $nestedData['action'] .= '<li>';
                                            $nestedData['action'] .= '<a class="dropdown-item text_blue" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="0">';
                                            $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Unallocate';
                                            $nestedData['action'] .= '</a>';
                                            $nestedData['action'] .= '</li>';
                                        }

                                        // Complete option
                                        $nestedData['action'] .= '<li>';
                                        $nestedData['action'] .= '<a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="lease_items" data-uuid="' . $leaseItem->uuid . '" data-status="1">';
                                        $nestedData['action'] .= '<span><i class="fa-solid fa-circle"></i></span>Complete';
                                        $nestedData['action'] .= '</a>';
                                        $nestedData['action'] .= '</li>';

                                        $nestedData['action'] .= '</ul>';
                                        $nestedData['action'] .= '</div>';
                                    } else {
                                        $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                                    }
                                }
                            }
                        }

                        if ($request->leaseUuid == null) {
                            if ((!$inventory->issue) && (!$inventory->underMaintenance && !$inventory->dispose && !$inventory->lease))
                                $nestedData['action'] .= '<a class="btn btn-blue btn-sm transfer-btn"  data-inventory_id="' . $inventory->id . '"  data-asset_stock_id="' . $inventory->asset_stock_id . '" data-asset_stock_uuid="' . $inventory->assetStock?->uuid . '">Transfer </a>';

                            $nestedData['action'] .= '<a href="" class="edit_icon inventory-edit"  data-uuid="' . $inventory->uuid . '"  data-unique_id="' . $inventory->unique_id . '" data-capacity_specs="' . $inventory->capacity_specs . '"  data-asset_condition="' . $inventory->asset_condition . '   "  data-purchase_date="' . Carbon::parse($inventory->purchase_date)->format('Y-m-d') . '" "  data-warranty_licence_date="' . Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') . '" "><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            if (!$inventory->issue)
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="inventories" data-uuid="' . $inventory->uuid . '"><i
                                                        class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div>';





                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }




    public function getIssueList(Request $request, $uuid)
    {
        if ($request->ajax()) {
            try {


                $arnItemData = $this->assetService->findAssetReceiptNoteItemById(uuidtoid($uuid, 'asset_receipt_note_items'));
                // dd($arnItemData->arn->stock[0]->inventories);
                // $arnData = $this->assetService->findAssetReceiptNoteById($arnItemData->asset_receipt_note_id);
                $arnData = $arnItemData->arn;
                $assetStock = $this->assetService->getAssetStock(['asset_id' => $arnItemData->asset_id, 'location_id' => $arnData->received_location_id]);
                $filterConditions = ['asset_stock_id' => $assetStock->id];
                $totalData = $this->assetStockService->findInventories($filterConditions)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                //dd("sdfghjk");
                $inventories = $this->assetStockService->findInventories($filterConditions, $order, $dir, $limit, $index, false);
                //dd($inventories);
                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['sl_no'] = $inventory->unique_id;
                        $nestedData['capacity_spec'] = $inventory->capacity_specs;
                        $nestedData['warranty_licence_date'] = $inventory->warranty_licence_date ? Carbon::parse($inventory->warranty_licence_date)->format('d-m-Y') : '';;
                        $nestedData['issued_to'] = $inventory->issue ? $inventory->issue->user->full_name : '';
                        $nestedData['issued_date'] = $inventory->issue ? Carbon::parse($inventory->issue->created_at)->format('d-m-Y') : '';
                        $nestedData['action'] = '<div class="action_sec">';
                        $nestedData['action'] .= (!$inventory->issue) ? '<a class="btn btn-blue btn-sm issue-btn" data-sl-no="' . $inventory->unique_id . '"  data-inventory-id="' . $inventory->id . '"  data-expiry="' . $inventory->warranty_licence_date . '" href="javascript:void(0)"> Issue</a>' : '';
                        $nestedData['action'] .= '</div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getInvoices(Request $request)
    {
        if ($request->ajax()) {
            try {
                $poUuid = $request->uuid;
                $filterCondition = [];
                if ($poUuid) {
                    $filterCondition['purchase_order_id'] = uuidtoid($poUuid, 'purchase_orders');
                }

                // $status = 'all';


                $statClass = 'text_black';
                $status = 'Not Sent For Approval';

                $search = $request->filterData;
                $totalData = $this->assetService->getTotalInvoices();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $invoices = $this->assetService->findInvoices($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $invoices = $this->assetService->findInvoices($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalInvoices($search);
                }

                if ($invoices) {

                    foreach ($invoices as $key => $invoice) {
                        $index++;
                        $view_invoice_url = $poUuid ? route('admin.po.invoice.view', [$invoice->uuid, $poUuid]) : route('admin.invoice.inv.view', $invoice->uuid);
                        $nestedData['unique_id'] = '<a href="' . $view_invoice_url . '" class="edit_icon">' . $invoice->unique_id . '</a>';
                        $nestedData['party_invoice_number'] = $invoice->party_invoice_number;
                        // $nestedData['po_no'] = $invoice->purchaseOrder?->unique_id;
                        $nestedData['purchase_order_id'] = '<a href="' . route('admin.po.view', $invoice->purchaseOrder?->uuid) . '" class="edit_icon" target="_blank">' . $invoice->purchaseOrder?->unique_id . '</a>';
                        $nestedData['vendor'] = $invoice->vendor?->full_name;
                        $nestedData['invoice_date'] = Carbon::parse($invoice->invoice_date)->format('d-m-Y');
                        switch ($invoice->status) {
                            case '0':
                                $statClass = 'text_pending';
                                $status = 'Pending';
                                break;
                            case '1':
                                $statClass = 'text_green';
                                $status = 'Approved';
                                break;
                            case '2':
                                $statClass = 'text_danger';
                                $status = 'Rejected';
                                break;
                            case '3':
                                $statClass = 'text_danger';
                                $status = 'Cancelled';
                                break;
                            case '4':
                                $statClass = 'text_black';
                                $status = 'Closed';
                                break;
                            case '5':
                                $statClass = 'text_blue';
                                $status = 'Ongoing Approval';
                                break;

                            case null:
                                $statClass = 'text_danger';
                                $invoiceData = $this->assetService->findInvoiceById($invoice->id);
                                // dd($invoiceData);
                                if ($invoiceData)
                                    $isRejectedCheck = $invoiceData->isRejectedCheck()->get();
                                // dd($isRejectedCheck);
                                if ($isRejectedCheck && $isRejectedCheck->contains('status', 2))
                                    $status = 'Rejected';
                                break;

                            default:
                                $statClass = 'text_black';
                                $status = 'Not Sent For Approval';
                                break;
                        }

                        $checkInvoiceApproval = $this->assetService->checkPoInvoiceApproval($invoice->id, auth()->user()->id);

                        // $checkInvoiceApproval = $this->assetService->checkPoInvoiceApprovalLatestOrder($invoice->id, auth()->user()->id);


                        if ($checkInvoiceApproval && $checkInvoiceApproval->status == '0') {
                            if (auth()->user()->canAny(['status-invoice'])) {
                                $nestedData['status'] = '<div class="action_sec">
                                <div class="status_box">
                                    <a class="btn btn-outline-success text_green" onclick="invoiceStatusChange(this, ' . $checkInvoiceApproval->level . ')" href="javascript:void(0)" data-table="purchase_order_invoices" data-userid="' . $invoice->user_id . '" data-uuid="' . $invoice->uuid . '" data-status="1"  data-level="' . $checkInvoiceApproval->level . '"><i class="fa-solid fa-circle"></i> Approve</a>
                                    <a class="btn btn-outline-danger text_danger" onclick="invoiceStatusChange(this, ' . $checkInvoiceApproval->level . ')" href="javascript:void(0)" data-table="purchase_order_invoices" data-userid="' . $invoice->user_id . '" data-uuid="' . $invoice->uuid . '" data-status="2"  data-level="' . $checkInvoiceApproval->level . '"><i class="fa-solid fa-circle"></i> Reject</a>
                                </div>
                            </div>';
                            } else {
                                $nestedData['status'] = '';
                            }
                        } else {
                            $approval_url = $poUuid ? route('admin.po.invoice.sendForApproval', [$invoice->uuid, $poUuid]) : route('admin.invoice.inv.sendForApproval', $invoice->uuid);
                            $lastApproval = PoInvoiceApproval::where(['po_invoice_id' => $invoice->id])->where('status', '<>', null)->where('status', '<>', 0)->orderBy('id', 'desc')->first();
                            $nestedData['status'] = '<span class="' . $statClass . '" data-toggle="tooltip" data-placement="top" title="' . $lastApproval?->comments . '"><a href="' . $approval_url . '" class="edit_icon h6" title="Send for approval"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</a>';
                            if (in_array($invoice->status, [1, 2, 3, 4, 5])) {
                                $nestedData['status'] .= '<a href="javascript:void(0);" class="show-comments ml-2" title="View Comments" data-invoice-uuid="' . $invoice->uuid . '"><i class="fa fa-info-circle" aria-hidden="true"></i></a>';
                            }
                            $nestedData['status'] .= '</span>';
                        }

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if (auth()->user()->hasRole('super-admin') || (auth()->user()->id == $invoice->created_by)) {
                            $view_invoice_url = $poUuid ? route('admin.po.invoice.edit', [$invoice->uuid, $poUuid]) : route('admin.invoice.inv.edit', $invoice->uuid);
                            if ((($invoice->status === null) || ($invoice->status == '2') || ($invoice->status == '3')) && auth()->user()->canAny(['edit-invoice'])) {
                                $nestedData['action'] .= '<a href="' . $view_invoice_url . '" class="edit_icon" title="Edit Invoice"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                            }
                            if (($invoice->status === null) && auth()->user()->canAny(['delete-invoice'])) {
                                $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="purchase_order_invoices" data-uuid="' . $invoice->uuid . '" title="Delete Invoice"><i class="fa-solid fa-trash-can"></i></a>';
                            }
                        }
                        if (auth()->user()->canAny(['export-invoice'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.invoice.pdf.download', $invoice->uuid) . '" class="edit_icon text-success" title="Download Invoice"><i class="fa fa-download" aria-hidden="true"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getInvoiceItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $poId = $request->po_id ? uuidtoid($request->po_id, 'purchase_orders') : null;
                $invoiceId = $request->invoice_uuid ? uuidtoid($request->invoice_uuid, 'purchase_order_invoices') : null;
                $poData = null;
                if ($poId) {
                    $poData = $this->assetService->findPoId($poId);
                }
                $invoiceData = null;
                if ($invoiceId) {
                    $invoiceData = $this->assetService->findInvoiceById($invoiceId);
                }
                // $purchaseOrder = $poId ? $this->assetService->findPoId($poId) : null;
                $filterCondition = ['purchase_order_id' => $poId];
                $poItems = $this->assetService->findPoItems($filterCondition);
                $totalData = $poItems->count();
                $totalFiltered = $totalData;
                $nestedData = [];
                $data = [];
                $totalAmount = 0;
                if ($poItems) {
                    foreach ($poItems as $k => $item) {
                        $nestedData['SrNo'] = '<div class="action_box">
                                <label for="item_id_' . $item->unique_id . '">' . ($k + 1) . '</label>
                                <input type="hidden" name="purchase_order_items[' . $k . '][unique_id]" id="unique_id_' . $k . '" value="' . $item->unique_id . '">
                            </div>';
                        // $nestedData['asset_category'] = '<div class="form-group">
                        //     <label>' . $item->assetCategory->name . '</label>
                        //     <input type="hidden" name="purchase_order_items[' . $k . '][category_id]" id="category_id_' . $k . '" value="' . $item->category_id . '">
                        //     <input type="hidden" name="purchase_order_items[' . $k . '][category_name]" id="category_name_' . $k . '" value="' . $item->assetCategory->name . '">
                        // </div>';
                        // $nestedData['asset_type'] = '<div class="form-group">
                        //     <label>' . $item->assetType->name . '</label>
                        //     <input type="hidden" name="purchase_order_items[' . $k . '][asset_type_id]" id="asset_type_id_' . $k . '"value="' . $item->asset_type_id . '">
                        //     <input type="hidden" name="purchase_order_items[' . $k . '][asset_type_name]" id="asset_type_id_' . $k . '"value="' . $item->assetType->name . '">
                        // </div>';
                        $nestedData['item'] = '<div class="form-group">
                            <input type="text" name="purchase_order_items[' . $k . '][asset_name]" id="asset_name_' . $k . '" value="' . $item->asset?->asset_name . '" class="form-control">
                            <input type="hidden" name="purchase_order_items[' . $k . '][asset_id]" id="asset_id_' . $k . '" value="' . $item->asset_id . '">
                            <input type="hidden" name="purchase_order_items[' . $k . '][uuid]" id="uuid_' . $k . '" value="' . $item->uuid . '">
                        </div>';
                        $nestedData['specs'] = '<div class="form-group">
                            <textarea name="purchase_order_items[' . $k . '][specifications]" id="specifications_' . $k . '" class="form-control specifications">' . $item->specifications . '</textarea>
                        </div>';

                        $itemQuantity = ($invoiceData && isset($invoiceData->purchase_order_items[$k]['quantity'])) ? $invoiceData->purchase_order_items[$k]['quantity'] : $item->quantity;
                        $itemAmount = ($invoiceData && isset($invoiceData->purchase_order_items[$k]['amount'])) ? $invoiceData->purchase_order_items[$k]['amount'] : $item->amount;
                        $itemDiscountType = ($invoiceData && isset($invoiceData->purchase_order_items[$k]['discount_type'])) ? $invoiceData->purchase_order_items[$k]['discount_type'] : $item->discount_type;
                        $itemDiscount = ($invoiceData && isset($invoiceData->purchase_order_items[$k]['discount'])) ? $invoiceData->purchase_order_items[$k]['discount'] : $item->discount;
                        $itemTax = ($invoiceData && isset($invoiceData->purchase_order_items[$k]['tax'])) ? $invoiceData->purchase_order_items[$k]['tax'] : $item->tax;
                        $itemDiscountedTotal = 0;
                        $itemTotal = $itemQuantity * $itemAmount;
                        if ($itemDiscount) {
                            if ($itemDiscountType == 'percentage') {
                                $itemDiscountedTotal = $itemTotal - ($itemTotal * $itemDiscount / 100);
                            } else {
                                $itemDiscountedTotal = $itemTotal - $itemDiscount;
                            }
                        } else {
                            $itemDiscountedTotal = $itemTotal;
                        }
                        $itemTotalAmount = $itemDiscountedTotal + ($itemDiscountedTotal * $itemTax) / 100;

                        $nestedData['qty'] = '<div class="form-group">
                            <input type="number" name="purchase_order_items[' . $k . '][quantity]" class="form-control quantity" id="quantity_' . $k . '" value="' . $itemQuantity . '" data-max="' . $itemQuantity . '">
                        </div>';
                        $nestedData['unit'] = '<div class="form-group">
                            ' . ucfirst($item->unit) . '
                            <input type="hidden" name="purchase_order_items[' . $k . '][unit]" id="unit_' . $k . '" value="' . $item->unit . '" class="form-control">
                        </div>';
                        $nestedData['unit_rate'] = '<div class="form-group">
                            <input type="number" name="purchase_order_items[' . $k . '][amount]" class="form-control amount" id="amount_' . $k . '" data-index="' . $k . '" min="1" value="' . $itemAmount . '" data-max="' . $itemAmount . '">
                        </div>';
                        // $nestedData['discount'] = '<div class="form-group">
                        //     <input type="number" name="purchase_order_items[' . $k . '][discount]" class="form-control discount" id="discount_' . $k . '" data-index="' . $k . '" min="1" value="' . $itemDiscount . '" >
                        // </div>';
                        $nestedData['discount'] = '<div class="input-group">
                                <select class="form-control item_wise_discount_type" id="discount_type_' . $k . '"
                                    name="purchase_order_items[' . $k . '][discount_type]">
                                    <option value="percentage" ' . (($itemDiscountType == 'percentage') ? 'selected' : '') . '>%</option>
                                    <option value="fixed" ' . (($itemDiscountType == 'fixed') ? 'selected' : '') . '>Fixed</option>
                                </select>
                                <input type="number" name="purchase_order_items[' . $k . '][discount]" class="form-control item_wise_discount" id="discount_' . $k . '" data-index="' . $k . '" min="0" value="' . $itemDiscount . '">
                            </div>
                            <div class="mt-2">
                                <label id="item_discount_amount_label_' . $k . '">
                                    ' . (($itemDiscountType == 'percentage') ? '- ' . $itemDiscount . '% ( ₹' . number_format(($itemQuantity * $item->amount * $itemDiscount / 100), 2, '.', ',') . ' )' : '- ₹' . number_format($itemDiscount, 2, '.', ',')) . '
                                </label>
                            </div>';
                        $nestedData['tax'] = '<div class="form-group">
                            <input type="number" name="purchase_order_items[' . $k . '][tax]" class="form-control tax" id="tax_' . $k . '" data-index="' . $k . '" min="0" value="' . $itemTax . '" >
                        </div>';
                        $nestedData['total_amount'] = '<div class="form-group">
                            <label id="item_total_amount_label_' . $k . '">₹' . number_format((float) $itemTotalAmount, 2, '.', ',') . '</label>
                            <input type="hidden" name="purchase_order_items[' . $k . '][item_total_amount]" class="form-control item_total_amount" id="item_total_amount_' . $k . '" value="' . $itemTotalAmount . '" >
                        </div>';

                        $totalAmount += $itemTotalAmount;

                        $data[] = $nestedData;
                        $nestedData = [];
                    }

                    $summary = '<tr>
                        <td colspan="6" style="vertical-align:top;"></td>
                        <td colspan="2">
                            <div class="form-group">
                                <label>Total: </label>
                            </div>
                        </td>
                        <td>
                            <div class="form-group">
                                <label id="grand_total_label">₹' . number_format((float) $totalAmount, 2, '.', ',') . '</label>
                                <input type="hidden" id="grand_total" name="grand_total" value="' . $totalAmount . '">
                                <input type="hidden" id="sub_total" name="sub_total" value="' . $totalAmount . '">
                            </div>
                        </td>
                    </tr>';
                }
                $billing_state = ($poData && isset($poData->billing_address['billing_state_id']) && $poData->billing_address['billing_state_id']) ? getStateDetails($poData?->billing_address['billing_state_id'])?->name : '';
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                    "summary" => $summary,
                    "vendor_id" => $poData?->vendor?->id,
                    "vendor_name" => $poData?->vendor?->full_name,
                    "billing_state_id" => ($poData && isset($poData->billing_address['billing_state_id'])) ? $poData?->billing_address['billing_state_id'] : null,
                    "billing_state" => $billing_state,
                    "billing_street_address" => $poData?->billing_address['billing_street_address'],
                    "billing_from_address" => $poData?->vendor?->full_address,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    /*public function getTicketRaisedByMe(Request $request,)
    {
        if ($request->ajax()) {
            try {
                $filterConditions = ['raised_id' => Auth()->user()->id];
                $totalData = $this->assetService->findTicketRaisedByMe($filterConditions)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                //dd($totalData);
                $tickets = $this->assetService->findTicketRaisedByMe($filterConditions, $order, $dir, $limit, $index, false);
                // dd($tickets);
                if ($tickets) {
                    foreach ($tickets as $key => $ticket) {
                        $index++;
                        //$nestedData['SrNo'] = $k + 1;
                        $nestedData['ticket_id'] = $ticket->unique_id;
                        $nestedData['subject'] = $ticket->subject;
                        $nestedData['entity'] = $ticket->entity?->name;
                        $nestedData['department'] = $ticket->department?->name;
                        $nestedData['raised_by'] = $ticket->user?->first_name . " " . $ticket->user?->last_name;
                        $nestedData['raised_on'] = $ticket->created_at ? Carbon::parse($ticket->created_at)->format('d-m-Y') : '';
                        $nestedData['completion_date'] = $ticket->completed_at == null ? '---' : $ticket->completed_at;
                        $nestedData['priority'] = ucfirst($ticket->priority);

                        $nestedData['status'] = ' <div class="status_box">
                        <div class="dropdown">
                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="' . (($ticket->status == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($ticket->status == '1') ? 'Open' : 'Closed') . '
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Open</a></li>
                                <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Close</a></li>
                            </ul>
                        </div>
                    </div>';
                        $nestedData['action'] = '<div class="action_sec">
                                                    <div class="action_box">
                                                        <a href="" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>

                                                    </div>
                                                </div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }*/

    public function getAssetStockDetails(Request $request)
    {
        if ($request->ajax()) {
            $locationId = $request->locationId;
            $entityId = $request->entityId;
            //dd($entityId);
            if (!$locationId) {
                return $this->responseJson(false, 500, 'Location is required');
            }

            // $filterConditions = [];
            $filterConditions['asset_id'] = $request->assetId;
            $filterConditions['location_id'] = $locationId;
            if ($request->entityId) {
                $filterConditions['entity_id'] = $entityId;
                //return $this->responseJson(false, 500, 'Entity is required');
            }

            try {
                // $assetStock = $this->assetService->getAssetStock(['asset_id' => $request->assetId, 'location_id' => $locationId,'entity_id' => $entityId]);
                $assetStock = $this->assetService->getAssetStock($filterConditions);
                return $this->responseJson(true, 200, 'Asset stock feteched', $assetStock);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getAssetAvailableItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');
                $filterConditions = ['asset_stock_id' => $asset_stock_id];
                $order = 'id';
                $dir = 'desc';
                $search = $request->search['value'];
                $totalData = $this->assetStockService->findAvailableItems($filterConditions, $order, $dir, null, null, false, $search)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $index = $start;
                $nestedData = [];
                $data = [];

                $inventories = $this->assetStockService->findAvailableItems($filterConditions, $order, $dir, $limit, $index, false, $search);
                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['identification_no'] = $inventory->identification_no;
                        $nestedData['sl_no'] = $inventory->unique_id;
                        $nestedData['capacity_spec'] = $inventory->capacity_specs;
                        $nestedData['warranty_licence_date'] = $inventory->warranty_licence_date ? Carbon::parse($inventory->warranty_licence_date)->format('Y-m-d') : '';
                        $nestedData['asset_condition'] = $inventory->asset_condition;
                        $nestedData['purchase_date'] = $inventory->purchase_date ? Carbon::parse($inventory->purchase_date)->format('Y-m-d') : '';
                        $nestedData['amount'] = '<input type="number" min="0" name="amount[]" class="form-control amount" id="amount_' . $inventory->id . '" value="0">';
                        $nestedData['action'] = '<div class="action_sec">';
                        $nestedData['action'] .= '<input type="checkbox" name="asset_items[]" class="lease_item" id="lease_item_' . $inventory->id . '" value="' . $inventory->id . '" data-unique-id="' . $inventory->unique_id . '">';
                        $nestedData['action'] .= '<div id="lease_sec_' . $inventory->id . '" class="lease_sec"></div>';
                        $nestedData['action'] .= '</div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getInventoryQr(Request $request)
    {

        if ($request->ajax()) {
            try {

                $inventoryData = $this->assetService->findInventoryById(uuidtoid($request->uuid, 'inventories'));
                $message = 'QR Code Re-Generated Successfully';
                //dd($inventoryData);
                $assetData = $this->assetService->findById($inventoryData->asset_id);
                $assetTypeData = $this->assetTypeService->findById($assetData->asset_type_id); //entity and assetType name
                $assetStockData = $this->assetStockService->findById($inventoryData->asset_stock_id);
                $locationData = $this->assetService->findLocationById($assetStockData->location_id);
                $month = date('m', strtotime($inventoryData['purchase_date']));
                $year = date('Y', strtotime($inventoryData['purchase_date']));
                $lastId = $inventoryData->id;
                $entity = $assetStockData->arn->purchaseOrder->entity->name;
                $identification_no = $this->generateUniqueCode($entity, $locationData->street_address, $assetTypeData->name, $month, $year, str_pad($lastId, 4, '0', STR_PAD_LEFT));

                $data = [
                    'identification_no' => $identification_no,
                ];
                $isStockUpdated = $this->assetService->addOrUpdateInventory(['uuid' => $request->uuid], $data);
                return $this->responseJson(true, 200, $message, $inventoryData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }




    protected function generateUniqueCode($entity = null, $location = null, $assetType = null, $month = null, $year = null, $lastId = null)
    {
        $budgetCode = substr(strtoupper((preg_replace('/[^a-zA-Z0-9]/', '', $entity))), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $location)), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $assetType)), 0, 3) . '/' . $month . '/' . $year . '-' . $lastId;
        return $budgetCode;
    }

    public function getAssetLeasedItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');
                $filterConditions = ['asset_stock_id' => $asset_stock_id];
                $order = 'id';
                $dir = 'desc';
                $search = $request->search['value'];
                $totalData = $this->assetStockService->findLeasedItems($filterConditions, $order, $dir, null, null, false, $search)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $index = $start;
                $nestedData = [];
                $data = [];

                $inventories = $this->assetStockService->findLeasedItems($filterConditions, $order, $dir, $limit, $index, false, $search);
                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['identification_no'] = $inventory->identification_no;
                        $nestedData['sl_no'] = $inventory->unique_id;
                        $nestedData['capacity_spec'] = $inventory->capacity_specs;
                        $nestedData['warranty_licence_date'] = $inventory->warranty_licence_date ? Carbon::parse($inventory->warranty_licence_date)->format('d-m-Y') : '';
                        $nestedData['asset_condition'] = $inventory->asset_condition;
                        $nestedData['purchase_date'] = $inventory->purchase_date ? Carbon::parse($inventory->purchase_date)->format('d-m-Y') : '';
                        $nestedData['action'] = '<div class="action_sec"></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getIssuedList(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');
                $filterConditions = ['asset_stock_id' => $asset_stock_id];
                $totalData = $this->assetStockService->listAssetIssues($filterConditions)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                $issueList = $this->assetStockService->listAssetIssues($filterConditions, $order, $dir, $limit, $index, false);
                if ($issueList) {
                    foreach ($issueList as $k => $issue) {
                        $index++;
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['asset_name'] = $issue?->inventory?->asset?->asset_name;
                        $nestedData['sl_no'] = $issue->inventory?->unique_id;
                        $nestedData['capacity_spec'] = $issue->inventory?->capacity_specs;
                        $nestedData['warranty_licence_date'] = $issue->inventory?->warranty_licence_date ? Carbon::parse($issue->inventory?->warranty_licence_date)->format('d-m-Y') : '';
                        $nestedData['asset_condition'] = $issue->inventory?->asset_condition;
                        $nestedData['purchase_date'] = $issue->inventory?->purchase_date ? Carbon::parse($issue->inventory?->purchase_date)->format('d-m-Y') : '';
                        $nestedData['issued_to'] = $issue->user?->first_name . " " . $issue->user?->last_name;
                        $nestedData['issued_date'] = $issue->issued_date ? Carbon::parse($issue->issued_date)->format('d-m-Y') : '';
                        $nestedData['comments'] = $issue->comments;
                        $nestedData['issued_image'] = $issue->issuedImage->count() ? '<div class="issue_image"><a href="javascript:void(0);" target="_blank" data-url="' . asset('storage/images/documents/' . $issue->issuedImage[0]->file) . '" data-file="' . $issue->issuedImage[0]->file . '" class="viewDocument"><img src="' . asset('storage/images/documents/' . $issue->issuedImage[0]->file) . '" alt="' . $issue->issuedImage[0]->file . '"></a></div>' : '';
                        $nestedData['surrendered_image'] = $issue->surrenderedImage->count() ? '<div class="issue_image"><a href="javascript:void(0);" target="_blank" data-url="' . asset('storage/images/documents/' . $issue->surrenderedImage[0]->file) . '" data-file="' . $issue->surrenderedImage[0]->file . '" class="viewDocument"><img src="' . asset('storage/images/documents/' . $issue->surrenderedImage[0]->file) . '" alt="' . $issue->surrenderedImage[0]->file . '"></a></div>' : '';
                        $nestedData['allotment_letter'] = $issue->allotment_letter ? '<div class="issue_image"><a href="javascript:void(0);" target="_blank" data-url="' . asset('storage/images/documents/' . $issue->allotment_letter) . '" data-file="' . $issue->allotment_letter . '" class="viewDocument">' . $issue->allotment_letter . '</a></div>' : '';

                        $qrCodeSvg = '';
                        $qrCodeSvg = $issue->inventory->identification_no ? (string) QrCode::format('svg')->size(50)->generate($issue->inventory->identification_no) : '';

                        $nestedData['generate_qr'] = $qrCodeSvg ?
                            '<a href="#" class="qr-code-link"  data-identification_no="' . $issue->inventory->identification_no . '" data-qr="' . htmlentities($qrCodeSvg) . '">' . $qrCodeSvg . '</a>' : '';

                        $acceptance_status = 'NA';
                        if ($issue->is_accepted !== null) {
                            if ($issue->is_accepted == '1') {
                                $acceptance_status = '<span class="text_green"><i class="fa-solid fa-circle mr-1"></i> Accepted</span>';
                            } else {
                                $acceptance_status = '<span class="text_danger"><i class="fa-solid fa-circle mr-1"></i> Rejected</span>';
                            }
                        }
                        $nestedData['acceptance_status'] = $acceptance_status;

                        $itemStatusText = '';
                        $itemStatusClass = '';
                        switch ($issue->is_surrender) {
                            case '0':
                                $itemStatusText = 'Ongoing';
                                $itemStatusClass = 'text_blue';
                                break;
                            case '1':
                                $itemStatusText = 'Surrendered';
                                $itemStatusClass = 'text_green';
                                break;
                        }
                        $nestedData['action'] = '<div class="status_box">';
                        if ($issue->is_surrender == '0') {
                            $nestedData['action'] .= '<div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $k . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . $itemStatusClass . '"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $k . '">
                                        <li>
                                            <a class="dropdown-item text_blue disabled" onclick="issueStatusChange(this)" href="javascript:void(0)" data-table="asset_issues" data-uuid="' . $issue->uuid . '"    data-issued_to="' . $issue->user?->full_name . '"  data-issued_date="' . $issue->issued_date  . '" data-surrender_pdf_route="' . route('admin.assetstock.surrender.download', ["pdf", $issue->uuid]) . '" data-surrender_word_route="' . route('admin.assetstock.surrender.download', ["word", $issue->uuid]) . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Ongoing</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item text_green" onclick="issueStatusChange(this)" href="javascript:void(0)" data-table="asset_issues" data-uuid="' . $issue->uuid . '"    data-issued_to="' . $issue->user?->full_name . '"  data-issued_date="' . $issue->issued_date  . '" data-surrender_pdf_route="' . route('admin.assetstock.surrender.download', ["pdf", $issue->uuid]) . '" data-surrender_word_route="' . route('admin.assetstock.surrender.download', ["word", $issue->uuid]) . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Surrender</a>
                                        </li>
                                    </ul>
                                </div>';
                        } else {
                            $nestedData['action'] .= '<span class="' . $itemStatusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $itemStatusText;
                        }
                        $nestedData['action'] .= '</div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getMaintenanceList(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $totalData = $this->assetStockService->getTotalMaintenances();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'unique_id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $maintenanceList = $this->assetStockService->findMaintenances($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $maintenanceList = $this->assetStockService->findMaintenances($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetStockService->getTotalMaintenances($search);
                }
                if ($maintenanceList) {
                    foreach ($maintenanceList as $key => $maintenance) {
                        $index++;
                        // $nestedData['sl_no'] = $index;
                        $nestedData['unique_id'] = '<a href="' . route('admin.maintenance.view', $maintenance->uuid) . '" class="edit_icon">' . $maintenance->unique_id . '</a>';
                        $nestedData['asset_stock_id'] = $maintenance->stock?->unique_id;
                        $nestedData['location_id'] = $maintenance->location?->street_address;
                        $nestedData['title'] =  $maintenance->title;
                        $nestedData['start_date'] =  Carbon::parse($maintenance->start_date)->format('d-m-Y');
                        $nestedData['end_date'] =  Carbon::parse($maintenance->end_date)->format('d-m-Y');
                        // switch ($maintenance->status) {
                        //     case '0':
                        //         $statusText = 'Ongoing';
                        //         $statusClass = 'text_blue';
                        //         break;
                        //     case '1':
                        //         $statusText = 'Completed';
                        //         $statusClass = 'text_green';
                        //         break;
                        //     case '2':
                        //         $statusText = 'Cancelled';
                        //         $statusClass = 'text_danger';
                        //         break;
                        // }
                        // $nestedData['status'] = '<span class="' . $statusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $statusText;

                        $statusText = '';
                        $statusClass = '';
                        switch ($maintenance->status) {
                            case '0':
                                $statusText = 'Ongoing';
                                $statusClass = 'text_blue';
                                break;
                            case '1':
                                $statusText = 'Completed';
                                $statusClass = 'text_green';
                                break;
                            case '2':
                                $statusText = 'Cancelled';
                                $statusClass = 'text_danger';
                                break;
                        }

                        $nestedData['status'] = '<div class="status_box">';
                        if ($maintenance->status == '0') {
                            if (auth()->user()->canAny(['status-maintenance'])) {
                                $nestedData['status'] .= '<div class="dropdown">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="' . $statusClass . '"><i class="fa-solid fa-circle"></i></span>' . $statusText . '
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <li>
                                                <a class="dropdown-item text_blue disabled" onclick="statusChange(this)" href="javascript:void(0)" data-table="asset_maintenances" data-uuid="' . $maintenance->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Ongoing</a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="asset_maintenances" data-uuid="' . $maintenance->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Completed</a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="asset_maintenances" data-uuid="' . $maintenance->uuid . '" data-status="2"><span><i class="fa-solid fa-circle"></i></span>Cancelled</a>
                                            </li>

                                            <li>
                                                <a class="dropdown-item text_pending" onclick="statusChange(this)" href="javascript:void(0)" data-table="asset_maintenances" data-uuid="' . $maintenance->uuid . '" data-status="2"><span><i class="fa-solid fa-circle"></i></span>All Disposed</a>
                                            </li>
                                        </ul>
                                    </div>';
                            } else {
                                $nestedData['status'] = '';
                            }
                        } else {
                            $nestedData['status'] .= '<span class="' . $statusClass . ' mr-2"><i class="fa-solid fa-circle"></i></span>' . $statusText;
                        }
                        $nestedData['status'] .= '</div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getWorkflows(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->workflowService->listWorkflows($filterCondition)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $workflows = $this->workflowService->listWorkflows($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $workflows = $this->workflowService->listWorkflows($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->workflowService->listWorkflows($filterCondition, $search)->count();
                }
                if ($workflows) {
                    foreach ($workflows as $key => $workflow) {
                        $index++;
                        $nestedData['unique_id'] = '<a href="' . route('admin.workflow.view', $workflow->uuid) . '" class="edit_icon">' . $workflow->unique_id . '</a>';
                        $nestedData['name'] = $workflow->name;
                        $nestedData['description'] = $workflow->description;
                        $nestedData['type'] = $workflow->type;
                        $nestedData['module'] = $workflow->module;

                        $nestedData['status'] = '';
                        if (auth()->user()->canAny(['status-workflow'])) {
                            $nestedData['status'] = '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($workflow->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($workflow->is_active == '1') ? 'Active' : 'In-Active') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="workflows" data-uuid="' . $workflow->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="workflows" data-uuid="' . $workflow->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>In-Active</a></li>
                                    </ul>
                                </div>
                            </div>';
                        }

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';

                        if (auth()->user()->canAny(['edit-workflow'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.workflow.edit', $workflow->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                        }

                        if (auth()->user()->canAny(['delete-workflow'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="workflows" data-uuid="' . $workflow->uuid . '"><i class="fa-solid fa-trash-can"></i></a>';
                        }

                        $nestedData['action'] .= '</div></div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getChallans($poUuid)
    {
        $poData = $this->assetService->findPoId(uuidtoid($poUuid, 'purchase_orders'));
        // dd($poData->arns->pluck('challan_no'));
        $data = $poData->arns->pluck('challan_no');
        return $this->responseJson(true, 200, 'data fetched', $data);
    }

    // public function poPdfDownload(Request $request, $uuid)
    // {
    //     $poData = $this->assetService->findPoId(uuidtoid($uuid, 'purchase_orders'));
    //     $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
    //     $quotations = $this->assetService->getAllQuotations(['is_selected' => 1]);
    //     $vendors = $this->userService->getAllVendors(['is_active' => '1']);
    //     $states = $this->stateService->findStates(['country_id' => 101]);
    //     //dd($states);
    //     $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
    //     // $employees = $this->userService->getEmployees();
    //     $locations = $this->assetService->listLocations();
    //     $paymentScheduleList = $this->assetService->listPaymentSchedules(['purchase_order_id' => $poData->id]);

    //     $quotationData = $this->assetService->findQuotationById($poData->quotation_id);
    //     $vendorData = $this->vendorService->findUserById($poData->vendor_id);
    //     //$stateData = $this->stateService->findState(4853 );
    //     $vendorStateData = State::find($poData->vendor_state);
    //     $deliveryStateData = State::find($poData->delivery_state);
    //     $entityData = $this->categoryService->findCategoryById($poData->entity_id);
    //     //$vendorD
    //     $dompdf = new Dompdf();
    //     $html = view('admin.purchase-order.pdf', compact('entities', 'quotations', 'vendors', 'states', 'poData', 'uuid', 'quotationData', 'vendorData', 'vendorStateData', 'deliveryStateData', 'entityData', 'locations', 'poItems', 'paymentScheduleList'));

    //     $dompdf->loadHtml($html);
    //     $dompdf->setPaper('A4', 'potrait');
    //     $dompdf->render();
    //     $pdfOutput = $dompdf->output();
    //     $filename = 'Purchase_order_details_' . time() . '.pdf';
    //     return Response::make($pdfOutput, 200, [
    //         'Content-Type' => 'application/pdf',
    //         'Content-Disposition' => 'attachment; filename="' . $filename . '"',
    //     ]);
    // }
    public function poPdfDownload(Request $request,)
    {
        if ($request->ajax()) {
            try {

                $uuid = $request->uuid;
                $poData = $this->assetService->findPoId(uuidtoid($request->uuid, 'purchase_orders'));
                $entities = $this->categoryService->listCategories(['is_active' => 1, 'type' => 'entity']);
                $quotations = $this->assetService->getAllQuotations(['is_selected' => 1]);
                $vendors = $this->userService->getAllVendors(['is_active' => '1']);
                $states = $this->stateService->findStates(['country_id' => 101]);
                $poItems = $this->assetService->findPoItems(['purchase_order_id' => $poData->id], 'id', 'asc');
                $locations = $this->assetService->listLocations();
                $paymentScheduleList = $this->assetService->listPaymentSchedules(['purchase_order_id' => $poData->id]);
                $quotationData = $this->assetService->findQuotationById($poData->quotation_id);
                $vendorData = $this->vendorService->findUserById($poData->vendor_id);
                $vendorStateData = State::find($poData->vendor_state);
                $deliveryStateData = State::find($poData->delivery_state);
                $entityData = $this->categoryService->findCategoryById($poData->entity_id);
                $dompdf = new Dompdf();
                $html = view('admin.purchase-order.pdf', compact('entities', 'quotations', 'vendors', 'states', 'poData', 'uuid', 'quotationData', 'vendorData', 'vendorStateData', 'deliveryStateData', 'entityData', 'locations', 'poItems', 'paymentScheduleList'));
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();
                $pdfOutput = $dompdf->output();
                $filename = 'Purchase_order_details_' . time() . '.pdf';
                $pdfBase64 = base64_encode($pdfOutput);
                return $this->responseJson(true, 200, 'PDF Rendered Successfully', ['filename' => $filename, 'pdfContent' => $pdfBase64]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getSiteModules(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->rolePermissionService->listModules($filterCondition)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'asc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $modules = $this->rolePermissionService->listModules($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $modules = $this->rolePermissionService->listModules($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->rolePermissionService->listModules($filterCondition, $order, $dir, null, null, false, $search)->count();
                }
                if ($modules) {
                    foreach ($modules as $module) {
                        $index++;
                        $nestedData['title'] = $module->title;
                        $nestedData['slug'] = $module->slug;
                        $nestedData['type'] = $module->type;

                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">
                                <a href="' . route('admin.settings.module.edit', $module->uuid) . '" class="edit_icon"><i class="fa fa-pen" aria-hidden="true"></i></a>
                                <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="modules" data-uuid="' . $module->uuid . '"><i class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getEmployeList($level)
    {
        $data = $this->userService->getEmployeesByLevel($level);
        return $this->responseJson(true, 200, 'data fetched', $data);
    }
    public function getEmployeeUsers(Request $request)
    {
        $data = $this->userService->getEmployees('', ['entity_id' => $request->entity_id]);
        return $this->responseJson(true, 200, 'data fetched', $data);
    }
    public function getTickets(Request $request)
    {
        if ($request->ajax()) {
            try {
                // $filterConditions = ['raised_id' => Auth()->user()->id];
                $filterCondition = [];
                $search = $request->filterData;
                $type = $request->type ?? '';
                // dd($type);
                $totalData = $this->ticketService->listTickets($filterCondition, $type)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $tickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false);
                } else {
                    $tickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->count();
                }
                if ($tickets) {
                    foreach ($tickets as $key => $ticket) {
                        $nestedData['ticket_id'] = '<a href="' . route('admin.ticket.view', $ticket->uuid) . '" class="edit_icon">' . $ticket->unique_id . '</a>';


                        if($type=='all-tickets'){

                        $userIds=$ticket?->ccTo->pluck('user_id')->toArray();

                        if(($ticket?->ccTo->count() && $ticket?->ccTo[0]?->ticket_id == $ticket->id) && (in_array(auth()->user()->id,$userIds)) )
                            $nestedData['ticket_id'].= '<span class="badge">Its CC to you</span>';

                        }
                        $nestedData['subject'] = $ticket->subject;


                        $nestedData['entity'] = $ticket->entity?->name;
                        $nestedData['department'] = $ticket->department?->name;
                        $nestedData['raised_by'] = '<div class="created_by">
                                                        <h6>' . $ticket->activity(0)?->user?->full_name . '</h6>
                                                        <p>Emp. ID: ' . $ticket->activity(0)?->user?->unique_id . '</p>
                                                    </div>';
                        $nestedData['raised_on'] = Carbon::parse($ticket->activity(0)?->created_at)->format('d-m-Y');
                        $nestedData['completion_date'] = ($ticket->completed_at == null) ? '---' : Carbon::parse($ticket->completed_at)->format('d-m-Y');

                        $priority = '';
                        switch ($ticket->priority) {
                            case '1':
                                $priority = 'High';
                                break;
                            case '2':
                                $priority = 'Medium';
                                break;
                            case '3':
                                $priority = 'Low';
                                break;
                        }
                        $nestedData['priority'] = $priority;

                        $nestedData['status'] = '<div class="status_box">';
                        $assignedUserId = null;
                        if ($ticket->activity(3)) {
                            $assignedUserId = $ticket->activity(3)?->user_id;
                        } elseif ($ticket->activity(2)) {
                            $assignedUserId = $ticket->activity(2)?->user_id;
                        } else {
                            $assignedUserId = $ticket->activity(1)?->user_id;
                        }
                        $assignedTo = '';
                        if ($assignedUserId) {
                            $assignedUser = User::find($assignedUserId);
                            $assignedTo = '<div class="created_by">
                                                <h6>' . $assignedUser?->full_name . '</h6>
                                                <p>Emp. ID: ' . $assignedUser?->unique_id . '</p>
                                            </div>';
                        }
                        $nestedData['assigned_to'] = $assignedTo;
                        $statusText = '';
                        switch ($ticket->status) {
                            case '-1':
                                $statusText = 'Requested For Close';
                                $statusClass = 'text_green';
                                break;
                            case '0':
                                $statusText = 'Closed';
                                $statusClass = 'text_green';
                                break;
                            case '1':
                                $statusText = 'Open';
                                $statusClass = 'text_blue';
                                break;
                            case '2':
                                $statusText = 'Cancelled';
                                $statusClass = 'text_danger';
                                break;
                        }
                        if ((auth()->user()->id == $assignedUserId) && $ticket->status == '1') {
                            $nestedData['status'] .= '<div class="dropdown">
                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="' . $statusClass . '"><i class="fa-solid fa-circle"></i></span>' . $statusText . '
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                    <li><a class="dropdown-item text_blue" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="1" ' . (($ticket->status != '1') ? 'onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Open</a></li>
                                    <li><a class="dropdown-item text_green" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="-1" ' . (($ticket->status != '-1') ? 'onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Close</a></li>
                                </ul>
                            </div>';
                        } else if ((auth()->user()->id == $ticket->activity(0)?->user_id) && $ticket->status == '1') {
                            $nestedData['status'] .= '<div class="dropdown">
                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="' . $statusClass . '"><i class="fa-solid fa-circle"></i></span>' . $statusText . '
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                    <li><a class="dropdown-item text_blue" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="1" ' . (($ticket->status != '1') ? 'onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Open</a></li>
                                    <li><a class="dropdown-item text_danger" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="2" ' . (($ticket->status != '2') ? ' onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Cancel</a></li>
                                </ul>
                            </div>';
                        }else if((auth()->user()->id == $ticket->activity(0)->user_id) && $ticket->status == '-1'){
                            $nestedData['status'] .= '<div class="dropdown">
                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="' . $statusClass . '"><i class="fa-solid fa-circle"></i></span>' . $statusText . '
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                    <li><a class="dropdown-item text_blue" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="0" ' . (($ticket->status != '0') ? 'onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Accept</a></li>
                                    <li><a class="dropdown-item text_danger" href="javascript:void(0)" data-table="tickets" data-uuid="' . $ticket->uuid . '" data-status="1" ' . (($ticket->status != '1') ? ' onclick="ticketStatusChange(this)" ' : '') . '><span><i class="fa-solid fa-circle"></i></span>Deny</a></li>
                                </ul>
                            </div>';
                        } else {
                            $nestedData['status'] .= '<span class="mr-1 ' . $statusClass . '"><i class="fa-solid fa-circle"></i></span>' . $statusText;
                        }
                        $nestedData['status'] .= '</div>';
                        $nestedData['statusCode'] = $ticket->status;
                        $nestedData['action'] = '<div class="action_sec">
                            <div class="action_box">';
                        if (auth()->user()->canAny(['edit-e-ticket']) && $ticket->status == 1 && (auth()->user()->id == $ticket->activity(0)?->user_id)) {
                            $nestedData['action'] .= '<a href="' . route('admin.ticket.edit', $ticket->uuid) . '" class="edit_icon" title="Edit"><i class="fa fa-pen" aria-hidden="true"></i></a>';
                        }



                        // if (auth()->user()->id == $ticket->activity(0)?->user_id && (!$ticket->activity(2) && !$ticket->activity(4)) || (auth()->user()->id == $ticket->activity(0)?->user_id && $ticket->status == 0)) {

                        if (auth()->user()->canAny(['delete-e-ticket']) && $ticket->status == 1 && (auth()->user()->id == $ticket->activity(0)?->user_id)) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="tickets" data-uuid="' . $ticket->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        if ((auth()->user()->id == $ticket->department?->department_manager) && $ticket->status == 1) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon assign_ticket_btn" title="' . ($ticket->activity(2) ? 'Re-Assign' : 'Assign') . '" data-department-uuid="' . $ticket->department?->uuid . '" data-ticket-uuid="' . $ticket->uuid . '"><i class="fa fa-tasks" aria-hidden="true"></i></a>';
                        }

                        $nestedData['action'] .= '</div>
                        </div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getLeases_bk(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $type = $request->type ?? '';
                //$totalData = $this->assetStockService->getTotalLeases();
                $totalData = $this->assetStockService->findLeases($filterCondition, $type)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';


                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $leases = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false);
                } else {
                    $leases = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->count();

                    //$totalFiltered = $this->assetStockService->getTotalLeases($search,$typr);
                }
                // dd($leases);

                if ($leases) {
                    foreach ($leases as $key => $lease) {
                        $nestedData['sl_no'] = ++$key;
                        $nestedData['unique_id'] = '<a href="' . route('admin.lease.view', $lease->uuid) . '" class="edit_icon">' . $lease->unique_id . '</a>';
                        $nestedData['asset_stock_id'] = $lease->assetStock->unique_id;
                        $nestedData['asset_id'] = $lease->asset?->asset_name;


                        // $filterConditions = ['lease_id' => $asset_stock_id];
                        // $totalData = $this->assetStockService->findLeasedItems($filterConditions, $order, $dir, null, null, false, $search)->count();
                        // $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);


                        $nestedData['total_stock'] = $lease->asset?->asset_name;
                        $nestedData['current_stock'] = $lease->asset?->asset_name;
                        $nestedData['issued'] = $lease->asset?->asset_name;

                        $nestedData['from_entity_id'] = $lease->entity?->name;
                        $nestedData['to_entity_id'] = $lease->toEntity?->name;
                        $nestedData['location_id'] = $lease->location?->street_address;
                        $nestedData['lease_duration'] = 'From ' . Carbon::parse($lease->start_date)->format('d/m/Y') . ' To ' . Carbon::parse($lease->end_date)->format('d/m/Y');


                        $nestedData['lease_term'] = $lease->lease_term . " " . $lease->lease_term_frequency;
                        $nestedData['lease_type'] = $lease->lease_type;
                        $nestedData['payment_amount'] = $lease->payment_amount;
                        $nestedData['payment_frequency'] = $lease->payment_frequency;
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }



    public function getLeases(Request $request)
    {
        if ($request->ajax()) {
            try {
                // dd("ttt");
                $filterCondition = [];
                $status = 'all';
                $search = $request->filterData;
                $type = 'unallocated';
                if ($request->type)
                    $type = $request->type;

                //$type = 'unallocated';
                // dd("zsdfghjhgfds");
                //$totalData = $this->assetStockService->getTotalLeases();
                $totalData = $this->assetStockService->findLeases($filterCondition, $type)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';


                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $leases = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false);
                } else {
                    $leases = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetStockService->findLeases($filterCondition, $type, $order, $dir, $limit, $index, false, $search)->count();

                    //$totalFiltered = $this->assetStockService->getTotalLeases($search,$typr);
                }
                // dd($leases);

                if ($leases) {
                    foreach ($leases as $key => $lease) {
                        $nestedData['sl_no'] = ++$key;
                        $nestedData['unique_id'] = '<a href="' . route('admin.lease.view', $lease->uuid) . '" class="edit_icon">' . $lease->unique_id . '</a>';
                        $nestedData['asset_stock_id'] = $lease->assetStock->unique_id;
                        $nestedData['asset_id'] = $lease->asset?->asset_name;


                        $filterConditions = ['lease_id' => $lease->id];
                        //$totalData = $this->assetStockService->findLeasedItems($filterConditions, $order, $dir, null, null, false, $search)->count();

                        $total_stock = LeaseItem::where(['lease_id' => $lease->id, 'is_completed' => 0])->count();

                        $issued_stock = LeaseItem::where(['lease_id' => $lease->id, 'is_completed' => 0])->where('user_id', '!=', null,)->count();

                        // dd($totalData);
                        //$leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);


                        $nestedData['total_stock'] = $total_stock;
                        $nestedData['current_stock'] = $total_stock - $issued_stock;
                        $nestedData['issued'] = $issued_stock;

                        $nestedData['from_entity_id'] = $lease->entity?->name;
                        $nestedData['to_entity_id'] = $lease->toEntity?->name;
                        $nestedData['location_id'] = $lease->location?->street_address;
                        $nestedData['lease_duration'] = 'From ' . Carbon::parse($lease->start_date)->format('d/m/Y') . ' To ' . Carbon::parse($lease->end_date)->format('d/m/Y');


                        $nestedData['lease_term'] = $lease->lease_term . " " . $lease->lease_term_frequency;
                        $nestedData['lease_type'] = $lease->lease_type;
                        $nestedData['payment_amount'] = $lease->payment_amount;
                        $nestedData['payment_frequency'] = $lease->payment_frequency;


                        $asset_stock = $this->assetStockService->findById($lease->asset_stock_id);

                        //$uuid="5a5acb19-aed8-42df-b0c2-9daa4ec307ad";

                        $nestedData['action'] = '<a href="' . route('admin.assetstock.inventory', ['uuid' => $asset_stock->uuid, 'leaseUuid' => $lease->uuid]) . '" class="btn btn-blue btn-sm">View Inventory</a>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }












    // public function populateDepartmentEmployees(Request $request)
    // {
    //     if ($request->ajax()) {
    //         try {
    //             $ticket = $this->ticketService->findTicketById(uuidtoid($request->ticketUuid, 'tickets'));
    //             $department = $this->assetService->findDepartmentById(uuidtoid($request->uuid, 'departments'));
    //             $employeeOptions = '<option value="">--choose one--</option>';
    //             // $employeeProfiles = $department->employeeProfiles->where('user_id', '<>', $department->department_manager);
    //             $employeeProfiles = $department->employeeProfiles;
    //             // $employeeProfiles = $department->getConcernedPersons($department->concerned_persons);
    //             $primarilyAssigned = $ticket->activity(1);
    //             $assignedUserId = $primarilyAssigned->user_id;
    //             $isTicketAssigned = $ticket->activity(3) ? $ticket->activity(3) : $ticket->activity(2);
    //             if ($isTicketAssigned) {
    //                 $assignedUserId = $isTicketAssigned->user_id;
    //             }
    //             $empArr = [];
    //             if ($employeeProfiles) {
    //                 foreach ($employeeProfiles as $employeeProfile) {
    //                     if (!in_array($employeeProfile->user->id, $empArr)) {
    //                         $selected = ($employeeProfile->user->id == $assignedUserId) ? 'selected' : '';
    //                         $employeeOptions .= '<option value="' . $employeeProfile->user->uuid . '" ' . $selected . '>' . $employeeProfile->user->full_name . ' (' . $employeeProfile->user->unique_id . ')</option>';
    //                         $empArr[] = $employeeProfile->user->id;
    //                     }
    //                     // if(!in_array($employeeProfile->id, $empArr)){
    //                     //     $selected = ($employeeProfile->id == $assignedUserId) ? 'selected' : '';
    //                     //     $employeeOptions .= '<option value="' . $employeeProfile->uuid . '" ' . $selected . '>' . $employeeProfile->full_name . ' (' . $employeeProfile->unique_id . ')</option>';
    //                     //     $empArr[] = $employeeProfile->id;
    //                     // }
    //                 }
    //             }
    //             $modalTitle = ($isTicketAssigned) ? 'Re-Assign Ticket #' . $ticket->unique_id : 'Assign Ticket #' . $ticket->unique_id;
    //             return $this->responseJson(true, 200, 'data fetched', ['options' => $employeeOptions, 'modalTitle' => $modalTitle]);
    //         } catch (\Exception $e) {
    //             logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
    //             return $this->responseJson(false, 500, $e->getMessage(), []);
    //         }
    //     }
    //     abort(405);
    // }




    public function populateConcernDepartmentEmployees(Request $request)
    {
        if ($request->ajax()) {
            try {
                $ticket = $this->ticketService->findTicketById(uuidtoid($request->ticketUuid, 'tickets'));
                $department = $this->assetService->findDepartmentById(uuidtoid($request->uuid, 'departments'));



                $employeeOptions = '<option value="">--choose one--</option>';
                $employeeProfiles = $department->employeeProfiles;


                $departementAdminAndConcernPersons = $department->concerned_persons ?? [];
                $departmentAdminUserId = $department->department_manager;

                if (!in_array($departmentAdminUserId, $departementAdminAndConcernPersons)) {
                    $departementAdminAndConcernPersons[] = (string)$departmentAdminUserId;
                }

                $primarilyAssigned = $ticket->activity(1);
                $assignedUserId = $primarilyAssigned->user_id;
                $isTicketAssigned = $ticket->activity(3) ? $ticket->activity(3) : $ticket->activity(2);
                if ($isTicketAssigned) {
                    $assignedUserId = $isTicketAssigned->user_id;
                }
                //$empArr = [];
                // if ($employeeProfiles) {
                //     foreach ($employeeProfiles as $employeeProfile) {
                //         if (!in_array($employeeProfile->user->id, $empArr)) {
                //             $selected = ($employeeProfile->user->id == $assignedUserId) ? 'selected' : '';
                //             $employeeOptions .= '<option value="' . $employeeProfile->user->uuid . '" ' . $selected . '>' . $employeeProfile->user->full_name . ' (' . $employeeProfile->user->unique_id . ')</option>';
                //             $empArr[] = $employeeProfile->user->id;
                //         }
                //     }
                // }
                if (!empty($departementAdminAndConcernPersons)) {
                    foreach ($departementAdminAndConcernPersons as $employeeProfile) {
                        $findUser = User::find($employeeProfile);
                        // if (!in_array($employeeProfile, $empArr)) {
                        $selected = ($employeeProfile == $assignedUserId) ? 'selected' : '';
                        $employeeOptions .= '<option value="' . $findUser->uuid . '" ' . $selected . '>' . $findUser->full_name . ' (' . $findUser->unique_id . ')</option>';
                        //     $empArr[] = $employeeProfile;
                        // }
                    }
                }
                $modalTitle = ($isTicketAssigned) ? 'Re-Assign Ticket #' . $ticket->unique_id : 'Assign Ticket #' . $ticket->unique_id;


                // dd($employeeOptions);
                return $this->responseJson(true, 200, 'data fetched', ['options' => $employeeOptions, 'modalTitle' => $modalTitle]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }








    public function populateDepartmentUsers(Request $request)
    {
        if ($request->ajax()) {
            try {
                // $department = $this->assetService->findDepartmentById(uuidtoid($request->duuid, 'departments'));
                // $employeeOptions = '';
                // $employeeProfiles = $department->getEmployeesByEntity(uuidtoid($request->euuid, 'categories'));
                // if ($employeeProfiles) {
                //     $employees = [];
                //     foreach ($employeeProfiles as $employeeProfile) {
                //         if (!in_array($employeeProfile->user->id, $employees)) {
                //             // $selected = ($employeeProfile->user->id == $department->department_manager) ? 'selected' : '';
                //             $employeeOptions .= '<option value="' . $employeeProfile->user->id . '">' . $employeeProfile->user->full_name . ' (' . $employeeProfile->user->unique_id . ')</option>';
                //             $employees[] = $employeeProfile->user->id;
                //         }
                //     }
                // }
                $employeeOptions = '';
                $employees = $this->userService->getEmployees('', ['entity_id' => uuidtoid($request->euuid, 'categories')]);
                if ($employees) {
                    foreach ($employees as $employee) {
                        $employeeOptions .= '<option value="' . $employee->id . '">' . $employee->full_name . '</option>';
                    }
                }
                return $this->responseJson(true, 200, 'data fetched', ['options' => $employeeOptions]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }


    public function getSlaTimes(Request $request)
    {
        if ($request->ajax()) {
            try {
                $slaTimes = $this->assetService->findSlaTimeByDepartmentId(uuidtoid($request->uuid, 'departments'));
                return $this->responseJson(true, 200, 'data fetched', ['slaTimes' => $slaTimes]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }
    public function updateWidgetPostition(Request $request)
    {
        if ($request->ajax()) {
            DB::beginTransaction();
            try {
                $updateCount = 0;
                if ($request->items) {
                    foreach ($request->items as $widget) {
                        $isPositionUpdated = auth()->user()->widgets()->updateOrCreate([
                            'widget_id' => $widget['id'],
                        ], [
                            'position' => $widget['position'],
                        ]);
                        if ($isPositionUpdated) {
                            $updateCount++;
                        }
                    }
                }
                if (count($request->items) == $updateCount) {
                    DB::commit();
                    return $this->responseJson(true, 200, 'Widget position updated successfully');
                } else {
                    return $this->responseJson(false, 500, 'Something went wrong', '');
                }
            } catch (\Exception $e) {
                DB::rollBack();
                logger($e->getMessage() . 'on' . $e->getFile() . 'in' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), '');
            }
        }
    }

    // public function getVendors($poUuid)
    // {
    //     $poData = $this->assetService->findPoId(uuidtoid($poUuid, 'purchase_orders'));
    //     // dd($poData->arns->pluck('challan_no'));
    //     $data = $poData->arns->pluck('challan_no');
    //     return $this->responseJson(true, 200, 'data fetched', $data);
    // }

    public function getVerificationLists(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetStockService->getTotalVerificationLists();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $verificationLists = $this->assetStockService->findVerificationLists($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $verificationLists = $this->assetStockService->findVerificationLists($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetStockService->getTotalVerificationLists($search);
                }
                if ($verificationLists) {
                    foreach ($verificationLists as $key => $verificationList) {
                        // $nestedData['sl_no'] = ++$key;
                        // $nestedData['verification_id'] = $verificationList->unique_id;
                        $nestedData['name'] = $verificationList->name;
                        // $nestedData['name'] = '<a href="' . route('admin.verification.view', $verificationList->uuid) . '" class="edit_icon">' . $verificationList->name . '</a>';
                        $nestedData['start_date'] = Carbon::parse($verificationList->start_date)->format('d-m-Y') . ' to ' . Carbon::parse($verificationList->end_date)->format('d-m-Y');
                        $nestedData['asset_info'] = '<p>Category: <strong>' . ucwords($verificationList->category?->name) . '</strong></p>Type: <strong>' . ucwords($verificationList->assetType?->name) . '</strong></p><p>Asset Name/Model No: <strong>' . ucwords($verificationList->asset?->asset_name) . '</strong></p>';
                        $nestedData['location'] = $verificationList->location?->street_address;
                        $nestedData['entity'] = $verificationList->entity?->name;
                        $nestedData['verified_by'] = $verificationList->verifiedBy?->full_name;
                        $nestedData['status'] = '<span class="mr-3 ' . (($verificationList->status == '1') ? 'text_green' : 'text_blue') . '"><i class="fa-solid fa-circle"></i></span>' . (($verificationList->status == '1') ? 'Completed' : 'On-Going');
                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if (auth()->user()->hasRole('super-admin') || auth()->user()->canAny(['edit-physical-verification'])) {
                            if ($verificationList->status == '0') {
                                $continueUrl = ($verificationList->step == '1') ? route('admin.verification.add', $verificationList->uuid) : route('admin.verification.verify', $verificationList->uuid);
                                $nestedData['action'] .= '<a href="' . $continueUrl . '" class="edit_icon btn-sm btn-primary" title="Continue">Continue</a>';
                            } else {
                                $nestedData['action'] .= '<a href="' . route('admin.verification.view', $verificationList->uuid) . '" class="edit_icon btn-sm btn-primary" title="View">View</a>';
                            }


                            // $nestedData['action'] .= '<a href="' . route('admin.verification.edit', $verificationList->uuid) . '" class="edit_icon" title="Edit"><i class="fa fa-pen" aria-hidden="true"></i> </a>';
                        }
                        if ((auth()->user()->hasRole('super-admin') || auth()->user()->canAny(['export-physical-verification'])) && $verificationList->status != '0') {

                            $nestedData['action'] .= '<a href="' . route('admin.verification.excel.download', $verificationList->uuid) . '" class="edit_icon text-primary h6" title="Excel Download"><i class="fas fa-download"></i>

                        </a>';
                        }
                        if (auth()->user()->hasRole('super-admin') || auth()->user()->canAny(['delete-physical-verification'])) {
                            $nestedData['action'] .= '<a href="javascript:;" class="edit_icon text-danger deleteData" data-table="asset_verifications" data-uuid="' . $verificationList->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getInventoriesByAssetId(Request $request)
    {
        $asset = $this->assetService->findById($request->assetId);
        if ($asset->count()) {
            $inventories = $asset->inventories->pluck('identification_no', 'id')->toArray();
            return $this->responseJson(true, 200, 'Inventories Fetched.', $inventories);
        }
        return $this->responseJson(false, 500, 'Something went wrong!', "");
        abort(405);
    }
    public function getInventoryByIdentificationNo(Request $request)
    {
        $inventoryData = $this->assetService->findInventoryByCondition([
            'identification_no' => preg_replace('/\s+/', '', strtoupper($request->identificationNo)),
        ]);
        return $this->responseJson(true, 200, 'Inventory Data Fetched.', $inventoryData);
    }
    public function getVerifiedAssetById(Request $request)
    {
        $verifiedAssetData = $this->assetStockService->findVerifiedAssetById($request->id);
        return $this->responseJson(true, 200, 'Verified Asset Data Fetched.', $verifiedAssetData);
    }

    public function getVendorsByLocation(Request $request)
    {
        if ($request->ajax()) {
            try {
                $search = $request->term;
                $users = $this->vendorService->findUserByLocation($search);
                $data = [];
                $nestedData = [];
                if ($users) {
                    foreach ($users as $user) {
                        $nestedData['id'] = $user->id;
                        $nestedData['text'] = $user->full_name;
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function updateAvailability(Request $request)
    {
        if ($request->ajax()) {
            $table = $request->find;
            $id = uuidtoid($request->uuid, $table);
            $data = $this->userService->updateUser($request->only('is_available'), $id);
            $message = 'User availability updated';
            if ($data) {
                $this->userService->updateAlternateApprover([
                    'user_id' => $id
                ], [
                    'approver_id' => null,
                ]);
                return $this->responseJson(true, 200, $message);
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function updatePoVendorApproval(Request $request)
    {
        if ($request->ajax()) {
            $data = $this->assetService->addOrUpdatePurchaseOrder(['uuid' => $request->uuid], ['is_vendor_approved' => $request->is_vendor_approved, 'vendor_approval_rejection_comments' => $request->vendor_approval_rejection_comments]);
            if ($data) {
                return $this->responseJson(true, 200, 'Po status updated');
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function assetStockExcelDownload(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filename = 'Asset_stock_details_' . time() . '.xlsx';
                $asset = $this->assetService->findById(uuidtoid($request->assetUuid, 'assets'));
                $search = $request->filterData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                if (!$search) {
                    $assetStock = $this->assetStockService->findAssetStock(['asset_id' => uuidtoid($request->assetUuid, 'assets')], $order, $dir, $limit, $index, false);
                } else {
                    $assetStock = $this->assetStockService->findAssetStock(['asset_id' => uuidtoid($request->assetUuid, 'assets')], $order, $dir, $limit, $index, false, $search);
                }
                return Excel::download(new AssetStockDetailsExport($asset, $assetStock), $filename);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
            }
        }
        abort(405);
    }
    public function assetExcelDownload(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filename = 'Asset_list_details_' . time() . '.xlsx';
                $filterCondition = [];
                $search = $request->filterData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                if (!$search) {
                    $assets = $this->assetService->findAssets($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assets = $this->assetService->findAssets($filterCondition, $order, $dir, $limit, $index, false, $search);
                }
                return Excel::download(new AssetDetailsExport($assets), $filename);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
            }
        }
        abort(405);
    }
    public function getAssetStockItems(Request $request)
    {
        if ($request->ajax()) {
            try {
                $asset_stock_id = uuidtoid($request->uuid, 'asset_stocks');
                $filterConditions = ['asset_stock_id' => $asset_stock_id];
                $order = 'id';
                $dir = 'desc';
                $search = $request->search['value'];
                $totalData = $this->assetStockService->findInStockItems($filterConditions, $order, $dir, null, null, false, $search)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $index = $start;
                $nestedData = [];
                $data = [];

                $inventories = $this->assetStockService->findInStockItems($filterConditions, $order, $dir, $limit, $index, false, $search);
                if ($inventories) {
                    foreach ($inventories as $k => $inventory) {
                        $index++;
                        $nestedData['SrNo'] = $k + 1;
                        $nestedData['identification_no'] = $inventory->identification_no;
                        $nestedData['sl_no'] = $inventory->unique_id;
                        $nestedData['capacity_spec'] = $inventory->capacity_specs;
                        $nestedData['warranty_licence_date'] = $inventory->warranty_licence_date ? Carbon::parse($inventory->warranty_licence_date)->format('d-m-Y') : '';
                        $nestedData['asset_condition'] = $inventory->asset_condition;
                        $nestedData['purchase_date'] = $inventory->purchase_date ? Carbon::parse($inventory->purchase_date)->format('d-m-Y') : '';
                        $nestedData['amount'] = '<input type="number" min="0" name="amount[]" class="form-control amount" id="amount_' . $inventory->id . '" value="0">';
                        $nestedData['action'] = '<div class="action_sec">';
                        $nestedData['action'] .= '<input type="checkbox" name="asset_items[]" class="lease_item" id="lease_item_' . $inventory->id . '" value="' . $inventory->id . '" data-unique-id="' . $inventory->unique_id . '">';
                        $nestedData['action'] .= '<div id="lease_sec_' . $inventory->id . '" class="lease_sec"></div>';
                        $nestedData['action'] .= '</div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getInvoiceApprovals(Request $request)
    {
        $invoiceId = uuidtoid($request->uuid, 'purchase_order_invoices');
        $invoiceData = $this->assetService->findInvoiceById($invoiceId);
        $approvalStatusHtml = '';
        if ($invoiceData?->approval) {
            $approvalStatusHtml .= '<div class="col-md-12">
                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-3 field_head"><label>Approver Level</label></div>
                        <div class="col-sm-2 field_head"><label>Status</label></div>
                        <div class="col-sm-2 field_head"><label>Date</label></div>
                        <div class="col-sm-5 field_head"><label>Approval/Rejection Comments</label></div>
                    </div>
                </div>
            </div>';
            foreach ($invoiceData?->approval as $poInvoiceApproval) {
                switch ($poInvoiceApproval->status) {
                    case '0':
                        $statClass = 'text_pending';
                        $status = 'Pending';
                        break;
                    case '1':
                        $statClass = 'text_green';
                        $status = 'Approved';
                        break;
                    case '2':
                        $statClass = 'text_danger';
                        $status = 'Rejected';
                        break;
                    default:
                        $statClass = '';
                        $status = 'Not Sent';
                        break;
                }
                $approvalStatusHtml .= '<div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-3 mt-0"><strong>Level ' . $poInvoiceApproval->level . ': </strong>' . $poInvoiceApproval->user->full_name . '</div>
                            <div class="col-sm-2"><span class="' . $statClass . '"><i class="fa-solid fa-circle mr-1"></i>' . $status . '</span></div>
                            <div class="col-sm-2">' . (($poInvoiceApproval->status == 1 || $poInvoiceApproval->status == 2) ? Carbon::parse($poInvoiceApproval->updated_at)->format('d-m-Y') : 'NA') . '</div>
                            <div class="col-sm-5"><p>' . ($poInvoiceApproval->comments ?? 'NA') . '</p></div>
                        </div>
                    </div>
                </div>';
            }
        }
        return $this->responseJson(true, 200, 'Asset Details Fetched.', [$approvalStatusHtml]);
        abort(405);
    }
    public function getSearchedAssets(Request $request)
    {
        if ($request->ajax()) {
            try {
                // dd($request->all());
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetService->getTotalSearchedAssets(null, $filterCondition);
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $assets = $this->assetService->findSearchedAssets($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assets = $this->assetService->findSearchedAssets($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetService->getTotalSearchedAssets($search, $filterCondition);
                }
                if ($assets) {
                    foreach ($assets as $key => $asset) {
                        $index++;
                        $nestedData['asset_info'] = '<a href="' . route('admin.assetstock.list', $asset->uuid) . '">';
                        $nestedData['asset_info'] .= '<div class="row">';
                        $nestedData['asset_info'] .= '<div class="col-md-4">Id: <strong>' . $asset->asset_id . '</strong></div>';
                        $nestedData['asset_info'] .= '<div class="col-md-8"><p>Name: <strong>' . ucwords($asset->asset_name) . '</strong><br>';
                        $nestedData['asset_info'] .= 'Category: <strong>' . ucwords($asset->category?->name) . '</strong><br>';
                        $nestedData['asset_info'] .= 'Type: <strong>' . ucwords($asset->assettype?->name) . '</strong></p></div>';
                        $nestedData['asset_info'] .= '</div>';
                        $nestedData['asset_info'] .= '</a>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function updateTermAndConditions(Request $request)
    {
        if ($request->ajax()) {
            $orderData = $request->orderData;
            $updateCount = 0;
            if (count($orderData)) {
                foreach ($orderData as $data) {
                    $isUpdated = $this->assetService->updateTermAndConditions(['order' => $data['order']], $data['id']);
                    if ($isUpdated) {
                        $updateCount++;
                    }
                }
            }

            if (count($orderData) == $updateCount) {
                return $this->responseJson(true, 200, 'Order updated');
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function updateAttributes(Request $request)
    {
        if ($request->ajax()) {
            $orderData = $request->orderData;
            $updateCount = 0;
            if (count($orderData)) {
                foreach ($orderData as $data) {
                    $isUpdated = $this->assetService->addOrUpdateAttribute(['order' => $data['order']], $data['id']);
                    if ($isUpdated) {
                        $updateCount++;
                    }
                }
            }
            if (count($orderData) == $updateCount) {
                return $this->responseJson(true, 200, 'Order updated');
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        }
        abort(405);
    }
    public function getAssetTypeAttributes(Request $request, $id)
    {
        if ($request->ajax()) {
            try {
                $filterConditions = ['asset_type_id' => $id];
                $attributes = $this->assetService->getAttributes($filterConditions);
                $jsonData = array(
                    "data" => $attributes,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getAssetTypes(Request $request, $role = null)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                $search = $request->filterData;
                $totalData = $this->assetTypeService->findAssetTypes($filterCondition)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'name';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }

                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $assetTypes = $this->assetTypeService->findAssetTypes($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assetTypes = $this->assetTypeService->findAssetTypes($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->assetTypeService->findAssetTypes($filterCondition, $order, $dir, null, null, false, $search)->count();
                }
                if ($assetTypes) {
                    foreach ($assetTypes as $key => $assetType) {
                        $index++;
                        //echo $assetType->name;
                        //dd($assetType->category);
                        $nestedData['type_id'] = $assetType->type_id;
                        $nestedData['name'] = $assetType->name;
                        $nestedData['parent'] = $assetType->parent?->name;
                        $nestedData['category'] = $assetType->category?->name;
                        $nestedData['depreciation_settings'] = $assetType->depreciationSettings ? '<div class="depreciation_sec"><label><strong>Useful Life:</strong> ' . $assetType->depreciationSettings->useful_years . ' Years</label><br><label><strong>Effective Rate:</strong> ' . $assetType->depreciationSettings->effective_rate . '%</label><br><label><strong>Salvage Value:</strong> ' . $assetType->depreciationSettings->salvage_value . '%</label></div>' : '';
                        $nestedData['is_active'] = '<div class="action_sec">';
                        if (auth()->user()->canAny(['status-asset-type'])) {
                            $nestedData['is_active'] .= '<div class="status_box"><div class="dropdown">';
                            $nestedData['is_active'] .= '<button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false"><span class="' . (($assetType->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($assetType->is_active == '1') ? 'Active' : 'Deactive') . '</button>';
                            $nestedData['is_active'] .= '<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '"><li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-type="' . ($assetType->is_active == '1' ? 'active' : 'inactive') . '" data-table="asset_types" data-uuid="' . $assetType->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li><li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-type="' . ($assetType->is_active == '1' ? 'active' : 'inactive') . '" data-table="asset_types" data-uuid="' . $assetType->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li></ul>';
                            $nestedData['is_active'] .= '</div></div>';
                        }
                        $nestedData['is_active'] .= '</div>';
                        $nestedData['action'] = '<div class="action_sec">';
                        $nestedData['action'] .= '<div class="action_box">';
                        if (auth()->user()->canAny(['edit-asset-type'])) {
                            $nestedData['action'] .= '<a href="' . route('admin.assettype.edit', $assetType->uuid) . '" class="edit_icon editlist"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }
                        if (auth()->user()->canAny(['delete-asset-type'])) {
                            $nestedData['action'] .= '<a href="javascript:void(0)" data-table="asset_types" data-uuid="' . $assetType->uuid . '" class="edit_icon text-danger deleteData"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        if (auth()->user()->canAny(['edit-asset-type']) && $assetType->category?->slug == 'non-consumable' && !$assetType->children?->count()) {
                            $nestedData['action'] .= '<a href="' . route('admin.assettype.depreciation.settings', $assetType->uuid) . '" class="edit_icon editlist" title="Depreciation Settings"><i class="fa fa-cog" aria-hidden="true"></i></a>';
                        }
                        $nestedData['action'] .= '</div>';
                        $nestedData['action'] .= '</div>';

                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getMasterList(Request $request, $type)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = ['type' => $type];
                $search = $request->filterData;
                $totalData = $this->categoryService->listCategories($filterCondition)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'name';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $masterData = $this->categoryService->listCategories($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $masterData = $this->categoryService->listCategories($filterCondition, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->categoryService->listCategories($filterCondition, $order, $dir, null, null, false, $search)->count();
                }
                if ($masterData) {
                    foreach ($masterData as $key => $mData) {
                        $index++;
                        $nestedData['name'] = $mData->name;
                        $nestedData['description'] = $mData->description;
                        $nestedData['is_active'] = '<div class="action_sec">';
                        if (auth()->user()->canAny(['status-' . $type])) {
                            $nestedData['is_active'] .= '<div class="status_box">
                                <div class="dropdown">
                                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                        <span class="' . (($mData->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($mData->is_active == '1') ? 'Active' : 'Deactive') . '
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                        <li><a class="dropdown-item text_green" onclick="statusChange(this)" href="javascript:void(0)" data-table="categories" data-uuid="' . $mData->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                        <li><a class="dropdown-item text_danger" onclick="statusChange(this)" href="javascript:void(0)" data-table="categories" data-uuid="' . $mData->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                                    </ul>
                                </div>
                            </div>';
                        }
                        $nestedData['is_active'] .= '</div>';
                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        if (auth()->user()->canAny(['edit-' . $type])) {
                            $nestedData['action'] .= '<a href="' . route('admin.master-edit', ['type' => $type, 'uuid' => $mData->uuid]) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>';
                        }
                        if (auth()->user()->canAny(['delete-' . $type])) {
                            $nestedData['action'] .= '<a href="javascript:void(0)" data-table="categories" data-uuid="' . $mData->uuid . '" class="edit_icon text-danger deleteData"><i class="fa-solid fa-trash-can"></i></a>';
                        }
                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    public function getDepreciationSettingsData(Request $request, $id)
    {
        if ($request->ajax()) {
            try {
                $filterConditions = ['asset_type_id' => $id];
                $depreSettingsData = $this->reportService->getDepreciationSettings($filterConditions);
                $jsonData = array(
                    "data" => $depreSettingsData,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return response()->json(array(
                    "data" => []
                ));
            }
        }
        abort(405);
    }
    public function getTicketCategories(Request $request, $duuid, $uuid = null)
    {
        if ($request->ajax()) {
            try {
                $departmentId = uuidtoid($duuid, 'departments');
                $department = $this->assetService->findDepartmentById($departmentId);
                $filterConditions = [
                    'department_id' => $departmentId,
                    'parent_id' => null
                    // 'parent_id' => $uuid ? uuidtoid($uuid, 'ticket_categories') : null
                ];
                $totalData = $this->ticketService->listTicketCategories($filterConditions)->count();
                $totalFiltered = $totalData;
                $limit = 20;
                $start = 0;
                $order = 'name';
                $dir = 'asc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                // $nestedData = [];
                $data = [];
                $search = $request->filterData;
                if (!$search) {
                    $categories = $this->ticketService->listTicketCategories($filterConditions, $order, $dir, $limit, $index);
                    // dd($categories);
                } else {
                    $categories = $this->ticketService->listTicketCategories($filterConditions, $order, $dir, $limit, $index, false, $search);
                    $totalFiltered = $this->ticketService->listTicketCategories($filterConditions, $order, $dir, null, null, false, $search)->count();
                }

                $data = $this->getTicketCategoryList($categories, $department->uuid);
                // dd($data);
                // if ($categories) {
                //     foreach ($categories as $key => $category) {
                //         $nestedData['name'] = '<p class="table-con">' . $category->name . '</p>';
                //         $nestedData['subcategories'] = '<p class="table-con"><a href="' . route('admin.settings.ticket.categories', [$department->uuid, $category->uuid]) . '" class="edit_icon" title="Ticket Sub Categories"><i class="fa fa-list"></i><sup>'.$category->children->count().'</sup></a></p>';
                //         $nestedData['is_active'] = '<div class="action_sec">
                //             <div class="status_box">
                //                 <div class="dropdown">
                //                     <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                //                         <span class="' . (($category->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($category->is_active == '1') ? 'Active' : 'Inactive') . '
                //                     </button>
                //                     <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                //                         <li><a class="dropdown-item text_green" ' . (($category->is_active != '1') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                //                         <li><a class="dropdown-item text_danger" ' . (($category->is_active != '0') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                //                     </ul>
                //                 </div>
                //             </div>
                //         </div>';

                //         $nestedData['action'] = '<div class="action_sec">
                //             <div class="action_box">
                //                 <a href="' . route('admin.settings.ticket.category.edit', [$department->uuid, $category->uuid]) . '" class="edit_icon"><i class="fa-regular fa-pen-to-square"></i></a>
                //                 <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="ticket_categories" data-uuid="' . $category->uuid . '"><i class="fa-solid fa-trash-can"></i></a>
                //             </div>
                //         </div>';
                //         $data[] = $nestedData;
                //         $nestedData = [];
                //     }
                // }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );
                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
    private function getTicketCategoryList($categories, $departmentUuid, $isChildRow = false, $data = [])
    {
        if ($categories->count()) {
            foreach ($categories as $key => $category) {
                $nestedData = [];
                $priority = '';
                switch ($category->priority) {
                    case '1':
                        $priority = 'High';
                        break;
                    case '2':
                        $priority = 'Medium';
                        break;
                    case '3':
                        $priority = 'Low';
                        break;
                }
                $categoryNameClass = $isChildRow ? 'child-category-name' : '';
                $nestedData['name'] = '<p class="table-con category-name ' . $categoryNameClass . '">' . $category->name . '</p>';
                $nestedData['parent'] = '<p class="table-con">' . $category->parent?->name . '</p>';
                $nestedData['description'] = '<p class="table-con">' . $category->description . '</p>';
                $nestedData['priority'] = '<p class="table-con">' . $priority . '</p>';
                $nestedData['is_active'] = '<div class="action_sec">
                    <div class="status_box">
                        <div class="dropdown">
                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton' . $key . '" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="' . (($category->is_active == '1') ? 'text_green' : 'text_danger') . '"><i class="fa-solid fa-circle"></i></span>' . (($category->is_active == '1') ? 'Active' : 'Inactive') . '
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $key . '">
                                <li><a class="dropdown-item text_green" ' . (($category->is_active != '1') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="1"><span><i class="fa-solid fa-circle"></i></span>Active</a></li>
                                <li><a class="dropdown-item text_danger" ' . (($category->is_active != '0') ? 'onclick="statusChange(this)" ' : '') . ' href="javascript:void(0)" data-table="ticket_categories" data-uuid="' . $category->uuid . '" data-status="0"><span><i class="fa-solid fa-circle"></i></span>Inactive</a></li>
                            </ul>
                        </div>
                    </div>
                </div>';

                $nestedData['action'] = '<div class="action_sec">
                    <div class="action_box">';
                if (!$category->children->count()) {
                    $nestedData['action'] .= '<a href="' . route('admin.settings.ticket.category.concerned', [$departmentUuid, $category->uuid]) . '" class="edit_icon" title="Concerned Persons"><i class="fa fa-user" aria-hidden="true"></i></a>';
                }
                $nestedData['action'] .= '<a href="' . route('admin.settings.ticket.category.edit', [$departmentUuid, $category->uuid]) . '" class="edit_icon" title="Edit"><i class="fa-regular fa-pen-to-square"></i></a>
                        <a href="javascript:;" class="edit_icon text-danger deleteData" data-table="ticket_categories" data-uuid="' . $category->uuid . '" title="Delete"><i class="fa-solid fa-trash-can"></i></a>
                    </div>
                </div>';
                $data[] = $nestedData;
                if ($category->children->count()) {
                    $data = $this->getTicketCategoryList($category->children, $departmentUuid, true, $data);
                }
            }
        }
        return $data;
    }
    public function deleteConcernedPerson(Request $request)
    {
        if ($request->ajax()) {
            $id = uuidtoid($request->uuid, 'users');
            $did = uuidtoid($request->duuid, 'departments');
            $department = $this->assetService->findDepartmentById($did);
            $concernedPersons = $department->concerned_persons;
            if (($key = array_search($id, $concernedPersons)) !== false) {
                unset($concernedPersons[$key]);
                $concernedPersons = array_values($concernedPersons);
            }
            $isUpdated = $this->assetService->createOrUpdateDepartment(['concerned_persons' => count($concernedPersons) ? $concernedPersons : null], $did);
            if ($isUpdated) {
                return $this->responseJson(true, 200, 'Concerned person deleted successfully');
            } else {
                return $this->responseJson(false, 500, 'Something Wrong Happened');
            }
        } else {
            abort(405);
        }
    }
    public function getTicketCategoryOptions(Request $request, $did, $pid = null)
    {
        if ($request->ajax()) {
            try {
                $filterConditions = [
                    'department_id' => $did,
                    'parent_id' => $pid
                ];
                $categories = $this->ticketService->listTicketCategories($filterConditions);
                $categoryOptions = '<option value="">--choose one--</option>';
                if ($categories) {
                    foreach ($categories as $category) {
                        $categoryOptions .= '<option value="' . $category->id . '" data-priority="' . $category->priority . '">' . $category->name . '</option>';
                    }
                }
                return $this->responseJson(true, 200, 'data fetched', ['options' => $categoryOptions, 'option_count' => count($categories)]);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }
    public function rfqResend(Request $request)
    {
        if ($request->ajax()) {
            try {
                $findVendodData = Vendor::find($request->userId);
                $mailData = [
                    'to' => $findVendodData->email,
                    'from' => env('MAIL_FROM_ADDRESS'),
                    'mail_type' => 'general',
                    'line' => 'You got a RFQ',
                    'content' => "Please check RFQ details.<br>Your OTP is: " . $request->otp . "<br>Quotation submission link: " . $request->link,
                    'subject' => 'RFQ',
                    'greetings' => 'Hello Sir/Madam',
                    'end_greetings' => 'Regards,',
                    'from_user' => env('MAIL_FROM_NAME')
                ];
                $isMailSend = Mail::send(new SendMailable($mailData));
                if ($isMailSend) {
                    return $this->responseJson(true, 200, 'RFQ successfully resend');
                } else {
                    return $this->responseJson(false, 500, 'Something Wrong Happened');
                }
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }



    public function clearNotification(Request $request)
    {
        if ($request->ajax()) {
            try {

                // $isNotificationCleared=auth()->user()->notifications()->update('deleted_at'=>date('Y-m-d'));

                // $isNotificationCleared = auth()->user()->notifications()->update(['deleted_at' => Carbon::now()]);

                $notiId = $request->notiId;
                $isRead = $request->isRead;
                $message = 'Notifications cleared successfully';
                if(!$notiId){
                    auth()->user()->unreadNotifications->markAsRead();
                }else{
                    $notification = auth()->user()->notifications()->where('id', $notiId)->first();
                    if(!$isRead){
                        $notification->markAsRead();
                        $message = 'Notifications marked as read successfully';
                    }else{
                        $test = $notification->update(['read_at' => null]);
                        $message = 'Notifications marked as unread successfully';
                    }
                }

                return $this->responseJson(true, 200, $message);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }
    public function deleteNotification(Request $request)
    {
        if ($request->ajax()) {
            try {
                if($request->notiId){
                    $isNotificationDeleted = auth()->user()->notifications()->where('id', $request->notiId)->update(['deleted_at' => Carbon::now()]);
                }else{
                    $isNotificationDeleted = auth()->user()->notifications()->update(['deleted_at' => Carbon::now()]);
                }

                if ($isNotificationDeleted) {
                    return $this->responseJson(true, 200, 'Notifications deleted successfully');
                } else {
                    return $this->responseJson(false, 500, 'Something Wrong Happened');
                }

            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $this->responseJson(false, 500, $e->getMessage(), []);
            }
        }
        abort(405);
    }


    public function getNewLeaseList(Request $request)
    {
        if ($request->ajax()) {
            try {
                $filterCondition = [];
                if ($request->assetUuid) {
                    $filterCondition['asset_id'] = uuidtoid($request->assetUuid, 'assets');
                }
                $search = $request->filterData;
                // $totalData = $this->assetStockService->getTotalAssetStock($filterCondition);
                $totalData = $this->assetStockService->findNewList($filterCondition)->count();
                $totalFiltered = $totalData;
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'unique_id';
                $dir = 'desc';
                if (isset($request->order) && is_array($request->order)) {
                    $order = $request->order[0]['name'];
                    $dir = $request->order[0]['dir'];
                }
                $index = $start;
                $nestedData = [];
                $data = [];
                if (!$search) {
                    $assetStock = $this->assetStockService->findNewList($filterCondition, $order, $dir, $limit, $index, false);
                } else {
                    $assetStock = $this->assetStockService->findNewList($filterCondition, $order, $dir, $limit, $index, false, $search);
                    // $totalFiltered = $this->assetStockService->getTotalAssetStock($filterCondition, $search);
                    $totalFiltered = $this->assetStockService->findNewList($filterCondition, $search)->count();
                }
                if ($assetStock) {
                    foreach ($assetStock as $key => $stock) {



                        // if($leased_qty > 0){
                        $index++;
                        $nestedData['id'] = $index;
                        $nestedData['unique_id'] = $stock->unique_id;
                        $nestedData['location'] = $stock->location?->street_address;
                        $nestedData['entity'] = $stock->entity?->name;
                        $categoryData = $this->categoryService->findCategoryById($stock->lease?->first()->to_entity_id);
                        $nestedData['leased_entity'] = $categoryData->name;
                        $nestedData['current_stock'] = $stock->current_stock;
                        $issued_qty = $stock->assetIssue?->where('is_surrender', '0')->sum('quantity');
                        $nestedData['issued'] = $issued_qty ? '<a href="' . route('admin.assetstock.issued.list', $stock->uuid) . '" >' . $issued_qty . '</a>' : 0;

                        $leased_qty = 0;
                        $leased_agreements = $this->assetService->findLeasedAgreements(['asset_stock_id' => $stock->id]);
                        if ($leased_agreements) {
                            foreach ($leased_agreements as $leased_agreement) {
                                $leased_qty += $leased_agreement->leaseItems->where('is_completed', '0')->count();
                            }
                        }

                        $maintenance_qty = 0;
                        $disposed_qty = 0;
                        $asset_maintenances = $this->assetService->findAssetMaintenances(['asset_stock_id' => $stock->id]);
                        if ($asset_maintenances) {
                            foreach ($asset_maintenances as $asset_maintenance) {
                                $maintenance_qty += $asset_maintenance->maintenanceItems->where('status', '0')->count();
                                $disposed_qty += $asset_maintenance->maintenanceItems->where('status', '2')->count();
                            }
                        }
                        if ($stock->asset->has_unique_number) {
                            $nestedData['leased'] = '<a href="' . route('admin.assetstock.leased.list', $stock->uuid) . '" >' . $leased_qty . '</a>';

                            $nestedData['under_maintenance'] = $maintenance_qty ? '<a href="' . route('admin.assetstock.maintenance.list', $stock->uuid) . '" >' . $maintenance_qty . '</a>' : 0;

                            $nestedData['disposed'] = $disposed_qty ? '<a href="' . route('admin.assetstock.disposal.list', $stock->uuid) . '" >' . $disposed_qty . '</a>' : 0;
                        }

                        $nestedData['total_stock'] = $stock->current_stock + $issued_qty + $leased_qty + $maintenance_qty + $disposed_qty;

                        $nestedData['action'] = '<div class="action_sec"><div class="action_box">';
                        $nestedData['action'] .= '<a href="' . route('admin.assetstock.inventory', $stock->uuid) . '" class="btn btn-blue btn-sm">View Inventory</a>';

                        if ($stock->asset->category->slug == 'non-consumable') {
                            // if ($stock->current_stock > 0) {
                            //     if (auth()->user()->canAny(['add-lease'])) {
                            //         $nestedData['action'] .= '<a href="' . route('admin.assetstock.lease', $stock->uuid) . '" class="btn btn-green btn-sm">Add Lease</a>';
                            //     }
                            // }
                            if ($stock->current_stock > 0 || ($stock->current_stock == 0 && $stock->assetIssue->count())) {
                                if (auth()->user()->canAny(['add-maintenance'])) {
                                    $nestedData['action'] .= '<a href="' . route('admin.assetstock.maintenance', $stock->uuid) . '" class="btn btn-green btn-sm">Add Maintenance</a>';
                                }
                            }
                            // if ($stock->current_stock > 0) {
                            //     if (auth()->user()->canAny(['edit-asset'])) {
                            //         $nestedData['action'] .= '<a href="' . route('admin.assetstock.transfer', $stock->uuid) . '" class="btn btn-orange btn-sm">TRANSFER</a>';
                            //     }
                            // }
                        }

                        $nestedData['action'] .= '</div></div>';
                        $data[] = $nestedData;
                        $nestedData = [];



                        // }
                    }
                }
                $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) $totalData,
                    "recordsFiltered" => (int) $totalFiltered,
                    "data" => $data,
                );

                return response()->json($jsonData);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }

    public function getEmployeeByEntity(Request $request)
    {

        if ($request->ajax()) {
            try {

                $employees = $this->userService->getEmployees('', ['entity_id' => $request->to_entity_id]);
                $message = 'Employee fetch successfully';
                return $this->responseJson(true, 200, $message, $employees);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }


    public function getTicketCountByEntity(Request $request)
    {

        if ($request->ajax()) {
            try {


                $filterCondition = [
                    'entity_id' => $request->entity_id,
                ];
                $type = $request->type ?? '';
                $limit = $request->input('length');
                $start = $request->input('start');
                $order = 'id';
                $dir = 'desc';
                $index = $start;
                $search = $request->filterData;
                // $specificDate = Carbon::createFromDate(2023, 10, 1);
                $today = Carbon::today();
                // $today = $specificDate;
                $filterCondition['status'] = '1';
                $opentickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                $filterCondition['status'] = '-1';
                $inprogresstickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                $filterCondition['status'] = '0';
                $closedtickets = $this->ticketService->listTickets($filterCondition, $type, $order, $dir, $limit, $index, false, $search);
                // dd($inprogresstickets);
                $openValue = $opentickets->count();
                $inprogressValue = $inprogresstickets->count();
                $closedValue = $closedtickets->count();


                // $employees = $this->userService->getEmployees('', ['entity_id' => $request->entity_id]);
                $message = 'Ticket count fetch successfully';

                $data = [
                    'openValue' => $openValue,
                    'inprogressValue' => $inprogressValue,
                    'closedValue' => $closedValue,

                ];
                // dd($opentickets);
                // return $this->responseJson(true, 200, $message, $employees);
                return $this->responseJson(true, 200, $message, $data);
            } catch (\Exception $e) {
                logger($e->getMessage() . ' on ' . $e->getFile() . ' line number ' . $e->getLine());
                return $jsonData = array(
                    "draw" => (int) $request->input('draw'),
                    "recordsTotal" => (int) 0,
                    "recordsFiltered" => (int) 0,
                    "data" => []
                );
            }
        }
        abort(405);
    }
}
