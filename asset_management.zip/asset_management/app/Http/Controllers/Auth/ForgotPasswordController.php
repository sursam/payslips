<?php

namespace App\Http\Controllers\Auth;

use DB;
use Mail;
use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Rules\RecaptchaRule;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends BaseController
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    public function adminForgotPassword()
    {
        $this->setPageTitle('Forgot Password');
        return view('auth.admin.forgot-password');
    }
    public function councilForgotPassword()
    {
        $this->setPageTitle('Forgot Password');
        return view('auth.council.passwords.email');
    }

    /**
     * Validate the email for the given request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    public function validateEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ], [
            'email.required' => 'Email is required',
            'email.email' => 'Email format is invalid',
        ]);
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function submitAdminForgotPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
        ]);
        if ($validator->fails()) {
            return $this->responseJson(false, 500, $validator->errors()->first(), $validator->errors());
        }
        $token = Str::random(64);
        DB::table('password_resets')->insert([
            'email' => $request->email,
            'token' => $token,
            'created_at' => Carbon::now()
        ]);
        Mail::send('mail.forgot-password', ['token' => $token, 'email' => $request->email], function($message) use($request){
            $message->to($request->email);
            $message->subject('Reset Password');
        });
        return $this->responseJson(true, 200, 'We have e-mailed your password reset link!', []);
        // return $this->responseRedirectBack('We have e-mailed your password reset link!', 'success', true, true);
    }
}
