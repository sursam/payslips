<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\BaseController;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends BaseController
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;
    // use ThrottlesLogins;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    protected $maxAttempts = 5; // Default is 5
    protected $decayMinutes = 2; // Default is 1

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('throttle:'.$this->maxAttempts.','.$this->decayMinutes)->only('login');
        $this->middleware('guest')->except('logout');
    }
    public function adminLogin()
    {
        $this->setPageTitle('Login');
        return view('auth.admin.login');
    }
    public function councilLogin()
    {
        $this->setPageTitle('Login');
        return view('auth.council.login');
    }

    public function login(Request $request)
    {
        $input = $request->all();
        // dd($input);
        if($request->password=='' && $request->email=='')
        return $this->responseJson(false, 200, 'Email address & Password is required.', [
        'redirect_url' => route('login')
        ]);
        if($request->email=='')
            return $this->responseJson(false, 200, 'Email address is required.', [
            'redirect_url' => route('login')
        ]);
        if($request->password=='')
            return $this->responseJson(false, 200, 'Password is required.', [
            'redirect_url' => route('login')
        ]);
        $this->validate($request, [
            'email' => 'email',
            //'password' => 'required',
            // 'recaptcha' => ['required', new RecaptchaRule('loginOrRegister')],
        ], [
            'email.required' => 'Email is required',
            'email.email' => 'Email format is invalid',
            'password' => 'Password is required'
        ]);

        $userData = array(
            'email' => $input['email'],
            'password' => $input['password'],
        );

        $rememberMe = $request->has('remember') ? true : false;
        if (auth()->attempt($userData, $rememberMe)) {
            $this->limiter()->clear($this->throttleKey($request));
            $request->session()->forget('login_attempts');
            $request->session()->remove('locked_out');
            // $this->clearLoginAttempts($request);

            $user = auth()->user();
            // $user->update([
            //     'last_login_at' => Carbon::now()->toDateTimeString(),
            //     'last_login_ip' => $request->getClientIp(),
            // ]);

            if (auth()->user()->is_twofactor) {
                $user->generateTwoFactorCode();
                $user->notify(new TwoFactorCode());

                // return redirect()->intended(route('twofactor'));
                return $this->responseJson(true, 200, 'Two factor.', [
                    'redirect_url' => route('twofactor')
                ]);
            } else {
                if (!auth()->user()->last_login_at) {
                    //return redirect()->route('admin.reset.user.password');
                    return $this->responseJson(true, 200, 'Please reset your password first.', [
                        'redirect_url' => route('admin.reset.user.password')
                    ]);
                }
                if (!auth()->user()->is_active) {
                    auth()->logout();
                    // return $this->responseRedirectBack('Oh no! Your Account has been deactivated. Please contact admin', 'info', true, true);
                    return $this->responseJson(false, 200, 'Oh no! Your Account has been deactivated. Please contact admin', [
                        'redirect_url' => route('login')
                    ]);
                }
                if (!auth()->user()->is_approve) {
                    auth()->logout();
                    // return $this->responseRedirectBack('Oh no! Your Account has been unapproved. Please contact admin', 'warning', true, true);
                    return $this->responseJson(false, 200, 'Oh no! Your Account has been unapproved. Please contact admin', [
                        'redirect_url' => route('login')
                    ]);
                }
                if (auth()->user()->is_blocked) {
                    auth()->logout();
                    // return $this->responseRedirectBack('Oh no! Your Account has been blocked. Please contact admin', 'warning', true, true);
                    return $this->responseJson(false, 200, 'Oh no! Your Account has been blocked. Please contact admin', [
                        'redirect_url' => route('login')
                    ]);
                }
                // if (auth()->user()->hasRole('super-admin')) {

                Auth::logoutOtherDevices($request->password);

                if(!auth()->user()->can('view-dashboard')){
                    // return redirect()->intended(route('admin.profile'));
                    return $this->responseJson(true, 200, 'Successfully logged in.', [
                        'redirect_url' => route('admin.profile')
                    ]);
                }
                // return redirect()->intended(route('admin.home'));
                return $this->responseJson(true, 200, 'Successfully logged in.', [
                    'redirect_url' => route('admin.home')
                ]);
                // }
            }
        }
        $failedAttempts = $this->limiter()->hit($this->throttleKey($request));
        $attemptsLeft = $this->maxAttempts - $failedAttempts;

        return $this->responseJson(false, 200, 'Email address and password are wrong. You have '.$attemptsLeft.' attempts left.', [
            'redirect_url' => route('login'),
            'failed_attempts' => $failedAttempts,
        ]);
    }

    protected function loggedOut(Request $request) {
        return redirect('/login');
    }
}
