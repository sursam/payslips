<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\HasRolesAndPermissions;
use Symfony\Component\HttpFoundation\Response;

class UserPermissions
{

    use HasRolesAndPermissions;
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */

    public function handle(Request $request, Closure $next): Response
    {

        $user = Auth::user();
        // dd($request->all());
        $currentPath = $request->path();
        $slug='';

        if ($currentPath='budget/add')
            $slug="add-budget";
        elseif($currentPath='budget/edit')
            $slug="edit-budget";
        elseif($currentPath='budget/list')
            $slug="view-budget";
        elseif($currentPath='ajax/updateStatus')
           $slug="status-budget";
        elseif($currentPath='ajax/deleteData')
             $slug="delete-budget";


        // $baseUrl = config('app.url');
        // if (str_starts_with($currentPath, trim($baseUrl, '/'))) {
        //     $currentPath = substr($currentPath, strlen($baseUrl));
        //     dd($currentPath);
        // }
        if ($user->userWisePermission($slug)) {
            return $next($request);
        }

        abort(401);
        //return response()->json(['message' => 'You dont Have Permission to Access This'], 403);

        // if (
        //     $request->user()->can('add-budget')
        //     || $request->user()->can('edit-budget')
        //     || $request->user()->can('view-budget')
        //     || $request->user()->can('status-budget')
        //     || $request->user()->can('delete-budget')
        // ) {
        //     return $next($request);
        // }
        // return response()->json(['error' => 'Unauthorized'], 403);

    }
}
