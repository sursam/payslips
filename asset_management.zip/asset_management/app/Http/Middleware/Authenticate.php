<?php

namespace App\Http\Middleware;

use Closure;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Auth\Middleware\Authenticate as Middleware;
use session;

class Authenticate extends Middleware
{
    protected $guards;

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string[]  ...$guards
     * @return mixed
     *
     * @throws \Illuminate\Auth\AuthenticationException
     */
    public function handle($request, Closure $next, ...$guards)
    {
        $this->guards = $guards;
        if (auth()->user() && !auth()->user()->last_login_at && request()->route()->getName() != "admin.reset.user.password") {
            auth()->logout();
        }
        session()->put('last_activity', Carbon::now());
        if (Carbon::now()->diffInMinutes(session()->get('last_activity')) > config('session.lifetime')) {
            auth()->logout();
        }
        return parent::handle($request, $next, ...$guards);
    }
    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    protected function redirectTo(Request $request): ?string
    {
        return $request->expectsJson() ? null : route('login');
    }

    // protected function unauthenticated($request, array $guards)
    // {
    //     abort(response()->json(
    //         [
    //             'status' => false,
    //             'response_code' => 401,
    //             'error' => 'Unauthenticated',
    //             'message' => 'Please Provide a token',
    //         ],
    //         401
    //     ));
    // }
}
