<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'step' => $this->step,
            'uuid' => $this->uuid,
            'patient' => new PatientResource($this->patient),
            'doctor' => $this->doctor ? new DoctorResource($this->doctor) : null,
            'issue' => new IssuesResource($this->issue),
            "booking_datetime" => $this->booking_datetime,
            "status" => $this->status,
            "payment_mode" => $this->paymentMode?->name ?? null,
            'price' => $this->price,
            'verification_code' => $this->verification_code ?? 0,
            'details' => new BookingDetailResource($this->details),
            'meeting_link' => $this->meeting_link,
        ];
    }
}
