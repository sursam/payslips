<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\QuestionOptionResource;

class QuestionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        // $options = $this->options ? $this->options : (Object)[];
        return [
            'uuid' => $this->uuid,
            'name' => $this->name,
            'type' => $this->type,
            'options' => QuestionOptionResource::collection($this->options)
        ];
    }
}
