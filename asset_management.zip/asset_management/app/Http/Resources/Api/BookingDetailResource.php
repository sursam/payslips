<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use PhpParser\Node\Expr\Cast\Object_;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\BookingAddressResource;

class BookingDetailResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'uuid' => $this->uuid,
            'doctor_level' => $this->doctorLevel->name,
            "booking_for" => $this->booking_for,
            "gender" => $this->gender,
            "partner_info" => $this->partner_info,
            'other_info' => $this->other_info,
            'consultaion_type' => $this->consultaion_type,
            'survey_results' => $this->survey_results
        ];
    }
}
