<?php

namespace App\Repositories\Report;

use App\Models\Report\DepreciationSetting;

class ReportRepository
{
    public function __construct(protected DepreciationSetting $depreciationSettingModel)
    {
        $this->depreciationSettingModel = $depreciationSettingModel;
    }
    public function addOrUpdateSettings(array $condition, array $attributes)
    {
        $query = $this->depreciationSettingModel->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function getDepreciationSettings(array $filterConditions){
        $model = $this->depreciationSettingModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        // dd($model->toRawSql());
        return $model->first();
    }
}
