<?php

namespace App\Repositories\Ticket;

use Carbon\Carbon;
use App\Traits\UploadAble;
use App\Models\Ticket\Ticket;
use App\Models\Ticket\TicketCc;
use Illuminate\Support\Facades\Log;
use App\Models\Ticket\TicketSetting;
use App\Repositories\BaseRepository;
use App\Models\Ticket\TicketActivity;
use App\Models\Ticket\TicketCategory;
use App\Contracts\Ticket\TicketContract;

class TicketRepository extends BaseRepository implements TicketContract
{
    use UploadAble;
    public function __construct(protected Ticket $ticket, protected TicketActivity $ticket_activity_model, protected TicketCc $ticket_ccto_model, protected TicketCategory $ticket_category_model, protected TicketSetting $ticket_setting_model)
    {
        $this->ticket = $ticket;
        $this->ticket_activity_model = $ticket_activity_model;
        $this->ticket_ccto_model = $ticket_ccto_model;
        $this->ticket_category_model = $ticket_category_model;
    }
    public function listTickets_bk(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->ticket;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        // if (isset($type) && $type) {
        switch ($type) {
            case 'raised-by-me':
                $model = $model->whereHas('activities', function ($model) {
                    $model->where('user_id', auth()->user()->id)
                        ->where('type', 0);
                });
                break;
                // case 'assigned-to-me':
                //     $model = $model->whereHas('activities', function ($model) {
                //             $model->where('user_id', auth()->user()->id)
                //                 ->where(function($query){
                //                     $query->where('type', 1)
                //                     ->orWhere('type', 2)
                //                     ->orWhere('type', 3);
                //                 });
                //         })->orWhereHas('department', function ($model) {
                //             $model->where('department_manager', auth()->user()->id);
                //         })->whereDoesntHave('activities', function ($model) {
                //             $model->where('user_id', auth()->user()->id)->where('type', 7);
                //         });
                //     break;




                //sk'scode
                // case 'assigned-to-me':
                //     $ticketId=1;
                //     $ticket = Ticket::find($ticketId);
                //     $latestTicketType=TicketActivity::where('ticket_id',$ticketId)->whereIn('type',[1,2,3])->orderBy('id','DESC')->first();
                //     if(auth()->user()->id == $ticket->department?->department_manager)
                //         $model = $this->ticket->whereHas('department', function ($query) {
                //             $query->where('department_manager', auth()->user()->id);
                //         });
                //     else{
                //     if(($latestTicketType->type== 3 && $latestTicketType->user_id != auth()->user()->id) )
                //         $model = collect();
                //     else
                //         $model = $model->whereHas('activities', function ($query) use ($latestTicketType) {
                //                 $query->where('user_id', auth()->user()->id)
                //                     ->where('type', $latestTicketType->type);
                //                 })->whereDoesntHave('activities', function ($model) {
                //                      $model->where('user_id', auth()->user()->id)->where('type', 7);
                //                  });
                //     }
                //     break;


            case 'assigned-to-me':
                $tickets = $model->with(['activities', 'department'])->get();
                $filteredTickets = $tickets->filter(function ($ticket) {
                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    if ($isTransfered != null) {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $ticket->department?->department_manager) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });

                                // $containsLatestActivity = $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                //     $result = $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id ;
                                //     Log::info('Activity match:', [
                                //         'activity_user_id' => $activity->user_id,
                                //         'activity_type' => $activity->type,
                                //         'result' => $result
                                //     ]);
                                //     return $result;
                                // });

                                // $containsType7 = $ticket->activities->contains(function ($activity) {
                                //     $result = $activity->user_id == auth()->user()->id && $activity->type == 7;
                                //     Log::info('Type 7 match:', [
                                //         'activity_user_id' => $activity->user_id,
                                //         'activity_type' => $activity->type,
                                //         'result' => $result
                                //     ]);
                                //     return $result;
                                // });

                                // return $containsLatestActivity && !$containsType7;
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $ticket->department?->department_manager) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                $ticketIds = $filteredTickets->pluck('id');
                $model = $model->whereIn('id', $ticketIds);
                break;



                // $model = $model->orWhereHas('department', function ($query) {
                //   $query->where('department_manager', auth()->user()->id);
                //    });
                //dd($latestTicketType);
                // $model = $model->whereHas('department', function ($query) {
                //     $query->where('department_manager', auth()->user()->id);
                // });

                //break;
                // case 'closed':
                //     $model = $model->where('status', '0')
                //             ->where(function($model){
                //                 $model->whereHas('activities', function ($model) {
                //                     $model->where('user_id', auth()->user()->id)
                //                         ->where('type', 0);
                //                 })
                //                 ->orWhereHas('activities', function ($model) {
                //                     $model->where('user_id', auth()->user()->id)
                //                         ->where(function($query){
                //                             $query->where('type', 1)
                //                             ->orWhere('type', 2)
                //                             ->orWhere('type', 3);
                //                         });
                //                 });
                //             });
                //     break;
            case 'cc-to-me':
                $model = $model->whereHas('ccTo', function ($model) {
                    $model->where('user_id', auth()->user()->id);
                });
                break;


                // default:
                //     $model = $model->whereHas('activities', function ($model) {
                //         $model->where('user_id', auth()->user()->id)
                //             ->where('type', 0);
                //     })->orWhereHas('activities', function ($model) {
                //         $model->where('user_id', auth()->user()->id)
                //             ->where(function($query){
                //                 $query->where('type', 1)
                //                 ->orWhere('type', 2)
                //                 ->orWhere('type', 3);
                //             });
                //     })->orWhereHas('department', function ($model) {
                //         $model->where('department_manager', auth()->user()->id);
                //     })->whereDoesntHave('activities', function ($model) {
                //         $model->where('user_id', auth()->user()->id)->where('type', 7);
                //     })->orWhereHas('ccTo', function ($model) {
                //         $model->where('user_id', auth()->user()->id);
                //     });
                //     break;

                ///sk'scode
                // default:
                // $ticketId=1;
                //     $ticket = Ticket::find($ticketId);
                //     if($ticket !==null){
                //     $latestTicketType=TicketActivity::where('ticket_id',$ticketId)->whereIn('type',[1,2,3])->orderBy('id','DESC')->first();
                //     if(auth()->user()->id == $ticket->department?->department_manager)
                //         $model = $this->ticket->whereHas('department', function ($query) {
                //             $query->where('department_manager', auth()->user()->id);
                //         });
                //     else{
                //     if(($latestTicketType->type== 3 && $latestTicketType->user_id != auth()->user()->id) )
                //         $model = $this->ticket->whereRaw('1 = 0');
                //     else
                //         $model = $model->whereHas('activities', function ($query) use ($latestTicketType) {
                //                 $query->where('user_id', auth()->user()->id)
                //                     ->where('type', $latestTicketType->type);
                //                 })->whereDoesntHave('activities', function ($model) {
                //                      $model->where('user_id', auth()->user()->id)->where('type', 7);
                //                  });

                //     }
                //     $model = $model->orWhereHas('activities', function ($model) {
                //          $model->where('user_id', auth()->user()->id)
                //              ->where('type', 0);
                //      })->orWhereHas('ccTo', function ($model) {
                //                  $model->where('user_id', auth()->user()->id);
                //              });
                // }
                //  break;
            default:
                $tickets = $model->with(['activities', 'department', 'ccTo'])->get();
                $filteredTickets = $tickets->filter(function ($ticket) {


                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    if ($isTransfered != null) {

                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $ticket->department?->department_manager) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type &&  $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $ticket->department?->department_manager) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                $ticketIds = $filteredTickets->pluck('id');
                $model = $model->whereIn('id', $ticketIds)
                    ->orWhereHas('activities', function ($query) {
                        $query->where('user_id', auth()->user()->id)
                            ->where('type', 0);
                    })
                    ->orWhereHas('ccTo', function ($query) {
                        $query->where('user_id', auth()->user()->id);
                    });
                break;
        }
        // }else{
        //     $model = $model->whereHas('activities', function ($model) {
        //         $model->where('user_id', auth()->user()->id)
        //             ->where('type', 0);
        //     })->orWhereHas('activities', function ($model) {
        //         $model->where('user_id', auth()->user()->id)
        //             ->where(function($query){
        //                 $query->where('type', 1)
        //                 ->orWhere('type', 2)
        //                 ->orWhere('type', 3);
        //             });
        //     })->orWhereHas('department', function ($model) {
        //         $model->where('department_manager', auth()->user()->id);
        //     })->whereDoesntHave('activities', function ($model) {
        //         $model->where('user_id', auth()->user()->id)->where('type', 7);
        //     })->orWhereHas('ccTo', function ($model) {
        //         $model->where('user_id', auth()->user()->id);
        //     });
        // }
        if ($search) {
            // $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            // dd($type);

            /*if (isset($filterData['filterBy'])) {
                // if($filterData['filterBy'] == 'byme'){
                //     $model = $model->whereHas('activities', function ($model) {
                //         $model->where('user_id', auth()->user()->id)
                //             ->where('type', 0);
                //     });
                // }
                // if($filterData['filterBy'] == 'tome'){
                //     $model = $model->whereHas('activities', function ($model) {
                //         $model->where('user_id', auth()->user()->id)
                //             ->where(function($query){
                //                 $query->where('type', 1)
                //                 ->orWhere('type', 2)
                //                 ->orWhere('type', 3);
                //             });
                //     });
                // }
                if($filterData['filterBy'] == 'unassigned'){
                    $model = $model->whereDoesntHave('activities', function ($model) {
                        $model->where('type', 2)
                        ->orWhere('type', 3)
                        ->orWhere('type', 4);
                    });
                    if(!auth()->user()->hasRole('super-admin')){
                        $model = $model->whereHas('activities', function ($model) {
                            $model->where('user_id', auth()->user()->id)
                                ->where('type', 0);
                        });
                    }
                }
            }*/
            if (isset($filterData['entity'])) {
                $model = $model->whereIn('entity_id', $filterData['entity']);
            }
            if (isset($filterData['department'])) {
                $model = $model->whereIn('department_id', $filterData['department']);
            }
            if (isset($filterData['priority'])) {
                $model = $model->whereIn('priority', $filterData['priority']);
            }
            if (isset($filterData['status'])) {
                $model = $model->whereIn('status', $filterData['status']);
            }
            /*if (isset($filterData['raised_id'])) {
                $raisedId = $filterData['raised_id'];
                $model = $model->whereHas('raisedBy', function ($model) use ($raisedId) {
                    $model->where('user_id', $raisedId);
                });
            }
            if (isset($filterData['assigned_to'])) {
                $assignedTo = $filterData['assigned_to'];
                $model = $model->whereHas('assignedTo', function ($model) use ($assignedTo) {
                    $model->where('user_id', $assignedTo);
                });
            }
            if (isset($filterData['created_at'] ) && $filterData['created_at'] != "") {
                $model = $model->whereDate('created_at', '=', $filterData['created_at']);
            }
            if (isset($filterData['completed_at'] ) && $filterData['completed_at'] != "") {
                $model = $model->whereDate('completed_at', '=', $filterData['completed_at']);
            }*/
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('subject', 'LIKE', "%{$searchText}%");
                });
            }
        }/*else{
            if(!auth()->user()->hasRole('super-admin')){
                $model = $model->whereHas('activities', function ($model) {
                    $model->where('user_id', auth()->user()->id)
                        ->where(function($query){
                            $query->where('type', 0)
                            ->orWhere('type', 1)
                            ->orWhere('type', 2)
                            ->orWhere('type', 3);
                        });
                })
                ->orWhereHas('ccTo', function ($model) {
                    $model->where('user_id', auth()->user()->id);
                });
            }
        }*/

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'id':
                case 'ticket_id':
                    // $model = $model->orderByRaw("FIELD(priority, 'high', 'medium', 'low')")->orderBy('id', $sortBy);
                    $prioritySortBy = ($sortBy == 'asc') ? 'desc' : 'asc';
                    $model = $model->orderBy('priority', $prioritySortBy)->orderBy('id', $sortBy);
                    break;
                case 'entity':
                    $model = $model->select('tickets.*')->leftJoin('categories', function ($model) {
                        $model->on('categories.id', '=', 'tickets.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'department':
                    $model = $model->select('tickets.*')->leftJoin('departments', function ($model) {
                        $model->on('departments.id', '=', 'tickets.department_id');
                    })->orderBy('departments.name', $sortBy);
                    break;
                case 'completion_date':
                    $model = $model->orderBy('completed_at', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }

        // dd($model->toRawSql());
        return $model->get();
    }




    public function listTickets(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->ticket;

        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $model = $this->applyCommonFilters($model, $search);
        }
        switch ($type) {
            case 'raised-by-me':
                $model = $model->whereHas('activities', function ($query) {
                    $query->where('user_id', auth()->user()->id)->where('type', 0);
                });
                break;
            case 'assigned-to-me':
                $tickets = $model->with(['activities', 'department'])->get();
                $filteredTickets = $tickets->filter(function ($ticket) {
                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    $ticketSettingsData = $ticket->department?->getTicketSettingsData($ticket->ticket_category_id, $ticket->entity_id, auth()->user()->profile->location_id);
                    $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : null;
                    if ($isTransfered != null) {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                // dd($filteredTickets);
                $ticketIds = $filteredTickets->pluck('id');
                $model = $model->whereIn('id', $ticketIds);
                break;

            case 'cc-to-me':
                $model = $model->whereHas('ccTo', function ($query) {
                    $query->where('user_id', auth()->user()->id);
                });
                break;

            default:
                $tickets = $model->with(['activities', 'department', 'ccTo'])->get();

                $filteredTickets = $tickets->filter(function ($ticket) {
                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    $ticketSettingsData = $ticket->department?->getTicketSettingsData($ticket->ticket_category_id, $ticket->entity_id, auth()->user()->profile->location_id);
                    $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;
                    // dd($departmentAdminId);
                    if ($isTransfered != null) {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type &&  $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                $ticketIds = $filteredTickets->pluck('id');
                $model = $model->where(function($query) use ($ticketIds){
                    $query->whereIn('id', $ticketIds)
                    ->orWhereHas('activities', function ($query) {
                        $query->where('user_id', auth()->user()->id)->where('type', 0);
                    })
                    ->orWhereHas('ccTo', function ($query) {
                        $query->where('user_id', auth()->user()->id);
                    });
                });
                // $model = $model->whereIn('id', $ticketIds)
                // ->orWhereHas('activities', function ($query) {
                //     $query->where('user_id', auth()->user()->id)->where('type', 0);
                // })
                // ->orWhereHas('ccTo', function ($query) {
                //     $query->where('user_id', auth()->user()->id);
                // });
                // dd($model->get());

                // $ticketIds = $filteredTickets->pluck('id');
                // $fiteredTickets = $model->whereIn('id', $ticketIds);

                // // Apply common filters to all queries
                // $fiteredTickets = $this->applyCommonFilters($fiteredTickets, $search);
                // $activitiesQuery = $model->whereHas('activities', function ($query) {
                //     $query->where('user_id', auth()->user()->id)
                //         ->where('type', 0);
                // });
                // $activitiesQuery = $this->applyCommonFilters($activitiesQuery, $search);
                // $ccToQuery = $model->whereHas('ccTo', function ($query) {
                //     $query->where('user_id', auth()->user()->id);
                // });
                // $ccToQuery = $this->applyCommonFilters($ccToQuery, $search);

                // $unionQuery = $fiteredTickets->union($activitiesQuery)->union($ccToQuery);
                // $model = $unionQuery;
                // dd($model->get());
                break;
        }
        // dd($model->get());
        // Apply search filters if needed


        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'id':
                case 'ticket_id':
                    $prioritySortBy = ($sortBy == 'asc') ? 'desc' : 'asc';
                    $model = $model->orderBy('priority', $prioritySortBy)->orderBy('id', $sortBy);
                    break;
                case 'entity':
                    $model = $model->select('tickets.*')->leftJoin('categories', function ($model) {
                        $model->on('categories.id', '=', 'tickets.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'department':
                    $model = $model->select('tickets.*')->leftJoin('departments', function ($model) {
                        $model->on('departments.id', '=', 'tickets.department_id');
                    })->orderBy('departments.name', $sortBy);
                    break;
                case 'completion_date':
                    $model = $model->orderBy('completed_at', $sortBy);
                    break;
                case 'raised_by':
                    // $model = $model->with(['activities' => function ($query) use($sortBy) {
                    //     $query->with(['user' => function ($q) use($sortBy){
                    //         $q->orderBy('first_name', $sortBy);
                    //     }]);
                    // }]);
                    break;
                case 'assigned_to':
                    // $model = $model->select('tickets.*')->leftJoin('ticket_activities', function ($query) {
                    //     $query->on('ticket_activities.ticket_id', '=', 'tickets.id')
                    //         ->leftJoin('users', function ($q) {
                    //             $q->on('users.id', '=', 'ticket_activities.user_id');
                    //         });
                    // })->orderBy('users.first_name', $sortBy);
                    // dd($model->toRawSql());
                    break;
                case 'raised_on':
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }

        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }

    private function applyCommonFilters($query, $search)
    {
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $query = $query->whereIn('entity_id', $filterData['entity']);
            }
            if (isset($filterData['department'])) {
                $query = $query->whereIn('department_id', $filterData['department']);
            }
            if (isset($filterData['priority'])) {
                $query = $query->whereIn('priority', $filterData['priority']);
            }
            if (isset($filterData['status'])) {
                $query = $query->whereIn('status', $filterData['status']);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $query = $query->where(function ($query) use ($searchText) {
                    $query->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('subject', 'LIKE', "%{$searchText}%");
                });
            }
        }
        return $query;
    }




    public function listTicketsForDashboard(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->ticket->whereDate('created_at', Carbon::today());
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        switch ($type) {

            case 'raised-by-me':
                $model = $model->whereHas('activities', function ($model) {
                    $model->where('user_id', auth()->user()->id)
                        ->where('type', 0);
                });
                break;
            case 'assigned-to-me':
                $tickets = $model->with(['activities', 'department'])->get();
                $filteredTickets = $tickets->filter(function ($ticket) {
                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    $ticketSettingsData = $ticket->department?->getTicketSettingsData($ticket->ticket_category_id, $ticket->entity_id, auth()->user()->profile->location_id);
                    $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : null;
                    if ($isTransfered != null) {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });

                                // $containsLatestActivity = $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                //     $result = $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id ;
                                //     Log::info('Activity match:', [
                                //         'activity_user_id' => $activity->user_id,
                                //         'activity_type' => $activity->type,
                                //         'result' => $result
                                //     ]);
                                //     return $result;
                                // });

                                // $containsType7 = $ticket->activities->contains(function ($activity) {
                                //     $result = $activity->user_id == auth()->user()->id && $activity->type == 7;
                                //     Log::info('Type 7 match:', [
                                //         'activity_user_id' => $activity->user_id,
                                //         'activity_type' => $activity->type,
                                //         'result' => $result
                                //     ]);
                                //     return $result;
                                // });

                                // return $containsLatestActivity && !$containsType7;
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                $ticketIds = $filteredTickets->pluck('id');
                $model = $model->whereIn('id', $ticketIds);
                break;
            case 'cc-to-me':
                $model = $model->whereHas('ccTo', function ($model) {
                    $model->where('user_id', auth()->user()->id);
                });
                break;
            default:
                $raisedByMe = $this->ticket->whereDate('created_at', Carbon::today());
                $ccTo = $this->ticket->whereDate('created_at', Carbon::today());

                $raisedByMe = $raisedByMe->where(function ($query) {
                    $query->whereHas('activities', function ($subQuery) {
                        $subQuery->where('user_id', auth()->user()->id)
                            ->where('type', 0);
                    });
                })->get();

                $ccTo = $ccTo->whereHas('ccTo', function ($model) {
                    $model->where('user_id', auth()->user()->id);
                })->get();
                $assignedToMe = $ccTo->merge($raisedByMe)->sortByDesc('id')->unique('id');

                $tickets = $model->with(['activities', 'department'])->get();
                $filteredTickets = $tickets->filter(function ($ticket) {
                    $isTransfered = $ticket->activities->where('type', 9)->sortByDesc('id')->first();
                    $ticketSettingsData = $ticket->department?->getTicketSettingsData($ticket->ticket_category_id, $ticket->entity_id, auth()->user()->profile->location_id);
                    $departmentAdminId = $ticketSettingsData && $ticketSettingsData->department_admin ?  $ticketSettingsData->department_admin : 1;
                    if ($isTransfered != null) {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->where('id', '>', $isTransfered->id)->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type && $activity->id >= $latestActivity->id;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    } else {
                        $latestActivity = $ticket->activities->whereIn('type', [1, 2, 3])->sortByDesc('id')->first();
                        if (auth()->user()->id == $departmentAdminId) {
                            return true;
                        } else {
                            if ($latestActivity && $latestActivity->type == 3 && $latestActivity->user_id != auth()->user()->id) {
                                return false;
                            } else {
                                return $ticket->activities->contains(function ($activity) use ($latestActivity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == $latestActivity->type;
                                }) && !$ticket->activities->contains(function ($activity) {
                                    return $activity->user_id == auth()->user()->id && $activity->type == 7;
                                });
                            }
                        }
                    }
                });
                $ticketIds = $filteredTickets->pluck('id');
                $model4 = $model->whereIn('id', $ticketIds)->get();

                $model = $model4->merge($assignedToMe)->sortByDesc('id')->unique('id');
                return ($model);
                break;
        }
    }
    public function listTicketsWithActivities(array $filterConditions = [])
    {
        $model = $this->ticket;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        $model = $model->with(['activities' => function ($query) {
            $query->where('type', '3')
                ->orWhere('type', '2')
                ->orWhere('type', '1')
                ->orderBy('type', 'DESC');
        }]);
        // dd($model->toRawSql());
        return $model->get();
    }
    public function findTicketById($id)
    {
        return $this->ticket->find($id);
    }
    public function addOrUpdateTicket($condition, $attributes)
    {
        $model = $this->ticket;
        if (isset($attributes['attachment_document'])) {
            $fileName = uniqid() . '.' . $attributes['attachment_document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['attachment_document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['attachment_file'] = $fileName;
            }
        }
        $model = $model->updateOrCreate($condition, $attributes);
        return $model;
    }
    public function deleteTicket($id)
    {
        $model = $this->ticket;
        $model = $model->whereId($id)->delete();
        return $model;
    }
    public function addTicketActivity($attributes)
    {
        $query = $this->ticket_activity_model;
        if (isset($attributes['attachment_document'])) {
            $fileName = uniqid() . '.' . $attributes['attachment_document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['attachment_document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['attachment_file'] = $fileName;
            }
        }
        $query = $query->create($attributes);
        return $query;
    }
    public function updateTicketActivity($attributes, $id)
    {
        $query = $this->ticket_activity_model;
        if (isset($attributes['attachment_document']) && $attributes['attachment_document']) {
            $fileName = uniqid() . '.' . $attributes['attachment_document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['attachment_document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['attachment_file'] = $fileName;
            }
        }
        $query = $query->whereId($id)->update($attributes);
        return $query;
    }
    public function addCcToUser($attributes)
    {
        $query = $this->ticket_ccto_model;
        $query = $query->create($attributes);
        return $query;
    }
    public function listTicketActivities(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false)
    {
        $model = $this->ticket_activity_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function listTicketCategories($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->ticket_category_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhere('description', 'LIKE', "%$searchText%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }

        // dd($model->toRawSql());
        // dd($model->get());
        return $model->get();
    }
    public function deleteTicketCategory($id)
    {
        $model = $this->ticket_category_model;
        $model = $model->whereId($id)->delete();
        return $model;
    }
    public function addOrUpdateTicketCategory($condition, $attributes)
    {
        $model = $this->ticket_category_model;
        $model = $model->updateOrCreate($condition, $attributes);
        return $model;
    }
    public function updateTicketCategoryStatus($attributes, $id)
    {
        return $this->ticket_category_model->whereId($id)->update($attributes);
    }
    public function findTicketCategoryById($id)
    {
        return $this->ticket_category_model->find($id);
    }
    public function deleteTicketSettings($id)
    {
        $model = $this->ticket_setting_model;
        $model = $model->whereId($id)->delete();
        return $model;
    }
}
