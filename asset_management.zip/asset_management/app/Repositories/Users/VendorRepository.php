<?php

namespace App\Repositories\Users;

use App\Models\User\Role;
use App\Traits\UploadAble;
use App\Models\User\Vendor;
use App\Repositories\BaseRepository;
use App\Contracts\Users\VendorContract;

class VendorRepository extends BaseRepository implements VendorContract
{
    use UploadAble;
    protected $model;
    protected $roleModel;
    public function __construct(Vendor $model, Role $roleModel,)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->roleModel = $roleModel;
    }

    public function createVendor(array $attributes){
        //dd($attributes);
        $isUserCreated = $this->create($attributes);
        return $isUserCreated;

    }
    public function getTotalUsers($search=null){
        $query = $this->model;
        if ($search) {
            $search = trim($search);
            $query = $query->where(function ($model) use ($search) {
                $model->where('first_name', 'LIKE', "%{$search}%")
                    ->orWhere('last_name', 'LIKE', "%{$search}%")
                    ->orWhere('email', 'LIKE', "%{$search}%")
                    ->orWhere('mobile_number', 'LIKE', "%{$search}%")
                    ->orWhere('company_name', 'LIKE', "%{$search}%")
                    ->orWhere('id', (int)str_replace("vdr", "", str_replace(" ", "", strtolower($search))));;
            });
        }
        return $query->count();
    }
    public function findUserByRole(array $filterConditions,string $role='vendor',string $orderBy = 'id', string $sortBy = 'asc',$limit= null,$offset=null,$inRandomOrder=false,$search=null){
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str( $search, $filterData );
            $searchText = trim($filterData['s']);
            if($searchText){
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('first_name', 'LIKE', "%{$searchText}%")
                        ->orWhere('last_name', 'LIKE', "%{$searchText}%")
                        ->orWhere('email', 'LIKE', "%{$searchText}%")
                        ->orWhere('mobile_number', 'LIKE', "%{$searchText}%")
                        ->orWhere('company_name', 'LIKE', "%{$searchText}%")
                        ->orWhere('id', (int)str_replace("vdr", "", str_replace(" ", "", strtolower($searchText))));
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'vendor_id':
                    $model = $model->orderBy('id', $sortBy);
                    break;
                case 'name':
                    $model = $model->orderByRaw('CONCAT(first_name, last_name) '.$sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset ) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function updateVendor(array $attributes,int $id){
        $isUserUpdated = $this->find($id);
        $isUserUpdated = $isUserUpdated->update($attributes);
        return $isUserUpdated;
    }
    public function getAllUsers($filterConditions, $role = 'vendor', string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false){
        return $this->model->where($filterConditions)->orderBy($orderBy, $sortBy)->get();
    }
    public function deleteVendor(int $id){
        return $this->delete($id);
    }
    public function findUserById(int $id){
        return $this->find($id);
    }
    public function updateVendorStatus(array $attributes, int $id){
        $query = $this->find($id);
        $isChanged = $query->update($attributes);
        return $isChanged;
    }
    public function findUserByLocation($search = null, string $orderBy = 'id', $sortBy = 'asc', $inRandomOrder = false){
        $model = $this->model->where('type','asset-vendor');
        if ($search) {
            $searchText = trim($search);
            if($searchText){
                $model = $model->where('first_name', 'LIKE', "%{$searchText}%")
                            ->orWhere('last_name', 'LIKE', "%{$searchText}%")
                            ->orWhereHas('city', function ($model) use ($searchText) {
                                $model->where('name', 'LIKE', "%{$searchText}%");
                            })->orWhereHas('state', function ($model) use ($searchText) {
                                $model->where('name', 'LIKE', "%{$searchText}%");
                            })->orWhere('address', 'LIKE', "%{$searchText}%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        // dd($model->toRawSql());
        return $model->get();
    }
    public function findVendorsExceptIds($vendorIds){
        return $this->model->whereNotIn('id', $vendorIds)->orderByRaw('CONCAT(first_name, last_name) ASC')->get();
    }
}
