<?php

namespace App\Repositories\Inventory;

use App\Contracts\Inventory\AssetStockContract;
use App\Models\Inventory\AssetIssue;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\AssetStockLog;
use App\Models\Inventory\AssetSurrender;
use App\Models\Inventory\Inventory;
use App\Models\Lease\LeaseAgreement;
use App\Models\Lease\LeaseItem;
use App\Models\Maintenance\AssetMaintenance;
use App\Models\Maintenance\MaintenanceItem;
use App\Models\Master\AssetVerification;
use App\Models\Master\VerifiedAsset;
use App\Models\Ticket\Ticket;
use App\Repositories\BaseRepository;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AssetStockRepository extends BaseRepository implements AssetStockContract
{
    use UploadAble;

    public function __construct(protected AssetStock $assetStock, protected Inventory $assetInventoryModel, protected AssetIssue $assetIssueModel, protected AssetStockLog $assetStockLogModel, protected LeaseAgreement $assetLeaseModel, protected LeaseItem $assetLeaseItemModel, protected AssetMaintenance $assetMaintenanceModel, protected MaintenanceItem $assetMaintenanceItemModel, protected AssetSurrender $assetSurrenderModel, protected AssetVerification $verificationModel, protected VerifiedAsset $verifiedAssetModel, protected Ticket $ticketModel)
    {

        parent::__construct($assetStock);
        $this->assetStock = $assetStock;
        $this->assetInventoryModel = $assetInventoryModel;
        $this->assetIssueModel = $assetIssueModel;
        $this->assetStockLogModel = $assetStockLogModel;
        $this->assetLeaseModel = $assetLeaseModel;
        $this->assetLeaseItemModel = $assetLeaseItemModel;
        $this->assetMaintenanceModel = $assetMaintenanceModel;
        $this->assetMaintenanceItemModel = $assetMaintenanceItemModel;
        $this->verificationModel = $verificationModel;
        $this->verifiedAssetModel = $verifiedAssetModel;
        $this->ticketModel = $ticketModel;
    }
    public function listAssetStocks(array $filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id);
            }
            if (isset($filterData['asset_type_id'])) {
                $asset_type_id = $filterData['asset_type_id'];
                $model = $model->whereIn('asset_type_id', $asset_type_id);
            }
            if (isset($filterData['location_id'])) {
                $location_id = $filterData['location_id'];
                $model = $model->whereIn('location_id', $location_id);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhereHas('asset', function ($model) use ($searchText) {
                            $model->where('asset_name', 'LIKE', "%{$searchText}%")
                                ->orWhere('asset_id', 'LIKE', "%{$searchText}%");
                        });
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($order, $sort);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }
    public function deleteAssetStock(int $id)
    {
        $query = $this->model;
        $query = $query->find($id)->delete();
        return $query;
    }
    public function findById(int $id)
    {
        return $this->model->find($id);
    }
    public function updateTable(array $condition, array $attributes)
    {
        //dd($attributes);
        $query = $this->model;
        $query = $query->where($condition);
        return $query->update($attributes);
    }
    public function getTotalAssetStock(array $filterConditions, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id);
            }
            if (isset($filterData['asset_type_id'])) {
                $asset_type_id = $filterData['asset_type_id'];
                $model = $model->whereIn('asset_type_id', $asset_type_id);
            }
            if (isset($filterData['location_id'])) {
                $location_id = $filterData['location_id'];
                $model = $model->whereIn('location_id', $location_id);
            }
            if (isset($filterData['entity_id'])) {
                $entity_id = $filterData['entity_id'];
                $model = $model->whereIn('entity_id', $entity_id);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhereHas('asset', function ($model) use ($searchText) {
                            $model->where('asset_name', 'LIKE', "%{$searchText}%")
                                ->orWhere('unique_id', 'LIKE', "%{$searchText}%");
                        });
                });
            }
        }
        return $model->count();
    }
    public function findAssetStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id);
            }
            if (isset($filterData['asset_type_id'])) {
                $asset_type_id = $filterData['asset_type_id'];
                $model = $model->whereIn('asset_type_id', $asset_type_id);
            }

            if (isset($filterData['location_id'])) {
                $location_id = $filterData['location_id'];
                $model = $model->whereIn('location_id', $location_id);
            }
            if (isset($filterData['entity_id'])) {
                $entity_id = $filterData['entity_id'];
                $model = $model->whereIn('entity_id', $entity_id);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhereHas('asset', function ($model) use ($searchText) {
                            $model->where('asset_name', 'LIKE', "%{$searchText}%")
                                ->orWhere('asset_id', 'LIKE', "%{$searchText}%");
                        });
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'location':
                    $model = $model->select('asset_stocks.*')->leftJoin('locations', function ($model) {
                        $model->on('locations.id', '=', 'asset_stocks.location_id');
                    })->orderBy('locations.street_address', $sortBy);
                    break;
                case 'entity':
                    $model = $model->select('asset_stocks.*')->leftJoin('categories', function ($model) {
                        $model->on('categories.id', '=', 'asset_stocks.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }
    public function updateStatus(array $attributes, int $id)
    {
        $query = $this->model;
        $query = $query->find($id)->update($attributes);
        return $query;
    }


    public function create($attributes)
    {
        //dd($attributes);
        $query = $this->assetStock;
        $query = $query->create($attributes);
        return $query;
    }
    public function findInventories(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetInventoryModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'user_entity':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('profiles', function ($model) {
                                $model->on('profiles.user_id', '=', 'asset_issues.user_id')
                                    ->leftJoin('categories', function ($model) {
                                        $model->on('categories.id', '=', 'profiles.entity_id');
                                    });
                            });
                    })->orderBy('categories.name', $sortBy);
                    // dd($model->toRawSql());
                    break;
                case 'employee_code':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('users', function ($model) {
                                $model->on('users.id', '=', 'asset_issues.user_id');
                            });
                    })->orderBy('users.unique_id', $sortBy);
                    break;
                case 'employee_name':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('users', function ($model) {
                                $model->on('users.id', '=', 'asset_issues.user_id');
                            });
                    })->orderByRaw('CONCAT(users.first_name, users.last_name) ' . $sortBy);
                    break;
                case 'designation':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('profiles', function ($model) {
                                $model->on('profiles.user_id', '=', 'asset_issues.user_id')
                                    ->leftJoin('categories', function ($model) {
                                        $model->on('categories.id', '=', 'profiles.designation_id');
                                    });
                            });
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'sbu':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('profiles', function ($model) {
                                $model->on('profiles.user_id', '=', 'asset_issues.user_id')
                                    ->leftJoin('categories', function ($model) {
                                        $model->on('categories.id', '=', 'profiles.sbu_id');
                                    });
                            });
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'division':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('profiles', function ($model) {
                                $model->on('profiles.user_id', '=', 'asset_issues.user_id')
                                    ->leftJoin('categories', function ($model) {
                                        $model->on('categories.id', '=', 'profiles.division_id');
                                    });
                            });
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'user_location':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id')
                            ->leftJoin('profiles', function ($model) {
                                $model->on('profiles.user_id', '=', 'asset_issues.user_id')
                                    ->leftJoin('locations', function ($model) {
                                        $model->on('locations.id', '=', 'profiles.location_id');
                                    });
                            });
                    })->orderBy('locations.street_address', $sortBy);
                    break;
                case 'date_of_scraping':
                    $model = $model->select('inventories.*')->leftJoin('maintenance_items', function ($model) {
                        $model->on('inventories.id', '=', 'maintenance_items.inventory_id');
                    })->orderBy('maintenance_items.updated_at', $sortBy);
                    break;
                case 'vendor':
                    $model = $model->select('inventories.*')->join('asset_stocks', function ($model) {
                        $model->on('asset_stocks.id', '=', 'inventories.asset_stock_id')
                            ->leftJoin('asset_receipt_notes', function ($model) {
                                $model->on('asset_receipt_notes.id', '=', 'asset_stocks.asset_receipt_note_id')
                                    ->leftJoin('purchase_orders', function ($model) {
                                        $model->on('purchase_orders.id', '=', 'asset_receipt_notes.purchase_order_id')
                                            ->leftJoin('vendors', function ($model) {
                                                $model->on('vendors.id', '=', 'purchase_orders.vendor_id');
                                            });
                                    });
                            });
                    })->orderByRaw('CONCAT(vendors.first_name, vendors.last_name) ' . $sortBy);
                    break;
                case 'allotment_date':
                    $model = $model->select('inventories.*')->leftJoin('asset_issues', function ($model) {
                        $model->on('inventories.id', '=', 'asset_issues.inventory_id');
                    })->orderBy('asset_issues.issued_date', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function getRenewalListByDays(int $days, array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetInventoryModel;
        $model = $model->whereBetween('warranty_licence_date', [Carbon::today(), Carbon::today()->addDays($days)]);
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function alterStockTable(array $condition, int $stock, string $type)
    {
        //dd($attributes);
        $query = $this->model;
        $query = $query->where($condition);
        if ($type == 'decrease')
            $query = $query->decrement('current_stock', $stock);
        else
            $query = $query->increment('current_stock', $stock);

        return $query;
    }
    public function listAssetIssues(array $filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetIssueModel;
        if ($filterConditions) {
            if (isset($filterConditions['asset_type_id']) && $filterConditions['asset_type_id']) {
                $assetTypeId = $filterConditions['asset_type_id'];
                $model = $model->whereHas('asset', function ($model) use ($assetTypeId) {
                    $model->where('asset_type_id', $assetTypeId);
                });
                unset($filterConditions['asset_type_id']);
            }

            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($order, $sort);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        // return $model->get();
        return $model->where('quantity','!=',null)->get();    // here quantity not null stands for Lease Item //
    }
    public function getUsedAssets(array $filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $offset = null, $inRandomOrder = false)
    {
        $model = $this->assetIssueModel;
        if ($filterConditions) {
            if (isset($filterConditions['asset_type_id']) && $filterConditions['asset_type_id']) {
                $assetTypeId = $filterConditions['asset_type_id'];
                $model = $model->whereHas('asset', function ($model) use ($assetTypeId) {
                    $model->where('asset_type_id', $assetTypeId);
                });
                unset($filterConditions['asset_type_id']);
            }
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($order, $sort);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        $model = $model->get()->groupBy('inventory_id');
        // dd($model->toRawSql());
        return $model;
    }
    public function addOrUpdateAssetIssue($condition, $attributes)
    {
        $query = $this->assetIssueModel;
        $documentType = 'document_allocation';
        if (isset($attributes['allotment_letter'])) {
            $fileName = uniqid() . '.' . $attributes['allotment_letter']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['allotment_letter'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['allotment_letter'] = $fileName;
                $documentType = 'document_allocation';
            }
        }
        if (isset($attributes['surrender_letter'])) {
            $fileName = uniqid() . '.' . $attributes['surrender_letter']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['surrender_letter'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['surrender_letter'] = $fileName;
                $documentType = 'document_surrender';
            }
        }
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['picture']) && $attributes['picture']) {
            $fileName = uniqid() . '.' . $attributes['picture']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['picture'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->updateOrCreate(['documentable_id' => $query->id, 'document_type' => $documentType], [
                    'title' => $fileName,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => $documentType,
                    'file' => $fileName,
                    'created_by' => auth()->user()->id,
                ]);
            }
        }
        return $query;
    }
    public function findAssetIssueById(int $id)
    {
        return $this->assetIssueModel->find($id);
    }
    // public function getAssetIssueByCondition_bk(array $filterConditions)
    // {
    //     $model = $this->assetIssueModel;
    //     if ($filterConditions) {
    //         $model = $model->where($filterConditions);
    //     }
    //     return $model->first();
    // }


    public function getAssetIssueByCondition(array $filterConditions)
    {
        $model = $this->assetIssueModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        return $model->get();
    }
    public function addAssetStockLog($attributes)
    {
        //dd($attributes);
        $query = $this->assetStockLogModel;
        $query = $query->create($attributes);
        return $query;
    }
    public function getAssetStockByCondition(array $filterConditions)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        // dd($model->toRawSql());
        return $model->first();
    }
    public function findAvailableItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        // $model = $this->assetInventoryModel->doesntHave('issue')->doesntHave('lease')->doesntHave('underMaintenance')->where('under_maintenance', '0');
        $model = $this->assetInventoryModel->doesntHave('issue')->doesntHave('lease')->doesntHave('underMaintenance')->where('under_maintenance', '0');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = trim($search);
            $model = $model->where(function ($model) use ($searchText) {
                $model->where('identification_no', 'LIKE', "%{$searchText}%")
                    ->orWhere('unique_id', 'LIKE', "%{$searchText}%")
                    ->orWhere('capacity_specs', 'LIKE', "%{$searchText}%");
            });
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->toRawSql());
        return $model->get();
    }
    public function findInStockItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetInventoryModel->doesntHave('issue')->doesntHave('lease')->doesntHave('underMaintenance')->where('under_maintenance', '0');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = trim($search);
            $model = $model->where(function ($model) use ($searchText) {
                $model->where('identification_no', 'LIKE', "%{$searchText}%")
                    ->orWhere('unique_id', 'LIKE', "%{$searchText}%")
                    ->orWhere('capacity_specs', 'LIKE', "%{$searchText}%");
            });
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->toRawSql());
        return $model->get();
    }
    public function findInventoryItems(array $inventoryIds)
    {
        $model = $this->assetInventoryModel;
        return $model->whereIn('id', $inventoryIds)->get();
    }
    public function addOrUpdateLease($condition, $attributes)
    {
        $query = $this->assetLeaseModel;
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['attachment_document']) && $attributes['attachment_document']) {
            $document = $attributes['attachment_document'];
            $fileName = uniqid() . '.' . $document->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($document, config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->create([
                    'title' => $fileName,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => auth()->user()->id,
                ]);
            }
        }
        return $query;
    }
    public function addOrUpdateLeaseItems($condition, $attributes)
    {
        $query = $this->assetLeaseItemModel;


        if (isset($attributes['document'])) {
            $fileName = uniqid() . '.' . $attributes['document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['document'] = $fileName;
               // $documentType = 'document_surrender';
            }
        }

        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function findLeasedItemById(int $id)
    {
        return $this->assetLeaseItemModel->find($id);
    }
    public function addOrUpdateMaintenance($condition, $attributes)
    {
        $query = $this->assetMaintenanceModel;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function updateMaintenanceStatus(array $attributes, int $id)
    {
        $query = $this->assetMaintenanceModel;
        $query = $query->find($id)->update($attributes);
        return $query;
    }
    public function findMaintenanceById(int $id)
    {
        return $this->assetMaintenanceModel->find($id);
    }
    public function addOrUpdateMaintenanceItems($condition, $attributes)
    {
        $query = $this->assetMaintenanceItemModel;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function updateMaintenanceItemStatus(array $attributes, int $id)
    {
        $query = $this->assetMaintenanceItemModel;
        $query = $query->find($id)->update($attributes);
        return $query;
    }
    public function findMaintenanceItemById(int $id)
    {
        return $this->assetMaintenanceItemModel->find($id);
    }
    public function getTotalMaintenances($search)
    {

        // $query = $this->assetMaintenanceModel;
        $model = $this->assetMaintenanceModel;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['maintenanceId'])) {
                $maintenanceId = $filterData['maintenanceId'];
                $model = $model->whereIn('id', $maintenanceId);
            }
            if (isset($filterData['stockId'])) {
                $stockId = (is_array($filterData['stockId'])) ? $filterData['stockId'] : json_decode($filterData['stockId']);
                $model = $model->whereHas('stock', function ($model) use ($stockId) {
                    $model->whereIn('id', $stockId);
                });
            }
            if (isset($filterData['locationId'])) {
                $locationId = $filterData['locationId'];
                $model = $model->whereIn('location_id', $locationId);
            }
            if (isset($filterData['start_date']) && $filterData['start_date'] != "") {
                $model = $model->whereDate('start_date', '=', $filterData['start_date']);
            }
            if (isset($filterData['end_date']) && $filterData['end_date'] != "") {
                $model = $model->whereDate('end_date', '=', $filterData['end_date']);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('title', 'LIKE', "%{$searchText}%");
                });
            }
        }
        // return $query->count();
        return $model->count();
    }
    public function findMaintenances(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetMaintenanceModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['maintenanceId'])) {
                $maintenanceId = $filterData['maintenanceId'];
                $model = $model->whereIn('id', $maintenanceId);
            }
            if (isset($filterData['stockId'])) {
                $stockId = (is_array($filterData['stockId'])) ? $filterData['stockId'] : json_decode($filterData['stockId']);
                $model = $model->whereHas('stock', function ($model) use ($stockId) {
                    $model->whereIn('id', $stockId);
                });
            }
            if (isset($filterData['locationId'])) {
                $locationId = $filterData['locationId'];
                $model = $model->whereIn('location_id', $locationId);
            }
            if (isset($filterData['start_date']) && $filterData['start_date'] != "") {
                $model = $model->whereDate('start_date', '=', $filterData['start_date']);
            }
            if (isset($filterData['end_date']) && $filterData['end_date'] != "") {
                $model = $model->whereDate('end_date', '=', $filterData['end_date']);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('title', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'location_id':
                    $model = $model->select('asset_maintenances.*')->leftJoin('locations', function ($model) {
                        $model->on('locations.id', '=', 'asset_maintenances.location_id');
                    })->orderBy('locations.street_address', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function findMaintenanceItemsByStockId(int $stockId, array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetMaintenanceItemModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        $model = $model->WhereHas('maintenance', function ($m) use ($stockId) {
            $m->where('asset_stock_id', $stockId);
        });
        if ($search) {
            $searchText = trim($search);
            $model = $model->where(function ($model) use ($searchText) {
                $model->where('unique_id', 'LIKE', "%{$searchText}%")
                    ->orWhere('title', 'LIKE', "%{$searchText}%")
                    ->orWhere('description', 'LIKE', "%{$searchText}%");
            });
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function getTotalLeases($search, string $type = '')
    {
        $model = $this->assetLeaseModel;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['leaseId'])) {
                $leaseId = $filterData['leaseId'];
                $model = $model->whereIn('id', $leaseId);
            }

            if (isset($filterData['stockId'])) {
                $stockId = (is_array($filterData['stockId'])) ? $filterData['stockId'] : json_decode($filterData['stockId']);
                $model = $model->whereHas('assetStock', function ($model) use ($stockId) {
                    $model->whereIn('id', $stockId);
                });
            }

            if (isset($filterData['locationId'])) {
                $locationId = $filterData['locationId'];
                $model = $model->whereIn('location_id', $locationId);
            }

            if (isset($filterData['start_date']) && $filterData['start_date'] != "") {
                $model = $model->whereDate('start_date', '=', $filterData['start_date']);
            }

            if (isset($filterData['end_date']) && $filterData['end_date'] != "") {
                $model = $model->whereDate('end_date', '=', $filterData['end_date']);
            }

            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term_frequency', 'LIKE', "%$searchText%")
                    ->orWhere('lease_type', 'LIKE', "%$searchText%")
                    ->orWhereHas('assetStock', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        return $model->count();
    }

    public function findLeasesbk(array $filterConditions, string $type, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetLeaseModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        // $totalLeaseItem = $model->has('leaseItems')->count();
        // $totalAllocatedLeaseItem = $model->whereHas('leaseItems', function ($query) {
        //     $query->where('user_id', '!=', null);
        // })->count();
        //dd($filterConditions);
        //$employee->profile?->entity?->name

        if (!auth()->user()->hasRole('super-admin'))
            $model = $model->where('to_entity_id',auth()->user()->profile?->entity_id)->orWhere('entity_id',auth()->user()->profile?->entity_id);

        // dd($type);
        if(($type == "unallocated") ){

            $model = $model->whereHas('leaseItems', function ($query) {
                $query->where('user_id',null);
            });

        }
        if ($type == "allocated") {
            $model = $model->whereDoesntHave('leaseItems', function ($query) {
                $query->where('user_id', '=', null);
            });
        }

        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['leaseId'])) {
                $leaseId = $filterData['leaseId'];
                $model = $model->whereIn('id', $leaseId);
            }

            if (isset($filterData['stockId'])) {
                $stockId = (is_array($filterData['stockId'])) ? $filterData['stockId'] : json_decode($filterData['stockId']);
                $model = $model->whereHas('assetStock', function ($model) use ($stockId) {
                    $model->whereIn('id', $stockId);
                });
            }

            if (isset($filterData['locationId'])) {
                $locationId = $filterData['locationId'];
                $model = $model->whereIn('location_id', $locationId);
            }

            if (isset($filterData['start_date']) && $filterData['start_date'] != "") {
                $model = $model->whereDate('start_date', '=', $filterData['start_date']);
            }

            if (isset($filterData['end_date']) && $filterData['end_date'] != "") {
                $model = $model->whereDate('end_date', '=', $filterData['end_date']);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term_frequency', 'LIKE', "%$searchText%")
                    ->orWhere('lease_type', 'LIKE', "%$searchText%")
                    ->orWhereHas('assetStock', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'asset_stock_id':
                    $model = $model->select('lease_agreements.*')->join('asset_stocks', function ($model) {
                        $model->on('asset_stocks.id', '=', 'lease_agreements.asset_stock_id');
                    })->orderBy("asset_stocks.unique_id", $sortBy);
                    break;

                case 'asset_id':
                    $model = $model->select('lease_agreements.*')->join('assets', function ($model) {
                        $model->on('assets.id', '=', 'lease_agreements.asset_id');
                    })->orderBy("assets.asset_name", $sortBy);
                    break;

                case 'location_id':
                    $model = $model->select('lease_agreements.*')->join('locations', function ($model) {
                        $model->on('locations.id', '=', 'lease_agreements.location_id');
                    })->orderBy("locations.street_address", $sortBy);
                    break;

                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        };
        return $model->get();
    }



    public function findLeases(array $filterConditions, string $type, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetLeaseModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if (!auth()->user()->hasRole('super-admin'))
            $model = $model->where('to_entity_id',auth()->user()->profile?->entity_id)->orWhere('entity_id',auth()->user()->profile?->entity_id);


        if(($type == "unallocated") ){
            $model = $model->FilterByUnallocated();

        }
        if ($type == "allocated") {

            $model1=$model;
            $leaseAgreements = $model1->get();
            $filteredLeaseByAllocated = $leaseAgreements->filter(function ($leaseAgreement) {
                $totalItems = $leaseAgreement->leaseItems->where('id', '!=', null)->count();
                $totalAllocated = $leaseAgreement->leaseItems->where('user_id', '!=', null)->count();
                return $totalItems == $totalAllocated;
            });
            $allocatedIds = $filteredLeaseByAllocated->pluck('id');

            if($allocatedIds->isEmpty())
                $model=collect();
            else
                $model = $this->assetLeaseModel->whereIn('id', $allocatedIds);
            //$model =$model->whereIn('id', $allocatedIds);


            //dd($allocatedIds);

        }

        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['leaseId'])) {
                $leaseId = $filterData['leaseId'];
                $model = $model->whereIn('id', $leaseId);
            }

            if (isset($filterData['stockId'])) {
                $stockId = (is_array($filterData['stockId'])) ? $filterData['stockId'] : json_decode($filterData['stockId']);
                $model = $model->whereHas('assetStock', function ($model) use ($stockId) {
                    $model->whereIn('id', $stockId);
                });
            }

            if (isset($filterData['locationId'])) {
                $locationId = $filterData['locationId'];
                $model = $model->whereIn('location_id', $locationId);
            }

            if (isset($filterData['start_date']) && $filterData['start_date'] != "") {
                $model = $model->whereDate('start_date', '=', $filterData['start_date']);
            }

            if (isset($filterData['end_date']) && $filterData['end_date'] != "") {
                $model = $model->whereDate('end_date', '=', $filterData['end_date']);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term', 'LIKE', "%$searchText%")
                    ->orWhere('lease_term_frequency', 'LIKE', "%$searchText%")
                    ->orWhere('lease_type', 'LIKE', "%$searchText%")
                    ->orWhereHas('assetStock', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'asset_stock_id':
                    $model = $model->select('lease_agreements.*')->join('asset_stocks', function ($model) {
                        $model->on('asset_stocks.id', '=', 'lease_agreements.asset_stock_id');
                    })->orderBy("asset_stocks.unique_id", $sortBy);
                    break;

                case 'asset_id':
                    $model = $model->select('lease_agreements.*')->join('assets', function ($model) {
                        $model->on('assets.id', '=', 'lease_agreements.asset_id');
                    })->orderBy("assets.asset_name", $sortBy);
                    break;

                case 'location_id':
                    $model = $model->select('lease_agreements.*')->join('locations', function ($model) {
                        $model->on('locations.id', '=', 'lease_agreements.location_id');
                    })->orderBy("locations.street_address", $sortBy);
                    break;

                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        };
        return $model->get();
    }


    public function findLeaseAgreementById(int $id)
    {
        return $this->assetLeaseModel->find($id);
    }

    public function addOrUpdateAssetSurrender($condition, $attributes)
    {
        $query = $this->assetSurrenderModel;
        if (isset($attributes['document_file'])) {
            $fileName = uniqid() . '.' . $attributes['document_file']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['document_file'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['document_file'] = $fileName;
            }
        }
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function getTotalVerificationLists(array $filterConditions, $search = null)
    {
        $model = $this->verificationModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id);
            }
            if (isset($filterData['asset_type_id'])) {
                $asset_type_id = $filterData['asset_type_id'];
                $model = $model->whereIn('asset_type_id', $asset_type_id);
            }
            if (isset($filterData['asset_id'])) {
                $asset_id = $filterData['asset_id'];
                $model = $model->whereIn('asset_id', $asset_id);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhereHas('asset', function ($model) use ($searchText) {
                            $model->where('asset_name', 'LIKE', "%{$searchText}%")
                                ->orWhere('unique_id', 'LIKE', "%{$searchText}%");
                        });
                });
            }
        }
        return $model->count();
    }
    public function findVerificationLists(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->verificationModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id'])) {
                $category_id = $filterData['category_id'];
                $model = $model->whereIn('category_id', $category_id);
            }
            if (isset($filterData['asset_type_id'])) {
                $asset_type_id = $filterData['asset_type_id'];
                $model = $model->whereIn('asset_type_id', $asset_type_id);
            }
            if (isset($filterData['asset_id'])) {
                $asset_id = $filterData['asset_id'];
                $model = $model->whereIn('asset_id', $asset_id);
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhereHas('asset', function ($model) use ($searchText) {
                            $model->where('asset_name', 'LIKE', "%{$searchText}%")
                                ->orWhere('unique_id', 'LIKE', "%{$searchText}%");
                        });
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch ($orderBy) {
                case 'asset_info':
                    $model = $model->select('asset_verifications.*')->leftJoin('assets', function ($model) {
                        $model->on('assets.id', '=', 'asset_verifications.asset_id');
                    })->orderBy('assets.asset_name', $sortBy);
                    break;
                case 'location':
                    $model = $model->select('asset_verifications.*')->leftJoin('locations', function ($model) {
                        $model->on('locations.id', '=', 'asset_verifications.location_id');
                    })->orderBy('locations.street_address', $sortBy);
                    break;
                case 'entity':
                    $model = $model->select('asset_verifications.*')->leftJoin('categories', function ($model) {
                        $model->on('categories.id', '=', 'asset_verifications.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'verified_by':
                    $model = $model->select('asset_verifications.*')->leftJoin('users', function ($model) {
                        $model->on('users.id', '=', 'asset_verifications.verified_by');
                    })->orderByRaw('CONCAT(users.first_name, users.last_name) ' . $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }
    public function addOrUpdatePhysicalVerification($condition, $attributes)
    {
        $query = $this->verificationModel;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function findVerificationById(int $id)
    {
        return $this->verificationModel->find($id);
    }
    public function deleteAssetVerifications(int $id)
    {
        $query = $this->verificationModel;
        // $query = $query->find($id)->delete();
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function getInventoryByIdentificationNo(string $identificationNo)
    {
        return $this->assetInventoryModel->where('identification_no', $identificationNo)->first();
    }
    public function getInventoryById(int $id)
    {
        return $this->assetInventoryModel->where('id', $id)->first();
    }
    public function findInventoriesByIds($ids)
    {
        $query = $this->assetInventoryModel->with('assetStock');
        $query = $query->whereIn('id', $ids);
        return $query->get();
    }
    public function addOrUpdateVerifiedAsset($condition, $attributes)
    {
        $query = $this->verifiedAssetModel;
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['picture']) && $attributes['picture']) {
            $fileName = uniqid() . '.' . $attributes['picture']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['picture'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->create([
                    'title' => $fileName,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => auth()->user()->id,
                ]);
            }
        }
        return $query;
    }
    public function deleteVerifiedAsset(int $id)
    {
        $query = $this->verifiedAssetModel;
        $query = $query->find($id)->delete();
        return $query;
    }
    public function findVerifiedAssetById(int $id)
    {
        return $this->verifiedAssetModel->with('document')->find($id);
    }
    public function addOrUpdateInventory($condition, $attributes)
    {
        $query = $this->assetInventoryModel;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function getExpiringLeases($day)
    {
        $query = $this->assetLeaseModel;
        $query = $query->whereHas('leaseItems', function ($itemModel) {
            $itemModel->where('is_completed', '0');
        });
        // $query = $query->where('end_date', '<=', Carbon::now()->addDays($day)->format('Y-m-d'))->where('end_date', '>=', Carbon::now()->format('Y-m-d'));
        $query = $query->whereRaw('DATEDIFF(end_date,current_date) = ' . $day);
        return $query->get();
    }
    public function getExpiringTickets()
    {


        $tickets = Ticket::with(['department.slaTimes', 'ticketCategory'])->get();
        $matchingTickets = $tickets->filter(function ($ticket) {
            $priority = $ticket->ticketCategory?->priority;
            $slaTimes = $ticket->department?->slaTimes?->where('priority', $priority);
            if ($slaTimes->isEmpty()) {
                return false;
            }
            $duration = $slaTimes?->first()->duration;
            $expiryDate = $ticket->created_at->copy()->addHours($duration);
            return Carbon::today() > $expiryDate;
            // $carbonToday = Carbon::today();
            // $targetDate = $ticket->created_at->copy()->addDays($duration);
            // return $carbonToday->isSameDay($targetDate);
        });
        // dd($matchingTickets);
        return $matchingTickets;
    }




    public function findNewList(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        $model = $model->whereHas('lease', function ($model){
            $model->where('id','!=',null);
        });
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    // public function findLeasedItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    // {
    //     $model = $this->lease_agreement_model;
    //     if ($filterConditions) {
    //         $model = $model->where($filterConditions);
    //     }
    //     if ($inRandomOrder) {
    //         $model = $model->inRandomOrder();
    //     } else {
    //         $model = $model->orderBy($orderBy, $sortBy);
    //     }
    //     if ($offset) {
    //         $model = $model->offset($offset);
    //     }
    //     if ($limit) {
    //         $model = $model->limit($limit);
    //     }
    //     // return $model->toRawSql();
    //     return $model->get();
    // }
}
