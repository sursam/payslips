<?php

namespace App\Repositories\Inventory;

use App\Repositories\BaseRepository;
use App\Models\Inventory\OutwardStock;
use App\Contracts\Inventory\OutwardStockContract;
class OutwardStockRepository extends BaseRepository implements OutwardStockContract
{
    public function __construct(protected OutwardStock $outwardStock){
        parent::__construct($outwardStock);
        $this->outwardStock = $outwardStock;
    }
    public function listOutWardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){

    }
    public function deleteOutWardStock(int $id){
        $query = $this->model;
        $query = $query->find($id)->delete();
        return $query;
    }
    public function findById(int $id){
        return $this->model->find($id);
    }
    public function updateTable(array $condition, array $attributes){
        $query = $this->model;
        $query = $query->where($condition);
        return $query->update($attributes);
    }
    public function getTotalOutWardStock(array $search = null){
        $query = $this->model;
        if($search) {
            $filterData = [];
        }
        return $query->count();
    }
    public function findOutWardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            if(isset($search['asset_uuid'])){
                $asseid = uuidtoid($search['asset_uuid'], 'assets');
                $model = $model->where('asset_id', $asseid);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset ) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function updateStatus(array $attributes, int $id){
        $query = $this->model;
        $query = $query->find($id)->update($attributes);
        return $query;
    }
}
