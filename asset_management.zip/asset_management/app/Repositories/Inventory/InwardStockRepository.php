<?php

namespace App\Repositories\Inventory;

use App\Repositories\BaseRepository;
use App\Models\Inventory\InwardStock;
use App\Contracts\Inventory\InwardStockContract;

class InwardStockRepository extends BaseRepository implements InwardStockContract
{
    public function __construct(protected InwardStock $inwardStock){
        parent::__construct($inwardStock);
        $this->inwardStock = $inwardStock;
    }
    public function listInWardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){

    }
    public function deleteInWardStock(int $id){
        $query = $this->model;
        $query = $query->find($id)->delete();
        return $query;
    }
    public function findById(int $id){
        return $this->model->find($id);
    }
    public function updateTable(array $condition, array $attributes){
        $query = $this->model;
        $query = $query->where($condition);
        return $query->update($attributes);
    }
    public function getTotalInWardStock(array $search = null){
        $query = $this->model;
        if($search) {
            $filterData = [];
        }
        return $query->count();
    }
    public function findInWardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            if(isset($search['asset_uuid'])){
                $asseid = uuidtoid($search['asset_uuid'], 'assets');
                $model = $model->where('asset_id', $asseid);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset ) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function updateStatus(array $attributes, int $id){
        $query = $this->model;
        $query = $query->find($id)->update($attributes);
        return $query;
    }
}
