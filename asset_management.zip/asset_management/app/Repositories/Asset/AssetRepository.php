<?php

namespace App\Repositories\Asset;

use \Log;
use App\Models\Site\Media;
use App\Traits\UploadAble;
use App\Models\Master\Asset;
use App\Models\Budget\Budget;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\Ticket\Ticket;
use App\Models\InvoiceVersion;
use App\Models\Site\Attribute;
use App\Models\Ticket\SlaTime;
use App\Models\Requisition\Rfq;
use App\Models\Site\Department;
use App\Models\Company\Location;
use App\Models\Budget\BudgetItem;
use App\Models\Budget\BudgetNote;
use Illuminate\Support\Facades\DB;
use App\Models\Inventory\Inventory;
use App\Models\Requisition\RfqItem;
use App\Models\Site\RecentActivity;
use App\Models\Budget\BudgetVersion;
use App\Models\Inventory\AssetStock;
use App\Models\Lease\LeaseAgreement;
use App\Models\Ticket\TicketSetting;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Auth;
use App\Models\Budget\BudgetApproval;
use App\Models\Requisition\Quotation;
use App\Models\Requisition\RfqVendor;
use App\Contracts\Asset\AssetContract;
use App\Models\Purchase\PurchaseOrder;
use App\Models\Master\TermAndCondition;
use App\Models\Requisition\Requisition;
use App\Models\Requisition\RfqApproval;
use App\Models\Purchase\PaymentSchedule;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Requisition\QuotationItem;
use App\Models\Purchase\PoInvoiceApproval;
use App\Models\Purchase\PurchaseOrderItem;
use App\Models\Maintenance\AssetMaintenance;
use App\Models\Receipt\AssetReceiptNoteItem;
use App\Models\Site\EntityDepartmentSetting;
use App\Models\Purchase\PurchaseOrderInvoice;
use App\Models\Requisition\RequisitionAssets;
use App\Models\Purchase\PurchaseOrderApproval;
use App\Models\Requisition\RequisitionVersion;
use App\Models\Requisition\RequisitionApproval;

class AssetRepository extends BaseRepository implements AssetContract
{
    use UploadAble;

    public function __construct(protected Asset $asset, protected Requisition $requisition_model, protected RequisitionAssets $requisition_item_model, protected Budget $budget_model, protected BudgetItem $budget_item_model, protected BudgetNote $budget_note_model, protected Media $budget_media_model, protected Document $budget_document_model, protected BudgetApproval $budget_approval_model, protected Location $location_model,  protected Category $category_model, protected BudgetVersion $budget_version_model, protected RequisitionApproval $requisition_approval_model, protected RequisitionVersion $requisition_version_model, protected Rfq $rfq_model, protected RfqVendor $rfq_vendor_model, protected RfqItem $rfq_item_model, protected Quotation $quotation_model, protected QuotationItem $quotation_item_model, protected PurchaseOrder $po_model, protected TermAndCondition $tnc_model, protected PurchaseOrderItem $po_item_model, protected PurchaseOrderApproval $po_approval_model, protected PaymentSchedule $payment_schedule_model, protected AssetReceiptNote $asset_receipt_note_model, protected AssetReceiptNoteItem $arn_item_model, protected RfqApproval $rfq_approval_model, protected AssetStock $asset_stock_model, protected Inventory $asset_inventory_model, protected PurchaseOrderInvoice $po_invoice_model, protected PoInvoiceApproval $po_invoice_approval_model, protected Department $department_model, protected Ticket $ticket_model, protected LeaseAgreement $lease_agreement_model, protected AssetMaintenance $asset_maintenance_model, protected RecentActivity $recent_activity_model, protected Attribute $attribute_model, protected SlaTime $sla_time_model, protected InvoiceVersion $invoice_version_model, protected EntityDepartmentSetting $entity_department_setting_model, protected TicketSetting $ticket_setting_model)
    {
        parent::__construct($asset);
        $this->asset = $asset;
        $this->requisition_model = $requisition_model;
        $this->requisition_item_model = $requisition_item_model;
        $this->budget_model = $budget_model;
        $this->budget_item_model = $budget_item_model;
        $this->budget_document_model = $budget_document_model;
        $this->budget_approval_model = $budget_approval_model;
        $this->location_model = $location_model;
        $this->budget_version_model = $budget_version_model;
        $this->requisition_approval_model = $requisition_approval_model;
        $this->requisition_version_model = $requisition_version_model;
        $this->rfq_vendor_model = $rfq_vendor_model;
        $this->rfq_item_model = $rfq_item_model;
        $this->quotation_model = $quotation_model;
        $this->quotation_item_model = $quotation_item_model;
        $this->po_model = $po_model;
        $this->po_item_model = $po_item_model;
        $this->tnc_model = $tnc_model;
        $this->po_approval_model = $po_approval_model;
        $this->payment_schedule_model = $payment_schedule_model;
        $this->asset_receipt_note_model = $asset_receipt_note_model;
        $this->arn_item_model = $arn_item_model;
        $this->rfq_approval_model = $rfq_approval_model;
        $this->asset_inventory_model = $asset_inventory_model;
        $this->po_invoice_model = $po_invoice_model;
        $this->po_invoice_approval_model = $po_invoice_approval_model;
        $this->ticket_model = $ticket_model;
        $this->department_model = $department_model;
        $this->lease_agreement_model = $lease_agreement_model;
        $this->asset_maintenance_model = $asset_maintenance_model;
        $this->recent_activity_model = $recent_activity_model;
        $this->attribute_model = $attribute_model;
        $this->sla_time_model = $sla_time_model;
        $this->invoice_version_model = $invoice_version_model;
    }

    public function listAssets($filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false)
    {
        $query = $this->asset;
        if (!is_null($filterConditions)) {
            $query = $query->where($filterConditions);
        }
        if ($inRandomOrder) {
            $query = $query->inRandomOrder();
        } else {
            $query = $query->orderBy($order, $sort);
        }
        if (!is_null($limit)) {
            return $query->paginate($limit);
        }
        return $query->get();
    }
    public function addOrUpdate($condition, $attributes)
    {
        $query = $this->asset;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function deleteAsset($id)
    {
        $query = $this->asset;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function setCategoryStatus($attributes, $id)
    {
        return $this->update($attributes, $id);
    }
    public function findById($id)
    {
        return $this->find($id);
    }
    public function updateTable($condition, $attributes)
    {
        $query = $this->asset;
        $query = $query->where($condition);
        return $query->update($attributes);
    }
    public function getUniqueVendor(int $id = null)
    {
        $query = $this->asset;
        $query = $query->where([['vendor_name', '!=', '']]);
        $query = $query->distinct();
        return $query;
    }
    public function getTotalAssets($search, $filterConditions)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        //    dd($search);
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id']) && $filterData['category_id'] && (!isset($filterData['asset_type']) || (isset($filterData['asset_type']) && !$filterData['asset_type']))) {
                $category_id = $filterData['category_id'];
                $model = $model->where('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['asset_type']) && $filterData['asset_type']) {
                // $asset_type = (is_array($filterData['asset_type'])) ? $filterData['asset_type'] : json_decode($filterData['asset_type']);
                $asset_type = explode(',', $filterData['asset_type']);
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        return $model->count();
    }
    public function findAssets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['category_id']) && $filterData['category_id'] && (!isset($filterData['asset_type']) || (isset($filterData['asset_type']) && !$filterData['asset_type']))) {
                $category_id = $filterData['category_id'];
                $model = $model->where('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['asset_type']) && $filterData['asset_type']) {
                // $asset_type = (is_array($filterData['asset_type'])) ? $filterData['asset_type'] : json_decode($filterData['asset_type']);
                $asset_type = explode(',', $filterData['asset_type']);
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'total_qty':
                case 'current_qty':
                case 'issued_qty':
                case 'leased_qty':
                case 'maintenance_qty':
                case 'disposed_qty':
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->get());
        // dd($model->toRawSql());
        return $model->get();
    }
    public function getAssetsByCatyegoryId(int $categoryId = null, array $filterConditions = [], $limit = null, $offset = null, string $orderBy = 'id', string $sortBy = 'asc', $inRandomOrder = false)
    {
        $model = $this->model->with('assetStock');
        if ($categoryId) {
            $model = $model->where('category_id', $categoryId)
                ->orWhereHas('category', function ($model) use ($categoryId) {
                    $model->where('parent_id', $categoryId);
                });
        }
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function getTotalRequisitions(array $filterConditions, $search = null)
    {
        $model = $this->requisition_model;
        if ($filterConditions) {
            if (isset($filterConditions['items'])) {
                $model = $model->has('items', '>', 0);
                unset($filterConditions['items']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $model = $model->whereIn('entity_id', $filterData['entity']);
            }
            if (isset($filterData['department'])) {
                $model = $model->whereIn('department_id', $filterData['department']);
            }
            if (isset($filterData['priority'])) {
                $model = $model->whereIn('priority', $filterData['priority']);
            }
            // if (isset($filterData['status'])) {
            //     $model = $model->whereIn('status', $filterData['status']);
            // }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }
            if (isset($filterData['created_by'])) {
                $model = $model->whereIn('created_by', $filterData['created_by']);
            }
            if (isset($filterData['created_at']) && $filterData['created_at'] != "") {
                $model = $model->whereDate('created_at', '=', $filterData['created_at']);
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('version', 'LIKE', "%{$searchText}%");
                });
            }
        }
        return $model->count();
    }
    public function findRequisitions(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->requisition_model;
        if ($filterConditions) {
            if (isset($filterConditions['items'])) {
                $model = $model->has('items', '>', 0);
                unset($filterConditions['items']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $model = $model->whereIn('entity_id', $filterData['entity']);
            }
            if (isset($filterData['department'])) {
                $model = $model->whereIn('department_id', $filterData['department']);
            }
            if (isset($filterData['priority'])) {
                $model = $model->whereIn('priority', $filterData['priority']);
            }
            // if (isset($filterData['status'])) {
            //     $model = $model->whereIn('status', $filterData['status']);
            // }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }
            if (isset($filterData['created_by'])) {
                $model = $model->whereIn('created_by', $filterData['created_by']);
            }
            if (isset($filterData['created_at']) && $filterData['created_at'] != "") {
                $model = $model->whereDate('created_at', '=', $filterData['created_at']);
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('unique_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('version', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'department_id':
                    $model = $model->select('requisitions.*')->join('departments', function ($model) {
                        $model->on('departments.id', '=', 'requisitions.department_id');
                    })->orderBy('departments.name', $sortBy);
                    break;
                case 'entity_id':
                    $model = $model->select('requisitions.*')->join('categories', function ($model) {
                        $model->on('categories.id', '=', 'requisitions.entity_id');
                    })->orderBy('categories.name', $sortBy);

                    break;
                case 'created_by':
                    $model = $model->select('requisitions.*')->join('users', function ($model) {
                        $model->on('users.id', '=', 'requisitions.created_by');
                    })->orderBy(DB::raw("CONCAT(users.first_name, ' ', users.last_name)"), $sortBy);

                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
           // $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->with('items')->get();
    }
    public function addOrUpdateRequisition($condition, $attributes)
    {
        $query = $this->requisition_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function deleteRequisition($id)
    {
        $query = $this->requisition_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findRequisitionById($id)
    {
        return $this->requisition_model->find($id);
    }
    public function updateRequisitionStatus($attributes, $id)
    {
        return $this->requisition_model->where('id', $id)->update($attributes);
    }

    public function getTotalRequisitionItems(array $filterConditions, $search)
    {
        $query = $this->requisition_item_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        /*if($search) {
            $filterData = [];
            parse_str( $search, $filterData );
            if(isset($filterData['s']) || $filterData['s'] != ''){
                $searchText = $filterData['s'];
                $query = $query->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%")
                        ->orWhere('id', (int)str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
                });
            }
            if(isset($filterData['entity'])){
                $entity = $filterData['entity'];
                $query = $query->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if(isset($filterData['asset_type'])){
                $asset_type = $filterData['asset_type'];
                $query = $query->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if(isset($filterData['is_active'])){
                $is_active = $filterData['is_active'];
                $query = $query->whereIn('is_active', $is_active);
            }
            if(isset($filterData['vendor_name'])){
                $vendor_name = $filterData['vendor_name'];
                $query = $query->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
        }*/
        return $query->count();
    }
    public function findRequisitionItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->requisition_item_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        /*if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str( $search, $filterData );
            if(isset($filterData['entity'])){
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if(isset($filterData['asset_type'])){
                $asset_type = $filterData['asset_type'];
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if(isset($filterData['is_active'])){
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if(isset($filterData['vendor_name'])){
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if(isset($filterData['s']) || $filterData['s'] != ''){
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%")
                        ->orWhere('id', (int)str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
                });
            }
        }*/
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }

    public function addOrUpdateRequisitionItem($condition, $attributes)
    {
        // dd($attributes);
        $query = $this->requisition_item_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function deleteRequisitionItem($id)
    {
        $query = $this->requisition_item_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findRequisitionItemById($id)
    {
        return $this->requisition_item_model->find($id);
    }

    // public function getTotalBudgets($search)
    // {
    //     $query = $this->budget_model;
    //     if ($search) {
    //         $filterData = [];
    //         parse_str($search, $filterData);
    //         if (isset($filterData['s']) || $filterData['s'] != '') {
    //             $searchText = $filterData['s'];
    //             $query = $query->where(function ($model) use ($searchText) {
    //                 $model->where('asset_id', 'LIKE', "%{$searchText}%")
    //                     ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
    //                     ->orWhereDate('purchase_date', $searchText)
    //                     ->orWhereDate('expiry_date', $searchText)
    //                     ->orWhere('price', 'LIKE', "%{$searchText}%")
    //                     ->orWhere('id', (int) str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
    //             });
    //         }
    //         if (isset($filterData['entity'])) {
    //             $entity = $filterData['entity'];
    //             $query = $query->whereHas('assettype', function ($model) use ($entity) {
    //                 $model->whereIn('entity_id', $entity);
    //             });
    //         }
    //         if (isset($filterData['asset_type'])) {
    //             $asset_type = $filterData['asset_type'];
    //             $query = $query->whereHas('assettype', function ($model) use ($asset_type) {
    //                 $model->whereIn('id', $asset_type);
    //             });
    //         }
    //         if (isset($filterData['is_active'])) {
    //             $is_active = $filterData['is_active'];
    //             $query = $query->whereIn('is_active', $is_active);
    //         }
    //         if (isset($filterData['vendor_name'])) {
    //             $vendor_name = $filterData['vendor_name'];
    //             $query = $query->whereHas('vendor', function ($model) use ($vendor_name) {
    //                 $model->whereIn('id', $vendor_name);
    //             });
    //         }
    //     }
    //     return $query->count();
    // }


    // public function findBudgets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    //     {
    //         $model = $this->budget_model;
    //         if ($filterConditions) {
    //             $model = $model->where($filterConditions);
    //         }
    //         if ($search) {
    //             $searchText = '';
    //             $filterData = [];
    //             parse_str($search, $filterData);
    //             if (isset($filterData['entity'])) {
    //                 $entity = $filterData['entity'];
    //                 $model = $model->whereHas('assettype', function ($model) use ($entity) {
    //                     $model->whereIn('entity_id', $entity);
    //                 });
    //             }
    //             if (isset($filterData['asset_type'])) {
    //                 $asset_type = $filterData['asset_type'];
    //                 $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
    //                     $model->whereIn('id', $asset_type);
    //                 });
    //             }
    //             if (isset($filterData['is_active'])) {
    //                 $is_active = $filterData['is_active'];
    //                 $model = $model->whereIn('is_active', $is_active);
    //             }
    //             if (isset($filterData['vendor_name'])) {
    //                 $vendor_name = $filterData['vendor_name'];
    //                 $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
    //                     $model->whereIn('id', $vendor_name);
    //                 });
    //             }
    //             if (isset($filterData['s']) || $filterData['s'] != '') {
    //                 $searchText = $filterData['s'];
    //                 $model = $model->where(function ($model) use ($searchText) {
    //                     $model->where('asset_id', 'LIKE', "%{$searchText}%")
    //                         ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
    //                         ->orWhereDate('purchase_date', $searchText)
    //                         ->orWhereDate('expiry_date', $searchText)
    //                         ->orWhere('price', 'LIKE', "%{$searchText}%")
    //                         ->orWhere('id', (int) str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
    //                 });
    //             }
    //         }
    //         if ($inRandomOrder) {
    //             $model = $model->inRandomOrder();
    //         } else {
    //             $model = $model->orderBy($orderBy, $sortBy);
    //         }
    //         if ($offset) {
    //             $model = $model->offset($offset);
    //         }
    //         if ($limit) {
    //             $model = $model->limit($limit);
    //         }
    //         // return $model->toRawSql();
    //         return $model->get();
    //     }


    public function addOrUpdateBudget($condition, $attributes)
    {
        $query = $this->budget_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function deleteBudget($id)
    {
        $query = $this->budget_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findBudgetById($id)
    {
        return $this->budget_model->find($id);
    }
    public function updateBudgetStatus($attributes, $id)
    {
        return $this->budget_model->where('id', $id)->update($attributes);
    }

    public function getTotalBudgetItems(array $filterConditions, $search)
    {
        $query = $this->budget_item_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        /*if($search) {
            $filterData = [];
            parse_str( $search, $filterData );
            if(isset($filterData['s']) || $filterData['s'] != ''){
                $searchText = $filterData['s'];
                $query = $query->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%")
                        ->orWhere('id', (int)str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
                });
            }
            if(isset($filterData['entity'])){
                $entity = $filterData['entity'];
                $query = $query->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if(isset($filterData['asset_type'])){
                $asset_type = $filterData['asset_type'];
                $query = $query->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if(isset($filterData['is_active'])){
                $is_active = $filterData['is_active'];
                $query = $query->whereIn('is_active', $is_active);
            }
            if(isset($filterData['vendor_name'])){
                $vendor_name = $filterData['vendor_name'];
                $query = $query->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
        }*/
        return $query->count();
    }
    public function findBudgetItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->budget_item_model;


        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        /*if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str( $search, $filterData );
            if(isset($filterData['entity'])){
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if(isset($filterData['asset_type'])){
                $asset_type = $filterData['asset_type'];
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if(isset($filterData['is_active'])){
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if(isset($filterData['vendor_name'])){
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if(isset($filterData['s']) || $filterData['s'] != ''){
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%")
                        ->orWhere('id', (int)str_replace("emp", "", str_replace(" ", "", strtolower($searchText))));
                });
            }
        }*/
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();

        return $model->get();
    }

    public function addOrUpdateBudgetItem($condition, $attributes)
    {
        $query = $this->budget_item_model;
        $data = [
            'budget_id' => $attributes['budget_id'],
            'category_id' => $attributes['parent_id'],
            'asset_type_id' => $attributes['asset_type_id'],
            'asset_id' => $attributes['asset_id'],
            'quantity' => $attributes['amount'],
            'specifications' => $attributes['specifications'],
        ];
        $query = $query->updateOrCreate($condition, $data);
        return $query;
    }
    public function deleteBudgetItem($id)
    {
        $query = $this->budget_item_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findBudgetItemById($id)
    {
        return $this->budget_item_model->find($id);
    }

    public function updateBudgetItemStatus($attributes, $id)
    {
        // dd($attributes);
        return $this->budget_item_model->where('id', $id)->update($attributes);
    }

    public function addOrUpdateBudgetNote($condition, $attributes)
    {
        $query = $this->budget_note_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }



    public function findBudgetNotes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->budget_note_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function findBudgetNoteById($id)
    {
        return $this->budget_note_model->find($id);
    }
    public function deleteBudgetNote($id)
    {
        $query = $this->budget_note_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function getTotalBudgetNotes(array $filterConditions, $search)
    {
        $query = $this->budget_note_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->count();
    }


    public function createBudgetDocument($condition, $attributes)
    {
        $budget = $this->findBudgetById($condition)->first();
        // dd($budget);
        if (isset($attributes['document'])) {
            foreach ($attributes['document'] as $value) {
                $fileName = uniqid() . '.' . $value->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($value, config('constants.SITE_BUDGET_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $budget->document()->create([
                        'title' => $attributes['title'],
                        'documentable_type ' => get_class($budget),
                        'documentable_id ' => $budget->id,
                        'document_type' => 'document',
                        'file' => $fileName,
                        'created_by' => Auth::user()->id,
                    ]);
                }
            }
        }

        return $budget;
    }

    public function getTotalBudgetDocuments(array $filterConditions, $search)
    {
        $query = $this->budget_document_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->count();
    }

    public function findBudgetDocuments(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->budget_document_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }


    // public function updateBudgetStatus($attributes, $id)
    // {
    //     // dd($attributes);
    //     return $this->budget_item_model->where('id', $id)->update($attributes);
    // }


    public function findBudgets(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        $model = $this->budget_model->with('budgetApproval');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                //  $status = $filterData['status'];
                // $model = $model->whereIn('status', $status);
                // if(in_array("6", $status)){
                //     $model = $model->whereNull('status');
                // }
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhere('unique_id', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'entity':
                    $model = $model->select('budgets.*')->leftJoin('categories', function ($model) {
                        $model->on('categories.id', '=', 'budgets.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                case 'dept':
                    $model = $model->select('budgets.*')->leftJoin('departments', function ($model) {
                        $model->on('departments.id', '=', 'budgets.department_id');
                    })->orderBy('departments.name', $sortBy);
                    break;
                case 'date':
                    $model = $model->orderBy('start_date', $sortBy);
                    break;
                case 'created_by':
                    $model = $model->select('budgets.*')->leftJoin('users', function ($model) {
                        $model->on('users.id', '=', 'budgets.created_by');
                    })->orderByRaw('CONCAT(users.first_name, users.last_name) '.$sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->get());
        //return ;
        return $model->get();
    }

    public function getTotalBudgets(array $filterConditions, $search = null)
    {
        $model = $this->budget_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhere('unique_id', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
            //return $model->get();
        }
        return $model->count();
    }



    public function findBudgetItemTotalAmount($id) //////this function is used to sum the total amount of Item listed under a budget
    {

        return $this->budget_item_model->where('budget_id', $id)->sum('quantity');
    }
    public function deleteBudgetDocument($id)
    {
        $query = $this->budget_document_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }

    public function createOrUpdateBudgetApproval($attributes)
    {
        $query = $this->budget_approval_model;
        $budgetApproval = $query->where('budget_id', $attributes['budget_id'])->where('level', $attributes['level'])->first();
        if ($budgetApproval) {
            $query = $budgetApproval->update($attributes);
        } else {
            $budgetApproval = $query->create($attributes);
        }
        return $budgetApproval;
    }
    public function getBudgetApprovals(array $filterConditions)
    {
        $query = $this->budget_approval_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->get();
    }
    public function getPendingBudgetApprovalsByUser(int $userId)
    {
        $query = $this->budget_approval_model;
        $query = $query->where('user_id', $userId)
                    ->where(function ($query) {
                        $query->where('status', 0)
                        ->orWhere('status', null);
                    });

        return $query->get();
    }
    public function checkBudgetApproval(int $budgetId, int $userId = null, int $level = null)
    {
        $query = $this->budget_approval_model;
        $query = $query->where('budget_id', $budgetId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->first();
    }
    public function addOrUpdateLocation($condition, $attributes)
    {
        // dd($attributes);
        $query = $this->location_model;
        $data = [
            'country_id' => $attributes['country'] ?? 101,
            'state_id' => $attributes['state'] ?? 101,
            'city_id' => $attributes['city'] ?? 101,
            'zipcode' => $attributes['zipcode'] ?? 700156,
            'street_address' => $attributes['street_address'],
            'name' => $attributes['location_name'],

        ];
        $query = $query->updateOrCreate($condition, $data);
        return $query;
    }
    public function getTotalLocations($search)
    {
        $query = $this->location_model;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $query = $query->where(function ($query) use ($searchText) {
                    $query->where('street_address', 'LIKE', "%{$searchText}%")
                    ->orWhereHas('city', function ($model) use ($searchText) {
                        $model->where('name', 'LIKE', "%{$searchText}%");
                    })
                    ->orWhereHas('state', function ($model) use ($searchText) {
                        $model->where('name', 'LIKE', "%{$searchText}%");
                    });
                });
            }
        }
        return $query->count();
    }

    public function findLocations(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->location_model;
        $model = $model->select('locations.*');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('street_address', 'LIKE', "%{$searchText}%")
                    ->orWhereHas('city', function ($model) use ($searchText) {
                        $model->where('name', 'LIKE', "%{$searchText}%");
                    })
                    ->orWhereHas('state', function ($model) use ($searchText) {
                        $model->where('name', 'LIKE', "%{$searchText}%");
                    });
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'city_id':
                    $model = $model->join('cities', 'cities.id', '=', 'locations.city_id');
                    $model = $model->orderBy('cities.name', $sortBy);
                    break;
                case 'state_id':
                    $model = $model->join('states', 'states.id', '=', 'locations.state_id');
                    $model = $model->orderBy('states.name', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function deleteLocation($id)
    {
        $query = $this->location_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function listLocations($filterConditions = [], string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false)
    {
        $query = $this->location_model->where('is_active', '1');
        if (!is_null($filterConditions)) {
            $query = $query->where($filterConditions);
        }
        if ($inRandomOrder) {
            $query = $query->inRandomOrder();
        } else {
            $query = $query->orderBy($order, $sort);
        }
        if (!is_null($limit)) {
            return $query->paginate($limit);
        }
        return $query->get();
    }

    public function getTotalBudgetVersions($filterConditions = [], $search = null)
    {
        $model = $this->budget_version_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
                //dd($model->get());
                //return $model->get();
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
        }
        return $model->count();
    }
    public function findBudgetVersions(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        $model = $this->budget_version_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
                //dd($model->get());
                //return $model->get();
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
            //return $model->get();
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->get());
        //return ;
        return $model->get();
    }
    public function addBudgetVersion($attributes)
    {
        $query = $this->budget_version_model;
        $query = $query->create($attributes);
        return $query;
    }
    public function deleteBudgetVersion($id)
    {
        $query = $this->budget_version_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findBudgetVersionById($id)
    {
        return $this->budget_version_model->with('entity')->with('department')->with('createdBy')->with('location')->with('category')->find($id);
    }
    public function findRequisitionVersionById($id)
    {
        return $this->requisition_version_model->with('entity')->with('department')->with('createdBy')->with('category')->find($id);
    }

    public function checkRequisitionApproval(int $requisitionId, int $userId = null, int $level = null)
    {
        $query = $this->requisition_approval_model;
        $query = $query->where('requisition_id', $requisitionId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->first();
    }
    public function createRequisitionDocument($condition, $attributes)
    {
        $requisition = $this->findRequisitionById($condition)->first();
        // dd($requisition);
        if (isset($attributes['document'])) {
            foreach ($attributes['document'] as $value) {
                $fileName = uniqid() . '.' . $value->getClientOriginalExtension();
                $isFileUploaded = $this->uploadOne($value, config('constants.SITE_BUDGET_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
                if ($isFileUploaded) {
                    $requisition->document()->create([
                        'title' => $attributes['title'],
                        'documentable_type ' => get_class($requisition),
                        'documentable_id ' => $requisition->id,
                        'document_type' => 'document',
                        'file' => $fileName,
                        'created_by' => Auth::user()->id,
                    ]);
                }
            }
        }

        return $requisition;
    }

    public function getTotalRequisitionDocuments(array $filterConditions, $search)
    {
        $query = $this->budget_document_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->count();
    }

    public function findRequisitionDocuments(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->budget_document_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function deleteRequisitionDocument($id)
    {
        $query = $this->budget_document_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function createOrUpdateRequisitionApproval($attributes)
    {
        $query = $this->requisition_approval_model;
        $requisitionApproval = $query->where('requisition_id', $attributes['requisition_id'])->where('level', $attributes['level'])->first();
        if ($requisitionApproval) {
            $query = $requisitionApproval->update($attributes);
        } else {
            $requisitionApproval = $query->create($attributes);
        }
        return $requisitionApproval;
    }
    public function getRequisitionApprovals(array $filterConditions)
    {
        $query = $this->requisition_approval_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->get();
    }
    public function getPendingRequisitionApprovalsByUser(int $userId)
    {
        $query = $this->requisition_approval_model;
        $query = $query->where('user_id', $userId)
                    ->where(function ($query) {
                        $query->where('status', 0)
                        ->orWhere('status', null);
                    });
        return $query->get();
    }
    public function getTotalRequisitionVersions($filterConditions = [], $search = null)
    {
        $model = $this->requisition_version_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
                //dd($model->get());
                //return $model->get();
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
        }
        return $model->count();
    }
    public function findRequisitionVersions(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        $model = $this->requisition_version_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
                //dd($model->get());
                //return $model->get();
            }
            if (isset($filterData['department'])) {
                $department = $filterData['department'];
                $model = $model->whereIn('department_id', $department);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
                    ->orWhere('amount', 'LIKE', "%$searchText%");
            }
            //return $model->get();
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->get());
        //return ;
        return $model->get();
    }
    public function addRequisitionVersion($attributes)
    {
        $query = $this->requisition_version_model;
        $query = $query->create($attributes);
        return $query;
    }
    public function deleteRequisitionVersion($id)
    {
        $query = $this->requisition_version_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function addOrUpdateRfq($condition, $attributes)
    {
        //dd($attributes);
        $query = $this->rfq_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }


    public function getTotalRfqs($filterConditions = [], $search = null)
    {
        $model = $this->rfq_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['request_date']) && $filterData['request_date'] != "") {
                $request_date = $filterData['request_date'];
                $model = $model->whereDate('request_date', '=', $request_date);
            }

            if (isset($filterData['validity_date']) && $filterData['validity_date'] != "") {
                $validity_date = $filterData['validity_date'];
                $model = $model->whereDate('validity_date', '=', $validity_date);
            }

            if (isset($filterData['request_no'])) {
                $request_no = $filterData['request_no'];
                $model = $model->whereIn('id', $request_no);
            }


            // if (isset($filterData['entity'])) {
            //     $entity = $filterData['entity'];
            //     $model = $model->whereIn('entity_id', $entity);
            // }
            // if (isset($filterData['department'])) {
            //     $department = $filterData['department'];
            //     $model = $model->whereIn('department_id', $department);
            // }
            // if (isset($filterData['status'])) {
            //     $status = $filterData['status'];
            //     $model = $model->whereIn('status', $status);
            // }
            // if (isset($filterData['s']) && $filterData['s'] != "") {
            //     $searchText = $filterData['s'];
            //     $model = $model->where('name', 'LIKE', "%$searchText%")
            //     ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
            //     ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
            //         ->orWhere('amount', 'LIKE', "%$searchText%");

            // }
        }
        return $model->count();
    }
    public function findRfqById($id)
    {
        return $this->rfq_model->with('rqfVendor')->find($id);
    }

    public function findRfqs(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        $model = $this->rfq_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            //dd($filterData);
            if (isset($filterData['request_date']) && $filterData['request_date'] != "") {
                $request_date = $filterData['request_date'];
                $model = $model->whereDate('request_date', '=', $request_date);
            }

            if (isset($filterData['validity_date']) && $filterData['validity_date'] != "") {
                $validity_date = $filterData['validity_date'];
                $model = $model->whereDate('validity_date', '=', $validity_date);
            }

            if (isset($filterData['request_no'])) {
                $request_no = $filterData['request_no'];
                $model = $model->whereIn('id', $request_no);
            }


            // if (isset($filterData['entity'])) {
            //     $entity = $filterData['entity'];
            //     $model = $model->whereIn('entity_id', $entity);
            // }
            // if (isset($filterData['department'])) {
            //     $department = $filterData['department'];
            //     $model = $model->whereIn('department_id', $department);
            // }
            // if (isset($filterData['status'])) {
            //     $status = $filterData['status'];
            //     $model = $model->whereIn('status', $status);
            // }
            // if (isset($filterData['s']) && $filterData['s'] != "") {
            //     $searchText = $filterData['s'];
            //     $model = $model->where('name', 'LIKE', "%$searchText%")
            //     ->orWhereRaw('DATE(start_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
            //     ->orWhereRaw('DATE(end_date) = STR_TO_DATE(?, "%Y-%m-%d")', [$searchText])
            //         ->orWhere('amount', 'LIKE', "%$searchText%");

            // }

        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }


    public function addOrUpdateRfqVendor($condition, $attributes)
    {
        //dd($attributes);
        $query = $this->rfq_vendor_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function addOrUpdateRfqItems($condition, $attributes)
    {
        $query = $this->rfq_item_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }


    public function findItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->requisition_item_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function deleteRfq($id)
    {
        $query = $this->rfq_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }

    public function getAllRfqItems($filterConditions, string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        return $this->rfq_item_model->where($filterConditions)->orderBy($orderBy, $sortBy)->get();
    }
    public function addOrUpdateQuotation($condition, $attributes)
    {
        //dd($attributes);
        $query = $this->quotation_model;
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['document'])) {

            $fileName = uniqid() . '.' . $attributes['document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['document'], config('constants.SITE_QUOTATION_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->create([
                    'title' => 'Quotation Document #' . $query->unique_id,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => Auth::user() ? Auth::user()->id : null,
                ]);
            }
        }
        return $query;
    }
    public function updateQuotation($attributes, $id)
    {
        $quotation = $this->quotation_model->find($id);
        return $quotation->update($attributes);
    }
    public function addOrUpdateQuotationItems($condition, $attributes)
    {
        $query = $this->quotation_item_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function getAllQuotations($filterConditions, string $orderBy = 'id', $sortBy = 'desc', $limit = null, $inRandomOrder = false)
    {   //dd($sortBy);
        return $this->quotation_model->where($filterConditions)->orderBy($orderBy, $sortBy)->with('rfq')->get();
    }
    public function getAllQuotationItems($filterConditions, string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        return $this->quotation_item_model->where($filterConditions)->orderBy($orderBy, $sortBy)->get();
    }

    public function listQuotations(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {

        $model = $this->quotation_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['quotation_date']) && $filterData['quotation_date'] != "") {
                $model = $model->whereDate('created_at', '=', $filterData['quotation_date']);
            }
            if (isset($filterData['quotation_id'])) {
                $model = $model->whereIn('id', $filterData['quotation_id']);
            }
            if (isset($filterData['request_id'])) {
                $model = $model->whereIn('request_id', $filterData['request_id']);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'vendor_id':
                    $model = $model->select('quotations.*')->join('vendors', function ($model) {
                        $model->on('vendors.id', '=', 'quotations.vendor_id');
                    })->orderBy(DB::raw("CONCAT(vendors.first_name, ' ', vendors.last_name)"), $sortBy);
                    break;

                case 'comapny_name':
                    $model = $model->select('quotations.*')->join('vendors', function ($model) {
                        $model->on('vendors.id', '=', 'quotations.vendor_id');
                    })->orderBy('vendors.company_name', $sortBy);

                    break;
                case 'contact_no':
                    $model = $model->select('quotations.*')->join('vendors', function ($model) {
                        $model->on('vendors.id', '=', 'quotations.vendor_id');
                    })->orderBy('vendors.mobile_number', $sortBy);

                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function getTotalQuotations(array $filterConditions, $search = null)
    {
        $model = $this->quotation_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['quotation_date']) && $filterData['quotation_date'] != "") {
                $model = $model->whereDate('created_at', '=', $filterData['quotation_date']);
            }
            if (isset($filterData['quotation_id'])) {
                $model = $model->whereIn('id', $filterData['quotation_id']);
            }
            if (isset($filterData['request_id'])) {
                $model = $model->whereIn('request_id', $filterData['request_id']);
            }
        }
        return $model->count();
    }
    public function findQuotationById($id)
    {
        return $this->quotation_model->find($id);
    }

    public function getTotalPurchaseOrders($search)
    {
        $model = $this->po_model;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
            }
            if (isset($filterData['order_date']) && $filterData['order_date'] != "") {
                $model = $model->whereDate('po_date', '=', $filterData['order_date']);
            }
            if (isset($filterData['vendor'])) {
                $vendor = $filterData['vendor'];
                $model = $model->whereIn('vendor_id', $vendor);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhereHas('quotations', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        return $model->count();
    }
    public function findPurchaseOrders(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->po_model->with('poApproval');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereIn('entity_id', $entity);
            }
            if (isset($filterData['order_date']) && $filterData['order_date'] != "") {
                $model = $model->whereDate('po_date', '=', $filterData['order_date']);
            }
            if (isset($filterData['vendor'])) {
                $vendor = $filterData['vendor'];
                $model = $model->whereIn('vendor_id', $vendor);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->where(function ($query) use ($status) {
                    if (in_array("6", $status)) {
                        $status = array_diff($status, ["6"]);
                        if (!empty($status)) {
                            $query->where(function ($subQuery) use ($status) {
                                $subQuery->whereIn('status', $status)
                                    ->orWhereNull('status');
                            });
                        } else {
                            $query->whereNull('status');
                        }
                    } else {
                        $query->whereIn('status', $status);
                    }
                });
            }

            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhereHas('quotations', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'entity':
                    $model = $model->select('purchase_orders.*')->join('categories', function ($model) {
                        $model->on('categories.id', '=', 'purchase_orders.entity_id');
                    })->orderBy('categories.name', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function addOrUpdatePurchaseOrder($condition, $attributes)
    {
        $query = $this->po_model;
        $query = $query->updateOrCreate($condition, $attributes);

        if (isset($attributes['attachment_document']) && $attributes['attachment_document']) {
            $document = $attributes['attachment_document'];
            $fileName = uniqid() . '.' . $document->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($document, config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->updateOrCreate(['documentable_id' => $query->id], [
                    'title'=> $fileName,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => auth()->user()->id,
                ]);
            }
        }



        return $query;
    }
    public function deletePurchaseOrder($id)
    {
        $query = $this->po_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findPurchaseOrderById($id)
    {
        return $this->po_model->find($id);
    }
    public function updatePurchaseOrderStatus($attributes, $id)
    {
        return $this->po_model->where('id', $id)->update($attributes);
    }
    public function addOrUpdatePurchaseOrderItems($condition, $attributes)
    {
        $query = $this->po_item_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function deleteTermAndCondition($id)
    {
        $query = $this->tnc_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findTermAndConditions(array $filterConditions, string $orderBy = 'order', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->tnc_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('name', 'LIKE', "%$searchText%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }

    public function getTotalTermAndConditions($search)
    {
        $model = $this->tnc_model;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('name', 'LIKE', "%$searchText%");
            }
        }
        return $model->count();
    }

    public function setLocationStatus($attributes, $id)
    {
        return $this->location_model->where('id', $id)->update($attributes);
    }
    public function setTncStatus($attributes, $id)
    {
        return $this->tnc_model->where('id', $id)->update($attributes);
    }
    public function checkPurchaseOrderApproval(int $poId, int $userId = null, int $level = null)
    {
        $query = $this->po_approval_model;
        $query = $query->where('purchase_order_id', $poId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->first();
    }

    public function createOrUpdatePoApproval($attributes)
    { //dd($attributes);
        $query = $this->po_approval_model;
        //dd($attributes);
        $poApproval = $query->where('purchase_order_id', $attributes['purchase_order_id'])->where('level', $attributes['level'])->first();

        if ($poApproval) {
            $query = $poApproval->update($attributes);
        } else {
            $poApproval = $query->create($attributes);
        }
        return $poApproval;
    }

    public function checkPoApproval(int $poId, int $userId = null, int $level = null)
    {
        $query = $this->po_approval_model;
        $query = $query->where('purchase_order_id', $poId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->first();
    }

    public function updatePoStatus($attributes, $id)
    {
        return $this->po_model->where('id', $id)->update($attributes);
    }

    public function findPoId($id)
    {
        return $this->po_model->with('quotations')->find($id);
    }
    public function findPoItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->po_item_model;
        if ($filterConditions) {
            if (isset($filterConditions['items'])) {
                $model = $model->has('items', '>', 0);
                unset($filterConditions['items']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['asset_type'])) {
                $asset_type = $filterData['asset_type'];
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function deletePo($id)
    {
        $query = $this->po_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }


    public function getPoApprovals(array $filterConditions)
    {
        $query = $this->po_approval_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->get();
    }

    public function getPendingPoApprovalsByUser(int $userId)
    {
        $query = $this->po_approval_model;
        $query = $query->where('user_id', $userId)
                    ->where(function ($query) {
                        $query->where('status', 0)
                        ->orWhere('status', null);
                    });
        return $query->get();
    }

    public function addOrUpdatePaymentSchedules($condition, $attributes)
    {
        $query = $this->payment_schedule_model;
        if (isset($attributes['attachment_document'])) {
            $fileName = uniqid() . '.' . $attributes['attachment_document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['attachment_document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['attachment_file'] = $fileName;
            }
        }
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }


    public function listPaymentSchedules($filterConditions = [], string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false)
    {
        $query = $this->payment_schedule_model;
        if (!is_null($filterConditions)) {
            $query = $query->where($filterConditions);
        }
        if ($inRandomOrder) {
            $query = $query->inRandomOrder();
        } else {
            $query = $query->orderBy($order, $sort);
        }
        if (!is_null($limit)) {
            return $query->paginate($limit);
        }
        return $query->get();
    }

    public function findPsItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->payment_schedule_model;
        if ($filterConditions) {
            if (isset($filterConditions['items'])) {
                $model = $model->has('items', '>', 0);
                unset($filterConditions['items']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['asset_type'])) {
                $asset_type = $filterData['asset_type'];
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function addOrUpdateAssetReceiptNote($condition, $attributes)
    {
        //dd($attributes);
        $query = $this->asset_receipt_note_model;
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['attachment_document']) && $attributes['attachment_document']) {
            $document = $attributes['attachment_document'];
            $fileName = uniqid() . '.' . $document->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($document, config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->updateOrCreate(['documentable_id' => $query->id], [
                    'title'=> $fileName,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => auth()->user()->id,
                ]);
            }
        }
        return $query;
    }
    public function addOrUpdateAssetReceiptNoteItems($condition, $attributes)
    {
        $query = $this->arn_item_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }

    public function getTotalAssetReceiptNotes($search)
    {
        $model = $this->asset_receipt_note_model;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['arnId'])) {
                $arnId = $filterData['arnId'];
                $model = $model->whereIn('id', $arnId);
            }

            if (isset($filterData['purchaseOrder'])) {
                $purchaseOrder = $filterData['purchaseOrder'];
                $model = $model->whereIn('purchase_order_id', $purchaseOrder);
            }

            if (isset($filterData['received_date']) && $filterData['received_date'] != "") {
                $model = $model->whereDate('received_date', '=', $filterData['received_date']);
            }

            if (isset($filterData['receiverName'])) {
                $receiverName = $filterData['receiverName'];
                $model = $model->whereIn('receiver_id', $receiverName);
            }
            if (isset($filterData['receivedLocation'])) {
                $receivedLocation = $filterData['receivedLocation'];
                $model = $model->whereIn('received_location_id', $receivedLocation);
            }
        }
        return $model->count();
    }
    public function findAssetReceiptNotes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->asset_receipt_note_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['arnId'])) {
                $arnId = $filterData['arnId'];
                $model = $model->whereIn('id', $arnId);
            }

            if (isset($filterData['purchaseOrder'])) {
                $purchaseOrder = $filterData['purchaseOrder'];
                $model = $model->whereIn('purchase_order_id', $purchaseOrder);
            }
            if (isset($filterData['received_date']) && $filterData['received_date'] != "") {
                $model = $model->whereDate('received_date', '=', $filterData['received_date']);
            }
            if (isset($filterData['receiverName'])) {
                $receiverName = $filterData['receiverName'];
                $model = $model->whereIn('receiver_id', $receiverName);
            }
            if (isset($filterData['receivedLocation'])) {
                $receivedLocation = $filterData['receivedLocation'];
                $model = $model->whereIn('received_location_id', $receivedLocation);
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'receiver_name':
                    $model = $model->select('asset_receipt_notes.*')->join('users', function ($model) {
                        $model->on('users.id', '=', 'asset_receipt_notes.receiver_id');
                    })->orderBy(DB::raw("CONCAT(users.first_name, ' ', users.last_name)"), $sortBy);
                    break;

                case 'receiver_location':
                        $model = $model->select('asset_receipt_notes.*')->join('locations', function ($model) {
                            $model->on('locations.id', '=', 'asset_receipt_notes.received_location_id');
                        })->orderBy('locations.street_address', $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
                }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function findAssetReceiptNoteById($id)
    {
        return $this->asset_receipt_note_model->find($id);
    }
    public function findAssetReceiptNoteItemById($id)
    {
        return $this->arn_item_model->find($id);
    }


    public function findAssetReceiptNoteItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->arn_item_model;
        if ($filterConditions) {
            if (isset($filterConditions['items'])) {
                $model = $model->has('items', '>', 0);
                unset($filterConditions['items']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['asset_type'])) {
                $asset_type = $filterData['asset_type'];
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }

    public function getAllAssetReceiptNoteItems($filterConditions, string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        return $this->arn_item_model->where($filterConditions)->orderBy($orderBy, $sortBy)->get();
    }

    public function deleteAssetReceiptNote($id)
    {
        $query = $this->asset_receipt_note_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function createOrUpdateRfqApproval($attributes)
    {
        $query = $this->rfq_approval_model;
        //$rfqApproval = $query->where('request_id', $attributes['request_id'])->where('level', $attributes['level'])->first();
        //dd($attributes);
        $rfqApproval = $query->where(['request_id'=> $attributes['request_id'],'user_id'=>$attributes['user_id']])->where('level', $attributes['level'])->first();

        //dd($rfqApproval);
        if ($rfqApproval !== null) {
            $query = $rfqApproval->update($attributes);
        } else {

           $rfqApproval = $query->create($attributes);
       }
        return $rfqApproval;
    }
    public function checkRfqApproval(int $requestId, int $userId = null, int $level = null, $status = null)
    {
        $query = $this->rfq_approval_model;
        $query = $query->where('request_id', $requestId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        if ($status != null) {
            $query = $query->where('status', $status);
        }
        return $query->first();
    }

    public function checkRfqApprovalByLatestOrder(int $requestId, int $userId = null, int $level = null, $status = null)
    {
        $query = $this->rfq_approval_model->orderBy('id','desc');
        //dd("aaa");
        $query = $query->where('request_id', $requestId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        if ($status != null) {
            $query = $query->where('status', $status);
        }
        return $query->first();
    }
    public function getPendingRfqApprovalsByUser(int $userId)
    {
        $query = $this->rfq_approval_model;
        $query = $query->where('user_id', $userId)
                    ->where(function ($query) {
                        $query->where('status', 0)
                        ->orWhere('status', null);
                    });
        return $query->get();
    }
    public function findLocationById($id)
    {
        return $this->location_model->find($id);
    }
    public function getAssetStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $inRandomOrder = false)
    {
        $model = $this->asset_stock_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        return $model->first();
    }
    public function addOrUpdateAssetStock($condition, $attributes)
    {
        $query = $this->asset_stock_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function addOrUpdateInventory($condition, $attributes)
    {
        $query = $this->asset_inventory_model;
        $query = $query->updateOrCreate($condition, $attributes);

        if (isset($attributes['document'])) {
            $fileName = uniqid() . '.' . $attributes['document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['document'], config('constants.SITE_QUOTATION_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $query->document()->create([
                    'title' => 'Quotation Document #' . $query->unique_id,
                    'documentable_type ' => get_class($query),
                    'documentable_id ' => $query->id,
                    'document_type' => 'document',
                    'file' => $fileName,
                    'created_by' => Auth::user()->id,
                ]);
            }
        }
        return $query;
    }

    public function getInventories($filterConditions, string $orderBy = 'id', $sortBy = 'asc', $inRandomOrder = false)
    {
        $model = $this->asset_inventory_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        return $model->get();
    }

    public function getTotalInvoices($search)
    {
        $model = $this->po_invoice_model;
        if ($search) {
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['invoice_date']) && $filterData['invoice_date'] != "") {
                $model = $model->whereDate('invoice_date', '=', $filterData['invoice_date']);
            }
            if (isset($filterData['vendor'])) {
                $vendor = $filterData['vendor'];
                $model = $model->whereIn('vendor_id', $vendor);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhere('party_invoice_number', 'LIKE', "%$searchText%")
                    ->orWhereHas('purchaseOrder', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        return $model->count();
    }
    public function findInvoices(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->po_invoice_model->with('approval');
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['invoice_date']) && $filterData['invoice_date'] != "") {
                $model = $model->whereDate('invoice_date', '=', $filterData['invoice_date']);
            }
            if (isset($filterData['vendor'])) {
                $vendor = $filterData['vendor'];
                $model = $model->whereIn('vendor_id', $vendor);
            }
            if (isset($filterData['status'])) {
                $status = $filterData['status'];
                $model = $model->whereIn('status', $status);
            }
            if (isset($filterData['s']) && $filterData['s'] != "") {
                $searchText = trim($filterData['s']);
                $model = $model->where('unique_id', 'LIKE', "%$searchText%")
                    ->orWhere('party_invoice_number', 'LIKE', "%$searchText%")
                    ->orWhereHas('purchaseOrder', function ($model) use ($searchText) {
                        $model->where('unique_id', 'LIKE', "%$searchText%");
                    });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'vendor':
                    $model = $model->select('purchase_order_invoices.*')->join('vendors', function ($model) {
                        $model->on('vendors.id', '=', 'purchase_order_invoices.vendor_id');
                    })->orderBy(DB::raw("CONCAT(vendors.first_name, ' ', vendors.last_name)"), $sortBy);
                    break;


                default:
                    $model = $model->orderBy($orderBy, $sortBy);
                }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        //dd($model->toRawSql());
        //return ;
        return $model->get();
    }
    public function addOrUpdateInvoice($condition, $attributes)
    {
        $query = $this->po_invoice_model;
        $query = $query->updateOrCreate($condition, $attributes);
        if (isset($attributes['document_file']) && $attributes['document_file']) {
            foreach ($attributes['document_file'] as $key => $document) {
                if ($document) {
                    $fileName = uniqid() . '.' . $document->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($document, config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $query->document()->create([
                            'title' => (isset($attributes['document_title'][$key]) && $attributes['document_title'][$key]) ? $attributes['document_title'][$key] : 'Invoice document ' . ($key + 1),
                            'documentable_type ' => get_class($query),
                            'documentable_id ' => $query->id,
                            'document_type' => 'document',
                            'file' => $fileName,
                            'created_by' => Auth::user()->id,
                        ]);
                    }
                }
            }
        }
        return $query;
    }
    public function deleteInvoice($id)
    {
        $query = $this->po_invoice_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findInvoiceById($id)
    {
        return $this->po_invoice_model->find($id);
    }
    public function updateInvoiceStatus($attributes, $id)
    {
        return $this->po_invoice_model->where('id', $id)->update($attributes);
    }
    public function createOrUpdateInvoiceApproval($attributes)
    {
        $query = $this->po_invoice_approval_model;
        $poInvoiceApproval = $query->where('po_invoice_id', $attributes['po_invoice_id'])->where('level', $attributes['level'])->first();

        if ($poInvoiceApproval) {
            $query = $poInvoiceApproval->update($attributes);
        } else {
            $poInvoiceApproval = $query->create($attributes);
        }
        return $poInvoiceApproval;
    }


    public function createInvoiceApproval($attributes)
    {
        // $query = $this->po_invoice_approval_model;
        // $poInvoiceApproval = $query->where('po_invoice_id', $attributes['po_invoice_id'])->where('level', $attributes['level'])->first();

        // if ($poInvoiceApproval) {
        //     $query = $poInvoiceApproval->update($attributes);
        // } else {
        //     $poInvoiceApproval = $query->create($attributes);
        // }
        $query = $this->po_invoice_approval_model;
        $poInvoiceApproval = $query->create($attributes);

        return $poInvoiceApproval;
    }

    public function createOrUpdateInvoiceApprovalLatestOrder($attributes)
    {
        $query = $this->po_invoice_approval_model;
        $poInvoiceApproval = $query->where('po_invoice_id', $attributes['po_invoice_id'])->where('level', $attributes['level'])->latest()->first();

        if ($poInvoiceApproval) {
            $query = $poInvoiceApproval->update($attributes);
        } else {
            $poInvoiceApproval = $query->create($attributes);
        }
        return $poInvoiceApproval;
    }




    public function findInventoryById($id)
    {
        return $this->asset_inventory_model->find($id);
    }
    public function findAssetStockById($id)
    {
        return $this->asset_stock_model->find($id);
    }
    public function alterArnItemRemainingQuantity(array $condition, int $quantity, string $type)
    {
        $query = $this->arn_item_model;
        $query = $query->where($condition);
        if ($type == 'decrease')
            $query = $query->decrement('remaining_quantity', $quantity);
        else
            $query = $query->increment('remaining_quantity', $quantity);

        return $query;
    }
    public function findInventoryByCondition($filterConditions)
    {
        $query = $this->asset_inventory_model->with('assetStock');
        $query = $query->where($filterConditions);
        return $query->first();
    }
    public function findAssetByCondition($filterConditions)
    {
        $query = $this->model;
        $query = $query->where($filterConditions);
        return $query->first();
    }

    public function checkPoInvoiceApproval(int $poInvoiceId, int $userId = null, int $level = null)
    {
        $query = $this->po_invoice_approval_model;
        $query = $query->where('po_invoice_id', $poInvoiceId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->first();
    }

    public function checkPoInvoiceApprovalLatestOrder(int $poInvoiceId, int $userId = null, int $level = null)
    {
        $query = $this->po_invoice_approval_model;
        $query = $query->where('po_invoice_id', $poInvoiceId);
        if ($userId) {
            $query = $query->where('user_id', $userId);
        }
        if ($level) {
            $query = $query->where('level', $level);
        }
        return $query->latest()->first();
    }


    public function getPoInvoiceApprovals(array $filterConditions)
    {
        $query = $this->po_invoice_approval_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->get();
    }




    public function getPendingPoInvoiceApprovalsByUser(int $userId)
    {
        $query = $this->po_invoice_approval_model;
        $query = $query->where('user_id', $userId)
                    ->where(function ($query) {
                        $query->where('status', 0)
                        ->orWhere('status', null);
                    });
        return $query->get();
    }

    public function addOrUpdateTicket($condition, $attributes)
    {
        $query = $this->ticket_model;
        // dd($attributes);
        if (isset($attributes['attachment_document'])) {
            $fileName = uniqid() . '.' . $attributes['attachment_document']->getClientOriginalExtension();
            $isFileUploaded = $this->uploadOne($attributes['attachment_document'], config('constants.SITE_DOCUMENT_UPLOAD_PATH'), $fileName, 'public');
            if ($isFileUploaded) {
                $attributes['attachment_file'] = $fileName;
            }
        }
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function listDepartments($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $search = null)
    {
        $departments = $this->department_model->where($filterConditions)->orderBy($orderBy, $sortBy);
        if (isset($search['search_text']) && $search['search_text'] != "") {
            $searchText = trim($search['search_text']);
            $departments = $departments->where('name', 'LIKE', "%$searchText%")
                ->orWhere('unique_id', 'LIKE', "%$searchText%")
                ->orWhere('description', 'LIKE', "%$searchText%")
                ->orWhere('type', 'LIKE', "%$searchText%");
        }
        if (!is_null($limit)) {
            return $departments->paginate($limit);
        }
        return $departments->get();
    }
    public function findDepartmentById($id)
    {
        return $this->department_model->find($id);
    }

    public function findDepartmentByName($name)
    {
        return $this->department_model->where(['name' => $name])->first();
    }
    public function createDepartment($attributes)
    {
        $isDepartmentCreated = $this->department_model->updateOrCreate($attributes);

        return $isDepartmentCreated;
    }
    public function updateDepartment($attributes, $id)
    {
        $department = $this->department_model->find($id);
        $isDepartmentUpdated = $department->update($attributes);

        return $isDepartmentUpdated;
    }



    public function createOrUpdateSla($attributes, $id)
    {

        $priorities = [
            1 => 'high',
            2 => 'medium',
            3 => 'low',
        ];

        $isSlaUpdated = false;
        foreach ($priorities as $priority => $attribute) {
            if (isset($attributes[$attribute]) && $attributes[$attribute] !== null) {
                $updated = SlaTime::where('department_id', $id)
                    ->where('priority', $priority)
                    ->update(['duration' => $attributes[$attribute]]);
                if ($updated === 0) {
                    SlaTime::create([
                        'department_id' => $id,
                        'priority' => $priority,
                        'duration' => $attributes[$attribute],
                    ]);
                }
                $isSlaUpdated = true;
            }
        }
        return $isSlaUpdated;
    }
    public function setDepartmentStatus($attributes, $id)
    {
        $department = $this->department_model->find($id);
        return $department->update($attributes);
    }
    public function deleteDepartment($id)
    {
        $department = $this->findDepartmentById($id);
        ## Delete page seo
        if ($department) {
            $department->delete();
        }
        return $department ?? false;
    }
    public function findTicketRaisedByMe(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->ticket_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function deleteInventory($id)
    {
        $query = $this->asset_inventory_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }
    public function findLeasedAgreements(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->lease_agreement_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function findAssetMaintenances(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->asset_maintenance_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function addOrUpdateRecentActivity($condition, $attributes)
    {
        $query = $this->recent_activity_model;
        $query = $query->updateOrCreate($condition, $attributes);
        return $query;
    }
    public function findRecentActivities(array $filterConditions, array $type = null, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        //dd($filterConditions);
        $model = $this->recent_activity_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }

        if ($type != null) {
            $model = $model->whereIn('type', $type)->groupBy('type', 'inventory_id')
                ->selectRaw('type, inventory_id,   COUNT(*) as totalrow');
        } else {
            // $model = $model->groupBy('type', 'task_name', 'task_description', 'task_url')
            //     ->select('type,task_name,task_description, task_url, MAX(created_at) as created_at, COUNT(*) as totalrow');

            $model = $model->selectRaw('type,task_name,task_description, task_url, MAX(created_at) as created_at, COUNT(*) as totalrow')
                ->groupBy('type', 'task_name', 'task_description', 'task_url');
        }


        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function getRelatedBudgets(array $requisitionItems)
    {
        $model = $this->budget_model->whereHas('items', function ($model) use ($requisitionItems) {
            $model->whereIn('asset_id', $requisitionItems);
        });
        // dd($model->toRawSql());
        return $model->get();
    }
    public function getItemsNotInBudget(array $requisitionItems)
    {
        $itemsArr = [];
        if ($requisitionItems) {
            foreach ($requisitionItems as $requisitionItem) {
                $modelCount = $this->budget_item_model->where('asset_id', $requisitionItem)->count();
                if (!$modelCount) {
                    $itemsArr[] = $requisitionItem;
                }
            }
        }
        return $itemsArr;
    }
    public function getTotalSearchedAssets($search, $filterConditions)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        //    dd($search);
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['category_id']) && $filterData['category_id'] && (!isset($filterData['asset_type']) || (isset($filterData['asset_type']) && !$filterData['asset_type']))) {
                $category_id = $filterData['category_id'];
                $model = $model->where('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['asset_type']) && $filterData['asset_type']) {
                // $asset_type = (is_array($filterData['asset_type'])) ? $filterData['asset_type'] : json_decode($filterData['asset_type']);
                $asset_type = explode(',', $filterData['asset_type']);
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        return $model->count();
    }
    public function findSearchedAssets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);

            if (isset($filterData['category_id']) && $filterData['category_id'] && (!isset($filterData['asset_type']) || (isset($filterData['asset_type']) && !$filterData['asset_type']))) {
                $category_id = $filterData['category_id'];
                $model = $model->where('category_id', $category_id)
                    ->orWhereHas('category', function ($model) use ($category_id) {
                        $model->where('parent_id', $category_id);
                    });
            }
            if (isset($filterData['asset_type']) && $filterData['asset_type']) {
                // $asset_type = (is_array($filterData['asset_type'])) ? $filterData['asset_type'] : json_decode($filterData['asset_type']);
                $asset_type = explode(',', $filterData['asset_type']);
                $model = $model->whereHas('assettype', function ($model) use ($asset_type) {
                    $model->whereIn('id', $asset_type);
                });
            }
            if (isset($filterData['entity'])) {
                $entity = $filterData['entity'];
                $model = $model->whereHas('assettype', function ($model) use ($entity) {
                    $model->whereIn('entity_id', $entity);
                });
            }
            if (isset($filterData['is_active'])) {
                $is_active = $filterData['is_active'];
                $model = $model->whereIn('is_active', $is_active);
            }
            if (isset($filterData['vendor_name'])) {
                $vendor_name = $filterData['vendor_name'];
                $model = $model->whereHas('vendor', function ($model) use ($vendor_name) {
                    $model->whereIn('id', $vendor_name);
                });
            }
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('asset_id', 'LIKE', "%{$searchText}%")
                        ->orWhere('asset_name', 'LIKE', "%{$searchText}%")
                        ->orWhereDate('purchase_date', $searchText)
                        ->orWhereDate('expiry_date', $searchText)
                        ->orWhere('price', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->get());
        // dd($model->toRawSql());
        return $model->get();
    }
    public function updateTermAndConditions($attributes, $id)
    {
        $query = $this->tnc_model;
        $query = $query->where('id', $id);
        return $query->update($attributes);
    }
    public function getRfqApprovals(array $filterConditions)
    {
        $query = $this->rfq_approval_model;
        if ($filterConditions) {
            $query = $query->where($filterConditions);
        }
        return $query->orderBy('id', 'desc')->get();
    }
    public function getAttributes(array $filterConditions, string $orderBy = 'order', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->attribute_model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('name', 'LIKE', "%{$searchText}%")
                        ->orWhere('slug', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        return $model->get();
    }
    public function addAttribute($attributes)
    {
        $query = $this->attribute_model;
        $query = $query->create($attributes);
        return $query;
    }
    public function updateAttribute($attributes, $id)
    {
        $query = $this->attribute_model;
        $query = $query->where('id', $id);
        return $query->update($attributes);
    }
    public function deleteAttribute($id)
    {
        $query = $this->attribute_model;
        $query = $query->whereId($id)->delete();
        return $query;
    }

    public function findSlaTimeByDepartmentId($id)
    {
        return $this->sla_time_model->where('department_id',$id)->get();
    }


    public function addInvoiceVersion($attributes)
    {

        // \Log::debug('Attributes before create:', $attributes);

        // dd($attributes);
        $query = $this->invoice_version_model;

        $query = $query->create($attributes);
        // dd($query);
        return $query;
    }

    public function createEntityDepartmentSettings($attributes)
    {
        $isDepartmentCreated = $this->entity_department_setting_model->updateOrCreate([], $attributes);
        return $isDepartmentCreated;
    }
    public function updateEntityDepartmentSettings($attributes, $condition)
    {
        $isDepartmentUpdated = $this->entity_department_setting_model->updateOrCreate($condition, $attributes);
        return $isDepartmentUpdated;
    }
    public function createTicketSettings($attributes)
    {
        $isDepartmentCreated = $this->ticket_setting_model->updateOrCreate([], $attributes);
        return $isDepartmentCreated;
    }
    public function updateTicketSettings($attributes, $condition)
    {
        $isDepartmentUpdated = $this->ticket_setting_model->updateOrCreate($condition, $attributes);
        return $isDepartmentUpdated;
    }
}
