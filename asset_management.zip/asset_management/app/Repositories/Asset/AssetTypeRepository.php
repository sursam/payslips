<?php

namespace App\Repositories\Asset;

use App\Models\Site\Category;
use App\Models\Master\AssetType;
use App\Repositories\BaseRepository;
use App\Contracts\Asset\AssetTypeContract;

class AssetTypeRepository extends BaseRepository implements AssetTypeContract
{
    public function __construct(protected AssetType $assetType,protected Category $category_model){
        parent::__construct($assetType);
        $this->assetType = $assetType;
        $this->category_model = $category_model;
    }

    public function listAssets($filterConditions, string $order = 'id', string $sort = 'desc', $limit = null, $inRandomOrder = false){
        $query =  $this->assetType;
        if (!is_null($filterConditions)) {
            $query = $query->where($filterConditions);
        }
        if ($inRandomOrder) {
            $query = $query->inRandomOrder();
        } else {
            $query = $query->orderBy($order, $sort);
        }
        if (!is_null($limit)) {
            return $query->paginate($limit);
        }
        return $query->get();
    }

    public function findAssetTypes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->assetType;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhere('type_id', 'LIKE', "%$searchText%")
                    ->orWhereHas('category', function ($query) use ($searchText) {
                        $query->where('name', 'LIKE', "%$searchText%");
                    });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            switch($orderBy){
                case 'parent':
                    // $model = $model->join('asset_types as at', 'at.id', '=', 'asset_types.parent_id');
                    // $model = $model->orderBy('at.name', $sortBy);
                    // $model = $model->orderBy(AssetType::select('name')->whereColumn('asset_types.parent_id','id'), $sortBy);
                    break;
                case 'category':
                    $model = $model->orderBy(Category::select('name')->whereColumn('asset_types.category_id','categories.id'), $sortBy);
                    break;
                default:
                    $model = $model->orderBy($orderBy, $sortBy);
            }
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }

        // dd($model->toRawSql());
        // dd($model->get());
        return $model->get();
    }

    public function addOrUpdate($condition, $data){
        $query =  $this->assetType;
        $query = $query->updateOrCreate($condition, $data);
        return $query;
    }

    public function deleteType($id){
        $query =  $this->assetType;
        $query =  $query->whereId($id)->delete();
        return $query;
    }

    public function setCategoryStatus($attributes, $id){
        return $this->update($attributes, $id);
    }

    public function findById($id){
        return $this->find($id);
    }

    public function updateTable($condition, $attributes){
        $query =  $this->assetType;
        $query = $query->where($condition);
        return $query->update($attributes);
    }
    public function findAssetTypeByCategoryId(int $id){
        $query = $this->category_model;
        $query=$query->where('parent_id',$id)->get();
        return $query;
    }
}
