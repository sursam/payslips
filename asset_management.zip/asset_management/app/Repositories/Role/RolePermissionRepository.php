<?php
namespace App\Repositories\Role;

use App\Contracts\Role\RolePermissionContract;
use App\Models\Module\Module;
use App\Models\User\Permission;
use App\Models\User\Role;
use App\Repositories\BaseRepository;


class RolePermissionRepository extends BaseRepository implements RolePermissionContract
{

    public function __construct(Role $model,protected Permission $permissionModel, protected Module $moduleModel)
    {
        parent::__construct($model);
        $this->permissionModel= $permissionModel;
        $this->moduleModel= $moduleModel;
    }

    public function getTotalData($search = null)
    {
        if($search) {
            return $this->model->where('name','LIKE',"%{$search}%")
                ->orWhere('slug', 'LIKE',"%{$search}%")
                ->count();
        }

        return $this->model->count();
    }

    public function getTotalPermissionData($search = null)
    {
        if($search) {
            return $this->permissionModel->where('name','LIKE',"%{$search}%")
                ->orWhere('slug', 'LIKE',"%{$search}%")
                ->count();
        }

        return $this->permissionModel->count();
    }

    /**
     * @param $start
     * @param $limit
     * @param $order
     * @param $dir
     * @param null $search
     * @return mixed
     */
    public function getList($start = null, $limit = null, $order = 'id', $dir = 'asc', $search = null)
    {
        $model = $this->model;
        if($search) {
            $model = $model->where('name','LIKE',"%{$search}%")
                ->orWhere('slug', 'LIKE',"%{$search}%");
        }
        if($start && $limit){
            $model = $model->offset($start)->limit($limit);
        }
        return $model->orderBy($order, $dir)->get();
    }
    /**
     * @param $start
     * @param $limit
     * @param $order
     * @param $dir
     * @param null $search
     * @return mixed
     */
    public function getPermissionList($start, $limit, $order, $dir, $search = null)
    {
        if($search) {
            return $this->permissionModel->where('name','LIKE',"%{$search}%")
                ->orWhere('slug', 'LIKE',"%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
        }

        return $this->permissionModel->offset($start)
            ->limit($limit)
            ->orderBy($order, $dir)
            ->get();
    }

    public function findById($id){
        return $this->find($id);
    }

    public function getAllPermissions($type = ''){
        $permissionModel = $this->permissionModel;
        if($type){
            $permissionModel = $permissionModel->where('type',$type);
        }
        return $permissionModel->orderBy('type')->orderBy('module_id')->NotDashboard()->get();
    }

    public function createRole($attributes){
        return $this->model->create($attributes);
    }
    public function deleteRole($id)
    {
        $model = $this->model;
        $model = $model->find($id)->delete();
        return $model;
    }
    public function createPermission($attributes){
        return $this->permissionModel->create($attributes);
    }

    public function getAllRoles($filterConditions,string $orderBy = 'id', $sortBy = 'asc'){
        return $this->model->where($filterConditions)->orderBy($orderBy, $sortBy)->get();

    }
    public function listModules(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        // dd($search);
        $model = $this->moduleModel;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = trim($filterData['s']);
                $model = $model->where('title', 'LIKE', "%{$searchText}%")
                ->orWhere('slug', 'LIKE', "%{$searchText}%")
                ->orWhere('type', 'LIKE', "%{$searchText}%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // dd($model->toRawSql());
        return $model->get();
    }
    public function findModuleById($id)
    {
        return $this->moduleModel->find($id);
    }
    public function addOrUpdateModule($condition, $attributes)
    {
        $model = $this->moduleModel;
        $model = $model->updateOrCreate($condition, $attributes);
        return $model;
    }
    public function deleteModule($id)
    {
        $model = $this->moduleModel;
        $model = $model->whereId($id)->delete();
        return $model;
    }
    public function addOrUpdatePermissions($condition, $attributes)
    {
        $model = $this->permissionModel;
        if(isset($condition['slug'])){
            $slug = $condition['slug'];
            $model = $model->where('slug', 'LIKE', "%{$slug}%");
            unset($condition['slug']);
        }
        $model = $model->updateOrCreate($condition, $attributes);
        return $model;
    }
    public function listPermissions(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->permissionModel;
        if ($filterConditions) {
            if(isset($filterConditions['slug'])){
                $slug = $filterConditions['slug'];
                $model = $model->where('slug', 'LIKE', "%{$slug}%");
                unset($filterConditions['slug']);
            }
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('name', 'LIKE', "%{$searchText}%")
                        ->orWhere('slug', 'LIKE', "%{$searchText}%")
                        ->orWhere('type', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function findRoleBySlug($slug)
    {
        return $this->model->where('slug', $slug)->first();
    }
}
