<?php

namespace App\Repositories\Workflow;

use App\Models\Workflow\Workflow;
use App\Traits\UploadAble;
use App\Repositories\BaseRepository;
use App\Contracts\Workflow\WorkflowContract;

class WorkflowRepository extends BaseRepository implements WorkflowContract
{
    use UploadAble;
    public function __construct(protected Workflow $workflow)
    {
        $this->workflow = $workflow;
    }
    public function listWorkflows(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->workflow;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) || $filterData['s'] != '') {
                $searchText = $filterData['s'];
                $model = $model->where(function ($model) use ($searchText) {
                    $model->where('name', 'LIKE', "%{$searchText}%")
                        ->orWhere('type', 'LIKE', "%{$searchText}%")
                        ->orWhere('module', 'LIKE', "%{$searchText}%");
                });
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }
        // return $model->toRawSql();
        return $model->get();
    }
    public function findWorkflowById($id)
    {
        return $this->find($id);
    }
    public function addOrUpdateWorkflow($condition, $attributes)
    {
        $model = $this->workflow;
        $model = $model->updateOrCreate($condition, $attributes);
        return $model;
    }
    public function deleteWorkflow($id)
    {
        $model = $this->workflow;
        $model = $model->whereId($id)->delete();
        return $model;
    }
}
