<?php

namespace App\Repositories\Location;

use App\Models\Location\City;
use App\Models\Budget\BudgetItem;
use App\Repositories\BaseRepository;
use App\Contracts\Location\CityContract;

class CityRepository extends BaseRepository implements CityContract
{
    protected $model;
    public function __construct(City $model, protected BudgetItem $budget_item_model, protected City $city_model,)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->budget_item_model = $budget_item_model;
    }

    public function getCityByState(int $stateid){

        $model = $this->city_model->where('state_id',$stateid);
        return $model->get();

        // $model = $this->budget_item_model;
        // return $model->get();
    }


    public function findBudgetNotes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null)
    {
        $model = $this->budget_item_model;

        return $model->get();
    }
}
