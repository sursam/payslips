<?php

namespace App\Repositories\Location;

use App\Models\Location\State;
use App\Repositories\BaseRepository;
use App\Contracts\Location\StateContract;

class StateRepository extends BaseRepository implements StateContract
{

    protected $model;
    public function __construct(State $model)
    {
        parent::__construct($model);
        $this->model = $model;
    }
    public function find($id){
        $query = $this->find($id);
        return $query;
    }
    public function findBy($filterConditions, string $orderBy = 'name', string $sortBy = 'asc'){
        $query = $this->model->where($filterConditions);
        $query = $query->orderBy($orderBy, $sortBy);
        $query = $query->get();
        return $query;
    }
    // public function getCityByState(int $stateid){

    //     $model = $this->city_model->where('state_id',$stateid);
    //     return $model->get();
    // }
    public function getStateByCountry(int $countryid){

        $model = $this->model->where('country_id',$countryid);
        $model = $model->orderBy('name', 'asc');
        return $model->get();
    }

    public function getAllState(){
        $model = $this->model;
        $model = $model->orderBy('name', 'asc');
        return $model->get();
    }
}
