<?php

namespace App\Repositories\Category;

use App\Models\Site\Group;
use App\Models\Site\Media;
use App\Traits\UploadAble;
use App\Models\Site\Category;
use App\Models\Site\Attribute;
use App\Models\Site\AttributeValue;
use App\Repositories\BaseRepository;
use App\Contracts\Category\CategoryContract;
use App\Models\Master\TermAndCondition;
use App\Models\Site\CategoryFeature;
use Illuminate\Database\Eloquent\Collection;

/**
 * Class UserRepository
 *
 * @package \App\Repositories
 */
class CategoryRepository extends BaseRepository implements CategoryContract
{
    use UploadAble;
    /**
     * CategoryRepository constructor.
     * @param Category $model
     *  @param Attribute $attributeModel
     */
    public function __construct(Category $model,protected Attribute $attributeModel,protected Group $groupModel, protected Media $mediaModel, protected AttributeValue $attributeValueModel,protected TermAndCondition $termAndConditionModel)
    {
        parent::__construct($model);
        $this->model = $model;
        $this->attributeModel = $attributeModel;
        $this->groupModel = $groupModel;
        $this->mediaModel = $mediaModel;
        $this->attributeValueModel = $attributeValueModel;
        $this->termAndConditionModel = $termAndConditionModel;
    }

    public function findCategories($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $offset=null, $inRandomOrder=false, $search=null)
    {
        // $categories = $this->model->where($filterConditions)->orderBy($orderBy,$sortBy);
        // if (!is_null($limit)) {
        //     return $categories->paginate($limit);
        // }
        // return $categories->get();

        $model = $this->model;
        if ($filterConditions) {
            $model = $model->where($filterConditions);
        }
        if ($search) {
            $searchText = '';
            $filterData = [];
            parse_str($search, $filterData);
            if (isset($filterData['s']) && $filterData['s']) {
                $searchText = $filterData['s'];
                $model = $model->where('name', 'LIKE', "%$searchText%")
                    ->orWhere('description', 'LIKE', "%$searchText%");
            }
        }
        if ($inRandomOrder) {
            $model = $model->inRandomOrder();
        } else {
            $model = $model->orderBy($orderBy, $sortBy);
        }
        if ($offset) {
            $model = $model->offset($offset);
        }
        if ($limit) {
            $model = $model->limit($limit);
        }

        // dd($model->toRawSql());
        // dd($model->get());
        return $model->get();
    }
    public function listMasterCategories($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $categories= $this->model;
        if(!is_null($filterConditions)){
            $categories= $categories->where($filterConditions);
        }
        $categories = $categories->whereNull('parent_id')->get();
       // dd($categories);
        return $categories;
    }
    public function findAttributes($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $attribute = $this->attributeModel;

        if (!is_null($filterConditions)) {
            $attribute= $attribute->where($filterConditions);
        }

        $attribute= $attribute->orderBy($orderBy,$sortBy);
        if (!is_null($limit)) {
            return $attribute->paginate($limit);
        }
        return $attribute->get();
    }
    public function getCategories()
    {
        return $this->with('subcategories')->where(['parent_id' => 0])->get();
    }
    public function findCategoryById($id)
    {
        return $this->find($id);
    }
    public function createCategory($attributes)
    {
        $isCategoryCreated = $this->model->updateOrCreate([
            'name' => $attributes['name'],
            'parent_id' => $attributes['parent_id'] ? $attributes['parent_id'] : NULL,
            'description' => $attributes['description'] ?? null,
            'type' => $attributes['type']
        ]);
        if ($isCategoryCreated) {
            if (isset($attributes['category_image'])) {
                foreach ($attributes['category_image'] as $image) {
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_CATEGORY_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $isFileRelatedMediaCreated = $isCategoryCreated->media()->create([
                            'user_id' => auth()->user()->id,
                            'mediaable_type' => get_class($isCategoryCreated),
                            'mediaable_id' => $isCategoryCreated->id,
                            'media_type' => 'image',
                            'file' => $fileName,
                            'is_profile_picture' => false
                        ]);
                    }
                }
            }
            if (isset($attributes['banner_image'])) {
                $bannerFileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isBannerFileUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_CATEGORY_IMAGE_UPLOAD_PATH'), $bannerFileName, 'public');
                if ($isBannerFileUploaded) {
                    $isCategoryCreated->media()->where('media_type','banner')->delete();
                    $isBannerFileRelatedMediaCreated = $isCategoryCreated->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $bannerFileName,
                        'is_profile_picture' => false
                    ]);
                }
            }
        }

        return $isCategoryCreated;
    }
    public function updateCategory($attributes, $id)
    {
        $categoryData = $this->model->find($id);
        $isCategoryUpdated = $this->model->updateOrCreate([
            'id' => $id
        ], [
            'name' => $attributes['name'],
            'slug' => NULL,
            'parent_id' => $attributes['parent_id'] > 0 ? $attributes['parent_id'] : NULL,
            'description' => $attributes['description'] ?? null,
        ]);

        if ($isCategoryUpdated) {
            if (isset($attributes['category_image'])) {
                foreach ($attributes['category_image'] as $image) {
                    $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
                    $isFileUploaded = $this->uploadOne($image, config('constants.SITE_CATEGORY_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $categoryData->media()->delete();
                        $isFileRelatedMediaCreated = $categoryData->media()->create([
                            'user_id' => auth()->user()->id,
                            'media_type' => 'image',
                            'file' => $fileName,
                            'is_profile_picture' => false
                        ]);
                    }
                }
            }
            if (isset($attributes['banner_image'])) {
                $bannerFileName = uniqid() . '.' . $attributes['banner_image']->getClientOriginalExtension();
                $isBannerFileUploaded = $this->uploadOne($attributes['banner_image'], config('constants.SITE_CATEGORY_IMAGE_UPLOAD_PATH'), $bannerFileName, 'public');
                if ($isBannerFileUploaded) {
                    $categoryData->media()->where('media_type','banner')->delete();
                    $isBannerFileRelatedMediaCreated = $categoryData->media()->create([
                        'user_id' => auth()->user()->id,
                        'media_type' => 'banner',
                        'file' => $bannerFileName,
                        'is_profile_picture' => false
                    ]);
                }
            }
        }
        return $isCategoryUpdated;
    }
    public function setCategoryStatus($attributes, $id)
    {
        return $this->update($attributes, $id);
    }
    public function deleteCategory($id)
    {
        $category = $this->findCategoryById($id);
        ## Delete page seo
        if ($category) {
            // $category->is_active = 3;
            $category->update();
            if ($category->seo) {
                $category->seo->delete();
            }
            $category->delete();
        }
        return $category ?? false;
    }
    public function listAttributes($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $attribute = $this->attributeModel->get();
        if (!is_null($limit)) {
            return $attribute->paginate($limit);
        }
        return $attribute;
    }
    public function findAttributeById($id)
    {
        return $this->attributeModel->find($id);
    }
    public function createAttribute($attributes)
    {
        $isAttributCreated = $this->attributeModel->create([
            'name' => $attributes['name'],
            'created_by' => auth()->user()->id,
            'updated_by' => auth()->user()->id
        ]);
        if ($isAttributCreated->id) {
            foreach ($attributes['category']  as $cat_id) {
                $category = $this->find($cat_id);
                $isAttributeAttached = $category->attribute()->attach($isAttributCreated);
            }
        }
        return $isAttributCreated;
    }
    public function createAttributeValue($attributes)
    {
        return $this->attributeValueModel->create([
            'value' => $attributes['value'],
            'attribute_id' => $attributes['attribute_id'],
        ]);
    }
    public function updateAttribute($attributes, $id)
    {
        $isAttribute = $this->attributeModel->where('id', $id)->first();
        $isAttributeUpdate =  $this->attributeModel->where('id', $id)->update([
            'name' => $attributes['name'],
            'updated_by' => auth()->user()->id
        ]);
        if ($isAttribute->id) {

            $category = $this->model->whereIn('id', $attributes['category'])->get();
            $isAttribute->categories()->detach();
            $isAttribute->categories()->attach($category);
        }
        return $isAttributeUpdate;
    }
    public function deleteAttribute($id)
    {
        $attribute = $this->findAttributeById($id);
        ## Delete page seo
        if ($attribute) {
            $attribute->is_active = 3;
            $attribute->update();
            $attribute->delete();
        }
        return $attribute ?? false;
    }




    public function getTotalData($filterConditions, $search=null){
        $query = $this->model;
        if($filterConditions) {
            $query = $query->where($filterConditions);
        }
        if($search) {
            $query = $query->where('name','LIKE',"%{$search}%");
        }
        return $query->count();
    }
    public function getListofCategories($filterConditions, $start, $limit, $order, $dir, $search = null)
    {
        $query = $this->model->where($filterConditions);
        if($search) {
            $query = $query->where('name','LIKE',"%{$search}%");
        }
        $query = $query->offset($start)->limit($limit)->orderBy($order, $dir);
        // dd($query->toRawSql());
        return $query->get();
    }
    public function getListofAssetTypeCategories($filterConditions, $start, $limit, $order, $dir, $search = null, $parent = null, $results = null)
    {
        /*if(!$results){
            $results = new Collection([]);
        }
        $query = $this->model->where($filterConditions);

        if($search) {
            $filterData = [];
            parse_str( $search, $filterData );
            $searchText = $filterData['s'];
            if($searchText){
                $query = $query->where('name','LIKE',"%{$searchText}%");
            }
        }
        if($parent){
            $query = $query->where('parent_id', $parent);
        }
        $query = $query->offset($start)->limit($limit)->orderBy($order, $dir);
        $queryData = $query->get();
        if($queryData->count()){
            foreach($queryData as $row){
                $results->push($row);
                $this->getListofAssetTypeCategories($filterConditions, $start, $limit, $order, $dir, $search, $row->id, $results);
            }
        }
        return $results;*/

        $query = $this->model;
        if($filterConditions) {
            $query = $query->where($filterConditions);
        }
        if($search) {
            $filterData = [];
            parse_str( $search, $filterData );
            $searchText = $filterData['s'];
            if($searchText){
                $query = $query->where('name','LIKE',"%{$searchText}%");
            }
        }
        $query = $query->offset($start)->limit($limit)->orderBy($order, $dir);
        return $query->get();
    }
    public function categoriesList($filterConditions)
    {
        $query = $this->model->where($filterConditions);
        return $query->orderBy('id', 'asc')->get();
    }
    public function getListofSubCategories($filterConditions)
    {
        $query = $this->model->whereNull('parent_id')->where($filterConditions);
        return $query->orderBy('id', 'desc')->get();
    }

    public function findCategoryBySlug($slug)
    {
        return $this->model->where(['slug' => $slug])->first();
    }





    public function attachAttributes(array $attributes,int $id){
        $category= $this->find($id);
        if($category){
            if(isset($attributes['attributes'])){
                $attributes= $this->attributeModel->whereIn('uuid',$attributes['attributes'])->get();
                $category->attributes()->sync($attributes);
            }
            return $category;
        }
        return false;
    }
    public function attachGroups(array $attributes,int $id){
        $category= $this->find($id);
        if($category){
            if(isset($attributes['attributes'])){
                $attributes= $this->groupModel->whereIn('uuid',$attributes['attributes'])->get();
                $category->groups()->sync($attributes);
            }
            return $category;
        }
        return false;
    }

    public function findFaqCategories($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $categories = $this->model->where('type', 'faqs')->where($filterConditions)->orderBy($orderBy,$sortBy);
        if (!is_null($limit)) {
            return $categories->paginate($limit);
        }
        return $categories->with('faqs')->get();
    }
    public function findSupportCategories($filterConditions, $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $categories = $this->model->where('type', 'support')->where('parent_id', NULL)->where($filterConditions)->orderBy($orderBy,$sortBy);
        if (!is_null($limit)) {
            return $categories->paginate($limit);
        }
        // return $categories->with('supports')->get();
        return $categories->get();
    }


    public function createTermAndCondition($attributes)
    {
        $isCategoryCreated = $this->termAndConditionModel->updateOrCreate([
            'name' => $attributes['name'],
            'type' => $attributes['type'] ?? null,
            'description' => $attributes['description'] ?? null,
        ]);
        return $isCategoryCreated;
    }
    public function updateTermAndCondition($attributes, $id)
    {
        $categoryData = $this->termAndConditionModel->find($id);
        $isCategoryUpdated = $this->termAndConditionModel->updateOrCreate([
            'id' => $id
        ], [
            'name' => $attributes['name'],
            'type' => $attributes['type'] ?? null,
            'description' => $attributes['description'] ?? null,
        ]);
        return $isCategoryUpdated;
    }


    public function findTermAndConditions($filterConditions, $orderBy = 'order', $sortBy = 'asc', $limit = null, $inRandomOrder = false)
    {
        $categories = $this->termAndConditionModel->where($filterConditions)->orderBy($orderBy,$sortBy);
        if (!is_null($limit)) {
            return $categories->paginate($limit);
        }
        return $categories->get();
    }

    public function findTermAndCondition($id)
    {
        return $this->termAndConditionModel->find($id);
    }

}
