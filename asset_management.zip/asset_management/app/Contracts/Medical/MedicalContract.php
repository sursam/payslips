<?php

namespace App\Contracts\Medical;

/**
 * Interface MedicalContract
 * @package App\Contracts
 */
interface MedicalContract
{

}
