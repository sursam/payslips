<?php

namespace App\Contracts\Product;

/**
 * Interface ProductContract
 * @package App\Contracts
 */
interface ProductContract
{

}
