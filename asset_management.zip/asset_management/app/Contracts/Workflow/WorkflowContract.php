<?php

namespace App\Contracts\Workflow;

/**
 * Interface PageContract
 * @package App\Contracts
 */
interface WorkflowContract
{
    /**
     * @param string $order
     * @param string $sort
     * @param array $columns
     * @return mixed
     */
    public function listWorkflows(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null);

    /**
     * @param int $id
     * @return mixed
     */


    public function findWorkflowById(int $id);

    /**
     * @param array $condition
     * @param array $attributes
     * @return mixed
     */

    public function addOrUpdateWorkflow(array $condition, array $attributes);

    /**
     * @param int $id
     * @return mixed
     */

    public function deleteWorkflow(int $id);
}
