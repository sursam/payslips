<?php

namespace App\Contracts\Users;

interface VendorContract
{
    public function createVendor(array $attributes);
    public function updateVendor(array $attributes,int $id);
    public function getTotalUsers(string $sreach = null);
    public function deleteVendor(int $id);
    public function findUserById(int $id);
    public function updateVendorStatus(array $attributes, int $id);
    public function getAllUsers($filterConditions,$role,string $orderBy = 'id', $sortBy = 'asc', $limit = null, $inRandomOrder = false);
    public function findUserByRole(array $filterConditions,string $role='vendor',string $orderBy = 'id', string $sortBy = 'asc',$limit= null,$offset=null,$inRandomOrder=false,$search=null);
    public function findUserByLocation($search = null, string $orderBy = 'id', string $sortBy = 'asc', $inRandomOrder=false);
    public function findVendorsExceptIds(array $vendorIds);
}
