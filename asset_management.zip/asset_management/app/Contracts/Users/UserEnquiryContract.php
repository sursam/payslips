<?php

namespace App\Contracts\Users;

/**
 * Interface AdsContract
 * @package App\Contracts
 */
interface UserEnquiryContract
{
	

}
