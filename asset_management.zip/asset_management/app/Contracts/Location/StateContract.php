<?php

namespace App\Contracts\Location;

/**
 * Interface StateContract
 * @package App\Contracts
 */
interface StateContract
{
    public function find(int $id);
    public function findBy(array $filterConditions, string $orderBy = 'name', string $sortBy = 'asc');

}
