<?php

namespace App\Contracts\Location;

/**
 * Interface CityContract
 * @package App\Contracts
 */
interface CityContract
{
    public function getCityByState(int $stateid);
}
