<?php

namespace App\Contracts\Inventory;

interface AssetStockContract{
    public function listAssetStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false);
    public function deleteAssetStock(int $id);
    public function findById(int $id);
    public function updateTable(array $condition, array $attributes);
    public function getTotalAssetStock(array $search);
    public function updateStatus(array $attributes, int $id);
    public function findAssetStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null);
}
