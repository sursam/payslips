<?php

namespace App\Contracts\Inventory;

interface InwardStockContract{
    public function listInwardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false);
    public function deleteInwardStock(int $id);
    public function findById(int $id);
    public function updateTable(array $condition, array $attributes);
    public function getTotalInwardStock(array $search = null);
    public function updateStatus(array $attributes, int $id);
    public function findInwardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null);
}
