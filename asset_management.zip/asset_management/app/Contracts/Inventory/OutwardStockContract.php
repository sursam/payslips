<?php

namespace App\Contracts\Inventory;

interface OutwardStockContract{
    public function listOutwardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false);
    public function deleteOutwardStock(int $id);
    public function findById(int $id);
    public function updateTable(array $condition, array $attributes);
    public function getTotalOutwardStock(array $search = null);
    public function updateStatus(array $attributes, int $id);
    public function findOutwardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null);
}
