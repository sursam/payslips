<?php

namespace App\Contracts\Subscription;

interface SubscriptionContract
{
}
