<?php

namespace App\Contracts\Zone;

/**
 * Interface ZoneContract
 * @package App\Contracts
 */
interface ZoneContract
{

}
