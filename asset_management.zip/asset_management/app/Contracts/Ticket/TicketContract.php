<?php

namespace App\Contracts\Ticket;

/**
 * Interface PageContract
 * @package App\Contracts
 */
interface TicketContract
{
    /**
     * @param string $order
     * @param string $sort
     * @param array $columns
     * @return mixed
     */
    public function listTickets(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null);

    /**
     * @param int $id
     * @return mixed
     */


    public function findTicketById(int $id);

    /**
     * @param array $condition
     * @param array $attributes
     * @return mixed
     */

    public function addOrUpdateTicket(array $condition, array $attributes);

    /**
     * @param int $id
     * @return mixed
     */

    public function deleteTicket(int $id);
}
