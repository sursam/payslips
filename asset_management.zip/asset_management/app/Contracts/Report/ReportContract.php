<?php

namespace App\Contracts\Report;

interface ReportContract{
    public function addOrUpdateSettings(array $condition, array $attributes);
    public function getDepreciationSettings(array $filterConditions);
}
