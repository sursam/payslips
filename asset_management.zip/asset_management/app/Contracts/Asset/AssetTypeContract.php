<?php

namespace App\Contracts\Asset;

interface AssetTypeContract{
    public function listAssets(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false);
    public function addOrUpdate(array $condition, array $data);
    public function deleteType(int $id);
    public function setCategoryStatus(array $attributes, int $id);
    public function findById(int $id);
    public function updateTable(array $condition, array $attributes);
}
