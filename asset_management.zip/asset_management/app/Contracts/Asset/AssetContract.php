<?php

namespace App\Contracts\Asset;

interface AssetContract{
    public function listAssets(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false);
    public function addOrUpdate(array $condition, array $attributes);
    public function deleteAsset(int $id);
    public function setCategoryStatus(array $attributes, int $id);
    public function findById(int $id);
    public function updateTable(array $condition, array $attributes);
    public function getUniqueVendor(int $id = null);
    public function getTotalAssets(array $search, array $filterConditions);
    public function findAssets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null);
}
