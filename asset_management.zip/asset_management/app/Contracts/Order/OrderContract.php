<?php

namespace App\Contracts\Order;

/**
 * Interface OrderContract
 * @package App\Contracts
 */
interface OrderContract
{

}
