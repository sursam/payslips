<?php

namespace App\Services\Asset;
use App\Repositories\Asset\AssetRepository;
class AssetService
{
    protected $assetRepository;
    public function __construct(AssetRepository $assetRepository){
        $this->assetRepository = $assetRepository;
    }
    public function listAssets(array $filterConditions,string $orderBy='id',$sortBy='asc',$limit= null,$inRandomOrder= false){
        return $this->assetRepository->listAssets($filterConditions,$orderBy,$sortBy,$limit,$inRandomOrder);
    }
    public function addOrUpdate(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdate($condition, $attributes);
    }

    public function deleteAsset(int $id){
        return $this->assetRepository->deleteAsset($id);
    }

    public function updateStatus(array $attributes,$id){
        $data['is_active'] = $attributes['is_active'] ? '1' : '0';
        return $this->assetRepository->setCategoryStatus($data,$id);
    }

    public function findById(int $id){
        return $this->assetRepository->findById($id);
    }

    public function updateTable(array $condition, array $attributes){
        return $this->assetRepository->updateTable($condition, $attributes);
    }

    public function getUniqueVendor(int $id = null){
        return $this->assetRepository->getUniqueVendor($id);
    }
    public function getTotalAssets(string $search = null, array $filterConditions = []){
        return $this->assetRepository->getTotalAssets($search, $filterConditions);
    }
    public function findAssets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findAssets($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getAssetsByCatyegoryId(int $categoryId = null, array $filterConditions = [], $limit= null, $offset=null, string $orderBy = 'id', string $sortBy = 'desc', $inRandomOrder=false){
        return $this->assetRepository->getAssetsByCatyegoryId($categoryId, $filterConditions, $limit, $offset, $orderBy, $sortBy, $inRandomOrder);
    }
    public function getTotalRequisitions(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalRequisitions($filterConditions, $search);
    }
    public function findRequisitions(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findRequisitions($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateRequisition(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRequisition($condition, $attributes);
    }
    public function deleteRequisition(int $id){
        return $this->assetRepository->deleteRequisition($id);
    }
    public function findRequisitionById(int $id){
        return $this->assetRepository->findRequisitionById($id);
    }
    public function updateRequisitionStatus(array $attributes,$id){
        return $this->assetRepository->updateRequisitionStatus($attributes,$id);
    }


    public function getTotalRequisitionItems(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalRequisitionItems($filterConditions, $search);
    }
    public function findRequisitionItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findRequisitionItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateRequisitionItem(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRequisitionItem($condition, $attributes);
    }
    public function deleteRequisitionItem(int $id){
        return $this->assetRepository->deleteRequisitionItem($id);
    }
    public function findRequisitionItemById(int $id){
        return $this->assetRepository->findRequisitionItemById($id);
    }

    public function getTotalBudgets(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalBudgets($filterConditions, $search);
    }
    public function findBudgets(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findBudgets($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateBudget(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateBudget($condition, $attributes);
    }
    public function deleteBudget(int $id){
        return $this->assetRepository->deleteBudget($id);
    }
    public function findBudgetById(int $id){
        return $this->assetRepository->findBudgetById($id);
    }
    public function updateBudgetStatus(array $attributes,$id){
        return $this->assetRepository->updateBudgetStatus($attributes,$id);
    }

    public function getTotalBudgetItems(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalBudgetItems($filterConditions, $search);
    }
    public function findBudgetItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findBudgetItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateBudgetItem(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateBudgetItem($condition, $attributes);
    }
    public function deleteBudgetItem(int $id){
        return $this->assetRepository->deleteBudgetItem($id);
    }
    public function findBudgetItemById(int $id){
        return $this->assetRepository->findBudgetItemById($id);
    }

    public function updateBudgetItemStatus(array $attributes,$id){
        //dd($attributes);
        return $this->assetRepository->updateBudgetItemStatus($attributes,$id);
    }


    public function addOrUpdateBudgetNote(array $condition, array $attributes){
       // dd($attributes);
        return $this->assetRepository->addOrUpdateBudgetNote($condition, $attributes);
    }


    public function findBudgetNotes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findBudgetNotes($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findBudgetNoteById(int $id){
        return $this->assetRepository->findBudgetNoteById($id);
    }
    public function deleteBudgetNote(int $id){
        return $this->assetRepository->deleteBudgetNote($id);
    }

    public function getTotalBudgetNotes(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalBudgetNotes($filterConditions, $search);
    }

    public function createOrUpdateBudgetApproval(array $attributes){
        return $this->assetRepository->createOrUpdateBudgetApproval($attributes);
    }
    public function getBudgetApprovals(array $filterConditions){
        return $this->assetRepository->getBudgetApprovals($filterConditions);
    }
    public function getPendingBudgetApprovalsByUser(int $userId){
        return $this->assetRepository->getPendingBudgetApprovalsByUser($userId);
    }

    public function getTotalBudgetDocuments(array $filterConditions, string $search = null){
        return $this->assetRepository->getTotalBudgetDocuments($filterConditions, $search);
    }
    public function findBudgetDocuments(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findBudgetDocuments($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }



    public function findBudgetItemTotalAmount(int $id){
        return $this->assetRepository->findBudgetItemTotalAmount($id);
    }

    public function createBudgetDocument(array $filterConditions, array $attributes){
        return $this->assetRepository->createBudgetDocument($filterConditions, $attributes);
    }
    public function deleteBudgetDocument(int $id){
        return $this->assetRepository->deleteBudgetDocument($id);
    }
    // public function createBudgetApproval(array $attributes){
    //     return $this->assetRepository->createBudgetApproval($attributes);
    // }
    public function checkBudgetApproval(int $budgetId, int $userId = null, int $level = null){
        return $this->assetRepository->checkBudgetApproval($budgetId, $userId, $level);
    }
    public function checkRequisitionApproval(int $budgetId, int $userId = null, int $level = null){
        return $this->assetRepository->checkRequisitionApproval($budgetId, $userId, $level);
    }
    public function addOrUpdateLocation(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateLocation($condition, $attributes);
    }

    public function getTotalLocations(string $search = null){
        return $this->assetRepository->getTotalLocations($search);
    }
    public function findLocations(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findLocations($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }

    public function deleteLocation(int $id){
        return $this->assetRepository->deleteLocation($id);
    }
    public function listLocations(array $filterConditions = [],string $orderBy='id',$sortBy='asc',$limit= null,$inRandomOrder= false){
        return $this->assetRepository->listLocations($filterConditions,$orderBy,$sortBy,$limit,$inRandomOrder);
    }

    public function getTotalBudgetVersions(array $filterConditions = [], string $search = null){
        return $this->assetRepository->getTotalBudgetVersions($filterConditions, $search);
    }
    public function findBudgetVersions(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findBudgetVersions($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addBudgetVersion(array $attributes){
        return $this->assetRepository->addBudgetVersion($attributes);
    }
    public function deleteBudgetVersion(int $id){
        return $this->assetRepository->deleteBudgetVersion($id);
    }
    public function findBudgetVersionById(int $id){
        return $this->assetRepository->findBudgetVersionById($id);
    }
    public function createRequisitionDocument(array $filterConditions, array $attributes){
        return $this->assetRepository->createRequisitionDocument($filterConditions, $attributes);
    }
    public function deleteRequisitionDocument(int $id){
        return $this->assetRepository->deleteRequisitionDocument($id);
    }
    public function createOrUpdateRequisitionApproval(array $attributes){
        return $this->assetRepository->createOrUpdateRequisitionApproval($attributes);
    }
    public function getRequisitionApprovals(array $filterConditions){
        return $this->assetRepository->getRequisitionApprovals($filterConditions);
    }
    public function getPendingRequisitionApprovalsByUser(int $userId){
        return $this->assetRepository->getPendingRequisitionApprovalsByUser($userId);
    }
    public function getTotalRequisitionVersions(array $filterConditions = [], string $search = null){
        return $this->assetRepository->getTotalRequisitionVersions($filterConditions, $search);
    }
    public function findRequisitionVersions(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findRequisitionVersions($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addRequisitionVersion(array $attributes){
        return $this->assetRepository->addRequisitionVersion($attributes);
    }
    public function deleteRequisitionVersion(int $id){
        return $this->assetRepository->deleteRequisitionVersion($id);
    }
    public function findRequisitionVersionById(int $id){
        return $this->assetRepository->findRequisitionVersionById($id);
    }


    public function addOrUpdateRfq(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRfq($condition, $attributes);
    }

    public function createBudgetVersion($budget){
        $versionData = $budget->toArray();
        unset($versionData['id'], $versionData['uuid'], $versionData['created_at'], $versionData['updated_at'], $versionData['deleted_at']);
        $versionVal = (float) trim(str_replace('V.', '', $versionData['version']));
        $versionData['budget_id'] = $budget->id;
        $versionData['budget_items'] = $budget->items->toArray();
        $versionData['budget_notes'] = $budget->notes->toArray();
        $versionData['budget_documents'] = $budget->document->toArray();
        $versionData['budget_approvals'] = $budget->approvals->toArray();
        // dd($budget->approvals->toArray());
        $isUpdated = $this->addBudgetVersion($versionData);
        $isStatusUpdated = $this->updateBudgetStatus(['version' => 'V.' . ($versionVal + 0.1), 'status' => 0, 'updated_at' => now()], $budget->id);
        if($isUpdated && $isStatusUpdated){
            $budget->approvals()->delete();
            return true;
        }
        return false;
    }
    public function createRequisitionVersion($requisition){
        $versionData = $requisition->toArray();
        unset($versionData['id'], $versionData['uuid'], $versionData['created_at'], $versionData['updated_at'], $versionData['deleted_at']);
        $versionVal = (float) trim(str_replace('V.', '', $versionData['version']));
        $versionData['requisition_id'] = $requisition->id;
        $versionData['requisition_items'] = $requisition->items->toArray();
        // $versionData['requisition_notes'] = $requisition->notes->toArray();
        $versionData['requisition_documents'] = $requisition->document->toArray();
        $versionData['requisition_approvals'] = $requisition->approvals->toArray();
        // dd($requisition->approvals->toArray());
        $isUpdated = $this->addRequisitionVersion($versionData);
        $isStatusUpdated = $this->updateRequisitionStatus(['version' => 'V.' . ($versionVal + 0.1), 'status' => 0, 'updated_at' => now()], $requisition->id);
        if($isUpdated && $isStatusUpdated){
            $requisition->approvals()->delete();
            return true;
        }
        return false;
    }

    public function findRfqById(int $id){
        return $this->assetRepository->findRfqById($id);
    }
    public function findRfqs(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findRfqs($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }


    public function getTotalRfqs(array $filterConditions = [], string $search = null){
        return $this->assetRepository->getTotalRfqs($filterConditions, $search);
    }


    public function addOrUpdateRfqVendor(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRfqVendor($condition, $attributes);
    }
    public function addOrUpdateRfqItems(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRfqItems($condition, $attributes);
    }

    public function findItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }


    public function deleteRfq(int $id){
        return $this->assetRepository->deleteRfq($id);
    }

    public function getAllRfqItems($filterConditions,string $orderBy = 'id', $sortBy = 'asc')
    {
        return $this->assetRepository->getAllRfqItems($filterConditions,$orderBy,$sortBy);
    }
    public function findQuotationById(int $id){
        return $this->assetRepository->findQuotationById($id);
    }
    public function addOrUpdateQuotation(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateQuotation($condition, $attributes);
    }
    public function updateQuotation(array $attributes, $id){
        return $this->assetRepository->updateQuotation($attributes, $id);
    }
    public function addOrUpdateQuotationItems(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateQuotationItems($condition, $attributes);
    }

    public function getAllQuotations($filterConditions,string $orderBy = 'id', $sortBy = 'desc')
    {
        return $this->assetRepository->getAllQuotations($filterConditions,$orderBy,$sortBy);
    }
    public function getAllQuotationItems($filterConditions,string $orderBy = 'id', $sortBy = 'asc')
    {
        return $this->assetRepository->getAllQuotationItems($filterConditions,$orderBy,$sortBy);
    }

    public function listQuotations(array $filterConditions = [],string $orderBy='id',$sortBy='asc',$limit= null,$offset=null,$inRandomOrder= false, $search=null){
        return $this->assetRepository->listQuotations($filterConditions,$orderBy,$sortBy,$limit,$offset,$inRandomOrder,$search);
    }
    public function getTotalQuotations(array $filterConditions = [], string $search = null){
        return $this->assetRepository->getTotalQuotations($filterConditions, $search);
    }

    public function getTotalPurchaseOrders(string $search = null){
        return $this->assetRepository->getTotalPurchaseOrders($search);
    }
    public function findPurchaseOrders(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findPurchaseOrders($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdatePurchaseOrder(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdatePurchaseOrder($condition, $attributes);
    }
    public function deletePurchaseOrder(int $id){
        return $this->assetRepository->deletePurchaseOrder($id);
    }
    public function findPurchaseOrderById(int $id){
        return $this->assetRepository->findPurchaseOrderById($id);
    }
    public function updatePurchaseOrderStatus(array $attributes,$id){
        return $this->assetRepository->updatePurchaseOrderStatus($attributes,$id);
    }
    public function addOrUpdatePurchaseOrderItems(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdatePurchaseOrderItems($condition, $attributes);
    }
    public function deleteTermAndCondition(int $id){
        return $this->assetRepository->deleteTermAndCondition($id);
    }
    public function findTermAndConditions(array $filterConditions, string $orderBy = 'order', string $sortBy = 'asc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findTermAndConditions($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getTotalTermAndConditions(string $search = null){
        return $this->assetRepository->getTotalTermAndConditions($search);
    }
    public function updateTermAndConditions(array $attributes, $id){
        return $this->assetRepository->updateTermAndConditions($attributes, $id);
    }

    public function updateLocationStatus(array $attributes,$id){
        $data['is_active'] = $attributes['is_active'] ? '1' : '0';
        return $this->assetRepository->setLocationStatus($data,$id);
    }
    public function updateTncStatus(array $attributes,$id){
        $data['is_active'] = $attributes['is_active'] ? '1' : '0';
        return $this->assetRepository->setTncStatus($data,$id);
    }
    public function checkPurchaseOrderApproval(int $poId, int $userId = null, int $level = null){
        return $this->assetRepository->checkPurchaseOrderApproval($poId, $userId, $level);
    }
    public function createOrUpdatePoApproval(array $attributes){
        return $this->assetRepository->createOrUpdatePoApproval($attributes);
    }

    public function checkPoApproval(int $budgetId, int $userId = null, int $level = null){
        return $this->assetRepository->checkPoApproval($budgetId, $userId, $level);
    }
    public function updatePoStatus(array $attributes,$id){
        return $this->assetRepository->updatePoStatus($attributes,$id);
    }

    public function findPoId(int $id){
        return $this->assetRepository->findPoId($id);
    }
    public function findPoItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findPoItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function deletePo(int $id){
        return $this->assetRepository->deletePo($id);
    }

    public function getPoApprovals(array $filterConditions){
        return $this->assetRepository->getPoApprovals($filterConditions);
    }
    public function getPendingPoApprovalsByUser(int $userId){
        return $this->assetRepository->getPendingPoApprovalsByUser($userId);
    }
    public function addOrUpdatePaymentSchedules(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdatePaymentSchedules($condition, $attributes);
    }
    public function listPaymentSchedules(array $filterConditions = [],string $orderBy='id',$sortBy='asc',$limit= null,$inRandomOrder= false){
        return $this->assetRepository->listPaymentSchedules($filterConditions,$orderBy,$sortBy,$limit,$inRandomOrder);
    }
    public function findPsItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findPsItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }

    public function addOrUpdateAssetReceiptNote(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateAssetReceiptNote($condition, $attributes);
    }
    public function addOrUpdateAssetReceiptNoteItems(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateAssetReceiptNoteItems($condition, $attributes);
    }
    public function getTotalAssetReceiptNotes(string $search = null){
        return $this->assetRepository->getTotalAssetReceiptNotes($search);
    }

    public function findAssetReceiptNotes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findAssetReceiptNotes($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findAssetReceiptNoteById(int $id){
        return $this->assetRepository->findAssetReceiptNoteById($id);
    }
    public function findAssetReceiptNoteItemById(int $id){
        return $this->assetRepository->findAssetReceiptNoteItemById($id);
    }
    public function findAssetReceiptNoteItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findAssetReceiptNoteItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function alterArnItemRemainingQuantity(array $condition, int $quantity, string $type){
        return $this->assetRepository->alterArnItemRemainingQuantity($condition, $quantity, $type);
    }
    public function getAllAssetReceiptNoteItems($filterConditions,string $orderBy = 'id', $sortBy = 'asc')
    {
        return $this->assetRepository->getAllAssetReceiptNoteItems($filterConditions,$orderBy,$sortBy);
    }
    public function deleteAssetReceiptNote(int $id){
        return $this->assetRepository->deleteAssetReceiptNote($id);
    }

    public function createOrUpdateRfqApproval(array $attributes){
        return $this->assetRepository->createOrUpdateRfqApproval($attributes);
    }
    public function checkRfqApproval(int $requestId, int $userId = null, int $level = null, $status = null){
        return $this->assetRepository->checkRfqApproval($requestId, $userId, $level, $status);
    }
    public function checkRfqApprovalByLatestOrder(int $requestId, int $userId = null, int $level = null, $status = null){
        return $this->assetRepository->checkRfqApprovalByLatestOrder($requestId, $userId, $level, $status);
    }
    public function findLocationById(int $id){
        return $this->assetRepository->findLocationById($id);
    }
    public function getAssetStock($filterConditions,string $orderBy = 'id', $sortBy = 'asc', $inRandomOrder = false)
    {
        return $this->assetRepository->getAssetStock($filterConditions, $orderBy, $sortBy, $inRandomOrder);
    }
    public function addOrUpdateAssetStock(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateAssetStock($condition, $attributes);
    }
    public function addOrUpdateInventory(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateInventory($condition, $attributes);
    }


    public function getInventories($filterConditions,string $orderBy = 'id', $sortBy = 'asc', $inRandomOrder = false)
    {
        return $this->assetRepository->getInventories($filterConditions, $orderBy, $sortBy, $inRandomOrder);
    }

    public function getTotalInvoices(string $search = null){
        return $this->assetRepository->getTotalInvoices($search);
    }
    public function findInvoices(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findInvoices($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateInvoice(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateInvoice($condition, $attributes);
    }
    public function deleteInvoice(int $id){
        return $this->assetRepository->deleteInvoice($id);
    }
    public function findInvoiceById(int $id){
        return $this->assetRepository->findInvoiceById($id);
    }
    public function updateInvoiceStatus(array $attributes,$id){
        return $this->assetRepository->updateInvoiceStatus($attributes,$id);
    }
    public function createOrUpdateInvoiceApproval(array $attributes){
        return $this->assetRepository->createOrUpdateInvoiceApproval($attributes);
    }

    public function findInventoryById(int $id){
        return $this->assetRepository->findInventoryById($id);
    }
    public function findAssetStockById(int $id){
        return $this->assetRepository->findAssetStockById($id);
    }
    public function findInventoryByCondition(array $filterConditions){
        return $this->assetRepository->findInventoryByCondition($filterConditions);
    }
    public function findAssetByCondition(array $filterConditions){
        return $this->assetRepository->findAssetByCondition($filterConditions);
    }
    public function checkPoInvoiceApproval(int $poInvoiceId, int $userId = null, int $level = null){
        return $this->assetRepository->checkPoInvoiceApproval($poInvoiceId, $userId, $level);
    }
    public function getPoInvoiceApprovals(array $filterConditions){
        return $this->assetRepository->getPoInvoiceApprovals($filterConditions);

    }
    public function getPendingPoInvoiceApprovalsByUser(int $userId){
        return $this->assetRepository->getPendingPoInvoiceApprovalsByUser($userId);
    }
    public function addOrUpdateTicket(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateTicket($condition, $attributes);
    }
    public function listDepartments(array $filterConditions,string $orderBy='id',$sortBy='asc',$limit= null, array $search = null){
        return $this->assetRepository->listDepartments($filterConditions,$orderBy,$sortBy,$limit, $search);
    }
    public function findDepartmentById($id){
        return $this->assetRepository->findDepartmentById($id);
    }
    public function createOrUpdateDepartment(array $attributes,$id= null){
        if(is_null($id)){
            return $this->assetRepository->createDepartment($attributes);
        }else{
            return $this->assetRepository->updateDepartment($attributes,$id);
        }
    }
    public function createOrUpdateSla(array $attributes,$id= null){

            return $this->assetRepository->createOrUpdateSla($attributes,$id);
    }
    public function deleteDepartment(int $id){
        return $this->assetRepository->deleteDepartment($id);
    }
    public function updateDepartmentStatus(array $attributes,$id){
        return $this->assetRepository->setDepartmentStatus($attributes,$id);
    }
    public function findTicketRaisedByMe(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findTicketRaisedByMe($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function deleteInventory(int $id){
        return $this->assetRepository->deleteInventory($id);
    }
    public function findLeasedAgreements(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findLeasedAgreements($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findAssetMaintenances(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findAssetMaintenances($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateRecentActivity(array $condition, array $attributes){
        return $this->assetRepository->addOrUpdateRecentActivity($condition, $attributes);
    }
    public function findRecentActivities(array $filterConditions, array $type=null, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findRecentActivities($filterConditions,$type, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getRelatedBudgets(array $requisitionItems){
        return $this->assetRepository->getRelatedBudgets($requisitionItems);
    }
    public function getItemsNotInBudget(array $requisitionItems){
        return $this->assetRepository->getItemsNotInBudget($requisitionItems);
    }
    public function findDepartmentByName($name){
        return $this->assetRepository->findDepartmentByName($name);
    }
    public function getPendingRfqApprovalsByUser(int $userId){
        return $this->assetRepository->getPendingRfqApprovalsByUser($userId);
    }
    public function getTotalSearchedAssets(string $search = null, array $filterConditions = []){
        return $this->assetRepository->getTotalSearchedAssets($search, $filterConditions);
    }
    public function findSearchedAssets(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->findSearchedAssets($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getRfqApprovals(array $filterConditions){
        return $this->assetRepository->getRfqApprovals($filterConditions);
    }
    public function getAttributes(array $filterConditions, string $orderBy = 'order', string $sortBy = 'asc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetRepository->getAttributes($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdateAttribute(array $attributes, $id = null){
        if(!$id){
            return $this->assetRepository->addAttribute($attributes);
        }else{
            return $this->assetRepository->updateAttribute($attributes, $id);
        }
    }
    public function deleteAttribute(int $id){
        return $this->assetRepository->deleteAttribute($id);
    }
    public function findSlaTimeByDepartmentId($id){
        return $this->assetRepository->findSlaTimeByDepartmentId($id);
    }


    public function createInvoiceApproval(array $attributes){
        return $this->assetRepository->createInvoiceApproval($attributes);
    }

    public function checkPoInvoiceApprovalLatestOrder(int $poInvoiceId, int $userId = null, int $level = null){
        return $this->assetRepository->checkPoInvoiceApprovalLatestOrder($poInvoiceId, $userId, $level);
    }
    public function createOrUpdateInvoiceApprovalLatestOrder(array $attributes){
        return $this->assetRepository->createOrUpdateInvoiceApprovalLatestOrder($attributes);
    }
    public function addInvoiceVersion(array $attributes){
        return $this->assetRepository->addInvoiceVersion($attributes);
    }

    public function createInvoiceVersion($invoiceData,$currentData){

        // dd($invoiceData,$invoiceData->items);
        $versionData = $invoiceData->toArray();
        unset($versionData['id'], $versionData['uuid'], $versionData['created_at'], $versionData['updated_at'], $versionData['deleted_at']);
        // $versionVal = (float) trim(str_replace('V.', '', $versionData['version']));
        $versionVal = (float) trim(str_replace('V.', '', '1.0'));
        $versionData['po_invoice_id'] = $invoiceData->id;
        $versionData['version'] = '1.0';
        $versionData['purchase_order_items'] = null;
        $versionData['invoice_items'] = null;
        $versionData['invoice_documents'] = null;
        $versionData['invoice_approvals'] = null;

        // dd($versionData);
        $isUpdated = $this->addInvoiceVersion($versionData);
        // dd($isUpdated);
        //$isStatusUpdated = $this->updateBudgetStatus(['version' => 'V.' . ($versionVal + 0.1), 'status' => 0, 'updated_at' => now()], $invoiceData->id);
        $isStatusUpdated = $this->updateInvoiceStatus(['status' => 0, 'updated_at' => now()], $invoiceData->id);

        // dd($isUpdated,$isStatusUpdated);

        // dd($invoiceData->approvals());

        $isApprovalUpdated= $this->createOrUpdateInvoiceApproval($currentData);
        if($isUpdated && $isStatusUpdated){

            $invoiceData->approvals()->delete();
            return true;
        }
        return false;
    }

    public function createOrUpdateEntityDepartmentSettings(array $attributes, $condition = []){
        if(!$condition){
            return $this->assetRepository->createEntityDepartmentSettings($attributes);
        }else{
            return $this->assetRepository->updateEntityDepartmentSettings($attributes, $condition);
        }
    }
    public function createOrUpdateTicketSettings(array $attributes, $condition = []){
        if(!$condition){
            return $this->assetRepository->createTicketSettings($attributes);
        }else{
            return $this->assetRepository->updateTicketSettings($attributes, $condition);
        }
    }
}
