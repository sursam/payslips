<?php

namespace App\Services\Asset;

use App\Repositories\Asset\AssetTypeRepository;

class AssetTypeService
{
    protected $assetTypeRepository;
    public function __construct(AssetTypeRepository $assetTypeRepository){
        $this->assetTypeRepository = $assetTypeRepository;
    }
    public function listAssets(array $filterConditions,string $orderBy='id',$sortBy='asc',$limit= null,$inRandomOrder= false){
        return $this->assetTypeRepository->listAssets($filterConditions,$orderBy,$sortBy,$limit,$inRandomOrder);
    }
    public function findAssetTypes(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetTypeRepository->findAssetTypes($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdate(array $condition, array $data){
        return $this->assetTypeRepository->addOrUpdate($condition, $data);
    }

    public function deleteType(int $id){
        return $this->assetTypeRepository->deleteType($id);
    }

    public function updateStatus(array $attributes,$id){
        $data['is_active'] = $attributes['is_active'] ? '1' : '0';
        return $this->assetTypeRepository->setCategoryStatus($data,$id);
    }

    public function findById(int $id){
        return $this->assetTypeRepository->findById($id);
    }

    public function updateTable(array $condition, array $attributes){
        return $this->assetTypeRepository->updateTable($condition, $attributes);
    }

    public function findAssetTypeByCategoryId(int $id){
        return $this->assetTypeRepository->findAssetTypeByCategoryId($id);
    }
}
