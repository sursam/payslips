<?php

namespace App\Services\Role;

use App\Contracts\Role\RolePermissionContract;

class RolePermissionService
{

    /**
     * class InviteService constructor
     */
    public function __construct(protected RolePermissionContract $rolePermissionRepository)
    {
        $this->rolePermissionRepository = $rolePermissionRepository;

    }

    public function findRoleById($id){
        return $this->rolePermissionRepository->findById($id);
    }
    public function findRoleBySlug($slug){
        return $this->rolePermissionRepository->findRoleBySlug($slug);
    }

    public function getList($start = null, $limit = null, $order = 'id', $dir = 'asc', $search = null)
    {
        return $this->rolePermissionRepository->getList($start, $limit, $order, $dir, $search);
    }
    public function getAllRoles($filterConditions,string $orderBy = 'id', $sortBy = 'asc')
    {
        return $this->rolePermissionRepository->getAllRoles($filterConditions,$orderBy,$sortBy);
    }

    public function getTotalData($search=null)
    {
        return $this->rolePermissionRepository->getTotalData($search);
    }

    public function getPermissionList($start, $limit, $order, $dir, $search=null)
    {
        return $this->rolePermissionRepository->getPermissionList($start, $limit, $order, $dir, $search);
    }

    public function getTotalPermissionData($search=null)
    {
        return $this->rolePermissionRepository->getTotalPermissionData($search);
    }

    public function getAllPermissions( string $type = ''){
        return $this->rolePermissionRepository->getAllPermissions($type);
    }

    public function addRole(array $attributes)
    {
        return $this->rolePermissionRepository->create($attributes);
    }
    public function updateRole(array $attributes, $id)
    {
        return $this->rolePermissionRepository->update($attributes, $id);
    }
    public function deleteRole(int $id){
        return $this->rolePermissionRepository->deleteRole($id);
    }

    public function addPermission(array $attributes)
    {
        return $this->rolePermissionRepository->createPermission($attributes);
    }


    public function listModules(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->rolePermissionRepository->listModules($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findModuleById(int $id){
        return $this->rolePermissionRepository->findModuleById($id);
    }
    public function addOrUpdateModule(array $condition, array $attributes){
        return $this->rolePermissionRepository->addOrUpdateModule($condition, $attributes);
    }
    public function deleteModule(int $id){
        return $this->rolePermissionRepository->deleteModule($id);
    }
    public function addOrUpdatePermissions(array $condition, array $attributes){
        return $this->rolePermissionRepository->addOrUpdatePermissions($condition, $attributes);
    }
    public function listPermissions(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->rolePermissionRepository->listPermissions($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
}
