<?php

namespace App\Services\User;

use App\Contracts\Users\VendorContract;

class VendorService
{
    protected $vendorRepository;
    public function __construct(VendorContract $vendorRepository)
    {
        $this->vendorRepository  = $vendorRepository;
    }
    public function createVendor(array $attributes){
        return $this->vendorRepository->createVendor($attributes);
    }
    public function updateVendor(array $attributes,int $id){
        return $this->vendorRepository->updateVendor($attributes, $id);
    }
    public function getTotalUsers(string $sreach = null){
        return $this->vendorRepository->getTotalUsers($sreach);
    }
    public function findUserByRole(array $filterConditions,string $role='vendor',string $orderBy = 'id', string $sortBy = 'asc',$limit= null,$offset=null,$inRandomOrder=false,$search=null){
        return $this->vendorRepository->findUserByRole($filterConditions,$role,$orderBy,$sortBy,$limit,$offset,$inRandomOrder,$search);
    }
    public function getAllUsers($filterConditions,$role = 'vendor',string $orderBy = 'id', $sortBy = 'asc'){
        return $this->vendorRepository->getAllUsers($filterConditions,$role,$orderBy,$sortBy);
    }
    public function deleteVendor(int $id){
        return $this->vendorRepository->deleteVendor($id);
    }
    public function findUserById(int $id){
        return $this->vendorRepository->findUserById($id);
    }
    public function updateVendorStatus(array $attributes, int $id){
        return $this->vendorRepository->updateVendorStatus($attributes, $id);
    }
    public function findUserByLocation(string $sreach = null, string $orderBy = 'id', $sortBy = 'asc', $inRandomOrder = false){
        return $this->vendorRepository->findUserByLocation($sreach, $orderBy, $sortBy, $inRandomOrder);
    }
    public function findVendorsExceptIds(array $vendorIds){
        return $this->vendorRepository->findVendorsExceptIds($vendorIds);
    }
}
