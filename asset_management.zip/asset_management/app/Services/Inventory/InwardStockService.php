<?php

namespace App\Services\Inventory;

use App\Repositories\Inventory\InwardStockRepository;

class InwardStockService
{
    protected $inwardStockRepository;
    public function __construct(InwardStockRepository $inwardStockRepository){
        $this->inwardStockRepository = $inwardStockRepository;
    }
    public function listInWardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){
        return $this->inwardStockRepository->listInWardStocks($filterConditions, $order, $sort, $limit, $inRandomOrder);
    }
    public function deleteInWardStock(int $id){
        return $this->inwardStockRepository->deleteInWardStock($id);
    }
    public function findById(int $id){
        return $this->inwardStockRepository->findById($id);
    }
    public function updateTable(array $condition, array $attributes){
        return $this->inwardStockRepository->updateTable($condition, $attributes);
    }
    public function getTotalInWardStock(array $search = null){
        return $this->inwardStockRepository->getTotalInWardStock($search);
    }
    public function findInWardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->inwardStockRepository->findInWardStock($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function create(array $attributes){
        return $this->inwardStockRepository->create($attributes);
    }
    public function updateStatus(array $attributes, int $id){
        return $this->inwardStockRepository->updateStatus($attributes, $id);
    }
}

