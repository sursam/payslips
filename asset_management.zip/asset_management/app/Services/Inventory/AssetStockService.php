<?php

namespace App\Services\Inventory;

use App\Repositories\Inventory\AssetStockRepository;

class AssetStockService
{
    protected $assetStockRepository;
    public function __construct(AssetStockRepository $assetStockRepository){
        $this->assetStockRepository = $assetStockRepository;
    }
    public function listAssetStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){
        return $this->assetStockRepository->listAssetStocks($filterConditions, $order, $sort, $limit, $inRandomOrder);
    }
    public function deleteAssetStock(int $id){
        return $this->assetStockRepository->deleteAssetStock($id);
    }
    public function findById(int $id){
        return $this->assetStockRepository->findById($id);
    }
    public function updateTable(array $condition, array $attributes){
        return $this->assetStockRepository->updateTable($condition, $attributes);
    }
    public function getTotalAssetStock(array $filterConditions, $search = null){
        return $this->assetStockRepository->getTotalAssetStock($filterConditions, $search);
    }
    public function findAssetStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findAssetStock($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function create(array $attributes){
        return $this->assetStockRepository->create($attributes);
    }
    public function updateStatus(array $attributes, int $id){
        return $this->assetStockRepository->updateStatus($attributes, $id);
    }
    public function findInventories(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findInventories($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getRenewalListByDays(int $days, array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->getRenewalListByDays($days, $filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function alterStockTable(array $condition, int $stock, string $type){
        return $this->assetStockRepository->alterStockTable($condition, $stock, $type);
    }
    public function listAssetIssues(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){
        return $this->assetStockRepository->listAssetIssues($filterConditions, $order, $sort, $limit, $inRandomOrder);
    }
    public function getUsedAssets(array $filterConditions,string $order = 'id', string $sort = 'asc', $limit= null, $inRandomOrder= false){
        return $this->assetStockRepository->getUsedAssets($filterConditions, $order, $sort, $limit, $inRandomOrder);
    }
    public function addOrUpdateAssetIssue(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateAssetIssue($condition, $attributes);
    }
    public function findAssetIssueById(int $id){
        return $this->assetStockRepository->findAssetIssueById($id);
    }
    public function getAssetIssueByCondition(array $filterConditions){
        return $this->assetStockRepository->getAssetIssueByCondition($filterConditions);
    }
    public function addAssetStockLog(array $attributes){
        return $this->assetStockRepository->addAssetStockLog($attributes);
    }
    public function getAssetStockByCondition(array $filterConditions){
        return $this->assetStockRepository->getAssetStockByCondition($filterConditions);
    }
    public function findAvailableItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findAvailableItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findInStockItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findInStockItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findInventoryItems(array $inventoryIds){
        return $this->assetStockRepository->findInventoryItems($inventoryIds);
    }
    public function addOrUpdateLease(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateLease($condition, $attributes);
    }
    public function addOrUpdateLeaseItems(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateLeaseItems($condition, $attributes);
    }
    public function findLeasedItemById(int $id){
        return $this->assetStockRepository->findLeasedItemById($id);
    }
    public function addOrUpdateMaintenance(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateMaintenance($condition, $attributes);
    }
    public function updateMaintenanceStatus(array $attributes, int $id){
        return $this->assetStockRepository->updateMaintenanceStatus($attributes, $id);
    }
    public function findMaintenanceById(int $id){
        return $this->assetStockRepository->findMaintenanceById($id);
    }
    public function addOrUpdateMaintenanceItems(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateMaintenanceItems($condition, $attributes);
    }
    public function updateMaintenanceItemStatus(array $attributes, int $id){
        return $this->assetStockRepository->updateMaintenanceItemStatus($attributes, $id);
    }
    public function findMaintenanceItemById(int $id){
        return $this->assetStockRepository->findMaintenanceItemById($id);
    }
    public function getTotalMaintenances(string $search = null){
        return $this->assetStockRepository->getTotalMaintenances($search);
    }
    public function findMaintenances(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findMaintenances($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findMaintenanceItemsByStockId(int $stockId, array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findMaintenanceItemsByStockId($stockId, $filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function getTotalLeases(string $search = null, string $type = ''){
        return $this->assetStockRepository->getTotalLeases($search,$type);
    }
    public function findLeases(array $filterConditions, string $type='', string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        
        
    //    dd($type);


        return $this->assetStockRepository->findLeases($filterConditions,$type, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }

    public function findLeaseAgreementById(int $id){
        return $this->assetStockRepository->findLeaseAgreementById($id);
    }
    public function addOrUpdateAssetSurrender(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateAssetSurrender($condition, $attributes);
    }
    public function getTotalVerificationLists(array $filterConditions = [], $search = null){
        return $this->assetStockRepository->getTotalVerificationLists($filterConditions, $search);
    }
    public function findVerificationLists(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findVerificationLists($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function addOrUpdatePhysicalVerification(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdatePhysicalVerification($condition, $attributes);
    }
    public function findVerificationById(int $id){
        return $this->assetStockRepository->findVerificationById($id);
    }
    public function getInventoryByIdentificationNo(string $identificationNo){
        return $this->assetStockRepository->getInventoryByIdentificationNo($identificationNo);
    }
    public function getInventoryById(int $id){
        return $this->assetStockRepository->getInventoryById($id);
    }
    public function findInventoriesByIds(array $ids){
        return $this->assetStockRepository->findInventoriesByIds($ids);
    }
    public function deleteAssetVerifications(int $id){
        return $this->assetStockRepository->deleteAssetVerifications($id);
    }
    public function addOrUpdateVerifiedAsset(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateVerifiedAsset($condition, $attributes);
    }
    public function deleteVerifiedAsset(int $id){
        return $this->assetStockRepository->deleteVerifiedAsset($id);
    }
    public function findVerifiedAssetById(int $id){
        return $this->assetStockRepository->findVerifiedAssetById($id);
    }
    public function addOrUpdateInventory(array $condition, array $attributes){
        return $this->assetStockRepository->addOrUpdateInventory($condition, $attributes);
    }
    public function getExpiringLeases(int $day){
        return $this->assetStockRepository->getExpiringLeases($day);
    }
    public function getExpiringTickets(){
        return $this->assetStockRepository->getExpiringTickets();
    }
    public function findNewList(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->assetStockRepository->findNewList($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }

    // public function findLeasedItems(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
    //     return $this->assetStockRepository->findLeasedItems($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    // }
}
