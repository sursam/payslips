<?php

namespace App\Services\Inventory;
use App\Repositories\Inventory\OutwardStockRepository;

class OutwardStockService
{
    protected $outwardStockRepository;
    public function __construct(OutwardStockRepository $outwardStockRepository){
        $this->outwardStockRepository = $outwardStockRepository;
    }
    public function listOutWardStocks(array $filterConditions,string $order = 'id', string $sort = 'desc', $limit= null,$inRandomOrder= false){
        return $this->outwardStockRepository->listOutWardStocks($filterConditions, $order, $sort, $limit, $inRandomOrder);
    }
    public function deleteOutWardStock(int $id){
        return $this->outwardStockRepository->deleteOutWardStock($id);
    }
    public function findById(int $id){
        return $this->outwardStockRepository->findById($id);
    }
    public function updateTable(array $condition, array $attributes){
        return $this->outwardStockRepository->updateTable($condition, $attributes);
    }
    public function getTotalOutWardStock(array $search = null){
        return $this->outwardStockRepository->getTotalOutWardStock($search);
    }
    public function findOutWardStock(array $filterConditions, string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->outwardStockRepository->findOutWardStock($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function create(array $attributes){
        return $this->outwardStockRepository->create($attributes);
    }
    public function updateStatus(array $attributes, int $id){
        return $this->outwardStockRepository->updateStatus($attributes, $id);
    }
}
