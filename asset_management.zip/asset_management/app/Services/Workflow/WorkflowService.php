<?php

namespace App\Services\Workflow;

use App\Repositories\Workflow\WorkflowRepository;

class WorkflowService
{
    protected $workflowRepository;
    public function __construct(WorkflowRepository $workflowRepository){
        $this->workflowRepository = $workflowRepository;
    }
    public function listWorkflows(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->workflowRepository->listWorkflows($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function findWorkflowById(int $id){
        return $this->workflowRepository->findWorkflowById($id);
    }
    public function addOrUpdateWorkflow(array $condition, array $attributes){
        return $this->workflowRepository->addOrUpdateWorkflow($condition, $attributes);
    }
    public function deleteWorkflow(int $id){
        return $this->workflowRepository->deleteWorkflow($id);
    }
}
