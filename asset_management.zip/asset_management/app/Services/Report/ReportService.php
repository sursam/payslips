<?php

namespace App\Services\Report;

use App\Repositories\Report\ReportRepository;

class ReportService
{
    protected $reportRepository;
    public function __construct(ReportRepository $reportRepository){
        $this->reportRepository = $reportRepository;
    }
    public function addOrUpdateSettings(array $condition, array $attributes){
        return $this->reportRepository->addOrUpdateSettings($condition, $attributes);
    }
    public function getDepreciationSettings(array $filterConditions){
        return $this->reportRepository->getDepreciationSettings($filterConditions);
    }
}
