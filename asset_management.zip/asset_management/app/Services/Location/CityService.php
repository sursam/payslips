<?php

namespace App\Services\Location;

use App\Contracts\Location\CityContract;

class CityService
{
    protected $cityRepository;
    public function __construct(CityContract $cityRepository)
    {
        $this->cityRepository = $cityRepository;
    }
    public function getCityByState(int $stateid){
        return $this->cityRepository->getCityByState($stateid);
    }
}
