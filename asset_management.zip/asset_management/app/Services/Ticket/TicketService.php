<?php

namespace App\Services\Ticket;

use App\Repositories\Ticket\TicketRepository;

class TicketService
{
    protected $ticketRepository;
    public function __construct(TicketRepository $ticketRepository){
        $this->ticketRepository = $ticketRepository;
    }
    public function listTickets(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->ticketRepository->listTickets($filterConditions, $type, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function listTicketsForDashboard(array $filterConditions = [], string $type = '', string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false, $search=null){
        return $this->ticketRepository->listTicketsForDashboard($filterConditions, $type, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function listTicketsWithActivities(array $filterConditions = []){
        return $this->ticketRepository->listTicketsWithActivities($filterConditions);
    }
    public function findTicketById(int $id){
        return $this->ticketRepository->findTicketById($id);
    }
    public function addOrUpdateTicket(array $condition, array $attributes){
        return $this->ticketRepository->addOrUpdateTicket($condition, $attributes);
    }
    public function deleteTicket(int $id){
        return $this->ticketRepository->deleteTicket($id);
    }
    public function addTicketActivity(array $attributes){
        return $this->ticketRepository->addTicketActivity($attributes);
    }
    public function updateTicketActivity(array $attributes, int $id){
        return $this->ticketRepository->updateTicketActivity($attributes, $id);
    }
    public function addCcToUser(array $attributes){
        return $this->ticketRepository->addCcToUser($attributes);
    }
    public function listTicketActivities(array $filterConditions = [], string $orderBy = 'id', string $sortBy = 'desc', $limit= null, $offset=null, $inRandomOrder=false){
        return $this->ticketRepository->listTicketActivities($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder);
    }
    public function listTicketCategories(array $filterConditions = [], string $orderBy = 'id', $sortBy = 'asc', $limit = null, $offset = null, $inRandomOrder = false, $search = null){
        return $this->ticketRepository->listTicketCategories($filterConditions, $orderBy, $sortBy, $limit, $offset, $inRandomOrder, $search);
    }
    public function deleteTicketCategory(int $id){
        return $this->ticketRepository->deleteTicketCategory($id);
    }
    public function addOrUpdateTicketCategory(array $condition, array $attributes){
        return $this->ticketRepository->addOrUpdateTicketCategory($condition, $attributes);
    }
    public function updateTicketCategoryStatus(array $attributes,$id){
        $data['is_active'] = $attributes['is_active'] ? '1' : '0';
        return $this->ticketRepository->updateTicketCategoryStatus($data,$id);
    }
    public function findTicketCategoryById(int $id){
        return $this->ticketRepository->findTicketCategoryById($id);
    }
    public function deleteTicketSettings(int $id){
        return $this->ticketRepository->deleteTicketSettings($id);
    }
}
