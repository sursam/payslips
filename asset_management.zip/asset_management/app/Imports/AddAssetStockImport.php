<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Http\Controllers\BaseController;
use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Receipt\AssetReceiptNoteItem;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class AddAssetStockImport implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas
{
    use UploadAble;

    protected $request;

    protected $assetService;
    protected $rowCount = 0;
    protected $initialStock = 0;
    protected $assetStockUuid;
    public function __construct(Request $request, AssetService $assetService, AssetTypeService $assetTypeService)
    {
        $this->request = $request;
        $this->assetService = $assetService;
        $this->assetTypeService = $assetTypeService;
        // $category = Category::where('name', $sheetName)->first();
        // dd($request);
        // $this->entityId = $category ? $category->id : null;
        $assetLocationStock = $this->assetService->getAssetStock([
            'asset_id' => $this->request->asset_id,
            'location_id' =>  $this->request->location_id,
            'entity_id' => $this->request->entity_id
        ]);
        $this->initialStock = $assetLocationStock?->current_stock ?? 0;
    }

    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */




    public function onRow(Row $row)
    {

        // self::$rowCount++;


        $row = $row->toArray();
        $arnItemData = AssetReceiptNoteItem::find(uuidtoid($this->request->arn_item_uuid, 'asset_receipt_note_items'));
        $findAsset=Asset::find($this->request->asset_id);
        if($findAsset->asset_name==trim($row['name'])){

            if ($arnItemData->remaining_quantity > 0 && $this->rowCount < $arnItemData->remaining_quantity) {
                $arnData = $this->assetService->findAssetReceiptNoteById(uuidtoid($this->request->arn_uuid, 'asset_receipt_notes'));
                $assetLocationStock = $this->assetService->getAssetStock(['asset_id' => $this->request->asset_id, 'location_id' => $this->request->location_id, 'entity_id' => $this->request->entity_id]);
                $assetData = $this->assetService->findById($this->request->asset_id);
                $assetTypeData = $this->assetTypeService->findById($assetData->asset_type_id);
                $locationData = $this->assetService->findLocationById($this->request->location_id);

                if ($assetLocationStock?->uuid) {
                    $assetStock = AssetStock::find(uuidtoid($assetLocationStock?->uuid, 'asset_stocks'));
                    $this->assetStockUuid = $assetStock?->uuid;
                } else {
                    // dd("test2");
                    $assetStock = new AssetStock();
                    $assetStock->asset_receipt_note_id = $arnData->id;
                    $assetStock->arn_item_id = $arnItemData->id;
                    $assetStock->category_id = $this->request->category_id;
                    $assetStock->asset_type_id = $this->request->asset_type_id;
                    $assetStock->asset_id = $this->request->asset_id;
                    $assetStock->location_id = $this->request->location_id;
                    $assetStock->entity_id = $this->request->entity_id;
                    $assetStock->previous_stock = 0;
                    $assetStock->current_stock = 0;
                    $assetStock->unit = $arnItemData->unit;
                    $assetStock->save();
                    $this->assetStockUuid = $assetStock?->uuid;
                }

                $inventory['asset_stock_id'] = $assetStock->id;

                // $this->assetStockUuid = $assetLocationStock?->uuid;

                $lastId = Inventory::orderBy('id', 'desc')->pluck('id')->first();
                // $entity = $arnData->purchaseOrder->entity->name;
                $purchaseDateSerial = $row['purchase_date'];
                $purchaseDate = Carbon::instance(\PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($purchaseDateSerial));
                $inventory['purchase_date'] = $purchaseDate->format('Y-m-d');

                $month = $purchaseDate->month;
                $year = $purchaseDate->year;
                $entity = Category::find($this->request->entity_id);
                $identification_no = $this->generateIdentificationCode($entity->name, $locationData->street_address, $assetTypeData->name, $month, $year, str_pad($lastId + 1, 4, '0', STR_PAD_LEFT));

                $inventory['identification_no'] = $identification_no;
                $inventory['category_id'] = $this->request->category_id;
                $inventory['asset_type_id'] = $this->request->asset_type_id;
                $inventory['asset_id'] = $this->request->asset_id;
                $inventory['capacity_specs'] = $this->transformCapacitySpecsToHtmlList($row['attibute']);
                $inventory['asset_condition'] = $row['asset_condition'];
                $inventory['purchase_date'] = $purchaseDate->format('Y-m-d');
                $inventory['duration'] = $row['duration'];
                $warrantyLicenceDate = $purchaseDate->copy()->addMonths($inventory['duration']);
                $inventory['warranty_licence_date'] = $warrantyLicenceDate->format('Y-m-d');
                $inventory['amount'] = $arnItemData->amount;
                $isInventoryCreated = $assetStock->inventories()->updateOrCreate(['unique_id' => $row['unique_number_type']], $inventory);
                $this->rowCount++;


            }
        }
    }

    private function transformCapacitySpecsToHtmlList($capacitySpecsJson)
    {

        $capacitySpecsArray = json_decode($capacitySpecsJson, true);
        $htmlList = '<ul>';
        foreach ($capacitySpecsArray as $key => $value) {
            $htmlList .= "<li><strong>{$key}: </strong>{$value}</li>";
        }
        $htmlList .= '</ul>';
        return $htmlList;
    }
    public function __destruct()
    {


        $newStock = $this->initialStock + $this->rowCount;
        $data = [
            'previous_stock' => $this->initialStock,
            'current_stock' => $newStock,
        ];

        // dd($this->assetStockUuid);
         $isStockUpdated = $this->assetService->addOrUpdateAssetStock(['uuid' => $this->assetStockUuid ?? null], $data);

        // $isStockUpdated = $assetStock->where('uuid',$this->assetStockUuid )->update($data);


        $arnItemData = AssetReceiptNoteItem::find(uuidtoid($this->request->arn_item_uuid, 'asset_receipt_note_items'));
        if ($arnItemData) {
            $isArnRemainingQuantityUpdated = $arnItemData->update([
                'remaining_quantity' => $arnItemData->remaining_quantity - $this->rowCount
            ]);
        }
    }

    private function generateIdentificationCode($entity = null, $location = null, $assetType = null, $month = null, $year = null, $lastId = null)
    {
        $budgetCode = substr(strtoupper((preg_replace('/[^a-zA-Z0-9]/', '', $entity))), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $location)), 0, 3) . '/' . substr(strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $assetType)), 0, 3) . '/' . $month . '/' . $year . '-' . $lastId;
        return $budgetCode;
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        // return 'street_address';
    }

    /**
     * Summary of rules
     * @return array
     */



    public function rules(): array
    {
        return [];
    }
}
