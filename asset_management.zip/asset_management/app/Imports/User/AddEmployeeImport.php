<?php

/**
 * Summary of namespace App\Imports\User
 */
namespace App\Imports\User;

use Carbon\Carbon;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Mail\SendMailable;
use App\Traits\UploadAble;
use Maatwebsite\Excel\Row;
use App\Models\Company\Location;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;

/**
 * Summary of AddEmployeeImport
 */
class AddEmployeeImport implements OnEachRow,WithHeadingRow,WithValidation,SkipsEmptyRows,WithUpserts,WithGroupedHeadingRow,WithCalculatedFormulas
{
    use UploadAble;
    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */
    public function onRow(Row $row)
    {
        $row = $row->toArray();
        if($row['email'] && $row['mobile_number']){
            $isEmployeeExists = User::where('email', $row['email'])->first();
            $isEmployeeCreatedOrUpdated = User::updateOrCreate(['email' => $row['email']],
            [
                'unique_id'    => $row['employee_id'],
                'first_name'    => $row['first_name'],
                'last_name'     => $row['last_name'],
                'mobile_number' => $row['mobile_number'],
                'email'         => $row['email'],
                'password' => bcrypt($row['mobile_number'])
            ]);


            if($isEmployeeCreatedOrUpdated){
                $officeLocation = Location::where('street_address', $row['office_location'])->first();


                // dd(nametoid($row['department'], 'departments'));
                $isEmployeeCreatedOrUpdated->profile()->updateOrCreate(['user_id' => $isEmployeeCreatedOrUpdated->id], [
                    'date_of_joining' => Carbon::parse(\PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['date_of_joining']))->format('Y-m-d'),
                    'designation_id' => nametoid($row['designation'], 'categories', 'designation'),
                    'department_id' => nametoid($row['department'], 'departments', 'department'),
                    'sbu_id' => nametoid($row['sbu'], 'categories', 'sbu'),
                    'division_id' => nametoid($row['division'], 'categories', 'division'),
                    'location_id' => $officeLocation?->id,
                    'entity_id' => nametoid($row['entity'], 'categories', 'entity'),
                    'max_amount' => $row['max_amount'],
                ]);


                if(!$isEmployeeExists){
                    $role = Role::where('name', $row['role'])->first();
                    $isEmployeeCreatedOrUpdated->roles()->attach($role);
                    $permissions = $role->permissions()->pluck('slug')->toArray();
                    $isEmployeeCreatedOrUpdated->givePermissionsTo($permissions);
                    $isEmployeeCreatedOrUpdated->markEmailAsVerified();
                }



                /*$reporting_persons = [];
                $reportingManager = null;
                $reportingPartner = null;

                if ($row['reporting_manager']){
                    $reportingManagerNames = explode(' ', trim($row['reporting_manager']));
                    $reportingManagerQuery = User::where('first_name', $reportingManagerNames[0]);
                    if(isset($reportingManagerNames[1]) && $reportingManagerNames[1]){
                        $reportingManagerQuery = $reportingManagerQuery->where('last_name', $reportingManagerNames[1]);
                    }
                    $reportingManager = $reportingManagerQuery->first();
                }
                if ($row['reporting_partner']){
                    $reportingPartnerNames = explode(' ', trim($row['reporting_partner']));
                    $reportingPartnerQuery = User::where('first_name', $reportingPartnerNames[0]);
                    if(isset($reportingPartnerNames[1]) && $reportingPartnerNames[1]){
                        $reportingPartnerQuery = $reportingPartnerQuery->where('last_name', $reportingPartnerNames[1]);
                    }
                    $reportingPartner = $reportingPartnerQuery->first();
                }



                if(!$isEmployeeExists){
                    if($reportingManager){
                        $isEmployeeCreatedOrUpdated->reportingPersons()->attach($reportingManager->id, [
                            'role_type' => 'manager'
                        ]);
                    }
                    if($reportingPartner){
                        $isEmployeeCreatedOrUpdated->reportingPersons()->attach($reportingPartner->id, [
                            'role_type' => 'partner'
                        ]);
                    }
                }else{
                    if($reportingManager){
                        $reporting_persons[] = [
                            'person_id' => $reportingManager->id,
                            'role_type' => 'manager'
                        ];
                    }
                    if($reportingPartner){
                        $reporting_persons[] = [
                            'person_id' => $reportingPartner->id,
                            'role_type' => 'partner'
                        ];
                    }
                    if($reporting_persons){
                        $isEmployeeCreatedOrUpdated->reportingPersons()->detach();
                        $isEmployeeCreatedOrUpdated->reportingPersons()->sync($reporting_persons);
                    }
                }*/

                if ($row['profile_image']) {
                    $b64image = base64_encode(file_get_contents($row['profile_image']));
                    $imageUrlArr = explode('.', $row['profile_image']);
                    $fileName = uniqid() . '.' . end($imageUrlArr);
                    $isFileUploaded = $this->createImageFromBase64($b64image, config('constants.SITE_USER_IMAGE_UPLOAD_PATH'), $fileName, 'public');
                    if ($isFileUploaded) {
                        $isEmployeeCreatedOrUpdated->media()->updateOrCreate(['user_id' => $isEmployeeCreatedOrUpdated->id,'media_type'=>'image'], [
                            'mediaable_type' => get_class($isEmployeeCreatedOrUpdated),
                            'mediaable_id' => $isEmployeeCreatedOrUpdated->id,
                            'media_type' => 'image',
                            'file' => $fileName,
                            'is_profile_picture' => true
                        ]);
                    }
                }
                // if(!$isEmployeeExists){
                //     $mailData =[
                //         'to' => $row['email'],
                //         'from' => env('MAIL_FROM_ADDRESS'),
                //         'mail_type' => 'information',
                //         'line' => 'Welcome To DHC Portal',
                //         'content' => 'Your account has been successfully created. Please change your password once you login into our portal',
                //         'subject' => 'Credentials for Login',
                //         'password' => $row['mobile_number'],
                //         'greetings' => 'Hello Sir/Madam',
                //         'link' => route('login')
                //     ];
                //     // Mail::send(new SendMailable($mailData));
                // }
            }

        }
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        return 'email';
    }

    /**
     * Summary of rules
     * @return array
     */
    public function rules(): array
    {
        return [
            // 'employeeid'        => 'required',
            'first_name'        => 'required|string|min:1',
            'last_name'         => 'required|string|min:1',
            // 'mobile_number'     => 'required|integer|digits:10',
            // 'email'             => 'required|email',
            'date_of_joining'   => 'required',
            'entity'            => 'required|string',
            'department'        => 'required|string',
            'sbu'               => 'required|string',
            'role'              => 'required|string',
            'division'          => 'required|string',
            'designation'       => 'required|string',
            'profile_image'     => 'nullable|sometimes',
            'max_amount'        => 'required|numeric',
            'office_location'   => 'nullable|string',
            'reporting_manager' => 'nullable|string',
            'reporting_partner' => 'nullable|string',
        ];
    }
}
