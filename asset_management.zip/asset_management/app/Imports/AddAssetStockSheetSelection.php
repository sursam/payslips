<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Http\Controllers\BaseController;
use App\Imports\AddAssetStockImport;
use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Receipt\AssetReceiptNoteItem;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;
use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Summary of AddEmployeeImport
 */
class AddAssetStockSheetSelection implements WithMultipleSheets
{
    protected $request;
    protected $assetService;
    protected $assetTypeService;

    public function __construct($request, $assetService, $assetTypeService)
    {
        $this->request = $request;
        $this->assetService = $assetService;
        $this->assetTypeService = $assetTypeService;
    }

    public function sheets(): array
    {
        $sheetNames = $this->getSheetNamesFromExcel($this->request->file('excel_file'));
        
        $sheets = [];
        foreach ($sheetNames as $sheetName) {
            $sheets[$sheetName] = new AddAssetStockImport($this->request, $this->assetService, $this->assetTypeService, $sheetName);
        }

        return $sheets;
    }
    private function getSheetNamesFromExcel($file)
    {
        // Load the spreadsheet file
        $spreadsheet = IOFactory::load($file->getPathname());

        // Get all sheet names
        $sheetNames = $spreadsheet->getSheetNames();

        return $sheetNames;
    }
}
