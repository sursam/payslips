<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Site\Category;
use App\Models\Site\Department;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class AddMasterImport implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas
{
    protected $type;

    public function __construct($type)
    {
        $this->type = $type;
    }
    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */
    public function onRow(Row $row)
    {
        $row = $row->toArray();

        if ($this->type == 'department') {
            if (trim($row['parent_department']) != null)
                $findParent = Department::where('name', trim($row['parent_department']))->first();
            $isDepartmentCreatedOrUpdated = Department::updateOrCreate(
                ['name' => trim($row['department_name'])],
                [
                    'name'    => trim($row['department_name']),
                    'description' => $row['description'] ?? null,
                    'parent_id'        => $findParent->id ?? null,
                    'type'        => 'department',
                ]
            );
        } else
            $isDataCreatedOrUpdated = Category::updateOrCreate(
                ['name' => trim($row['name'])],
                [
                    'name'    => trim($row['name']),
                    'description' =>$row['description'] ?? null,
                    'type'        => $this->type,
                ]
            );
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    
     public function uniqueBy()
    {
        // if ($this->type == 'department')
        //     return 'department_name';
        // else
        //     return 'name';
    }

    /**
     * Summary of rules
     * @return array
     */
    public function rules(): array
    {
        if ($this->type == 'department')
            return [
                'department_name'        => 'required|string|min:1',
                'description' => 'nullable|string',
                'parent_department' => 'nullable|string',
            ];
        else
            return [
                'name'        => 'required|string|min:1',
                'description' => 'nullable|string',
            ];
    }
}
