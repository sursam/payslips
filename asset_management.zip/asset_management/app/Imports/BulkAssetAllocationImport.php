<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Http\Controllers\BaseController;
use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Inventory\AssetIssue;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use App\Models\Lease\LeaseAgreement;
use App\Models\Lease\LeaseItem;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Receipt\AssetReceiptNoteItem;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Notifications\IssueNotification;
use App\Services\Asset\AssetService;
use App\Services\Asset\AssetTypeService;
use App\Services\Inventory\AssetStockService;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class BulkAssetAllocationImport implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas
{
    use UploadAble;

    protected $request;

    protected $assetService;
    public function __construct(Request $request, AssetService $assetService, AssetTypeService $assetTypeService, AssetStockService $assetStockService)
    {
        $this->request = $request;
        $this->assetService = $assetService;
        $this->assetTypeService = $assetTypeService;
        $this->assetStockService = $assetStockService;
    }

    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */




    public function onRow(Row $row)
    {

        $row = $row->toArray();

        $findAssetInventory = Inventory::Where('unique_id', trim($row['serial_no']))->first();
        $findUser = User::where('unique_id', trim($row['employee_code_as_per_hub']))->first();
        $notificationContent = '';
        if ($findAssetInventory && $findUser) {
            $findAsset = Asset::find($findAssetInventory->asset_id);
            $findAssetStock = AssetStock::find($findAssetInventory->asset_stock_id);

            $isIssueExists = AssetIssue::where(['asset_id' => $findAssetInventory->asset_id, 'asset_stock_id' => $findAssetInventory->asset_stock_id, 'inventory_id' => $findAssetInventory->id, 'location_id' => $findAssetStock->location_id,  'is_surrender' => 0])->first();

            if (!$isIssueExists && ($findAsset->asset_name == trim($row['model_no']))) {
                if ($this->request->lease_uuid) {
                    $itemData = [
                        'user_id' => $findUser->id,
                        'leased_date' => Carbon::now()->format('Y-m-d'),
                    ];


                    $leasedAgreement = $this->assetStockService->findLeaseAgreementById(uuidtoid($this->request->lease_uuid, 'lease_agreements'));
                    $findLeaseItem = LeaseItem::where('lease_id', $leasedAgreement->id)->where('inventory_id', $findAssetInventory->id)->first();

                    if ($findLeaseItem) {
                        $isLeaseItems = $this->assetStockService->addOrUpdateLeaseItems(['uuid' => $findLeaseItem->uuid], $itemData);
                        if ($this->request->lease_uuid != null)
                            $asset = $this->assetService->findById($leasedAgreement->asset_id);
                        $acceptance_otp = rand(1000, 9999);
                        $this->request->merge(['asset_id' => $asset->id, 'asset_stock_id' => $leasedAgreement->asset_stock_id, 'inventory_id' => $findAssetInventory->id, 'location_id' => $leasedAgreement->location_id, 'user_id' => $findUser->id, 'expiry' => $findAssetInventory->warranty_licence_date, 'quantity' => null, 'issued_date' => Carbon::now()->format('Y-m-d'), 'acceptance_otp' => $acceptance_otp]);

                        $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => null], $this->request->except('_token'));


                        if ($findLeaseItem->inventory_id != null) {
                            $inventoryData = $this->assetService->findInventoryById($findLeaseItem->inventory_id);
                            $notificationContent = 'An asset with serial no #' . $inventoryData->unique_id . ' has been allocated to you.';
                        }
                    }

                } else {
                    $acceptance_otp = rand(1000, 9999);
                    $duration = $findAssetInventory->duration;
                    $this->request->merge(['asset_id' => $findAssetInventory->asset_id, 'asset_stock_id' => $findAssetInventory->asset_stock_id, 'acceptance_otp' => $acceptance_otp, 'user_id' => $findUser->id, 'inventory_id' => $findAssetInventory->id, 'location_id' => $findAssetStock->location_id, 'issued_date' => Carbon::now()->format('Y-m-d'), 'expiry' => Carbon::now()->addMonths($duration)->format('Y-m-d')]);


                    $isIssued = $this->assetStockService->addOrUpdateAssetIssue(['uuid' => null], $this->request->except('_token'));
                    if ($isIssued) {
                        $isUpdated = $this->assetStockService->alterStockTable(['id' => $findAssetInventory->asset_stock_id], 1, 'decrease');
                        if ($isUpdated) {
                            $filterConditions = ['asset_id' => $findAssetInventory->asset_id, 'location_id' => $findAssetStock->location_id, 'entity_id' => $findAssetStock->entity_id];
                            $assetStockData = $this->assetStockService->getAssetStockByCondition($filterConditions);
                            $logData = [
                                'asset_stock_id' => $findAssetInventory->asset_stock_id,
                                'asset_id' => $findAssetInventory->asset_id,
                                'location_id' => $findAssetStock->location_id,
                                'entity_id' => $findAssetStock->entity_id,
                                'type' => 'substruct',
                                'quantity' => 1
                            ];
                            $isLogAdded = $this->assetStockService->addAssetStockLog($logData);
                        }
                        $asset = $this->assetService->findById($findAssetInventory->asset_id);
                    }
                    $notificationContent = 'An asset with serial no #' . $findAssetInventory->unique_id . ' has been allocated to you.';

                }

                $notiData = [
                    'form_name' => $notificationContent,
                    'issue_uuid' => $isIssued->uuid ?? null,
                ];
                $findUser->notify(new IssueNotification($notiData));
            }
        }
    }





    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        // return 'street_address';
    }

    /**
     * Summary of rules
     * @return array
     */



    public function rules(): array
    {
        return [];
    }
}
