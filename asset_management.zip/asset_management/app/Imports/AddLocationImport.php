<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class AddLocationImport implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas
{
    use UploadAble;
    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */
    public function onRow(Row $row)
    {
        $row = $row->toArray();
        $findState = State::where('name', $row['state'])->first();
        $findCity = City::where('name', $row['city'])->first();
        try {
            $isLocationCreatedOrUpdated = Location::updateOrCreate(
                ['street_address' => trim($row['street_address'])],
                [
                    'street_address' => trim($row['street_address']),
                    'country_id' => 101,
                    'state_id' => $findState->id,
                    'city_id' => $findCity->id,
                ]
            );
        } catch (\Exception $e) {
            Log::error('Error inserting row: ' . json_encode($row) . ' - ' . $e->getMessage());
        }
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        return 'street_address';
    }

    /**
     * Summary of rules
     * @return array
     */
    public function rules(): array
    {
        return [
            'street_address'        => 'required|string|min:1',
            'state'         => 'required|string|min:1',
            'city'     => 'required|string|min:1'
        ];
    }
}
