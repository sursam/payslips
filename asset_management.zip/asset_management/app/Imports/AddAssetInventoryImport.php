<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Http\Controllers\BaseController;
use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class AddAssetInventoryImport  implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas, WithMultipleSheets
{
    protected $type;
    protected static $findAssetForAssetStock;
    protected static $findAssetCategoryForAssetStock;
    protected static $findAssetTypeForAssetStock;
    public function __construct($type)
    {
        $this->type = $type;
        self::$findAssetForAssetStock = null;
        self::$findAssetCategoryForAssetStock = null;
        self::$findAssetTypeForAssetStock = null;
    }


    public function sheets(): array
    {

        return [
            // 'Sheet1' => new self($this->type),
            // 'Sheet2' => new self($this->type),
            // 'Sheet3' => new self($this->type),
            // 'Sheet4' => new self($this->type),
            // 'Sheet5' => new self($this->type),
            // 'Sheet6' => new self($this->type),
            // 'Sheet7' => new self($this->type),
        ];
    }

    // public function map($row): array
    // {
    //     return [

    //         'asset_category' => $row['C5'] ?? null, // Fetching from C5
    //     ];
    // }
    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */




    public function onRow(Row $row)
    {
      //dd("aaaaaaaaa");
        $row = $row->toArray();      
        // if (($row['asset_name'] != null) && ($row['purchase_entity'] != null) && ($row['asset_location'] != null)) {
            $findAssetForInventory = Asset::where('asset_name', trim($row['asset_name']))->first();
            $findAssetLocation = Location::where('street_address', trim($row['asset_location']))->first();
            $findEntity = Category::where('name', trim($row['purchase_entity']))->first();
            $findAssetStcock = AssetStock::where(['asset_id' => $findAssetForInventory->id, 'location_id' => $findAssetLocation->id, 'entity_id' => $findEntity->id,])->first();
        // }
        


        $month = date('m', strtotime($row['purchase_date']));
        $year = date('Y', strtotime($row['purchase_date']));
        $lastId = Inventory::orderBy('id', 'desc')->pluck('id')->first();
        $identification_no = "CON/CON/LAP/12/2024-0006";

        $isAssetInventoryCreated = Inventory::create(
            [
                'unique_id' => trim($row['serial_no']),
                'identification_no' => $identification_no,
                'asset_stock_id' => $findAssetStcock->id ?? null,
                'category_id' => $findAssetStcock->category_id ?? null ?? null,
                'asset_type_id' => $findAssetStcock->asset_type_id ?? null,
                'asset_id' => $findLocation->id ?? null,
                'capacity_specs' => null,
                'asset_condition' => 'new',
                'warranty_licence_date' => trim($row['warranty_expire']),
            ]
        );
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        //return 'email';
    }

    /**
     * Summary of rules
     * @return array
     */
    public function rules(): array
    {

        switch ($this->type) {
            case 'asset-type-category':
                return [
                    'name'        => 'required|string|min:1',
                    'parent_category'         => 'nullable|string'
                ];
                break;
            case 'asset-type':
                return [
                    'name'        => 'required|string|min:1',
                    'category'         => 'nullable|string',
                    'parent_asset_type'         => 'nullable|string',
                    'additional_details'         => 'nullable|string',
                    'unique_number_type'         => 'nullable|string',
                    'attribute'         => 'nullable|string'
                ];
                break;

            case 'assetstock':
                return [
                    // 'name'        => 'required|string|min:1',
                    // 'category'         => 'nullable|string',
                    // 'parent_asset_type'         => 'nullable|string',
                    // 'additional_details'         => 'nullable|string',
                    // 'unique_number_type'         => 'nullable|string',
                    // 'attribute'         => 'nullable|string'
                ];
                break;
            default:
                return [
                    // 'asset_name_model_no'        => 'required|string|min:1',
                    // 'asset_category'        => 'required|string|min:1',
                    // 'asset_type'        => 'required|string|min:1',
                    // 'has_unique_number'         => 'nullable|string',
                    // 'specifications'         => 'nullable|string'
                ];
                break;
        }
    }
}
