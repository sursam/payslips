<?php

/**
 * Summary of namespace App\Imports\User
 */

namespace App\Imports;

use App\Http\Controllers\BaseController;
use App\Mail\SendMailable;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Site\Attribute;
use App\Models\Site\Category;
use App\Models\Site\Tag;
use App\Models\User\Role;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Traits\UploadAble;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\WithGroupedHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;

/**
 * Summary of AddEmployeeImport
 */
class AddAssetImport  implements OnEachRow, WithHeadingRow, WithValidation, SkipsEmptyRows, WithUpserts, WithGroupedHeadingRow, WithCalculatedFormulas, WithMultipleSheets
{
    protected $type;
    protected static $findAssetForAssetStock;
    protected static $findAssetCategoryForAssetStock;
    protected static $findAssetTypeForAssetStock;
    public function __construct($type)
    {
        $this->type = $type;
        self::$findAssetForAssetStock = null;
        self::$findAssetCategoryForAssetStock = null;
        self::$findAssetTypeForAssetStock = null;
    }


    public function sheets(): array
    {

        return [
            // 'Sheet1' => new self($this->type),
            // 'Sheet2' => new self($this->type),
            // 'Sheet3' => new self($this->type),
            // 'Sheet4' => new self($this->type),
            // 'Sheet5' => new self($this->type),
            // 'Sheet6' => new self($this->type),
            // 'Sheet7' => new self($this->type),
        ];
    }

    // public function map($row): array
    // {
    //     return [

    //         'asset_category' => $row['C5'] ?? null, // Fetching from C5
    //     ];
    // }
    /**
     * Summary of onRow
     * @param \Maatwebsite\Excel\Row $row
     * @return void
     */




    public function onRow(Row $row)
    {

        $row = $row->toArray();
        switch ($this->type) {
            case 'asset-type-category':
                if (trim($row['parent_category']) != null)
                    $findParent = Category::where('name', trim($row['parent_category']))->first();
                $isAssetTypeCategoryCreatedOrUpdated = Category::updateOrCreate(
                    ['name' => trim($row['name'])],
                    [
                        'parent_id' => $findParent->id ?? null,
                        'type' => 'asset_type'
                    ]
                );
                break;
            case 'asset-type':
                $findCategory = Category::where('name', trim($row['category']))->first();
                $findParentAssetType = AssetType::where('name', trim($row['parent_asset_type']))->first();

                $findAssetType = AssetType::where('name', trim($row['name']))->first();
                if ($findAssetType)
                    $typeId = $findAssetType->type_id;
                else {
                    $lastId = AssetType::orderBy('id', 'desc')->pluck('id')->first();
                    $typeId = 'ASTP' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
                }

                $isAssetTypeCreatedOrUpdated = AssetType::updateOrCreate(
                    ['name' => trim($row['name'])],
                    [
                        'type_id' => $typeId,
                        'category_id' => $findCategory->id ?? null,
                        'parent_id' => $findParentAssetType->id ?? null,
                        'name' => trim($row['name']),
                        'additional_details' => $row['additional_details'] ?? null,
                        'type' => 'asset',
                        'unique_number_type' => trim($row['unique_number_type']) == "Serial Number" ? "serial" : 'license'
                    ]
                );

                if ($row['attribute'] != null) {
                    $attributes = json_decode($row['attribute'], true);
                    if (is_array($attributes)) {
                        foreach ($attributes as $name => $value) {
                            $findParent = Attribute::create([
                                'asset_type_id' => $isAssetTypeCreatedOrUpdated->id,
                                'name' => $name,
                                'created_by' => auth()->user()->id,
                                'updated_by' => auth()->user()->id
                            ]);
                        }
                    }
                }
                break;







            case 'assetstock':
                if (($row['asset_name'] != null) && ($row['asset_type'] != null)) {
                    self::$findAssetForAssetStock = Asset::where('asset_name', trim($row['asset_name']))->first();
                    $findAssetType = AssetType::where('name', trim($row['asset_type']))->first();
                    self::$findAssetCategoryForAssetStock = Category::where('name', trim($row['asset_category']))->first();
                    self::$findAssetTypeForAssetStock = AssetType::where('name', trim($row['asset_type']))->first();
                }
                $findLocation = Location::where('street_address', trim($row['location']))->first();
                $findEntity = Category::where('name', trim($row['entity']))->first();
                $assetStockExists = Assetstock::where([
                    'asset_id' => self::$findAssetForAssetStock->id ?? null,
                    'location_id' => $findLocation->id ?? null,
                    'entity_id' => $findEntity->id ?? null
                ])->first();
                $isAssetStockCreatedOrUpdated = AssetStock::updateOrCreate(
                    [
                        'asset_id' => self::$findAssetForAssetStock->id ?? null,
                        'location_id' => $findLocation->id ?? null,
                        'entity_id' => $findEntity->id ?? null
                    ],
                    [
                        'asset_receipt_note_id' => null,
                        'arn_item_id' => null,
                        'category_id' => self::$findAssetCategoryForAssetStock->id ?? null,
                        'asset_type_id' => self::$findAssetTypeForAssetStock->id ?? null,
                        'asset_id' => self::$findAssetForAssetStock->id ?? null,
                        'location_id' => $findLocation->id ?? null,
                        'entity_id' => $findEntity->id ?? null,
                        'previous_stock' => $assetStockExists ? $assetStockExists->current_stock : 0,
                        'current_stock' => trim($row['current_stock']),
                        'unit' => 'piece',
                    ]
                );
                break;


            case 'inventory':
                if (($row['asset_name'] != null) && ($row['purchase_entity'] != null) && ($row['asset_location'] != null)) {
                    $findAssetForInventory = Asset::where('asset_name', trim($row['asset_name']))->first();
                    $findAssetLocation = Location::where('street_address', trim($row['asset_location']))->first();
                    $findEntity = Category::where('name', trim($row['purchase_entity']))->first();
                    $findAssetStcock = AssetStock::where(['asset_id' => $findAssetForInventory->id, 'location_id' => $findAssetLocation->id, 'entity_id' => $findEntity->id,])->first();
                }


                // $findLocation = Location::where('street_address', trim($row['location']))->first();
                // $findEntity = Category::where('name', trim($row['entity']))->first();


                // $assetStockExists = Assetstock::where([
                //     'asset_id' => self::$findAssetForAssetStock->id ?? null,
                //     'location_id' => $findLocation->id ?? null,
                //     'entity_id' => $findEntity->id ?? null
                // ])->first();


                $month = date('m', strtotime($row['purchase_date']));
                $year = date('Y', strtotime($row['purchase_date']));
                $lastId = Inventory::orderBy('id', 'desc')->pluck('id')->first();
                $identification_no = "CON/CON/LAP/12/2024-0006";

                $isAssetInventoryCreated = Inventory::create(
                    [
                        'unique_id' => trim($row['serial_no']),
                        'identification_no' => $identification_no,
                        'asset_stock_id' => $findAssetStcock->id ?? null,
                        'category_id' => $findAssetStcock->category_id ?? null ?? null,
                        'asset_type_id' => $findAssetStcock->asset_type_id ?? null,
                        'asset_id' => $findLocation->id ?? null,
                        'capacity_specs' => null,
                        'asset_condition' => 'new',
                        'warranty_licence_date' => trim($row['warranty_expire']),
                    ]
                );
                // dd($isAssetInventoryCreated);

                break;





            default:
                $findAsset = Asset::where('asset_name', trim($row['asset_name_model_no']))->first();
                if ($findAsset)
                    $assetid = $findAsset->asset_id;
                else {
                    $lastId = Asset::orderBy('id', 'desc')->pluck('id')->first();
                    $assetid = 'ASST' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
                }

                $findCategory = Category::where('name', trim($row['asset_category']))->first();
                $findAssetType = AssetType::where('name', trim($row['asset_type']))->first();

                if ($row['specifications'] != null) {
                    $specifications = json_decode($row['specifications'], true);
                    $findAttributes = Attribute::where('asset_type_id', $findAssetType->id)->get();
                    $storedAttributes = [];
                    //dd($findAttributes);
                    foreach ($findAttributes as $attribute) {
                        foreach ($specifications as $specName => $specValue) {
                            if ($attribute->name == $specName) {
                                $storedAttributes[$attribute->id] = [
                                    'name' => $specName,
                                    'value' => $specValue
                                ];
                            }
                        }
                    }
                }
                //dd($storedAttributes);
                $isAssetCreatedOrUpdated = Asset::updateOrCreate(
                    ['asset_name' => trim($row['asset_name_model_no'])],
                    [
                        'category_id' => $findCategory->id ?? null,
                        'asset_type_id' => $findAssetType->id ?? null,
                        'asset_id' => $assetid ?? null,
                        'asset_name' => trim($row['asset_name_model_no']),
                        'slug' => Str::slug(trim($row['asset_name_model_no'])),
                        'asset_image' => "noimg.png",
                        'specifications' => $storedAttributes ?? null,
                        'has_unique_number' => trim($row['has_unique_number']) == "yes" ? "1" : '0'
                    ]
                );


                break;
        }
    }

    /**
     * Summary of uniqueBy
     * @return string
     */
    public function uniqueBy()
    {
        //return 'email';
    }

    /**
     * Summary of rules
     * @return array
     */
    public function rules(): array
    {

        switch ($this->type) {
            case 'asset-type-category':
                return [
                    'name'        => 'required|string|min:1',
                    'parent_category'         => 'nullable|string'
                ];
                break;
            case 'asset-type':
                return [
                    'name'        => 'required|string|min:1',
                    'category'         => 'nullable|string',
                    'parent_asset_type'         => 'nullable|string',
                    'additional_details'         => 'nullable|string',
                    'unique_number_type'         => 'nullable|string',
                    'attribute'         => 'nullable|string'
                ];
                break;

            case 'assetstock':
                return [
                    // 'name'        => 'required|string|min:1',
                    // 'category'         => 'nullable|string',
                    // 'parent_asset_type'         => 'nullable|string',
                    // 'additional_details'         => 'nullable|string',
                    // 'unique_number_type'         => 'nullable|string',
                    // 'attribute'         => 'nullable|string'
                ];
                break;
            default:
                return [
                    // 'asset_name_model_no'        => 'required|string|min:1',
                    // 'asset_category'        => 'required|string|min:1',
                    // 'asset_type'        => 'required|string|min:1',
                    // 'has_unique_number'         => 'nullable|string',
                    // 'specifications'         => 'nullable|string'
                ];
                break;
        }
    }
}
