<?php

namespace App\Traits;

use App\Models\User\User;
use Google\Client as Google_Client;
use Illuminate\Support\Facades\Auth;

/**
 * Trait FlashMessages
 * @package App\Traits
 */

trait PushNotificationTrait
{
    function getAccessToken()
    {
        $credentialsFilePath = config_path('google-services.json');
        $client = new Google_Client();
        $client->setAuthConfig($credentialsFilePath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $token = $client->fetchAccessTokenWithAssertion();
        $accessToken = $token['access_token'];
        // dd($accessToken);
        return $accessToken;
    }

    function sendPushNotification($userId = null, $requestparam)
    {
        $user = $userId ? User::find($userId) : auth()->user();
        $deviceToken = $user->fcm_token ? $user->fcm_token : '';
        // dd($user);
        $accessToken = $this->getAccessToken();

        $notification = [
            "title" => $requestparam->title,
            "body" => $requestparam->body,
            "image" => asset('assets/images/logo.png')
        ];

        $data = [
            "message" => [
                "token" => $deviceToken,
                "data" => $notification,
            ],
        ];

        $dataString = json_encode($data);

        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $accessToken,
        ];

        $projectId = config('services.firebase.projectId');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/v1/projects/'.$projectId.'/messages:send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
        $response = curl_exec($ch);
        // dd($response);
        if ($response === false) {
            die('FCM Send Error: ' . curl_error($ch));
        }

        curl_close($ch);

        return $response;
    }

}
