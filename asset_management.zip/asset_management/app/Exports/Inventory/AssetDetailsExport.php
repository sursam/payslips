<?php

namespace App\Exports\Inventory;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\FromCollection;

// class InventoryStockDetailsExport implements FromCollection
class AssetDetailsExport implements FromView
{

    protected $assets;

    public function __construct($assets)
    {   
        $this->assets = $assets;
    }

    public function view(): View
    {
        return view('admin.asset.stock.inventory.asset-details', [
            'assets' => $this->assets,
        ]);
    }
}
