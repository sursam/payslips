<?php

namespace App\Exports\Inventory;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\FromCollection;

// class InventoryStockDetailsExport implements FromCollection
class InventoryStockDetailsExport implements FromView
{
    // /**
    // * @return \Illuminate\Support\Collection
    // */
    // public function collection()
    // {
       
    // }


    protected $asset_stock;
    protected $inventories;

    public function __construct($asset_stock,$inventories)
    {
        $this->asset_stock = $asset_stock;
        $this->inventories = $inventories;
    }



    public function view(): View
    {

        return view('admin.asset.stock.inventory.inventory-stock-details',[
            'asset_stock' => $this->asset_stock,
            'inventories' => $this->inventories
        ]);       

    }
}
