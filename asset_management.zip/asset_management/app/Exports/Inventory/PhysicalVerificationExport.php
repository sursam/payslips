<?php

namespace App\Exports\Inventory;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\FromCollection;

// class InventoryStockDetailsExport implements FromCollection
class PhysicalVerificationExport implements FromView
{

    protected $verificationData;
    protected $mismatchedInventories;

    public function __construct($verificationData,$mismatchedInventories)
    {   
       
        $this->verificationData = $verificationData;
        $this->mismatchedInventories = $mismatchedInventories;
    }

    public function view(): View
    {
        return view('admin.asset.stock.verification.excel', [
                    'verificationData' => $this->verificationData,
                    'mismatchedInventories' => $this->mismatchedInventories
                ]);
    }
}
