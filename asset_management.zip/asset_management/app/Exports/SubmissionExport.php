<?php



namespace App\Exports;

use Carbon\Carbon;
use App\Models\User;
use App\Models\School;

use App\Models\District;

use App\Models\EmployeeConference;
use App\Models\User\Vendor;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;


class SubmissionExport implements FromCollection, WithHeadings

{
    protected $quotations;
    protected $rfqData;
    public function __construct($quotations,$rfqData)
    {
        $this->quotations = $quotations;
        $this->rfqData = $rfqData;
    }
    /**

     * @return \Illuminate\Support\Collection

     */

    public function collection()
    {


        $result = [];
        // $rfqData = [
        //     'RFQ ID' => $this->rfqData->unique_id ?? '',
        //     'Quotation Date' => $this->rfqData->request_date ?? '',
        // ];


        // $rfqData = [
        //     'RFQ Details' => "RFQ ID: " . $this->rfqData->unique_id . "\n" .
        //                      " Quotation Date: " . $this->rfqData->request_date,
        // ];
        // $result[] = $rfqData;




        //dd($result);
        $staticCollection=([1,2]);

        foreach ($staticCollection as $quotation) {
            $result[] = [
                'Quotation Title' => 'title',
                // Add other quotation data as needed
            ];
        }

        // foreach ($schools as $record) {
        //     $result[] = array(
        //         // 'Quotation Details' => '',
        //         // 'Comparative Statement' =>'',
        //         'Quotation Id' => 'a',
        //         'conference Title' =>"b",
        //         'conference url' => "c",
        //         'location' =>"d",
        //         'conference date' =>'e',
        //         'Status'           =>'f',

        //     );
        // }

        return collect($result);
    }
    public function headings(): array
    {
        return [
            'Quotation Title',
            // 'School Name',
            // 'conference Title',
            // 'conference url',
            // 'location',
            // 'conference date',
            // 'status'
        ];
    }
}
