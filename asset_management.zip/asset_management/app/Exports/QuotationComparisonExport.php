<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\FromCollection;

class QuotationComparisonExport implements FromView
{


    protected $rfqData;
    protected $quotations;

    public function __construct($rfqData, $quotations)
    {
        $this->rfqData = $rfqData;
        $this->quotations = $quotations;
    }



    public function view(): View
    {

        return view('admin.requisition.quotation.excel',[
            'rfqData' => $this->rfqData,
            'quotations' => $this->quotations
        ]);

        // return view('admin.requisition.quotation.pdf',[
        //     'rfqData' => $this->rfqData,
        //     'quotations' => $this->quotations
        // ]);


    }

}
