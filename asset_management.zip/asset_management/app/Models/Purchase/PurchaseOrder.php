<?php

namespace App\Models\Purchase;

use App\Models\Location\State;
use App\Models\Master\AssetType;
use App\Models\Purchase\PurchaseOrderApproval;
use App\Models\Purchase\PurchaseOrderInvoice;
use App\Models\Purchase\PurchaseOrderItem;
use App\Models\Receipt\AssetReceiptNote;
use App\Models\Requisition\Quotation;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\User\User;
use App\Models\User\Vendor;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;

class PurchaseOrder extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'PORD'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'quotation_id',
        'vendor_id',
        'vendor_state',
        'delivery_state',
        'entity_id',
        'po_date',
        //'po_for',
        'valid_date_from',
        'valid_date_to',
        //'po_subject',
        //'purchase_type',
        //'vendor_bank',
        'is_gst_checked',
        'item_total',
        'total_amount',
        'total_item_count',
        'delivery_terms',
        'service_terms',
        'payment_terms',
        'warranty_terms',
        'line_before_items',
        'descriptions',
        'terms_conditions',
        'billing_address',
        'delivery_address',
        'status',
        'is_vendor_approved',
        'vendor_approval_rejection_comments',
        'discount_type',
        'discount',
        'tax_type',
        'tax',
        'created_by',
        'added_by',
    ];
    protected $casts = [
        'po_date' =>'date',
        'valid_date_from' =>'date',
        'valid_date_to' =>'date',
        'delivery_address' =>'array',
        'billing_address' =>'array',
        'terms_conditions' =>'array',
    ];
    public function poApproval(){
        return $this->hasMany(PurchaseOrderApproval::class, 'purchase_order_id', 'id');
    }
    public function quotations(){
        return $this->belongsTo(Quotation::class, 'quotation_id', 'id');
    }
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }

    public function items(){
        return $this->hasMany(PurchaseOrderItem::class);
    }
    public function vendor(){
        return $this->hasOne(Vendor::class, 'id', 'vendor_id');
    }
    public function arns(){
        return $this->hasMany(AssetReceiptNote::class, 'purchase_order_id', 'id');
    }
    public function PurchaseOrderInvoice(){
        return $this->hasMany(PurchaseOrderInvoice::class, 'purchase_order_id', 'id');
    }
    public function vendorState(){
        return $this->belongsTo(State::class, 'vendor_state', 'id');
    }
    public function deliveryState(){
        return $this->belongsTo(State::class, 'delivery_state', 'id');
    }
    public function user(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
}
