<?php

namespace App\Models\Purchase;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentSchedule extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'purchase_order_id',
        'percent',
        'payment_type',
        'payment_credit_days',
        'notify_days',
        'descriptions',
        'amount',
        'attachment_file',
    ];
    public function purchaseOrder(){
        return $this->belongsTo(PurchaseOrder::class);
    }

}
