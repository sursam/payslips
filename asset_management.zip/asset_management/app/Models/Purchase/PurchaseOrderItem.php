<?php

namespace App\Models\Purchase;

use Webpatser\Uuid\Uuid;
use App\Models\Master\Asset;
use App\Models\Master\AssetType;
use App\Models\Site\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PurchaseOrderItem extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'PITM'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'purchase_order_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'quantity',
        'unit',
        'specifications',
        'description',
        'amount',
        'discount_type',
        'discount',
        'tax_type',
        'tax',
        'total_amount',
        'status',
    ];
    protected $casts = [

    ];

    public function assetCategory(){
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
    public function assetType(){
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function purchaseOrder(){
        return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id', 'id');
    }

}
