<?php

namespace App\Models\Purchase;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PurchaseOrderApproval extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'purchase_order_id',
        'user_id',
        'level',
        'comments',
        'status'
    ];
    protected $casts = [

    ];
    public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
