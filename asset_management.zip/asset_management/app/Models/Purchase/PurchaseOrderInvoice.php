<?php

namespace App\Models\Purchase;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Models\Site\Document;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PurchaseOrderInvoice extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'INVC'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'purchase_order_id',
        'vendor_id',
        'party_invoice_number',
        'invoice_date',
        'challan_no',
        'billing_from_location',
        'billing_location',
        'sub_total',
        'grand_total',
        'tax_type',
        'tax',
        'descriptions',
        'purchase_order_items',
        'terms_conditions',
        'status',
        'created_by'
    ];
    protected $casts = [
        'invoice_date' =>'datetime',
        'purchase_order_items' =>'array',
    ];
    public function approval(){
        return $this->hasMany(PoInvoiceApproval::class, 'po_invoice_id', 'id');
    }
    public function purchaseOrder(){
        return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id', 'id');
    }
    public function vendor(){
        return $this->belongsTo(Vendor::class, 'vendor_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function approvals()
    {
        return $this->hasMany(PoInvoiceApproval::class, 'po_invoice_id', 'id');
    }

    public function isRejectedCheck()
        {
            return $this->hasMany(PoInvoiceApproval::class, 'po_invoice_id', 'id')->onlyTrashed();
        }
}
