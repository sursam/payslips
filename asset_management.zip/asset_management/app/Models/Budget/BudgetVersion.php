<?php

namespace App\Models\Budget;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Media;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\Site\Department;
use App\Models\Company\Location;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BudgetVersion extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'budget_id',
        'version',
        'name',
        'project_title',
        'category_id',
        'entity_id',
        'location_id',
        'department_id',
        'budget_for',
        'budget_type',
        'start_date',
        'end_date',
        'comments',
        'created_by',
        'added_by',
        'amount',
        'status',
        'budget_items',
        'budget_notes',
        'budget_documents',
        'budget_approvals',
    ];
    protected $casts = [
        'start_date' =>'date',
        'end_date' =>'date',
        'budget_items' =>'array',
        'budget_notes' =>'array',
        'budget_documents' =>'array',
        'budget_approvals' =>'array'
    ];

    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function addedBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }


    public function media()
    {
        return $this->hasMany(Media::class, 'user_id', 'id');
    }
    public function image(): MorphMany
    {
        return $this->morphMany(Media::class, 'mediaable');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function location(){
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }
    public function category(){
        return $this->belongsTo(Category::class);
    }
}
