<?php

namespace App\Models\Budget;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BudgetNote extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'BUDN'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'budget_id',
        'title',
        'content',
        'status'
    ];
    public function budget(){
        return $this->belongsTo(Budget::class, 'budget_id', 'id');
    }
}
