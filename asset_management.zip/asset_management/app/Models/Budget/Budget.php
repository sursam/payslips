<?php

namespace App\Models\Budget;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Media;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\Company\Location;
use App\Models\Site\Department;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Budget extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $model->version = 'V.1.0';
            // $unqid = strtoupper(substr(sha1(mt_rand()), 17, 6));
            // $model->unique_id = 'BUDG'.$unqid;
            // $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            // $model->unique_id = 'BUDG'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'version',
        'name',
        'project_title',
        'category_id',
        'entity_id',
        'location_id',
        'department_id',
        'budget_for',
        'budget_type',
        'start_date',
        'end_date',
        'comments',
        'created_by',
        'added_by',
        'amount',
        'status'
    ];
    protected $casts = [
        'start_date' =>'date',
        'end_date' =>'date'
    ];
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function addedBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }


    public function media()
    {
        return $this->hasMany(Media::class, 'user_id', 'id');
    }
    public function image(): MorphMany
    {
        return $this->morphMany(Media::class, 'mediaable');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function budgetApproval(){
        return $this->hasMany(BudgetApproval::class, 'budget_id', 'id');
    }

    public function location(){
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }
    public function category(){
        return $this->belongsTo(Category::class);
    }


    public function items()
    {
        return $this->hasMany(BudgetItem::class, 'budget_id', 'id');
    }
    public function notes()
    {
        return $this->hasMany(BudgetNote::class, 'budget_id', 'id');
    }
    public function approvals()
    {
        return $this->hasMany(BudgetApproval::class, 'budget_id', 'id');
    }
    public function versions()
    {
        return $this->hasMany(BudgetVersion::class, 'budget_id', 'id');
    }
}
