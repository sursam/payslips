<?php

namespace App\Models\Medical;

use Webpatser\Uuid\Uuid;
use App\Models\Site\Question;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Models\Site\Media;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Issue extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'name',
        'description',
        'category_id',
        'type',
        'gender'
    ];
    public function questions():BelongsToMany{
        return $this->belongsToMany(Question::class, 'questions_issues');
    }
    public function image():MorphMany{
        return $this->morphMany(Media::class,'mediaable');
    }
    public function getDisplayImageAttribute(){
        return $this->displayImage('original');
    }
    protected function displayImage($type='original'){
        $file= $this->image()->first()?->file;
        if($file){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/' . $type . '/issue/' . $file))){
                    return asset('storage/images/' . $type . '/issue/' . $file);
                }
            }
        }
        return asset('assets/images/no-image.png');
    }
}
