<?php

namespace App\Models\Report;

use App\Models\Master\AssetType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class DepreciationSetting extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'act_name',
        'asset_type_id',
        'useful_years',
        'effective_rate',
        'months_in_year',
        'salvage_value',
        'status',
    ];
    public function assetType(): BelongsTo{
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
}
