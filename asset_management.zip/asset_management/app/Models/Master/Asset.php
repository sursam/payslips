<?php

namespace App\Models\Master;

use App\Models\Inventory\AssetStock;
use App\Models\Inventory\Inventory;
use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Models\Site\Category;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;

class Asset extends Model
{
    use HasFactory,Sluggable,HasRecursiveRelationships,SoftDeletes;
    protected $append = ['avatar', 'assetid'];
    protected $fillable= [
        'uuid',
        'category_id',
        'asset_type_id',
        'asset_id',
        'asset_name',
        'slug',
        'purchase_date',
        'expiry_date',
        'vendor_name',
        'price',
        'asset_image',
        'specifications',
        'has_unique_number',
        'is_active'
    ];
    protected $casts = [
        'specifications' =>'array'
    ];
    public static function boot(){
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    public function sluggable(): array{
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }
    public function getAvatarAttribute() {
        if(($this->attributes['asset_image'] != '') && ($this->attributes['asset_image'] != 'noimg.png')){
            return asset('storage/asset_image/'.$this->attributes['asset_image']);
        }
        return asset('assets/images/noimg.png');
    }
    public function assettype(): BelongsTo{
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }

    public function vendor(): BelongsTo{
        return $this->belongsTo(Vendor::class, 'vendor_name', 'id');
    }

    public function category(): BelongsTo{
        return $this->belongsTo(Category::class);
    }

    // public function getAssetIdAttribute() {
    //     return 'AST'.str_pad($this->attributes['id'], 6, 0, STR_PAD_LEFT);
    // }
    public function assetStock() {
        return $this->hasMany(AssetStock::class,'asset_id','id');
    }
    public function inventories() {
        return $this->hasMany(Inventory::class, 'asset_id', 'id');
    }

}
