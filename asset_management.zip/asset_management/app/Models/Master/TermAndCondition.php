<?php

namespace App\Models\Master;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TermAndCondition extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable= [
        'uuid',
        'name',
        'type',
        'description',
        'is_active',
        'order',
    ];
    public static function boot(){
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
}
