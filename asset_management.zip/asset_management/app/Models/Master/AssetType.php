<?php

namespace App\Models\Master;

use App\Models\Report\DepreciationSetting;
use App\Models\Site\Category;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;
class AssetType extends Model
{
    use HasFactory,Sluggable,HasRecursiveRelationships;

    protected $fillable= [
        'type_id',
        // 'entity_id',
        // 'entity',
        'name',
        'slug',
        'image',
        'type',
        'parent_id',
        'category_id',
        'additional_details',
        'unique_number_type',
        'is_active'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
        // self::softDeleted(function ($model) {
        //     dd($model->name.'--'.time());
        //     $model->name = $model->name.'--'.time();
        //     $model->update();
        // });
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    public function parent(){
        return $this->belongsTo(static::class,'parent_id','id');
    }
    public function category(){
        return $this->belongsTo(Category::class,'category_id','id');
    }
    public function children() {
        return $this->hasMany(static::class,'parent_id','id');
    }

    // public function entity(){
    //     return $this->belongsTo(Category::class, 'entity_id', 'id');
    // }
    public function assets(){
        return $this->hasMany(Asset::class, 'asset_type_id', 'id');
    }
    public function depreciationSettings(): HasOne{
        return $this->hasOne(DepreciationSetting::class, 'asset_type_id', 'id');
    }
}
