<?php

namespace App\Models\Master;

use App\Models\Company\Location;
use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetVerification extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'VERF'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
        self::softDeleted(function ($model) {
            $model->verifiedAssets->delete();
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'name',
        'start_date',
        'end_date',
        'category_id',
        'asset_type_id',
        'asset_id',
        'verified_by',
        'location_id',
        'entity_id',
        'status',
        'step'
    ];
    protected $casts = [
        'start_date' =>'date',
        'end_date' =>'date',
        'location_id' =>'array',
        'entity_id' =>'array'
    ];

    public function category(){
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
    public function assetType(){
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function verifiedBy(){
        return $this->belongsTo(User::class, 'verified_by', 'id');
    }
    // public function location(){
    //     return $this->belongsTo(Location::class, 'location_id', 'id');
    // }
    // public function entity(){
    //     return $this->belongsTo(Category::class, 'entity_id', 'id');
    // }
    public function verifiedAssets(){
        return $this->hasMany(VerifiedAsset::class, 'verification_id', 'id');
    }
    public function verifiedInventoryAssets(){
        return $this->hasMany(VerifiedAsset::class, 'verification_id', 'id')->where('inventory_id', '<>', null);
    }
}
