<?php
namespace App\Models\Master;

use App\Models\Site\Document;
use App\Models\Inventory\Inventory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class VerifiedAsset extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'unique_id',
        'identification_no',
        'verification_id',
        'inventory_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'capacity_specs',
        'asset_condition',
        'purchase_date',
        'warranty_licence_date',
        'status',
        'allocation_info',
        'remarks',
        'is_active',
        'is_updated'
    ];
    protected $casts = [
        'purchase_date' => 'date',
        'warranty_licence_date' => 'date',
        'allocation_info' => 'array'
    ];
    public function assetVerification(){
        return $this->belongsTo(AssetVerification::class, 'verification_id', 'id');
    }
    public function inventory(){
        return $this->belongsTo(Inventory::class, 'inventory_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
}
