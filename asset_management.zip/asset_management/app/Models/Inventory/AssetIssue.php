<?php

namespace App\Models\Inventory;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Master\Asset;
use App\Models\User\Profile;
use App\Models\Site\Document;
use App\Models\Inventory\Inventory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetIssue extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'asset_id',
        'asset_stock_id',
        'inventory_id',
        'location_id',
        'user_id',
        'expiry',
        'quantity',
        'issued_date',
        'comments',
        'is_accepted',
        'acceptance_otp',
        'is_surrender',
        'allotment_letter',
        'surrender_letter',
        'surrender_comments'
    ];

    protected $casts = [
        'issued_date' =>'date',
    ];
    public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    public function inventory(){
        return $this->belongsTo(Inventory::class, 'inventory_id', 'id');
    }
    public function assetStock(){
        return $this->belongsTo(AssetStock::class, 'asset_stock_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function surrender(){
        return $this->hasOne(AssetSurrender::class, 'asset_issue_id', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
    public function issuedImage(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable')->where('document_type', 'document_allocation');
    }
    public function surrenderedImage(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable')->where('document_type', 'document_surrender');
    }
}
