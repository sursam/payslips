<?php

namespace App\Models\Inventory;

use App\Models\Lease\LeaseItem;
use App\Models\Maintenance\MaintenanceItem;
use Webpatser\Uuid\Uuid;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Master\AssetType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Inventory extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'identification_no',
        'asset_stock_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'capacity_specs',
        'asset_condition',
        'purchase_date',
        'duration',
        'warranty_licence_date',
        'amount',
        'under_maintenance',
        'is_active',
    ];
    protected $casts = [
        'purchase_date' =>'date',
        'warranty_licence_date' =>'date'
    ];
    public function category(): BelongsTo{
        return $this->belongsTo(Category::class);
    }
    public function assettype(): BelongsTo{
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class,'asset_id', 'id');
    }
    public function issue(){
        return $this->hasOne(AssetIssue::class,'inventory_id', 'id')->where('is_surrender', '0');
    }
    public function lease(){
        return $this->hasOne(LeaseItem::class,'inventory_id', 'id')->where('is_completed', '0');
    }
    public function underMaintenance(){
        return $this->hasOne(MaintenanceItem::class,'inventory_id', 'id')->where('status', '0');
    }
    public function dispose(){
        return $this->hasOne(MaintenanceItem::class,'inventory_id', 'id')->where('status', '2');
    }
    public function issues(){
        return $this->hasMany(AssetIssue::class,'inventory_id', 'id');
    }
    public function leases(){
        return $this->hasMany(LeaseItem::class,'inventory_id', 'id');
    }
    public function underMaintenances(){
        return $this->hasMany(MaintenanceItem::class,'inventory_id', 'id');
    }
    public function assetStock(): BelongsTo{
        return $this->belongsTo(AssetStock::class, 'asset_stock_id', 'id');
    }
    // public function surrender(){
    //     return $this->hasOne(AssetIssue::class,'inventory_id', 'id')->where('is_surrender', '1');
    // }

    // public function assetIssue(){
    //     return $this->hasOne(AssetIssue::class,'inventory_id', 'id');
    // }
    public function surrender(){
        return $this->hasMany(AssetIssue::class,'inventory_id', 'id')->where('is_surrender', '1');
    }
    public function assetIssues(){
        return $this->hasMany(AssetIssue::class,'inventory_id', 'id')->latest();
    }
    public function assetLeases(){
        return $this->hasMany(LeaseItem::class,'inventory_id', 'id')->latest();
    }
    // public function leaseCompletion(){
    //     return $this->hasMany(LeaseItem::class,'inventory_id', 'id')->where('is_completed', '1');;
    // }
    public function maintenances(){
        return $this->hasMany(MaintenanceItem::class,'inventory_id', 'id')->latest();
    }


    public function inventoryLeases($leaseId)
    {
        return $this->hasMany(LeaseItem::class, 'inventory_id', 'id')->where('lease_id', $leaseId)->first();
    }
}
