<?php

namespace App\Models\Inventory;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetStockLog extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'asset_stock_id',
        'asset_id',
        'location_id',
        'entity_id',
        'type',
        'quantity',
    ];
}
