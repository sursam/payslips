<?php

namespace App\Models\Inventory;

use Webpatser\Uuid\Uuid;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Company\Location;
use App\Models\Lease\LeaseAgreement;
use App\Models\Maintenance\AssetMaintenance;
use App\Models\Master\AssetType;
use App\Models\Receipt\AssetReceiptNote;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;

class AssetStock extends Model
{
    use HasFactory,HasRecursiveRelationships,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'ASTK'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $appends= ['stockid'];
    protected $fillable = [
        'uuid',
        'unique_id',
        'asset_receipt_note_id',
        'arn_item_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'location_id',
        'entity_id',
        'previous_stock',
        'current_stock',
        'unit',
        'opening_stock',
        'inward_qty',
        'outward_qty',
        'lost',
        'balance_stock',
        'reorder_level',
        'is_active'
    ];

    public function asset(){
        return $this->belongsTo(Asset::class,'asset_id', 'id');
    }

    public function getStockIdAttribute() {
        return 'STK'.str_pad($this->attributes['id'], 6, 0, STR_PAD_LEFT);
    }
    public function inventories(){
        return $this->hasMany(Inventory::class,'asset_stock_id','id');
    }
    public function category(): BelongsTo{
        return $this->belongsTo(Category::class);
    }
    public function assettype(): BelongsTo{
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function location(){
        return $this->belongsTo(Location::class,'location_id','id');
    }
    public function entity(){
        return $this->belongsTo(Category::class,'entity_id','id');
    }

    public function assetIssue(){
        return $this->hasMany(AssetIssue::class,'asset_stock_id','id');
    }
    public function assetMaintenance(){
        return $this->hasMany(AssetMaintenance::class,'asset_stock_id','id');
    }
    public function arn(){
        return $this->belongsTo(AssetReceiptNote::class,'asset_receipt_note_id','id');
    }

    public function lease(){
        return $this->hasMany(LeaseAgreement::class,'asset_stock_id','id');
    }
}
