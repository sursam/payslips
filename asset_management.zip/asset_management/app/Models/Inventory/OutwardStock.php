<?php

namespace App\Models\Inventory;

use Webpatser\Uuid\Uuid;
use App\Models\User\Vendor;
use App\Models\Master\Asset;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;

class OutwardStock extends Model
{
    use HasFactory,HasRecursiveRelationships,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $appends= ['outwardstockid'];

    protected $fillable = [
        'uuid',
        'asset_id',
        'vendor_id',
        'issuing_by',
        'receiving_by',
        'receiving_department',
        'unit',
        'date',
        'qty',
        'qty_issued',
        'qty_rejected',
        'rejection_reason',
        'is_active',
    ];

    public function getOutwardStockIdAttribute() {
        return 'OSTK'.str_pad($this->attributes['id'], 6, 0, STR_PAD_LEFT);
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function vendor(){
        return $this->belongsTo(Vendor::class, 'vendor_id', 'id');
    }
    public function issuing_person(){
        return $this->belongsTo(User::class, 'issuing_by', 'id');
    }
    public function receiving_person(){
        return $this->belongsTo(User::class, 'receiving_by', 'id');
    }
}
