<?php

namespace App\Models\Inventory;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Models\Master\Asset;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;

class InwardStock extends Model
{
    use HasFactory,HasRecursiveRelationships,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $appends= ['inwardstockid'];

    protected $fillable = [
        'uuid',
        'asset_id',
        'vendor_id',
        'approved_by',
        'qty_rejected_by',
        'requisition_person',
        'ordering_by',
        'vendor_invoice',
        'unit',
        'date',
        'qty',
        'requisition_department',
        'rejection_reason',
        'is_active',
    ];

    public function getInwardStockIdAttribute() {
        return 'ISTK'.str_pad($this->attributes['id'], 6, 0, STR_PAD_LEFT);
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function vendor(){
        return $this->belongsTo(Vendor::class, 'vendor_id', 'id');
    }
    public function approved_person(){
        return $this->belongsTo(User::class, 'approved_by', 'id');
    }
    public function qty_rejected_person(){
        return $this->belongsTo(User::class, 'qty_rejected_by', 'id');
    }
    public function ordering_person(){
        return $this->belongsTo(User::class, 'ordering_by', 'id');
    }
    public function requisition_by(){
        return $this->belongsTo(User::class, 'requisition_person', 'id');
    }
}
