<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Webpatser\Uuid\Uuid;

class InvoiceVersion extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'po_invoice_id',
        'version',
        'purchase_order_id',
        'vendor_id',
        'party_invoice_number',
        'invoice_date',
        'billing_location',
        'sub_total',
        'grand_total',
        'tax_type',
        'tax',
        'purchase_order_items',
        'descriptions',
        'terms_conditions',
        'created_by',
        'status',
        'invoice_items',
        'invoice_documents',
        'invoice_approvals'
    ];
    
}
