<?php

namespace App\Models\Module;

use App\Models\User\Permission;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Module extends Model
{
    use HasFactory, SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
        // self::deleting(function ($query) {
        //     $query->modulePermissions()->delete();
        // });
    }
    protected $fillable = [
        'uuid',
        'title',
        'slug',
        'is_active',
        'type',
    ];
    protected $guarded = [];
    public function modulePermissions(): HasMany
    {
        return $this->hasMany(Permission::class, 'module_id', 'id');
    }
}
