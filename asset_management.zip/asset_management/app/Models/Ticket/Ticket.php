<?php

namespace App\Models\Ticket;

use App\Models\Inventory\Inventory;
use Webpatser\Uuid\Uuid;
use App\Models\Site\Category;
use App\Models\Site\Department;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Ticket extends Model
{
    use HasFactory, SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'TKT' . str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'entity_id',
        'department_id',
        'ticket_category_id',
        'inventory_id',
        'subject',
        'description',
        'mobile_number',
        'completed_at',
        'status',
        'attachment_file',
        'priority',

    ];
    protected $casts = [
        'completed_at' => 'date',
    ];
    public function entity(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function ticketCategory(): BelongsTo
    {
        return $this->belongsTo(TicketCategory::class);
    }

    public function activities(): HasMany
    {
        return $this->hasMany(TicketActivity::class, 'ticket_id', 'id');
    }
    public function activity($type)
    {
        return $this->hasOne(TicketActivity::class, 'ticket_id', 'id')->where('type', $type)->orderBy('id', 'DESC')->first();
    }
    public function latestAssignee(array $types)
    {
        return $this->hasOne(TicketActivity::class, 'ticket_id', 'id')
            ->whereIn('type', $types)
            ->orderBy('id', 'DESC')
            ->first();
    }
    public function ccTo(): HasMany
    {
        return $this->hasMany(TicketCc::class, 'ticket_id', 'id');
    }
    public function taggedAsset(): BelongsTo
    {
        return $this->belongsTo(Inventory::class, 'inventory_id', 'id');
    }
    public function getFileSourceAttribute()
    {
        $fileSrc = '';
        if ($this->attachment_file) {
            $extension = pathinfo($this->attachment_file, PATHINFO_EXTENSION);
            switch ($extension) {
                case 'jpg':
                case 'jpeg':
                case 'png':
                    $fileSrc = asset('storage/images/documents/' . $this->attachment_file);
                    break;
                case 'pdf':
                    $fileSrc = asset('assets/images/attachment-pdf.svg');
                    break;
                case 'doc':
                case 'docx':
                    $fileSrc = asset('assets/images/attachment-doc.svg');
                    break;
            }
        }
        return $fileSrc;
    }
}
