<?php

namespace App\Models\Ticket;

use App\Models\Company\Location;
use App\Models\User\User;
use App\Models\Site\Category;
use App\Models\Site\Department;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TicketSetting extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'entity_id',
        'department_id',
        'ticket_category_id',
        'location_ids',
        'department_admin',
        'concerned_persons',
        'is_active'
    ];
    protected $casts = [
        'concerned_persons' =>'array',
        'location_ids' =>'array'
    ];
    public function departmentAdmin(){
        return $this->belongsTo(User::class, 'department_admin', 'id');
    }
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function ticketCategory(){
        return $this->belongsTo(TicketCategory::class, 'ticket_category_id', 'id');
    }
    public function getConcernedPersons($ids){
        return User::whereIn('id', $ids)->get();
    }
    public function getLocations($ids){
        return Location::whereIn('id', $ids)->get();
    }
}
