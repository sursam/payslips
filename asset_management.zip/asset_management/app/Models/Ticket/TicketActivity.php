<?php

namespace App\Models\Ticket;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TicketActivity extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'TACT'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'ticket_id',
        'message',
        'type',
        'attachment_file',
        'user_id',
        'is_updated'
    ];
    public function ticket(): BelongsTo{
        return $this->belongsTo(Ticket::class, 'ticket_id', 'id');
    }
    public function user(): BelongsTo{
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function getFileSourceAttribute(){
        $fileSrc = '';
        if($this->attachment_file){
            $extension = pathinfo($this->attachment_file, PATHINFO_EXTENSION);
            switch($extension){
                case 'jpg':
                case 'jpeg':
                case 'png':
                    $fileSrc = asset('storage/images/documents/'.$this->attachment_file);
                    break;
                case 'pdf':
                    $fileSrc = asset('assets/images/attachment-pdf.svg');
                    break;
                case 'doc':
                case 'docx':
                    $fileSrc = asset('assets/images/attachment-doc.svg');
                    break;
            }
        }
        return $fileSrc;
    }
}
