<?php

namespace App\Models\Ticket;

use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TicketCategory extends Model
{
    use HasFactory, SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'name',
        'parent_id',
        'department_id',
        'description',
        'priority',
        'is_active',
    ];
    public function parent():BelongsTo{
        return $this->belongsTo(static::class,'parent_id','id');
    }
    public function children():HasMany{
        return $this->hasMany(static::class,'parent_id','id');
    }
}
