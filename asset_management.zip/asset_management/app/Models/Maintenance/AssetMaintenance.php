<?php

namespace App\Models\Maintenance;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetMaintenance extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'MTNC'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'asset_stock_id',
        'location_id',
        'title',
        'description',
        'start_date',
        'end_date',
        'status',
        'created_by'
    ];
    protected $casts = [
        'start_date' =>'date',
        'end_date' =>'date'
    ];
    public function maintenanceItems(){
        return $this->hasMany(MaintenanceItem::class,'asset_maintenance_id', 'id');
    }
    public function location(){
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function stock(){
        return $this->belongsTo(AssetStock::class, 'asset_stock_id', 'id');
    }
}
