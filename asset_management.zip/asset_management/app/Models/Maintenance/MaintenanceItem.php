<?php

namespace App\Models\Maintenance;

use Webpatser\Uuid\Uuid;
use App\Models\Inventory\Inventory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MaintenanceItem extends Model
{
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            // $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            // $model->unique_id = 'MTNC'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'asset_maintenance_id',
        'inventory_id',
        'repaired_comments',
        'status'
    ];
    public function inventory(){
        return $this->belongsTo(Inventory::class, 'inventory_id', 'id');
    }
    public function maintenance(){
        return $this->belongsTo(AssetMaintenance::class, 'asset_maintenance_id', 'id');
    }
}
