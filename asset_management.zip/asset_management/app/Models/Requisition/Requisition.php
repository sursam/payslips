<?php

namespace App\Models\Requisition;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Category;
use App\Models\Site\Department;
use App\Models\Site\Document;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Requisition extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {

            $model->uuid = (string) Uuid::generate(4);
            // $unqid = strtoupper(substr(sha1(mt_rand()), 17, 6));
            // $model->unique_id = 'REID'.$unqid;
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'REQS'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
            $model->version = 'V.1.0';
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'version',
        'department_id',
        'category_id',
        'created_by',
        'added_by',
        'entity_id',
        'status',
        'requisition_date',
        'notes',
        'checked_by',
        'approved_by',
        'priority'
    ];
    protected $casts = [
        'requisition_date' =>'date'
    ];
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
    public function requisitionApproval(){
        return $this->hasMany(RequisitionApproval::class, 'requisition_id', 'id');
    }
    public function category(){
        return $this->belongsTo(Category::class);
    }
    public function items()
    {
        return $this->hasMany(RequisitionAssets::class, 'requisition_id', 'id');
    }
    // public function notes()
    // {
    //     return $this->hasMany(RequisitionNote::class, 'requisition_id', 'id');
    // }
    public function approvals()
    {
        return $this->hasMany(RequisitionApproval::class, 'requisition_id', 'id');
    }
    public function versions()
    {
        return $this->hasMany(RequisitionVersion::class, 'requisition_id', 'id');
    }
}
