<?php

namespace App\Models\Requisition;

use Webpatser\Uuid\Uuid;
use App\Models\User\Vendor;
use App\Models\Site\Document;
use App\Models\Location\State;
use App\Models\Requisition\Rfq;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Quotation extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            // $unqid = strtoupper(substr(sha1(mt_rand()), 17, 6));
            // $model->unique_id = 'QUO'.$unqid;
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'QUOT'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'request_id',
        'vendor_id',
        'notes',
        'item_total',
        'discount',
        'discount_type',
        'tax',
        'tax_type',
        'total_amount',
        'status',
        'delivery_state',
        'vendor_state',
        'gst_no',
        'payment_days',
        'delivery_days',
        'purchase_type',
        'payment_mode',
        'advance_percentage',
        'advance_amount',
        'is_selected',
        'is_editable',
        'terms_conditions',
        'remarks'
    ];

    public function rfq(){
        return $this->belongsTo(Rfq::class,'request_id','id');
    }
    public function vendor(){
        return $this->belongsTo(Vendor::class,'vendor_id','id');
    }

    public function items(){
        return $this->hasMany(QuotationItem::class);
    }
    public function rfqVendor($reqid){
        return $this->hasMany(RfqVendor::class,'vendor_id','vendor_id')->where('request_id', $reqid)->first();
    }
    public function deliveryState():HasOne{
        return $this->hasOne(State::class, 'id', 'delivery_state');
    }
    public function vendorState():HasOne{
        return $this->hasOne(State::class, 'id', 'vendor_state');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

}
