<?php

namespace App\Models\Requisition;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\User\Vendor;
use App\Models\Requisition\RfqItem;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Rfq extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'RFQ'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'requisition_id',
        'request_date',
        'validity_date',
        'request_subject',
        'entity_id',
        'department_id',
        'location_id',
        'remarks',
        'quotation_comments',
        'status',
        'is_sent',
        'created_by'
    ];
    protected $casts = [
        'request_date' =>'date',
        'validity_date' =>'date'
    ];

    public function requisition(){
        return $this->belongsTo(Requisition::class);
    }
    public function items(){
        return $this->hasMany(RfqItem::class, 'request_id', 'id');
    }

    public function rqfVendor(){
        return $this->hasMany(RfqVendor::class,'request_id','id');
    }
    public function quotations(){
        return $this->hasMany(Quotation::class, 'request_id', 'id');
    }
    public function approvals()
    {
        return $this->hasMany(RfqApproval::class, 'request_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class,'created_by','id');
    }
}
