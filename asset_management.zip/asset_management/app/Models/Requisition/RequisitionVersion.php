<?php

namespace App\Models\Requisition;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Media;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\Site\Department;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RequisitionVersion extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'requisition_id',
        'version',
        'category_id',
        'entity_id',
        'department_id',
        'requisition_date',
        'comments',
        'created_by',
        'added_by',
        'amount',
        'status',
        'requisition_items',
        'requisition_notes',
        'requisition_documents',
        'requisition_approvals',
    ];
    protected $casts = [
        'requisition_date' =>'date',
        'requisition_items' =>'array',
        'requisition_notes' =>'array',
        'requisition_documents' =>'array',
        'requisition_approvals' =>'array'
    ];

    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function addedBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }


    public function media()
    {
        return $this->hasMany(Media::class, 'user_id', 'id');
    }
    public function image(): MorphMany
    {
        return $this->morphMany(Media::class, 'mediaable');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
    public function category(){
        return $this->belongsTo(Category::class);
    }
}
