<?php

namespace App\Models\Requisition;

use Webpatser\Uuid\Uuid;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Master\AssetType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class QuotationItem extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'QITM'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'quotation_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'quantity',
        'unit',
        'specifications',
        'description',
        'amount',
        'discount_type',
        'discount',
        'tax_type',
        'tax',
        'total_amount',
        'status',
    ];
    public function category(){
        return $this->belongsTo(Category::class);
    }
    public function assetType(){
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
}
