<?php

namespace App\Models\Receipt;

use Webpatser\Uuid\Uuid;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Master\AssetType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetReceiptNoteItem extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'ARNI'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'asset_receipt_note_id',
        'category_id',
        'asset_type_id',
        'asset_id',
        'unit',
        'amount',
        'po_quantity',
        'received_quantity',
        'return_quantity',
        'remaining_quantity',
        'description',
        'specifications',
        'return_reasons',
        'is_active',

    ];
    public function assetType(){
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function assetCategory(){
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function category(): BelongsTo{
        return $this->belongsTo(Category::class);
    }
    public function arn(): BelongsTo{
        return $this->belongsTo(AssetReceiptNote::class,'asset_receipt_note_id','id');
    }
}
