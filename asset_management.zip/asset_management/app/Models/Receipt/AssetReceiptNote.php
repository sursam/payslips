<?php

namespace App\Models\Receipt;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Site\Document;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use App\Models\Purchase\PurchaseOrder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AssetReceiptNote extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'ARNO'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
        self::deleting(function ($query) {
            $query->items()->delete();
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'received_location_id',
        'receiver_id',
        'received_date',
        'purchase_order_id',
        'challan_no',
        'challan_date',
        'created_by',
        'added_by',
        'is_active',
    ];
    protected $casts = [

    ];

    public function purchaseOrder(){
        return $this->belongsTo(PurchaseOrder::class);
    }
    public function receiver(){
        return $this->belongsTo(User::class, 'receiver_id', 'id');
    }
    public function location(){
        return $this->belongsTo(Location::class,'received_location_id','id');
    }

    public function stock(){
        return $this->hasMany(AssetStock::class,'asset_receipt_note_id','id');
    }
    public function items(){
        return $this->hasMany(AssetReceiptNoteItem::class);
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }

}
