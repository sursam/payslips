<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AlternateApprover extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'user_id',
        'approver_id',
        'module_type'
    ];
    public function user() {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    public function approver() {
        return $this->belongsTo(User::class, 'approver_id', 'id');
    }
}
