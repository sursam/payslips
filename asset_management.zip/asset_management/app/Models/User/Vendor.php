<?php

namespace App\Models\User;

use App\Models\Location\City;
use App\Models\Location\State;
use App\Models\Site\Media;
use Webpatser\Uuid\Uuid;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Vendor extends Model
{
    use HasApiTokens,HasFactory,Notifiable,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $appends= [
        'profile_picture', 'full_name', 'vendorid'
    ];
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'mobile_number',
        'type',
        'company_name',
        'state_id',
        'city_id',
        'address',
        'is_active',
        'created_by',
    ];

    public function city(): BelongsTo{
        return $this->belongsTo(City::class, 'city_id', 'id');
    }
    public function state(): BelongsTo{
        return $this->belongsTo(State::class, 'state_id', 'id');
    }
    public function getFullAddressAttribute() {
        $fullAddress = [];
        if ($this->address) {
            $fullAddress[] = $this->address;
        }
        if ($this->city) {
            $fullAddress[] = $this->city->name;
        }
        if ($this->state) {
            $fullAddress[] = $this->state->name;
        }
        return implode(', ', $fullAddress);
    }
    public function createdBy(): BelongsTo{
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function image():MorphMany{
        return $this->morphMany(Media::class,'mediaable');
    }
    public function media(){
        return $this->hasMany(Media::class, 'user_id', 'id');
    }
    public function profilePicture($type = 'original') {
        $profilePicture = $this->media()->where('is_profile_picture', 1)->value('file');
        if(!is_null($profilePicture)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public' && file_exists(public_path('storage/images/' . $type . '/user/' . $profilePicture))){
                return asset('storage/images/' . $type . '/user/' . $profilePicture);
            }
        }
        if(auth()->user() && auth()->user()->profile->gender== 'female') return asset('assets/frontend/images/dummy-user-girl.png');
        return asset('assets/images/user.png');
    }
    public function getProfilePictureAttribute() {
        return $this->profilePicture('original');
    }
    public function getFullNameAttribute() {
        return $this->first_name .(!is_null($this->last_name) ?  ' ' . $this->last_name : '');
    }
    public function getVendorIdAttribute() {
        return 'VDR'.str_pad($this->attributes['id'], 6, 0, STR_PAD_LEFT);
    }


}
