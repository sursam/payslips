<?php

namespace App\Models\User;

use App\Models\Company\Location;
use App\Models\Site\Category;
use App\Models\Site\Department;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Profile extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'uuid',
        'user_id',
        'date_of_joining',
        'designation_id',
        'department_id',
        'sbu_id',
        'division_id',
        'location_id',
        'entity_id',
        'gender',
        'birthday',
        'address',
        'relation',
        'date_of_resign',
        'max_amount'
    ];

    public function user():BelongsTo{
        return $this->belongsTo(User::class);
    }
    public function designation():BelongsTo{
        return $this->belongsTo(Category::class, 'designation_id');
    }
    public function department():BelongsTo{
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
    public function entity():BelongsTo{
        return $this->belongsTo(Category::class, 'entity_id');
    }
    public function sbu():BelongsTo{
        return $this->belongsTo(Category::class, 'sbu_id');
    }
    public function division():BelongsTo{
        return $this->belongsTo(Category::class, 'division_id');
    }
    public function location():BelongsTo{
        return $this->belongsTo(Location::class, 'location_id');
    }
}
