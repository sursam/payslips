<?php

namespace App\Models\User;

use App\Models\Module\Module;
use Illuminate\Database\Eloquent\Model;
// use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Permission extends Model
{
    use HasFactory,SoftDeletes;
    // public function sluggable(): array
    // {
    //     return [
    //         'slug' => [
    //             'source' => 'name'
    //         ]
    //     ];
    // }

    protected $fillable =[
        'name',
        'slug',
        'type',
        'module_id',
    ];
    public function roles():BelongsToMany {
        return $this->belongsToMany(Role::class,'roles_permissions');
    }

    public function scopeNotDashboard($query){
        return $query->whereNotIn('slug', ['view-dashboard','customize-dashboard']);
    }
    public function module():BelongsTo {
        return $this->belongsTo(Module::class, 'module_id', 'id');
    }
}
