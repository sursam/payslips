<?php

namespace App\Models\Site;

use App\Models\Inventory\Inventory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RecentActivity extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'task_name',
        'task_description',
        'task_url',
        'added_by',
        'type',
        'related_id',
        'inventory_id'
    ];
    public function inventory(){
        return $this->belongsTo(Inventory::class,'inventory_id','id');
    }
}
