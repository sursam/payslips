<?php

namespace App\Models\Site;

use App\Models\User\User;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Document extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=[
        'uuid',
        'title',
        'documentable_type',
        'documentable_id',
        'document_type',
        'file',
        'status',
        'created_by'

    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    public function documentable(){
        return $this->morphTo();
    }
    public function user():BelongsTo{
        return $this->belongsTo(User::class,'created_by','id');
    }
}
