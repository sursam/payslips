<?php

namespace App\Models\Site;

use App\Models\Master\AssetType;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Attribute extends Model
{
    use HasFactory,SoftDeletes,Sluggable;

    // protected $table= 'attributes';
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable=[
        'uuid',
        'asset_type_id',
        'name',
        'slug',
        'created_by',
        'updated_by',
        'is_active',
        'order'
    ];

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }
    public function assetType():BelongsTo{
        return $this->belongsTo(AssetType::class, 'asset_type_id', 'id');
    }
    public function categories():BelongsToMany{
        return $this->belongsToMany(Category::class,'category_attributes');
    }


}
