<?php

namespace App\Models\Site;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class EntityDepartmentSetting extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'entity_id',
        'department_id',
        'from_name',
        'from_email',
        'phone_number',
        'is_active'
    ];
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function department(){
        return $this->belongsTo(Department::class, 'department_id', 'id');
    }
}
