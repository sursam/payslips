<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\User\Profile;
use App\Models\Ticket\SlaTime;
use App\Models\Ticket\TicketSetting;
use App\Models\Ticket\TicketCategory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Casts\Attribute;

class Department extends Model
{
    use HasFactory,SoftDeletes;
    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'DEPT'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
        self::softDeleted(function ($model) {
            $model->name= $model->name.'--'.time();
            $model->update();
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'parent_id',
        'department_manager',
        'department_head',
        'name',
        'description',
        'concerned_persons',
        'type',
        'is_active'
    ];
    protected $casts = [
        'concerned_persons' =>'array'
    ];

    public function parentDepartment(){
        return $this->belongsTo($this::class, 'parent_id', 'id');
    }
    public function subDepartments(){
        return $this->hasMany($this::class, 'parent_id', 'id');
    }
    public function departmentManager(){
        return $this->belongsTo(User::class, 'department_manager', 'id');
    }
    public function departmentHead(){
        return $this->belongsTo(User::class, 'department_head', 'id');
    }
    public function employeeProfiles(){
        return $this->hasMany(Profile::class, 'department_id', 'id');
    }
    public function getEmployeesByEntity($entityId){
        return $this->employeeProfiles()->where('entity_id', $entityId)->get();
    }
    public function ticketCategories():HasMany{
        return $this->hasMany(TicketCategory::class, 'department_id', 'id');
    }
    public function getConcernedPersons($ids){
        return User::whereIn('id', $ids)->get();
    }
    public function slaTimes():HasMany{
        return $this->hasMany(SlaTime::class, 'department_id', 'id');
    }
    public function entityDepartmentSettings():HasMany{
        return $this->hasMany(EntityDepartmentSetting::class, 'department_id', 'id');
    }
    public function getSettingsData($entityId){
        return $this->entityDepartmentSettings()->where('entity_id', $entityId)->first();
    }

    public function ticketSettings():HasMany{
        return $this->hasMany(TicketSetting::class, 'department_id', 'id');
    }
    public function getTicketSettingsData($ticketCategoryId, $entityId, $locationId)
    {
        return  $this->ticketSettings()->where(['ticket_category_id' => $ticketCategoryId, 'entity_id' => $entityId])->where('location_ids', 'like', "%\"{$locationId}\"%")->first();
    }
    public function getAllTicketSettingsData($ticketCategoryId, $entityId)
    {
        return  $this->ticketSettings()->where(['ticket_category_id' => $ticketCategoryId, 'entity_id' => $entityId])->get();
    }
    public function getTicketSettingsByEntity($entityId)
    {
        return  $this->ticketSettings()->where(['entity_id' => $entityId])->get();
    }
    // public function ticketSettingsData($ticketCategoryId, $entityId): Attribute
    // {
    //     return new Attribute(
    //         get: fn () => $this->ticketSettings()->where(['ticket_category_id' => $ticketCategoryId, 'entity_id' => $entityId])->first()
    //     );
    // }
}
