<?php

namespace App\Models\Site;

use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class UserWidget extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'user_id',
        'widget_id',
        'position',
        'status'
    ];
    public function user():BelongsTo {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    public function widget():BelongsTo {
        return $this->belongsTo(Widget::class, 'widget_id', 'id');
    }
}
