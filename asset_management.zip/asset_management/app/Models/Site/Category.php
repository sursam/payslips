<?php

namespace App\Models\Site;

use Webpatser\Uuid\Uuid;
use App\Models\Fare\Fare;
use App\Models\User\User;
use App\Models\Vehicle\Vehicle;
use App\Models\Cms\Support;
use App\Models\Master\AssetType;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Staudenmeir\LaravelAdjacencyList\Eloquent\HasRecursiveRelationships;

class Category extends Model
{
    use HasFactory,Sluggable,HasRecursiveRelationships,SoftDeletes;

    protected $fillable= [
        'type_id',
        'entity',
        'name',
        'slug',
        'image',
        'type',
        'parent_id',
        'description',
        'is_active'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
        self::softDeleted(function ($model) {
            $model->name= $model->name.'--'.time();
            $model->update();
        });
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    public function parent(){
        return $this->belongsTo(static::class,'parent_id','id');
    }
    public function children() {
        return $this->hasMany(static::class,'parent_id','id');
    }
    public function media(){
        return $this->morphMany(Media::class,'mediaable');
    }

    public function latestImage(){
        return $this->morphOne(Media::class, 'mediaable');
    }

    public function image():MorphMany{
        return $this->morphMany(Media::class,'mediaable');
    }


    protected function categoryImage($type='original'){
        $file= $this->image()->first()?->file;
        if($file){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public'){
                if(file_exists(public_path('storage/images/' . $type . '/category/' . $file))){
                    return asset('storage/images/' . $type . '/category/' . $file);
                }
            }
        }
        return asset('assets/images/no-image.png');
    }

    public function parentCategory()
    {
        return $this->belongsTo(Category::class, 'parent_id', 'id');
    }

    public function subCategory()
    {
        return $this->hasMany(Category::class, 'parent_id', 'id');
    }
    public function assetType()
    {
        return $this->hasMany(AssetType::class);
    }
}
