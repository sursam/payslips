<?php

namespace App\Models\Booking;

use Webpatser\Uuid\Uuid;
use App\Models\Site\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BookingDetail extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }

    protected $fillable = [
        'uuid',
        'booking_id',
        'doctor_level_id',
        'booking_for',
        'gender',
        'relationship',
        'mobile_number',
        'partner_info',
        'other_info',
        'consultaion_type',
        'survey_results'
    ];
    protected $casts = [
        'partner_info' => 'array',
        'survey_results' => 'array'
    ];
    public function doctorLevel():BelongsTo {
        return $this->BelongsTo(Category::class,'doctor_level_id');
    }
}
