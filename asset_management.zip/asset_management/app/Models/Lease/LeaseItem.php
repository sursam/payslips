<?php

namespace App\Models\Lease;

use App\Models\Inventory\Inventory;
use App\Models\User\User;
use Webpatser\Uuid\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LeaseItem extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
        });
    }
    protected $fillable = [
        'uuid',
        'lease_id',
        'inventory_id',
        'user_id',
        'leased_date',
        'amount',
        'comments',
        'document',
        'is_completed'
    ];
    public function inventory(){
        return $this->belongsTo(Inventory::class, 'inventory_id', 'id');
    }
    public function leaseAgreement(){
        return $this->belongsTo(LeaseAgreement::class, 'lease_id', 'id');
    }
    public function leasedUser(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
