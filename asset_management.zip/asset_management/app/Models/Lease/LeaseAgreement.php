<?php

namespace App\Models\Lease;

use Webpatser\Uuid\Uuid;
use App\Models\User\User;
use App\Models\Master\Asset;
use App\Models\Site\Category;
use App\Models\Site\Document;
use App\Models\Company\Location;
use App\Models\Inventory\AssetStock;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LeaseAgreement extends Model
{
    use HasFactory,SoftDeletes;

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->uuid = (string) Uuid::generate(4);
            $lastId = $model->orderBy('id', 'desc')->pluck('id')->first();
            $model->unique_id = 'LEAS'.str_pad(($lastId + 1), 6, 0, STR_PAD_LEFT);
        });
    }
    protected $fillable = [
        'uuid',
        'unique_id',
        'asset_stock_id',
        'asset_id',
        'location_id',
        'type',
        'entity_id',
        'to_entity_id',
        'responsible_person_id',
        'start_date',
        'end_date',
        'lease_term',
        'lease_term_frequency',
        'lease_type',
        'payment_amount',
        'payment_frequency',
        'vendor_information',
        'renewal_terms',
        'created_by',
        'status'
    ];
    protected $casts = [
        'start_date' =>'date',
        'end_date' =>'date',
        'vendor_information' =>'array'
    ];
    public function leaseItems(){
        return $this->hasMany(LeaseItem::class,'lease_id', 'id');
    }
    public function onGoingLeaseItems(){
        return $this->hasMany(LeaseItem::class,'lease_id', 'id')->where('is_completed', '0');
    }
    public function createdBy(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
    public function location(){
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }
    public function entity(){
        return $this->belongsTo(Category::class, 'entity_id', 'id');
    }
    public function toEntity(){
        return $this->belongsTo(Category::class, 'to_entity_id', 'id');
    }
    public function asset(){
        return $this->belongsTo(Asset::class, 'asset_id', 'id');
    }
    public function assetStock(){
        return $this->belongsTo(AssetStock::class, 'asset_stock_id', 'id');
    }
    public function document(): MorphMany
    {
        return $this->morphMany(Document::class, 'documentable');
    }
    public function getFileSourceAttribute(){
        $fileSrc = '';
        if($this->document){
            $extension = pathinfo($this->document()->value('file'), PATHINFO_EXTENSION);
            switch($extension){
                case 'jpg':
                case 'jpeg':
                case 'png':
                    $fileSrc = asset('storage/images/documents/'.$this->document()->value('file'));
                    break;
                case 'pdf':
                    $fileSrc = asset('assets/images/attachment-pdf.svg');
                    break;
                case 'doc':
                case 'docx':
                    $fileSrc = asset('assets/images/attachment-doc.svg');
                    break;
            }
        }
        return $fileSrc;
    }

    public function getLeaseDocumentAttribute() {
        return $this->leaseDocument();
    }
    public function leaseDocument() {
        $leaseDocument = $this->document()->value('file');

        if(!is_null($leaseDocument)){
            $fileDisk = config('constants.SITE_FILE_STORAGE_DISK');
            if($fileDisk == 'public' && file_exists(public_path('storage/images/documents/' . $leaseDocument))){
                return asset('storage/images/documents/' . $leaseDocument);

            }
        }
        return asset('assets/images/no-image.png');
    }
    // public function scopeFilterByLeaseItemUserId($query, int $userId)
    // {
    //     return $query->whereHas('leaseItems', function ($query) use ($userId) {
    //         // $query->where('user_id', '=', $userId);
    //         $query->where('user_id', '=', null);
    //     });
    // }

    public function scopeFilterByUnallocated($query)
    {
        return $query->whereHas('leaseItems', function ($query)  {
            $query->where('user_id', '=', null);
        });
    }
    
}
