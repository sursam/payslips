import globals from "globals";
import pluginJs from "@eslint/js";
import tseslint from "typescript-eslint";
import pluginReact from "eslint-plugin-react";

/** @type {import('eslint').Linter.Config[]} */
export default [
  {
    name: "eslint-config",
    languageOptions: {
      parser: "@typescript-eslint/parser",
      sourceType: "module",
      ecmaVersion: 2018,
      ecmaFeatures: {
        jsx: true,
      },
    },
    plugins: {
      react: require("eslint-plugin-react"),
      "@typescript-eslint": require("@typescript-eslint/eslint-plugin"),
      prettier: require("eslint-plugin-prettier"),
      "react-hooks": require("eslint-plugin-react-hooks"),
    },
    extends: [
      "plugin:react/recommended",
      "plugin:@typescript-eslint/recommended",
      "prettier",
      "plugin:prettier/recommended",
      "plugin:react-hooks/recommended",
    ],
    rules: {
      "react/jsx-uses-react": "off",
      "multiline-ternary": "off",
      "react/react-in-jsx-scope": "off",
      quotes: ["error", "double"],
      "arrow-parens": ["error", "as-needed"],
    },
    settings: {
      react: {
        version: "detect",
      },
    },
  },
];
