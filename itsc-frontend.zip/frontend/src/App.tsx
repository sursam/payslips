import axios from 'axios';
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Login from './components/Auth/login';
import ForgetPassword from './components/Auth/forget_password';
import Registration from './components/Auth/registration';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Dashboard from './components/Dashboard/dashboard';
import JobList from './components/Job/jobList';
import JobPost from './components/Job/jobPost';
import ViewJob from './components/Job/viewJob'
import ViewProfile from './components/Profile/viewProfile';
import UpdateProfile from './components/Profile/updateProfile';
import Notification from './components/Announcement/Notification';
import PrivateRoute from './utils/PrivateRoute';
import PublicRoute from './utils/PublicRoute';
import LiveTruckList from './components/Job/liveTruckList';
import LiveTruckLoads from './components/Job/liveTruckLoads';
import FaqList from './components/faq/faqList';
import MyRatings from './components/Ratings/myRatings';
import LiveTruckLocation from './components/Job/liveTruckLocation';
import LiveTruckMovements from './components/Job/liveTruckMovements';
import JobAction from './components/Job/jobAction';
import PreApprovedPage from './components/Dashboard/preApprovedPage';
import AnnouncementList from './components/Announcement/announcementList';
import SubContractorList from './components/User/subContractorList';
import AlterSubContractor from './components/User/alterSubContractor';
import ViewSubContractor from './components/User/viewSubContractor';
import PermissionSubContractor from './components/User/permissionSubContractor';
import PaymentHistory from './components/paymentHistory/paymentHistory';
import PaymentInfo from './components/paymentInfo/paymentInfo';
import './styles/app.css';

const theme = createTheme({
  typography: {
    fontFamily: ['Poppins', 'sans-serif'].join(','),
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          fontSize: '.9rem',
          fontWeight: 500,
          padding: '10px 20px',
          margin: '10px 0',
          textTransform: 'capitalize',
          borderRadius: '5px',
          textDecoration: 'none',
          color: '#000000',
          '&:hover': {
            backgroundColor: '#d3d3d3',
          }
        },
        contained: {
          color: '#fff',
          '&:hover': {
            backgroundColor: '#303f9f',
          },
        },
        outlined: {
          borderColor: '#3f51b5',
          color: '#3f51b5',
          '&:hover': {
            borderColor: '#303f9f',
            color: '#303f9f',
          },
        },
      },
    },
    MuiFormControl: {
      styleOverrides: {
        root: {
          '& .MuiInputBase-root': {
            border: 0,
            borderRadius: '8px',
            padding: '10px 14px',
            '&:hover': {
              border: 0,
            },
            '&.Mui-focused': {
              border: 0,
              outline: 'none',
            },
          },
          '& .MuiInputLabel-root': {
            color: '#84818A'
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        input: {
          padding: '4px 0 5px',
          border: 0
        },
      },
    },
  },
});


// Global flag to prevent multiple redirects - outside component to persist
let isRedirecting = false;

// Function to clear all auth data
const clearAuthData = () => {
  const authKeys = ['@jwt', 'token', 'device-token', 'userDetails', 'memberId', 'completedSteps', 'doesPaymentNeeded', 'isSubContractor'];
  authKeys.forEach(key => {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
  });
};

// Function to get token from various possible storage keys
const getAuthToken = () => {
  return localStorage.getItem('@jwt') ||
    localStorage.getItem('token') ||
    sessionStorage.getItem('@jwt') ||
    sessionStorage.getItem('token');
};

// Global 401 Handler Component
const Global401Handler: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const responseInterceptor = axios.interceptors.response.use(
      (response) => response,
      (error) => {
        console.log('Axios error intercepted:', error.response?.status);

        // Handle 401 Unauthorized
        if (error.response?.status === 401) {
          if (!isRedirecting) {
            isRedirecting = true;

            console.log('401 Unauthorized - Clearing auth data and redirecting');

            // Clear all auth data
            clearAuthData();

            // Call auth context token expiration handler if available
            if ((window as any).handleTokenExpiration) {
              (window as any).handleTokenExpiration();
            }

            // Show error toast
            toast.error('Your session has expired. Please login again.', {
              toastId: 'session-expired', // Prevent duplicate toasts
              onClose: () => {
                isRedirecting = false; // Reset flag when toast closes
              }
            });

            // Small delay to ensure localStorage is cleared before navigation
            setTimeout(() => {
              navigate('/', { replace: true });
              // Reset flag after navigation
              setTimeout(() => {
                isRedirecting = false;
              }, 100);
            }, 100);
          }
        }

        // Handle 403 Forbidden
        if (error.response?.status === 403) {
          toast.error('Access denied. You do not have permission to perform this action.', {
            toastId: 'access-denied'
          });
        }

        // Handle 5xx server errors
        if (error.response?.status >= 500) {
          toast.error('Server error. Please try again later.', {
            toastId: 'server-error'
          });
        }

        return Promise.reject(error);
      }
    );

    const requestInterceptor = axios.interceptors.request.use(
      (config) => {
        const token = getAuthToken();
        if (token && token !== 'null' && token !== 'undefined') {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Cleanup function
    return () => {
      axios.interceptors.response.eject(responseInterceptor);
      axios.interceptors.request.eject(requestInterceptor);
    };
  }, [navigate]);

  return null;
};


const App: React.FC = () => {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        {/* Global 401 handler - must be inside Router to access navigate */}
        <Global401Handler />

        <ToastContainer
          position="top-right"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          className="toast-container"
        />

        <Routes>
          {/* Public Routes */}
          <Route element={<PublicRoute />}>
            <Route path='/' element={<Login />} />
            <Route path='/forgot-password' element={<ForgetPassword />} />
            <Route path='/sign-up' element={<Registration />} />
          </Route>

          {/* Private Routes */}
          <Route element={<PrivateRoute />}>
            <Route path='/dashboard' element={<Dashboard />} />
            <Route path='/profile' element={<ViewProfile />} />
            <Route path='/notification' element={<Notification />} />
            <Route path='/profile/edit' element={<UpdateProfile />} />
            <Route path='/job-list' element={<JobList />} />
            <Route path='/post-job/:id?' element={<JobPost isDraft={1} />} />
            <Route path='/edit-job/:id?' element={<JobPost />} />
            <Route path='/view-job/:id' element={<ViewJob />} />
            <Route path='/live-trucks' element={<LiveTruckList />} />
            <Route path='/job-action' element={<JobAction />} />
            <Route path='/live-truck-loads/:id' element={<LiveTruckLoads />} />
            <Route path='/live-truck-location/:id/:lid' element={<LiveTruckLocation />} />
            <Route path='/live-truck-movements' element={<LiveTruckMovements />} />
            <Route path="/faqs" element={<FaqList />} />
            <Route path='/my-ratings' element={<MyRatings />} />
            <Route path='/pre-approved' element={<PreApprovedPage />} />
            <Route path='/job-notification' element={<AnnouncementList />} />
            <Route path='/sub-contractor-list' element={<SubContractorList />} />
            <Route path='/add-sub-contractor' element={<AlterSubContractor />} />
            <Route path='/edit-sub-contractor/:uuid?' element={<AlterSubContractor />} />
            <Route path='/view-sub-contractor/:uuid?' element={<ViewSubContractor />} />
            <Route path='/sub-contractor-permissions/:uuid?' element={<PermissionSubContractor />} />
            <Route path='/payment-history' element={<PaymentHistory />} />
            <Route path='/payment-info' element={<PaymentInfo />} />
          </Route>
        </Routes>
      </Router>
    </ThemeProvider >
  );
}

export default App;
