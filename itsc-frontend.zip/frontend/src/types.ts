export interface walletrecharge {
	member_id: string | null;
	wallet_amount: any;
}

export interface transUpdate {
	id: string | null;
	payment_status: string;
}

export interface transDetails {
	member_id: string | null;
}

export interface PaymentOption {
	mode: "payment" | "setup" | "subscription"; // Specific string literal type
	amount: number;
	currency: string;
	clientSecret: string; // Ensure this is just string
}
export interface CheckoutFormProps {
	id: string;
	stripeData: any;
}
export interface SubscriptionType {
	member_id: string | null;
	subscription_id: string | null;
	price: number;
}
export interface Subscription {
	_id: string;
	name: string;
}
export interface SubscriptionListResponse {
	subscription: Subscription[];
}
export interface VerifyPaymentType {
	status: string;
	member_id: string;
	paymentIntent_id: string;
	payment_respons: {
		id: string;
		object: string;
		amount: number;
		amount_capturable: number;
		amount_received: number;
		application: string | null;
	};
}
export interface TransactionResponse {
	data: {
		message: string;
		data: [];
	};
}
export interface UsePaginationTypes {
	totalCount: number;
	pageSize: number;
	siblingCount?: number;
	currentPage: number;
}
export interface RowData {
	transaction_date: string;
	amount: number;
	transaction_status: string;
	payment_status: string;
	// status: string;
	payment_type: string;
}
export interface AdminSubscription {
	name: string;
	price: number;
	type: string;
	duration: number;
	description: string;
}

export interface PlatformType {
	name: string;
	value: number;
	description: string;
}

export type EmailVerificationType = "forgotemail" | "otp" | "password" | "email";
export interface VerificationPayload {
	type: EmailVerificationType;
	email: string;
	role?: string;
	otp?: string;
	password?: string;
	confirmPassword?: string;
}

export interface AnnouncementType {
	_id?: string;
	subject: string;
	date: string; // Ensure this line is present
	description: string;
	link?: string | undefined;
	image?: File | undefined; // URL for the uploaded image if provided by API
	createdAt?: string;
}

/* =================================================================================================================
                                                 conectar props |    |   |   |   |   |   |   |   |   |   |   |   |   |
    ================================================================================================================ */

export interface ProfileProps {
	fname: string;
	lname: string;
	country_code: string;
	mobile: string;
	email: string;
	dob: string;
	address: string;
	days_ago: string;
	my_jobs: string;
	average_rating: string;
	city: string;
	state: string;
	country: string;
	pincode: string;
	profile_image: string;
	complete_profile_info: {
		company_legal_name: string;
		company_dba: string;
		phone_2: string;
		tax_id: string;
	};
	country_details: {
		country_id: string;
		country_name: string;
	};

	state_details: {
		state_id: string;
		state_name: string;
	};

	city_details: {
		id: string;
		name: string;
	};
}
export interface shouldIReadyForJobPost {
	is_ready_for_job: boolean;
	is_payment_needed: boolean;
	interval_in_days: number;
	is_bank_details_updated: boolean;
	message: string;
}
export interface JobStatisticsProps {
	totalPostedJobs: number;
	pendingJobs: number;
	completedJobs: number;
	draftedJobs: number;
}
export interface BannerProps {
	banner_title: string;
	banner_image: string;
	banner_url: string;
}
export interface ActiveJobCodinates {
	id: number;
	unique_id: string;
	user_id: number;
	job_status: number;
	source: string;
	source_lat: string;
	source_lng: string;
	destination: string;
	delivery_lat: string;
	delivery_lng: string;
	pickup_date_time: string;
	delivery_date_time: string;
	contractor_details: {
		id: number;
		fname: string;
		lname: string;
		country_code: number;
		mobile: string;
		email: string;
	};
}
export interface CurrentLocation {
	lat: number;
	lng: number;
}
export interface UpcomingPickupsProps {
	id: string;
	unique_id: string;
	material_name: string;
	material_other: string;
	created_at: string;
	pickup_date_time: string;
	job_estimate_price: number;
	delivery_date_time: string;
	no_of_trucks: number;
}
export interface JobListProps {
	id: string;
	unique_id: string;
	material_name: string;
	material_other: string;
	created_at: string;
	pickup_date_time: string;
	job_estimate_price: number;
	delivery_date_time: string;
	no_of_trucks: number;
	is_available_for_edit: boolean;
	created_user: string;
	created_by: number;
}
export interface ReviewProps {
	given_contractor: {
		id: number;
		fname: string;
		lname: string;
		country_code: number;
		mobile: string;
		email: string;
		profile_image: string;
	};
	feedback: string;
	rating: string;
	created_at: string;
}
export interface RatingDistributionProps {
	avg: number;
	rating_percentage: {
		five_star: number;
		four_star: number;
		three_star: number;
		two_star: number;
		one_star: number;
	};
}
export interface FaqProps {
	question: string;
	answer: string;
	video_code: string;
	link: string;
}
export interface RunningJobLoadProps {
	load_id: number;
	load_index: number;
	trucker_details: {
		id: number;
		fname: string;
		lname: string;
		country_code: number;
		mobile: string;
		email: string;
	};
	job_details: {
		id: number;
		user_id: number;
		unique_id: string;
		source: string;
		destination: string;
		pickup_date_time: string;
		delivery_date_time: string;
		source_lat: string;
		source_lng: string;
		destination_lat: string;
		destination_lng: string;
		job_status: number;
	};
	trucker_current_lat: string;
	trucker_current_lng: string;
}
export interface StripeInitiateProps {
	customer: string;
	initiate_payment_reference: string;
	setupIntent: string;
	ephemeral_key: string;
	stripe_publishable_key: string;
	stripe_secret_key: string;
	amount: number;
	currency: string;
}
export interface ContractorDetailsProps {
	id: number;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
}
export interface LiveMarkerJobProps {
	id: number;
	unique_id: string;
	user_id: number;
	job_status: number;
	source: string;
	source_lat: string;
	source_lng: string;
	destination: string;
	delivery_lat: string;
	delivery_lng: string;
	pickup_date_time: string;
	delivery_date_time: string;
	contractor_details: ContractorDetailsProps;
}
export interface MarkerProps {
	lat: string;
	lng: string;
	unique_id: string;
	job: LiveMarkerJobProps;
	onClick: () => any;
}
export interface JobDetailsProps {
	unique_id: string;
	source: string;
	destination: string;
	pickup_date_time: string;
	delivery_date_time: string;
	source_lat: string;
	source_lng: string;
	delivery_lat: string;
	delivery_lng: string;
	pickup_location_company: string;
	pickup_location_contact_no: string;
	pickup_location_email: string;
	pickup_contact: string;
	drop_off_location_company: string;
	drop_off_location_contact_no: string;
	drop_off_location_email: string;
	drop_off_contact: string;
	created_at: string;
	material_name: string;
	material_other: string;
	order_no: string;
	total_mileage: string;
	total_load: string;
	equipment_id: string;
	equipment_name: string;
	equipment_other: string;
	load_spacing_minutes: string;
	available_load_count: string;
	truck_details: TrucksProps[];
	is_hourly: number;
	per_unit_price: string;
	job_estimate_price: string;
	notes: string | null;
}
export interface TrucksProps {
	truck_type_id: string;
	name: string;
	specs: string;
	weight_capacity: string;
	trucktype_image: string;
}
export interface JobLoadsProps {
	id: string;
	job_id: string;
	cancellation_request_id: string;
	completed_on: string;
	contractor_added_weight: string;
	pickup_date_time: string;
	delivery_date_time: string;
	discounted_load_cost: string;
	driver_load_weight: string;
	feedback: {
		comment: string;
		rating: string;
	};
	is_discarded: string;
	weight: string;
	status: number;
	load_spacing: string;
	load_cost: string;
	trucker_details: TrucksProps;
	pickup_latitude: string;
	pickup_longitude: string;
	delivery_latitude: string;
	delivery_longitude: string;
}
export interface LoadInfoProps {
	id: string;
	status: number;
	feedback?: { comment: string; rating: string };
}
export interface TruckerProps {
	id: string;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
	profile_image: string;
	rating: string;
	truck_type?: string;
	weight_capacity?: number;
	truck_type_image?: string;
}
export interface TruckTypesProps {
	name: string;
	specs: string;
	truck_type_id: string;
	trucktype_image: string;
	weight_capacity: string;
}
export interface DriverEndJobRequestProps {
	job_id: number;
	load_id: number;
	contracter_name: string;
	load_actual_weight: string;
	trucker_taken_weight: string;
	ticket_no: string;
	challan: string;
	signed_challan: string;
	trucker_notes: string;
	additional_note: string;
	is_ticket_signed: number;
}
export interface SubContractorProps {
	uuid: string;
	first_name: string;
	last_name: string;
	email: string;
	state: any;
	city: any;
	created_at: string;
}

export interface CountryDetailsProps {
	country_id: number;
	iso: string;
	country_name: string;
	phone_code: string;
}

export interface StateDetailsProps {
	state_id: number;
	state_name: string;
	country_id: number;
}

export interface CityDetailsProps {
	id: number;
	state_id: number;
	name: string;
}

export interface CompleteProfileInfoProps {
	company_legal_name: string;
	tax_id: string;
	company_dba: string;
	phone_2: number;
	country_code: string;
	company_ein: string;
	driving_license_no: string;
	driving_license_expiery: string;
}

export interface UserProps {
	id: number;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
	language: number;
	completed_steps: number;
	user_role: number;
	profile_image: string;
	address: string;
	pincode: number;
	dob: string;
	total_job: number;
	average_rating: string;
	days_ago: number;
	is_available: number;
	country_details: CountryDetailsProps;
	state_details: StateDetailsProps;
	city_details: CityDetailsProps;
	complete_profile_info: CompleteProfileInfoProps;
	todayTotalWorkingHours: number;
	total_unread_job_alerts: number;
	total_normal_job_alerts: number;
	my_jobs: number;
	remaining_payment_days: number;
	can_post_job: boolean;
	pending_actions_on_job: number;
	is_payment_pending: boolean;
	kyc_updation_link: string | null;
	user_type: number;
	is_any_running_jobLoad_exist: boolean;
	payment_terms: number;
	permissions: string[];
	user_role_slug: string;
}

export interface AuthStateProps {
	user: UserProps | null;
	token: string | null;
	isLoggedIn: boolean;
}

export interface CardDetails {
	brand: string;
	last4: string;
	exp_month: number;
	exp_year: number;
}

export interface PaymentMethodProps {
	id: string;
	type: string;
	card?: CardDetails;
}

export interface PaymentIntentProps {
	payment_intent_id: string;
	amount_processed: number;
	currency: string;
	status: string;
	amount_received: number;
	created_at: string;
	capture_method: string;
	description: string;
	latest_charge: string | null;
}

export interface PaymentEntry {
	paymentIntent: PaymentIntentProps;
	paymentMethod: PaymentMethodProps | null;
}

export interface PaymentData {
	total_paid: string;
	payments: PaymentEntry[];
}

export interface PaymentHistoryResponse {
	data: PaymentData;
}
