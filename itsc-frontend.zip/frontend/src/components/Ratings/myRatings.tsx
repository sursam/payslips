import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import { can } from "../../utils/helper";
import {
	Box,
	Card,
	CardContent,
	Grid,
	Typography,
	Avatar,
	Rating,
	LinearProgress,
	Stack,
	Skeleton,
	CircularProgress
} from '@mui/material';
import moment from 'moment';
import LayoutProvider from '../../providers/LayoutProvider';
import { ReviewProps, RatingDistributionProps } from '../../types';

const RatingSkeleton: React.FC = () => {
	return (
		<Box sx={{ maxWidth: '1500px', margin: '0 auto', padding: 1 }}>
			<Card elevation={3} sx={{ padding: 3, backgroundColor: '#fff' }}>
				<Grid container spacing={2}>
					{/* Left: Reviews Section Skeleton */}
					<Grid size={{ xs: 12, lg: 8 }}>
						<Stack spacing={3}>
							{Array.from({ length: 3 }).map((_, index) => (
								<Card key={index} elevation={0} sx={{ padding: 0 }}>
									<Box
										sx={{
											display: 'flex',
											alignItems: 'flex-start',
											gap: 2,
											borderBottom: '1px solid #E7E7E7',
											paddingBottom: 2,
										}}
									>
										<Skeleton variant="circular" width={50} height={50} />
										<Box sx={{ flex: 1 }}>
											<Box
												sx={{
													display: 'flex',
													justifyContent: 'space-between',
													alignItems: 'flex-start',
													mb: 1,
												}}
											>
												<Skeleton variant="text" width="40%" height={24} />
												<Skeleton variant="text" width="30%" height={16} />
											</Box>
											<Skeleton variant="rectangular" width="30%" height={20} sx={{ mb: 1 }} />
											<Skeleton variant="text" width="100%" height={40} />
										</Box>
									</Box>
								</Card>
							))}
						</Stack>
					</Grid>

					{/* Right: Rating Summary Skeleton */}
					<Grid size={{ xs: 12, lg: 4 }}>
						<Stack spacing={3}>
							<Card
								elevation={2}
								sx={{
									backgroundColor: '#F7F7F7',
									padding: 3,
									borderRadius: 2,
									boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
								}}
							>
								<Box sx={{ textAlign: 'center', mb: 3 }}>
									<Skeleton variant="text" width="40%" height={40} sx={{ mx: 'auto', mb: 1 }} />
									<Skeleton variant="rectangular" width={120} height={24} sx={{ mx: 'auto' }} />
									<Skeleton variant="text" width="30%" height={20} sx={{ mx: 'auto', mt: 1 }} />
								</Box>

								<Stack spacing={2}>
									{Array.from({ length: 5 }).map((_, index) => (
										<Box key={index} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
											<Skeleton variant="text" width={20} height={20} />
											<Skeleton variant="rectangular" width={20} height={20} />
											<Skeleton variant="rectangular" width="100%" height={8} sx={{ borderRadius: 4 }} />
											<Skeleton variant="text" width={35} height={20} />
										</Box>
									))}
								</Stack>
							</Card>
						</Stack>
					</Grid>
				</Grid>
			</Card>
		</Box>
	);
};

const MyRatings: React.FC = () => {
	const [myReviews, setMyReviews] = React.useState<ReviewProps[]>([]);
	const [ratingDistributions, setRatingDistributions] = React.useState<RatingDistributionProps | null>(null);
	const [isLoading, setIsLoading] = React.useState<boolean>(true);
	const navigate = useNavigate();

	const fetchMyReviews = async () => {
		setIsLoading(true);
		try {
			const response = await api.activity.fetchMyReviews();
			if (response) {
				setMyReviews(response?.data || []);
				setRatingDistributions(response?.overall || null);
			}
		} catch (error) {
			console.error("Failed to fetch reviews:", error);
		} finally {
			setIsLoading(false);
		}
	};

	useEffect(() => {
		if (!can(['view-ratings'])) {
			navigate(`/dashboard`);
		}
		fetchMyReviews();
	}, []);

	// Safe distributions mapping with fallback
	const distributions = ratingDistributions?.rating_percentage
		? Object.entries(ratingDistributions.rating_percentage)
			.map(([key, value]) => {
				const starMapping: { [key: string]: number } = {
					five_star: 5,
					four_star: 4,
					three_star: 3,
					two_star: 2,
					one_star: 1
				};
				return {
					stars: starMapping[key] || 0,
					percentage: value || 0
				};
			})
			.sort((a, b) => b.stars - a.stars)
		: [];

	return (
		<LayoutProvider pageTitle="My Ratings">
			{isLoading ? (
				<RatingSkeleton />
			) : (
				<Box sx={{ maxWidth: '1500px', margin: '0 auto', padding: 1 }}>
					<Card elevation={3} sx={{ padding: 3, backgroundColor: '#fff' }}>
						<Grid container spacing={2}>
							{/* Left: Reviews Section */}
							<Grid size={{ xs: 12, lg: 8 }}>
								{myReviews.length === 0 ? (
									<Box sx={{ textAlign: 'center', py: 4 }}>
										<Typography variant="h6" color="text.secondary">
											No reviews available yet
										</Typography>
									</Box>
								) : (
									<Stack spacing={3}>
										{myReviews.map((review, index) => (
											<CardContent key={index} sx={{ padding: 0 }}>
												<Box sx={{
													display: 'flex',
													alignItems: 'flex-start',
													gap: 2,
													borderBottom: index === myReviews.length - 1 ? 'none' : '1px solid #E7E7E7',
													paddingBottom: 2
												}}>
													<Avatar
														src={review?.given_contractor?.profile_image}
														sx={{ width: 50, height: 50 }}
													>
														{`${review?.given_contractor?.fname?.charAt(0) || ''}${review?.given_contractor?.lname?.charAt(0) || ''}`}
													</Avatar>
													<Box sx={{ flex: 1 }}>
														<Box sx={{
															display: 'flex',
															justifyContent: 'space-between',
															alignItems: 'flex-start',
															mb: 1
														}}>
															<Typography variant="h6" fontWeight="bold">
																{`${review?.given_contractor?.fname || ''} ${review?.given_contractor?.lname || ''}`}
															</Typography>

															<Box sx={{ display: 'flex', flexDirection: 'column', textAlign: 'right' }}>
																<Typography variant="caption" color="text.secondary">
																	Posted:
																</Typography>
																<Typography variant="caption" sx={{ fontWeight: 'bold', color: '#000', fontSize: '12px' }}>
																	{moment(review?.created_at).format('DD MMM YYYY | HH:mm:ss')}
																</Typography>
															</Box>
														</Box>

														<Box sx={{ mb: 1 }}>
															<Rating
																value={parseInt(review?.rating) || 0}
																readOnly
																size="small"
															/>
														</Box>

														<Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.6 }}>
															{review?.feedback || 'No feedback provided'}
														</Typography>
													</Box>
												</Box>
											</CardContent>
										))}
									</Stack>
								)}
							</Grid>

							{/* Right: Rating Summary */}
							<Grid size={{ xs: 12, lg: 4 }}>
								<Stack spacing={3}>
									{/* Overall Rating Card */}
									<Card elevation={2} sx={{
										backgroundColor: '#F7F7F7',
										padding: 3,
										borderRadius: 2,
										boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
									}}>
										<Box sx={{ textAlign: 'center', mb: 3 }}>
											<Typography variant="h3" fontWeight="bold" color="primary" sx={{ mb: 1 }}>
												{ratingDistributions?.avg?.toFixed(2) || '0.00'}
											</Typography>
											<Rating
												value={ratingDistributions?.avg || 0}
												readOnly
												precision={0.1}
												size="medium"
											/>
											<Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
												{myReviews?.length || 0} Ratings
											</Typography>
										</Box>

										<Stack spacing={2}>
											{distributions.map((item) => (
												<Box key={item.stars} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
													<Typography variant="body2" fontWeight="bold" sx={{ minWidth: 20 }}>
														{item.stars}
													</Typography>
													<Rating
														value={1}
														max={1}
														readOnly
														size="small"
														sx={{ color: '#fbc02d' }}
													/>
													<Box sx={{ flex: 1, mx: 1 }}>
														<LinearProgress
															variant="determinate"
															value={item.percentage}
															sx={{
																height: 8,
																borderRadius: 4,
																backgroundColor: '#e0e0e0',
																'& .MuiLinearProgress-bar': {
																	backgroundColor: '#4caf50',
																	borderRadius: 4,
																}
															}}
														/>
													</Box>
													<Typography variant="body2" color="text.secondary" sx={{ minWidth: 35 }}>
														{item.percentage}%
													</Typography>
												</Box>
											))}
										</Stack>
									</Card>
								</Stack>
							</Grid>
						</Grid>
					</Card>
				</Box>
			)
			}

		</LayoutProvider >
	);
};

export default MyRatings;