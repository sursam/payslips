import React from 'react';
import { useForm } from 'react-hook-form';
import {
	Box,
	Button,
	Fade,
	FormControl,
	Grid,
	Modal,
	TextField,
	Typography,
} from '@mui/material';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import styles from "../../../styles/viewJob.module.css";

interface ChildProps {
	jobId: string;
	loadId: string;
	loadPrice: string;
	open: boolean;
	onClose: () => void;
	onSubmitPrice: (jobId: string, loadId: string, price: string) => void;
}
const ChangePrice: React.FC<ChildProps> = ({ jobId, loadId, loadPrice, open, onClose, onSubmitPrice }) => {
	const [newPrice, setNewPrice] = React.useState('');
	const validationSchema = Yup.object().shape({
		price: Yup.string().required('Price is required'),
	});
	const {
		register,
		handleSubmit,
		formState: { errors },
		reset
	} = useForm({
		resolver: yupResolver(validationSchema)
	});
	const onSubmit = (data: { price: string }) => {
		onSubmitPrice(jobId, loadId, data.price);
		onClose();
		reset();
	};

	return (
		<Modal
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			open={open}
			onClose={onClose}
			closeAfterTransition
			slotProps={{
				backdrop: {
					timeout: 500,
				},
			}}
		>
			<Fade in={open}>
				<Box className={styles.modalBox}>
					<div className={styles.modalHeader}>
						<Typography id="transition-modal-title" className={styles.modalTitle}>
							Change Price
						</Typography>
						<input type='hidden' value={loadId} />
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: 'red',
								border: '1px solid red',
								borderRadius: '4px',
								padding: '4px',
								'&:hover': {
									backgroundColor: 'rgba(255, 0, 0, 0.1)',
								}
							}}
						>
							<CloseIcon />
						</IconButton>
					</div>

					<div className={styles.contentContainer}>
						<div className={styles.priceWrap}>
							<Typography sx={{
								fontSize: 12,
								fontWeight: 400,
								fontFamily: 'Poppins',
								color: '#888',
								fontStyle: 'italic'
							}}>
								Old Load Price :
							</Typography>
							<Typography sx={{
								fontSize: 16,
								fontWeight: 600,
								fontFamily: 'Poppins'
							}}>
								${loadPrice}
							</Typography>
						</div>
						<form onSubmit={handleSubmit(onSubmit)}>
							<Grid container spacing={3} sx={{ mb: 3 }}>
								<FormControl fullWidth>
									<TextField
										label="Enter New Price"
										variant="outlined"
										fullWidth
										margin="normal"
										{...register("price")}
										error={!!errors?.price}
										helperText={!!errors?.price}
										className={`${styles.formControl} ${errors?.price ? 'is-invalid' : ''}`}
									/>
									<div className="invalid-feedback">{errors.price?.message?.toString()}</div>
								</FormControl>
							</Grid>
							<Button
								variant="contained"
								type="submit"
								sx={{
									fontFamily: 'Poppins, sans-serif',
									fontWeight: 600,
									textTransform: 'none',
									backgroundColor: '#005DAA',
									borderRadius: '8px',
									padding: '8px 24px',
									'&:hover': {
										backgroundColor: '#004A8A'
									}
								}}
							>
								Submit
							</Button>
						</form>
					</div>
				</Box>
			</Fade>
		</Modal>
	);
};

export default ChangePrice;