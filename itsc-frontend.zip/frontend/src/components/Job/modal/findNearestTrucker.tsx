import React, { use, useCallback, useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../../../utils/api';
import {
	Typography,
	Button,
	Box,
	Modal,
	Slide
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import styles from "../../../styles/viewJob.module.css";
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import StarIcon from '@mui/icons-material/Star';
import { toast } from 'react-toastify';


interface ChildProps {
	jobId: string;
	open: boolean;
	onClose: () => void;
	truckers: any[];
}
interface sendJobRequest {
	jobId: string;
	userId: number
}

const FindNearestTrucker: React.FC<ChildProps> = ({ jobId, open, onClose, truckers }) => {
	const handleSendRequest = async (userId: number) => {
		try {

			const payload: sendJobRequest = { jobId, userId };

			const response = await api.job.notifyTruckers(jobId, userId);
			if (response?.status) {
				toast.success(response?.message);
				onClose();
			} else {
				toast.error(response?.message);
			}

		} catch (error) {
			console.error('Failed to send request:', error);
		}

	}
	return (
		<Modal
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			open={open}
			onClose={onClose}
			closeAfterTransition
			slotProps={{
				backdrop: {
					timeout: 500,
				},
			}}
		>
			<Slide in={open} direction="left" mountOnEnter unmountOnExit>
				<Box className={styles.modalBox}>
					<div className={styles.modalHeader}>
						<Typography id="transition-modal-title" className={styles.modalTitle}>
							Nearest Trucker List
						</Typography>
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: 'red',
								border: '1px solid red',
								borderRadius: '4px',
								padding: '4px',
								'&:hover': {
									backgroundColor: 'rgba(255, 0, 0, 0.1)',
								}
							}}
						>
							<CloseIcon />
						</IconButton>
					</div>

					<div className={styles.contentContainer}>
						{truckers.length > 0 ? truckers.map((trucker: any) => (
							<div className={styles.truckerItem}>
								<div className={styles.truckerInfo}>
									<div className={styles.truckerAvatarContainer}>
										<img
											src={trucker.profile_image}
											alt={trucker.fname + ' ' + trucker.lname}
											className={styles.truckerAvatar}
										/>
										{parseFloat(trucker.rating) > 0 && <div className={styles.ratingContainer}>
											<StarIcon className={styles.starIcon} />
											<span className={styles.rating}>{trucker.rating}</span>
										</div>
										}
									</div>

									<div className={styles.truckerDetails}>
										<div className={styles.truckerName}>
											<PersonIcon className={styles.personIcon} />
											{trucker.fname + ' ' + trucker.lname}
										</div>
										<div className={styles.truckerEmail}>
											<EmailIcon className={styles.emailIcon} />
											{trucker.email}
										</div>
									</div>
								</div>
								<Button
									className={styles.sendRequestButton}
									onClick={() => handleSendRequest(trucker.id)}
								>
									Send Request
								</Button>
							</div>
						)) : (
							<div className={styles.noTruckersContainer}>
								<img
									src="/assets/images/no_nearest_trucker.png"  // Update with correct image path
									alt="No truckers found"
									className={styles.errorImage}
								/>
								<Typography
									className={styles.errorMessage}
								>
									Sorry! No Truckers Found
								</Typography>
								<Button
									className={styles.retryButton}
								>
									Find Again?
								</Button>
							</div>
						)}
					</div>
				</Box>
			</Slide>
		</Modal>
	);
};

export default FindNearestTrucker;