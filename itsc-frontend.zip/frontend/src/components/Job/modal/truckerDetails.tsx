// import React, { useEffect } from 'react';
// import {
// 	Box,
// 	Fade,
// 	Modal,
// 	Typography,
// 	IconButton,
// 	Grid,
// 	FormControl,
// 	TextField,
// 	Button
// } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';
// import PersonIcon from '@mui/icons-material/Person';
// import EmailIcon from '@mui/icons-material/Email';
// import PhoneIcon from '@mui/icons-material/Phone';
// import StarBorderIcon from '@mui/icons-material/StarBorder';
// import StarIcon from '@mui/icons-material/Star';
// import LocalShippingIcon from '@mui/icons-material/LocalShipping';
// import * as Yup from 'yup';
// import { yupResolver } from '@hookform/resolvers/yup';
// import { useForm } from 'react-hook-form';
// import styles from "../../../styles/viewJob.module.css";
// import { job } from '../../../utils/api/job';
// import { toast } from 'react-toastify';

// interface ChildProps {
// 	jobId: string;
// 	load: any;
// 	open: boolean;
// 	onClose: () => void;
// 	truckerData: any;
// }
// interface RatingFrom {
// 	rating: number;
// 	feedback: string;
// }

// const TruckerDetails: React.FC<ChildProps> = ({ jobId, load, open, onClose, truckerData }) => {
// 	const [currentRating, setCurrentRating] = React.useState(0);
// 	const [feedbackData, setFeedbackData] = React.useState(load?.feedback);

// 	const validationSchema = Yup.object().shape({
// 		rating: Yup.number()
// 			.required('Rating is required')
// 			.min(1, 'At least give a rating of 1 star')
// 			.max(5, 'Rating cannot exceed 5 stars'),
// 		feedback: Yup.string()
// 			.max(500, 'Comment cannot exceed 500 characters')
// 	})

// 	const { register, handleSubmit, control, formState: { errors }, setValue } = useForm({
// 		resolver: yupResolver(validationSchema)
// 	});

// 	const handleRatingClick = (value: number) => {
// 		setCurrentRating(value);
// 		setValue('rating', value, { shouldValidate: true, shouldDirty: true });
// 	};
// 	useEffect(() => {
// 		setValue('rating', currentRating, { shouldValidate: true });
// 	}, [currentRating, setValue]);

// 	const onSubmit = async (data: any) => {
// 		// Ensure rating is included in the data
// 		const payload = {
// 			job_id: jobId,
// 			load_id: load.id,
// 			rating: data.rating,
// 			comment: data.feedback
// 		}

// 		const isSubmitted = await job.submitRating(payload);

// 		if (isSubmitted?.status == true) {
// 			toast.success(isSubmitted?.message);
// 			onClose();
// 		} else {
// 			onClose();
// 			toast.error(isSubmitted?.message);
// 		}
// 	};

// 	return (
// 		<Modal
// 			aria-labelledby="transition-modal-title"
// 			aria-describedby="transition-modal-description"
// 			open={open}
// 			onClose={onClose}
// 			closeAfterTransition
// 			slotProps={{
// 				backdrop: {
// 					timeout: 500,
// 				},
// 			}}
// 		>
// 			<Fade in={open}>
// 				<Box className={styles.modalBox}>
// 					{/* Header */}
// 					<div className={styles.modalHeader}>
// 						<Typography id="transition-modal-title" className={styles.modalTitle}>
// 							Trucker Details
// 						</Typography>
// 						<IconButton
// 							aria-label="close"
// 							onClick={onClose}
// 							sx={{
// 								color: 'red',
// 								border: '1px solid red',
// 								borderRadius: '4px',
// 								padding: '4px',
// 								'&:hover': {
// 									backgroundColor: 'rgba(255, 0, 0, 0.1)',
// 								}
// 							}}
// 						>
// 							<CloseIcon />
// 						</IconButton>
// 					</div>

// 					{/* Content */}
// 					<Box sx={{ p: 3, textAlign: 'center' }}>
// 						{/* Avatar */}
// 						<Box sx={{ mb: 2 }}>
// 							<img
// 								src={truckerData?.profile_image}
// 								alt={truckerData?.fname + ' ' + truckerData?.lname}
// 								style={{
// 									width: '80px',
// 									height: '80px',
// 									borderRadius: '50%',
// 									margin: '0 auto',
// 									border: '3px solid #e0e0e0',
// 									objectFit: 'cover'
// 								}}
// 							/>
// 						</Box>

// 						{/* Rating Badge */}
// 						{truckerData?.rating && (
// 							<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
// 								<Box sx={{
// 									position: 'absolute',
// 									top: '167px',
// 									left: '206px',
// 									backgroundColor: '#FF6B35',
// 									color: 'white',
// 									px: 1.5,
// 									py: 0.5,
// 									borderRadius: '12px',
// 									fontSize: '14px',
// 									fontWeight: 'bold',
// 									display: 'flex',
// 									alignItems: 'center',
// 									gap: 0.5
// 								}}>
// 									<span>★</span>
// 									<span>{truckerData?.rating.toFixed(1)}</span>
// 								</Box>
// 							</Box>
// 						)}

// 						{/* Name */}
// 						<Typography variant="h6" sx={{ fontWeight: '400', mb: 2, color: '#333' }}>
// 							<PersonIcon sx={{ fontSize: '25px' }} />
// 							{truckerData?.fname} {truckerData?.lname}
// 						</Typography>

// 						{/* Contact Information */}
// 						<div className={styles.truckerContactInfo}>
// 							<Box sx={{ mb: 3, textAlign: 'center' }}>
// 								<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5, color: '#666', fontSize: '14px' }}>
// 									<EmailIcon sx={{ fontSize: '16px' }} />
// 									<span>{truckerData?.email}</span>
// 								</Box>
// 								<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, color: '#666', fontSize: '14px', justifyContent: 'center' }}>
// 									<PhoneIcon sx={{ fontSize: '16px' }} />
// 									<span>+{truckerData?.country_code} {truckerData?.mobile}</span>
// 								</Box>
// 							</Box>
// 						</div>

// 						{/* Truck Information */}
// 						<div className={styles.contentContainer}>
// 							<div className={styles.truckerItem}>
// 								<div className={styles.truckerDetailTruckInfo}>
// 									<div className={styles.truckDetails}>
// 										<div className={styles.truckertruckName}>
// 											{truckerData?.truck_type}
// 										</div>
// 										<div className={styles.truckerSpecs}>
// 											<span className={styles.tonnage}>{truckerData?.weight_capacity} Tons</span>
// 										</div>
// 									</div>

// 									<img
// 										src={truckerData?.truck_type_image}
// 										alt="Truck Image"
// 										className={styles.truckerTruckImage}
// 									/>
// 								</div>
// 							</div>
// 							<div className={styles.truckerItem}>
// 								<div className={styles.truckerDetailTruckInfo}>
// 									<div className={styles.truckDetails}>
// 										<div className={styles.truckerName}>
// 											Weight
// 										</div>
// 										<div className={styles.truckerSpecs}>
// 											<span className={styles.acceptedWeight}>{truckerData?.weight_capacity} Tons</span>
// 										</div>
// 									</div>
// 								</div>
// 							</div>
// 						</div>

// 						{load?.status < 4 ? (       // Load not delivered yet (status < 3)
// 							<Box sx={{
// 								width: '100%',
// 								p: 1.5,
// 								backgroundColor: '#e0f7fa',
// 								borderRadius: '8px',
// 								fontFamily: 'Poppins',
// 								fontSize: '14px',
// 								fontWeight: '500',
// 								textAlign: 'center',
// 								'&:hover': {
// 									backgroundColor: '#b2ebf2'
// 								}
// 							}}>
// 								You can rate the trucker after the load is delivered.
// 							</Box>
// 						) : load?.status == 4 && load?.feedback != null ? (  // show existing given feedback
// 							<Box
// 								sx={{
// 									width: '100%',
// 									p: 3,
// 									backgroundColor: '#f9fbe7',
// 									borderRadius: 2,
// 									boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
// 									fontFamily: 'Poppins, sans-serif',
// 									color: '#333',
// 								}}
// 							>
// 								<Typography
// 									variant="h6"
// 									sx={{
// 										mb: 2,
// 										fontWeight: 600,
// 										color: '#2e7d32',
// 									}}
// 								>
// 									Your Rating
// 								</Typography>

// 								<Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
// 									{[1, 2, 3, 4, 5].map((value) => (
// 										<IconButton key={value} disabled sx={{ p: 0.5 }}>
// 											{value <= load.feedback.rating ? (
// 												<StarIcon sx={{ fontSize: 28, color: '#FFD700' }} />
// 											) : (
// 												<StarBorderIcon sx={{ fontSize: 28, color: '#ccc' }} />
// 											)}
// 										</IconButton>
// 									))}
// 								</Box>

// 								<Typography
// 									variant="body1"
// 									sx={{
// 										whiteSpace: 'pre-line',
// 										lineHeight: 1.6,
// 										fontSize: '15px',
// 										color: '#555',
// 									}}
// 								>
// 									{load.feedback.comment || 'No feedback text provided.'}
// 								</Typography>
// 							</Box>

// 						) : load?.status == 4 && load?.feedback == null ? (   // show feedback form
// 							<form className="custom-Form" onSubmit={handleSubmit(onSubmit, (err) => console.log("Validation errors:", err))}>
// 								<Box sx={{
// 									width: '100%',
// 									p: 1.5,
// 									backgroundColor: '#e8f5e8',
// 									borderRadius: '8px',
// 									fontFamily: 'Poppins',
// 									fontSize: '14px',
// 									fontWeight: '500',
// 									textAlign: 'center',
// 									mb: 2,
// 									'&:hover': {
// 										backgroundColor: '#d4f4d4'
// 									}
// 								}}>
// 									Please give a rating to the Trucker
// 								</Box>

// 								{/* Rating Stars */}
// 								<Box sx={{ display: 'flex', justifyContent: 'center', gap: 0.5, mb: 1 }}>
// 									{[1, 2, 3, 4, 5].map((value) => (
// 										<IconButton key={value} onClick={() => handleRatingClick(value)} sx={{ padding: 0 }}>
// 											{value <= currentRating ? (
// 												<StarIcon sx={{ fontSize: '30px', color: '#FFD700' }} />
// 											) : (
// 												<StarBorderIcon sx={{ fontSize: '30px', color: '#ccc' }} />
// 											)}
// 										</IconButton>
// 									))}
// 								</Box>

// 								{errors.rating && (
// 									<div className="invalid-feedback" style={{ color: 'red', fontSize: '14px', marginBottom: '16px' }}>
// 										{errors.rating.message}
// 									</div>
// 								)}

// 								<Grid container spacing={3} sx={{ mb: 3 }}>
// 									<Grid size={{ xs: 12 }}>
// 										<TextField
// 											label="Add Your Feedback"
// 											variant="outlined"
// 											multiline
// 											rows={3}
// 											fullWidth
// 											margin="normal"
// 											error={!!errors?.feedback}
// 											helperText={errors.feedback?.message}
// 											{...register('feedback')}
// 										/>
// 									</Grid>
// 								</Grid>

// 								<Button
// 									type='submit'
// 									variant="contained"
// 									color="primary"
// 									className={styles.formButton}
// 								>
// 									Submit
// 								</Button>
// 							</form>
// 						) : null}

// 					</Box>
// 				</Box>
// 			</Fade>
// 		</Modal>
// 	);
// };

// export default TruckerDetails;



import React, { useEffect, useState } from 'react';
import {
	Box,
	Fade,
	Modal,
	Typography,
	IconButton,
	Grid,
	TextField,
	Button
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import StarIcon from '@mui/icons-material/Star';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import styles from "../../../styles/viewJob.module.css";
import { job } from '../../../utils/api/job';
import { toast } from 'react-toastify';

interface ChildProps {
	jobId: string;
	load: any;
	open: boolean;
	onClose: () => void;
	truckerData: any;
}

const TruckerDetails: React.FC<ChildProps> = ({ jobId, load, open, onClose, truckerData }) => {
	const [currentRating, setCurrentRating] = useState(0);
	const [submittedFeedback, setSubmittedFeedback] = useState(load?.feedback);
	const [isSubmitting, setIsSubmitting] = useState(false);

	const validationSchema = Yup.object().shape({
		rating: Yup.number()
			.required('Rating is required')
			.min(1, 'At least give a rating of 1 star')
			.max(5, 'Rating cannot exceed 5 stars'),
		feedback: Yup.string()
			.max(500, 'Comment cannot exceed 500 characters')
	});

	const { register, handleSubmit, formState: { errors }, setValue, reset } = useForm({
		resolver: yupResolver(validationSchema)
	});

	const handleRatingClick = (value: number) => {
		setCurrentRating(value);
		setValue('rating', value, { shouldValidate: true, shouldDirty: true });
	};

	useEffect(() => {
		setValue('rating', currentRating, { shouldValidate: true });
	}, [currentRating, setValue]);

	// Reset feedback state when modal opens/closes or load changes
	useEffect(() => {
		setSubmittedFeedback(load?.feedback);
		setCurrentRating(0);
		reset();
	}, [load, open, reset]);

	const onSubmit = async (data: any) => {
		setIsSubmitting(true);
		const payload = {
			job_id: jobId,
			load_id: load.id,
			rating: data.rating,
			comment: data.feedback || ''
		};

		try {
			const isSubmitted = await job.submitRating(payload);

			if (isSubmitted?.status === true) {
				// Update local state immediately to show feedback
				setSubmittedFeedback({
					rating: data.rating,
					comment: data.feedback || ''
				});

				toast.success(isSubmitted?.message);
				reset();
				setCurrentRating(0);
			} else {
				toast.error(isSubmitted?.message || 'Failed to submit rating');
			}
		} catch (error) {
			toast.error('An error occurred while submitting rating');
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<Modal
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			open={open}
			onClose={onClose}
			closeAfterTransition
			slotProps={{
				backdrop: {
					timeout: 500,
				},
			}}
		>
			<Fade in={open}>
				<Box className={styles.modalBox}>
					{/* Header */}
					<div
						className={styles.modalHeader}
					>
						<Typography
							id="transition-modal-title"
							className={styles.modalTitle}
							sx={{
								fontSize: '20px',
								fontWeight: 600,
								color: '#333'
							}}
						>
							Trucker Details
						</Typography>
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: '#ff4444',
								border: '1px solid #ff4444',
								borderRadius: '8px',
								padding: '6px',
								'&:hover': {
									backgroundColor: 'rgba(255, 68, 68, 0.08)',
								}
							}}
						>
							<CloseIcon sx={{ fontSize: '20px' }} />
						</IconButton>
					</div>

					{/* Content */}
					<Box sx={{ p: 3, textAlign: 'center', maxHeight: 'calc(90vh - 80px)', overflowY: 'auto' }}>
						{/* Avatar with Rating Badge */}
						<Box sx={{ position: 'relative', display: 'inline-block', mb: 3 }}>
							<Box
								component="img"
								src={truckerData?.profile_image}
								alt={`${truckerData?.fname} ${truckerData?.lname}`}
								sx={{
									width: '100px',
									height: '100px',
									borderRadius: '50%',
									border: '4px solid #f0f0f0',
									objectFit: 'cover',
									boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
								}}
							/>
							{truckerData?.rating && (
								<Box sx={{
									position: 'absolute',
									bottom: '-8px',
									right: '23px',
									backgroundColor: '#FF6B35',
									color: 'white',
									px: 1.5,
									py: 0.5,
									borderRadius: '20px',
									fontSize: '14px',
									fontWeight: 'bold',
									display: 'flex',
									alignItems: 'center',
									gap: 0.5,
									boxShadow: '0 2px 8px rgba(255,107,53,0.3)'
								}}>
									<span>★</span>
									<span>{truckerData?.rating.toFixed(1)}</span>
								</Box>
							)}
						</Box>

						{/* Name */}
						<Typography
							variant="h6"
							sx={{
								fontWeight: 600,
								mb: 2.5,
								color: '#333',
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								gap: 1
							}}
						>
							<PersonIcon sx={{ fontSize: '24px', color: '#666' }} />
							{truckerData?.fname} {truckerData?.lname}
						</Typography>

						{/* Contact Information */}
						<Box sx={{
							mb: 3,
							p: 2,
							backgroundColor: '#f9f9f9',
							borderRadius: '12px',
							display: 'inline-block',
							minWidth: '300px'
						}}>
							<Box sx={{
								display: 'flex',
								alignItems: 'center',
								gap: 1.5,
								mb: 1.5,
								color: '#555',
								justifyContent: 'center'
							}}>
								<EmailIcon sx={{ fontSize: '18px', color: '#666' }} />
								<Typography sx={{ fontSize: '14px' }}>{truckerData?.email}</Typography>
							</Box>
							<Box sx={{
								display: 'flex',
								alignItems: 'center',
								gap: 1.5,
								color: '#555',
								justifyContent: 'center'
							}}>
								<PhoneIcon sx={{ fontSize: '18px', color: '#666' }} />
								<Typography sx={{ fontSize: '14px' }}>
									+{truckerData?.country_code} {truckerData?.mobile}
								</Typography>
							</Box>
						</Box>

						{/* Truck Information */}
						<Box sx={{
							display: 'flex',
							gap: 2,
							mb: 3,
							flexWrap: 'wrap',
							justifyContent: 'center'
						}}>
							<Box sx={{
								flex: '1 1 250px',
								p: 2,
								backgroundColor: '#fff',
								borderRadius: '12px',
								border: '1px solid #e0e0e0',
								display: 'flex',
								justifyContent: 'space-between',
								alignItems: 'center'
							}}>
								<Box sx={{ textAlign: 'left' }}>
									<Typography sx={{
										fontSize: '16px',
										fontWeight: 600,
										color: '#333',
										mb: 0.5
									}}>
										{truckerData?.truck_type}
									</Typography>
									<Typography sx={{
										fontSize: '14px',
										color: '#666',
										fontWeight: 500
									}}>
										{truckerData?.weight_capacity} Tons
									</Typography>
								</Box>
								<Box
									component="img"
									src={truckerData?.truck_type_image}
									alt="Truck"
									sx={{
										width: '60px',
										height: '60px',
										objectFit: 'contain'
									}}
								/>
							</Box>
						</Box>

						{/* Rating Section */}
						{load?.status < 4 ? (
							<Box sx={{
								width: '100%',
								padding: '16px 0px',
								backgroundColor: '#e3f2fd',
								borderRadius: '12px',
								fontSize: '14px',
								fontWeight: '500',
								textAlign: 'center',
								color: '#1976d2',
								border: '1px solid #90caf9'
							}}>
								⏳ You can rate the trucker after the load is delivered.
							</Box>
						) : submittedFeedback ? (
							<Box sx={{
								width: '100%',
								backgroundColor: '#f1f8e9',
								borderRadius: '12px',
								boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
								border: '1px solid #c5e1a5'
							}}>
								<Typography sx={{
									mb: 2,
									fontWeight: 600,
									color: '#558b2f',
									fontSize: '18px'
								}}>
									✓ Rating
								</Typography>

								<Box sx={{
									display: 'flex',
									gap: 0.5,
									mb: 2,
									justifyContent: 'center'
								}}>
									{[1, 2, 3, 4, 5].map((value) => (
										<Box key={value}>
											{value <= submittedFeedback.rating ? (
												<StarIcon sx={{ fontSize: 32, color: '#FFD700' }} />
											) : (
												<StarBorderIcon sx={{ fontSize: 32, color: '#ddd' }} />
											)}
										</Box>
									))}
								</Box>

								<Typography sx={{
									whiteSpace: 'pre-line',
									lineHeight: 1.6,
									fontSize: '15px',
									color: '#555',
									textAlign: 'left',
									padding: '9px',
									backgroundColor: '#fff',
									borderRadius: '8px',
									margin: '10px'
								}}>
									{submittedFeedback.comment || 'No feedback text provided.'}
								</Typography>
							</Box>
						) : (
							<form onSubmit={handleSubmit(onSubmit)}>
								<Box sx={{
									width: '100%',
									padding: '6px 0px 10px 0px',
									backgroundColor: '#e8f5e9',
									borderRadius: '12px',
									fontSize: '14px',
									fontWeight: '500',
									textAlign: 'center',
									mb: 2,
									color: '#2e7d32',
									border: '1px solid #a5d6a7'
								}}>
									⭐ Please rate your experience with this trucker
								</Box>

								{/* Rating Stars */}
								<Box sx={{
									display: 'flex',
									justifyContent: 'center',
									gap: 1,
									mb: 2
								}}>
									{[1, 2, 3, 4, 5].map((value) => (
										<IconButton
											key={value}
											onClick={() => handleRatingClick(value)}
											sx={{
												padding: '4px',
												'&:hover': {
													transform: 'scale(1.1)',
													transition: 'transform 0.2s'
												}
											}}
										>
											{value <= currentRating ? (
												<StarIcon sx={{ fontSize: '36px', color: '#FFD700' }} />
											) : (
												<StarBorderIcon sx={{ fontSize: '36px', color: '#ccc' }} />
											)}
										</IconButton>
									))}
								</Box>

								{errors.rating && (
									<Typography sx={{
										color: '#d32f2f',
										fontSize: '13px',
										mb: 2,
										textAlign: 'center'
									}}>
										{errors.rating.message}
									</Typography>
								)}

								<TextField
									label="Add Your Feedback"
									variant="outlined"
									multiline
									rows={4}
									fullWidth
									margin="normal"
									error={!!errors?.feedback}
									helperText={errors.feedback?.message}
									{...register('feedback')}
									sx={{
										mb: 2,
										'& .MuiOutlinedInput-root': {
											borderRadius: '12px',
										}
									}}
								/>

								<Button
									type='submit'
									variant="contained"
									fullWidth
									disabled={isSubmitting}
									sx={{
										py: 1.5,
										borderRadius: '12px',
										textTransform: 'none',
										fontSize: '16px',
										fontWeight: 600,
										backgroundColor: '#1976d2',
										'&:hover': {
											backgroundColor: '#1565c0'
										}
									}}
								>
									{isSubmitting ? 'Submitting...' : 'Submit Rating'}
								</Button>
							</form>
						)}
					</Box>
				</Box>
			</Fade>
		</Modal>
	);
};

export default TruckerDetails;