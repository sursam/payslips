import React, { use, useCallback, useEffect, useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import {
	Checkbox,
	Fade,
	Typography,
	Button,
	Box,
	Modal,
} from '@mui/material';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import styles from "../../../styles/viewJob.module.css";
import { job } from '../../../utils/api/job';


interface ChildProps {
	jobId: string;
	truckType: any[];
	open: boolean;
	onClose: () => void;
	onSubmitTruckTypes: (jobId: string, truckTypeIds: string) => void;
}
const ChangeTruck: React.FC<ChildProps> = ({ jobId, truckType, open, onClose, onSubmitTruckTypes }) => {
	const schema = Yup.object().shape({
		truckType: Yup.array().min(1, 'Please select at least one truck type')
	});

	const {
		register,
		handleSubmit,
		formState: { errors },
		reset
	} = useForm();
	const onSubmit = (data: any) => {
		onSubmitTruckTypes(jobId, data.truckType.join(','));
		onClose();
		reset();
	};

	return (
		<Modal
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			open={open}
			onClose={onClose}
			closeAfterTransition
			slotProps={{
				backdrop: {
					timeout: 500,
				},
			}}
		>
			<Fade in={open}>
				<Box className={styles.modalBox}>
					<div className={styles.modalHeader}>
						<Typography id="transition-modal-title" className={styles.modalTitle}>
							Change Truck Type
						</Typography>
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: 'red',
								border: '1px solid red',
								borderRadius: '4px',
								padding: '4px',
								'&:hover': {
									backgroundColor: 'rgba(255, 0, 0, 0.1)',
								}
							}}
						>
							<CloseIcon />
						</IconButton>
					</div>
					<form onSubmit={handleSubmit(onSubmit)}>
						<div className={styles.contentContainer}>
							{truckType.map((item, index) => (
								<div className={styles.truckerItem}>
									<div className={styles.truckInfo}>
										<div className={styles.checkboxWrapper}>
											<Checkbox
												{...register('truckType')}
												value={item?.truck_type_id}
												className={styles.truckCheckbox}
											/>

										</div>

										<div className={styles.truckDetails}>
											<div className={styles.truckerName}>
												{item?.name}
											</div>
											<div className={styles.truckerSpecs}>
												<span className={styles.axles}>{item?.specs} Axles</span>
												<span className={styles.divider}>|</span>
												<span className={styles.tonnage}>{item?.weight_capacity} Tons</span>
											</div>
										</div>

										<img
											src={item?.trucktype_image}
											alt={item?.name}
											className={styles.truckImage}
										/>
									</div>
								</div>
							))}
							{errors.truckType && <div className="invalid-feedback">Please select any truck Type</div>}


						</div>
						<Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
							<Button
								variant="contained"
								type="submit"
								sx={{
									fontFamily: 'Poppins, sans-serif',
									fontWeight: 600,
									textTransform: 'none',
									backgroundColor: '#005DAA',
									borderRadius: '8px',
									padding: '8px 24px',
									'&:hover': {
										backgroundColor: '#004A8A'
									}
								}}
							>
								Submit
							</Button>
						</Box>
					</form>


				</Box>
			</Fade>
		</Modal>
	);
};

export default ChangeTruck;