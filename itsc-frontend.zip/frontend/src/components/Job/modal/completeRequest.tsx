import React, { use, useCallback, useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import SignatureCanvas from 'react-signature-canvas';
import type SignatureCanvasType from 'react-signature-canvas';
import Button from '@mui/material/Button';
import { api } from '../../../utils/api';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import {
	Box,
	Fade,
	FormControlLabel,
	FormControl,
	Grid,
	Modal,
	Radio,
	RadioGroup,
	TextField,
	Typography,
	TextareaAutosize
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import styles from "../../../styles/viewJob.module.css";
import { job } from '../../../utils/api/job';
import { toast } from 'react-toastify';

interface ChildProps {
	jobId: string;
	loadId: string;
	open: boolean;
	onClose: () => void;
	endJobRequest: any;
	onCompleteRequest: (data: FormData) => void;
}

interface verifyLoadDeliveryRequestFrom {
	job_id: string;
	load_id: string;
	receiver_name: string;
	contractor_status: string;
	isnetweightflag: string;
	correct_net_weight?: string;
	trucker_taken_weight?: string;
	signature: File | null;
	notes?: string;
	ticket_no?: string;
	challan?: string;
	signed_challan?: string;
}


const validationSchema = Yup.object().shape({
	job_id: Yup.string().required('Job ID is required'),
	load_id: Yup.string().required('Load ID is required'),
	receiver_name: Yup.string().required('Receiver name is required'),
	contractor_status: Yup.string().required('Contractor status is required'),
	isnetweightflag: Yup.string().required('Net weight flag is required'),
	correct_net_weight: Yup.string().notRequired(),
	notes: Yup.string().notRequired(),
	ticket_no: Yup.string().notRequired()
});

const CompleteRequest: React.FC<ChildProps> = ({ jobId, loadId, open, onClose, endJobRequest, onCompleteRequest }) => {
	const [selectedOption, setSelectedOption] = useState('yes');
	const [submitting, setSubmitting] = useState(false);
	const [signatureError, setSignatureError] = useState<string>('');

	const {
		register,
		handleSubmit,
		setValue,
		setError,
		clearErrors,
		formState: { errors },
		reset,
		watch
	} = useForm({
		resolver: yupResolver(validationSchema as any)
	});

	// Populate form when modal opens
	useEffect(() => {

		if (open && endJobRequest) {
			setValue('job_id', jobId);
			setValue('load_id', loadId);
			setValue('receiver_name', endJobRequest.contracter_name || '');
			setValue('correct_net_weight', endJobRequest.load_actual_weight || '');
			setValue('trucker_taken_weight', endJobRequest.trucker_taken_weight || '');
			setValue('contractor_status', '1'); // Set appropriate status
			setValue('isnetweightflag', selectedOption === 'yes' ? 'true' : 'false');
			setValue('notes', endJobRequest.additional_note || '');
			setValue('ticket_no', endJobRequest.ticket_no || '');
			setValue('challan', endJobRequest.challan || '');
			setValue('signed_challan', endJobRequest.signed_challan || '');
		}
	}, [open, endJobRequest, jobId, loadId, selectedOption, setValue]);

	// Update net weight flag when radio changes
	useEffect(() => {
		setValue('isnetweightflag', selectedOption === 'yes' ? 'true' : 'false');
	}, [selectedOption, setValue]);

	const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		setSelectedOption(event.target.value);
	};

	const sigCanvasRef = useRef<SignatureCanvasType>(null);

	const clear = () => {
		if (sigCanvasRef.current) {
			sigCanvasRef.current.clear();
			setSignatureError('');
		}
	};

	// Clear signature error when user starts drawing
	const handleSignatureEnd = () => {
		if (sigCanvasRef.current) {
			try {
				// Try different methods to check if canvas is not empty
				const isEmpty = sigCanvasRef.current.isEmpty ? sigCanvasRef.current.isEmpty() : false;
				if (!isEmpty) {
					setSignatureError(''); // Clear any existing signature errors
				}
			} catch (e) {
				// If we can't check, assume user has drawn something
				setSignatureError('');
			}
		}
	};

	// Replace the onSubmit function:
	const onSubmit = async (data: verifyLoadDeliveryRequestFrom) => {

		// Check if signature is present
		let isCanvasEmpty = true;

		try {
			isCanvasEmpty = sigCanvasRef.current?.isEmpty() ?? true;
		} catch (e) {
			// Fallback check for older versions
			try {
				const canvas = sigCanvasRef.current?.getCanvas();
				const context = canvas?.getContext('2d');
				if (canvas && context) {
					const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
					const pixelBuffer = new Uint32Array(imageData.data.buffer);
					isCanvasEmpty = !pixelBuffer.some(color => color !== 0);
				} else {
					isCanvasEmpty = false; // Assume not empty if we can't check
				}
			} catch (e2) {
				console.warn('Could not check if canvas is empty, proceeding with submission');
				isCanvasEmpty = false;
			}
		}

		if (!sigCanvasRef.current || isCanvasEmpty) {
			setSignatureError('Signature is required');
			return;
		}

		setSubmitting(true);

		try {
			// Get signature data and convert to file - using multiple fallback methods
			let signatureDataURL: string;

			try {
				// Try getTrimmedCanvas first (newer versions)
				signatureDataURL = sigCanvasRef.current.getTrimmedCanvas().toDataURL('image/png');
			} catch (e1) {
				try {
					signatureDataURL = sigCanvasRef.current.getCanvas().toDataURL('image/png');
				} catch (e2) {
					try {
						const canvas = sigCanvasRef.current.getCanvas();
						signatureDataURL = canvas.toDataURL('image/png');
					} catch (e3) {
						throw new Error('Unable to get signature data from canvas');
					}
				}
			}

			// Enhanced dataURLToFile function with better error handling
			const dataURLToFile = (dataUrl: string, filename: string): File => {
				// Validate data URL format
				if (!dataUrl || !dataUrl.startsWith('data:')) {
					throw new Error('Invalid data URL format');
				}

				const arr = dataUrl.split(',');
				if (arr.length !== 2) {
					throw new Error('Invalid data URL structure');
				}

				const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
				const bstr = atob(arr[1]);
				let n = bstr.length;
				const u8arr = new Uint8Array(n);

				while (n--) {
					u8arr[n] = bstr.charCodeAt(n);
				}

				return new File([u8arr], filename, { type: mime });
			};

			const signatureFile = dataURLToFile(signatureDataURL, 'signature.png');

			// Validate that the file was created successfully
			if (!signatureFile || signatureFile.size === 0) {
				throw new Error('Failed to create signature file or file is empty');
			}

			const formData = new FormData();

			formData.append('job_id', data.job_id || jobId);
			formData.append('load_id', data.load_id || loadId);
			formData.append('receiver_name', data.receiver_name || '');
			formData.append('contractor_status', '1');
			formData.append('isnetweightflag', selectedOption === 'yes' ? '1' : '0');
			formData.append('signature', signatureFile, signatureFile.name);
			formData.append('correct_net_weight', data.trucker_taken_weight || '');
			formData.append('notes', data.notes || '');

			onCompleteRequest(formData);
			reset();
			clear();
			setSignatureError('');
			onClose();

		} catch (error) {
			console.error("Error submitting request:", error);
			// More specific error messages
			if (error instanceof Error) {
				alert(`Error submitting form: ${error.message}`);
			} else {
				alert('Error submitting form. Please try again.');
			}
		}
	};

	// Helper function to convert data URL to File (place this outside the component)
	const dataURLToFile = (dataUrl: string, filename: string): File => {
		// Validate data URL format
		if (!dataUrl || !dataUrl.startsWith('data:')) {
			throw new Error('Invalid data URL format');
		}

		const arr = dataUrl.split(',');
		if (arr.length !== 2) {
			throw new Error('Invalid data URL structure');
		}

		const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
		const bstr = atob(arr[1]);
		let n = bstr.length;
		const u8arr = new Uint8Array(n);

		while (n--) {
			u8arr[n] = bstr.charCodeAt(n);
		}

		return new File([u8arr], filename, { type: mime });
	};

	return (
		<Modal
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			open={open}
			onClose={onClose}
			closeAfterTransition
			slotProps={{
				backdrop: {
					timeout: 500,
				},
			}}
		>
			<Fade in={open}>
				<Box className={styles.modalBox}>
					<div className={styles.modalHeader}>
						<Typography id="transition-modal-title" className={styles.modalTitle}>
							Complete Request
						</Typography>
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: 'red',
								border: '1px solid red',
								borderRadius: '4px',
								padding: '4px',
								'&:hover': {
									backgroundColor: 'rgba(255, 0, 0, 0.1)',
								}
							}}
						>
							<CloseIcon />
						</IconButton>
					</div>
					<form className="custom-Form" encType="multipart/form-data" onSubmit={handleSubmit(onSubmit)}>
						<div className={styles.contentContainer}>
							<Grid container spacing={3} sx={{ mb: 3 }}>
								<Grid size={12}>
									<FormControl fullWidth>
										<TextField
											label="Receiver Name"
											variant="outlined"
											fullWidth
											margin="normal"
											error={!!errors?.receiver_name}
											helperText={errors?.receiver_name?.message as string}
											className={`${styles.formControl} ${errors?.receiver_name ? 'is-invalid' : ''}`}
											{...register('receiver_name')}
										/>
									</FormControl>
								</Grid>
							</Grid>

							<Grid container spacing={3} sx={{ mb: 3 }}>
								<Grid size={12}>
									<Typography variant="h6" gutterBottom className={styles.formTitle} sx={{ fontSize: '13px' }}>
										Is the Net Weight Correct?
									</Typography>
									<FormControlLabel
										control={
											<Radio
												color="primary"
												value="yes"
												checked={selectedOption === 'yes'}
												onChange={handleRadioChange}
											/>
										}
										label="Yes"
										sx={{ marginLeft: "5px" }}
									/>
									<FormControlLabel
										control={
											<Radio
												color="primary"
												value="no"
												checked={selectedOption === 'no'}
												onChange={handleRadioChange}
											/>
										}
										label="No"
									/>
								</Grid>

								<Grid size={6}>
									<FormControl fullWidth>
										<TextField
											label="Net Weight"
											variant="outlined"
											fullWidth
											margin="normal"
											disabled
											{...register('correct_net_weight')}
											error={!!errors.correct_net_weight}
											helperText={errors.correct_net_weight?.message as string}
											className={`${styles.formControl} ${errors?.correct_net_weight ? 'is-invalid' : ''}`}
										/>
									</FormControl>
								</Grid>

								<Grid size={6}>
									<FormControl fullWidth>
										<TextField
											label="Trucker Taken"
											variant="outlined"
											fullWidth
											margin="normal"
											disabled={selectedOption === 'yes'}
											{...register('trucker_taken_weight')}
											error={!!errors.trucker_taken_weight}
											helperText={errors.trucker_taken_weight?.message as string}
											className={`${styles.formControl} ${errors?.trucker_taken_weight ? 'is-invalid' : ''}`}
										/>
									</FormControl>
								</Grid>

								{endJobRequest?.ticket_no && (
									<Grid size={12}>
										<FormControl fullWidth>
											<TextField
												label="Ticket Number"
												variant="outlined"
												fullWidth
												disabled
												margin="normal"
												{...register('ticket_no')}
												error={!!errors.ticket_no}
												helperText={errors.ticket_no?.message as string}
												className={`${styles.formControl} ${errors?.ticket_no ? 'is-invalid' : ''}`}
											/>
										</FormControl>
									</Grid>
								)}

								{/* Show Signed Ticket Image if present */}
								{endJobRequest?.signed_challan && (
									<Grid size={12}>
										<FormControl fullWidth>
											<Typography variant="subtitle1" gutterBottom>
												Signed Ticket
											</Typography>
											<img
												src={endJobRequest.signed_challan}
												alt="Signed Ticket"
												style={{ width: '400px', height: '150px', borderRadius: 8 }}
											/>
										</FormControl>
									</Grid>
								)}

								{/* Show Unsigned Ticket Image if present */}
								{endJobRequest?.challan && (
									<Grid size={12}>
										<FormControl fullWidth>
											<Typography variant="subtitle1" gutterBottom>
												Unsigned Ticket
											</Typography>
											<img
												src={endJobRequest.challan}
												alt="Unsigned Ticket"
												style={{ width: '400px', height: '150px', borderRadius: 8 }}
											/>
										</FormControl>
									</Grid>
								)}
							</Grid>

							{endJobRequest?.trucker_notes && (
								<Grid container spacing={3} sx={{ mb: 3 }}>
									<Grid size={12}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Note Added By Trucker
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{endJobRequest.trucker_notes}
										</Typography>
									</Grid>
								</Grid>
							)}

							<Grid container spacing={3} sx={{ mb: 3 }}>
								<Grid size={12}>
									<FormControl fullWidth>
										<TextField
											label="Add Your Note"
											variant="outlined"
											multiline
											rows={3}
											fullWidth
											margin="normal"
											{...register('notes')}
											error={!!errors.notes}
											helperText={errors.notes?.message as string}
										/>
									</FormControl>
								</Grid>
							</Grid>

							<Grid container spacing={3} sx={{ mb: 3 }}>
								<Grid size={12}>
									<Typography sx={{
										fontSize: 12,
										fontWeight: 400,
										fontFamily: 'Poppins',
										color: '#888',
										fontStyle: 'italic',
										mb: 0.5
									}}>
										Signature
									</Typography>
									<FormControl
										fullWidth
										sx={{
											border: signatureError ? '1px solid #d32f2f' : '1px solid #000',
											borderRadius: '8px'
										}}
									>
										<SignatureCanvas
											ref={sigCanvasRef}
											penColor="black"
											onEnd={handleSignatureEnd} // Add this to clear errors when user draws
											canvasProps={{
												height: 150,
												className: 'sigCanvas'
											}}
										/>
									</FormControl>
									{signatureError && (
										<Typography color="error" variant="caption" sx={{ mt: 1 }}>
											{signatureError}
										</Typography>
									)}
									<Button
										variant="contained"
										size="small"
										sx={{
											fontSize: '11px',
											padding: '6px 16px',
											textTransform: 'capitalize',
											backgroundColor: '#ff0000ed',
											fontFamily: 'Poppins, sans-serif',
											fontWeight: 500,
											borderRadius: '16px',
											mt: 1
										}}
										onClick={clear}
									>
										Clear
									</Button>
								</Grid>
							</Grid>
						</div>

						<Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
							<Button
								variant="contained"
								type="submit"
								sx={{
									fontFamily: 'Poppins, sans-serif',
									fontWeight: 600,
									textTransform: 'none',
									backgroundColor: '#005DAA',
									borderRadius: '8px',
									padding: '8px 24px',
									'&:hover': {
										backgroundColor: '#004A8A'
									}
								}}
							>
								{/* {submitting ? 'Submitting...' : 'Submit'} */}
								Submit
							</Button>
						</Box>
					</form>
				</Box>
			</Fade>
		</Modal>
	);
};

export default CompleteRequest;