import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import moment from 'moment';
import {
	Box,
	Button,
	CardContent,
	Grid,
	Typography,
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Divider,
	Avatar
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import GoogleMapReact from 'google-map-react';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import DirectionsRenderer from "./directionsRenderer";
import CompleteRequest from "./modal/completeRequest";
import { toast } from 'react-toastify';
import { can } from "../../utils/helper";

interface Job {
	unique_id: string,
	created_at: string,
	material_name: string,
	material_other: string,
	order_no: string,
	total_mileage: number,
	total_load: string,
	equipment_id: string,
	equipment_name: string,
	equipment_other: string,
	load_spacing_minutes: string,
	available_load_count: string,
	is_hourly: number,
	per_unit_price: string,
	job_estimate_price: string,
	notes: string | null,
	pickup_date_time: string,
	delivery_date_time: string,
	load_type: any,
	weight: number,
	source_lat: string,
	source_lng: string,
	source: string,
	pickup_contact: string,
	pickup_location_email: string,
	pickup_location_contact_no: string,
	delivery_lat: string,
	delivery_lng: string,
	destination: string,
	drop_off_contact: string,
	drop_off_location_email: string,
	drop_off_location_contact_no: string,
}

interface JobLoad {
	load_id: string;
	weight: number;
	load_cost: number;
	trucker_taken_weight: number;
	started_on: string;
	completed_on: string;
	status: string;
}

interface JobDetails {
	id: number;
	user_id: number;
	contractor_details: ContractorDetails;
	truck_details: TruckDetail[];
	load_type_id: number;
	unique_id: string;
	order_no: string;
	job_type: number;
	pickup_location_company: string;
	pickup_location_contact_no: string;
	pickup_location_email: string;
	pickup_contact: string;
	drop_off_location_company: string;
	drop_off_location_contact_no: string;
	drop_off_location_email: string;
	drop_off_contact: string;
	scheduling_type: string | null;
	source: string;
	destination: string;
	pickup_date_time: string;
	delivery_date_time: string;
	source_lat: string;
	source_lng: string;
	delivery_lat: string;
	delivery_lng: string;
	priority: number;
	material_id: number;
	material_name: string;
	material_details: MaterialDetails;
	equipment_details: any;
	load_type: LoadType;
	total_load: string;
	material_other: string | null;
	material_option_id: number | null;
	material_option_other: string | null;
	truck_type_ids: string;
	fright_charges: number | null;
	equipment_id: number | null;
	equipment_name: string | null;
	equipment_other: string | null;
	equipment_option_id: number | null;
	equipment_option_other: string | null;
	no_of_trucks: number;
	total_mileage: string;
	load_spacing_minutes: string;
	per_unit: string;
	per_unit_price: string;
	job_estimate_price: string;
	total_miles: string;
	status: number;
	job_completed_date: string | null;
	payment_status: number;
	payment_type: string | null;
	payment_date: string | null;
	notes: string;
	is_draft: number;
	is_closed: number;
	is_hourly: number;
	available_loads: AvailableLoad[];
	job_created_by: number;
}

interface ContractorDetails {
	id: number;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
}

interface TruckDetail {
	truck_type_id: number;
	name: string;
	specs: number;
	weight_capacity: number;
	trucktype_image: string;
}

interface MaterialDetails {
	id: number;
	name: string;
}

interface LoadType {
	id: number;
	name: string;
	slug: string;
}

interface AvailableLoad {
	id: number;
	load_index: number;
	job_id: number;
	trucker_id: number;
	weight: string;
	contractor_added_weight: string | null;
	driver_load_weight: string;
	price_per_ton: string;
	load_cost: string;
	cal_comission: string;
	discounted_load_cost: string;
	min_completed_hours: number | null;
	max_completed_hours: number | null;
	reached_on: string;
	started_on: string;
	completed_on: string;
	status: number;
	cancellation_request_id: number | null;
	feedback: string | null;
	is_discarded: boolean;
	trucker_details: TruckerDetails;
	ticket_no: string;
	pickup_date_time: string;
	delivery_date_time: string;
	is_hourly: number;
	load_spacing: string;
	pickup_latitude: string;
	pickup_longitude: string;
	delivery_latitude: string;
	delivery_longitude: string;
}

interface TruckerDetails {
	id: number;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
	language: number;
	completed_steps: number;
	user_role: number;
	truck_type: string;
	truck_type_image: string;
	weight_capacity: number;
	rating: number | null;
	profile_image: string;
}
interface DriverEndJobRequest {
	job_id: number;
	load_id: number;
	contracter_name: string;
	load_actual_weight: string;
	trucker_taken_weight: string;
	ticket_no: string;
	challan: string;
	signed_challan: string;
	trucker_notes: string;
	additional_note: string;
	is_ticket_signed: number;
}
interface JobInfo {
	job_id: string;
	load_id: string;
}

const JobAction: React.FC = () => {
	const { id } = useParams();
	const userId = JSON.parse(localStorage.getItem('userDetails') || '{}').id;
	const [jobs, setJobs] = useState<JobDetails[]>([]);
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(0);
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [expanded, setExpanded] = useState<string | false>(false);
	const [endJobRequest, setEndJobRequest] = useState<DriverEndJobRequest | null>(null);
	const [openVerifyLoadModal, setOpenVerifyLoadModal] = React.useState(false);
	const [jobInfo, setJobInfo] = useState<JobInfo | null>({ job_id: "", load_id: "" });
	const [map, setMap] = useState<any>(null);
	const hasFetched = useRef(false);
	const navigate = useNavigate();

	const defaultProps = {
		center: {
			lat: 10.99835602,
			lng: 77.01502627
		},
		zoom: 11
	};

	const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
		lat: 22.5810906,
		lng: 88.4818398
	});

	const fetchPendingJobActions = async () => {
		setIsLoading(true);
		try {
			const response = await api.job.pendingJobActions(currentPage);
			if (response?.data) {
				setIsLoading(false);
				setJobs(response?.data || []);
				setTotalPages(response?.pagination?.total_pages || 0);
				setCurrentPage(response?.pagination?.current_page || 1);
			}
		} catch (error) {
			setIsLoading(false);
			console.error("Failed to fetch jobs:", error);
			setJobs([]);
		} finally {
			hasFetched.current = true;
		}
	};

	useEffect(() => {
		if (!can(['verify-job'])) {
			navigate(`/dashboard`);
		}
		if (hasFetched.current) return;
		fetchPendingJobActions();
	}, []);

	const handleChange = (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
		setExpanded(isExpanded ? panel : false);
	};

	const handleApiLoaded = (mapInstance: any, mapsInstance: any) => {
		setMap(mapInstance);
	};

	const showEndJobRequest = async (jobId: string, loadId: string) => {
		try {
			const response = await api.job.getDriverEndJobRequest(jobId, loadId);
			if (response) {
				setJobInfo({ job_id: jobId, load_id: loadId });
				setEndJobRequest(response);
				setOpenVerifyLoadModal(true);
			}
		} catch (error) {

		}
	};

	const handleCloseVerifyLoad = () => {
		setOpenVerifyLoadModal(false);
	}
	const handleAcceptCompleteLoadRequest = async (payload: any) => {
		try {
			const response = await api.job.approveDriverEndJobRequest(payload);

			if (response?.status) {
				fetchPendingJobActions();
				toast.success(response?.message);
			} else {
				toast.error(response?.message);
			}
		} catch (error) {
			console.error('Failed to send request:', error);
		}
	}

	return (
		<LayoutProvider pageTitle="Live Truck Loads" backUrl="/live-trucks">
			<Grid container spacing={3}>
				<Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox} sx={{ padding: "15px" }}>
					<CardContent className={styles.gridBoxwrap} sx={{ minHeight: '420px' }}>
						{isLoading ? (
							<Box className="loaderContainer">
								<Loader />
							</Box>
						) : null}

						{jobs?.length > 0 ? (
							<Box className={styles.jobSummary}>
								{jobs.map((jobDetails: JobDetails, jobIndex: number) => (
									<Box key={jobDetails.id} sx={{ marginBottom: '40px' }}>
										{/* Job Header */}
										<Typography
											variant="h6"
											className={styles.jobHeaderTitle}
											sx={{
												marginBottom: '20px',
												fontWeight: 'bold',
												color: '#333',
												borderBottom: '2px solid #e0e0e0',
												paddingBottom: '10px'
											}}
										>
											Job: {jobDetails.unique_id} - {jobDetails.material_name}
										</Typography>

										{/* Job Basic Details */}
										<Grid container spacing={2} sx={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f9f9f9', borderRadius: '8px' }}>
											<Grid size={{ md: 3, sm: 6, xs: 12 }}>
												<Typography className={styles.jobItalicTitle}>Order Number</Typography>
												<Typography className={styles.jobText}>{jobDetails.order_no}</Typography>
											</Grid>
											<Grid size={{ md: 3, sm: 6, xs: 12 }}>
												<Typography className={styles.jobItalicTitle}>Total Mileage</Typography>
												<Typography className={styles.jobText}>{jobDetails.total_mileage} Miles</Typography>
											</Grid>
											<Grid size={{ md: 3, sm: 6, xs: 12 }}>
												<Typography className={styles.jobItalicTitle}>Total Load</Typography>
												<Typography className={styles.jobText}>{jobDetails.total_load} Tons</Typography>
											</Grid>
											<Grid size={{ md: 3, sm: 6, xs: 12 }}>
												<Typography className={styles.jobItalicTitle}>Job Price</Typography>
												<Typography className={styles.jobText}>${jobDetails.job_estimate_price}</Typography>
											</Grid>
										</Grid>

										{/* Loads under this job */}
										{jobDetails.available_loads?.length > 0 ? (
											jobDetails.available_loads.map((jobLoad: AvailableLoad, loadIndex: number) => (
												<Accordion
													key={`${jobDetails.id}-${jobLoad.id}`}
													disableGutters
													elevation={0}
													sx={{
														'&:before': {
															display: 'none',
														},
														boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
														marginBottom: '15px'
													}}
													expanded={expanded === `job${jobIndex}-load${loadIndex}`}
													onChange={handleChange(`job${jobIndex}-load${loadIndex}`)}
												>
													<AccordionSummary
														aria-controls="panel2-content"
														id="location-header"
														expandIcon={(expanded === `job${jobIndex}-load${loadIndex}`) ?
															<RemoveIcon sx={{ color: "#808080", fontSize: "25px" }} /> :
															<AddIcon sx={{ color: "#808080", fontSize: "25px" }} />
														}
														sx={{
															backgroundColor: "#FFF9EC",
															color: "#333333",
															borderTopLeftRadius: '10px',
															borderTopRightRadius: '10px',
														}}
														className={styles.accordionHeader}
													>
														<Typography className={styles.accordionTitle}>
															Load - Status: {jobLoad.status === 1 ? 'Active' : jobLoad.status === 2 ? 'In Progress' : jobLoad.status === 3 ? 'Completed' : 'Unknown'}
														</Typography>
													</AccordionSummary>
													<AccordionDetails>
														<Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Material type</Typography>
																	<Typography className={styles.jobText}>
																		{jobDetails?.material_name.toLowerCase() !== 'other' ? jobDetails?.material_name : jobDetails?.material_other}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Order Number</Typography>
																	<Typography className={styles.jobText}>
																		{jobDetails?.order_no}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Pickup Date & Time</Typography>
																	<Typography className={styles.jobText}>
																		{jobLoad.started_on ? moment(jobLoad.started_on).format("DD MMM YYYY | hh:mm A") : '----'}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Drop Off Date & Time</Typography>
																	<Typography className={styles.jobText}>
																		{jobLoad.completed_on ? moment(jobLoad.completed_on).format("DD MMM YYYY | hh:mm A") : '----'}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Weight</Typography>
																	<Typography className={styles.jobText}>
																		{jobLoad.weight} Tons
																	</Typography>
																</Box>
															</Grid>
														</Grid>
														<Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Load Spacing in Minutes</Typography>
																	<Typography className={styles.jobText}>
																		{jobDetails?.load_spacing_minutes}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Load Price</Typography>
																	<Typography className={styles.jobText}>
																		$ {jobLoad.load_cost ? Number(jobLoad.load_cost).toFixed(2) : '0.00'}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Total Mileage</Typography>
																	<Typography className={styles.jobText}>
																		{jobDetails?.total_mileage} Miles
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Weight Received by Trucker</Typography>
																	<Typography className={styles.jobText}>
																		{jobLoad.driver_load_weight ?? '----'}
																	</Typography>
																</Box>
															</Grid>
															<Grid className={styles.runningJobBox}>
																<Box className={styles.jobBox}>
																	<Typography className={styles.jobItalicTitle}>Weight Received by Contractor</Typography>
																	<Typography className={styles.jobText}>
																		{jobLoad.status == 4 ? jobLoad.weight : '----'}
																	</Typography>
																</Box>
															</Grid>
														</Grid>
														<Divider
															sx={{
																borderColor: 'divider',
																position: 'sticky',
																top: 0,
																zIndex: 1,
															}}
														/>
														<Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ padding: "20px 10px" }}>
															<Typography className={styles.loadTitle}>Job Locations</Typography>
															<Grid container spacing={0}>
																<Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
																	<Box className={styles.active}>
																		<Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
																			<span className={`${styles.circle} ${styles.orange}`} />
																			Pickup <span>(Lat: {jobDetails?.source_lat} | Long: {jobDetails?.source_lng})</span>
																		</Typography>
																		<Box sx={{ marginLeft: '20px' }}>
																			<Typography className={styles.locationDate}>
																				{moment(`${jobLoad.started_on}`).format("DD MMM YYYY | hh:mm A")}
																			</Typography>
																			<Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
																				<BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.source}
																			</Typography>
																			<Typography className={styles.locationPerson}>
																				<PersonIcon className={styles.personIcon} /> {jobDetails?.pickup_contact}
																			</Typography>
																			<Typography className={styles.personContact}>
																				<EmailIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_contact_no}
																			</Typography>
																		</Box>
																	</Box>

																	<Box>
																		<Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
																			<span className={`${styles.circle} ${styles.green}`} />
																			Drop Off <span>(Lat: {jobDetails?.delivery_lat} | Long: {jobDetails?.delivery_lng})</span>
																		</Typography>
																		<Box sx={{ marginLeft: '20px' }}>
																			<Typography className={styles.locationDate}>
																				{jobLoad.completed_on ? moment(`${jobLoad.completed_on}`).format("DD MMM YYYY | hh:mm A") : '----'}
																			</Typography>
																			<Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
																				<BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.destination}
																			</Typography>
																			<Typography className={styles.locationPerson}>
																				<PersonIcon className={styles.personIcon} /> {jobDetails?.drop_off_contact}
																			</Typography>
																			<Typography className={styles.personContact}>
																				<EmailIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_contact_no}
																			</Typography>
																		</Box>
																	</Box>
																</Grid>
																<Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
																	<Box style={{ height: '40vh', width: '100%' }}>
																		{GOOGLE_MAPS_API_KEY ? (
																			<GoogleMapReact
																				bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
																				defaultCenter={defaultProps.center}
																				center={{
																					lat: Number(jobDetails?.source_lat) || mapCenter.lat,
																					lng: Number(jobDetails?.source_lng) || mapCenter.lng
																				}}
																				defaultZoom={14}
																				zoom={14}
																				onGoogleApiLoaded={({ map, maps }) => handleApiLoaded(map, maps)}
																			>
																				{map && (
																					<DirectionsRenderer
																						map={map}
																						origin={{ lat: Number(jobDetails?.source_lat), lng: Number(jobDetails?.source_lng) }}
																						destination={{ lat: Number(jobDetails?.delivery_lat), lng: Number(jobDetails?.delivery_lng) }}
																					/>
																				)}
																			</GoogleMapReact>
																		) : null}
																	</Box>
																	<Box className={styles.truckerDetails}>
																		<Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 2 }}>
																			<Avatar
																				alt={`${jobLoad?.trucker_details?.fname} ${jobLoad?.trucker_details?.lname}`}
																				src={jobLoad?.trucker_details?.profile_image}
																				sx={{ width: '50px', height: '50px' }}
																			/>
																			<Box>
																				<Typography className={styles.locationPerson}>
																					<PersonIcon className={styles.personIcon} /> {`${jobLoad?.trucker_details?.fname} ${jobLoad?.trucker_details?.lname}`}
																				</Typography>
																				<Typography className={styles.personContact} sx={{ marginLeft: '2px !important' }}>
																					<EmailIcon className={styles.contactIcon} /> {jobLoad?.trucker_details?.email}
																				</Typography>
																			</Box>
																		</Box>
																	</Box>
																	<Button
																		className={styles.liveTruckLink}
																		onClick={() => showEndJobRequest(jobDetails?.id?.toString(), jobLoad?.id?.toString())}
																	>
																		Show Request
																	</Button>
																</Grid>
															</Grid>
														</Grid>
													</AccordionDetails>
												</Accordion>
											))
										) : (
											<Typography sx={{ padding: '20px', textAlign: 'center', color: '#666' }}>
												No loads available for this job
											</Typography>
										)}
									</Box>
								))}
							</Box>
						) : (
							<div className={styles.noDataContainer}>
								<Typography variant="h6" color="textSecondary" align="center">
									{/* <AssignmentLateIcon fontSize="large" /> */}
									<img
										src="/assets/images/no_nearest_trucker.png"
										className={styles.noTruckerImage}
										alt="No nearest trucker"
									/>
									<br />
									No Pending action found on job
								</Typography>

								<Typography onClick={fetchPendingJobActions} style={{ textDecoration: 'none', color: '#007A2F', fontWeight: '500', cursor: 'pointer' }}>
									Find Again?
								</Typography>
							</div>
						)}
					</CardContent>
					<CompleteRequest
						jobId={jobInfo.job_id}
						loadId={jobInfo.load_id}
						open={openVerifyLoadModal}
						onClose={handleCloseVerifyLoad}
						endJobRequest={endJobRequest}
						onCompleteRequest={handleAcceptCompleteLoadRequest}
					/>
				</Grid>
			</Grid>
		</LayoutProvider>
	);
};

export default JobAction;