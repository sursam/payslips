"use client";
import React, { useEffect, useState } from 'react'
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer } from '@react-google-maps/api';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
const containerStyle = {
    width: '400px',
    height: '400px '
};

let directionsService: google.maps.DirectionsService;

function MapContainer() {
    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: GOOGLE_MAPS_API_KEY || ""
    });

    const pickupCoordinates = {
        lat: -33.8827923,
        lng: 151.1959758
    }

    const deliveryCoordinates = {
        lat: -33.8876642,
        lng: 151.2086783
    }

    const [deliveryGuyPosition, setDeliveryGuyPosition] = useState(deliveryCoordinates);
    const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);

    const [_, setMap] = React.useState<google.maps.Map | null>(null)

    const onLoad = React.useCallback(function callback(map: google.maps.Map) {
        const bounds = new window.google.maps.LatLngBounds();
        directionsService = new google.maps.DirectionsService();
        bounds.extend(deliveryCoordinates);
        bounds.extend(pickupCoordinates);
        map.fitBounds(bounds);

        changeDirection(pickupCoordinates, deliveryCoordinates);
        setMap(map)
    }, []);

    const changeDirection = (origin: any, destination: any) => {
        directionsService.route(
            {
                origin: origin,
                destination: destination,
                travelMode: google.maps.TravelMode.DRIVING
            },
            (result, status) => {
                if (status === google.maps.DirectionsStatus.OK) {
                    // Change the state of directions to the result of direction service
                    setDirections(result);
                } else {
                    console.error(`Error fetching directions ${result}`);
                }
            }
        );
    };

    const onUnmount = React.useCallback(function callback() {
        setMap(null)
    }, [])

    useEffect(() => {
        const interval = setInterval(() => {
            setDeliveryGuyPosition(prevPos => ({
                lat: prevPos.lat + (Math.random() - 0.5) * 0.001, // Small random change
                lng: prevPos.lng + (Math.random() - 0.5) * 0.001,
            }));
        }, 1000); // Update every second

        return () => clearInterval(interval);
    }, []);

    return (isLoaded && <GoogleMap mapContainerStyle={containerStyle} onLoad={onLoad} onUnmount={onUnmount}>
        {directions !== null && <DirectionsRenderer directions={directions}
            options={{
                markerOptions: {
                    icon: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
                }
            }}
        />}
        <Marker position={pickupCoordinates} title="pick up location" />
        <Marker position={deliveryGuyPosition} title="Delivery Guy" />
    </GoogleMap>)

}

export default React.memo(MapContainer)