import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import moment from 'moment';
import {
    Box,
    CardContent,
    Grid,
    Typography,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Divider,
    Avatar
} from '@mui/material';
// import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import GoogleMapReact from 'google-map-react';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import DirectionsRenderer from "./directionsRenderer";
import { can } from "../../utils/helper";

interface Job {
    unique_id: string,
    created_at: string,
    material_name: string,
    material_other: string,
    order_no: string,
    total_mileage: number,
    total_load: string,
    equipment_id: string,
    equipment_name: string,
    equipment_other: string,
    load_spacing_minutes: string,
    available_load_count: string,
    is_hourly: number,
    per_unit_price: string,
    job_estimate_price: string,
    notes: string | null,
    pickup_date_time: string,
    delivery_date_time: string,
    load_type: any,
    weight: number,
    source_lat: string,
    source_lng: string,
    source: string,
    pickup_contact: string,
    pickup_location_email: string,
    pickup_location_contact_no: string,
    delivery_lat: string,
    delivery_lng: string,
    destination: string,
    drop_off_contact: string,
    drop_off_location_email: string,
    drop_off_location_contact_no: string,
}
interface JobLoad {
    load_id: string;
    weight: number;
    load_cost: number;
    trucker_taken_weight: number;
    started_on: string;
    completed_on: string;
    status: string;
    // destination: string;
    // pickup_date_time: string;
    // total_job_cost: number;
    // delivery_date_time: string;
    // total_job_load: number;
}



const LiveTruckLoads: React.FC = () => {
    const { id } = useParams();
    const [jobDetails, setJobDetails] = useState<Job | null>(null);
    const [jobLoads, setJobLoads] = useState<JobLoad[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [expanded, setExpanded] = useState<any>(false);
    const hasFetched = useRef(false);
    const navigate = useNavigate();
    const defaultProps = {
        center: {
            lat: 10.99835602,
            lng: 77.01502627
        },
        zoom: 11
    };
    const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
        lat: 22.5810906,  // default or initial location
        lng: 88.4818398
    });

    const [map, setMap] = useState<google.maps.Map | null>(null);

    function handleApiLoaded(mapInstance: google.maps.Map, google: any) {
        setMap(mapInstance);
    }

    const handleChange = (panel: any) => (event: any, isExpanded: any) => {
        setExpanded(isExpanded ? panel : false);
    };

    const fetchJobLoads = async () => {
        setIsLoading(true);
        try {
            const payload = {
                job_id: id,
            };
            const response = await api.job.getRunningJobLoads(payload);
            if (response?.data.length) {
                setIsLoading(false);
                setJobLoads(response.data);
                setExpanded('panel1');
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobLoads([]);
        } finally {
            hasFetched.current = true;
        }
    };
    const fetchJobDetails = async () => {
        setIsLoading(true);
        try {
            let jobId: any = id;
            const response = await api.job.getJobDetails(jobId);
            if (response?.data) {
                setIsLoading(false);
                setJobDetails(response.data);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobDetails(null);
        } finally {
            hasFetched.current = true;
        }
    };
    // Separate useEffect for data fetching
    useEffect(() => {
        if (!can(['view-loads'])) {
            navigate(`/dashboard`);
        }
        if (hasFetched.current) return;

        fetchJobDetails();
        fetchJobLoads();
    }, [id]); // Re-fetch when tab value changes


    return (

        <LayoutProvider pageTitle="Live Truck Loads" backUrl="/live-trucks">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox} sx={{ padding: "15px" }}>
                    <CardContent className={styles.gridBoxwrap} sx={{ minHeight: '420px' }}>
                        {isLoading ?
                            <Box className="loaderContainer">
                                <Loader />
                            </Box>
                            : ''
                        }

                        {jobLoads?.length > 0 ?
                            <Box className={styles.jobSummary} >
                                {jobLoads?.map((jobLoad: any, k: number) => {
                                    return (
                                        <Accordion
                                            // defaultExpanded
                                            disableGutters
                                            elevation={0}
                                            sx={{
                                                '&:before': {
                                                    display: 'none',
                                                },
                                                boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
                                                marginBottom: '30px'
                                            }}
                                            key={jobLoad.load_id}
                                            expanded={expanded === `panel${k + 1}`}
                                            onChange={handleChange(`panel${k + 1}`)}
                                        >
                                            <AccordionSummary
                                                aria-controls="panel2-content"
                                                id="location-header"
                                                // expandIcon={<ArrowDropDownIcon sx={{ color: "#808080", fontSize: "25px" }} />}
                                                expandIcon={(expanded === `panel${k + 1}`) ? <RemoveIcon sx={{ color: "#808080", fontSize: "25px" }} /> : <AddIcon sx={{ color: "#808080", fontSize: "25px" }} />}
                                                sx={{
                                                    backgroundColor: "#FFF9EC",
                                                    color: "#333333",
                                                    borderTopLeftRadius: '10px',
                                                    borderTopRightRadius: '10px',
                                                }}
                                                className={styles.accordionHeader}
                                            >
                                                <Typography className={styles.accordionTitle}>
                                                    Load {k + 1}
                                                </Typography>
                                            </AccordionSummary>
                                            <AccordionDetails>
                                                <Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Material type</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobDetails?.material_name.toLowerCase() != 'other' ? jobDetails?.material_name : jobDetails?.material_other}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Order Number</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobDetails?.order_no}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Pickup Date & Time</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobLoad.started_on ? moment(jobLoad.started_on).format("DD MMM YYYY | hh:mm A") : '----'}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Drop Off Date & Time</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobLoad.completed_on ? moment(jobLoad.completed_on).format("DD MMM YYYY | hh:mm A") : '----'}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Weight</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobLoad.weight} Tons
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                                <Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Load Spacing in Minutes</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobDetails?.load_spacing_minutes}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Load Price</Typography>
                                                            <Typography className={styles.jobText}>
                                                                $ {jobLoad.load_cost ? jobLoad.load_cost.toFixed(2) : '0.00'}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Total Millage</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobDetails?.total_mileage} Miles
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Weight Received by Trucker</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobLoad.trucker_taken_weight ? `${jobLoad.trucker_taken_weight} Tons` : '----'}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                    <Grid className={styles.runningJobBox}>
                                                        <Box className={styles.jobBox}>
                                                            <Typography className={styles.jobItalicTitle}>Weight Received by Contractor</Typography>
                                                            <Typography className={styles.jobText}>
                                                                {jobLoad.status == 4 ? jobLoad.weight : '----'}
                                                            </Typography>
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                                <Divider
                                                    sx={{
                                                        borderColor: 'divider',
                                                        position: 'sticky',
                                                        top: 0,
                                                        zIndex: 1,
                                                    }}
                                                />
                                                <Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ padding: "20px 10px" }}>
                                                    <Typography className={styles.loadTitle}>Job Locations</Typography>
                                                    <Grid container spacing={0}>
                                                        {/* <line x1="120" y1="100" x2="480" y2="100" stroke="black" strokeWidth="2" /> */}
                                                        <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
                                                            <Box className={styles.active}>
                                                                <Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
                                                                    <span className={`${styles.circle} ${styles.orange}`} />
                                                                    Pickup <span>(Lat: {jobDetails?.source_lat} | Long: {jobDetails?.source_lng})</span>
                                                                </Typography>
                                                                <Box sx={{ marginLeft: '20px' }}>
                                                                    <Typography className={styles.locationDate}>
                                                                        {moment(`${jobLoad.started_on}`).format("DD MMM YYYY | hh:mm A")}
                                                                    </Typography>
                                                                    <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                                                        <BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.source}
                                                                    </Typography>
                                                                    <Typography className={styles.locationPerson}>
                                                                        <PersonIcon className={styles.personIcon} /> {jobDetails?.pickup_contact}
                                                                    </Typography>
                                                                    <Typography className={styles.personContact}>
                                                                        <EmailIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_contact_no}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>

                                                            <Box>
                                                                <Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
                                                                    <span className={`${styles.circle} ${styles.green}`} />
                                                                    Drop Off <span>(Lat: {jobDetails?.delivery_lat} | Long: {jobDetails?.delivery_lng})</span>
                                                                </Typography>
                                                                <Box sx={{ marginLeft: '20px' }}>
                                                                    <Typography className={styles.locationDate}>
                                                                        {jobLoad.completed_on ? moment(`${jobLoad.completed_on}`).format("DD MMM YYYY | hh:mm A") : '----'}
                                                                    </Typography>
                                                                    <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                                                        <BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.destination}
                                                                    </Typography>
                                                                    <Typography className={styles.locationPerson}>
                                                                        <PersonIcon className={styles.personIcon} /> {jobDetails?.drop_off_contact}
                                                                    </Typography>
                                                                    <Typography className={styles.personContact}>
                                                                        <EmailIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_contact_no}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>
                                                        </Grid>
                                                        <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
                                                            <Box style={{ height: '40vh', width: '100%' }}>
                                                                {GOOGLE_MAPS_API_KEY ?
                                                                    <GoogleMapReact
                                                                        bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
                                                                        defaultCenter={defaultProps.center}
                                                                        center={mapCenter}
                                                                        defaultZoom={14}
                                                                        zoom={14}
                                                                        onGoogleApiLoaded={({ map, maps }) => handleApiLoaded(map, maps)}
                                                                    >
                                                                        {map && (
                                                                            <DirectionsRenderer
                                                                                map={map}
                                                                                origin={{ lat: Number(jobDetails?.source_lat), lng: Number(jobDetails?.source_lng) }}
                                                                                destination={{ lat: Number(jobDetails?.delivery_lat), lng: Number(jobDetails?.delivery_lng) }}
                                                                            />
                                                                        )}
                                                                    </GoogleMapReact>
                                                                    : ''}

                                                            </Box>
                                                            <Box className={styles.truckerDetails}>
                                                                <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                                                                    <Avatar
                                                                        alt={`${jobLoad?.trucker_details?.fname} ${jobLoad?.trucker_details?.lname}`}
                                                                        src={jobLoad?.trucker_details?.image}
                                                                        sx={{ width: '50px', height: '50px' }}
                                                                    />
                                                                    <Box>
                                                                        <Typography className={styles.locationPerson}>
                                                                            <PersonIcon className={styles.personIcon} /> {`${jobLoad?.trucker_details?.fname} ${jobLoad?.trucker_details?.lname}`}
                                                                        </Typography>
                                                                        <Typography className={styles.personContact} sx={{ marginLeft: '2px !important' }}>
                                                                            <EmailIcon className={styles.contactIcon} /> {jobLoad?.trucker_details?.email}
                                                                        </Typography>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                            <Link
                                                                to={`/live-truck-location/${id}/${jobLoad?.load_id}`}
                                                                className={styles.liveTruckLink}
                                                            >
                                                                View Live Location
                                                            </Link>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </AccordionDetails>
                                        </Accordion>
                                    );
                                })}
                            </Box>
                            :
                            ''
                        }

                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default LiveTruckLoads;
