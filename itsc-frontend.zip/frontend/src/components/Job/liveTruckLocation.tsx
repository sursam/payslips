import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import moment from 'moment';
import {
    Box,
    CardContent,
    Grid,
    Typography,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Divider,
    Avatar
} from '@mui/material';
// import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import GoogleMapReact from 'google-map-react';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
// import DirectionsRenderer from "./directionsRenderer";
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer } from '@react-google-maps/api';
import { can } from "../../utils/helper";

interface Job {
    unique_id: string,
    created_at: string,
    material_name: string,
    material_other: string,
    order_no: string,
    total_mileage: number,
    total_load: string,
    equipment_id: string,
    equipment_name: string,
    equipment_other: string,
    load_spacing_minutes: string,
    available_load_count: string,
    is_hourly: number,
    per_unit_price: string,
    job_estimate_price: string,
    notes: string | null,
    pickup_date_time: string,
    delivery_date_time: string,
    load_type: any,
    weight: number,
    source_lat: string,
    source_lng: string,
    source: string,
    pickup_contact: string,
    pickup_location_email: string,
    pickup_location_contact_no: string,
    delivery_lat: string,
    delivery_lng: string,
    destination: string,
    drop_off_contact: string,
    drop_off_location_email: string,
    drop_off_location_contact_no: string,
}
interface JobLoad {
    load_id: string;
    weight: number;
    load_cost: number;
    trucker_taken_weight: number;
    started_on: string;
    completed_on: string;
    status: number;
    trucker_details: {
        fname: string,
        lname: string,
        image: string,
        email: string
    }
}



const LiveTruckLocation: React.FC = () => {
    const { id, lid } = useParams();
    const [jobDetails, setJobDetails] = useState<Job | null>(null);
    const [jobLoad, setJobLoad] = useState<JobLoad | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const navigate = useNavigate();
    const hasFetched = useRef(false);
    const containerStyle = {
        width: '100%',
        height: '100% '
    };
    let directionsService: google.maps.DirectionsService;
    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: GOOGLE_MAPS_API_KEY || ""
    });
    const [destinationCoordinates, setDestinationCoordinates] = useState({
        lat: 0,
        lng: 0
    });
    const [truckerPosition, setTruckerPosition] = useState({
        lat: 0,
        lng: 0
    });
    const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);

    const [_, setMap] = React.useState<google.maps.Map | null>(null)

    const onLoad = React.useCallback(async function callback(map: google.maps.Map) {
        setIsLoading(true);
        try {
            let jobId: any = id;
            const response = await api.job.getJobDetails(jobId);
            if (response?.data) {
                setIsLoading(false);
                setJobDetails(response.data);

                let truckerPos = {
                    lat: Number(response.data.source_lat),
                    lng: Number(response.data.source_lng)
                };
                let destinationPos = {
                    lat: Number(response.data.delivery_lat),
                    lng: Number(response.data.delivery_lng)
                };
                setTruckerPosition(truckerPos);
                setDestinationCoordinates(destinationPos);

                const bounds = new window.google.maps.LatLngBounds();
                directionsService = new google.maps.DirectionsService();
                bounds.extend(truckerPos);
                bounds.extend(destinationPos);
                map.fitBounds(bounds);

                changeDirection(destinationPos, truckerPos);
                setMap(map)
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobDetails(null);
        } finally {
            hasFetched.current = true;
        }
    }, []);

    const changeDirection = (origin: any, destination: any) => {
        directionsService.route(
            {
                origin: origin,
                destination: destination,
                travelMode: google.maps.TravelMode.DRIVING
            },
            (result, status) => {
                if (status === google.maps.DirectionsStatus.OK) {
                    // Change the state of directions to the result of direction service
                    setDirections(result);
                } else {
                    console.error(`Error fetching directions ${result}`);
                }
            }
        );
    };

    const onUnmount = React.useCallback(function callback() {
        setMap(null)
    }, [])




    // const defaultProps = {
    //     center: {
    //         lat: 10.99835602,
    //         lng: 77.01502627
    //     },
    //     zoom: 11
    // };
    // const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
    //     lat: 22.5810906,  // default or initial location
    //     lng: 88.4818398
    // });

    // const [map, setMap] = useState<google.maps.Map | null>(null);

    // function handleApiLoaded(mapInstance: google.maps.Map, google: any) {
    //     setMap(mapInstance);
    // }

    const fetchJobLoadDetails = async () => {
        // setIsLoading(true);
        try {
            const payload = {
                job_id: id,
                load_id: lid,
            };
            const response = await api.job.getRunningJobLoadDetails(payload);
            if (response?.data) {
                // setIsLoading(false);
                setJobLoad(response.data);
                if (response.data.driver_current_lat && response.data.driver_current_lng) {
                    setTruckerPosition(prevPos => ({
                        lat: response.data.driver_current_lat, // Small random change
                        lng: response.data.driver_current_lng,
                    }));
                }
            }
        } catch (error) {
            // setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
        } finally {
            hasFetched.current = true;
        }
    };
    const fetchJobDetails = async () => {
        setIsLoading(true);
        try {
            let jobId: any = id;
            const response = await api.job.getJobDetails(jobId);
            if (response?.data) {
                setIsLoading(false);
                setJobDetails(response.data);
                setDestinationCoordinates({
                    lat: Number(response.data.delivery_lat),
                    lng: Number(response.data.delivery_lng)
                });
                setTruckerPosition({
                    lat: Number(response.data.source_lat),
                    lng: Number(response.data.source_lng)
                });
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobDetails(null);
        } finally {
            hasFetched.current = true;
        }
    };
    // Separate useEffect for data fetching
    useEffect(() => {
        if (!can(['view-loads'])) {
            navigate(`/dashboard`);
        }
        if (hasFetched.current) return;

        fetchJobDetails();
        // fetchJobLoadDetails();

        if (!isLoading) {
            const interval = setInterval(async () => {
                fetchJobLoadDetails();
                // setTruckerPosition(prevPos => ({
                //     lat: prevPos.lat + (Math.random() - 0.5) * 0.001, // Small random change
                //     lng: prevPos.lng + (Math.random() - 0.5) * 0.001,
                // }));

            }, 5000); // Update every 5 seconds
            return () => clearInterval(interval);
        }

    }, [id]); // Re-fetch when tab value changes

    return (

        <LayoutProvider pageTitle="Track Live Truck Load" backUrl={`/live-truck-loads/${id}`}>
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox} sx={{ padding: "15px" }}>
                    <CardContent className={styles.gridBoxwrap} sx={{ minHeight: '420px' }}>
                        {isLoading ?
                            <Box className="loaderContainer">
                                <Loader />
                            </Box>
                            : ''
                        }

                        <Box className={styles.jobSummary} >

                            <Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Material type</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobDetails?.material_name.toLowerCase() != 'other' ? jobDetails?.material_name : jobDetails?.material_other}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Order Number</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobDetails?.order_no}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Pickup Date & Time</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobLoad?.started_on ? moment(jobLoad.started_on).format("DD MMM YYYY | hh:mm A") : '----'}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Drop Off Date & Time</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobLoad?.completed_on ? moment(jobLoad.completed_on).format("DD MMM YYYY | hh:mm A") : '----'}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Weight</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobLoad?.weight} {jobDetails?.load_type?.name}
                                        </Typography>
                                    </Box>
                                </Grid>
                            </Grid>
                            <Grid container spacing={0} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Load Spacing in Minutes</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobDetails?.load_spacing_minutes}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Load Price</Typography>
                                        <Typography className={styles.jobText}>
                                            $ {jobLoad?.load_cost ? jobLoad.load_cost.toFixed(2) : '0.00'}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Total Millage</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobDetails?.total_mileage} Miles
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Weight Received by Trucker</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobLoad?.trucker_taken_weight ? `${jobLoad?.trucker_taken_weight} Tons` : '----'}
                                        </Typography>
                                    </Box>
                                </Grid>
                                <Grid className={styles.runningJobBox}>
                                    <Box className={styles.jobBox}>
                                        <Typography className={styles.jobItalicTitle}>Weight Received by Contractor</Typography>
                                        <Typography className={styles.jobText}>
                                            {jobLoad?.status == 4 ? `${jobLoad.weight} Tons` : '----'}
                                        </Typography>
                                    </Box>
                                </Grid>
                            </Grid>
                            <Divider
                                sx={{
                                    borderColor: 'divider',
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 1,
                                }}
                            />
                            <Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ padding: "20px 10px" }}>
                                <Typography className={styles.loadTitle}>Job Locations</Typography>
                                <Grid container spacing={0}>
                                    <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
                                        <Box className={styles.active}>
                                            <Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
                                                <span className={`${styles.circle} ${styles.orange}`} />
                                                Pickup <span>(Lat: {jobDetails?.source_lat} | Long: {jobDetails?.source_lng})</span>
                                            </Typography>
                                            <Box sx={{ marginLeft: '20px' }}>
                                                <Typography className={styles.locationDate}>
                                                    {jobLoad?.started_on ? moment(`${jobLoad?.started_on}`).format("DD MMM YYYY | hh:mm A") : '----'}
                                                </Typography>
                                                <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                                    <BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.source}
                                                </Typography>
                                                <Typography className={styles.locationPerson}>
                                                    <PersonIcon className={styles.personIcon} /> {jobDetails?.pickup_contact}
                                                </Typography>
                                                <Typography className={styles.personContact}>
                                                    <EmailIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.pickup_location_contact_no}
                                                </Typography>
                                            </Box>
                                        </Box>

                                        <Box>
                                            <Typography className={`${styles.locationTitle}`} sx={{ color: '#666666' }}>
                                                <span className={`${styles.circle} ${styles.green}`} />
                                                Drop Off <span>(Lat: {jobDetails?.delivery_lat} | Long: {jobDetails?.delivery_lng})</span>
                                            </Typography>
                                            <Box sx={{ marginLeft: '20px' }}>
                                                <Typography className={styles.locationDate}>
                                                    {jobLoad?.completed_on ? moment(`${jobLoad.completed_on}`).format("DD MMM YYYY | hh:mm A") : '----'}
                                                </Typography>
                                                <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                                    <BusinessCenterIcon className={styles.locationIcon} /> {jobDetails?.destination}
                                                </Typography>
                                                <Typography className={styles.locationPerson}>
                                                    <PersonIcon className={styles.personIcon} /> {jobDetails?.drop_off_contact}
                                                </Typography>
                                                <Typography className={styles.personContact}>
                                                    <EmailIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_email} | <PhoneIphoneIcon className={styles.contactIcon} /> {jobDetails?.drop_off_location_contact_no}
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px" }}>
                                        <Box style={{ height: '40vh', width: '100%' }}>
                                            {/* {GOOGLE_MAPS_API_KEY ?
                                                <GoogleMapReact
                                                    bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
                                                    defaultCenter={defaultProps.center}
                                                    center={mapCenter}
                                                    defaultZoom={14}
                                                    zoom={14}
                                                    onGoogleApiLoaded={({ map, maps }) => handleApiLoaded(map, maps)}
                                                >
                                                    {map && (
                                                        <DirectionsRenderer
                                                            map={map}
                                                            origin={{ lat: Number(jobDetails?.source_lat), lng: Number(jobDetails?.source_lng) }}
                                                            destination={{ lat: Number(jobDetails?.delivery_lat), lng: Number(jobDetails?.delivery_lng) }}
                                                        />
                                                    )}
                                                </GoogleMapReact>
                                                : ''} */}
                                            {isLoaded && <GoogleMap mapContainerStyle={containerStyle} onLoad={onLoad} onUnmount={onUnmount}>
                                                {directions !== null && <DirectionsRenderer directions={directions}
                                                    options={{
                                                        markerOptions: {
                                                            icon: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
                                                        }
                                                    }}
                                                />}
                                                <Marker position={destinationCoordinates} title="Delivery location" />
                                                <Marker position={truckerPosition} title="Trucker Location" />
                                            </GoogleMap>}

                                        </Box>
                                        <Box className={styles.truckerDetails}>
                                            <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                                                <Avatar
                                                    alt={`${jobLoad?.trucker_details?.fname} ${jobLoad?.trucker_details?.lname}`}
                                                    src={jobLoad?.trucker_details?.image}
                                                    sx={{ width: '50px', height: '50px' }}
                                                />
                                                <Box>
                                                    <Typography className={styles.locationPerson}>
                                                        <PersonIcon className={styles.personIcon} />{' '}
                                                        {jobLoad?.trucker_details
                                                            ? `${jobLoad.trucker_details.fname} ${jobLoad.trucker_details.lname}`
                                                            : 'Loading...'}
                                                    </Typography>

                                                    <Typography
                                                        className={styles.personContact}
                                                        sx={{ marginLeft: '2px !important' }}
                                                    >
                                                        <EmailIcon className={styles.contactIcon} />{' '}
                                                        {jobLoad?.trucker_details ? jobLoad.trucker_details.email : 'Loading...'}
                                                    </Typography>
                                                </Box>

                                            </Box>
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Box>

                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default LiveTruckLocation;
