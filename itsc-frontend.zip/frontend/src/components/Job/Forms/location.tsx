import React from 'react';
import { TextField, Typography, Box, Grid, FormControl, Divider, Stack, Autocomplete } from '@mui/material';
import styles from '../../../styles/job.module.css';
import LocationInput from '../../CustomFields/locationInput';
import Loader from '../../Loader/loader';
import PhoneInput from 'react-phone-input-2';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleCompanyAutoCompleteChange: (name: any, value: any, isFetch?: any) => void;
    handleDateChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onContactNumberChange: (value: any, data: any, event: any, formattedValue: any) => void;
    setLocationData: any;
    state: any;
    isLoading: any;
    existingCompanies: any;
}
const Location: React.FC<ChildProps> = ({ errors, register, handleChange, handleCompanyAutoCompleteChange, handleDateChange, setLocationData, state, isLoading, existingCompanies, onContactNumberChange }) => {
    return (
        <Box className={styles.formContainer}>
            {isLoading ?
                <Box className="loaderContainer">
                    <Loader />
                </Box>
                : ''
            }
            <Grid container spacing={0}>
                <Grid size={{ md: 6, sm: 12, xs: 12 }} sx={{ borderRight: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }} className={styles.formBox}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle}>
                        Pickup Location
                    </Typography>
                    <FormControl sx={{ marginBottom: '10px' }} className={styles.locationBox} fullWidth>
                        <LocationInput
                            setLocationData={setLocationData}
                            id="pickupLocation"
                            name="pickupLocation"
                            value={state.pickupLocation}
                            className={`${styles.formControl} locfield ${errors?.pickupLocation ? 'is-invalid' : ''}`}
                        />
                        <div className="invalid-feedback">{errors.pickupLocation?.message?.toString()}</div>
                    </FormControl>
                    <Divider sx={{ color: '#999999' }}>OR</Divider>
                    <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: "10px", sm: '20px', md: '30px' } }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Latitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="number"
                                inputMode="decimal"
                                value={state.pickupLatitude}
                                className={`${styles.formControl} ${errors?.pickupLatitude ? 'is-invalid' : ''}`}
                                {...register('pickupLatitude', {
                                    onChange: handleChange,
                                    validate: value => !isNaN(parseFloat(value)) || 'Enter a valid decimal number'
                                })}
                                inputProps={{
                                    autoComplete: "pickupLatitude",
                                    step: "any",
                                    onKeyDown: (e) => {
                                        if (["e", "E", "+", "-"].includes(e.key)) {
                                            e.preventDefault();
                                        }
                                    }
                                }}
                            />
                            <div className="invalid-feedback">{errors.pickupLatitude?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Longitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="number"
                                inputMode="decimal"
                                value={state.pickupLongitude}
                                className={`${styles.formControl} ${errors?.pickupLongitude ? 'is-invalid' : ''}`}
                                {...register('pickupLongitude', {
                                    onChange: handleChange,
                                    validate: value => !isNaN(parseFloat(value)) || 'Enter a valid decimal number'
                                })}
                                inputProps={{
                                    autoComplete: "pickupLongitude",
                                    step: "any", // allows decimal input
                                    onKeyDown: (e) => {
                                        if (["e", "E", "+", "-"].includes(e.key)) {
                                            e.preventDefault();
                                        }
                                    }
                                }}
                            />
                            <div className="invalid-feedback">{errors.pickupLongitude?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                    <FormControl fullWidth>
                        <Stack sx={{ marginTop: '16px', marginBottom: '8px' }}>
                            <Autocomplete
                                freeSolo
                                id="pickupCompanyName"
                                disableClearable
                                options={existingCompanies.map((option) => option.title)}
                                value={state.pickupCompanyName}
                                onChange={(event, newValue) => {
                                    handleCompanyAutoCompleteChange('pickupCompanyName', newValue, true);
                                }}
                                onInputChange={(event, newValue) => {
                                    handleCompanyAutoCompleteChange('pickupCompanyName', newValue);
                                }}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Company Name"
                                        className={`${styles.formControl} ${errors?.pickupCompanyName ? 'is-invalid' : ''}`}
                                        slotProps={{
                                            input: {
                                                ...params.InputProps,
                                                type: 'search',
                                            },
                                        }}
                                    />
                                )}
                            />
                        </Stack>

                        {/* <TextField
                            label="Company Name"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.pickupCompanyName}
                            className={`${styles.formControl} ${errors?.pickupCompanyName ? 'is-invalid' : ''}`}
                            {...register('pickupCompanyName', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupCompanyName" }}
                        /> */}
                        <div className="invalid-feedback">{errors.pickupCompanyName?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Point Of Contact"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.pickupPointOfContact}
                            className={`${styles.formControl} ${errors?.pickupPointOfContact ? 'is-invalid' : ''}`}
                            {...register('pickupPointOfContact', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupPointOfContact" }}
                        />
                        <div className="invalid-feedback">{errors.pickupPointOfContact?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            type='email'
                            label="Email Id"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.pickupEmail}
                            className={`${styles.formControl} ${errors?.pickupEmail ? 'is-invalid' : ''}`}
                            {...register('pickupEmail', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupEmail" }}
                        />
                        <div className="invalid-feedback">{errors.pickupEmail?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <PhoneInput
                            country={'us'}
                            value={state.pickupContactNumber}
                            onChange={onContactNumberChange}
                            inputProps={{
                                name: 'pickupContactNumber',
                                autoFocus: false,
                            }}
                            containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                            inputStyle={{ borderColor: errors?.pickupContactNumber ? '#d32f2f' : '#ccc', }}
                        />
                        {/* <TextField
                            label="Contact Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.pickupContactNumber}
                            className={`${styles.formControl} ${errors?.pickupContactNumber ? 'is-invalid' : ''}`}
                            {...register('pickupContactNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupContactNumber" }}
                        /> */}
                        <div className="invalid-feedback">{errors.pickupContactNumber?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: "0" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Pickup Date"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="date"
                                value={state.pickupDate}
                                className={`${styles.formControl} ${errors?.pickupDate ? 'is-invalid' : ''}`}
                                {...register('pickupDate', { onChange: handleDateChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    inputProps: {
                                        min: new Date().toISOString().split('T')[0], // Set the minimum selectable date
                                    },
                                }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            borderTopRightRadius: '0',
                                            borderBottomRightRadius: '0',
                                            borderRight: 'none'
                                        },
                                    },
                                }}
                            />
                            <div className="invalid-feedback">{errors.pickupDate?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Pickup Time"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="time"
                                value={state.pickupTime}
                                className={`${styles.formControl} ${errors?.pickupTime ? 'is-invalid' : ''}`}
                                {...register('pickupTime', { onChange: handleChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            borderTopLeftRadius: '0',
                                            borderBottomLeftRadius: '0',
                                        },
                                    },
                                }}
                            // InputProps={{ inputProps: { min: "09:00" } }}
                            />
                            <div className="invalid-feedback">{errors.pickupTime?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                </Grid>
                <Grid size={{ md: 6, sm: 12, xs: 12 }} sx={{ borderBottom: '1px solid #e0e0e0' }} className={styles.formBox}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle}>
                        Drop off Location
                    </Typography>
                    <FormControl sx={{ marginBottom: '10px' }} className={styles.locationBox} fullWidth>
                        <LocationInput
                            setLocationData={setLocationData}
                            id="dropoffLocation"
                            name="dropoffLocation"
                            value={state.dropoffLocation}
                            className={`${styles.formControl} locfield ${errors?.dropoffLocation ? 'is-invalid' : ''}`}
                        />
                        <div className="invalid-feedback">{errors.dropoffLocation?.message?.toString()}</div>
                    </FormControl>
                    <Divider sx={{ color: '#999999' }}>OR</Divider>
                    <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: "10px", sm: '20px', md: '30px' } }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Latitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="number"
                                inputMode="decimal"
                                value={state.dropoffLatitude}
                                className={`${styles.formControl} ${errors?.dropoffLatitude ? 'is-invalid' : ''}`}
                                {...register('dropoffLatitude', {
                                    onChange: handleChange,
                                    validate: value => !isNaN(parseFloat(value)) || 'Enter a valid decimal number'
                                })}
                                inputProps={{
                                    autoComplete: "dropoffLatitude",
                                    step: "any",
                                    onKeyDown: (e) => {
                                        if (["e", "E", "+", "-"].includes(e.key)) {
                                            e.preventDefault();
                                        }
                                    }
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffLatitude?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Longitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="number"
                                inputMode="decimal"
                                value={state.dropoffLongitude}
                                className={`${styles.formControl} ${errors?.dropoffLongitude ? 'is-invalid' : ''}`}
                                {...register('dropoffLongitude', {
                                    onChange: handleChange,
                                    validate: value => !isNaN(parseFloat(value)) || 'Enter a valid decimal number'
                                })}
                                inputProps={{
                                    autoComplete: "dropoffLongitude",
                                    step: "any",
                                    onKeyDown: (e) => {
                                        if (["e", "E", "+", "-"].includes(e.key)) {
                                            e.preventDefault();
                                        }
                                    }
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffLongitude?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                    <FormControl fullWidth>
                        <Stack sx={{ marginTop: '16px', marginBottom: '8px' }}>
                            <Autocomplete
                                freeSolo
                                id="dropoffCompanyName"
                                disableClearable
                                options={existingCompanies.map((option) => option.title)}
                                value={state.dropoffCompanyName}
                                onChange={(event, newValue) => {
                                    handleCompanyAutoCompleteChange('dropoffCompanyName', newValue, true);
                                }}
                                onInputChange={(event, newValue) => {
                                    handleCompanyAutoCompleteChange('dropoffCompanyName', newValue);
                                }}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Company Name"
                                        className={`${styles.formControl} ${errors?.dropoffCompanyName ? 'is-invalid' : ''}`}
                                        slotProps={{
                                            input: {
                                                ...params.InputProps,
                                                type: 'search',
                                            },
                                        }}
                                    />
                                )}
                            />
                        </Stack>

                        {/* <TextField
                            label="Company Name"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.dropoffCompanyName}
                            className={`${styles.formControl} ${errors?.dropoffCompanyName ? 'is-invalid' : ''}`}
                            {...register('dropoffCompanyName', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffCompanyName" }}
                        /> */}
                        <div className="invalid-feedback">{errors.dropoffCompanyName?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Point Of Contact"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.dropoffPointOfContact}
                            className={`${styles.formControl} ${errors?.dropoffPointOfContact ? 'is-invalid' : ''}`}
                            {...register('dropoffPointOfContact', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffPointOfContact" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffPointOfContact?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            type='email'
                            label="Email Id"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.dropoffEmail}
                            className={`${styles.formControl} ${errors?.dropoffEmail ? 'is-invalid' : ''}`}
                            {...register('dropoffEmail', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffEmail" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffEmail?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <PhoneInput
                            country={'us'}
                            value={state.dropoffContactNumber}
                            onChange={onContactNumberChange}
                            inputProps={{
                                name: 'dropoffContactNumber',
                                autoFocus: false,
                            }}
                            containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                            inputStyle={{ borderColor: errors?.dropoffContactNumber ? '#d32f2f' : '#ccc', }}
                        />

                        {/* <TextField
                            label="Contact Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.dropoffContactNumber}
                            className={`${styles.formControl} ${errors?.dropoffContactNumber ? 'is-invalid' : ''}`}
                            {...register('dropoffContactNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffContactNumber" }}
                        /> */}
                        <div className="invalid-feedback">{errors.dropoffContactNumber?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'row', lg: 'row' }, justifyContent: "space-between", gap: "0" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Drop off Date"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="date"
                                value={state.dropoffDate}
                                className={`${styles.formControl} ${errors?.dropoffDate ? 'is-invalid' : ''}`}
                                {...register('dropoffDate', { onChange: handleDateChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    inputProps: {
                                        min: state.pickupDate ? new Date(state.pickupDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0], // Set the minimum selectable date
                                    },
                                }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            borderTopRightRadius: { xs: '8px', sm: '8px', md: '0' },
                                            borderBottomRightRadius: { xs: '8px', sm: '8px', md: '0' },
                                            borderRight: { xs: '1px', sm: '1px', md: '0' },
                                        },
                                    },
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffDate?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Drop off Time"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="time"
                                value={state.dropoffTime}
                                className={`${styles.formControl} ${errors?.dropoffTime ? 'is-invalid' : ''}`}
                                {...register('dropoffTime', { onChange: handleChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            borderTopLeftRadius: '0',
                                            borderBottomLeftRadius: '0',
                                        },
                                    },
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffTime?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                </Grid>
                <FormControl sx={{ paddingLeft: { xs: '10px', sm: '10px', md: '20px' }, paddingRight: { xs: '10px', sm: '10px', md: '20px' }, paddingTop: '10px', paddingBottom: '0px' }} fullWidth>
                    <TextField
                        type='textarea'
                        label="Additional Note"
                        variant="outlined"
                        multiline
                        rows={3}
                        fullWidth
                        margin="normal"
                        value={state.additionalNote}
                        className={`${styles.formControl} ${errors?.additionalNote ? 'is-invalid' : ''}`}
                        {...register('additionalNote', { onChange: handleChange })}
                        inputProps={{ autoComplete: "additionalNote" }}
                        InputLabelProps={{ shrink: state.additionalNote?.length > 0 }}
                    />
                    <div className="invalid-feedback">{errors.additionalNote?.message?.toString()}</div>
                </FormControl>
            </Grid>
        </Box >
    );
};

export default Location;
