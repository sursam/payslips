import React from 'react';
import { Typography, Box, Grid, Accordion, AccordionSummary, AccordionDetails, MenuItem, ListItemIcon, ListItemText, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Divider } from '@mui/material';
import styles from '../../../styles/job.module.css';
import Loader from '../../Loader/loader';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import MultipleStopIcon from '@mui/icons-material/MultipleStop';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import EditNoteIcon from '@mui/icons-material/EditNote';
import { Link } from 'react-router-dom';
import EditNoteOutlined from '@mui/icons-material/EditNoteOutlined';
import moment from 'moment';

interface ChildProps {
    state: any;
    isLoading: any;
    truckTypes: any;
    loadTypeName: string;
    isHourly: boolean;
    anyEquipment: string;
    equipmentTypeName: string;
    setActiveStep: any;
}
const JobSummary: React.FC<ChildProps> = ({ state, isLoading, truckTypes, loadTypeName, isHourly, anyEquipment, equipmentTypeName, setActiveStep }) => {

    return (
        <Box className={`${styles.jobSummary} ${styles.formContainer}`}>

            {isLoading ?
                <Box className="loaderContainer">
                    <Loader />
                </Box>
                : ''
            }
            <Grid container spacing={0}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.formBox}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle} sx={{ paddingBottom: '15px' }}>
                        Job Summary
                    </Typography>
                    <Accordion
                        defaultExpanded
                        disableGutters
                        elevation={0}
                        sx={{
                            '&:before': {
                                display: 'none',
                            },
                            boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
                            marginBottom: '30px'
                        }}
                    >
                        <AccordionSummary
                            aria-controls="panel2-content"
                            id="location-header"
                            expandIcon={<ArrowDropDownIcon sx={{ color: "#005DAA", fontSize: "30px" }} />}
                            sx={{
                                backgroundColor: "#E0F1FF",
                                color: "#005DAA",
                                borderTopLeftRadius: '10px',
                                borderTopRightRadius: '10px',
                            }}
                            className={styles.accordionHeader}
                        >
                            <Typography className={styles.accordionTitle}>
                                Locations <Link to="#" onClick={() => setActiveStep(0)}><EditNoteOutlined sx={{ fontSize: "25px", verticalAlign: "middle" }} /></Link>
                            </Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Grid container spacing={0}>
                                <Grid size={{ md: 5, sm: 5, xs: 12 }} sx={{ padding: "10px" }}>
                                    <Typography className={`${styles.locationTitle} ${styles.pickupTitle}`}>
                                        Pickup <span>(Lat: {state.pickupLatitude} | Long: {state.pickupLongitude})</span>
                                    </Typography>
                                    <Typography className={styles.locationDate}>
                                        {moment(`${state.pickupDate} ${state.pickupTime}`).format("DD MMM YYYY | hh:mm A")}
                                    </Typography>
                                    <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                        <BusinessCenterIcon className={styles.locationIcon} /> {state.pickupLocation}
                                    </Typography>
                                    <Typography className={styles.locationPerson}>
                                        <PersonIcon className={styles.personIcon} /> {state.pickupPointOfContact}
                                    </Typography>
                                    <Typography className={styles.personContact}>
                                        <EmailIcon className={styles.contactIcon} /> {state.pickupEmail} | <PhoneIphoneIcon className={styles.contactIcon} /> {state.pickupContactNumber}
                                    </Typography>
                                </Grid>
                                <Grid size={{ md: 2, sm: 2, xs: 12 }} sx={{ padding: "10px", display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <MultipleStopIcon sx={{ color: "#AAAAAA" }} />
                                </Grid>
                                <Grid size={{ md: 5, sm: 5, xs: 12 }} sx={{ padding: "10px" }}>
                                    <Typography className={`${styles.locationTitle} ${styles.dropoffTitle}`}>
                                        Drop Off <span>(Lat: {state.dropoffLatitude} | Long: {state.dropoffLongitude})</span>
                                    </Typography>
                                    <Typography className={styles.locationDate}>
                                        {moment(`${state.dropoffDate} ${state.dropoffTime}`).format("DD MMM YYYY | hh:mm A")}
                                    </Typography>
                                    <Typography className={`${styles.locationTitle} ${styles.addressTitle}`}>
                                        <BusinessCenterIcon className={styles.locationIcon} /> {state.dropoffLocation}
                                    </Typography>
                                    <Typography className={styles.locationPerson}>
                                        <PersonIcon className={styles.personIcon} /> {state.dropoffPointOfContact}
                                    </Typography>
                                    <Typography className={styles.personContact}>
                                        <EmailIcon className={styles.contactIcon} /> {state.dropoffEmail} | <PhoneIphoneIcon className={styles.contactIcon} /> {state.dropoffContactNumber}
                                    </Typography>
                                </Grid>

                                <Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ borderTop: "1px solid #E7E7E7", marginTop: "10px", paddingTop: "15px" }}>
                                    <Typography className={styles.italicTitle}>Additional Note</Typography>
                                    <Typography className={styles.jobContent}>{state.additionalNote}</Typography>
                                </Grid>
                            </Grid>
                        </AccordionDetails>
                    </Accordion>
                    <Accordion
                        defaultExpanded
                        disableGutters
                        elevation={0}
                        sx={{
                            '&:before': {
                                display: 'none',
                            },
                            boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)'
                        }}
                    >
                        <AccordionSummary
                            aria-controls="panel2-content"
                            id="job-header"
                            expandIcon={<ArrowDropDownIcon sx={{ color: "#005DAA", fontSize: "30px" }} />}
                            sx={{
                                backgroundColor: "#E0F1FF",
                                color: "#005DAA",
                                borderTopLeftRadius: '10px',
                                borderTopRightRadius: '10px',
                            }}
                            className={styles.accordionHeader}
                        >
                            <Typography className={styles.accordionTitle}>
                                Job Description <Link to="#" onClick={() => setActiveStep(1)}><EditNoteOutlined sx={{ fontSize: "25px", verticalAlign: "middle" }} /></Link>
                            </Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Grid container spacing={0}>
                                <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px 30px 10px 10px", borderRight: '1px solid #E7E7E7' }}>
                                    <Grid container spacing={2} >
                                        <Grid size={{ md: 6, sm: 6, xs: 12 }}>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Material type</Typography>
                                                <Typography className={styles.jobText}>{state.materialType.name.toLowerCase() !== 'other' ? state.materialType.name : state.materialOther
                                                }</Typography>
                                            </Box>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Total Millage</Typography>
                                                <Typography className={styles.jobText}>{state.totalMillage} Miles</Typography>
                                            </Box>
                                        </Grid>
                                        <Grid size={{ md: 6, sm: 6, xs: 12 }}>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Order Number</Typography>
                                                <Typography className={styles.jobText}>{state.orderNumber}</Typography>
                                            </Box>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Number Of Units</Typography>
                                                <Typography className={styles.jobText}>{state.numberOfUnits} ({loadTypeName})</Typography>
                                            </Box>
                                        </Grid>
                                        <Grid size={{ md: 12, sm: 12, xs: 12 }}>
                                            {isHourly ?
                                                <Grid container spacing={0} className={styles.jobHorBox} sx={{ marginBottom: "15px" }}>
                                                    <Grid size={{ md: 4, sm: 4, xs: 4 }}>
                                                        <Typography className={styles.jobHourTitle}><CheckCircleIcon className={styles.jobHourIcon} /> Hourly Job</Typography>
                                                    </Grid>
                                                    <Grid size={{ md: 4, sm: 4, xs: 4 }}>
                                                        <Typography className={styles.jobItalicTitle}>Minimum Hour(s) <span className={styles.jobHourText}>{state.minimumHours}</span></Typography>
                                                    </Grid>
                                                    <Grid size={{ md: 4, sm: 4, xs: 4 }}>
                                                        <Typography className={styles.jobItalicTitle}>Maximum Hour(s) <span className={styles.jobHourText}>{state.maximumHours}</span></Typography>
                                                    </Grid>
                                                </Grid>
                                                : ''}
                                            {(anyEquipment == 'yes') ?
                                                <Grid container spacing={0} className={styles.jobHorBox}>
                                                    <Grid size={{ md: 4, sm: 4, xs: 4 }}>
                                                        <Typography className={styles.jobHourTitle}><CheckCircleIcon className={styles.jobHourIcon} /> Equipment</Typography>
                                                    </Grid>
                                                    <Grid size={{ md: 8, sm: 8, xs: 8 }}>
                                                        <Typography className={styles.jobItalicTitle}>Type <span className={styles.jobHourText}>{equipmentTypeName}</span></Typography>
                                                    </Grid>
                                                </Grid>
                                                : ''}
                                        </Grid>
                                        <Grid size={{ md: 6, sm: 6, xs: 12 }}>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Load Spacing in Minutes</Typography>
                                                <Typography className={styles.jobText}>{state.loadSpacingMinutes}</Typography>
                                            </Box>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Price Per Unit</Typography>
                                                <Typography className={styles.jobText}>${state.pricePerUnit}</Typography>
                                            </Box>
                                        </Grid>
                                        <Grid size={{ md: 6, sm: 6, xs: 12 }}>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Number Of Loads</Typography>
                                                <Typography className={styles.jobText}>{state.loads.length} </Typography>
                                            </Box>
                                            <Box className={styles.jobBox}>
                                                <Typography className={styles.jobItalicTitle}>Total Job Cost</Typography>
                                                <Typography className={styles.jobText}>${state.totalJobCost}</Typography>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid size={{ md: 6, sm: 6, xs: 12 }} sx={{ padding: "10px 10px 10px 30px" }}>
                                    <Typography className={styles.jobItalicTitle}>Truck Type</Typography>
                                    <div>
                                        {truckTypes.length && truckTypes.map((truckType: any) => (
                                            <MenuItem key={truckType.truck_type_id} value={truckType.truck_type_id} className={styles.truck_type_menu_item}>
                                                <ListItemText primary={truckType.name} secondary={`${truckType.specs} Axels | ${truckType.weight_capacity} Tons`} className={styles.truck_type_option} />
                                                <ListItemIcon>
                                                    <img src={truckType.trucktype_image} alt={truckType.name} className={styles.trucktype_image} />
                                                </ListItemIcon>
                                            </MenuItem>
                                        ))}
                                    </div>
                                </Grid>
                                <Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ padding: "20px 10px", marginTop: "10px", borderTop: '1px solid #E7E7E7' }}>
                                    <Typography className={styles.loadTitle}>Load Details</Typography>
                                    {Array.isArray(state.loads) && state.loads.length > 0 ? (
                                        <TableContainer>
                                            <Table className={styles.loadTable}>
                                                <TableHead sx={{ backgroundColor: "#FFF9EC" }}>
                                                    <TableRow>
                                                        <TableCell>Load Idx</TableCell>
                                                        <TableCell>Weight</TableCell>
                                                        <TableCell>Load Spacing in Minutes</TableCell>
                                                        <TableCell>Price Per Load</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {state.loads.map((load: any, key: number) => (
                                                        <TableRow key={key}>
                                                            <TableCell>{`Load ${key + 1}`}</TableCell>
                                                            <TableCell>{load?.weight} Tons</TableCell>
                                                            <TableCell>{load?.load_spacing}</TableCell>
                                                            <TableCell>${load?.load_cost}</TableCell>
                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    ) : (
                                        <div className={styles.noDataContainer}>
                                            <Typography variant="body2" color="textSecondary" align="center">
                                                No loads found
                                            </Typography>
                                        </div>
                                    )}
                                </Grid>
                            </Grid>
                        </AccordionDetails>
                    </Accordion>
                </Grid>
            </Grid>

        </Box >

    );
};

export default JobSummary;
