import React, { useState, useEffect } from 'react';
import { TextField, Typography, Box, Grid, FormControlLabel, Radio, Select, MenuItem, FormControl, InputLabel, Stack, ListItemIcon, Checkbox, ListItemText, Autocomplete, Tooltip } from '@mui/material';
import Switch, { SwitchProps } from '@mui/material/Switch';
import { styled } from '@mui/material/styles';
import styles from '../../../styles/job.module.css';
import { api } from '../../../utils/api';
import Loader from '../../Loader/loader';

interface ChildProps {
    errors: any;
    register: any;
    materialTypeList: any;
    materialTypeOtherId: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleAutoCompleteChange: (name, value) => void;
    state: any;
    switchChecked: boolean;
    setSwitchChecked: any;
    anyEquipment: string;
    setAnyEquipment: any;
    truckTypeList: any;
    loadTypeList: any;
    equipmentTypeList: any;
}
const SwitchButton = styled((props: SwitchProps) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(16px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#65C466',
                opacity: 1,
                border: 0,
                ...theme.applyStyles('dark', {
                    backgroundColor: '#2ECA45',
                }),
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#33cf4d',
            border: '6px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color: theme.palette.grey[100],
            ...theme.applyStyles('dark', {
                color: theme.palette.grey[600],
            }),
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: 0.7,
            ...theme.applyStyles('dark', {
                opacity: 0.3,
            }),
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 22,
        height: 22,
    },
    '& .MuiSwitch-track': {
        borderRadius: 26 / 2,
        backgroundColor: '#E9E9EA',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
        ...theme.applyStyles('dark', {
            backgroundColor: '#39393D',
        }),
    },
}));
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250
        }
    },
    getContentAnchorEl: null,
    anchorOrigin: {
        vertical: "bottom",
        horizontal: "center"
    },
    transformOrigin: {
        vertical: "top",
        horizontal: "center"
    },
    variant: "menu"
};

const JobDescription: React.FC<ChildProps> = ({ errors, register, materialTypeList, materialTypeOtherId, handleChange, handleAutoCompleteChange, state, switchChecked, setSwitchChecked, anyEquipment, setAnyEquipment, truckTypeList, loadTypeList, equipmentTypeList }) => {
    console.log('materialType ----- ', state.loadTypeId);
    const [isFormLoading, setIsFormLoading] = useState<boolean>(true);
    const [unitTypeErrorMessage, setUnitTypeErrorMessage] = useState('');
    const truckTypeIdsArr = state.truckTypeIdsArr.map(Number);
    const filterTruckTypeValues = () => {
        let filteredValues = truckTypeList.filter((item: any) => truckTypeIdsArr.includes(item.truck_type_id)).map((item: any) => item.name).join(", ");
        return filteredValues;
    }
    // Handle click/focus on Number of Units field
    const handleUnitPriceClick = () => {
        if (!state.loadTypeId) {
            setUnitTypeErrorMessage('Please select a Unit type first');
        } else {
            setUnitTypeErrorMessage('');
        }
    };
    useEffect(() => {
        setIsFormLoading(false);
    }, []);

    return (
        <Box className={styles.formContainer}>

            {isFormLoading ?
                <Box className="loaderContainer">
                    <Loader />
                </Box>
                : ''
            }
            <Grid container spacing={0}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} sx={{ paddingLeft: "20px", paddingTop: "30px" }}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle}>
                        Description
                    </Typography>
                </Grid>
                <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox} sx={{ paddingTop: "15px !important" }}>
                    <FormControl fullWidth>
                        <Typography variant="h6" gutterBottom className={styles.formTitle}>
                            Job Type
                            <FormControlLabel
                                control={
                                    <Radio
                                        checked={true}
                                        color="primary"
                                        value={'short-haul'}
                                        {...register('jobType', { onChange: handleChange })}
                                    />
                                }
                                label="Short-Haul"
                                sx={{ marginLeft: "5px" }}
                            />
                        </Typography>
                        <div className="invalid-feedback">{errors.jobType?.message?.toString()}</div>
                    </FormControl>

                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <Autocomplete
                            disablePortal
                            id="material-type"
                            className='autoSelect'
                            options={materialTypeList}
                            getOptionLabel={(option: any) => option.name}
                            getOptionKey={(option: any) => option.material_id}
                            sx={{ width: '100%' }}
                            onChange={(event, newValue) => {
                                handleAutoCompleteChange('materialTypeId', newValue);
                            }}
                            value={state.materialType}
                            renderInput={(params) => <TextField {...params} label="Material Type" />}
                        />
                        <div className="invalid-feedback">{errors.materialTypeId?.message?.toString()}</div>
                    </FormControl>
                    {state.materialTypeId && state.materialTypeId == materialTypeOtherId ?
                        <FormControl fullWidth>
                            <TextField
                                label="Other Material Type"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={state.materialOther}
                                className={`${styles.formControl} ${errors?.materialOther ? 'is-invalid' : ''}`}
                                {...register('materialOther', { onChange: handleChange })}
                                inputProps={{ autoComplete: "materialOther" }}
                            />
                            <div className="invalid-feedback">{errors.materialOther?.message?.toString()}</div>
                        </FormControl>
                        : ''}
                    <FormControl fullWidth>
                        <TextField
                            label="Order Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.orderNumber}
                            className={`${styles.formControl} ${errors?.orderNumber ? 'is-invalid' : ''}`}
                            {...register('orderNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "orderNumber" }}
                        />
                        <div className="invalid-feedback">{errors.orderNumber?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Total Millage (Miles)"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.totalMillage}
                            className={`${styles.formControl} ${errors?.totalMillage ? 'is-invalid' : ''}`}
                            {...register('totalMillage', { onChange: handleChange })}
                            inputProps={{ autoComplete: "totalMillage", readOnly: true }}
                        />
                        <div className="invalid-feedback">{errors.totalMillage?.message?.toString()}</div>
                    </FormControl>


                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
                            <Typography variant="h6" gutterBottom className={styles.formTitle}>Hourly Job</Typography>
                            <SwitchButton inputProps={{ 'aria-label': 'Hourly Job' }} checked={switchChecked} onChange={(event) => setSwitchChecked(event.target.checked)} />
                        </Stack>
                    </FormControl>
                    {switchChecked ?
                        <Grid container spacing={0}>
                            <Grid
                                size={{ md: 6, sm: 12, xs: 12 }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            // borderTopRightRadius: '0',
                                            // borderBottomRightRadius: '0',
                                            // borderRight: 'none'
                                            borderTopRightRadius: { xs: '4px', sm: '4px', md: '0' }, // Default MUI radius is 4px; flat on md+
                                            borderBottomRightRadius: { xs: '4px', sm: '4px', md: '0' },
                                            borderRight: { xs: '1px solid', md: 'none' }, // Restore default border on xs; remove on md+
                                            borderRightColor: { xs: 'rgba(0, 0, 0, 0.23)', md: 'transparent' }, // Match MUI default border color
                                        },
                                    },
                                }}
                            >
                                <FormControl fullWidth>
                                    <TextField
                                        label="Minimum Hour(s)"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        value={state.minimumHours}
                                        className={`${styles.formControl} ${errors?.minimumHours ? 'is-invalid' : ''}`}
                                        {...register('minimumHours', { onChange: handleChange })}
                                        inputProps={{ autoComplete: "minimumHours" }}
                                    />
                                    <div className="invalid-feedback">{errors.minimumHours?.message?.toString()}</div>
                                </FormControl>
                            </Grid>
                            <Grid
                                size={{ md: 6, sm: 12, xs: 12 }}
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                            // borderTopLeftRadius: '0',
                                            // borderBottomLeftRadius: '0',

                                            borderTopLeftRadius: { xs: '4px', sm: '4px', md: '0' }, // Default MUI radius is 4px; flat on md+
                                            borderBottomLeftRadius: { xs: '4px', sm: '4px', md: '0' },
                                            // borderLeft: { xs: '1px solid', md: '1px solid' }, // Restore default border on xs; remove on md+
                                            borderLeftColor: { xs: 'rgba(0, 0, 0, 0.23)', }, // Match MUI default border color
                                        },
                                    },
                                }}
                            >
                                <FormControl fullWidth>
                                    <TextField
                                        label="Maximum Hour(s)"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        value={state.maximumHours}
                                        className={`${styles.formControl} ${errors?.maximumHours ? 'is-invalid' : ''}`}
                                        {...register('maximumHours', { onChange: handleChange })}
                                        inputProps={{ autoComplete: "maximumHours" }}
                                    />
                                    <div className="invalid-feedback">{errors.maximumHours?.message?.toString()}</div>
                                </FormControl>
                            </Grid>
                        </Grid>
                        : ''}
                </Grid>
                <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox} sx={{ paddingTop: "15px !important" }}>
                    <FormControl fullWidth>
                        <Typography variant="h6" gutterBottom className={styles.formTitle}>
                            Any Equipment
                            <FormControlLabel
                                control={
                                    <Radio
                                        color="primary"
                                        value={'yes'}
                                        checked={anyEquipment == 'yes'}
                                        onChange={() => setAnyEquipment('yes')}
                                    />
                                }
                                label="Yes"
                                sx={{ marginLeft: "5px" }}
                            />
                            <FormControlLabel
                                control={
                                    <Radio
                                        color="primary"
                                        value={'no'}
                                        checked={anyEquipment == 'no'}
                                        onChange={() => setAnyEquipment('no')}
                                    />
                                }
                                label="No"
                            />
                        </Typography>
                        <div className="invalid-feedback">{errors.anyEquipment?.message?.toString()}</div>
                    </FormControl>
                    {anyEquipment == 'yes' ?
                        <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                            <Autocomplete
                                disablePortal
                                id="equipment-type"
                                className='autoSelect'
                                options={equipmentTypeList}
                                getOptionLabel={(option: any) => option.name}
                                getOptionKey={(option: any) => option.equipment_id}
                                sx={{ width: '100%' }}
                                onChange={(event, newValue) => {
                                    handleAutoCompleteChange('equipmentTypeId', newValue);
                                }}
                                value={state.equipmentType}
                                renderInput={(params) => <TextField {...params} label="Equipment Type" />}
                            />
                            <div className="invalid-feedback">{errors.equipmentTypeId?.message?.toString()}</div>
                        </FormControl>
                        : ''}
                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <InputLabel id="truck-type-label">Truck Type</InputLabel>
                        <Select
                            labelId="truck-type-label"
                            id="truck-type"
                            label="Truck Type"
                            multiple
                            value={truckTypeIdsArr}
                            {...register('truckTypeIdsArr', { onChange: handleChange })}
                            renderValue={filterTruckTypeValues}
                            MenuProps={MenuProps}
                            className={`${styles.formControl} ${errors?.truckTypeIdsArr ? 'is-invalid' : ''}`}
                        >
                            {truckTypeList.length && truckTypeList.map((truckType: any) => (
                                <MenuItem key={truckType.truck_type_id} value={truckType.truck_type_id} className={styles.truck_type_menu_item}>
                                    <ListItemIcon className={`${styles.truck_type_check} ${truckTypeIdsArr.indexOf(truckType.truck_type_id) > -1 ? styles.checked : ''}`}>
                                        <Checkbox checked={truckTypeIdsArr.indexOf(truckType.truck_type_id) > -1} />
                                    </ListItemIcon>
                                    <ListItemText
                                        primary={
                                            <span style={{
                                                display: '-webkit-box',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                height: '30px',
                                                WebkitLineClamp: 1,
                                                WebkitBoxOrient: 'vertical',
                                                fontWeight: 600
                                            }}>
                                                {truckType.name}
                                            </span>
                                        }
                                        secondary={`${truckType.specs} Axels | ${truckType.weight_capacity} Tons`}
                                    />
                                    <ListItemIcon>
                                        <img src={truckType.trucktype_image} alt={truckType.name} className={styles.trucktype_image} />
                                    </ListItemIcon>
                                </MenuItem>
                            ))}
                        </Select>
                        <div className="invalid-feedback">{errors.truckTypeIdsArr?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Load Spacing in Minutes"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.loadSpacingMinutes}
                            className={`${styles.formControl} ${errors?.loadSpacingMinutes ? 'is-invalid' : ''}`}
                            {...register('loadSpacingMinutes', {
                                onChange: (e) => {
                                    const value = e.target.value;

                                    // Allow only numbers with up to 2 decimal places and max 8 digits total
                                    const regex = /^\d{0,6}(\.\d{0,2})?$/;

                                    if (regex.test(value)) {
                                        handleChange(e); // your existing handler
                                    }
                                }
                            })}
                            inputProps={{
                                autoComplete: "loadSpacingMinutes",
                                inputMode: 'decimal',
                            }}
                        />
                        <div className="invalid-feedback">{errors.loadSpacingMinutes?.message?.toString()}</div>
                    </FormControl>
                    <Grid container spacing={0}>
                        <Grid
                            size={{ md: 4, sm: 4, xs: 12 }}
                            sx={{
                                '& .MuiOutlinedInput-root': {
                                    '& fieldset': {
                                        borderTopRightRadius: { xs: '4px', md: '0' }, // Default MUI radius is 4px; flat on md+
                                        borderBottomRightRadius: { xs: '4px', md: '0' },
                                        borderRight: { xs: '1px solid', md: 'none' }, // Restore default border on xs; remove on md+
                                        borderRightColor: { xs: 'rgba(0, 0, 0, 0.23)', md: 'transparent' }, // Match MUI default border color
                                    },
                                },
                            }}

                        >
                            <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                                <InputLabel id="unit-label">Unit</InputLabel>
                                <Select
                                    labelId="unit-label"
                                    id="unit"
                                    label="Unit"
                                    value={state.loadTypeId}
                                    {...register('loadTypeId', { onChange: handleChange })}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    {loadTypeList && loadTypeList.map((loadType: any) => (
                                        <MenuItem value={loadType.load_id} key={loadType.load_id}>{loadType.name}</MenuItem>
                                    ))}
                                </Select>
                                <div className="invalid-feedback">{errors.loadTypeId?.message?.toString()}</div>
                            </FormControl>
                        </Grid>
                        <Grid
                            size={{ md: 4, sm: 4, xs: 12 }}
                            sx={{
                                '& .MuiOutlinedInput-root': {
                                    '& fieldset': {
                                        borderTopLeftRadius: { xs: '4px', md: '0' },
                                        borderTopRightRadius: { xs: '4px', md: '0' },
                                        borderBottomLeftRadius: { xs: '4px', md: '0' },
                                        borderBottomRightRadius: { xs: '4px', md: '0' },
                                    },
                                },
                            }}
                        >
                            <FormControl fullWidth>
                                <TextField
                                    label="Number of Units"
                                    variant="outlined"
                                    fullWidth
                                    margin="normal"
                                    value={state.loadTypeId ? state.numberOfUnits : ''}
                                    className={`${styles.formControl} ${errors?.numberOfUnits ? 'is-invalid' : ''}`}
                                    {...register('numberOfUnits', {
                                        onChange: (e) => {
                                            const value = e.target.value;
                                            const isLoads = state.loadTypeId == 2;

                                            // Regex: only digits for 'loads', else allow up to 2 decimals
                                            const regex = isLoads
                                                ? /^\d{0,8}$/ // whole numbers only
                                                : /^\d{0,6}(\.\d{0,2})?$/; // up to 2 decimals, max 8 digits

                                            if (regex.test(value)) {
                                                handleChange(e);
                                            }
                                        },
                                    })}
                                    inputProps={{
                                        autoComplete: 'numberOfUnits',
                                        readOnly: !state.loadTypeId,
                                        inputMode: state.loadTypeId === 'loads' ? 'numeric' : 'decimal',
                                    }}
                                    onClick={handleUnitPriceClick}
                                    onFocus={handleUnitPriceClick}
                                />

                                <div className="invalid-feedback">
                                    {unitTypeErrorMessage || errors.numberOfUnits?.message?.toString()}
                                </div>
                            </FormControl>
                        </Grid>
                        <Grid
                            size={{ md: 4, sm: 4, xs: 12 }}
                            sx={{
                                '& .MuiOutlinedInput-root': {
                                    '& fieldset': {
                                        // borderTopLeftRadius: '0',
                                        // borderBottomLeftRadius: '0',
                                        // borderLeft: 'none',

                                        borderTopLeftRadius: { xs: '4px', md: '0' }, // Restore full radius on xs
                                        borderBottomLeftRadius: { xs: '4px', md: '0' },
                                        borderLeft: { xs: '1px solid', md: 'none' }, // Restore default border on xs; remove on md+
                                        borderLeftColor: { xs: 'rgba(0, 0, 0, 0.23)', md: 'transparent' },
                                    },
                                },
                            }}
                        >
                            <FormControl fullWidth>
                                <TextField
                                    label="Price Per Unit"
                                    variant="outlined"
                                    fullWidth
                                    margin="normal"
                                    value={state.loadTypeId ? state.pricePerUnit : ''}
                                    className={`${styles.formControl} ${errors?.pricePerUnit ? 'is-invalid' : ''}`}
                                    {...register('pricePerUnit', {
                                        onChange: (e) => {
                                            const value = e.target.value;

                                            // Allow only numbers with up to 2 decimal places and max 8 digits total
                                            const regex = /^\d{0,6}(\.\d{0,2})?$/;

                                            if (regex.test(value)) {
                                                handleChange(e); // your existing handler
                                            }
                                        }
                                    })}
                                    inputProps={{ autoComplete: "pricePerUnit", readOnly: state.loadTypeId ? false : true, inputMode: 'decimal', }}
                                    onClick={handleUnitPriceClick}
                                    onFocus={handleUnitPriceClick}
                                />
                                <div className="invalid-feedback">
                                    {unitTypeErrorMessage || errors.pricePerUnit?.message?.toString()}
                                </div>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <FormControl fullWidth>
                        <TextField
                            label="Total Job Cost"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={state.totalJobCost}
                            className={`${styles.formControl} ${errors?.totalJobCost ? 'is-invalid' : ''}`}
                            {...register('totalJobCost', {
                                onChange: (e) => {
                                    const value = e.target.value;

                                    // Allow only numbers with up to 2 decimal places and max 8 digits total
                                    const regex = /^\d{0,6}(\.\d{0,2})?$/;

                                    if (regex.test(value)) {
                                        handleChange(e); // your existing handler
                                    }
                                }
                            })}
                            inputProps={{ autoComplete: "totalJobCost", readOnly: true }}
                        />
                        <div className="invalid-feedback">{errors.totalJobCost?.message?.toString()}</div>
                    </FormControl>

                </Grid>
            </Grid>


        </Box >

    );
};

export default JobDescription;
