import React, { use, useCallback, useEffect, useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import moment from 'moment';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import EditIcon from '@mui/icons-material/Edit';
import DoDisturbIcon from '@mui/icons-material/DoDisturb';
import {
    Box,
    CardContent,
    Menu,
    MenuItem,
    Pagination,
    PaginationItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid,
    Tabs,
    Tab,
    Typography,
    Skeleton
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { JobListProps } from '../../types';
import { toast } from 'react-toastify';
import { can } from "../../utils/helper";
import PostJobLink from '../Dashboard/parts/postJobLink';


const ITEM_HEIGHT = 48;


function jobTabProps(index: number) {
    return {
        id: `job-tab-${index}`,
        'aria-controls': `job-tabpanel-${index}`,
        className: styles.jobTabLink,
    };
}

const JobTableSkeleton: React.FC = () => {
    return (
        <TableContainer>
            <Table>
                <TableBody>
                    {Array.from({ length: 5 }).map((_, index) => (
                        <TableRow key={index}>
                            {Array.from({ length: 9 }).map((_, cellIndex) => (
                                <TableCell key={cellIndex}>
                                    <Skeleton variant="text" width="80%" height={20} />
                                </TableCell>
                            ))}
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

const JobList: React.FC = () => {
    const userId = JSON.parse(localStorage.getItem('userDetails') || '{}').id;
    const navigate = useNavigate();
    const [value, setValue] = useState(0);
    const [jobs, setJobs] = useState<JobListProps[]>([]);
    const [options, setOptions] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const hasFetched = useRef(false);

    // Menu state
    const [menuState, setMenuState] = useState<{
        anchorEl: HTMLElement | null;
        openJobId: string | null;
    }>({
        anchorEl: null,
        openJobId: null
    });
    const fetchJobs = async (page: number) => {
        setIsLoading(true);
        try {
            const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");

            const response = await api.job.getMyJobs(
                value + 1,
                currentDate.toString(),
                page
            );
            if (response?.data) {
                setIsLoading(false);
                setJobs(response?.data || []);
                setTotalPages(response?.pagination?.total_pages || 0);
                setCurrentPage(response?.pagination?.current_page || 1);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobs([]);
        } finally {
            hasFetched.current = true;
        }
    };
    const cancelJob = async (jobId: number) => {
        try {
            const response = await api.job.cancelJob(jobId);
            if (response?.status) {
                toast.success(response?.message);
                fetchJobs(currentPage);
            } else {
                toast.error(response?.message);
            }
        } catch (error: any) {
            throw error;
        }
    }
    // Separate useEffect for data fetching
    useEffect(() => {
        if (hasFetched.current) return;
        if (!can(['view-job'])) {
            navigate(`/dashboard`);
        }
        setOptions([
            'View Job'
        ]);
        if (can(['edit-job'])) {
            setOptions(prevState => ([
                ...prevState,
                'Edit Job'
            ]));
        }
        if (can(['cancel-job'])) {
            setOptions(prevState => ([
                ...prevState,
                'Cancel Job'
            ]));
        }
        fetchJobs(currentPage);
    }, [value]);

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);
        setCurrentPage(1);
        hasFetched.current = false;
    };

    // Menu handlers
    const handleClick = (event: React.MouseEvent<HTMLElement>, jobId: string) => {
        setMenuState({
            anchorEl: event.currentTarget,
            openJobId: jobId
        });
    };

    const handleClose = () => {
        setMenuState({
            anchorEl: null,
            openJobId: null
        });
    };

    const handleOptionClick = (event: React.MouseEvent<HTMLElement>) => {
        const option = event.currentTarget.getAttribute('data-option');
        const jobId = event.currentTarget.getAttribute('data-job-id');

        if (option === 'View Job' && jobId) {
            navigate(`/view-job/${jobId}`);
        } else if (option === 'Edit Job' && jobId) {
            // navigate(`/edit-job/${jobId}`);
            window.location.href = `/edit-job/${jobId}`
        } else if (option === 'Cancel Job' && jobId) {
            cancelJob(Number(jobId));
        }
        handleClose();
    };

    const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
        setCurrentPage(page);
        fetchJobs(page);
        hasFetched.current = false;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (

        <LayoutProvider pageTitle="Job List">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className={`${styles.cardTitle} ${styles.jobCardTitle}`}>
                            <Tabs value={value} className="jobTabList" onChange={handleChange} aria-label="job tabs">
                                <Tab label="Posted" {...jobTabProps(0)} />
                                <Tab label="Accepted" {...jobTabProps(1)} />
                                <Tab label="Completed" {...jobTabProps(2)} />
                                <Tab label="Past Jobs" {...jobTabProps(3)} />
                                <Tab label="Cancelled" {...jobTabProps(4)} />
                                <Tab label="Saved Jobs" {...jobTabProps(5)} />
                            </Tabs>
                        </div>
                        <Box className={styles.dataContainer}>
                            {isLoading ? (
                                // <Box className="loaderContainer">
                                <JobTableSkeleton />
                                // </Box>
                            ) : (
                                <div>
                                    <TableContainer>
                                        {jobs.length > 0 ? (
                                            <Table className={styles.table}>
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell>Job ID</TableCell>
                                                        <TableCell>Material</TableCell>
                                                        <TableCell>Posted Date & Time</TableCell>
                                                        <TableCell>Job Cost</TableCell>
                                                        <TableCell>Pickup Date & Time</TableCell>
                                                        <TableCell>Delivery Date & Time</TableCell>
                                                        <TableCell>No. Of Trucks</TableCell>
                                                        <TableCell>Created By</TableCell>
                                                        {value == 3 && (<TableCell></TableCell>)}
                                                        <TableCell></TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {jobs.map((job) => {
                                                        const isOpen = menuState.openJobId === job.id;

                                                        return (
                                                            <TableRow key={job.id}>
                                                                <TableCell>{job?.unique_id}</TableCell>
                                                                <TableCell>{job?.material_name?.toLowerCase() === 'other' ? job?.material_other : (job?.material_name || 'NA')}</TableCell>
                                                                <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                                <TableCell>${job.job_estimate_price}</TableCell>
                                                                <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                                <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                                <TableCell>
                                                                    <span className={`${styles.badge} ${styles.blueBg}`}>
                                                                        {job.no_of_trucks || 0}
                                                                    </span>
                                                                </TableCell>
                                                                <TableCell>{userId == job?.created_by ? 'You' : job?.created_user}</TableCell>
                                                                {value == 3 && (
                                                                    <TableCell>
                                                                        <PostJobLink redirectTo={`/post-job/${job.unique_id}`}>
                                                                            <div className={styles.smallButton} style={{ textDecoration: 'none', cursor: 'pointer' }}>
                                                                                Repeat Job
                                                                            </div>
                                                                        </PostJobLink>

                                                                    </TableCell>
                                                                )}

                                                                <TableCell>
                                                                    <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                                                        <IconButton
                                                                            aria-label="more"
                                                                            id={`long-button`}
                                                                            aria-controls={isOpen ? `long-menu-${job.id}` : undefined}
                                                                            aria-expanded={isOpen ? 'true' : undefined}
                                                                            aria-haspopup="true"
                                                                            onClick={(event) => handleClick(event, job.id)}
                                                                        >
                                                                            <MoreVertIcon />
                                                                        </IconButton>
                                                                        <Menu
                                                                            id={`long-menu`}
                                                                            anchorEl={menuState.anchorEl}
                                                                            open={isOpen}
                                                                            onClose={handleClose}
                                                                            className={styles.menuList}
                                                                            slotProps={{
                                                                                paper: {
                                                                                    style: {
                                                                                        maxHeight: ITEM_HEIGHT * 4.5,
                                                                                        width: 'auto',
                                                                                        minWidth: '130px',
                                                                                    },
                                                                                },
                                                                                list: {
                                                                                    'aria-labelledby': `long-button-${job.id}`,
                                                                                },
                                                                            }}
                                                                        >
                                                                            {options.map((option) => {
                                                                                const isSelected = option === 'View Job';
                                                                                const normalizedOption = option.toLowerCase().replace(/\s+/g, '');
                                                                                let isDisabled = false;

                                                                                const iconProps = { sx: { fontSize: 18, marginRight: 1 } };
                                                                                let IconComponent;

                                                                                switch (option) {
                                                                                    case 'View Job':
                                                                                        IconComponent = <ContentPasteIcon {...iconProps} />;
                                                                                        break;
                                                                                    case 'Edit Job':
                                                                                        isDisabled = !job?.is_available_for_edit || [1, 2, 3, 4].includes(value);
                                                                                        IconComponent = <EditIcon {...iconProps} />;
                                                                                        break;
                                                                                    default:
                                                                                        isDisabled = value > 1;
                                                                                        IconComponent = <DoDisturbIcon {...iconProps} />;
                                                                                }
                                                                                return (
                                                                                    <MenuItem
                                                                                        key={option}
                                                                                        selected={isSelected}
                                                                                        onClick={handleOptionClick}
                                                                                        data-option={option}
                                                                                        data-job-id={isDisabled ? null : job?.id}
                                                                                        className={`${styles.menuItem} ${styles[normalizedOption]}`}
                                                                                        sx={{
                                                                                            display: 'flex',
                                                                                            alignItems: 'center',
                                                                                            gap: 1,
                                                                                            paddingY: 1,
                                                                                            paddingX: 2,
                                                                                            fontSize: 14,
                                                                                            color: isSelected ? 'primary.main' : 'text.primary',
                                                                                            backgroundColor: isSelected ? 'action.selected' : 'transparent',
                                                                                            '&:hover': {
                                                                                                backgroundColor: isDisabled ? 'transparent' : 'action.hover',
                                                                                            },
                                                                                            opacity: isDisabled ? 0.5 : 1,
                                                                                            cursor: isDisabled ? 'not-allowed' : 'pointer',
                                                                                        }}
                                                                                    >
                                                                                        {IconComponent}
                                                                                        {option}
                                                                                    </MenuItem>
                                                                                );
                                                                            })}
                                                                        </Menu>
                                                                    </Box>
                                                                </TableCell>
                                                            </TableRow>
                                                        );
                                                    })}
                                                </TableBody>
                                            </Table>
                                        ) : (
                                            <div className={styles.noDataContainer}>
                                                <Typography variant="h6" color="textSecondary" align="center">
                                                    <AssignmentLateIcon fontSize="large" />
                                                    <br />
                                                    No jobs found
                                                </Typography>
                                                <Typography variant="body2" color="textSecondary" align="center">
                                                    There are currently no jobs matching your criteria
                                                </Typography>
                                            </div>
                                        )}
                                    </TableContainer>

                                    {/* Pagination Section - only show when there's data and multiple pages */}
                                    {!isLoading && jobs.length > 0 && (
                                        <Box
                                            display="flex"
                                            justifyContent="center"
                                            mt={3}
                                            mb={2}
                                            className={styles.paginationContainer}
                                            sx={{ float: 'right' }}
                                        >
                                            <Pagination
                                                count={totalPages}
                                                page={currentPage}
                                                onChange={handlePageChange}
                                                color="primary"
                                                showFirstButton
                                                showLastButton
                                                shape="rounded"
                                                siblingCount={1}
                                                boundaryCount={1}
                                            />
                                        </Box>
                                    )}
                                </div>
                            )}
                        </Box>
                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default JobList;
