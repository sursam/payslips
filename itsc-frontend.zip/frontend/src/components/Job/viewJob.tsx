import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import GoogleMapReact from 'google-map-react';
import Loader from '../Loader/loader';
import {
	Card,
	CardHeader,
	CardContent,
	Grid,
	Typography,
	Divider,
	Button,
	Box,
	Stack,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
import moment from 'moment';
import LayoutProvider from "../../providers/LayoutProvider";
import styles from "../../styles/viewJob.module.css";
import FindNearestTrucker from './modal/findNearestTrucker';
import CompleteRequest from './modal/completeRequest';
import ChangePrice from './modal/changePrice';
import ChangeTruck from './modal/changeTruck';
import TruckerDetails from './modal/truckerDetails';
import { toast } from 'react-toastify';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import DirectionsRenderer from "./directionsRenderer";
import SearchIcon from '@mui/icons-material/Search';
import PortraitIcon from '@mui/icons-material/Portrait';
import FilePresentOutlinedIcon from '@mui/icons-material/FilePresentOutlined';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { can } from '../../utils/helper';
interface JobDetails {
	unique_id: string,
	source: string,
	destination: string,
	pickup_date_time: string,
	delivery_date_time: string,
	source_lat: string,
	source_lng: string,
	delivery_lat: string,
	delivery_lng: string,
	pickup_location_company: string,
	pickup_location_contact_no: string,
	pickup_location_email: string,
	pickup_contact: string,
	drop_off_location_company: string,
	drop_off_location_contact_no: string,
	drop_off_location_email: string,
	drop_off_contact: string,
	created_at: string,
	material_name: string,
	material_other: string,
	order_no: string,
	total_mileage: string,
	total_load: string,
	equipment_id: string,
	equipment_name: string,
	equipment_other: string,
	load_spacing_minutes: string,
	available_load_count: string,
	truck_details: Trucks[],
	is_hourly: number,
	per_unit_price: string,
	job_estimate_price: string,
	notes: string | null,
	is_available_for_edit: boolean,


}
interface Trucks {
	truck_type_id: string,
	name: string,
	specs: string,
	weight_capacity: string,
	trucktype_image: string
}
interface JobLoads {
	id: string,
	job_id: string,
	cancellation_request_id: string,
	completed_on: string,
	contractor_added_weight: string,
	pickup_date_time: string,
	delivery_date_time: string,
	discounted_load_cost: string,
	driver_load_weight: string,
	feedback: {
		comment: string,
		rating: string
	},
	is_discarded: string,
	weight: string,
	status: number,
	load_spacing: string,
	load_cost: string,
	trucker_details: Trucker,
	pickup_latitude: string,
	pickup_longitude: string,
	delivery_latitude: string,
	delivery_longitude: string,
	load_job_status: number
}
interface LoadInfo {
	id: string,
	status: number,
	feedback?: { comment: string, rating: string }
}
const style = {
	position: 'absolute',
	transform: 'translateX(0)',
	top: '0',
	bottom: '0',
	right: '0',
	width: 400,
	bgcolor: 'background.paper',
	border: '2px solid #000',
	boxShadow: 24,
	p: 4,
};
interface Trucker {
	id: string;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
	profile_image: string;
	rating: string;
	truck_type?: string;
	weight_capacity?: number;
	truck_type_image?: string
}
interface TruckTypes {
	name: string;
	specs: string;
	truck_type_id: string;
	trucktype_image: string;
	weight_capacity: string
}
interface driverEndJobRequest {
	job_id: number;
	load_id: number;
	contracter_name: string;
	load_actual_weight: string;
	trucker_taken_weight: string;
	ticket_no: string;
	challan: string;
	signed_challan: string;
	trucker_notes: string;
	additional_note: string;
	is_ticket_signed: number;
}

interface verifyLoadDeliveryRequestFrom {
	job_id: string;
	load_id: string;
	receiver_name: string;
	contractor_status: string;
	isnetweightflag: string;
	correct_net_weight?: string;
	trucker_taken_weight?: string;
	signature: File | null;
	notes?: string;
	ticket_no?: string;
	challan?: string;
	signed_challan?: string;
}


const ViewJob: React.FC = () => {
	const navigate = useNavigate();
	const { id } = useParams();
	const [expanded, setExpanded] = React.useState(false);
	const [jobDetails, setJobDetails] = useState<JobDetails | null>(null);
	const [loads, setLoads] = useState<JobLoads[] | null>(null);
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(0);
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [hasMore, setHasMore] = useState(true);
	const [totalLoads, setTotalLoads] = useState(0);
	const [truckTypes, setTruckTypes] = useState<TruckTypes[]>([]);
	const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
	const [openNearestTruckerModal, setOpenNearestTruckerModal] = React.useState(false);
	const [openVerifyLoadModal, setOpenVerifyLoadModal] = React.useState(false);
	const [openChangePriceModal, setOpenChangePriceModal] = React.useState(false);
	const [openChangeTruckTypeModal, setOpenChangeTruckTypeModal] = React.useState(false);
	const [openTruckerDetailsModal, setOpenTruckerDetailsModal] = React.useState(false);
	const [truckersData, setTruckersData] = useState<Trucker[]>([]);
	const handleCloseNearestTrucker = () => setOpenNearestTruckerModal(false);
	const [endJobRequest, setEndJobRequest] = useState<driverEndJobRequest | null>(null);
	const [selectedLoad, setSelectedLoad] = useState<LoadInfo | null>(null);
	const [selectedTruckerData, setSelectedTruckerData] = React.useState(null);
	const [changePriceData, setChangePriceData] = React.useState({ jobId: "", loadId: "", loadCost: "" });
	const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
		lat: 22.5810906,  // default or initial location
		lng: 88.4818398
	});
	const [map, setMap] = useState<google.maps.Map | null>(null);
	const observerRef = useRef(null);
	function handleApiLoaded(mapInstance: google.maps.Map, google: any) {
		setMap(mapInstance);
	}
	const defaultProps = {
		center: {
			lat: 10.99835602,
			lng: 77.01502627
		},
		zoom: 11
	};
	const handleOpenNearestTrucker = async () => {

		try {
			const payload = {
				latitude: currentLocation?.lat,
				longitude: currentLocation?.lng,
				job_id: id
			};
			const response = await api.job.getNearestTruckers(payload);
			setTruckersData(response);
			setOpenNearestTruckerModal(true);
		} catch (err) {
			console.error("Error in handler:", err);
		}
	};
	const handleVerifyLoad = async (jobId: string, loadId: string) => {
		if (!jobId || !loadId) {
			console.warn('Missing jobId or loadId');
			return;
		}

		try {
			const response = await api.job.getDriverEndJobRequest(jobId, loadId);
			if (response) {
				setEndJobRequest(response);
			}
		} catch (error) {
			console.error("API call failed:", error);
		}
		setOpenVerifyLoadModal(true);
	};
	const handleChangePrice = (jobId: string, loadId: string, loadCost: string) => {
		setChangePriceData({ jobId: jobId, loadId: loadId, loadCost: loadCost });
		setOpenChangePriceModal(true);
	}
	const handleCloseChangePrice = () => {
		setOpenChangePriceModal(false);
	}
	const handleCloseVerifyLoad = () => {
		setOpenVerifyLoadModal(false);
	}
	const handleChangeTruckType = () => {
		setOpenChangeTruckTypeModal(true);
	}
	const handleCloseChangeTruckType = () => {
		setOpenChangeTruckTypeModal(false);
	}
	const handleCloseTruckerDetails = () => {
		setOpenTruckerDetailsModal(false);
	}

	const handlePriceSubmit = async (jobId: string, loadId: string, price: string) => {
		try {
			const response = await api.job.changeLoadPrice(jobId, loadId, parseFloat(price));
			if (response?.status) {
				toast.success(response?.message);
				jobLoads(currentPage);
			}
		} catch (error) {
			console.error('Failed to send request:', error);
		}
	};

	const handleAcceptCompleteLoadRequest = async (payload: any) => {
		try {
			const response = await api.job.approveDriverEndJobRequest(payload);

			if (response?.status) {
				toast.success(response?.message);
				jobLoads(currentPage);
			} else {
				toast.error(response?.message);
			}
		} catch (error) {
			console.error('Failed to send request:', error);
		}
	}

	const handleTruckTypeSubmit = async (jobId: string, truckTypeIds: string) => {
		try {
			const response = await api.job.changeTruckType(jobId, truckTypeIds);
			if (response?.status) {
				toast.success(response?.message);
				viewJobDetails();
			}
		} catch (error) {
			console.error('Failed to send request:', error);
		}
	};

	// get show end job request api
	useEffect(() => {
		const showEndJobRequest = async (jobId: string, loadId: string) => {
			try {
				const response = await api.job.getDriverEndJobRequest(jobId, loadId);
				if (response) {
					setEndJobRequest(response);
				}
			} catch (error) {
				console.log("failed to get end job request", error);
			}
		};

	}, []);

	// fetch current location
	useEffect(() => {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(
				(position) => {
					const { latitude, longitude } = position.coords;
					setCurrentLocation({ lat: latitude, lng: longitude });
				},
				(error) => {
					console.error("Error getting location:", error);
				}
			);
		} else {
			console.error("Geolocation is not supported by this browser.");
		}
	}, []);

	const handleTruckerDetails = (loadId: string, status: number, feedback: any, truckerData: Trucker) => {

		setSelectedLoad({ id: loadId, status: status, feedback: feedback != null ? { comment: feedback?.comment, rating: feedback?.rating } : null });
		setSelectedTruckerData(truckerData);
		setOpenTruckerDetailsModal(true);
	}

	const viewJobDetails = async () => {
		setIsLoading(true);
		try {
			const response = await api.job.viewJobDetails(id);
			// console.log("job details", response);

			setJobDetails(response);
			setIsLoading(false);
		} catch (error) {
			setIsLoading(false);
		}
	};

	// fetch job details
	useEffect(() => {
		viewJobDetails();
	}, [id]);

	const jobLoads = useCallback(async (page: number) => {

		// Prevent unnecessary API call if we've reached the last page
		if (totalPages && page > totalPages) {
			setHasMore(false);
			return;
		}

		setIsLoading(true);
		try {
			const response = await api.job.getJobLoads(id, page);

			const newLoads = response?.data || [];
			const pagination = response?.pagination || {};

			if (page === 1) {
				setLoads(newLoads);
			} else {
				setLoads(prevLoads => [...prevLoads, ...newLoads]);
			}

			setTotalPages(pagination.total_pages || 0);
			setCurrentPage(pagination.current_page || 1);
			setTotalLoads(pagination.total || 0);

			const hasMorePages = (pagination.current_page || 1) < (pagination.total_pages || 0);
			setHasMore(hasMorePages);
		} catch (error) {
			console.error('Error fetching job loads:', error);
		} finally {
			setIsLoading(false);
		}
	}, [id, totalPages]);



	useEffect(() => {
		jobLoads(1); // Always start from page 1
	}, [jobLoads]);


	useEffect(() => {
		const observer = new IntersectionObserver(
			(entries) => {
				if (
					entries[0].isIntersecting &&
					hasMore &&
					!isLoading &&
					currentPage < totalPages // Prevent extra call on last page
				) {
					jobLoads(currentPage + 1);
				}
			},
			{ threshold: 1 }
		);

		if (observerRef.current) observer.observe(observerRef.current);

		return () => {
			if (observerRef.current) observer.unobserve(observerRef.current);
		};
	}, [jobLoads, hasMore, isLoading, currentPage, totalPages]);




	// fetch Truck Types
	useEffect(() => {
		const truckTypes = async () => {
			try {
				const response = await api.job.getTruckTypeList();
				setTruckTypes(response.data);
			} catch (error) {
				console.error('Error fetching truck types:', error);
			}
		};
		truckTypes();
	}, [id]);


	const handleExpansion = () => {
		setExpanded((prevExpanded) => !prevExpanded);
	};

	const getStatusLabel = (status: any) => {

		switch (status) {
			case 0: return 'Available';
			case 1: return 'Accepted';
			case 2: return 'Running';
			case 3: return 'Show Request';
			case 4: return 'Completed';
			case 5: return 'Cancelled';
			default: return status;
		}
	};
	const statusCounts = {
		completed: loads?.filter(item => item.status === 4).length,
		available: loads?.filter(item => item.status === 0).length,
		ongoing: loads?.filter(item => item.status !== 0 && item.status !== 4).length,
	};
	const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
	const open = Boolean(anchorEl);
	const handleClick = (event: React.MouseEvent<HTMLElement>) => {
		setAnchorEl(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
	};
	const handleEditJob = () => {
		window.location.href = `/edit-job/${id}`
	}
	return (
		<LayoutProvider pageTitle="Job Details" backUrl="/job-list">
			<Box sx={{ flexGrow: 1, position: 'relative' }}>
				{isLoading ?
					<Box className="loaderContainer">

						<Loader />
					</Box>
					: ''
				}
				<Grid container spacing={{ lg: '0', md: '0', sm: '2', xs: '1' }} className={styles.gridContainer} sx={{ border: '1px solid #E7E7E7' }}>
					<Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }} className={`${styles.leftPanel} `} >
						<Card sx={{ boxShadow: 'none', height: 'auto', borderRight: '1px solid #E7E7E7', borderRadius: 0 }}>
							<CardHeader
								title={
									<Box className='jblHeader' sx={{
										display: 'flex',
										justifyContent: 'space-between',
										alignItems: 'center',
										// minHeight: '40px',
										gap: 2
									}}>
										<Box>
											<Typography variant="subtitle2" sx={{
												fontSize: 12,
												fontWeight: 400,
												fontFamily: 'Poppins',
												color: '#666',
												mb: 0.5
											}}>
												Job ID
											</Typography>
											<Typography variant="caption" sx={{
												fontSize: 16,
												fontWeight: 600,
												fontFamily: 'Poppins'
											}}>
												{jobDetails?.unique_id || 'NA'}
											</Typography>
										</Box>
										<Box sx={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
											<Box sx={{ textAlign: 'right' }}>
												<Typography variant="subtitle2" sx={{
													fontSize: 12,
													fontWeight: 400,
													fontFamily: 'Poppins',
													color: '#666',
													mb: 0.5
												}}>
													Posted On
												</Typography>
												<Typography variant="caption" sx={{
													fontSize: 16,
													fontWeight: 600,
													fontFamily: 'Poppins'
												}}>
													{moment(jobDetails?.created_at).format("D MMM YYYY | HH:mm:ss") || 'NA'}
												</Typography>
											</Box>
											<div>
												{jobDetails?.is_available_for_edit && (
													<IconButton
														aria-label="more"
														id="long-button"
														aria-controls={open ? 'long-menu' : undefined}
														aria-expanded={open ? 'true' : undefined}
														aria-haspopup="true"
														onClick={handleClick}
													>
														<MoreVertIcon />
													</IconButton>
												)}
												<Menu
													id="long-menu"
													anchorEl={anchorEl}
													open={open}
													onClose={handleClose}

												>
													<MenuItem onClick={handleEditJob}>
														Edit
													</MenuItem>

												</Menu>
											</div>
										</Box>
									</Box>
								}
								className={`${styles.cardHeader}`}
							/>

							<Divider
								sx={{
									borderColor: 'divider',
									position: 'sticky',
									top: 0,
									zIndex: 1,
								}}
							/>

							<CardContent sx={{
								overflowY: 'scroll',
								// height: '100%',
								p: 2,
								width: '-webkit-fill-available'
							}} className={`${styles.cardContent} jdHeight`}>

								{/* Job Details Section */}
								<Typography gutterBottom sx={{
									color: '#005DAA',
									fontSize: 18,
									fontFamily: 'Poppins',
									fontWeight: 600,
									mb: 2
								}}>
									Job Details
								</Typography>

								{/* Material Type and Order Number */}
								<Grid container spacing={2} sx={{ mb: 2 }}>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Material Type
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.material_name?.toLowerCase() === 'other' ? jobDetails?.material_other : (jobDetails?.material_name || 'NA')}
										</Typography>
									</Grid>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Order Number
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.order_no || 'NA'}
										</Typography>
									</Grid>
								</Grid>

								{/* Total Mileage and Number of Units */}
								<Grid container spacing={2} sx={{ mb: 2 }}>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Total Mileage
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.total_mileage ? `${jobDetails?.total_mileage} Miles` : 'NA'}
										</Typography>
									</Grid>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Number Of Units
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.total_load} Tons
										</Typography>
									</Grid>
								</Grid>

								{/* Hourly Job Section */}
								{jobDetails?.is_hourly === 1 &&
									<Box className='sfwfdgdfsdfsd' sx={{
										display: 'flex',
										alignItems: 'center',
										gap: 2,
										mb: 3,
										backgroundColor: '#f0f8f0',
										p: 2,
										borderRadius: 2,
										flexWrap: 'wrap',
										width: '-webkit-fill-available'
									}}>
										<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 'fit-content' }}>

											<Typography className={styles.jobHourTitles}><CheckCircleIcon className={styles.jobHourIcons} /> Hourly Job</Typography>
										</Box>

										<Box sx={{ display: 'flex', gap: 4, flex: 1, flexWrap: 'wrap' }}>
											<Box sx={{ minWidth: 'fit-content', display: 'flex', gap: 2, flex: 1, flexWrap: 'wrap', alignItems: 'center' }}>
												<Typography sx={{
													fontSize: 12,
													fontWeight: 400,
													fontFamily: 'Poppins',
													color: '#888',
													fontStyle: 'italic',
													mb: 0.5
												}}>
													Minimum Hour (s) :
												</Typography>
												<Typography sx={{
													fontSize: 16,
													fontWeight: 600,
													fontFamily: 'Poppins'
												}}>
													1
												</Typography>
											</Box>
											<Box sx={{ minWidth: 'fit-content', display: 'flex', gap: 2, flex: 1, flexWrap: 'wrap', alignItems: 'center' }}>
												<Typography sx={{
													fontSize: 12,
													fontWeight: 400,
													fontFamily: 'Poppins',
													color: '#888',
													fontStyle: 'italic',
													mb: 0.5
												}}>
													Maximum Hour (s) :
												</Typography>
												<Typography sx={{
													fontSize: 16,
													fontWeight: 600,
													fontFamily: 'Poppins'
												}}>
													1
												</Typography>
											</Box>
										</Box>
									</Box>
								}

								{/* Equipment Section */}
								{jobDetails?.equipment_name || jobDetails?.equipment_other ? (<Box className='sfwfdgdfsdfsddsd' sx={{
									display: 'flex',
									alignItems: 'center',
									gap: 2,
									mb: 3,
									backgroundColor: '#f0f8f0',
									p: 2,
									borderRadius: 2
								}}>
									<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>

										<Typography className={styles.jobHourTitles}><CheckCircleIcon className={styles.jobHourIcons} /> Equipment</Typography>
									</Box>
									<Box sx={{ display: 'flex', gap: 2, flex: 1, flexWrap: 'wrap', alignItems: 'center' }}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Type :
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.equipment_name ? jobDetails?.equipment_name : (jobDetails?.equipment_other ? jobDetails?.equipment_other : 'NA')}
										</Typography>
									</Box>
								</Box>) : ''}

								{/* Load Spacing and No Of Loads */}
								<Grid container spacing={2} sx={{ mb: 2 }}>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Load Spacing in Minutes
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.load_spacing_minutes ? jobDetails?.load_spacing_minutes : '0'}
										</Typography>
									</Grid>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											No Of Loads
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											{jobDetails?.available_load_count ? jobDetails?.available_load_count : '0'}
										</Typography>
									</Grid>
								</Grid>

								{/* Pricing Section */}
								<Grid container spacing={2} sx={{ mb: 2 }}>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Price Per Unit
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins'
										}}>
											${jobDetails?.per_unit_price ? jobDetails?.per_unit_price : '0'}
										</Typography>
									</Grid>
									<Grid size={6}>
										<Typography sx={{
											fontSize: 12,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#888',
											fontStyle: 'italic',
											mb: 0.5
										}}>
											Total Job Cost
										</Typography>
										<Typography sx={{
											fontSize: 16,
											fontWeight: 600,
											fontFamily: 'Poppins',
											color: '#005DAA'
										}}>
											${jobDetails?.job_estimate_price ? jobDetails?.job_estimate_price : '0'}
										</Typography>
									</Grid>
								</Grid>

								{/* Truck Type Section */}
								<Typography gutterBottom sx={{
									color: '#005DAA',
									fontSize: 18,
									fontFamily: 'Poppins',
									fontWeight: 600,
									mb: 2
								}}>
									Truck Type
								</Typography>

								{/* Truck Options */}
								{/* <Stack spacing={2} sx={{ mb: 4 }}> */}
								{jobDetails?.truck_details && jobDetails?.truck_details.map((truck: Trucks, index: number) => (
									<Stack spacing={2} sx={{ mb: 2 }} key={index}>
										<Box sx={{
											display: 'flex',
											alignItems: 'center',
											justifyContent: 'space-between',
											p: 2,
											border: 1,
											borderColor: '#e0e0e0',
											borderRadius: 2
										}}>
											<Box sx={{ flex: 1 }}>
												<Typography sx={{
													fontSize: 16,
													fontWeight: 600,
													fontFamily: 'Poppins',
													mb: 0.5
												}}>
													{truck.name ? truck.name : 'NA'}
												</Typography>
												<Typography sx={{
													fontSize: 12,
													fontWeight: 400,
													fontFamily: 'Poppins',
													color: '#888'
												}}>
													{truck?.specs} Axels | {truck?.weight_capacity} Tons
												</Typography>
											</Box>
											<Box sx={{
												width: 50,
												height: 30,
												display: 'flex',
												alignItems: 'center',
												justifyContent: 'center',
												flexShrink: 0
											}}>
												<img
													src={truck?.trucktype_image ? truck?.trucktype_image : '/assets/images/car.jpg'}
													alt="Truck"
													style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
												/>
											</Box>
										</Box>
									</Stack>
								))}
								{/* </Stack> */}
								{/* Location Details Section */}
								<Typography gutterBottom sx={{
									color: '#005DAA',
									fontSize: 18,
									fontFamily: 'Poppins',
									fontWeight: 600,
									mb: 2
								}}>
									Job Locations
								</Typography>

								<Box sx={{
									p: 3,
									mb: 4
								}}>
									{/* Pickup Location */}
									<Box sx={{ mb: 3 }}>
										<Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
											<Box sx={{
												width: 12,
												height: 12,
												borderRadius: '50%',
												backgroundColor: '#FF9800',
												mr: 2
											}} />
											<Typography sx={{
												fontSize: 16,
												fontFamily: 'Poppins',
												color: '#333',
												fontWeight: 600
											}}>
												Pickup
											</Typography>
										</Box>

										<Typography sx={{
											fontSize: 14,
											fontWeight: 600,
											fontFamily: 'Poppins',
											mb: 0.5,
											ml: 3
										}}>
											{jobDetails?.pickup_date_time ? new Date(jobDetails.pickup_date_time).toLocaleDateString('en-GB', {
												day: '2-digit',
												month: 'short',
												year: 'numeric'
											}) : '09 May 2025'} | {moment(jobDetails?.pickup_date_time).format('LT') || '10:00 AM'}
										</Typography>

										<Typography sx={{
											fontSize: 14,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#333',
											ml: 3,
											mb: 1
										}}>
											{jobDetails?.source || '11325 Nations Ford Rd, Pineville, North Carolina, 28134'}
										</Typography>

										<Box sx={{ display: 'flex', alignItems: 'center', ml: 3, mb: 1 }}>

										</Box>

										<Box sx={{ ml: 3 }}>
											<Typography sx={{
												fontSize: 14,
												fontWeight: 500,
												fontFamily: 'Poppins',
												color: '#333',
												mb: 0.5,
												display: 'flex',
												alignItems: 'center',
												gap: 1
											}}>
												<PersonIcon /> {jobDetails?.pickup_contact || 'Indranil Sen'}
											</Typography>
											<Typography sx={{
												fontSize: 12,
												fontWeight: 400,
												fontFamily: 'Poppins',
												color: '#666',
												display: 'flex',
												alignItems: 'center',
												gap: 1
											}}>
												<EmailIcon /> {jobDetails?.pickup_location_email || 'indranil.sen@shyamfuture.com'}  <LocalPhoneIcon /> {jobDetails?.pickup_location_contact_no || '+91 - 6291332961'}
											</Typography>
										</Box>
									</Box>
									{/* Drop Location */}
									<Box>
										<Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
											<Box sx={{
												width: 12,
												height: 12,
												borderRadius: '50%',
												backgroundColor: '#4CAF50',
												mr: 2
											}} />
											<Typography sx={{
												fontSize: 16,
												fontWeight: 600,
												fontFamily: 'Poppins',
												color: '#333'
											}}>
												Drop Off
											</Typography>
										</Box>

										<Typography sx={{
											fontSize: 14,
											fontWeight: 500,
											fontFamily: 'Poppins',
											mb: 0.5,
											ml: 3
										}}>
											{jobDetails?.delivery_date_time ? new Date(jobDetails.delivery_date_time).toLocaleDateString('en-GB', {
												day: '2-digit',
												month: 'short',
												year: 'numeric'
											}) : '09 May 2025'} | {'10:00 AM'}
										</Typography>

										<Typography sx={{
											fontSize: 14,
											fontWeight: 400,
											fontFamily: 'Poppins',
											color: '#333',
											ml: 3,
											mb: 1
										}}>
											{jobDetails?.destination || '11325 Nations Ford Rd, Pineville, North Carolina, 28134'}
										</Typography>

										<Box sx={{ display: 'flex', alignItems: 'center', ml: 3, mb: 1 }}>
										</Box>

										<Box sx={{ ml: 3 }}>
											<Typography sx={{
												fontSize: 14,
												fontWeight: 500,
												fontFamily: 'Poppins',
												color: '#333',
												mb: 0.5,
												display: 'flex',
												alignItems: 'center'
											}}>
												<PersonIcon /> {jobDetails?.drop_off_contact || 'Indranil Sen'}
											</Typography>
											<Typography sx={{
												fontSize: 12,
												fontWeight: 400,
												fontFamily: 'Poppins',
												color: '#666',
												display: 'flex',
												alignItems: 'center',
												gap: 1
											}}>
												<EmailIcon /> {jobDetails?.drop_off_location_email || 'indranil.sen@shyamfuture.com'}  <LocalPhoneIcon /> {jobDetails?.drop_off_location_contact_no || '+91 - 6291332961'}
											</Typography>
										</Box>
									</Box>
								</Box>


								{/* Additional Notes Section */}
								<Typography gutterBottom sx={{
									color: '#005DAA',
									fontSize: 18,
									fontFamily: 'Poppins',
									fontWeight: 600,
									mb: 2
								}}>
									Additional Notes
								</Typography>
								<Typography variant="body2" sx={{
									lineHeight: 1.6,
									color: '#333'
								}}>
									{jobDetails?.notes ? jobDetails?.notes : 'No additional notes available.'}
								</Typography>
							</CardContent>
						</Card>
					</Grid>

					<Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }} className={styles.rightPanel} >
						<Card sx={{ boxShadow: 'none', display: 'flex', flexDirection: 'column', borderRadius: 0 }}>
							<CardHeader
								title={
									<div style={{
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'space-between',
										gap: '16px'
										// minHeight: '64px'
									}}>
										{/* Title and Counter */}
										<div className='jblHeader' style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
											<Typography
												sx={{
													color: '#005DAA',
													fontSize: 18,
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 600,
													lineHeight: 1.5
												}}
											>
												Loads
											</Typography>
											<div style={{
												backgroundColor: '#005DAA',
												color: 'white',
												borderRadius: '50%',
												width: '28px',
												height: '28px',
												display: 'flex',
												alignItems: 'center',
												justifyContent: 'center',
												fontSize: '12px',
												fontWeight: 600,
												fontFamily: 'Poppins, sans-serif'
											}}>
												{totalLoads}
											</div>
										</div>

										{/* Status Indicators */}
										<div style={{
											display: 'flex',
											gap: '16px',
											alignItems: 'center'
										}}>
											{/* Completed */}
											<div style={{
												display: 'flex',
												alignItems: 'center',
												gap: '6px',
												padding: '6px 12px',
												borderRadius: '20px',
												backgroundColor: '#f5f5f5'
											}}>
												<span style={{
													color: '#007A2F',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 600,
													fontSize: '12px'
												}}>({statusCounts.completed})</span>
												<span style={{
													color: '#424242',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 500,
													fontSize: '12px'
												}}>Completed</span>
											</div>

											{/* On Going */}
											<div style={{
												display: 'flex',
												alignItems: 'center',
												gap: '6px',
												padding: '6px 12px',
												borderRadius: '20px',
												backgroundColor: '#f5f5f5'
											}}>
												<span style={{
													color: '#F9A825',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 600,
													fontSize: '12px'
												}}>({statusCounts.ongoing})</span>
												<span style={{
													color: '#424242',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 500,
													fontSize: '12px'
												}}>On Going</span>
											</div>

											{/* Available */}
											<div style={{
												display: 'flex',
												alignItems: 'center',
												gap: '6px',
												padding: '6px 12px',
												borderRadius: '20px',
												backgroundColor: '#f5f5f5'
											}}>
												<span style={{
													color: '#005DAA',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 600,
													fontSize: '12px'
												}}>({statusCounts.available})</span>
												<span style={{
													color: '#424242',
													fontFamily: 'Poppins, sans-serif',
													fontWeight: 500,
													fontSize: '12px'
												}}>Available</span>
											</div>
										</div>
									</div>
								}
							// sx={{ pb: 0, flexShrink: 0 }}
							/>

							<Divider sx={{ borderColor: '#e0e0e0', my: 0, flexShrink: 0 }} />

							<CardContent className='jdHeight' sx={{
								pt: 2,
								overflowY: 'auto'
							}}>
								<div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>


									{loads?.map((load, index) => {
										const isLastItem = loads.length === index + 1;
										return (
											<Accordion
												key={index}
												sx={{
													boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
													borderRadius: '8px !important',
													'&:before': { display: 'none' },
													mb: 2,
													flexShrink: 0
												}}
											>
												<AccordionSummary
													component="div"
													expandIcon={<ExpandMoreIcon />}
													sx={{
														backgroundColor: '#FFF9EC',
														borderRadius: '8px',
														// minHeight: '64px',
														'&.Mui-expanded': {
															borderBottomLeftRadius: 0,
															borderBottomRightRadius: 0
														}
													}}
												>
													<div style={{
														display: 'flex',
														alignItems: 'center',
														justifyContent: 'space-between',
														width: '100%',
														paddingRight: '16px'
													}}>
														<Typography
															sx={{
																fontFamily: 'Poppins, sans-serif',
																fontWeight: 600,
																fontSize: '16px',
																color: '#333'
															}}
														>
															Load {index + 1}
														</Typography>
														{/* <Button
															variant="contained"
															size="small"
															sx={{
																fontSize: '11px',
																padding: '6px 16px',
																backgroundColor: load?.status == 0 ? '#005DAA' : (load.status == 4 ? '#007A2F' : '#005DAA'),
																textTransform: 'capitalize',
																fontFamily: 'Poppins, sans-serif',
																fontWeight: 500,
																borderRadius: '16px',
																margin: '0',
															}}
														>
															{load?.load_job_status == 5 ? 'Cancelled' : getStatusLabel(load.status)}
														</Button> */}
														<Button
															variant="contained"
															size="small"
															sx={{
																fontSize: '11px',
																padding: '6px 16px',
																backgroundColor:
																	load?.load_job_status == 5 && load?.status == 0
																		? '#D32F2F'
																		: load?.status == 0
																			? '#005DAA'
																			: load?.status == 4
																				? '#007A2F'
																				: '#005DAA',
																textTransform: 'capitalize',
																fontFamily: 'Poppins, sans-serif',
																fontWeight: 500,
																borderRadius: '16px',
																margin: '0',
															}}
														>
															{load?.load_job_status == 5 && load?.status == 0 ? 'Cancelled' : getStatusLabel(load.status)}
														</Button>

													</div>
												</AccordionSummary>

												<AccordionDetails sx={{ backgroundColor: '#fff', padding: '24px 24px 0px 24px ' }}>
													<Grid container spacing={3}>
														<Grid size={6}>
															<Typography sx={{
																fontsize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Pickup Date & Time
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load?.pickup_date_time}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Drop Off Date & Time
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load?.delivery_date_time}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Weight
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load?.weight}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Load Spacing in Minutes
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load?.load_spacing}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Weight Received By Trucker
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load?.driver_load_weight}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Weight Received By Contractor
															</Typography>
															<Typography sx={{
																fontSize: 16,
																fontWeight: 600,
																fontFamily: 'Poppins, sans-serif',
																color: '#333'
															}}>
																{load.contractor_added_weight ? load.contractor_added_weight : 'NA'}
															</Typography>
														</Grid>

														<Grid size={6}>
															<Typography sx={{
																fontSize: 12,
																fontWeight: 400,
																fontFamily: 'Poppins, sans-serif',
																color: '#888',
																fontStyle: 'italic',
																mb: 0.5
															}}>
																Load Price
															</Typography>
															<div className={styles.priceSection}>
																<Typography sx={{
																	fontSize: 16,
																	fontWeight: 600,
																	fontFamily: 'Poppins, sans-serif',
																	color: '#333'
																}}>
																	{load?.load_cost}
																</Typography>
																{parseFloat(load.weight) <= 10.00 && load?.status == 0 && (
																	<Button
																		onClick={() => handleChangePrice(load.job_id, load.id, load.load_cost)}
																		className={styles.priceButton}
																	>
																		Change Price
																	</Button>
																)}
															</div>
														</Grid>
														{parseFloat(load.weight) <= 10.00 && load?.status == 0 && (
															<Grid size={6}>
																<Button
																	onClick={handleChangeTruckType}
																	className={styles.changeTruckButton}
																>
																	Change Truck
																</Button>
																<ChangeTruck
																	jobId={load.job_id}
																	truckType={truckTypes}
																	open={openChangeTruckTypeModal}
																	onClose={handleCloseChangeTruckType}
																	onSubmitTruckTypes={handleTruckTypeSubmit}
																/>
															</Grid>
														)}
													</Grid>
													<div style={{ marginTop: '24px' }}>
														<div style={{ height: '40vh', width: '100%', borderRadius: '12px' }}>
															{GOOGLE_MAPS_API_KEY ? (
																<GoogleMapReact
																	bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
																	defaultCenter={defaultProps.center}
																	center={mapCenter}
																	defaultZoom={14}
																	zoom={14}
																	onGoogleApiLoaded={({ map, maps }) => handleApiLoaded(map, maps)}
																>
																	{map && (
																		<DirectionsRenderer
																			map={map}
																			origin={{ lat: Number(jobDetails?.source_lat), lng: Number(jobDetails?.source_lng) }}
																			destination={{ lat: Number(jobDetails?.delivery_lat), lng: Number(jobDetails?.delivery_lng) }}
																		/>
																	)}
																</GoogleMapReact>
															) : ''}

														</div>
													</div>
													{load.status === 0 && load?.load_job_status != 5 ? (
														<div className={styles.accordianButtonGroup}>
															<Button
																onClick={handleOpenNearestTrucker}
																variant="outlined"
																startIcon={<SearchIcon />}
																sx={{
																	fontFamily: 'Poppins, sans-serif',
																	fontWeight: 600,
																	textTransform: 'none',
																	borderColor: 'transparent',
																	borderRadius: '8px',
																	padding: '8px 24px',
																	'&:hover': {
																		borderColor: '#004A8A',
																		backgroundColor: '#004A8A',
																		color: '#fff',
																	}
																}}
															>
																Find Nearest Trucker
															</Button>
														</div>
													) : load.status === 1 ? (
														<>
															<div className={styles.accordianButtonGroup}>
																<div className={styles.accordianButtonInner}>
																	<Button
																		onClick={() => handleTruckerDetails(load?.id, load?.status, load?.feedback, load?.trucker_details)}
																		variant="outlined"
																		startIcon={<PortraitIcon />}
																		sx={{
																			fontFamily: 'Poppins, sans-serif',
																			fontWeight: 600,
																			textTransform: 'none',
																			borderColor: 'transparent',
																			color: '#005DAA',
																			borderRadius: '8px',
																			padding: '8px 24px',
																			border: 0,
																			'&:hover': {
																				borderColor: '#004A8A',
																				backgroundColor: 'rgba(0, 93, 170, 0.04)'
																			}
																		}}
																	>
																		Trucker Details
																	</Button>
																</div>
															</div>
														</>
													) : load.status === 3 ? (
														<>
															<div className={styles.accordianButtonGroup}>
																<div className={styles.accordianButtonInner}>
																	<Button
																		onClick={() => handleTruckerDetails(load?.id, load?.status, load?.feedback, load?.trucker_details)}
																		variant="outlined"
																		startIcon={<PortraitIcon />}
																		sx={{
																			fontFamily: 'Poppins, sans-serif',
																			fontWeight: 600,
																			textTransform: 'none',
																			borderRadius: '8px',
																			padding: '8px 24px',
																			border: 0,
																			// Icon styling
																			'& .MuiButton-startIcon': {
																				color: '#005DAA',
																				fontSize: '40px',
																				marginRight: '8px',
																				transition: 'all 0.3s ease',
																			},

																			// Icon SVG specific styling
																			'& .MuiButton-startIcon svg': {
																				fontSize: '20px',
																				transition: 'transform 0.3s ease',
																			},

																			// Transition for smooth animations
																			transition: 'all 0.3s ease',
																		}}
																	>
																		Trucker Details
																	</Button>
																</div>
																{can(['verify-job']) ? (
																	<div className={styles.accordianButtonInner}>
																		<Button
																			variant="contained"
																			onClick={() => handleVerifyLoad(load?.job_id, load?.id)}
																			startIcon={<FilePresentOutlinedIcon />}
																			sx={{
																				fontFamily: 'Poppins, sans-serif',
																				fontWeight: 600,
																				border: 'none',
																				textTransform: 'none',
																				borderRadius: '8px',
																				padding: '8px 24px',
																				'&:hover': {
																					backgroundColor: '#004A8A'
																				}
																			}}
																		>
																			Complete Request
																		</Button>
																	</div>
																) : ''}
																<CompleteRequest
																	jobId={load.job_id}
																	loadId={load.id}
																	open={openVerifyLoadModal}
																	onClose={handleCloseVerifyLoad}
																	endJobRequest={endJobRequest}
																	onCompleteRequest={handleAcceptCompleteLoadRequest}
																/>
															</div>
														</>
													) : (
														<>
															<div className={styles.accordianButtonGroup}>
																<div className={styles.accordianButtonInner}>
																	<Button
																		onClick={() => handleTruckerDetails(load?.id, load?.status, load?.feedback, load?.trucker_details)}
																		variant="outlined"
																		startIcon={<PortraitIcon />}
																		sx={{
																			fontFamily: 'Poppins, sans-serif',
																			fontWeight: 600,
																			textTransform: 'none',
																			// borderColor: '#005DAA',
																			borderColor: 'transparent',
																			color: '#005DAA',
																			borderRadius: '8px',
																			padding: '8px 24px',
																			'&:hover': {
																				borderColor: '#004A8A',
																				backgroundColor: '#004A8A',
																				color: '#fff',
																			}
																		}}
																	>
																		Trucker Details
																	</Button>
																</div>
															</div>
														</>
													)
													}
												</AccordionDetails>
											</Accordion>
										);
									})}
									<div ref={observerRef} className="h-10" />
									{isLoading && <p>Loading more jobs...</p>}
									<TruckerDetails
										jobId={id}
										load={selectedLoad}
										open={openTruckerDetailsModal}
										onClose={handleCloseTruckerDetails}
										truckerData={selectedTruckerData}
									/>
									<FindNearestTrucker
										jobId={id}
										open={openNearestTruckerModal}
										onClose={handleCloseNearestTrucker}
										truckers={truckersData}
									/>
									<ChangePrice
										jobId={changePriceData?.jobId}
										loadId={changePriceData?.loadId}
										loadPrice={changePriceData?.loadCost}
										open={openChangePriceModal}
										onClose={handleCloseChangePrice}
										onSubmitPrice={handlePriceSubmit}
									/>
								</div>
							</CardContent>
						</Card>
					</Grid>
				</Grid>
			</Box>
		</LayoutProvider >
	);
};
export default ViewJob;