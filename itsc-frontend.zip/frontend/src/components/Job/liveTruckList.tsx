import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import moment from 'moment';
// import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import {
    Box,
    CardContent,
    Menu,
    MenuItem,
    Pagination,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid,
    Typography,
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { can } from "../../utils/helper";
const options = [
    'View Loads',
];

const ITEM_HEIGHT = 48;

interface Job {
    job_id: string;
    source: string;
    unique_id: string;
    destination: string;
    pickup_date: string;
    total_job_cost: number;
    delivery_date: string;
    total_job_load: number;
}

const LiveTruckList: React.FC = () => {

    const navigate = useNavigate();
    const [jobs, setJobs] = useState<Job[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const hasFetched = useRef(false);

    // Menu state
    const [menuState, setMenuState] = useState<{
        anchorEl: HTMLElement | null;
        openJobId: string | null;
    }>({
        anchorEl: null,
        openJobId: null
    });

    const fetchJobs = async () => {
        setIsLoading(true);
        try {
            const response = await api.job.getRunningJobs(
                currentPage
            );
            if (response?.data) {
                setIsLoading(false);
                setJobs(response?.data || []);
                setTotalPages(response?.pagination?.total_pages || 0);
                setCurrentPage(response?.pagination?.current_page || 1);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
            setJobs([]);
        } finally {
            hasFetched.current = true;
        }
    };

    // Separate useEffect for data fetching
    useEffect(() => {
        if (!can(['view-loads'])) {
            navigate(`/dashboard`);
        }
        if (hasFetched.current) return;
        fetchJobs();
    }, []); // Re-fetch when tab value changes

    // Menu handlers
    const handleClick = (event: React.MouseEvent<HTMLElement>, jobId: string) => {
        setMenuState({
            anchorEl: event.currentTarget,
            openJobId: jobId
        });
    };

    const handleClose = () => {
        setMenuState({
            anchorEl: null,
            openJobId: null
        });
    };

    const handleOptionClick = (event: React.MouseEvent<HTMLElement>) => {

        const option = event.currentTarget.getAttribute('data-option');
        const jobId = event.currentTarget.getAttribute('data-job-id');

        if (option === 'View Loads' && jobId) {
            navigate(`/live-truck-loads/${jobId}`);
        }

        handleClose();
    };

    const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
        setCurrentPage(page);
        hasFetched.current = false;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (

        <LayoutProvider pageTitle="Live Trucks">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        {isLoading ?
                            <Box className="loaderContainer">
                                <Loader />
                            </Box>
                            : ''
                        }
                        <div>
                            <TableContainer sx={{ minHeight: '420px' }}>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell sx={{ width: '20%' }}>Pickup Location</TableCell>
                                                <TableCell sx={{ width: '20%' }}>Pickup Date & Time</TableCell>
                                                <TableCell sx={{ width: '20%' }}>Drop off Location</TableCell>
                                                <TableCell sx={{ width: '20%' }}>Delivery Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell sx={{ width: '15%' }}>No. Of Loads</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => {
                                                const isOpen = menuState.openJobId === job?.job_id;

                                                return (
                                                    <TableRow key={job.job_id}>
                                                        <TableCell>{job?.unique_id}</TableCell>
                                                        <TableCell>{job?.source}</TableCell>
                                                        <TableCell>{moment(job.pickup_date).format("D MMM YYYY | HH:mm")}</TableCell>
                                                        <TableCell>{job?.destination}</TableCell>
                                                        <TableCell>{moment(job.delivery_date).format("D MMM YYYY | HH:mm")}</TableCell>
                                                        <TableCell>${job.total_job_cost}</TableCell>
                                                        <TableCell>
                                                            <span className={`${styles.badge} ${styles.blueBg}`}>
                                                                {job.total_job_load}
                                                            </span>
                                                        </TableCell>
                                                        <TableCell>
                                                            <div>
                                                                <IconButton
                                                                    aria-label="more"
                                                                    id={`long-button`}
                                                                    aria-controls={isOpen ? `long-menu-${job.job_id}` : undefined}
                                                                    aria-expanded={isOpen ? 'true' : undefined}
                                                                    aria-haspopup="true"
                                                                    onClick={(event) => handleClick(event, job.job_id)}
                                                                >
                                                                    <MoreVertIcon />
                                                                </IconButton>
                                                                <Menu
                                                                    id={`long-menu`}
                                                                    anchorEl={menuState.anchorEl}
                                                                    open={isOpen}
                                                                    onClose={handleClose}
                                                                    className={styles.menuList}
                                                                    slotProps={{
                                                                        paper: {
                                                                            style: {
                                                                                maxHeight: ITEM_HEIGHT * 4.5,
                                                                                width: '20ch',
                                                                            },
                                                                        },
                                                                        list: {
                                                                            'aria-labelledby': `long-button-${job.job_id}`,
                                                                        },
                                                                    }}
                                                                >
                                                                    {options.map((option) => (
                                                                        <MenuItem
                                                                            key={option.toLowerCase().replace(' ', '')}
                                                                            selected={option === 'View Loads'}
                                                                            onClick={handleOptionClick}
                                                                            data-option={option}
                                                                            data-job-id={job?.job_id}
                                                                            className={`${styles.menuItem} ${styles[option.toLowerCase().replace(' ', '')]}`}
                                                                        >
                                                                            {option}
                                                                        </MenuItem>
                                                                    ))}
                                                                </Menu>
                                                            </div>
                                                        </TableCell>
                                                    </TableRow>
                                                );
                                            })}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            {/* <AssignmentLateIcon fontSize="large" /> */}
                                            <img
                                                src="/assets/images/no_nearest_trucker.png"
                                                className={styles.noTruckerImage}
                                                alt="No nearest trucker"
                                            />
                                            <br />
                                            No live trucks found
                                        </Typography>

                                        <Typography onClick={fetchJobs} style={{ textDecoration: 'none', color: '#007A2F', fontWeight: '500', cursor: 'pointer' }}>
                                            Find Again?
                                        </Typography>
                                        {/* <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography> */}
                                    </div>
                                )}
                            </TableContainer>
                            {/* Pagination Section */}
                            {totalPages > 1 && (
                                <Box
                                    display="flex"
                                    justifyContent="center"
                                    mt={3}
                                    mb={2}
                                    className={styles.paginationContainer}
                                >
                                    <Pagination
                                        count={totalPages}
                                        page={currentPage}
                                        onChange={handlePageChange}
                                        color="primary"
                                        showFirstButton
                                        showLastButton
                                        shape="rounded"
                                        siblingCount={1}
                                        boundaryCount={1}
                                    />
                                </Box>
                            )}
                        </div>
                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default LiveTruckList;
