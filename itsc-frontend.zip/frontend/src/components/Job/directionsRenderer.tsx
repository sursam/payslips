import React, { useEffect } from 'react';
interface ChildProps {
    map: google.maps.Map | null;
    origin: google.maps.LatLngLiteral;
    destination: google.maps.LatLngLiteral;
}
const DirectionsRenderer: React.FC<ChildProps> = ({
    map,
    origin,
    destination
}) => {
    async function getRoute(
        origin: google.maps.LatLngLiteral,
        destination: google.maps.LatLngLiteral
    ): Promise<google.maps.DirectionsResult> {
        const directionsService = new google.maps.DirectionsService();
        return new Promise(function (resolve, reject) {
            directionsService.route(
                {
                    origin: origin,
                    destination: destination,
                    travelMode: google.maps.TravelMode.DRIVING,
                },
                (result: any, status: google.maps.DirectionsStatus) => {
                    if (status === google.maps.DirectionsStatus.OK) {
                        resolve(result);
                    } else {
                        reject(result);
                    }
                }
            );
        });
    }

    async function renderRoute() {
        const directions = await getRoute(origin, destination);
        const directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(map);
        directionsRenderer.setDirections(directions);
    }

    useEffect(() => {
        renderRoute().catch((err) => {
            console.log(err);
        });
    }, []);

    return null;
};
export default DirectionsRenderer;