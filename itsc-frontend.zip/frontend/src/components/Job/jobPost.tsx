import React, { useEffect, useState } from 'react';
import {
    Box,
    CardContent,
    Grid,
    Button,
    Stepper,
    Step,
    StepLabel
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import Location from './Forms/location';
import JobDescription from './Forms/jobDescription';
import JobSummary from './Forms/jobSummary';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import { api } from '../../utils/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { can } from "../../utils/helper";
import PostJobLink from '../Dashboard/parts/postJobLink';
import { shouldIReadyForJobPost, StripeInitiateProps } from '../../types';
import StripeCheckoutPage from '../Dashboard/parts/initStripe';
interface JobForm {
    jobId: any;
    pickupLocation: string;
    pickupLongitude: any;
    pickupLatitude: any;
    pickupCompanyName: string;
    pickupPointOfContact: string;
    pickupEmail: string;
    pickupContactNumber: string;
    pickupDate: string;
    pickupTime: string;
    dropoffLocation: string;
    dropoffLongitude: any;
    dropoffLatitude: any;
    dropoffCompanyName: string;
    dropoffPointOfContact: string;
    dropoffEmail: string;
    dropoffContactNumber: string;
    dropoffDate: string;
    dropoffTime: string;
    additionalNote: string;

    materialType: any;
    materialTypeId: any;
    materialName: string;
    materialOther: string;
    orderNumber: any;
    totalMillage: any;
    numberOfUnits: any;
    loadTypeId: any;
    minimumHours: any;
    maximumHours: any;
    equipmentType: any;
    equipmentTypeId: any;
    truckTypeIdsArr: any;
    truckTypeIds: string;
    loadSpacingMinutes: any;
    pricePerUnit: any;
    totalJobCost: any;
    maxLoadCapacity: any;

    loads: any;
}

interface ChildProps {
    isDraft?: number;
}

interface pastPostedJobCompanyDetails {
    pickup_company_name: string;
    dropoff_company_name: string;
    pickup_point_contract: string;
    dropoff_point_contract: string;
    pickup_point_email: string;
    dropoff_point_email: string;
    pickup_point_phone: string;
    dropoff_point_phone: string;
}

const JobPost: React.FC<ChildProps> = ({ isDraft }) => {
    const amISubContractor = typeof localStorage !== "undefined" && localStorage.getItem("isSubContractor") === "true";
    const [activeStep, setActiveStep] = React.useState(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [materialTypeList, setMaterialTypeList] = useState([]);
    const [materialTypeOtherId, setMaterialTypeOtherId] = useState('');
    const [switchChecked, setSwitchChecked] = useState(false);
    const [anyEquipment, setAnyEquipment] = useState('no');
    const [truckTypeList, setTruckTypeList] = useState([]);
    const [truckTypes, setTruckTypes] = useState([]);
    const [loadTypeList, setLoadTypeList] = useState([]);
    const [loadTypeName, setLoadTypeName] = useState('');
    const [equipmentTypeList, setEquipmentTypeList] = useState([]);
    const [equipmentTypeName, setEquipmentTypeName] = useState('');
    const [existingCompanies, setExistingCompanies] = useState([]);
    const [shouldIReadyForPostJob, setShouldIReadyForPostJob] = useState<shouldIReadyForJobPost | null>(null);
    const [stripeInitiate, setStripeInitiate] = useState<StripeInitiateProps | null>(null);
    const [openInitStripeModal, setOpenInitStripeModal] = React.useState(false);
    const [error, setError] = useState<string>('');
    const { id } = useParams();
    const location = useLocation();
    const jobNo = location.hash;
    const navigate = useNavigate();
    const stateObject = {
        jobId: id ? id : 0,
        pickupLocation: '',
        pickupLongitude: '',
        pickupLatitude: '',
        pickupCompanyName: '',
        pickupPointOfContact: '',
        pickupEmail: '',
        pickupContactNumber: '',
        pickupDate: '',
        pickupTime: '',
        dropoffLocation: '',
        dropoffLongitude: '',
        dropoffLatitude: '',
        dropoffCompanyName: '',
        dropoffPointOfContact: '',
        dropoffEmail: '',
        dropoffContactNumber: '',
        dropoffDate: '',
        dropoffTime: '',
        additionalNote: '',

        materialType: null,
        materialTypeId: '',
        materialName: '',
        materialOther: '',
        orderNumber: '',
        totalMillage: '',
        numberOfUnits: '',
        loadTypeId: '',
        minimumHours: '',
        maximumHours: '',
        equipmentType: null,
        equipmentTypeId: '',
        truckTypeIdsArr: [],
        truckTypeIds: '',
        loadSpacingMinutes: '',
        pricePerUnit: '',
        totalJobCost: '',
        maxLoadCapacity: '',
        isDraft: isDraft ? isDraft : 0,

        loads: [],
    };
    var [state, setState] = useState<JobForm>(stateObject);
    var {
        pickupLongitude,
        pickupLatitude,
        dropoffLongitude,
        dropoffLatitude,
        materialTypeId,
        numberOfUnits,
        pricePerUnit,
        totalMillage,
    } = state;

    useEffect(() => {
        getMaterialTypes();
        getloadTypes();
        getEquipmentTypes();
        getExistingCompanies();
        shouldIReadyForJobPost();
        if (id || jobNo) {
            if (!can(['edit-job'])) {
                navigate(`/dashboard`);
            }
            let payload: any = {};
            if (id) {
                payload.fieldName = 'id';
                payload.fieldValue = id;
            } else {
                payload.fieldName = 'unique_id';
                payload.fieldValue = jobNo;
            }
            fetchJobDetails(payload);
        } else {
            if (!can(['add-job'])) {
                navigate(`/dashboard`);
            }
            getTruckTypes();
            setState(stateObject);
        }
    }, [id, jobNo]);

    const fetchJobDetails = async (payload: any) => {
        setIsLoading(true);
        const response = await api.job.fetchJobDetails(payload);
        if (response?.status) {
            let jobDetails = response?.data;
            var pickupDateTime = new Date(jobDetails.pickup_date_time);
            var dropoffDateTime = new Date(jobDetails.delivery_date_time);
            var pickupDate = pickupDateTime.getFullYear() + '-' + ("0" + (pickupDateTime.getMonth() + 1)).slice(-2) + '-' + ("0" + pickupDateTime.getDate()).slice(-2);
            var pickupTime = ("0" + pickupDateTime.getHours()).slice(-2) + ':' + ("0" + pickupDateTime.getMinutes()).slice(-2);
            var dropoffDate = dropoffDateTime.getFullYear() + '-' + ("0" + (dropoffDateTime.getMonth() + 1)).slice(-2) + '-' + ("0" + dropoffDateTime.getDate()).slice(-2);
            var dropoffTime = ("0" + dropoffDateTime.getHours()).slice(-2) + ':' + ("0" + dropoffDateTime.getMinutes()).slice(-2);

            const truckTypeResponse = await api.job.getTruckTypeList();
            setTruckTypeList(truckTypeResponse.data);

            let maxLoadCapacity: any = '';
            if (truckTypeResponse.data.length) {
                let truckTypeIdsArr = jobDetails.truck_type_ids ? jobDetails.truck_type_ids.split(",").map(Number) : []
                let weightCapacities = truckTypeIdsArr.length ? truckTypeResponse.data.filter((item: any) => truckTypeIdsArr.includes(item.truck_type_id)).map((item: any) => item.weight_capacity) : [];
                let selectedTruckTypes = truckTypeIdsArr.length ? truckTypeResponse.data.filter((item: any) => truckTypeIdsArr.includes(item.truck_type_id)).map((item: any) => item) : [];
                setTruckTypes(selectedTruckTypes);
                if (weightCapacities.length) {
                    maxLoadCapacity = Math.max(...weightCapacities);
                }
            }

            if (jobDetails.equipment_id) {
                setAnyEquipment('yes');
            }
            setSwitchChecked(jobDetails.is_hourly);
            setState(prevState => ({
                ...prevState,
                jobId: !jobNo ? jobDetails.id : 0,
                pickupLocation: jobDetails.source,
                pickupLatitude: jobDetails.source_lat,
                pickupLongitude: jobDetails.source_lng,
                pickupCompanyName: jobDetails.pickup_location_company,
                pickupPointOfContact: jobDetails.pickup_contact,
                pickupEmail: jobDetails.pickup_location_email,
                pickupContactNumber: jobDetails.pickup_location_contact_no,
                pickupDate: pickupDate,
                pickupTime: pickupTime,
                dropoffLocation: jobDetails.destination,
                dropoffLatitude: jobDetails.delivery_lat,
                dropoffLongitude: jobDetails.delivery_lng,
                dropoffCompanyName: jobDetails.drop_off_location_company,
                dropoffPointOfContact: jobDetails.drop_off_contact,
                dropoffEmail: jobDetails.drop_off_location_email,
                dropoffContactNumber: jobDetails.drop_off_location_contact_no,
                dropoffDate: dropoffDate,
                dropoffTime: dropoffTime,
                additionalNote: jobDetails.notes,
                isDraft: jobDetails.is_draft,

                materialType: jobDetails.material_id ? { material_id: jobDetails.material_id, name: jobDetails.material_name } : null,
                materialTypeId: jobDetails.material_id,
                materialName: jobDetails.material_name?.toLowerCase() != 'other' ? jobDetails.material_name : jobDetails.material_other,
                materialOther: jobDetails.material_other,
                orderNumber: jobDetails.order_no,
                totalMillage: jobDetails.total_mileage,
                numberOfUnits: jobDetails.per_unit,
                loadTypeId: jobDetails.load_type_id,
                minimumHours: jobDetails.min_hours,
                maximumHours: jobDetails.max_hours,
                equipmentType: jobDetails.equipment_id ? { material_id: jobDetails.equipment_id, name: jobDetails.equipment_name } : null,
                equipmentTypeId: jobDetails.equipment_id,
                truckTypeIdsArr: jobDetails.truck_type_ids ? jobDetails.truck_type_ids.split(",") : [],
                truckTypeIds: jobDetails.truck_type_ids,
                loadSpacingMinutes: jobDetails.load_spacing_minutes,
                pricePerUnit: jobDetails.per_unit_price,
                totalJobCost: jobDetails.job_estimate_price,
                maxLoadCapacity: maxLoadCapacity,
            }));
            setIsLoading(false);
        } else {
            setIsLoading(false);
        }
    }
    const getExistingCompanies = async () => {
        setIsLoading(true);
        const response = await api.job.getExistingCompanies();
        setExistingCompanies(response.data);
        setIsLoading(false);
    }
    const handleCloseInitStripe = () => {
        setOpenInitStripeModal(false);
    }
    const handlePaymentSuccess = async () => {
        shouldIReadyForJobPost();
        localStorage.setItem("doesPaymentNeeded", "false");
        handleCloseInitStripe();
    };

    var validationObject: any;
    if (activeStep === 0) {
        validationObject = {
            pickupLocation: Yup.string().required('Pickup location is required'),
            pickupLatitude: Yup.string().required('Pickup latitude is required'),
            pickupLongitude: Yup.string().required('Pickup longitude is required'),
            pickupCompanyName: Yup.string().required('Pickup company name is required'),
            pickupPointOfContact: Yup.string().required('Pickup point of contact is required'),
            pickupEmail: Yup.string().required('Pickup email is required'),
            pickupContactNumber: Yup.string().required('Pickup contact number is required'),
            pickupDate: Yup.string().required('Pickup date is required'),
            pickupTime: Yup.string().required('Pickup time is required'),

            dropoffLocation: Yup.string().required('Dropoff location is required'),
            dropoffLatitude: Yup.string().required('Dropoff latitude is required'),
            dropoffLongitude: Yup.string().required('Dropoff longitude is required'),
            dropoffCompanyName: Yup.string().required('Dropoff company name is required'),
            dropoffPointOfContact: Yup.string().required('Dropoff point of contact is required'),
            dropoffEmail: Yup.string().required('Dropoff email is required'),
            dropoffContactNumber: Yup.string().required('Dropoff contact number is required'),
            dropoffDate: Yup.string().required('Dropoff date is required'),
            dropoffTime: Yup.string()
                .required('Dropoff time is required')
                .test(
                    'is-after-pickup',
                    'Dropoff date and time must be after pickup date and time',
                    function (value) {
                        const { pickupDate, pickupTime, dropoffDate } = this.parent;

                        if (!pickupDate || !pickupTime || !dropoffDate || !value) return true;

                        const pickupDateTime = new Date(`${pickupDate}T${pickupTime}`);
                        const dropoffDateTime = new Date(`${dropoffDate}T${value}`);

                        return dropoffDateTime > pickupDateTime;
                    }
                ),
        };
    }
    if (activeStep === 1) {
        validationObject = {
            materialTypeId: Yup.string().required('Material type is required'),
        };
        if (materialTypeId && materialTypeId == materialTypeOtherId) {
            validationObject.materialOther = Yup.string().required('Other value is required');
        }
        validationObject.orderNumber = Yup.string().required('Order number is required');
        validationObject.totalMillage = Yup.string().required('Total millage is required');
        validationObject.numberOfUnits = Yup.string().required('Number of units is required');
        validationObject.loadTypeId = Yup.string().required('Unit is required');

        if (switchChecked) {
            validationObject.minimumHours = Yup.string().required('Minimum hour is required');
            validationObject.maximumHours = Yup.string().required('Maximum hour is required');
        }
        if (anyEquipment == 'yes') {
            validationObject.equipmentTypeId = Yup.string().required('Equipment type is required');
        }
        validationObject.truckTypeIds = Yup.string().required('Truck type is required');
        validationObject.loadSpacingMinutes = Yup.string().required('Load spacing in minutes is required');
        validationObject.pricePerUnit = Yup.string().required('price per unit is required');
    }
    const validationSchema = Yup.object().shape(validationObject);
    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }
    const onSubmit = async (data: any) => {
        if (!amISubContractor && shouldIReadyForPostJob?.is_payment_needed) {
            try {
                const response = await api.stripe.initStripe();
                if (response) {
                    setStripeInitiate(response);
                    setOpenInitStripeModal(true);
                } else {
                    toast.error(response?.message || "Failed to initialize Stripe.");
                }
            } catch (error) {
                toast.error("Something went wrong while initializing payment.");
                console.error(error);
            }
        } else if (amISubContractor && shouldIReadyForPostJob?.is_payment_needed) {
            toast.error("Payment needed to post new job");
        } else {
            setIsLoading(true);
            switch (activeStep) {
                case 0:
                    const payloadLocations = {
                        step: 1,
                        is_draft: data.isDraft,
                        job_id: data.jobId,
                        source: data.pickupLocation,
                        source_lat: data.pickupLatitude,
                        source_lng: data.pickupLongitude,
                        pickup_location_company: data.pickupCompanyName,
                        pickup_contact: data.pickupPointOfContact,
                        pickup_location_email: data.pickupEmail,
                        pickup_location_contact_no: data.pickupContactNumber,
                        pickup_date_time: `${data.pickupDate} ${data.pickupTime}:00`,
                        destination: data.dropoffLocation,
                        delivery_lat: data.dropoffLatitude,
                        delivery_lng: data.dropoffLongitude,
                        drop_off_location_company: data.dropoffCompanyName,
                        drop_off_contact: data.dropoffPointOfContact,
                        drop_off_location_email: data.dropoffEmail,
                        drop_off_location_contact_no: data.dropoffContactNumber,
                        delivery_date_time: `${data.dropoffDate} ${data.dropoffTime}:00`,
                        notes: data.additionalNote,
                    }
                    const responseLocations = await api.job.postJob(payloadLocations);
                    setIsLoading(false);
                    if (responseLocations?.status) {
                        // toast.success(responseLocations?.message);
                        setState(prevState => ({
                            ...prevState,
                            jobId: responseLocations.data.job_id,
                        }));
                        setActiveStep((prevActiveStep) => prevActiveStep + 1);
                    } else {
                        toast.error(responseLocations?.message);
                    }
                    break;
                case 1:
                    const payloadJobDescription = {
                        step: 2,
                        job_id: data.jobId,
                        material_id: data.materialTypeId,
                        material_other: (data.materialTypeId && data.materialTypeId == materialTypeOtherId) ? data.materialOther : null,
                        order_no: data.orderNumber,
                        total_miles: Number(data.totalMillage),
                        total_mileage: Number(data.totalMillage),
                        per_unit: Number(data.numberOfUnits),
                        load_type_id: data.loadTypeId,
                        is_hourly: switchChecked,
                        equipment_id: (anyEquipment == 'yes') ? data.equipmentTypeId : null,
                        truck_type_ids: data.truckTypeIds,
                        no_of_trucks: data.truckTypeIdsArr.length,
                        load_spacing_minutes: data.loadSpacingMinutes,
                        per_unit_price: Number(data.pricePerUnit),
                        job_estimate_price: Number(data.totalJobCost),
                    }
                    const responseJobDescription = await api.job.postJob(payloadJobDescription);
                    setIsLoading(false);
                    if (responseJobDescription?.status) {
                        setState(prevState => ({
                            ...prevState,
                            materialOther: (data.materialTypeId && data.materialTypeId == materialTypeOtherId) ? data.materialOther : '',
                            equipmentTypeId: (anyEquipment == 'yes') ? data.equipmentTypeId : '',
                        }));
                        let loadType: any = data.loadTypeId ? loadTypeList.find((item: any) => item.load_id == data.loadTypeId) : [];
                        if (loadType) {
                            setLoadTypeName(loadType.name);
                        }
                        let equipmentType: any = (anyEquipment == 'yes' && data.equipmentTypeId) ? equipmentTypeList.find((item: any) => item.equipment_id == data.equipmentTypeId) : [];
                        if (equipmentType) {
                            setEquipmentTypeName(equipmentType.name);
                        }
                        const payloadCalculateLoad = {
                            source_lat: data.pickupLatitude,
                            min_hours: data.minimumHours,
                            truck_type_ids: data.truckTypeIds,
                            max_load_capacity: data.maxLoadCapacity,
                            per_unit: data.numberOfUnits,
                            max_hours: data.maximumHours,
                            load_type: loadType ? loadType.slug : '',
                            delivery_date_time: `${data.dropoffDate} ${data.dropoffTime}:00`,
                            job_id: data.jobId,
                            load_spacing_in_minutes: data.loadSpacingMinutes,
                            price_per_unit: data.pricePerUnit,
                            pickup_date_time: `${data.pickupDate} ${data.pickupTime}:00`,
                            is_hourly: switchChecked,
                            source_lng: data.pickupLongitude
                        }
                        const responseCalculateLoad = await api.job.calculateLoad(payloadCalculateLoad);
                        if (responseCalculateLoad) {
                            setState(prevState => ({
                                ...prevState,
                                loads: responseCalculateLoad.data,
                            }));
                            setActiveStep((prevActiveStep) => prevActiveStep + 1);
                        }
                    } else {
                        toast.error(responseJobDescription?.message);
                    }
                    break;
                case 2:
                    const payloadJobSummary = {
                        step: 3,
                        is_draft: 0,
                        job_id: data.jobId,
                        loads: data.loads,
                    }
                    const responseJobSummary = await api.job.postJob(payloadJobSummary);
                    setIsLoading(false);
                    if (responseJobSummary?.status) {
                        toast.success(responseJobSummary?.message);
                        navigate('/job-list');
                    } else {
                        toast.error(responseLocations?.message);
                    }
                    break;
            }
        }

    };

    const labels = ["Locations", "Job Description", "Summary"];
    const handleSteps = (step: number) => {
        switch (step) {
            case 0:
                return <Location
                    errors={errors}
                    register={register}
                    handleChange={handleChange}
                    handleCompanyAutoCompleteChange={handleCompanyAutoCompleteChange}
                    handleDateChange={handleDateChange}
                    setLocationData={setLocationData}
                    state={state}
                    isLoading={isLoading}
                    existingCompanies={existingCompanies}
                    onContactNumberChange={onContactNumberChange}
                />;
            case 1:
                if (!totalMillage) {
                    fetchDrivingDistance(pickupLatitude, pickupLongitude, dropoffLatitude, dropoffLongitude);
                }
                return <JobDescription
                    errors={errors}
                    register={register}
                    materialTypeList={materialTypeList}
                    materialTypeOtherId={materialTypeOtherId}
                    handleChange={handleChange}
                    handleAutoCompleteChange={handleAutoCompleteChange}
                    state={state}
                    switchChecked={switchChecked}
                    setSwitchChecked={setSwitchChecked}
                    anyEquipment={anyEquipment}
                    setAnyEquipment={setAnyEquipment}
                    truckTypeList={truckTypeList}
                    loadTypeList={loadTypeList}
                    equipmentTypeList={equipmentTypeList}
                />;
            case 2:
                return <JobSummary
                    state={state}
                    isLoading={isLoading}
                    truckTypes={truckTypes}
                    loadTypeName={loadTypeName}
                    isHourly={switchChecked}
                    anyEquipment={anyEquipment}
                    equipmentTypeName={equipmentTypeName}
                    setActiveStep={setActiveStep}
                />;
            default:
                throw new Error("Unknown step");
        }
    };

    const handleBack = () => {
        if (activeStep == 1) {
            setState(prevState => ({
                ...prevState,
                totalMillage: ''
            }));
        }
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        switch (name) {
            case 'pickupLongitude':
                if (pickupLatitude && value) {
                    fetchLocationByCoordinate('pickupLocation', pickupLatitude, value);
                }
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                break;
            case 'pickupLatitude':
                if (value && pickupLongitude) {
                    fetchLocationByCoordinate('pickupLocation', value, pickupLongitude);
                }
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                break;
            case 'dropoffLongitude':
                if (dropoffLatitude && value) {
                    fetchLocationByCoordinate('dropoffLocation', dropoffLatitude, value);
                }
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                break;
            case 'dropoffLatitude':
                if (value && dropoffLongitude) {
                    fetchLocationByCoordinate('dropoffLocation', value, dropoffLongitude);
                }
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                break;
            case 'numberOfUnits':
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                if (value && pricePerUnit) {
                    setState(prevState => ({
                        ...prevState,
                        totalJobCost: Number((Number(value) * pricePerUnit).toFixed(2))
                    }));
                } else {
                    setState(prevState => ({
                        ...prevState,
                        totalJobCost: 0
                    }));
                }
                break;
            case 'pricePerUnit':
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                if (value && numberOfUnits) {
                    setState(prevState => ({
                        ...prevState,
                        totalJobCost: (Number(value) * numberOfUnits).toFixed(2),
                    }));
                } else {
                    setState(prevState => ({
                        ...prevState,
                        totalJobCost: 0
                    }));
                }
                break;
            case 'truckTypeIdsArr':
                let weightCapacities = value ? truckTypeList.filter((item: any) => value.includes(item.truck_type_id)).map((item: any) => item.weight_capacity) : [];
                let maxLoadCapacity = weightCapacities.length ? Math.max(...weightCapacities) : '';
                let selectedTruckTypes: any = value ? truckTypeList.filter((item: any) => value.includes(item.truck_type_id)).map((item: any) => item) : [];
                setTruckTypes(selectedTruckTypes);
                let filteredValues: any = value;
                setState(prevState => ({
                    ...prevState,
                    truckTypeIds: filteredValues.join(','),
                    maxLoadCapacity: maxLoadCapacity,
                    [name]: value,
                }));
                break;
            default:
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
                break;
        }
        // trigger(name);
    };
    const handleAutoCompleteChange = (name, value) => {
        switch (name) {
            case 'materialTypeId':
                setState(prevState => ({
                    ...prevState,
                    [name]: value?.material_id,
                    materialType: value
                }));
                break;
            case 'equipmentTypeId':
                setState(prevState => ({
                    ...prevState,
                    [name]: value?.equipment_id,
                    equipmentType: value
                }));
                break;
            default:
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
        }
    }
    const handleCompanyAutoCompleteChange = (name, value, isFetch = false) => {
        setState(prevState => ({
            ...prevState,
            [name]: value,
        }));
        if (isFetch) {
            var matchedCompany = existingCompanies.find(function (company) {
                return company.title == value
            });
            switch (name) {
                case 'pickupCompanyName':
                    setState(prevState => ({
                        ...prevState,
                        pickupPointOfContact: matchedCompany?.point_of_contact,
                        pickupEmail: matchedCompany?.email,
                        pickupContactNumber: matchedCompany?.contact_no,
                    }));
                    break;
                case 'dropoffCompanyName':
                    setState(prevState => ({
                        ...prevState,
                        dropoffPointOfContact: matchedCompany?.point_of_contact,
                        dropoffEmail: matchedCompany?.email,
                        dropoffContactNumber: matchedCompany?.contact_no,
                    }));
                    break;
            }
        }
        if (!value) {
            switch (name) {
                case 'pickupCompanyName':
                    setState(prevState => ({
                        ...prevState,
                        pickupPointOfContact: '',
                        pickupEmail: '',
                        pickupContactNumber: '',
                    }));
                    break;
                case 'dropoffCompanyName':
                    setState(prevState => ({
                        ...prevState,
                        dropoffPointOfContact: '',
                        dropoffEmail: '',
                        dropoffContactNumber: '',
                    }));
                    break;
            }
        }
    }
    const onContactNumberChange = (value: any, data: any, event: any, formattedValue: any) => {
        const { name } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: formattedValue,
        }));
        // setState(prevState => ({
        //     ...prevState,
        //     mobile_number: formattedValue,
        //     country_code: data.dialCode,
        //     mobile: value.slice(data.dialCode.length),
        // }));
    };
    // const fetchLocationByCoordinate = (fieldName: string, latitude: string, longitude: string): any => {
    //     fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`)
    //         .then(response => response.json())
    //         .then(data => {
    //             toast.error(data.error_message);

    //             setState(prevState => ({
    //                 ...prevState,
    //                 [fieldName]: data.results ? data.results[0].formatted_address : '',
    //             }));
    //         });
    // }
    const fetchLocationByCoordinate = async (
        fieldName: string,
        latitude: string,
        longitude: string
    ): Promise<void> => {
        try {
            // ✅ Validate latitude and longitude
            const lat = parseFloat(latitude);
            const lng = parseFloat(longitude);

            if (
                isNaN(lat) ||
                isNaN(lng) ||
                lat < -90 ||
                lat > 90 ||
                lng < -180 ||
                lng > 180
            ) {
                toast.error("Invalid latitude or longitude.");
                return;
            }
            const response = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${GOOGLE_MAPS_API_KEY}`
            );

            const data = await response.json();
            console.log(data);

            if (data.status !== "OK") {
                toast.error(data.error_message || "Unable to fetch location data.");
                setState((prevState) => ({
                    ...prevState,
                    [fieldName]: "",
                }));
                return;
            }

            const address = data.results?.[0]?.formatted_address || "";
            setState((prevState) => ({
                ...prevState,
                [fieldName]: address,
            }));

        } catch (error) {
            console.error("Error fetching location:", error);
            toast.error("An unexpected error occurred while fetching the location.");
            setState((prevState) => ({
                ...prevState,
                [fieldName]: "",
            }));
        }
    };

    const fetchDrivingDistance = (lat1: number, long1: number, lat2: number, long2: number) => {
        const originLatLng = new google.maps.LatLng(lat1, long1);
        const destinationLatLng = new google.maps.LatLng(lat2, long2);
        var distanceService = new google.maps.DistanceMatrixService();

        distanceService.getDistanceMatrix({
            origins: [originLatLng],
            destinations: [destinationLatLng],
            travelMode: google.maps.TravelMode.DRIVING,
            unitSystem: google.maps.UnitSystem.IMPERIAL,
        },
            function (response, status) {
                if (status !== google.maps.DistanceMatrixStatus.OK) {
                } else {
                    let distanceInMeter = response?.rows[0].elements[0].distance.value;
                    const factor = 0.000621371;
                    let distanceInMiles = distanceInMeter * factor;
                    setState(prevState => ({
                        ...prevState,
                        totalMillage: distanceInMiles.toFixed(2),
                    }));
                }
            });
    }
    const handleDateChange = (e: any) => {
        setState(prevState => ({
            ...prevState,
            [e.target.name]: e.target.value
        }));
    };

    const setLocationData = (fieldName: string, locationData: any) => {
        switch (fieldName) {
            case 'pickupLocation':
                setState(prevState => ({
                    ...prevState,
                    pickupLocation: locationData.address,
                    pickupLongitude: locationData.longitude,
                    pickupLatitude: locationData.latitude
                }));
                break;
            case 'dropoffLocation':
                setState(prevState => ({
                    ...prevState,
                    dropoffLocation: locationData.address,
                    dropoffLongitude: locationData.longitude,
                    dropoffLatitude: locationData.latitude
                }));
                break;
        }

    }
    const shouldIReadyForJobPost = async () => {
        try {
            const response = await api.job.isReadyForJob();
            if (response) {
                setShouldIReadyForPostJob(response);
            } else {
                toast.error(response?.message);
            }
        } catch (e) {
            console.log("getting issue while fetching details ", e);
        }
    }

    const getMaterialTypes = async () => {
        setIsLoading(true);
        const response = await api.job.getMaterialTypeList();
        setMaterialTypeList(response.data);

        let mTypeOther = response.data ? response.data.find((mType: any) => mType.name?.toLowerCase() === 'other') : {};
        if (mTypeOther) {
            setMaterialTypeOtherId(mTypeOther.material_id);
        }
        setIsLoading(false);
    }
    const getTruckTypes = async () => {
        setIsLoading(true);
        const response = await api.job.getTruckTypeList();
        setTruckTypeList(response.data);
        setIsLoading(false);
    }
    const getloadTypes = async () => {
        setIsLoading(true);
        const response = await api.job.getLoadTypeList();
        setLoadTypeList(response.data);
        setIsLoading(false);
    }
    const getEquipmentTypes = async () => {
        setIsLoading(true);
        const response = await api.job.getEquipmentTypeList();
        setEquipmentTypeList(response.data);
        setIsLoading(false);
    }
    // const getPastPostedJobCompanyDetails = async () => {
    //     setIsLoading(true);
    //     const response = await api.job.getPastJobCompanyDetails();
    //     setPastPostedJobCompanyDetails(response);
    //     setIsLoading(false);
    // }

    return (
        <LayoutProvider pageTitle={(id || jobNo) ? "Edit Job" : "Post New Job"} backUrl="/job-list">
            <ToastContainer />
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <form className='custom-Form' encType='multipart/form-data' onSubmit={handleSubmit(onSubmit)}>
                        {activeStep === labels.length ? (
                            <></>
                        ) : (
                            <>
                                <div className={styles.cardTitle} style={{ padding: '10px 0' }}>
                                    <Stepper activeStep={activeStep} alternativeLabel>
                                        {labels.map((label) => (
                                            <Step key={label}>
                                                <StepLabel>{label}</StepLabel>
                                            </Step>
                                        ))}
                                    </Stepper>
                                </div>
                                <CardContent className={styles.gridBoxwrap}>
                                    {handleSteps(activeStep)}
                                </CardContent>
                            </>
                        )}
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '0px', justifyContent: 'center', alignItems: 'center', gap: "20px" }}>
                            {activeStep > 0 ?
                                <Button
                                    type='button'
                                    variant="contained"
                                    color="primary"
                                    onClick={handleBack}
                                    sx={{ mr: 1 }}
                                    className={styles.formButton}
                                >
                                    Previous
                                </Button>
                                : ''}
                            {/* <PostJobLink redirectTo='/post-job'> */}
                            <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.formButton}`} onClick={submitForm}>
                                {activeStep === labels.length - 1 ? (!isDraft ? 'Update Job' : 'Post Job') : 'Continue'}
                            </Button>
                            {/* </PostJobLink> */}
                        </Box>
                    </form>
                </Grid>
            </Grid>
            <StripeCheckoutPage
                initiatePaymentData={stripeInitiate}
                open={openInitStripeModal}
                onClose={handleCloseInitStripe}
                onPaymentSuccess={handlePaymentSuccess}
            />
        </LayoutProvider>
    );
};

export default JobPost;
