import React, { useState, useEffect } from 'react';
import { Box, TextField, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination, Button, Modal, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Autocomplete, Typography, Chip, Stack, Pagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CloseIcon from '@mui/icons-material/Close';
import styles from '../../styles/raceresult.module.css';
import { EditableRace, NewRace, useRace } from '../../context/RaceContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';

const ResultList: React.FC = () => {
	const [isSidebarOpen, setSidebarOpen] = useState(true);
	const [searchQuery, setSearchQuery] = useState('');
	const [formErrors, setFormErrors] = useState<{ description?: string; link?: string; points?: string; dogId?: string; raceId?: string }>({});

	const [openModal, setOpenModal] = useState(false);
	const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
	const [selectedDogId, setSelectedDogId] = useState<string | null>(null);
	const [selectedDogObj, setSelectedDogObj] = useState<any | null>(null);
	const [selectedRaceObj, setSelectedRaceObj] = useState<any | null>(null);
	const [errors, setErrors] = useState<any>({});
	const [dogList, setDogList] = useState<any[]>([]);
	const [race, setRaces] = useState<any[]>([]);
	const [raceList, setRaceList] = useState<any[]>([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [selectedRace, setSelectedRace] = useState<EditableRace | null>(null);
	interface Batch {
		filename: string;
		path: string;
		size: number;
	}
	interface Winner {
		position: number;
		dog_object_id: { _id: string } | string | null; // Ensuring it can be an object with `_id`, `string`, or `null`
		box_number: number | null;
		race_completion_time: string | null;
		mgn: number | null;
		split: number | null;
		in_run: number | null;
		weight: number | null;
		dog_price: string | null;
	}



	interface Round {
		time: string;
		race_round_no: number; // Ensure this is a number
		winners: Winner[];
	}

	interface Dog {
		_id: string;
		dog_id: string;
		dog_name: string;
		// Add other properties as needed
	}

	interface RaceObject {
		_id: string;
		race_name: string;
		location: string;
		race_date: string;
		race_time: string;
		grade: string;
		dogs: Dog[];
	}
	interface Race {
		_id: string;
		race_object_id: RaceObject; // Ensure this line is present
		race_date: string;
		grade: string;
		round: Round[];
	}

	const [raceData, setRaceData] = useState<NewRace>({
		race_object_id: '',
		race_date: '',
		grade: '',
		round: [{ time: '', race_round_no: '', winners: [] }],
	});

	const navigate = useNavigate();

	const { races, fetchRaces, addRace, deleteRace, fetchRaceById, updateRace } = useRace();
	const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
	const userRole = userDetails.userRole;

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	useEffect(() => {
		fetchRaces();
	}, [fetchRaces]);

	const handlePageChange = (event: unknown, newPage: number) => {
		setPage(newPage - 1); // Convert to 0-based index
	};


	const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		setRowsPerPage(parseInt(event.target.value, 10));
		setPage(0);
	};

	const handleEditClick = async (id: string) => {
		console.log("Edit Clicked", id);
		try {
			const race = await fetchRaceById(id);
			console.log("Fetched race", race);
			if (race) {
				const editableRace: EditableRace = {
					_id: race._id,
					race_object_id: race.race_object_id._id,
					race_date: race.race_date || '',
					grade: race.grade || '',
					round: Array.isArray(race.round) ? race.round : [{ time: '', race_round_no: 0, winners: [] }],
				};
				console.log('editableRace', editableRace);
				setRaceData(editableRace);
				setSelectedRace(editableRace);
				setSelectedRaceObj({
					_id: race.race_object_id._id,
					race_name: race.race_object_id.race_name,
					race_date: race.race_object_id.race_date,
					grade: race.grade,
				});

				// Populate dogList based on the fetched race data
				const dogs = race.race_object_id.dogs.map((dog: any) => ({
					_id: dog.dog_object_id._id,
					dog_id: dog.dog_object_id.dog_id,
					dog_name: dog.dog_object_id.dog_name,
				}));
				setDogList(dogs);
				console.log('dogs', dogs);
				setSelectedDogObj(dogs);
				console.log(selectedDogObj)

				// Set winners' dog_object_id in the round data
				const updatedRounds = editableRace.round.map((round) => ({
					...round,
					winners: round.winners.map((winner) => ({
						...winner,
						dog_object_id: typeof winner.dog_object_id === 'object' && winner.dog_object_id !== null
							? winner.dog_object_id._id
							: null,
					})),
				}));
				console.log('updatedRounds', updatedRounds);
				setRaceData((prev) => ({ ...prev, round: updatedRounds }));

				setOpenModal(true);
			} else {
				toast.error('Race not found');
			}
		} catch (error) {
			toast.error('Failed to load race data');
			console.error(error);
		}
	};





	const handleOpenAddModal = () => {
		setOpenModal(true);
		setSelectedRace(null);
		setRaceData({
			race_object_id: '',
			race_date: '',
			grade: '',
			round: [{ time: '', race_round_no: '', winners: [] }],
			dogs: [],
		});
	};

	const handleAddRound = () => {
		setRaceData({
			...raceData,
			round: [...raceData.round, { time: '', race_round_no: '', winners: [] }],
		});
	};

	const handleDeleteRound = (roundIndex: number) => {
		const newRounds = [...raceData.round];
		newRounds.splice(roundIndex, 1);
		setRaceData({ ...raceData, round: newRounds });
	};

	const handleAddWinner = (roundIndex: number) => {
		setRaceData((prevRaceData) => {
			const newRounds = prevRaceData.round.map((round, idx) => {
				if (idx === roundIndex) {
					return {
						...round,
						winners: [
							...round.winners,
							{
								position: null,
								race_completion_time: null,
								mgn: null,
								split: null,
								in_run: null,
								weight: null,
								dog_price: null,
								dog_object_id: null,
								box_number: null,
							},
						],
					};
				}
				return round;
			});
			return { ...prevRaceData, round: newRounds };
		});
	};



	const handleDeleteWinner = (roundIndex: number, winnerIndex: number) => {
		const newRounds = [...raceData.round];
		newRounds[roundIndex].winners.splice(winnerIndex, 1);
		setRaceData({ ...raceData, round: newRounds });
	};

	const handleAddRace = async () => {
		const formattedRaceDate = raceData.race_date.split('T')[0];

		const payload: NewRace = {
			race_object_id: raceData.race_object_id.trim(),
			race_date: formattedRaceDate,
			grade: raceData.grade.trim(),
			round: raceData.round?.map((round) => ({
				time: round.time.trim(),
				race_round_no: String(round.race_round_no),
				winners: round.winners?.map((winner) => ({
					box_number: winner.box_number ? String(winner.box_number) : winner.box_number,
					dog_object_id: winner.dog_object_id || null,
					dog_price: winner.dog_price ? String(winner.dog_price) : null,
					in_run: winner.in_run ? String(winner.in_run) : null,
					mgn: winner.mgn ? String(winner.mgn) : null,
					position: String(winner.position), // Ensure position is a string
					race_completion_time: winner.race_completion_time ? String(winner.race_completion_time) : null,
					split: winner.split ? String(winner.split) : null,
					weight: winner.weight ? String(winner.weight) : null,
				})),
			})) || [],
			dogs: undefined
		};

		try {
			let response;
			if (selectedRace && selectedRace._id) {
				response = await updateRace(selectedRace._id, payload);
			} else {
				response = await addRace(payload);
			}

			if (response && typeof response === "object") {
				if ("message" in response && !("err" in response)) {
					toast.success(response.message);
					handleCloseModal();
					fetchRaceList();
				} else if ("err" in response && Array.isArray(response.err?.details)) {
					response.err.details.forEach((detail: any) => {
						toast.error(detail.message);
					});
				} else {
					toast.error("Unexpected error occurred while adding/updating the race.");
				}
			} else {
				toast.error("Invalid API response received.");
			}
		} catch (error: any) {
			if (error?.err?.details?.length) {
				error.err.details.forEach((detail: any) => {
					toast.error(detail.message);
				});
			} else {
				toast.error(error?.message || "Error adding/updating race.");
			}
			console.error("Error:", error);
		}
	};





	const handleCloseModal = () => {
		setOpenModal(false);
		setErrors({});
		setSelectedRace(null);
	};

	const handleDeleteRace = async (id: string) => {
		try {
			await deleteRace(id);
			toast.success('Race deleted successfully!!!!!!!');
			setOpenDeleteDialog(false); // Close the dialog after deletion
			// Optionally, refetch the race list to update the UI
			const updatedRaceList = raceList.filter(race => race._id !== id);
			setRaceList(updatedRaceList);
		} catch (error) {
			console.error('Error deleting race:', error);
			toast.error('Failed to delete race');
		}
	};

	const handleDogChange = (roundIndex: number, winnerIndex: number) => (event: any, newValue: any) => {
		setRaceData((prevRaceData) => {
			const newRounds = [...prevRaceData.round];
			newRounds[roundIndex].winners[winnerIndex].dog_object_id = newValue ? newValue.dog_id : null;
			return { ...prevRaceData, round: newRounds };
		});
	};

	const handleRaceChange = async (event: any, newValue: any) => {
		console.log("Race Change", newValue);
		setSelectedRaceObj(newValue || null);
		if (newValue) {
			try {
				const response = await api.reward.getRaceWiseDogList(`${newValue._id}`);
				const dogs = response?.result.map((dog: any) => ({
					_id: dog._id,
					dog_id: dog.dog_object_id._id,
					dog_no: dog.dog_object_id.dog_id,
					dog_name: dog.dog_object_id.dog_name,
				})) || [];
				setDogList(dogs);
				setRaceData((prevRaceData) => ({
					...prevRaceData,
					grade: newValue.grade || '',
					race_date: newValue.race_date || '',
					race_object_id: newValue._id || '',
				}));
			} catch {
				setDogList([]);
			}
		} else {
			setDogList([]);
		}
	};

	useEffect(() => {
		const fetchRaces = async () => {
			try {
				const response = await api.race.getRaceList();
				setRaces(response?.result || []);
			} catch (error) {
				console.error("Error fetching race list:", error);
			}
		};
		fetchRaces();
	}, []);

	const fetchRaceList = async () => {
		try {
			const raceData = await fetchRaces();
			if (raceData && Array.isArray(raceData)) {
				setRaceList(raceData);
			} else {
				console.error("Unexpected race data format:", raceData);
				setRaceList([]);
			}
		} catch (error) {
			console.error("Error fetching race list:", error);
			setRaceList([]); // Ensure the state is set to an empty array on error
		}
	};

	useEffect(() => {
		fetchRaceList();
	}, []);

	const filteredRaceList = raceList.filter((race) => {
		const raceName = race.race_object_id?.race_name.toLowerCase() || '';
		const raceLocation = race.race_object_id?.location.toLowerCase() || '';
		const raceDate = new Date(race.race_object_id?.race_date).toLocaleDateString('en-GB') || '';

		return (
			raceName.includes(searchQuery.toLowerCase()) ||
			raceLocation.includes(searchQuery.toLowerCase()) ||
			raceDate.includes(searchQuery.toLowerCase())
		);
	});



	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Result List</h3>
					<div className={styles.headerRtSide}>
						<TextField
							variant="outlined"
							placeholder="Search Result"
							onChange={(e) => setSearchQuery(e.target.value)}
							size="small"
							sx={{ marginRight: 2 }}
						/>

						{userRole !== 'MEMBER' && (
							<Button variant="contained" onClick={handleOpenAddModal}>
								Add Result
							</Button>
						)}
					</div>
				</div>

				<div className={styles.customtable}>
					<TableContainer className={styles.tableContainer}>
						<Table className={styles.table}>
							<TableHead>
								<TableRow>
									<TableCell className={styles.stickyColumn}>Venue</TableCell>
									{raceList.length > 0 && raceList[0].round ? (
										raceList[0].round.map((round: any, index: number) => (
											<TableCell key={index}>Race {round.race_round_no}</TableCell>
										))
									) : (
										<TableCell>No Races Available</TableCell>
									)}
								</TableRow>
							</TableHead>
							<TableBody>
								{filteredRaceList.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((race: any, index: number) => (
									<TableRow key={index}>
										<TableCell style={{ padding: '12px' }}>
											<div
												style={{
													display: 'flex',
													flexDirection: 'column',
													alignItems: 'flex-start',
													gap: '6px',
													width: '100%',
												}}
											>
												<Tooltip title="Venue">
													<strong
														style={{ fontSize: '16px', fontWeight: 'bold', color: '#1976d2', cursor: 'pointer' }}
														onClick={() => navigate(`/resultdetails/${race?._id}`)}
													>
														{/* onClick={userRole !== 'MEMBER' ? () => navigate(`/resultdetails/${race?._id}`) : undefined} */}
														{/* cursor: userRole !== 'MEMBER' ? 'pointer' : 'default' */}
														{race.race_object_id?.race_name || "Unknown Venue"}
													</strong>
												</Tooltip>
												<small
													style={{
														fontSize: '14px',
														color: '#555',
														display: 'flex',
														alignItems: 'center',
														gap: '8px',
													}}
												>
													{new Date(race.race_object_id?.race_date).toLocaleDateString('en-GB', {
														day: 'numeric',
														month: 'short',
														year: 'numeric',
													})} | {race.race_object_id?.race_time} |
													<Tooltip title="Grade">
														<span style={{ fontWeight: 'bold', color: '#ff9800' }}>{race.race_object_id?.grade}</span>
													</Tooltip>
												</small>
												{userRole !== 'MEMBER' && (
													<div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
														<Tooltip title="Delete Result" >
															<IconButton
																color="error"
																onClick={() => {
																	setSelectedDogId(race._id);
																	setOpenDeleteDialog(true);
																}}
															>
																<DeleteIcon />
															</IconButton>
														</Tooltip>

														<Tooltip title="Edit Result">
															<IconButton
																color="primary"
																onClick={() => {
																	if (race._id) {
																		handleEditClick(race._id);
																	}
																}}
															>
																<EditIcon />
															</IconButton>
														</Tooltip>
													</div>
												)}
											</div>
										</TableCell>

										{race.round.map((round: any, roundIndex: number) => (
											<TableCell key={roundIndex}>
												<span className="winner">Winners for {round.time}</span>
												<div className="dog-icons">
													{round.winners.length > 0 ? (
														round.winners.map((winner: any, j: number) => (
															<span key={j} style={{ marginRight: '8px' }} className="dog-icon">
																{winner.dog_object_id?.dog_name || "No Winner"}
															</span>
														))
													) : (
														<span>No Winners Available</span>
													)}
												</div>
											</TableCell>
										))}
									</TableRow>
								))}
							</TableBody>
						</Table>
					</TableContainer>

					<Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
						<Pagination
							count={Math.ceil(raceList.length / rowsPerPage)} // Calculate total pages
							page={page + 1} // MUI Pagination is 1-based
							onChange={handlePageChange}
							color="primary"
						/>
					</Stack>
				</div>
			</Box>

			<Modal open={openModal} onClose={handleCloseModal}>
				<Box
					className={styles.modalBox}
					sx={{
						position: 'absolute',
						top: '50%',
						right: '0px',
						transform: 'translateY(-50%)',
						padding: 2,
						backgroundColor: 'white',
						borderRadius: 2,
						height: '100%',
						maxWidth: '60%',
						overflowY: 'auto'
					}}
				>
					<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
						<h2>{selectedRace ? 'Edit Result' : 'Add Result'}</h2>
						<IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
							<CloseIcon />
						</IconButton>
					</Box>

					<Box sx={{ display: 'flex', gap: 2, marginTop: 3, }}>
						<Box sx={{ flex: 1 }}>
							<Autocomplete
								options={race}
								getOptionLabel={(option) => option.race_name}
								value={selectedRaceObj} // This should be set correctly
								onChange={handleRaceChange}
								renderInput={(params) => (
									<TextField
										{...params}
										label="Select Race"
										error={Boolean(formErrors.raceId)}
										helperText={formErrors.raceId}
										required
										fullWidth
									/>
								)}
								renderOption={(props, option) => (
									<li {...props}>
										<Box display="flex" alignItems="center">
											<Typography variant="body1">{option.race_name}</Typography>
											<Chip
												label={new Date(option.race_date).toLocaleDateString()}
												size="small"
												color="success"
												sx={{ marginLeft: 1 }}
											/>
										</Box>
									</li>
								)}
							/>
						</Box>


					</Box>


					<Box
						sx={{
							display: 'flex',
							flexWrap: 'wrap',
							gap: 2,
							marginBottom: 3,
							marginTop: 2,
							padding: 0,
						}}
					>
						<TextField
							label="Race Date"
							type="date"
							variant="outlined"
							fullWidth
							value={raceData.race_date ? new Date(raceData.race_date).toISOString().split('T')[0] : ''}
							onChange={(e) => setRaceData({ ...raceData, race_date: e.target.value })}
							sx={{ flex: '1 1 45%' }}
							InputLabelProps={{
								shrink: true,
							}}
							disabled
							error={Boolean(errors.raceDate)}
							helperText={errors.raceDate}
							required
						/>


						<TextField
							label="Grade"
							variant="outlined"
							fullWidth
							value={raceData.grade}
							onChange={(e) => setRaceData({ ...raceData, grade: e.target.value })}
							sx={{ flex: '1 1 45%' }}
							disabled
							error={Boolean(errors.grade)}
							helperText={errors.grade}
							required
						/>
					</Box>

					<Button
						variant="contained"
						onClick={handleAddRound}
						sx={{ marginBottom: 2 }}
					>
						Add Round
					</Button>

					{Array.isArray(raceData.round) && raceData.round.length > 0 ? (
						raceData.round.map((round, roundIndex) => (
							<Box key={roundIndex} sx={{ marginBottom: 3, border: '1px solid #ddd', padding: 2, borderRadius: 2 }}>
								<TextField
									label={`Round ${roundIndex + 1} Time`}
									type="time"
									fullWidth
									value={round.time || ''}
									onChange={(e) => {
										const newRounds = [...raceData.round];
										newRounds[roundIndex].time = e.target.value;
										setRaceData({ ...raceData, round: newRounds });
									}}
									InputLabelProps={{ shrink: true }}
									sx={{ marginBottom: 2 }}
								/>

								<Box sx={{ flex: 1 }}>
									<TextField
										label="Round Number"
										variant="outlined"
										fullWidth
										value={round.race_round_no}
										onChange={(e) => {
											const newRounds = [...raceData.round];
											newRounds[roundIndex].race_round_no = parseInt(e.target.value, 10) || 0;
											setRaceData({ ...raceData, round: newRounds });
										}}
										error={Boolean(errors.title)}
										helperText={errors.title}
										required
									/>
								</Box>

								<Button variant="outlined" onClick={() => handleAddWinner(roundIndex)} sx={{ marginBottom: 2 }}>
									Add Winner
								</Button>

								{Array.isArray(round.winners) && round.winners.length > 0 ? (
									round.winners.map((winner, winnerIndex) => (
										<Box
											key={`winner-${roundIndex}-${winnerIndex}`}
											sx={{
												display: 'flex',
												flexWrap: 'wrap',
												gap: 2,
												marginBottom: 3,
												border: '1px solid #ddd',
												padding: 2,
												borderRadius: 2
											}}
										>
											<Box sx={{ width: '100%' }}>
												<Autocomplete
													options={dogList}
													getOptionLabel={(option) => option.dog_name}
													value={dogList.find(dog => dog._id === winner.dog_object_id) || null}
													onChange={handleDogChange(roundIndex, winnerIndex)}
													renderInput={(params) => (
														<TextField
															{...params}
															label={`Select Dog ${winnerIndex + 1}`}
															error={!!formErrors.dogId}
															helperText={formErrors.dogId}
															required
															sx={{ mb: 2, flex: '1 1 45%' }}
														/>
													)}
													renderOption={(props, option) => (
														<li {...props}>
															<Box display="flex" alignItems="center">
																<Typography variant="body1">{option.dog_name}</Typography>
																<Chip label={option.dog_id} size="small" sx={{ marginLeft: 1 }} color="success" />
															</Box>
														</li>
													)}
												/>




											</Box>

											<TextField
												label="Position"
												fullWidth
												type="number"
												value={winner.position}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													newRounds[roundIndex].winners[winnerIndex].position = parseInt(e.target.value, 10) || 0;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>

											{/* <TextField
												label="Name"
												fullWidth
												value={winner.name}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													newRounds[roundIndex].winners[winnerIndex].name = e.target.value;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/> */}
											{/* <TextField
												label="Trainer"
												fullWidth
												value={winner.trainer}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													newRounds[roundIndex].winners[winnerIndex].trainer = e.target.value;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/> */}
											<TextField
												label="Race Completion Time"
												fullWidth
												value={winner.race_completion_time?.toString() || ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value;
													newRounds[roundIndex].winners[winnerIndex].race_completion_time = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="Mgn"
												fullWidth
												value={winner.mgn ?? ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : null;
													newRounds[roundIndex].winners[winnerIndex].mgn = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="Split"
												fullWidth
												value={winner?.split ?? ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : null;
													newRounds[roundIndex].winners[winnerIndex].split = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="In Run"
												fullWidth
												value={winner.in_run ?? ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : null;
													newRounds[roundIndex].winners[winnerIndex].in_run = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="Weight"
												fullWidth
												value={winner.weight ?? ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : null;
													newRounds[roundIndex].winners[winnerIndex].weight = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="Dog Price"
												fullWidth
												value={winner.dog_price ?? ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : null;
													newRounds[roundIndex].winners[winnerIndex].dog_price = val;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											{/* <TextField
												label="Batch FileName"
												fullWidth
												value={winner.batch.filename}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													newRounds[roundIndex].winners[winnerIndex].batch.filename = e.target.value;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/>
											<TextField
												label="Batch Path"
												fullWidth
												value={winner.batch.path}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													newRounds[roundIndex].winners[winnerIndex].batch.path = e.target.value;
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 45%' }}
											/> */}
											<TextField
												label="Box Number"
												fullWidth
												value={winner.box_number !== undefined ? winner.box_number : ''}
												onChange={(e) => {
													const newRounds = [...raceData.round];
													const val = e.target.value ? parseFloat(e.target.value) : 0;
													newRounds[roundIndex].winners[winnerIndex].box_number = val; // Ensure box_number is a number
													setRaceData({ ...raceData, round: newRounds });
												}}
												sx={{ flex: '1 1 35%' }}
											/>

											<Tooltip title="Delete Winner">
												<IconButton onClick={() => handleDeleteWinner(roundIndex, winnerIndex)} color="error" aria-label="delete">
													<DeleteIcon />
												</IconButton>
											</Tooltip>
										</Box>
									))
								) : (
									<Box>No winners added yet</Box>
								)}
								<Tooltip title="Delete Round">
									<Button
										variant="outlined"
										color="error"
										onClick={() => handleDeleteRound(roundIndex)}
									>
										Delete Round
									</Button>
								</Tooltip>
							</Box>
						))
					) : (
						<Box>No rounds added yet</Box>
					)}

					<Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end' }}>
						<Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>
							Close
						</Button>
						<Button variant="contained" onClick={handleAddRace}>
							Save Changes
						</Button>
					</Box>
				</Box>
			</Modal>

			<Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
				<DialogTitle>Confirm Delete</DialogTitle>
				<DialogContent>
					<DialogContentText>
						Are you sure you want to delete this Race?
					</DialogContentText>
				</DialogContent>
				<DialogActions>
					<Button onClick={() => setOpenDeleteDialog(false)} color="primary">Cancel</Button>
					<Button
						onClick={async () => {
							if (selectedDogId) {
								await handleDeleteRace(selectedDogId);
							}
							setOpenDeleteDialog(false);
						}}
						color="secondary"
					>
						Delete
					</Button>
				</DialogActions>
			</Dialog>

		</Box>
	);
};

export default ResultList;
