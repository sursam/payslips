import React, { useState, useEffect } from 'react';
import { Box, TextField, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination, Button, Modal, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, MenuItem, Stack, Pagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CloseIcon from '@mui/icons-material/Close';
import styles from '../../styles/raceresult.module.css';
import { EditableRace, NewRace, useRace } from '../../context/RaceContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useDog } from '../../context/DogContext';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';
import { RacePayload } from '../../utils/api/race/raceList';

const RaceList: React.FC = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [openModal, setOpenModal] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [selectedDogId, setSelectedDogId] = useState<string | null>(null);
  const [errors, setErrors] = useState<any>({});
  const [page, setPage] = useState(0);
  const [dogList, setDogList] = useState<any[]>([]);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedRace, setSelectedRace] = useState<string | null>(null);
  const [races, setRaces] = useState<Array<{ _id: string; race_name: string; location: string; race_date: string; race_time: string; country: string; grade: string }>>([]);

  const { adminDogList } = useDog();

  const [raceData, setRaceData] = useState<RacePayload>({
    race_name: '',
    type: 0,
    location: '',
    race_date: '',
    race_time: '',
    country: '',
    country_image: undefined,
    grade: '',
    title: 'Default Title', // Added the missing title property
    dogs: [] as Array<{
      rug_number: string;
      dog_object_id: string;
      box_number: string;
      rug_image?: string; // Change from File | null to string
    }>,
  });



  const raceTypes = Array.from({ length: 12 }, (_, i) => ({
    value: `${i + 1}`,
    label: `${i + 1}`,
  }));

  const countries = [
    { value: 'Australia', label: 'Australia' },
    { value: 'USA', label: 'USA' },
    { value: 'UK', label: 'UK' },
    { value: 'India', label: 'India' },
  ];

  const navigate = useNavigate();

  const { addRace, deleteRace, updateRace } = useRace();
  const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
  const userRole = userDetails.userRole;

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handlePageChange = (event: unknown, newPage: number) => {
    setPage(newPage - 1); // Convert to 0-based index
  };


  const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDogFileChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const updatedDogs = [...raceData.dogs];
    fileToBase64(file).then((base64) => {
      updatedDogs[index].rug_image = base64;
      setRaceData({ ...raceData, dogs: updatedDogs });
    }).catch((error) => {
      console.error("Error converting file to Base64:", error);
    });
    setRaceData({ ...raceData, dogs: updatedDogs });
  };

  const handleCountryImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    fileToBase64(file).then((base64) => {
      setRaceData({ ...raceData, country_image: base64 });
    }).catch((error) => {
      console.error("Error converting file to Base64:", error);
    });
  };

  const handleOpenAddModal = () => {
    const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
    const currentTime = new Date().toTimeString().split(' ')[0].substring(0, 5); // Get current time in HH:MM format
    setOpenModal(true);
    setSelectedRace(null); // Reset selected race for adding a new race
    setRaceData({
      race_name: '',
      location: '',
      race_date: today, // Set today's date as the default
      grade: '',
      type: 0,
      country: '',
      country_image: undefined, // This can remain as undefined
      race_time: currentTime, // Set current time as the default
      title: 'Default Title', // Add a default value for title
      dogs: [{
        rug_number: '',
        dog_object_id: '',
        box_number: '', // Ensure box_number is always a string
        rug_image: undefined, // Change null to undefined
      }],
    });
  };

  const handleAddDog = () => {
    setRaceData({
      ...raceData,
      dogs: [
        ...raceData.dogs,
        {
          rug_number: '',
          dog_object_id: '',
          box_number: '', // Ensure box_number is always a string
          rug_image: undefined, // Change null to undefined
        },
      ],
    });
  };

  const handleOpenEditModal = async (id: string) => {
    setOpenModal(true);
    setSelectedRace(id); // Set the selected race ID (string)
    try {
      const response = await api.race.fetchRaceById(id); // Fetch race data by ID
      console.log("response_fetchRaceById", response);
      if (response?.result) {
        const race = response.result; // Access the race object directly
        setRaceData({
          race_name: race.race_name,
          type: race.type || 0, // Ensure type is included
          location: race.location,
          race_date: race.race_date.split('T')[0], // Format date to YYYY-MM-DD
          race_time: race.race_time,
          country: race.country,
          country_image: race.country_image,
          grade: race.grade,
          title: race.title || 'Default Title', // Ensure title is included
          dogs: race.dogs.map((dog: { rug_number: string; dog_object_id: string; box_number: string; rug_image?: string }) => ({
            rug_number: dog.rug_number,
            dog_object_id: dog.dog_object_id,
            box_number: dog.box_number,
            rug_image: dog.rug_image,
          })),
        });
      }
    } catch (error) {
      console.error("Error fetching race data:", error);
      toast.error("Failed to load race data.");
    }
  };

  const handleDeleteDog = (dogIndex: number) => {
    const newDogs = [...raceData.dogs];
    newDogs.splice(dogIndex, 1);
    setRaceData({ ...raceData, dogs: newDogs });
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };


  const handleAddRace = async () => {
    let newErrors: Record<string, string> = {};

    if (!raceData.race_name.trim()) newErrors.race_name = "Race Name is required";
    if (!raceData.location.trim()) newErrors.location = "Location is required";
    if (!raceData.race_date.trim()) newErrors.race_date = "Race Date is required";
    if (!raceData.grade.trim()) newErrors.grade = "Grade is required";
    if (!raceData.country.trim()) newErrors.country = "Country is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const formattedRaceDate = raceData.race_date.includes("T") ? raceData.race_date.split("T")[0] : raceData.race_date;

      let countryImageBase64 = "";
      if (raceData.country_image && typeof raceData.country_image !== 'string') {
        countryImageBase64 = await fileToBase64(raceData.country_image);
      }

      const dogsPayload = await Promise.all(
        raceData.dogs.map(async (dog) => {
          let rugImageBase64 = "";
          if (dog.rug_image && typeof dog.rug_image !== 'string') {
            rugImageBase64 = await fileToBase64(dog.rug_image);
          }
          return {
            rug_number: dog.rug_number,
            box_number: dog.box_number,
            dog_object_id: dog.dog_object_id,
            rug_image: rugImageBase64,
          };
        })
      );

      const payload = {
        race_name: raceData.race_name.trim(),
        type: raceData.type,
        location: raceData.location.trim(),
        race_date: formattedRaceDate,
        race_time: raceData.race_time ?? "",
        country: raceData.country.trim(),
        country_image: countryImageBase64,
        grade: raceData.grade.trim(),
        dogs: dogsPayload,
        title: raceData.title?.trim() || "Default Title",
        raceDate: formattedRaceDate,
        round: [],
      };



      let response;
      if (selectedRace) {
        response = await api.race.updateRace(selectedRace, payload);
        toast.success(response?.message);
      } else {
        response = await api.race.addRace(payload);
        toast.success(response?.message);
      }

      if (response) {
        fetchRaces();
        handleCloseModal();
      }
    } catch (error: any) {
      console.error("Error:", error);

      if (error?.response?.data?.details?.length) {
        error.response.data.details.forEach((detail: any) => {
          toast.error(detail.message);
        });
      } else {
        toast.error(error?.message || "Error adding/updating race.");
      }
    }
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setErrors({});
    setSelectedRace(null);
  };

  const handleDeleteRace = async (id: string) => {
    try {
      await api.race.deleteRace(id);
      toast.success('Race deleted successfully!');
      fetchRaces();
    } catch (error) {
      console.error('Error deleting race:', error);
    }
  };

  const fetchRaces = async () => {
    try {
      const response = await api.race.getRaceList();
      console.log("response", response);
      if (response?.result) {
        setRaces(response.result);
      }
    } catch (error) {
      console.error("Error fetching race list:", error);
    }
  };

  useEffect(() => {
    fetchRaces();
  }, []);

  const filteredRaces = races.filter((race) => {
    const searchQueryLower = searchQuery.toLowerCase();
    return (
      race.location.toLowerCase().includes(searchQueryLower) ||
      race.country.toLowerCase().includes(searchQueryLower) ||
      race.grade.toLowerCase().includes(searchQueryLower) ||
      new Date(race.race_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }).toLowerCase().includes(searchQueryLower) ||
      race.race_time.toLowerCase().includes(searchQueryLower)
    );
  });

  useEffect(() => {
    const fetchDogList = async () => {
      const dogs = await adminDogList();
      setDogList(dogs);
    };
    fetchDogList();
  }, [adminDogList]);

  return (
    <Box className={styles.container}>
      <Sidebar isOpen={isSidebarOpen} />
      <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
        <div className={styles.topsection}>
          <h3>Race List</h3>
          <div className={styles.headerRtSide}>
            <TextField
              variant="outlined"
              placeholder="Search Race"
              onChange={handleSearch}
              size="small"
              sx={{ marginRight: 2 }}
              value={searchQuery}
            />
            {userRole !== 'MEMBER' && (
              <Button variant="contained" onClick={handleOpenAddModal}>
                Add Race
              </Button>
            )}
          </div>
        </div>

        <div className={styles.customtable}>
          <TableContainer className={styles.tableContainer}>
            <Table className={`${styles.table} table`}>
              <TableHead>
                <TableRow>
                  <TableCell className={styles.stickyColumn}>Race Name</TableCell>
                  <TableCell className={styles.stickyColumn}>Venue</TableCell>
                  <TableCell className={styles.stickyColumn}>Date & Time</TableCell>
                  <TableCell className={styles.stickyColumn}>Country</TableCell>
                  <TableCell className={styles.stickyColumn}>Grade</TableCell>
                  {userRole !== 'MEMBER' && (
                    <TableCell className={styles.stickyColumn}>Actions</TableCell>
                  )}
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredRaces
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((race) => (
                    <TableRow key={race._id}>
                      <TableCell>{race.race_name}</TableCell>
                      <TableCell>{race.location}</TableCell>
                      <TableCell>
                        {new Date(race.race_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })} <br />
                        {race.race_time}
                      </TableCell>
                      <TableCell>{race.country}</TableCell>
                      <TableCell>{race.grade}</TableCell>
                      {userRole !== 'MEMBER' && (
                        <TableCell>
                          <Tooltip title="Edit Race">
                            <IconButton
                              className={styles.roundBtn}
                              sx={{ color: 'blue', borderColor: 'blue', width: '30px !important', height: '20px !important' }}
                              onClick={() => handleOpenEditModal(race._id)}
                            >
                              <EditIcon />
                            </IconButton>
                          </Tooltip>

                          <Tooltip title="Delete Race">
                            <IconButton
                              className={styles.roundBtn}
                              sx={{ color: 'red', borderColor: 'red' }}
                              onClick={() => {
                                setSelectedDogId(race._id);
                                setOpenDeleteDialog(true);
                              }}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
              </TableBody>

            </Table>
          </TableContainer>

          <Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
            <Pagination
              count={Math.ceil(filteredRaces.length / rowsPerPage)} // Calculate total pages
              page={page + 1} // MUI Pagination is 1-based
              onChange={handlePageChange}
              color="primary"
            />
          </Stack>

        </div>
      </Box>

      <Modal open={openModal} onClose={handleCloseModal}>
        <Box
          className={styles.modalBox}
          sx={{
            position: 'absolute',
            top: '50%',
            right: '0px',
            transform: 'translateY(-50%)',
            padding: 2,
            backgroundColor: 'white',
            borderRadius: 2,
            overflowY: 'auto'
          }}
        >
          {/* Close Button on Top Right */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2>{selectedRace ? 'Edit Race' : 'Add Race'}</h2>
            <IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
              <CloseIcon />
            </IconButton>
          </Box>

          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, marginTop: 2 }}>
            <TextField
              label="Name"
              variant="outlined"
              fullWidth
              value={raceData.race_name}
              onChange={(e) => setRaceData({ ...raceData, race_name: e.target.value })}
              sx={{ flex: '1 1 100%' }}
              error={Boolean(errors.name)}
              helperText={errors.name}
              required
            />
            <TextField
              select
              label="Race Type"
              variant="outlined"
              fullWidth
              value={raceData.type}
              onChange={(e) => setRaceData({ ...raceData, type: parseInt(e.target.value, 10) })}
              sx={{ flex: '1 1 45%' }}
              error={Boolean(errors.raceType)}
              helperText={errors.raceType}
              required
            >
              <MenuItem value="">
                <em>Select Race Type</em>
              </MenuItem>
              {raceTypes.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>

            <TextField
              label="Venue"
              variant="outlined"
              fullWidth
              value={raceData.location}
              onChange={(e) => setRaceData({ ...raceData, location: e.target.value })}
              sx={{ flex: '1 1 45%' }}
              error={Boolean(errors.venue)}
              helperText={errors.venue}
              required
            />
            <TextField
              label="Date"
              type="date"
              variant="outlined"
              fullWidth
              placeholder='Select Date'
              value={raceData.race_date?.split('T')[0] || ''}
              onChange={(e) => setRaceData({ ...raceData, race_date: e.target.value })}
              sx={{ flex: '1 1 45%' }}
              InputLabelProps={{
                shrink: true,
              }}
              error={Boolean(errors.race_date)}
              helperText={errors.race_date}
              required
            />

            <TextField
              label="Time"
              type="time"
              variant="outlined"
              fullWidth
              value={raceData.race_time || ''}
              onChange={(e) => setRaceData({ ...raceData, race_date: new Date(e.target.value).toISOString().split("T")[0] })}
              sx={{ flex: '1 1 45%' }}
              InputLabelProps={{
                shrink: true,
              }}
            />

            <TextField
              select
              label="Country"
              variant="outlined"
              fullWidth
              value={raceData.country}
              onChange={(e) => setRaceData({ ...raceData, country: e.target.value })}
              sx={{ flex: '1 1 45%' }}
              error={Boolean(errors.country)}
              helperText={errors.country}
              required
            >
              <MenuItem value="">
                <em>Select Country</em>
              </MenuItem>
              {countries.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>

            <Box sx={{ flex: '1 1 45%' }}>
              {/* <label htmlFor="country-image-upload" style={{ display: 'block', marginBottom: '5px' }}>Country Image</label> */}
              <label
                htmlFor="country-image-upload"
                style={{
                  display: 'block',
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ccc',
                  cursor: 'pointer',
                  textAlign: 'center',
                  backgroundColor: '#f8f8f8',
                  color: '#555',
                }}
              >
                Upload Country Image
              </label>
              <input
                id="country-image-upload"
                type="file"
                accept="image/*"
                onChange={handleCountryImageChange}
                style={{ display: 'none' }} // Hide the default file input
              />
            </Box>


            <TextField
              label="Grade"
              variant="outlined"
              fullWidth
              value={raceData.grade}
              onChange={(e) => setRaceData({ ...raceData, grade: e.target.value })}
              sx={{ flex: '1 1 45%' }}
              error={Boolean(errors.grade)}
              helperText={errors.grade}
              required
            />
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button variant="contained" onClick={handleAddDog}>
              Add Dog
            </Button>
          </Box>


          {Array.isArray(raceData.dogs) && raceData.dogs.length > 0 ? (
            raceData.dogs.map((dog, roundIndex) => (
              <Box key={roundIndex} sx={{ marginBottom: 3, border: '1px solid #ddd', padding: 2, borderRadius: 2 }}>
                <TextField
                  select
                  label="Dog Name"
                  variant="outlined"
                  fullWidth
                  value={dog.dog_object_id} // Ensure this corresponds to the actual dogObjectId
                  onChange={(e) => {
                    const updatedDogs = [...raceData.dogs];
                    updatedDogs[roundIndex].dog_object_id = e.target.value; // Update the dogObjectId based on selection
                    setRaceData({ ...raceData, dogs: updatedDogs });
                  }}
                  sx={{ flex: '1 1 100%', marginBottom: 2 }}
                  error={Boolean(errors.raceType)}
                  helperText={errors.raceType}
                  required
                >
                  <MenuItem value="">
                    <em>Select Dog</em>
                  </MenuItem>
                  {dogList.map((option) => (
                    <MenuItem key={option._id} value={option._id}>
                      {option?.dog_name}
                    </MenuItem>
                  ))}
                </TextField>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <TextField
                    label="Rug Name"
                    fullWidth
                    value={dog.rug_number || ''} // Ensure this corresponds to the actual rug value
                    onChange={(e) => {
                      const updatedDogs = [...raceData.dogs];
                      updatedDogs[roundIndex].rug_number = e.target.value;
                      setRaceData({ ...raceData, dogs: updatedDogs });
                    }}
                    sx={{ flex: '2' }}
                  />

                  <TextField
                    label="Box Number"
                    fullWidth
                    value={dog.box_number || ''}
                    onChange={(e) => {
                      const updatedDogs = [...raceData.dogs];
                      updatedDogs[roundIndex].box_number = e.target.value;
                      setRaceData({ ...raceData, dogs: updatedDogs });
                    }}
                    sx={{ flex: '2' }}
                  />


                  <IconButton
                    color="error"
                    onClick={() => handleDeleteDog(roundIndex)}
                    sx={{ flex: '1', maxWidth: '50px' }}
                  >
                    <DeleteIcon />
                  </IconButton>
                </Box>
                <Box sx={{ alignItems: 'center', gap: 2, marginTop: 2 }}>
                  {/* <label htmlFor={'rug-image-upload-' + roundIndex} style={{ display: 'block', marginBottom: '5px' }}>
                    Rug Image
                  </label> */}
                  <label
                    htmlFor={'rug-image-upload-' + roundIndex}
                    style={{
                      display: 'block',
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ccc',
                      cursor: 'pointer',
                      textAlign: 'center',
                      backgroundColor: '#f8f8f8',
                      color: '#555',
                    }}
                  >
                    Upload Rug Image
                  </label>
                  <input
                    id={'rug-image-upload-' + roundIndex}
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      if (!e.target.files || e.target.files.length === 0) return;
                      const file = e.target.files[0];
                      const updatedDogs = [...raceData.dogs];
                      const base64Image = await fileToBase64(file);
                      updatedDogs[roundIndex].rug_image = base64Image;
                      setRaceData({ ...raceData, dogs: updatedDogs });
                    }}
                    style={{ display: 'none' }} // Hide the default file input
                  />
                </Box>

              </Box>
            ))
          ) : (
            <Box sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              padding: '20px',
              border: '2px dashed #ccc',
              borderRadius: '8px',
              backgroundColor: '#f9f9f9',
              boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)',
              color: '#555',
              fontSize: '18px',
              fontWeight: '500',
              textAlign: 'center',
            }}>
              🐶 No dog added yet
            </Box>
          )}

          <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>
              Close
            </Button>
            <Button variant="contained" onClick={handleAddRace}>
              Save Changes
            </Button>
          </Box>
        </Box>
      </Modal>

      <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this Race?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDeleteDialog(false)} color="primary">Cancel</Button>
          <Button
            onClick={async () => {
              if (selectedDogId) {
                await handleDeleteRace(selectedDogId);
              }
              setOpenDeleteDialog(false);
            }}
            color="secondary"
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

    </Box >
  );
};
export default RaceList;
