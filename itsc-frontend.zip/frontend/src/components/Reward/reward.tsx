import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Modal, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, TextField, Link as MuiLink, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, TablePagination, Select, MenuItem, FormControl, InputLabel, Autocomplete, Chip, IconButton, Pagination, Stack } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import { toast } from 'react-toastify';
import { useReward } from '../../context/RewardContext';
import { useDog } from '../../context/DogContext';
import Sidebar from '../Sidebar/sidebar';
import Header from '../Header/header';
import styles from '../../styles/reward.module.css';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';
import { RewardCreatePayload } from '../../utils/api/rewards/rewardList';

const RewardList: React.FC = () => {
	const [isSidebarOpen, setSidebarOpen] = useState(true);
	const [openModal, setOpenModal] = useState(false);
	const [openEditModal, setOpenEditModal] = useState(false);
	const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
	const [selectedRewardId, setSelectedRewardId] = useState<string | null>(null);
	const [dogList, setDogList] = useState<any[]>([]);
	const [selectedDogObj, setSelectedDogObj] = useState<any | null>(null);
	const [dogMembers, setDogMembers] = useState<{ firstName: string; lastName: string; totalUnits: number }[]>([]);
	const [selectedDogs, setSelectedDogs] = useState<any | null>(null);
	const [races, setRaces] = useState<any[]>([]);
	const [rewards, setRewards] = useState<any[]>([]);
	const [selectedRace, setSelectedRace] = useState<any | null>(null);

	const [RewardData, setRewardData] = useState({
		description: '',
		rewardType: 'POINTS',
		points: '',
		dogId: '',
		raceId: '',
	});

	const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
	const userRole = userDetails.userRole;

	const [formErrors, setFormErrors] = useState<{ description?: string; link?: string; points?: string; dogId?: string; raceId?: string }>({});
	const [searchQuery, setSearchQuery] = useState('');
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const { addReward, editReward, deleteReward, fetchDogMembers } = useReward();
	const { adminDogList } = useDog();

	const members = [
		{ name: "Buddy", shareUnit: 5 },
		{ name: "Max", shareUnit: 3 },
		{ name: "Bella", shareUnit: 4 },
		{ name: "Charlie", shareUnit: 2 },
		{ name: "Daisy", shareUnit: 6 }
	];

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	const handleOpenModal = () => {
		setOpenModal(true);
		setRewardData({ description: '', rewardType: 'POINTS', points: '', dogId: '', raceId: '' });
		setSelectedDogs(null);
		setDogMembers([]);
		setSelectedRewardId(null);
		setSelectedDogObj(null);
		setSelectedRace(null);
		setFormErrors({});
	};

	const handleCloseModal = () => {
		setOpenModal(false);
		setRewardData({ description: '', rewardType: 'POINTS', points: '', dogId: '', raceId: '' });
		setSelectedDogs(null);
		setDogMembers([]);
		setSelectedRewardId(null);
		setSelectedDogObj(null);
		setSelectedRace(null);
		setFormErrors({});
	};

	const handleOpenEditModal = (Reward: any) => {
		setRewardData({
			description: Reward.description || '',
			rewardType: Reward.rewardType || 'POINTS',
			points: Reward.points ? String(Reward.points) : '',
			dogId: Reward.dogId || '',
			raceId: Reward.raceId || '',
		});
		const dog = dogList.find(d => d._id === Reward.dogId) || null;
		setSelectedDogs(dog);
		setSelectedDogObj(dog);
		setDogMembers(dog?.members || []);
		const race = races.find(r => r._id === Reward.raceId) || null;
		setSelectedRace(race);
		setSelectedRewardId(Reward._id || null);
		setOpenEditModal(true);
		setFormErrors({});
	};

	const handleCloseEditModal = () => {
		setOpenEditModal(false);
		setRewardData({ description: '', rewardType: 'POINTS', points: '', dogId: '', raceId: '' });
		setSelectedDogs(null);
		setDogMembers([]);
		setSelectedRewardId(null);
		setSelectedDogObj(null);
		setSelectedRace(null);
		setFormErrors({});
	};

	const validateFormData = (data: { description: string; points?: string; rewardType: string; dogId: string; raceId?: string }) => {
		const errors: { description?: string; points?: string; dogId?: string; raceId?: string } = {};
		let isValid = true;

		if (!data.raceId?.trim()) {
			errors.raceId = 'Please select a race';
			isValid = false;
		}

		if (!data.dogId?.trim()) {
			errors.dogId = 'Please select a dog';
			isValid = false;
		}

		if (data.rewardType === 'POINTS') {
			if (!data.points?.trim()) {
				errors.points = 'Points value is required';
				isValid = false;
			} else if (isNaN(Number(data.points)) || Number(data.points) < 0) {
				errors.points = 'Points value must be a non-negative number';
				isValid = false;
			}
		} else if (data.rewardType === 'GIFTS') {
			if (!data.description?.trim()) {
				errors.description = 'Description is required for gift reward type';
				isValid = false;
			}
		}

		setFormErrors(errors);
		return isValid;
	};

	const handleSaveReward = async () => {
		if (!validateFormData(RewardData)) {
			return;
		}

		try {
			const payload = {
				raceId: RewardData.raceId,
				dogId: RewardData.dogId,
				rewardType: RewardData.rewardType,
				description: RewardData.rewardType === 'GIFTS' ? RewardData.description.trim() : "",
				points: RewardData.rewardType === 'POINTS' ? Number(RewardData.points) : 0,
			};

			await api.reward.addReward(payload);
			toast.success('Reward added successfully!');
			fetchRewards(); // Refresh the rewards list
			setOpenModal(false);
		} catch (error) {
			toast.error('Error adding reward.');
		}
	};

	const handleSaveEditReward = async () => {
		if (!selectedRewardId) {
			toast.error("No Reward selected to edit.");
			return;
		}

		if (!validateFormData(RewardData)) {
			return;
		}

		const payload: any = {
			raceId: RewardData.raceId,
			dogId: RewardData.dogId,
			rewardType: RewardData.rewardType,
		};

		if (RewardData.rewardType === 'POINTS') {
			payload.points = Number(RewardData.points);
			payload.description = "";
		} else if (RewardData.rewardType === 'GIFTS') {
			payload.description = RewardData.description.trim();
			payload.points = 0;
		}

		try {
			await editReward(selectedRewardId, payload);
			toast.success("Reward updated successfully!");
			handleCloseEditModal();
		} catch (error) {
			const err = error as any;
			if (err?.response?.err?.details) {
				err.response.err.details.forEach((detail: any) => {
					toast.error(detail.message);
				});
			} else {
				toast.error("Error updating Reward.");
			}
			console.error("Error:", error);
		}
	};

	const handleOpenDeleteDialog = (id: string) => {
		setSelectedRewardId(id);
		setOpenDeleteDialog(true);
	};

	const handleCloseDeleteDialog = () => {
		setOpenDeleteDialog(false);
		setSelectedRewardId(null);
	};

	const handleDeleteReward = async () => {
		if (selectedRewardId) {
			try {
				await api.reward.deleteReward(selectedRewardId);
				toast.success("Reward deleted successfully!");
				handleCloseDeleteDialog();
			} catch (error) {
				toast.error("Error deleting Reward.");
				console.error("Error:", error);
			}
		}
	};

	const handleChangePage = (event: unknown, newPage: number) => {
		setPage(newPage - 1); // Convert to 0-based index
	};

	const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
		setRowsPerPage(parseInt(event.target.value, 10));
		setPage(0);
	};

	const handleDogChange = async (event: any, newValue: any) => {
		console.log("Dog Change", newValue);

		setSelectedDogObj(newValue || null);
		setSelectedDogs(newValue || null);
		setRewardData(prev => ({
			...prev,
			dogId: newValue ? newValue.dog_id : '',
		}));
		setFormErrors(prev => ({ ...prev, dogId: undefined }));

		if (newValue) {
			try {
				const members = await fetchDogMembers(newValue.dog_id);
				const mappedMembers = members.map((member: any) => ({
					firstName: member.member_ObjectId?.first_name || '',
					lastName: member.member_ObjectId?.last_name || '',
					totalUnits: member.totalUnits || 0,
				}));
				setDogMembers(mappedMembers);
			} catch {
				setDogMembers([]);
			}
		} else {
			setDogMembers([]);
		}
	};

	const handleRaceChange = async (event: any, newValue: any) => {
		setSelectedRace(newValue || null);
		setRewardData(prev => ({
			...prev,
			raceId: newValue ? newValue._id : '',
		}));
		setFormErrors(prev => ({ ...prev, raceId: undefined }));

		if (newValue) {
			try {
				const response = await api.reward.getRaceWiseDogList(`${newValue._id}`);
				const dogs = response?.result.map((dog: any) => ({
					_id: dog._id,
					dog_id: dog.dog_object_id._id,
					dog_no: dog.dog_object_id.dog_id,
					dog_name: dog.dog_object_id.dog_name,
				})) || [];
				setDogList(dogs);
			} catch {
				setDogList([]);
			}
		} else {
			setDogList([]);
		}
	};

	const fetchRewards = async () => {
		try {
			const response = await api.reward.getRewardList();
			console.log("Reward List Response:", response);
			if (response?.result) {
				setRewards(response.result); // Store the rewards in state
			} else {
				console.warn("Invalid reward list response format:", response);
			}
		} catch (error) {
			console.error("Error fetching rewards list:", error);
		}
	};

	useEffect(() => {
		fetchRewards(); // Fetch rewards on component mount
	}, []);

	useEffect(() => {
		const fetchRaces = async () => {
			try {
				const response = await api.race.getRaceList();
				setRaces(response?.result || []);
			} catch (error) {
				console.error("Error fetching race list:", error);
			}
		};
		fetchRaces();
	}, []);

	const filteredRewards = rewards.filter(reward =>
		(reward.description || '').toLowerCase().includes(searchQuery.toLowerCase()) || // Adjust this to the correct property
		(reward.dog_object_id?.dog_name || '').toLowerCase().includes(searchQuery.toLowerCase()) || // Include dog name in search
		(reward.race_object_id?.race_name || '').toLowerCase().includes(searchQuery.toLowerCase()) // Include race name in search
	);


	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Reward List</h3>
					<div className={styles.headerRtSide}>
						<TextField
							variant="outlined"
							placeholder="Search Reward"
							size="small"
							sx={{ marginRight: 2 }}
							value={searchQuery}
							onChange={(e) => setSearchQuery(e.target.value)}
						/>
						{userRole !== 'MEMBER' && (
							<Button variant="contained" onClick={handleOpenModal}>
								Add Reward
							</Button>
						)}
					</div>
				</div>

				<div className={styles.customtable}>
					{filteredRewards.length === 0 ? (
						<Typography variant="h6" color="textSecondary" align="center" sx={{ marginTop: 2 }}>
							No Rewards Found
						</Typography>
					) : (
						<TableContainer>
							<Table className={` ${styles.table} table`}>
								<TableHead>
									<TableRow>
										<TableCell>Race Name</TableCell>
										<TableCell>Dog Name</TableCell>
										<TableCell>Reward Type</TableCell>
										<TableCell>Points</TableCell>
										<TableCell>Description</TableCell>
										{/* {userRole !== 'MEMBER' && (
											<TableCell style={{ textAlign: 'center' }}>Actions</TableCell>
										)} */}
									</TableRow>
								</TableHead>
								<TableBody>
									{filteredRewards
										.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
										.map((Reward) => (
											<TableRow key={Reward._id}>
												<TableCell>{Reward.race_object_id?.race_name || 'N/A'}</TableCell>
												<TableCell>{Reward.dog_object_id?.dog_name || 'N/A'}</TableCell>
												<TableCell>{Reward.reward_types}</TableCell>
												<TableCell>{Reward.points}</TableCell>
												<TableCell style={{ whiteSpace: 'pre-wrap' }}>
													{Reward.member?.[0]?.description || 'N/A'}
												</TableCell>
												{/* {userRole !== 'MEMBER' && (
													<TableCell style={{ textAlign: 'center' }}>
														<Button
															variant="outlined"
															color="primary"
															sx={{ mr: 1 }}
															onClick={() => handleOpenEditModal(Reward)}
														>
															<EditIcon />
														</Button>
														<Button
															variant="outlined"
															sx={{ color: 'red', borderColor: 'red' }}
															color="secondary"
															onClick={() => handleOpenDeleteDialog(Reward._id!)}
														>
															<DeleteIcon />
														</Button>
													</TableCell>
												)} */}
											</TableRow>
										))}
								</TableBody>
							</Table>
						</TableContainer>

					)}
					{filteredRewards.length > 0 && (
						<Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
							<Pagination
								count={Math.ceil(filteredRewards.length / rowsPerPage)} // Calculate total pages
								page={page + 1} // MUI Pagination is 1-based
								onChange={handleChangePage}
								color="primary"
							/>
						</Stack>
					)}
				</div>

				{/* Add Reward Modal */}
				<Modal open={openModal} onClose={handleCloseModal}>
					<Box
						sx={{
							position: 'absolute',
							top: '50%',
							right: '0px',
							transform: 'translateY(-50%)',
							padding: 3,
							backgroundColor: 'white',
							borderRadius: 2,
							width: '500px',
							height: '100vh',
							overflowY: 'auto',
						}}
					>
						<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
							<Typography variant="h5" mb={2}>Add Reward</Typography>
							<IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
								<CloseIcon />
							</IconButton>
						</Box>

						<Box sx={{ display: 'flex', flexDirection: 'column' }}>
							<Autocomplete
								options={races}
								getOptionLabel={(option) => option.race_name}
								value={selectedRace}
								onChange={handleRaceChange}
								renderInput={(params) => (
									<TextField
										{...params}
										label="Select Race"
										error={Boolean(formErrors.raceId)}
										helperText={formErrors.raceId}
										required
										sx={{ mb: 2 }}
									/>
								)}
								renderOption={(props, option) => (
									<li {...props}>
										<Box display="flex" alignItems="center">
											<Typography variant="body1">{option.race_name}</Typography>
											<Chip
												label={new Date(option.race_date).toLocaleDateString()}
												size="small"
												color="success"
												sx={{ marginLeft: 1 }}
											/>
										</Box>
									</li>
								)}
							/>

							<Autocomplete
								options={dogList}
								getOptionLabel={(option) => option.dog_name}
								value={selectedDogObj}
								onChange={handleDogChange}
								isOptionEqualToValue={(option, value) => option._id === value._id}
								renderInput={(params) => (
									<TextField
										{...params}
										label="Select Dog"
										error={!!formErrors.dogId}
										helperText={formErrors.dogId}
										required
										sx={{ mb: 2 }}
									/>
								)}
								renderOption={(props, option) => (
									<li {...props}>
										<Box display="flex" alignItems="center">
											<Typography variant="body1">{option.dog_name}</Typography>
											<Chip label={option.dog_no} size="small" sx={{ marginLeft: 1 }} color="success" />
										</Box>
									</li>
								)}
							/>

							{dogMembers.length > 0 && (
								<Box sx={{ border: '1px solid #ddd', p: 2, borderRadius: 2, mb: 2, maxHeight: 220, overflowY: 'auto' }}>
									<Table size="small">
										<TableHead>
											<TableRow>
												<TableCell><strong>Member Name</strong></TableCell>
												<TableCell align="center"><strong>Share Units</strong></TableCell>
											</TableRow>
										</TableHead>

										<TableBody>
											{dogMembers.map((member, index) => (
												<TableRow key={index}>
													<TableCell>{member.firstName + ' ' + member.lastName}</TableCell>
													<TableCell align="center">{member.totalUnits}</TableCell>
												</TableRow>
											))}
										</TableBody>
									</Table>
								</Box>
							)}
						</Box>

						<FormControl fullWidth sx={{ mb: 2 }} required>
							<InputLabel id="reward-type-label">Reward Type</InputLabel>
							<Select
								labelId="reward-type-label"
								id="reward-type-select"
								value={RewardData.rewardType || "POINTS"}
								label="Reward Type"
								onChange={e => setRewardData(prev => ({
									...prev, rewardType: e.target.value, description: '', points: ''
								}))}
							>
								<MenuItem value="POINTS">Points</MenuItem>
								<MenuItem value="GIFTS">Gifts</MenuItem>
							</Select>
						</FormControl>

						{RewardData.rewardType === 'POINTS' && (
							<TextField
								fullWidth
								label="Points"
								value={RewardData.points}
								onChange={e => setRewardData(prev => ({ ...prev, points: e.target.value }))}
								sx={{ mb: 2 }}
								required
								error={Boolean(formErrors.points)}
								helperText={formErrors.points}
								type="number"
								inputProps={{ min: 0 }}
							/>
						)}

						{RewardData.rewardType === 'GIFTS' && (
							<TextField
								fullWidth
								multiline
								rows={6}
								label="Description"
								value={RewardData.description}
								onChange={e => setRewardData(prev => ({ ...prev, description: e.target.value }))}
								sx={{ mb: 2 }}
								required
								error={Boolean(formErrors.description)}
								helperText={formErrors.description}
							/>
						)}

						<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
							<Button onClick={handleCloseModal} sx={{ mr: 1 }}>Cancel</Button>
							<Button variant="contained" onClick={handleSaveReward}>Save</Button>
						</Box>
					</Box>
				</Modal>

				{/* Edit Reward Modal */}
				<Modal open={openEditModal} onClose={handleCloseEditModal}>
					<Box
						sx={{
							position: 'absolute',
							top: '50%',
							right: '0px',
							transform: 'translateY(-50%)',
							padding: 3,
							backgroundColor: 'white',
							borderRadius: 2,
							width: '500px',
							height: '100vh',
							overflowY: 'auto',
						}}
					>
						<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
							<Typography variant="h5" mb={2}>Edit Reward</Typography>
							<IconButton onClick={handleCloseEditModal} sx={{ color: 'gray' }}>
								<CloseIcon />
							</IconButton>
						</Box>

						<Box sx={{ display: 'flex', flexDirection: 'column' }}>
							<Autocomplete
								options={races}
								getOptionLabel={(option) => option.race_name}
								value={selectedRace}
								onChange={handleRaceChange}
								renderInput={(params) => (
									<TextField
										{...params}
										label="Select Race"
										error={Boolean(formErrors.raceId)}
										helperText={formErrors.raceId}
										required
										sx={{ mb: 2 }}
									/>
								)}
								renderOption={(props, option) => (
									<li {...props}>
										<Box display="flex" alignItems="center">
											<Typography variant="body1">{option.race_name}</Typography>
											<Chip
												label={new Date(option.race_date).toLocaleDateString()}
												size="small"
												color="success"
												sx={{ marginLeft: 1 }}
											/>
										</Box>
									</li>
								)}
							/>

							<Autocomplete
								options={dogList}
								getOptionLabel={(option) => option.dog_name}
								value={selectedDogObj}
								onChange={handleDogChange}
								isOptionEqualToValue={(option, value) => option._id === value._id}
								renderInput={(params) => (
									<TextField
										{...params}
										label="Select Dog"
										error={!!formErrors.dogId}
										helperText={formErrors.dogId}
										required
										sx={{ mb: 2 }}
									/>
								)}
								renderOption={(props, option) => (
									<li {...props}>
										<Box display="flex" alignItems="center">
											<Typography variant="body1">{option.dog_name}</Typography>
											<Chip label={option.dog_id} size="small" sx={{ marginLeft: 1 }} color="success" />
										</Box>
									</li>
								)}
							/>

							{dogMembers.length > 0 && (
								<Box sx={{ border: '1px solid #ddd', p: 2, borderRadius: 2, mb: 2, maxHeight: 220, overflowY: 'auto' }}>
									<Table size="small">
										<TableHead>
											<TableRow>
												<TableCell><strong>Member Name</strong></TableCell>
												<TableCell align="center"><strong>Share Units</strong></TableCell>
											</TableRow>
										</TableHead>

										<TableBody>
											{dogMembers.map((member, index) => (
												<TableRow key={index}>
													<TableCell>{member.firstName + ' ' + member.lastName}</TableCell>
													<TableCell align="center">{member.totalUnits}</TableCell>
												</TableRow>
											))}
										</TableBody>
									</Table>
								</Box>
							)}
						</Box>

						<FormControl fullWidth sx={{ mb: 2 }} required>
							<InputLabel id="edit-reward-type-label">Reward Type</InputLabel>
							<Select
								labelId="edit-reward-type-label"
								id="edit-reward-type-select"
								value={RewardData.rewardType}
								label="Reward Type"
								onChange={e => setRewardData(prev => ({ ...prev, rewardType: e.target.value, description: '', points: '' }))}
							>
								<MenuItem value="POINTS">Points</MenuItem>
								<MenuItem value="GIFTS">Gift</MenuItem>
							</Select>
						</FormControl>

						{RewardData.rewardType === 'POINTS' && (
							<TextField
								fullWidth
								label="Points"
								value={RewardData.points}
								onChange={e => setRewardData(prev => ({ ...prev, points: e.target.value }))}
								sx={{ mb: 2 }}
								required
								error={Boolean(formErrors.points)}
								helperText={formErrors.points}
								type="number"
								inputProps={{ min: 0 }}
							/>
						)}

						{RewardData.rewardType === 'GIFTS' && (
							<TextField
								fullWidth
								multiline
								rows={6}
								label="Description"
								value={RewardData.description}
								onChange={e => setRewardData(prev => ({ ...prev, description: e.target.value }))}
								sx={{ mb: 2 }}
								required
								error={Boolean(formErrors.description)}
								helperText={formErrors.description}
							/>
						)}

						<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
							<Button onClick={handleCloseEditModal} sx={{ mr: 1 }}>Cancel</Button>
							<Button variant="contained" onClick={handleSaveEditReward}>Save</Button>
						</Box>
					</Box>
				</Modal>


				{/* Delete Confirmation Dialog */}
				<Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
					<DialogTitle>Confirm Delete</DialogTitle>
					<DialogContent>
						<DialogContentText>Are you sure you want to delete this Reward?</DialogContentText>
					</DialogContent>
					<DialogActions>
						<Button onClick={handleCloseDeleteDialog} color="primary">Cancel</Button>
						<Button onClick={handleDeleteReward} color="secondary">Delete</Button>
					</DialogActions>
				</Dialog>
			</Box>
		</Box>
	);
};

export default RewardList;

