import React, { useEffect, useState } from 'react';
import {
	Box,
	IconButton,
	Typography,
	Stack,
	Chip,
	Avatar,
	Divider,
	CircularProgress,
	Paper
} from '@mui/material';
import {
	NotificationsActive,
	Schedule,
	Circle,
	NotificationsNone,
	Inbox
} from '@mui/icons-material';
import styles from '../../styles/notification.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import moment from 'moment';
import { api } from '../../utils/api';

interface Notification {
	id: number;
	title: string;
	user_id: number;
	description: string;
	alert_type: number;
	is_read: number;
	created_at: string;
}

const Notification: React.FC = () => {
	const [notifications, setNotifications] = useState<Notification[]>([]);
	const [isLoading, setIsLoading] = useState<boolean>(false);

	const fetchNotifications = async () => {
		try {
			setIsLoading(true);
			const response = await api.notifications.fetchNotifications();
			if (response) {
				setIsLoading(false);
				setNotifications(response);
			}
		} catch (error) {
			console.error('Failed to fetch notifications:', error);
		} finally {
			setIsLoading(false);
		}
	}

	useEffect(() => {
		fetchNotifications();
	}, []);

	// Loading state
	if (isLoading) {
		return (
			<LayoutProvider pageTitle="Notifications">
				<Box className={styles.container}>
					<Box className={styles.notifiWrap}>
						<Box sx={{
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							minHeight: 400
						}}>
							<CircularProgress size={50} />
						</Box>
					</Box>
				</Box>
			</LayoutProvider>
		);
	}

	// Empty state when no notifications
	if (!notifications || notifications.length == 0) {
		return (
			<LayoutProvider pageTitle="Notifications">
				<Box className={styles.container}>
					<Box className={styles.notifiWrap}>
						{/* Empty State */}
						<Paper
							elevation={0}
							sx={{
								display: 'flex',
								flexDirection: 'column',
								alignItems: 'center',
								justifyContent: 'center',
								minHeight: 400,
								p: 4,
								backgroundColor: '#fafafa',
								border: '2px dashed #e0e0e0',
								borderRadius: 3
							}}
						>
							<Box sx={{
								display: 'flex',
								flexDirection: 'column',
								alignItems: 'center',
								gap: 2,
								opacity: 0.7
							}}>
								<Avatar sx={{
									width: 80,
									height: 80,
									backgroundColor: '#f5f5f5',
									border: '2px solid #e0e0e0'
								}}>
									<NotificationsNone sx={{
										fontSize: 40,
										color: '#9e9e9e'
									}} />
								</Avatar>

								<Typography
									variant="h6"
									sx={{
										color: '#666',
										fontWeight: 500,
										textAlign: 'center'
									}}
								>
									No Notifications Found
								</Typography>

								<Typography
									variant="body2"
									sx={{
										color: '#9e9e9e',
										textAlign: 'center',
										maxWidth: 300
									}}
								>
									You're all caught up! New notifications will appear here when they arrive.
								</Typography>

								<Box sx={{
									display: 'flex',
									alignItems: 'center',
									gap: 1,
									mt: 2,
									p: 2,
									backgroundColor: 'white',
									borderRadius: 2,
									border: '1px solid #e0e0e0'
								}}>
									<Inbox sx={{ fontSize: 20, color: '#2196f3' }} />
									<Typography variant="caption" color="text.secondary">
										Your inbox is empty
									</Typography>
								</Box>
							</Box>
						</Paper>
					</Box>
				</Box>
			</LayoutProvider>
		);
	}

	// Main notifications view
	return (
		<LayoutProvider pageTitle="Notifications">
			<Box className={styles.container}>
				<Box className={styles.notifiWrap}>
					<Stack spacing={1.5} mt={2}>
						{notifications.map((notification, index) => (
							<Box
								key={index}
								sx={{
									display: 'flex',
									alignItems: 'flex-start',
									p: 2.5,
									borderRadius: 2,
									backgroundColor: notification?.is_read == 0 ? '#f8f9ff' : '#fafafa',
									border: notification?.is_read == 0 ? '1px solid #e3f2fd' : '1px solid #f0f0f0',
									transition: 'all 0.3s ease',
									position: 'relative',
									'&:hover': {
										backgroundColor: notification?.is_read == 0 ? '#f0f4ff' : '#f5f5f5',
										transform: 'translateY(-2px)',
										boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
										cursor: 'pointer'
									}
								}}
							>
								{/* Left Bell Icon with Priority Indicator */}
								<Box sx={{
									display: 'flex',
									alignItems: 'center',
									mr: 2,
									position: 'relative'
								}}>
									<Avatar sx={{
										width: 40,
										height: 40,
										backgroundColor: notification?.is_read == 0 ? '#2196f3' : '#9e9e9e',
										transition: 'all 0.3s ease'
									}}>
										<NotificationsActive sx={{ fontSize: 20 }} />
									</Avatar>

									{/* Priority dot indicator */}
									<Circle sx={{
										position: 'absolute',
										top: -2,
										right: -2,
										fontSize: 14,
										color: "#4caf50"
									}} />
								</Box>

								{/* Notification Content */}
								<Box sx={{ flex: 1, minWidth: 0 }}>
									<Typography
										variant="body2"
										sx={{
											color: notification?.is_read == 0 ? '#1a1a1a' : '#666',
											fontWeight: notification?.is_read == 0 ? 500 : 400,
											lineHeight: 1.5,
											mb: 1
										}}
									>
										{notification?.description}
									</Typography>

									{/* New badge */}
									{notification?.is_read == 0 && (
										<Chip
											label="New"
											size="small"
											sx={{
												backgroundColor: '#2196f3',
												color: 'white',
												fontSize: '0.7rem',
												height: 20,
												fontWeight: 600
											}}
										/>
									)}
								</Box>

								{/* Right Time with Clock Icon */}
								<Box sx={{
									display: 'flex',
									alignItems: 'center',
									flexDirection: 'column',
									gap: 0.5,
									ml: 2,
									minWidth: 'fit-content'
								}}>
									<Schedule sx={{
										fontSize: 16,
										color: '#9e9e9e'
									}} />
									<Typography
										variant="caption"
										sx={{
											color: '#9e9e9e',
											fontWeight: 500,
											textAlign: 'center',
											whiteSpace: 'nowrap'
										}}
									>
										{moment(notification.created_at).fromNow()}
									</Typography>
								</Box>

								{/* Unread indicator line */}
								{notification?.is_read == 0 && (
									<Box sx={{
										position: 'absolute',
										left: 0,
										top: 0,
										bottom: 0,
										width: 4,
										backgroundColor: '#2196f3',
										borderRadius: '0 4px 4px 0'
									}} />
								)}
							</Box>
						))}
					</Stack>

					{/* Footer */}
					<Box sx={{ mt: 4, textAlign: 'center' }}>
						<Divider sx={{ mb: 2 }} />
						<Typography variant="body2" color="text.secondary">
							You have {notifications.filter(n => n?.is_read == 0).length} new notifications
						</Typography>
					</Box>
				</Box>
			</Box>
		</LayoutProvider>
	)
}

export default Notification