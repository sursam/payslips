import React, { useState, useEffect, useRef } from 'react';
import { TextField, InputAdornment, IconButton, CircularProgress, Alert } from '@mui/material';
import MyLocation from '@mui/icons-material/MyLocation';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";

interface ChildProps {
    id: string;
    name: string;
    className: string;
    setLocationData: any;
    value: string;
    country?: string;
    types?: string[];
}

// Declare global google object
declare global {
    interface Window {
        google: any;
        initGoogleMaps: () => void;
    }
}

const LocationInput: React.FC<ChildProps> = ({
    id,
    name,
    className,
    setLocationData,
    value,
    country,
    types
}) => {
    const [locationVal, setLocationVal] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string>('');
    const [isGoogleMapsLoaded, setIsGoogleMapsLoaded] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);
    const autocompleteRef = useRef<any>(null);

    useEffect(() => {
        if (value) {
            setLocationVal(value);
        }
    }, [value]);

    // Load Google Maps API
    useEffect(() => {
        const loadGoogleMapsAPI = () => {
            // Check if Google Maps is already loaded
            if (window.google && window.google.maps) {
                initializeAutocomplete();
                return;
            }

            // Check if script is already added
            const existingScript = document.querySelector(`script[src*="maps.googleapis.com"]`);
            if (existingScript) {
                existingScript.addEventListener('load', initializeAutocomplete);
                return;
            }

            // Create and add the script
            const script = document.createElement('script');
            script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&callback=initGoogleMaps`;
            script.async = true;
            script.defer = true;

            // Set up global callback
            window.initGoogleMaps = initializeAutocomplete;

            script.onerror = () => {
                setError('Failed to load Google Maps API. Please check your API key and network connection.');
            };

            document.head.appendChild(script);
        };

        const initializeAutocomplete = () => {
            if (!window.google || !window.google.maps || !inputRef.current) {
                return;
            }

            try {
                // Comprehensive types for better coverage
                const searchTypes = types || [
                    'geocode',
                    'establishment'
                ];

                const options: any = {
                    types: searchTypes,
                    fields: [
                        'formatted_address',
                        'geometry',
                        'name',
                        'place_id',
                        'types',
                        'address_components'
                    ]
                };

                // Add country restriction if provided
                if (country) {
                    options.componentRestrictions = { country };
                }

                const autocomplete = new window.google.maps.places.Autocomplete(
                    inputRef.current,
                    options
                );

                autocomplete.addListener('place_changed', () => {
                    const place = autocomplete.getPlace();

                    if (place.geometry && place.geometry.location) {
                        const address = place.formatted_address || place.name || '';
                        setLocationVal(address);

                        const locationData = {
                            latitude: place.geometry.location.lat(),
                            longitude: place.geometry.location.lng(),
                            address: address,
                            place_id: place.place_id,
                            types: place.types
                        };

                        setLocationData(name, locationData);
                        setError('');
                    } else {
                        setError('Please select a location from the dropdown');
                    }
                });

                autocompleteRef.current = autocomplete;
                setIsGoogleMapsLoaded(true);
                setError('');

            } catch (error: any) {
                console.error('Error initializing autocomplete:', error);
                // setError('Error initializing location search');
            }
        };

        loadGoogleMapsAPI();

        // Cleanup
        return () => {
            if (autocompleteRef.current && window.google) {
                window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
            }
        };
    }, [country, types]);

    const fetchCurrentLocation = () => {
        if (!navigator.geolocation) {
            setError("Geolocation is not supported by this browser.");
            return;
        }

        setIsLoading(true);
        setError('');

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const { latitude, longitude, accuracy } = position.coords;
                try {
                    if (window.google && window.google.maps) {
                        console.log(position.coords);
                        // Use Google Maps Geocoder
                        const geocoder = new window.google.maps.Geocoder();

                        geocoder.geocode(
                            { location: { lat: latitude, lng: longitude } },
                            (results: any[], status: string) => {
                                setIsLoading(false);

                                if (status === 'OK' && results && results[0]) {
                                    const result = results[0];
                                    setLocationVal(result.formatted_address);

                                    const locationData = {
                                        latitude,
                                        longitude,
                                        address: result.formatted_address,
                                        place_id: result.place_id,
                                        types: result.types
                                    };

                                    setLocationData(name, locationData);
                                    setError('');
                                } else {
                                    setError('Could not determine your address');
                                }
                            }
                        );
                    } else {
                        // Fallback to direct API call
                        const response = await fetch(
                            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`
                        );
                        // console.log('response', response);

                        const data = await response.json();

                        if (data.status === 'OK' && data.results?.[0]) {
                            const result = data.results[0];
                            setLocationVal(result.formatted_address);

                            const locationData = {
                                latitude,
                                longitude,
                                address: result.formatted_address,
                                place_id: result.place_id,
                                types: result.types
                            };

                            setLocationData(name, locationData);
                            setError('');
                        } else {
                            setError('Could not determine your address');
                        }
                    }
                } catch (error: any) {
                    console.error('Error with reverse geocoding:', error);
                    setError('Error getting your location address');
                } finally {
                    setIsLoading(false);
                }
            },
            (err) => {
                setIsLoading(false);
                let errorMessage = 'Error getting your location';

                switch (err.code) {
                    case err.PERMISSION_DENIED:
                        errorMessage = "Location access denied. Please allow location access.";
                        break;
                    case err.POSITION_UNAVAILABLE:
                        errorMessage = "Location information is unavailable.";
                        break;
                    case err.TIMEOUT:
                        errorMessage = "Location request timed out.";
                        break;
                    default:
                        errorMessage = "An unknown error occurred while retrieving location.";
                        break;
                }

                setError(errorMessage);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    };



    return (
        <div style={{ position: 'relative' }}>
            {error && (
                <Alert severity="error" sx={{ mb: 1, fontSize: '0.875rem' }}>
                    {error}
                </Alert>
            )}

            <TextField
                label="Location"
                variant="outlined"
                fullWidth
                margin="normal"
                id={id}
                inputRef={inputRef}
                className={className}
                value={locationVal}
                onChange={(e) => setLocationVal(e.target.value)}
                placeholder={isGoogleMapsLoaded ? "Enter location, area, or landmark..." : "Loading location search..."}
                disabled={!isGoogleMapsLoaded && !error}
                InputProps={{
                    endAdornment: (
                        <InputAdornment position="end">
                            {isLoading ? (
                                <CircularProgress size={20} style={{ marginRight: '10px' }} />
                            ) : (
                                <IconButton
                                    onClick={fetchCurrentLocation}
                                    edge="end"
                                    disabled={!isGoogleMapsLoaded && !error}
                                    sx={{
                                        backgroundColor: (!isGoogleMapsLoaded && !error) ? '#f5f5f5' : '#DDFFEA',
                                        padding: '13px 15px',
                                        borderRadius: '0',
                                        borderLeft: '1px solid #c4c4c4',
                                        position: 'absolute',
                                        right: '0',
                                        margin: '0',
                                        color: (!isGoogleMapsLoaded && !error) ? '#999' : '#007A2F'
                                    }}
                                    title="Use current location"
                                >
                                    <MyLocation />
                                </IconButton>
                            )}
                        </InputAdornment>
                    ),
                }}
                helperText={
                    !isGoogleMapsLoaded && !error ? "Loading Google Maps..." :
                        isLoading ? "Getting your location..." : ""
                }
            />
        </div>
    );
};

export default LocationInput;