import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { ContractorDetailsProps, LiveMarkerJobProps, MarkerProps } from "../../types";

const Marker: React.FC<MarkerProps> = ({ lat, lng, unique_id, job, onClick }) => {
	const [showPopup, setShowPopup] = useState(false);

	const navigate = useNavigate();
	const handleClick = () => {
		onClick();
		setShowPopup((prev) => !prev);
	};
	const handleRedirectOnJob = (id: number) => {
		navigate(`/view-job/${id}`)
	}

	return (
		<div
			style={{
				position: "absolute",
				transform: "translate(-50%, -100%)",
				left: `${lng}%`,
				top: `${lat}%`,
				textAlign: "center",
				cursor: "pointer"
			}}
			onClick={handleClick}
		>
			<img
				src="../../assets/images/marker.png"
				alt="Marker"
				style={{
					height: "30px",
					width: "30px",
				}}
			/>
			<div
				style={{
					marginTop: "4px",
					background: "white",
					padding: "2px 6px",
					borderRadius: "4px",
					fontSize: "10px",
					fontWeight: "bold",
					boxShadow: "0 0 2px rgba(0,0,0,0.3)",
					whiteSpace: "nowrap"
				}}
			>
				{unique_id}
			</div>
			{showPopup && (
				<div
					style={{
						position: "absolute",
						top: "40px",
						left: "50%",
						transform: "translateX(-50%)",
						background: "#fff",
						padding: "8px",
						borderRadius: "6px",
						boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
						fontSize: "12px",
						width: "200px",
						zIndex: 10
					}}
					onClick={(e) => handleRedirectOnJob(job?.id)}
				>
					<strong>{unique_id}</strong>
					<div><strong>Pickup:</strong> {job.source}</div>
					<div><strong>Drop-off:</strong> {job.destination}</div>
				</div>
			)}
		</div>
	);
};

export default Marker;

