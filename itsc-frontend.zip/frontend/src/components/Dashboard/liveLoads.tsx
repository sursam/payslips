import React, { useState } from "react";
import { RunningJobLoadProps } from "../../types";
import LocalShippingIcon from '@mui/icons-material/LocalShipping';

interface ChildProps {
	data: any;
	lat: number;
	lng: number;
	// onClick?: () => void;
}

const LiveLoads: React.FC<ChildProps> = ({ data, lat, lng }) => {
	const [showPopup, setShowPopup] = useState(false);

	const handleClick = () => {
		setShowPopup((prev) => !prev);
	};

	return (
		<div
			style={{
				position: "absolute",
				transform: "translate(-50%, -100%)",
				textAlign: "center",
				cursor: "pointer",
				zIndex: 100
			}}
			onClick={handleClick}
		>
			<LocalShippingIcon
				style={{
					fontSize: "30px",
					color: "#045c8d",
					filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.3))"
				}}
			/>
			<div
				style={{
					marginTop: "4px",
					background: "white",
					padding: "2px 6px",
					borderRadius: "4px",
					fontSize: "10px",
					fontWeight: "bold",
					boxShadow: "0 0 2px rgba(0,0,0,0.3)",
					whiteSpace: "nowrap",
					border: "1px solid #ddd"
				}}
			>
				{data?.job_details?.unique_id || data?.unique_id || 'Load'}
			</div>
			{showPopup && (
				<div
					style={{
						position: "absolute",
						top: "40px",
						left: "50%",
						transform: "translateX(-50%)",
						background: "#fff",
						padding: "8px",
						borderRadius: "6px",
						boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
						fontSize: "12px",
						width: "200px",
						zIndex: 1000,
						border: "1px solid #ddd"
					}}
				>
					<strong>{data?.job_details?.unique_id || data?.unique_id}</strong>
					<div><strong>Load Index:</strong> {data?.load_index || 'N/A'}</div>
					<div><strong>Status:</strong> {data?.status || 'Active'}</div>
					{data?.trucker_details && (
						<div><strong>Driver:</strong> {data.trucker_details.fname} {data.trucker_details.lname}</div>
					)}
				</div>
			)}
		</div>
	);
};

export default LiveLoads;