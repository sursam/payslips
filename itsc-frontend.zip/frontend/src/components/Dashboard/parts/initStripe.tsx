import React, { useState } from 'react';
import { api } from '../../../utils/api';
import {
	Typography,
	Box,
	Modal,
	Slide,
	IconButton,
	Button,
	CircularProgress,
	Alert,
	Container,
	Skeleton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import styles from "../../../styles/viewJob.module.css";
import { loadStripe } from '@stripe/stripe-js';
import {
	Elements,
	useStripe,
	useElements,
	PaymentElement
} from '@stripe/react-stripe-js';
import { toast } from 'react-toastify';

let stripePromise: Promise<any> | null = null;
const getStripe = (key: string) => {
	if (!stripePromise) {
		stripePromise = loadStripe(key);
	}
	return stripePromise;
};

interface ChildProps {
	initiatePaymentData: {
		stripe_publishable_key: string;
		setupIntent: string;
		amount: number;
		currency: string;
	};
	open: boolean;
	onClose: () => void;
	onPaymentSuccess: () => void;
}

const CheckoutForm: React.FC<{
	amount: number;
	currency: string;
	onClose: () => void;
	onPaymentSuccess: () => void;
}> = ({ amount, currency, onClose, onPaymentSuccess }) => {
	const stripe = useStripe();
	const elements = useElements();

	const [state, setState] = React.useState({
		loading: false,
		error: null as string | null,
		success: false,
		elementReady: false
	});

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();
		if (!stripe || !elements) return;

		setState(prev => ({ ...prev, loading: true, error: null }));

		try {
			const result = await stripe.confirmPayment({
				elements,
				confirmParams: { return_url: window.location.href },
				redirect: 'if_required',
			});

			if (result.error) {
				setState(prev => ({
					...prev,
					error: result.error.message || 'Payment failed',
					loading: false
				}));
				toast.error(result.error.message || 'Payment failed');
				return;
			}

			if (result.paymentIntent?.status === 'succeeded') {
				const paymentMethodId = typeof result.paymentIntent.payment_method === 'string'
					? result.paymentIntent.payment_method
					: result.paymentIntent.payment_method?.id || '';

				await finalizePayment(result.paymentIntent.id, paymentMethodId);
			} else {
				setState(prev => ({
					...prev,
					error: 'Payment not completed',
					loading: false
				}));
			}
		} catch (err) {
			setState(prev => ({
				...prev,
				error: 'An unexpected error occurred',
				loading: false
			}));
			toast.error('An unexpected error occurred');
		}
	};

	const finalizePayment = async (paymentIntentId: string, paymentMethodId: string) => {
		try {
			const payload = {
				transaction_id: paymentIntentId,
				payment_method_id: paymentMethodId,
				status: 1
			};

			const response = await api.stripe.finalizePayment(payload);

			if (response) {
				setState(prev => ({ ...prev, loading: false, error: null, success: true, elementReady: prev.elementReady }));
				toast.success('Payment successful!');
				onClose();
				onPaymentSuccess();
			} else {
				throw new Error('Payment finalization failed');
			}
		} catch (err) {
			setState(prev => ({ ...prev, loading: false, error: 'Payment finalization failed', success: false, elementReady: prev.elementReady }));
			toast.error('Something went wrong during payment finalization');
		}
	};

	const { loading, error, success, elementReady } = state;

	return (
		<Container maxWidth="sm" sx={{ mt: 2 }}>
			<Typography variant="h6" sx={{ mb: 2 }}>
				Amount: ${(amount / 100).toFixed(2)} {currency.toUpperCase()}
			</Typography>

			{!elementReady && (
				<Box sx={{ mt: 2 }}>
					<Skeleton variant="rectangular" height={80} width="100%" sx={{ mb: 2 }} />
					<Skeleton variant="rectangular" height={40} width="100%" />
				</Box>
			)}

			<form onSubmit={handleSubmit} style={{ display: elementReady ? 'block' : 'none' }}>
				<PaymentElement
					onReady={() => setState(prev => ({ ...prev, elementReady: true }))}
				/>
				<Button
					type="submit"
					variant="contained"
					fullWidth
					disabled={loading || !stripe || !elements}
					sx={{ mt: 3 }}
				>
					{loading ? (
						<CircularProgress size={20} sx={{ color: 'white' }} />
					) : (
						`Pay $${(amount / 100).toFixed(2)}`
					)}
				</Button>
			</form>

			{error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
			{success && <Alert severity="success" sx={{ mt: 2 }}>🎉 Payment successful!</Alert>}
		</Container>
	);
};

const StripeCheckoutPage: React.FC<ChildProps> = ({
	initiatePaymentData,
	open,
	onClose,
	onPaymentSuccess
}) => {
	const { stripe_publishable_key, setupIntent, amount, currency } = initiatePaymentData || {};

	if (!stripe_publishable_key || !setupIntent) {
		return (
			<Modal open={open} onClose={onClose}>
				<Box className={styles.modalBox}>
					<Typography color="error">Stripe configuration missing</Typography>
					<Button onClick={onClose} sx={{ mt: 2 }}>Close</Button>
				</Box>
			</Modal>
		);
	}

	const stripeInstance = getStripe(stripe_publishable_key);

	return (
		<Modal open={open} onClose={onClose} closeAfterTransition>
			<Slide in={open} direction="left">
				<Box className={styles.modalBox}>
					<Box className={styles.modalHeader}>
						<Typography className={styles.modalTitle}>Complete Your Payment</Typography>
						<IconButton onClick={onClose} sx={{ color: 'red', border: '1px solid red' }}>
							<CloseIcon />
						</IconButton>
					</Box>

					<Elements
						stripe={stripeInstance}
						options={{
							clientSecret: setupIntent,
							appearance: { theme: 'stripe' }
						}}
					>
						<CheckoutForm
							amount={amount * 100}
							currency={currency}
							onClose={onClose}
							onPaymentSuccess={onPaymentSuccess}
						/>
					</Elements>
				</Box>
			</Slide>
		</Modal>
	);
};

export default StripeCheckoutPage;

