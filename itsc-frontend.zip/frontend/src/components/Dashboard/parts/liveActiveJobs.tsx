import React, { useEffect, useState } from 'react';
import {
	Box,
	CardContent,
	Grid,
	Tabs,
	Tab
} from '@mui/material';
import { api } from '../../../utils/api';
import Marker from '../marker';
import LiveLoads from '../liveLoads';
import GoogleMapReact from 'google-map-react';
import { toast } from 'react-toastify';
import { GOOGLE_MAPS_API_KEY } from "../../../config/config";
import styles from '../../../styles/dashboard.module.css';
import LocalShippingTwoToneIcon from '@mui/icons-material/LocalShippingTwoTone';
import { CurrentLocation, ActiveJobCodinates, RunningJobLoadProps } from "../../../types";
import { can } from "../../../utils/helper";

interface TabPanelProps {
	children?: React.ReactNode;
	index: number;
	value: number;
}
function tabPanel(props: TabPanelProps) {
	const { children, value, index, ...other } = props;
	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`job-tabpanel-${index}`}
			aria-labelledby={`job-tab-${index}`}
			{...other}
		>
			{value === index && <Box sx={{ p: 0 }}>{children}</Box>}
		</div>
	);
}
function tabProps(index: number) {

	return {
		id: `job-tab-${index}`,
		'aria-controls': `job-tabpanel-${index}`,
		className: styles.jobTabLink,
	};
}

const LiveActiveJobs: React.FC = () => {
	const [value, setValue] = useState(0);
	const [currentLocation, setCurrentLocation] = useState<CurrentLocation>({ lat: 0, lng: 0 });
	const [jobCoordinates, setJobCoordinates] = useState<ActiveJobCodinates[]>([]);
	const [selectedJob, setSelectedJob] = useState<ActiveJobCodinates | null>(null);
	const [selectedLoad, setSelectedLoad] = useState<RunningJobLoadProps | null>(null);
	const [runningLoads, setRunningLoads] = useState<RunningJobLoadProps[]>([]);
	const defaultProps = {
		center: {
			lat: 10.99835602,
			lng: 77.01502627
		},
		zoom: 11
	};
	const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
		lat: 22.5810906,  // default or initial location
		lng: 88.4818398
	});

	// fetch live active jobs which was posted by me
	const fetchActiveJobs = async (latitiude: number, longitude: number) => {
		try {
			const payload = {
				"latitude": latitiude,
				"longitude": longitude
			}
			const activeJobCoOrdiantes = await api.job.getActiveJobs(payload);
			if (activeJobCoOrdiantes.length > 0) {
				setJobCoordinates(activeJobCoOrdiantes);
			}
		} catch (error) {
			toast.error('Failed to fetch active jobs');
		}
	}
	const fetchLiveRunningLoads = async (latitiude: number, longitude: number) => {
		try {
			const response = await api.job.runningLiveLoads();
			if (response) {

				setRunningLoads(response);
			}
		} catch (error) {
			toast.error('Failed to fetch running loads');
		}
	}

	// getting user current location 
	useEffect(() => {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(
				(position) => {
					const { latitude, longitude } = position.coords;
					fetchActiveJobs(latitude, longitude);
					fetchLiveRunningLoads(latitude, longitude);
					setCurrentLocation({ lat: latitude, lng: longitude });
					setMapCenter({ lat: latitude, lng: longitude });

				},
				(error) => {
					console.error("Error getting location:", error);
				}
			);
		} else {
			console.error("Geolocation is not supported by this browser.");
		}
	}, []);
	const handleChange = (event: React.SyntheticEvent, newValue: number) => {
		setValue(newValue);
	};

	return (
		<Grid size={{ lg: 8, md: 8, sm: 12, xs: 12 }} className={styles.gridBox}>
			<Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
				<Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
					{can(['view-job']) ?
						<Tab label="Live Active Jobs" {...tabProps(0)} />
						: ''
					}
					{can(['view-loads']) ?
						<Tab label="Live Loads" {...tabProps(1)} />
						: ''
					}
				</Tabs>
			</Box>
			{value == 0 ? (
				<div className={styles.cardContent}>
					<div style={{ height: 'calc(100% - 50px)', width: '100%' }}>
						{GOOGLE_MAPS_API_KEY ?
							<GoogleMapReact
								bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
								defaultCenter={defaultProps.center}
								center={mapCenter}
								defaultZoom={14}
								zoom={14}
								distanceToMouse={(pt, mousePos) => {
									if (!pt || !mousePos) return 0;
									return Math.sqrt(
										(pt.x - mousePos.x) ** 2 + (pt.y - mousePos.y) ** 2
									);
								}}
							>
								{jobCoordinates.map((coord, index) => (
									<Marker key={coord.unique_id} lat={coord.source_lat} lng={coord.source_lng} unique_id={coord.unique_id} job={coord} // entire job object
										onClick={() => setSelectedJob(coord)} />
								))}
							</GoogleMapReact>
							: ''}

					</div>
				</div>
			) : (
				<div className={styles.cardContent}>
					<div style={{ height: 'calc(100% - 50px)', width: '100%' }}>
						{GOOGLE_MAPS_API_KEY ?
							<GoogleMapReact
								bootstrapURLKeys={{ key: GOOGLE_MAPS_API_KEY }}
								defaultCenter={defaultProps.center}
								center={mapCenter}
								defaultZoom={14}
								zoom={14}
								distanceToMouse={(pt, mousePos) => {
									if (!pt || !mousePos) return 0;
									return Math.sqrt(
										(pt.x - mousePos.x) ** 2 + (pt.y - mousePos.y) ** 2
									);
								}}
							>
								{runningLoads.map((load, index) => {
									const truckLat = load?.trucker_current_lat || load?.job_details?.source_lat || mapCenter.lat;
									const truckLng = load?.trucker_current_lng || load?.job_details?.source_lng || mapCenter.lng;

									const lat = Number(truckLat);
									const lng = Number(truckLng);

									if (!isNaN(lat) && !isNaN(lng) && lat !== 0 && lng !== 0) {
										return (
											<LiveLoads
												key={load?.load_id || load?.job_details?.unique_id || `load-${index}`}
												data={load}
												lat={lat}
												lng={lng}
											/>
										);
									}
									return null;
								})}
							</GoogleMapReact>
							: ''}
					</div>
				</div>
			)}

		</Grid>
	)
}
export default LiveActiveJobs;