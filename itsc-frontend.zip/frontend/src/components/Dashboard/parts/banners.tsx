import React, { useEffect, useState } from 'react';
import {
	Grid,
	CardContent
} from '@mui/material';
import { api } from '../../../utils/api';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import styles from '../../../styles/dashboard.module.css';
import { BannerProps } from "../../../types";

const Banners: React.FC = () => {
	const [banners, setBanners] = useState<BannerProps[]>([]);

	// fetch banners via api call
	const fetchBanners = async () => {
		try {
			const response = await api.activity.fetchActivity();
			setBanners(response);
		} catch (error) {
			console.error("Failed to fetch jobs:", error);
		}
	};

	useEffect(() => {
		fetchBanners();
	}, []);

	const settings = {
		dots: true,
		infinite: false,
		speed: 500,
		arrows: false,
		slidesToShow: 4,
		slidesToScroll: 4,
		initialSlide: 0,
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true
				}
			},
			{
				breakpoint: 600,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2,
					initialSlide: 2
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	};

	return (
		<Grid container spacing={3} style={{ marginBottom: '30px' }}>
			<Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox} style={{ backgroundColor: 'transparent', border: 'none' }}>
				<CardContent className={styles.gridBoxwrap}>
					<div className={`sliderSliderContainer ${styles.sliderContainer}`}>
						{Array.isArray(banners) && banners.length > 0 ? (
							<Slider {...settings}>
								{banners.map((banner, index) => (
									<div key={index} className={styles.imageBox}>
										<a href={banner?.banner_url} target="_blank" rel="noopener noreferrer">
											<img
												src={banner?.banner_image}
												alt={banner?.banner_title}
												className="object-contain"
											/>
										</a>
									</div>
								))}
							</Slider>
						) : (
							<p>No banners available</p>
						)}

					</div>
				</CardContent>
			</Grid>
		</Grid>
	);
}
export default Banners;