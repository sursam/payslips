import React, { useEffect, useState } from "react";
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import {
	Box,
	CardContent,
	Grid,
	IconButton,
	Table,
	TableContainer,
	TableHead,
	TableBody,
	TableRow,
	TableCell,
	Typography
} from '@mui/material';
import styles from "../../../styles/dashboard.module.css";
import { api } from "../../../utils/api";
import moment from "moment";
import { UpcomingPickupsProps } from "../../../types";

const UpcomingPickups: React.FC = () => {
	const [jobs, setJobs] = useState<UpcomingPickupsProps[]>([]);
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(0);

	// get those jobs which are not deliveried yet
	const fetchUpcomingPickups = async () => {
		try {
			const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");

			const response = await api.job.getMyJobs(
				1,
				currentDate.toString(),
				currentPage
			);
			setJobs(response?.data || []);
			setTotalPages(response?.pagination?.total_pages || 0);
			setCurrentPage(response?.pagination?.current_page || 1);
		} catch (error) {
			console.error("Failed to fetch jobs:", error);
			setJobs([]);
		}
	};

	useEffect(() => {
		fetchUpcomingPickups();
	}, []);
	return (
		<Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
			<CardContent className={styles.gridBoxwrap}>
				<div className={styles.cardTitle}>
					<h5>Upcoming Pickups</h5>
				</div>

				<TableContainer>
					{jobs.length > 0 ? (
						<Table className={styles.table}>
							<TableHead>
								<TableRow>
									<TableCell>Job ID</TableCell>
									<TableCell>Material</TableCell>
									<TableCell>Posted Date & Time</TableCell>
									<TableCell>Job Cost</TableCell>
									<TableCell>No. Of Trucks</TableCell>
									<TableCell>Pickup Date & Time</TableCell>
									<TableCell>Delivery Date & Time</TableCell>
									<TableCell></TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{jobs.map((job) => (
									<TableRow key={job.id}>
										<TableCell>{job?.unique_id}</TableCell>
										<TableCell>{job?.material_name?.toLowerCase() != 'other' ? job?.material_name : job?.material_other}</TableCell>
										<TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
										<TableCell>${job.job_estimate_price}</TableCell>
										<TableCell>
											<span className={`${styles.badge} ${styles.blueBg}`}>
												{job.no_of_trucks}
											</span>
										</TableCell>
										<TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
										<TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					) : (
						<div className={styles.noDataContainer}>
							<Typography variant="h6" color="textSecondary" align="center">
								<AssignmentLateIcon fontSize="large" />
								<br />
								No jobs found
							</Typography>
							<Typography variant="body2" color="textSecondary" align="center">
								There are currently no jobs matching your criteria
							</Typography>
						</div>
					)}

				</TableContainer>

			</CardContent>
		</Grid>
	);
}
export default UpcomingPickups;