import React, { useState, useEffect, ReactNode } from 'react';
import { api } from '../../../utils/api';
import StripeCheckoutPage from '../parts/initStripe';
import { shouldIReadyForJobPost, StripeInitiateProps } from "../../../types";
import { toast } from 'react-toastify';

interface ChildProps {
	redirectTo: string;
	children: ReactNode;
}
const PostJobLink: React.FC<ChildProps> = ({ children, redirectTo }) => {
	const shouldPaymentNeeded = typeof localStorage !== "undefined" && localStorage.getItem("doesPaymentNeeded") === "true";
	const amISubContractor = typeof localStorage !== "undefined" && localStorage.getItem("isSubContractor") === "true";

	const [shouldIReadyForJobPost, setShouldIReadyForJobPost] = useState<shouldIReadyForJobPost | null>(null);
	const [showPostButton, setShowPostButton] = React.useState(false);
	const [stripeInitiate, setStripeInitiate] = useState<StripeInitiateProps | null>(null);
	const [openInitStripeModal, setOpenInitStripeModal] = React.useState(false);

	const shouldIReadyForJob = async () => {
		const response = await api.job.isReadyForJob();
		if (response) {
			console.log("shouldIReadyForJobPost===>", response);
			setShouldIReadyForJobPost(response);
			setShowPostButton(true);

		} else {
			toast.error(response?.message);
		}
	}

	const handleCloseInitStripe = () => {
		setOpenInitStripeModal(false);
	}

	const handlePostJob = async () => {

		// if (!shouldPaymentNeeded) {
		if (!shouldIReadyForJobPost?.is_payment_needed) {
			window.location.href = redirectTo;
		} else if (!amISubContractor && shouldIReadyForJobPost?.is_payment_needed) {
			// User needs to make payment, initialize Stripe
			try {
				const response = await api.stripe.initStripe();
				if (response) {
					setStripeInitiate(response);
					setOpenInitStripeModal(true);
				} else {
					toast.error(response?.message || "Failed to initialize Stripe.");
				}
			} catch (error) {
				toast.error("Something went wrong while initializing payment.");
				console.error(error);
			}
		} else {
			toast.error("Payment needed to post new job");
		}
	};

	const handlePaymentSuccess = async () => {
		shouldIReadyForJob();
		localStorage.setItem("doesPaymentNeeded", "false");
		handleCloseInitStripe();

		setTimeout(() => {
			window.location.href = redirectTo;
		}, 500);
	};

	useEffect(() => {
		shouldIReadyForJob();
	}, []);
	// useEffect(() => {
	// 	if (!showPostButton && !amISubContractor) {
	// 		toast.error("Payment needed to post new job");
	// 	}
	// }, [showPostButton, amISubContractor]);


	return (
		<>
			{
				showPostButton && (
					<div onClick={handlePostJob}>{children}</div>
				)
			}

			<StripeCheckoutPage
				initiatePaymentData={stripeInitiate}
				open={openInitStripeModal}
				onClose={handleCloseInitStripe}
				onPaymentSuccess={handlePaymentSuccess}
			/>
		</>
	);
};

export default PostJobLink;


