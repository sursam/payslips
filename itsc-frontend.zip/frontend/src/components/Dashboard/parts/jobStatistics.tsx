import React from 'react';
import {
	Box,
	CardContent,
	IconButton,
	Grid,
} from '@mui/material';
import styles from '../../../styles/dashboard.module.css';
import { BusinessCenterOutlined, ErrorOutlineOutlined, TaskAltOutlined, SaveOutlined } from '@mui/icons-material';

interface ChildProps {
	jobStatistics: {
		totalPostedJobs: number;
		pendingJobs: number;
		completedJobs: number;
		draftedJobs: number;
	};
}
const JobStatistics: React.FC<ChildProps> = ({ jobStatistics }) => {
	return (
		<Grid container spacing={{ xs: 1, sm: 2, md: 3, lg: 3 }} style={{ marginBottom: '20px' }}>
			<Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }} className={styles.gridBox}>
				<CardContent className={styles.dbuserBoxwrap}>
					<Box className={`${styles.ttlBar} ${styles.cardBlue}`}>
						<div className={styles.cardIcon}>
							<IconButton className={styles.toggleButton}>
								<BusinessCenterOutlined style={{ width: '18px', height: '18px', color: '#005DAA' }} />
							</IconButton>
						</div>
						<div className={styles.cardBox}>
							<h6 className={styles.cardCount}>
								{jobStatistics?.totalPostedJobs}
							</h6>
							<span>Total Posted Jobs</span>
						</div>
					</Box>
				</CardContent>
			</Grid>
			<Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }} className={styles.gridBox}>
				<CardContent className={styles.dbuserBoxwrap}>
					<Box className={`${styles.ttlBar} ${styles.cardOrange}`}>
						<div className={styles.cardIcon}>
							<IconButton className={styles.toggleButton}>
								<ErrorOutlineOutlined style={{ width: '18px', height: '18px', color: '#E07211' }} />
							</IconButton>
						</div>
						<div className={styles.cardBox}>
							<h6 className={styles.cardCount}>
								{jobStatistics?.pendingJobs}
							</h6>
							<span>Pending Jobs</span>
						</div>
					</Box>
				</CardContent>
			</Grid>
			<Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }} className={styles.gridBox}>
				<CardContent className={styles.dbuserBoxwrap}>
					<Box className={`${styles.ttlBar} ${styles.cardGreen}`}>
						<div className={styles.cardIcon}>
							<IconButton className={styles.toggleButton}>
								<TaskAltOutlined style={{ width: '18px', height: '18px', color: '#079D0F' }} />
							</IconButton>
						</div>
						<div className={styles.cardBox}>
							<h6 className={styles.cardCount}>
								{jobStatistics?.completedJobs}
							</h6>
							<span>Completed Jobs</span>
						</div>
					</Box>
				</CardContent>
			</Grid>
			<Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }} className={styles.gridBox}>
				<CardContent className={styles.dbuserBoxwrap}>
					<Box className={`${styles.ttlBar} ${styles.cardGray}`}>
						<div className={styles.cardIcon}>
							<IconButton className={styles.toggleButton}>
								<SaveOutlined style={{ width: '18px', height: '18px', color: '#283c50' }} />
							</IconButton>
						</div>
						<div className={styles.cardBox}>
							<h6 className={styles.cardCount}>
								{jobStatistics?.draftedJobs}
							</h6>
							<span>Drafted Jobs</span>
						</div>
					</Box>
				</CardContent>
			</Grid>
		</Grid>
	)
};

export default JobStatistics;