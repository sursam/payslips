import React, { useState, useEffect } from 'react';
import {
	Box,
	Button,
	Grid,
	CardContent,
	Typography
} from '@mui/material';
import {
	WbSunny,
	NightsStay,
	Cloud,
	CloudQueue,
	Grain,
	Thunderstorm,
	WbCloudy,
	FilterDrama,
	Opacity
} from '@mui/icons-material';
import AirIcon from '@mui/icons-material/Air';
import ThunderstormIcon from '@mui/icons-material/Thunderstorm';
import AcUnitRoundedIcon from '@mui/icons-material/AcUnitRounded';
import NorthIcon from '@mui/icons-material/North';
import SouthIcon from '@mui/icons-material/South';
import BedtimeIcon from '@mui/icons-material/Bedtime';

import styles from '../../../styles/dashboard.module.css';
import { can } from "../../../utils/helper";

import PostJobLink from '../../../components/Dashboard/parts/postJobLink';

// interface ChildProps {
// 	handlePostJob: () => void;
// 	showPostButton: boolean;
// }

interface WeatherPeriod {
	number: number;
	name: string;
	startTime: string;
	endTime: string;
	isDaytime: boolean;
	temperature: number;
	temperatureUnit: string;
	probabilityOfPrecipitation: {
		value: number;
	};
	windSpeed: string;
	windDirection: string;
	icon: string;
	shortForecast: string;
	detailedForecast: string;
}

interface WeatherData {
	properties: {
		periods: WeatherPeriod[];
	};
}

interface Coordinates {
	latitude: number;
	longitude: number;
}

// const PostNewJob: React.FC<ChildProps> = ({ handlePostJob, showPostButton }) => {
const PostNewJob: React.FC = () => {
	const [coordinates, setCoordinates] = useState<Coordinates>({ latitude: 0, longitude: 0 });
	const [currentForecast, setCurrentForecast] = useState<WeatherPeriod | null>(null);
	const [loading, setLoading] = useState(true);
	const [locationName, setLocationName] = useState('Loading...');
	const [forecastPeriods, setForecastPeriods] = useState<WeatherPeriod[]>([]);

	const getUserLocation = (callback: (coords: Coordinates | null) => void) => {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(
				position => {
					callback({
						latitude: position.coords.latitude,
						longitude: position.coords.longitude
					});
				},
				error => {
					console.error('Geolocation error:', error);
					callback({ latitude: 29.4241, longitude: -98.4936 }); // Default fallback
				},
				{
					enableHighAccuracy: true,
					timeout: 10000,
					maximumAge: 60000
				}
			);
		} else {
			callback({ latitude: 29.4241, longitude: -98.4936 }); // Geolocation unsupported
		}
	};

	const getCurrentTimeForecast = (periods: WeatherPeriod[]): WeatherPeriod | null => {
		const now = new Date();
		for (const period of periods) {
			if (now >= new Date(period.startTime) && now <= new Date(period.endTime)) {
				return period;
			}
		}
		// Fallback
		return periods.length ? periods[0] : null;
	};

	const fahrenheitToCelsius = (fahrenheit: number): number => {
		return Math.round((fahrenheit - 32) * 5 / 9);
	};

	const getWeatherIcon = (shortForecast: string, isDaytime: boolean): React.ReactElement => {
		const forecast = shortForecast.toLowerCase();
		if (forecast.includes('clear') || forecast.includes('sunny')) {
			return isDaytime ? <WbSunny sx={{ fontSize: 70, color: '#FFA726' }} /> : <NightsStay sx={{ fontSize: 70, color: '#7986CB' }} />;
		} else if (forecast.includes('partly cloudy') || forecast.includes('mostly clear')) {
			return isDaytime ? <WbCloudy sx={{ fontSize: 70, color: '#78909C' }} /> : <NightsStay sx={{ fontSize: 70, color: '#7986CB' }} />;
		} else if (forecast.includes('mostly sunny')) {
			return <FilterDrama sx={{ fontSize: 70, color: '#FFB74D' }} />;
		} else if (forecast.includes('cloudy')) {
			return <Cloud sx={{ fontSize: 70, color: '#90A4AE' }} />;
		} else if (forecast.includes('rain') || forecast.includes('showers')) {
			return <Grain sx={{ fontSize: 70, color: '#42A5F5' }} />;
		} else if (forecast.includes('thunderstorm')) {
			return <Thunderstorm sx={{ fontSize: 70, color: '#5C6BC0' }} />;
		} else if (forecast.includes('overcast')) {
			return <CloudQueue sx={{ fontSize: 70, color: '#78909C' }} />;
		} else if (forecast.includes('drizzle')) {
			return <Opacity sx={{ fontSize: 70, color: '#29B6F6' }} />;
		}
		return isDaytime ? <WbSunny sx={{ fontSize: 70, color: '#FFA726' }} /> : <NightsStay sx={{ fontSize: 70, color: '#7986CB' }} />;
	};

	const getLocationName = async (latitude: number, longitude: number): Promise<string> => {
		try {
			// let latitude = 29.5903402;
			// let longitude = -98.3912551;
			const response = await fetch(`https://api.weather.gov/points/${latitude},${longitude}`);
			const data = await response.json();
			const city = data.properties?.relativeLocation?.properties?.city || 'Unknown';
			const state = data.properties?.relativeLocation?.properties?.state || '';
			return `${city}${state ? ', ' + state : ''}`;
		} catch (error) {
			console.error('Location name fetch error:', error);
			return 'Your Location';
		}
	};

	const fetchWeatherData = async (latitude: number, longitude: number) => {
		try {
			// let latitude = 29.5903402;
			// let longitude = -98.3912551;
			const pointsResponse = await fetch(`https://api.weather.gov/points/${latitude},${longitude}`);
			const pointsData = await pointsResponse.json();

			const forecastUrl = pointsData.properties?.forecast;
			if (forecastUrl) {
				const forecastResponse = await fetch(forecastUrl);
				const forecastData: WeatherData = await forecastResponse.json();
				console.log(forecastData);

				setForecastPeriods(forecastData.properties.periods || []);

				const current = getCurrentTimeForecast(forecastData.properties.periods);
				setCurrentForecast(current);
			}
		} catch (error) {
			console.error('Weather fetch error:', error);
		} finally {
			setLoading(false);
		}
	};


	useEffect(() => {
		getUserLocation(async (coords) => {
			if (coords) {
				setCoordinates(coords);
				const name = await getLocationName(coords.latitude, coords.longitude);
				setLocationName(name);
				await fetchWeatherData(coords.latitude, coords.longitude);
			}
		});
	}, []);

	if (loading) {
		return (
			<Grid size={{ lg: 4, md: 4, sm: 12, xs: 12 }} className={styles.gridBox}>
				<CardContent className={`${styles.gridBoxwrap} ${styles.weatherCard}`}>
					<Typography variant="h6" sx={{ margin: '44px' }}>Loading weather...</Typography>
				</CardContent>
			</Grid>
		);
	}
	if (!currentForecast) {
		return (
			<Grid size={{ lg: 4, md: 4, sm: 12, xs: 12 }} className={styles.gridBox}>
				<CardContent className={`${styles.gridBoxwrap} ${styles.weatherCard}`}>
					<Typography variant="h6" sx={{ margin: '44px' }}>Weather data unavailable</Typography>
					{can(['add-job']) ?
						<Box sx={{ padding: '10px 40px 0px', marginTop: '210px' }}>
							<PostJobLink redirectTo='/post-job'>
								<Button variant="contained" color="primary" className={styles.formButton}>
									Post a new job
								</Button>
							</PostJobLink>
							{/* {showPostButton ?
								<Button variant="contained" color="primary" className={styles.formButton} onClick={handlePostJob}>
									Post a new job
								</Button>
								: ''
							} */}
						</Box>
						: ''
					}
				</CardContent>
			</Grid>
		);
	}

	const tempCelsius = fahrenheitToCelsius(currentForecast.temperature);

	return (
		<Grid size={{ lg: 4, md: 4, sm: 12, xs: 12 }} className={styles.gridBox}>
			<CardContent className={`${styles.gridBoxwrap} ${styles.weatherCard}`}>
				<div className={styles.cardContent}>
					<Box className={styles.weatherb}>
						<p className={styles.location}>{locationName}</p>
						<div className={styles.top}>
							<h3 className={styles.temp}>
								{currentForecast.temperature}
								<sup>°{currentForecast.temperatureUnit}</sup>
							</h3>
							<div className={styles.clearBox}>
								<div className={styles.info}>
									<p>{currentForecast.shortForecast}</p>
									<ul>
										<li>
											<NorthIcon fontSize="small" /> <span>Max</span>
										</li>
										<li>
											<SouthIcon fontSize="small" /> <span>Min</span>
										</li>
									</ul>
								</div>
								<div className={styles.icon}>{getWeatherIcon(currentForecast.shortForecast, currentForecast.isDaytime)}</div>
							</div>
						</div>

						<div className={styles.outsideTem}>
							<p>Upcoming FORECAST</p>
							<div className={styles.outsideTemain}>
								<div className={styles.outsideTemWarp}>
									{forecastPeriods.slice(0, 5).map((period, idx) => (
										<div className={styles.temBox} key={idx}>
											<div className={styles.icon}>
												{getWeatherIcon(period.shortForecast, period.isDaytime)}
											</div>
											<div className={styles.text}>
												<span>{period.temperature}°{period.temperatureUnit}</span>
												<p>
													{new Date(period.startTime).toLocaleDateString(undefined, { weekday: 'short' })}
													{' '}
													{/* {new Date(period.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} */}
													{`(${period?.isDaytime ? 'Day' : 'Night'})`}
												</p>
											</div>
										</div>
									))}
								</div>
							</div>
						</div>




						<Box display="flex" flexDirection={{ xs: 'column', sm: 'row' }} justifyContent="space-between" gap={{ xs: '10px' }} mt={2}>
							<Box display="flex" alignItems="center" gap={1}>
								<AirIcon color="primary" />
								<span>Wind:</span>
								<strong>{currentForecast.windDirection} {currentForecast.windSpeed}</strong>
							</Box>
							<Box display="flex" alignItems="center" gap={1}>
								<ThunderstormIcon color="primary" />
								<span>Rain:</span>
								<strong>{currentForecast.probabilityOfPrecipitation?.value || 0}%</strong>
							</Box>
						</Box>
					</Box>

					{can(['add-job']) ?
						<Box sx={{ padding: '10px 40px 0px' }} mt={1}>
							{/* <Button variant="contained" color="primary" className={styles.formButton} onClick={handlePostJob}>
								Post a new job
							</Button> */}
							<PostJobLink redirectTo='/post-job'>
								<Button variant="contained" color="primary" className={styles.formButton}>
									Post a new job
								</Button>
							</PostJobLink>
						</Box>
						: ''
					}
				</div>
			</CardContent>
		</Grid>

	);
};

export default PostNewJob;


