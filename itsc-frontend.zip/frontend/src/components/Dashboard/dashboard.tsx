import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
    Box,
    // CardContent,
    Grid,
    // Button,
    // Typography
} from '@mui/material';
// import styles from '../../styles/dashboard.module.css';
import { api } from '../../utils/api';
import LayoutProvider from '../../providers/LayoutProvider';
// import { toast } from 'react-toastify';
import JobStatistics from './parts/jobStatistics';
import Banners from './parts/banners';
import LiveActiveJobs from './parts/liveActiveJobs';
import UpcomingPickups from './parts/upcomingPickups';
// import StripeCheckoutPage from './parts/initStripe';
import PostNewJob from './parts/postNewJob';
// import { shouldIReadyForJobPost, JobStatisticsProps, StripeInitiateProps } from "../../types";
import { JobStatisticsProps } from "../../types";

const Main: React.FC = () => {
    // const navigate = useNavigate();
    const [jobStatistics, setJobStatistics] = useState<JobStatisticsProps>({
        totalPostedJobs: 0,
        pendingJobs: 0,
        completedJobs: 0,
        draftedJobs: 0
    });
    // const [shouldIReadyForJobPost, setShouldIReadyForJobPost] = useState<shouldIReadyForJobPost | null>(null);
    // const [stripeInitiate, setStripeInitiate] = useState<StripeInitiateProps | null>(null);
    // const [openInitStripeModal, setOpenInitStripeModal] = React.useState(false);
    // const [showPostButton, setShowPostButton] = React.useState(false);

    // useEffect(() => {
    //     console.log("shouldIReadyForJobPost ::: ", shouldIReadyForJobPost);

    // }, [shouldIReadyForJobPost])
    const totalJobCounting = async () => {
        try {
            const response = await api.job.getMyPostedJobCounting();
            if (response) {
                setJobStatistics({
                    totalPostedJobs: response.totalPostedJobs,
                    pendingJobs: response.pendingJobs,
                    completedJobs: response.completedOrClosedJobs,
                    draftedJobs: response.draftedJobs
                });
            }
        } catch (error) {
            console.error("Failed to fetch jobs:", error);
        }
    };

    /* const shouldIReadyForJob = async () => {
        const response = await api.job.isReadyForJob();
        if (response) {
            console.log("shouldIReadyForJobPost===>", response);
            setShouldIReadyForJobPost(response);
            setShowPostButton(true);

        } else {
            toast.error(response?.message);
        }
    }

    const handleinitStripe = () => {
        setOpenInitStripeModal(true);
    }
    const handleCloseInitStripe = () => {
        setOpenInitStripeModal(false);
    }

    const initStripePayment = async () => {
        const response = await api.stripe.initStripe();
        if (response) {
            setStripeInitiate(response);
        } else {
            toast.error(response?.message);
        }
    }


    const handlePostJob = async () => {
        console.log("---------------------------------------------->>>>>>>>>>>>", shouldIReadyForJobPost?.is_ready_for_job, shouldIReadyForJobPost?.is_payment_needed);

        if (shouldIReadyForJobPost?.is_ready_for_job && !shouldIReadyForJobPost?.is_payment_needed) {

            window.location.href = '/post-job';
        } else {
            // User needs to make payment, initialize Stripe
            try {
                const response = await api.stripe.initStripe();
                if (response) {
                    console.log("response ::: ", response);

                    setStripeInitiate(response);
                    setOpenInitStripeModal(true);
                } else {
                    toast.error(response?.message || "Failed to initialize Stripe.");
                }
            } catch (error) {
                toast.error("Something went wrong while initializing payment.");
                console.error(error);
            }
        }
    };

    // const handlePaymentSuccess = () => {
    //     console.log("hereeeeeeeeeeeeeeeeeee");

    //     // After successful payment, update the ready status and navigate
    //     if (shouldIReadyForJobPost) {
    //         setShouldIReadyForJobPost({
    //             ...shouldIReadyForJobPost,
    //             is_ready_for_job: true
    //         });
    //     }
    //     handleCloseInitStripe();
    //     window.location.href = '/post-job';
    // };
    const handlePaymentSuccess = async () => {
        // After successful payment, refresh the ready status from API
        // try {
        //     const response = await api.job.isReadyForJob();
        //     if (response) {
        //         console.log("handlePaymentSuccess response", response);

        //         setShouldIReadyForJobPost(response);
        //         setShowPostButton(true);
        //     }
        // } catch (error) {
        //     console.error("Failed to refresh job ready status:", error);
        // }

        shouldIReadyForJob();
        handleCloseInitStripe();

        // Small delay to ensure state is updated
        setTimeout(() => {
            window.location.href = '/post-job';
        }, 500);
    }; */

    useEffect(() => {
        totalJobCounting();
        // shouldIReadyForJob();
    }, []);

    return (
        <LayoutProvider pageTitle="Dashboard">
            {/* Job Statictics */}
            <JobStatistics jobStatistics={jobStatistics} />
            {/* Payment Button */}
            <Box
                sx={{
                    position: 'fixed',
                    bottom: 0,
                    right: 0,
                    zIndex: 1,
                    width: '100%',
                    display: 'flex',
                    justifyContent: 'end',
                    alignItems: 'center',
                    py: 2,
                    margin: '0px 50px 0px 0px'
                }}
            >
            </Box>
            {/* banners section */}
            <Banners />
            <Grid container spacing={{ xs: 1, sm: 2, md: 3, lg: 3 }}>
                {/* Live Active Jobs in map */}
                <LiveActiveJobs />
                {/* Post a new job */}
                {/* <PostNewJob handlePostJob={handlePostJob} showPostButton={showPostButton} /> */}
                <PostNewJob />
                {/* upcoming job section */}
                <UpcomingPickups />
            </Grid>
            {/* <StripeCheckoutPage
                initiatePaymentData={stripeInitiate}
                open={openInitStripeModal}
                onClose={handleCloseInitStripe}
                onPaymentSuccess={handlePaymentSuccess}
            /> */}

        </LayoutProvider>
    );
};

export default Main;
