import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import {
	Box,
	Button,
	Typography,
	Grid,
	Container,
	useTheme,
	useMediaQuery
} from '@mui/material';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';

const PreApprovedPage: React.FC = () => {
	const navigate = useNavigate();
	const theme = useTheme();
	const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

	const handleLogout = async () => {
		await api.auth.logout();
		localStorage.clear();
		// navigate('/');
		window.location.reload();
	};
	const isApprovedByAdmin = async () => {
		try {
			const response = await api.job.isReadyForJob();

			if (response?.is_approved_by_admin) {
				navigate('/dashboard');
			} else {
				navigate('/pre-approved');
			}
		} catch (error) {
			console.error('Error checking user status:', error);
			if (error.response?.status === 401) {
				handleLogout();
			}
		}
	};

	useEffect(() => {
		isApprovedByAdmin();
	}, []);

	return (
		<Container maxWidth="md" sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
			<Box sx={{
				position: 'absolute',
				top: 10,
				right: 16,
				zIndex: 2
			}}>
				<Button
					variant="outlined"
					onClick={() => handleLogout()}
					sx={{
						textTransform: 'none',
						fontWeight: 'medium',
						border: 'none',
						color: '#DD4C40'
					}}
				>
					<LogoutOutlinedIcon /> Logout
				</Button>
			</Box>
			<Grid container justifyContent="center">
				<Grid size={{ xs: 12, sm: 10, md: 8 }}>
					{/* Logo */}
					<Box sx={{ textAlign: 'center', mt: 3 }}>
						<img src="/assets/images/auth_logo.png" alt="Conectar Logo" style={{ maxWidth: 150, height: '80px' }} />
					</Box>

					{/* Card */}
					<Box
						sx={{
							minHeight: '80vh',
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'center',
							alignItems: 'center',
							px: 2,
							textAlign: 'center',
						}}
					>
						<Typography color="success.main" sx={{ fontWeight: 'bold', fontSize: '2rem', mb: 1 }}>
							Congratulations!
						</Typography>

						<Typography color="text.secondary" sx={{ fontSize: '14px', mb: 3 }}>
							Your account has been created. Please wait For Admin Approval.
						</Typography>

						{/* Illustration */}
						<Box sx={{ mb: 3 }}>
							<img
								src="/assets/images/contractor_on_laptop.png"
								alt="Contractor"
								style={{ maxWidth: '100%', height: 'auto' }}
							/>
						</Box>
					</Box>
					{/* truck image */}
					<Box sx={{
						position: 'absolute',
						bottom: 16,
						left: 0,
						zIndex: 1,
					}}>
						<img src="/assets/images/side_truck.png" alt="truck logo" style={{ height: '250px' }} />
					</Box>

				</Grid>
			</Grid>
		</Container>
	);
};

export default PreApprovedPage;
