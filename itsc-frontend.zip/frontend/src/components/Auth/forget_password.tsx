import React, { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { TextField, Button, Container, Typography, Box, Grid, InputAdornment, IconButton } from '@mui/material';
import styles from '../../styles/login.module.css';
import { toast } from 'react-toastify'; // Import toast
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { api } from '../../utils/api';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';

interface ForgotForm {
    email: string;
    newPassword: string;
    confirmPassword: string;
    otp: string;
    otp1: string;
    otp2: string;
    otp3: string;
    otp4: string;
}

const ForgetPassword: React.FC = () => {
    var [state, setState] = useState<ForgotForm>({
        email: '',
        newPassword: '',
        confirmPassword: '',
        otp: '',
        otp1: '',
        otp2: '',
        otp3: '',
        otp4: '',
    });
    var { email, newPassword, confirmPassword, otp1, otp2, otp3, otp4 } = state;

    const inputRefOne = useRef<HTMLInputElement>(null);
    const inputRefTwo = useRef<HTMLInputElement>(null);
    const inputRefThree = useRef<HTMLInputElement>(null);
    const inputRefFour = useRef<HTMLInputElement>(null);

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [showVerification, setShowVerification] = useState<boolean>(false);
    const [apiOtp, setApiOtp] = useState('');
    const [showResetPassword, setShowResetPassword] = useState<boolean>(false); // State to control reset password section visibility
    const [showNewPassword, setShowNewPassword] = useState<boolean>(false); // State for new password visibility
    const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
    const navigate = useNavigate();

    var validationObject: any;
    if (!showVerification && !showResetPassword) {
        validationObject = {
            email: Yup.string()
                .required('Email is required')
                .email('Invalid email format'),
        };
    }
    if (showResetPassword) {
        validationObject = {
            newPassword: Yup.string()
                .required('InputCredential is required')
                .matches(
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                    "InputCredential must Contain minimum of 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
                ),
            confirmPassword: Yup.string()
                .required('Confirm InputCredential is required')
                .oneOf([Yup.ref('newPassword')], 'InputCredentials must match')
        };
    }
    if (showVerification) {
        validationObject = {
            otp1: Yup.string()
                .required(),
            otp2: Yup.string()
                .required(),
            otp3: Yup.string()
                .required(),
            otp4: Yup.string()
                .required(),
            otp: Yup.string()
                .required('Verification code is required')
                .matches(/^[0-9]+$/, "Verification code must be only digits")
                .min(4, 'Verification code must be exactly 4 digits')
                .max(4, 'Verification code must be exactly 4 digits'),
        };
    }
    const validationSchema = Yup.object().shape(validationObject);

    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }

    const onSubmit = async (formData: any) => {
        setIsLoading(true);
        var response;
        if (!showVerification && !showResetPassword) {
            const payload = {
                "email": formData.email,
            }
            response = await api.auth.forgotPassword(payload);
            if (response?.status === true) {
                const { message, otp } = response;
                // resetForm();
                setApiOtp(otp);
                setShowVerification(true);
                toast.success(message);
            } else {
                toast.error(response?.message);
            }
            setIsLoading(false);
        }
        if (showVerification) {
            const payload = {
                "email": formData.email,
                "otp": formData.otp,
            }
            response = await api.auth.otpVerification(payload);
            if (response?.status === true) {
                const { message } = response;
                setShowVerification(false);
                setShowResetPassword(true);
                toast.success(message);
                // resetForm();
            } else {
                toast.error(response?.message);
            }
            setIsLoading(false);
        }
        if (showResetPassword) {
            const payload = {
                "email": formData.email,
                "password": formData.newPassword,
            }
            response = await api.auth.resetPassword(payload);
            if (response?.status === true) {
                const { message } = response;
                toast.success(message);
                resetForm();
                navigate('/');
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        }
    };

    const resendOtp = async () => {
        setIsLoading(true);
        const payload = {
            "email": email,
        }
        const response = await api.auth.forgotPassword(payload);
        if (response?.status === true) {
            const { otp } = response;
            setApiOtp(otp);
            toast.success("OTP sent again to your email Id");
        } else {
            toast.error(response?.message);
        }
        setIsLoading(false);
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: value,
        }));
        // trigger(name);
    };

    const handleOtpChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, maxLength } = event.target;
        let verificationCode = '';
        switch (name) {
            case 'otp1':
                verificationCode = `${value}${otp2}${otp3}${otp4}`;
                break;
            case 'otp2':
                verificationCode = `${otp1}${value}${otp3}${otp4}`;
                break;
            case 'otp3':
                verificationCode = `${otp1}${otp2}${value}${otp4}`;
                break;
            case 'otp4':
                verificationCode = `${otp1}${otp2}${otp3}${value}`;
                break;
        }
        setState(prevState => ({
            ...prevState,
            [name]: value,
            otp: verificationCode
        }));
        // trigger(name);

        const [fieldName, fieldIndex] = name.split("otp");
        let fieldIntIndex = parseInt(fieldIndex, 10);
        // Check if no of char in field == maxlength
        if (value.length >= maxLength) {
            switch (fieldIntIndex) {
                case 1:
                    inputRefTwo.current?.focus();
                    break
                case 2:
                    inputRefThree.current?.focus();
                    break
                case 3:
                    inputRefFour.current?.focus();
                    break
            }
        }
    };
    const resetForm = () => {
        clearErrors();
        setState(prevState => ({
            ...prevState,
            email: '',
            newPassword: '',
            confirmPassword: '',
            otp: '',
            otp1: '',
            otp2: '',
            otp3: '',
            otp4: '',
        }));
        setIsLoading(false);
    }
    return (
        <Grid container className={styles.container}>
            <Grid container size={{ md: 6, sm: 12, xs: 12 }} display="flex" justifyContent="center" alignItems="center" className={styles.background}>
                <Grid>
                    <Box className={styles.signupPrompt}>
                        <a href="/" className={styles.noUnderline}>
                            <Typography variant="h4" component="h1" className={styles.excellenceText}>
                                Post your Requirement and get your delivery Partner
                            </Typography>
                        </a>
                        <Box className={styles.authImageContainer}>
                            {/* <Box className={styles.shadow}></Box> */}
                            <img src='/assets/images/authtruck.png' alt="Truck" className={styles.authImage} />
                        </Box>
                    </Box>
                </Grid>
            </Grid>
            <Grid container size={{ md: 6, sm: 12, xs: 12 }} display="flex" justifyContent="center" alignItems="center" className={styles.container}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }}>
                    <Container maxWidth="sm" sx={{ height: '100%' }} className={styles.mainBody}>
                        <Box className={styles.logoContainer}>
                            <img src="/assets/images/auth_logo.png" alt="Logo" className={styles.logo} />
                        </Box>
                        <form onSubmit={handleSubmit(onSubmit)} className='custom-Form'>
                            {!showVerification && !showResetPassword && (
                                <>
                                    <Box className={styles.loginForm}>
                                        <Box className={styles.formContainer}>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                                <Typography variant="h4" gutterBottom className={styles.formTitle}>
                                                    {showResetPassword ? 'Reset Password' : showVerification ? 'Verify OTP' : 'Forgot Password?'}
                                                </Typography>
                                                <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                                                    Please enter your registered email id, we will send a password reset link.
                                                </Typography>
                                                <TextField
                                                    label="Email ID"
                                                    variant="outlined"
                                                    fullWidth
                                                    margin="normal"
                                                    error={!!errors.email}
                                                    helperText={!!errors.email}
                                                    className={errors.email ? 'is-invalid' : ''}
                                                    {...register('email', { onChange: handleChange })}
                                                    value={email}
                                                    inputProps={{ autoComplete: "email" }}
                                                />
                                                <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                            </Box>
                                        </Box>
                                    </Box>
                                    <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} onClick={submitForm}>
                                        Send
                                    </Button>
                                </>
                            )}
                            {showVerification && (
                                <Box className={styles.formContainer}>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                        <Typography variant="h4" gutterBottom className={styles.formTitle}>
                                            Verify
                                        </Typography>
                                        <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                                            We sent a 4-digit OTP to your email Id <br /> <strong>{email}</strong> (OTP: {apiOtp})
                                        </Typography>
                                        <Box sx={{ display: 'flex', flexDirection: 'column', marginBottom: '20px' }}>
                                            <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "20px" }}>
                                                <TextField
                                                    variant="outlined"
                                                    margin="normal"
                                                    error={!!errors.otp1}
                                                    helperText={!!errors.otp1}
                                                    className={`otpField ${errors.otp1 ? 'is-invalid' : ''}`}
                                                    {...register('otp1', { onChange: handleOtpChange })}
                                                    inputProps={{ maxLength: 1 }}
                                                    inputRef={inputRefOne}
                                                />
                                                <TextField
                                                    variant="outlined"
                                                    margin="normal"
                                                    error={!!errors.otp2}
                                                    helperText={!!errors.otp2}
                                                    className={`otpField ${errors.otp2 ? 'is-invalid' : ''}`}
                                                    {...register('otp2', { onChange: handleOtpChange })}
                                                    inputProps={{ maxLength: 1 }}
                                                    inputRef={inputRefTwo}
                                                />
                                                <TextField
                                                    variant="outlined"
                                                    margin="normal"
                                                    error={!!errors.otp3}
                                                    helperText={!!errors.otp3}
                                                    className={`otpField ${errors.otp3 ? 'is-invalid' : ''}`}
                                                    {...register('otp3', { onChange: handleOtpChange })}
                                                    inputProps={{ maxLength: 1 }}
                                                    inputRef={inputRefThree}
                                                />
                                                <TextField
                                                    variant="outlined"
                                                    margin="normal"
                                                    error={!!errors.otp4}
                                                    helperText={!!errors.otp4}
                                                    className={`otpField ${errors.otp4 ? 'is-invalid' : ''}`}
                                                    {...register('otp4', { onChange: handleOtpChange })}
                                                    inputProps={{ maxLength: 1 }}
                                                    inputRef={inputRefFour}
                                                />
                                            </Box>
                                            <div className="invalid-feedback">{errors.otp?.message?.toString()}</div>
                                        </Box>

                                    </Box>
                                    <Box className={styles.buttonContainer} sx={{ marginTop: 2 }}>
                                        <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} onClick={submitForm}>Validate</Button>
                                    </Box>
                                    <Box className={styles.actionsContainer}>
                                        <Box>
                                            <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '5px' }}>
                                                Don’t get the code?
                                            </Typography>
                                            <Button color="primary" className={styles.resendButton} onClick={resendOtp}>
                                                Resend
                                            </Button>
                                        </Box>
                                    </Box>
                                </Box>
                            )}

                            {/* New Password Section */}
                            {showResetPassword && (
                                <Box className={styles.formContainer}>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                        <Typography variant="h4" gutterBottom className={styles.formTitle}>
                                            Reset Your Password
                                        </Typography>
                                        <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                                            Type your new password and repeat for confirming your password
                                        </Typography>
                                        <TextField
                                            label="New Password"
                                            variant="outlined"
                                            fullWidth
                                            margin="normal"
                                            error={!!errors.newPassword}
                                            helperText={!!errors.newPassword}
                                            className={errors.newPassword ? 'is-invalid' : ''}
                                            {...register('newPassword', { onChange: handleChange })}
                                            value={newPassword}
                                            type={showNewPassword ? 'text' : 'password'}
                                            InputProps={{
                                                endAdornment: (
                                                    <InputAdornment position="end">
                                                        <IconButton onClick={() => setShowNewPassword(!showNewPassword)}>
                                                            {!showNewPassword ? <VisibilityOff /> : <Visibility />}
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                            }}
                                        />
                                        <div className="invalid-feedback">{errors.newPassword?.message?.toString()}</div>
                                        <TextField
                                            label="Confirm Password"
                                            variant="outlined"
                                            fullWidth
                                            margin="normal"
                                            error={!!errors.confirmPassword}
                                            helperText={!!errors.confirmPassword}
                                            className={errors.confirmPassword ? 'is-invalid' : ''}
                                            {...register('confirmPassword', { onChange: handleChange })}
                                            value={confirmPassword}
                                            type={showConfirmPassword ? 'text' : 'password'}
                                            InputProps={{
                                                endAdornment: (
                                                    <InputAdornment position="end">
                                                        <IconButton onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                                                            {!showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                            }}
                                        />
                                        <div className="invalid-feedback">{errors.confirmPassword?.message?.toString()}</div>
                                        <Box className={styles.buttonContainer} sx={{ marginTop: 2 }}>
                                            <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} onClick={submitForm}>Reset Password</Button>
                                        </Box>
                                    </Box>
                                </Box>
                            )}
                        </form>

                        <Box className={styles.authBottomContainer} style={{ marginTop: '40px' }}>
                            <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '10px' }}>
                                Already have an account?
                            </Typography>
                            <Link to="/" color="primary" className={styles.signupButton}>
                                Login
                            </Link>
                        </Box>
                        {/* <Typography variant="body2" color="textSecondary" className={styles.copyright}>
                            Copyright © 2025 ITSC.
                        </Typography> */}
                    </Container>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default ForgetPassword;