import React from 'react'
import { Box, Typography, Card, CardContent } from '@mui/material';
import { Link } from 'react-router-dom';

const SubscriptionConfirm = () => {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Card 
            sx={{ 
                maxWidth: 400, 
                borderRadius: 2, 
                boxShadow: 3, 
                padding: 2 
            }}
        >
            <CardContent>
                <Typography variant="h5" color="success.main" align="center" gutterBottom>
                    Payment Successful
                </Typography>
                <Box display="flex" justifyContent="center" alignItems="center" mb={2}>
                    <img src='/assets/images/success.png' alt="Success" style={{ maxWidth: '100%', height: 'auto' }} />
                </Box>
                <Typography variant="body1" align="center" gutterBottom>
                    Your subscription payment is complete
                </Typography>
                <Typography align="center">
                    Go to <Link to="/login">Sign In</Link> page
                </Typography>
            </CardContent>
        </Card>
    </Box>
  )
}

export default SubscriptionConfirm
