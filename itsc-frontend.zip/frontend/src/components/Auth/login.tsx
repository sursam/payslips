import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { TextField, Button, Container, Typography, Box, Checkbox, FormControlLabel, InputAdornment, IconButton, Grid } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import styles from '../../styles/login.module.css';
import { toast } from 'react-toastify';
import { api } from '../../utils/api';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { v4 as uuid } from "uuid";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import { Padding } from '@mui/icons-material';
import { ProfileProps } from "../../types";

interface LoginForm {
    email: string;
    password: string;
    country_code: string;
    mobile: string;
    mobile_number: string;
    otp: string;
    otp1: string;
    otp2: string;
    otp3: string;
    otp4: string;
}

const Login: React.FC = () => {
    const [rememberMe, setRememberMe] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [showEmailLogin, setShowEmailLogin] = useState<boolean>(true);
    const [showMobileLogin, setShowMobileLogin] = useState<boolean>(false);
    const [showVerification, setShowVerification] = useState<boolean>(false);
    const [loginOtp, setLoginOtp] = useState('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const navigate = useNavigate();
    var deviceToken = (typeof localStorage !== 'undefined') ? localStorage.getItem("device-token") : null;
    var [state, setState] = useState<LoginForm>({
        email: '',
        password: '',
        country_code: '1',
        mobile: '',
        mobile_number: '',
        otp: '',
        otp1: '',
        otp2: '',
        otp3: '',
        otp4: '',
    });
    var { email, password, country_code, mobile, mobile_number, otp1, otp2, otp3, otp4 } = state;

    const inputRefOne = useRef<HTMLInputElement>(null);
    const inputRefTwo = useRef<HTMLInputElement>(null);
    const inputRefThree = useRef<HTMLInputElement>(null);
    const inputRefFour = useRef<HTMLInputElement>(null);

    var validationObject: any;
    if (showEmailLogin) {
        validationObject = {
            email: Yup.string()
                .required('Email is required')
                .email('Invalid email format'),
            password: Yup.string().required('InputCredential is required'),
        };
    }
    if (showMobileLogin) {
        const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/
        validationObject = {
            country_code: Yup.string()
                .required('Country code is required'),
            mobile: Yup.string()
                .required('Mobile number is required')
                .matches(phoneRegExp, 'Mobile number is not valid'),
        };
    }
    if (showVerification) {
        validationObject = {
            otp1: Yup.string()
                .required(),
            otp2: Yup.string()
                .required(),
            otp3: Yup.string()
                .required(),
            otp4: Yup.string()
                .required(),
            otp: Yup.string()
                .required('Verification code is required')
                .matches(/^[0-9]+$/, "Verification code must be only digits")
                .min(4, 'Verification code must be exactly 4 digits')
                .max(4, 'Verification code must be exactly 4 digits'),
        };
    }
    const validationSchema = Yup.object().shape(validationObject);

    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }

    const onSubmit = async (formData: any) => {
        setIsLoading(true);
        if (!deviceToken) {
            deviceToken = uuid();
            localStorage.setItem("device-token", uuid())
        }
        var response;
        if (showEmailLogin) {
            if (rememberMe) {
                localStorage.setItem('rememberedEmail', email);
                localStorage.setItem('rememberedPassword', password);
            } else {
                localStorage.removeItem('rememberedEmail');
                localStorage.removeItem('rememberedPassword');
            }
            const loginPayload = {
                "email": formData.email,
                "password": formData.password,
                "device_type": 1, // 1:web, 2:android , 3: iOS
                "device_token": deviceToken,
                "fcm_token": deviceToken,
            }

            // response = await api.auth.login(loginPayload, dispatch);
            response = await api.auth.login(loginPayload);

            if (response?.status) {
                if (response?.user?.completed_steps == 4) {
                    const { message } = response;
                    // check is he post job or not
                    const isReadyForJob = await api.job.isReadyForJob();

                    if (isReadyForJob?.is_approved_by_admin) {
                        toast.success(message);
                        resetForm();
                        window.location.href = '/dashboard';
                    } else {
                        window.location.href = '/pre-approved';
                    }
                } else {
                    // navigate('/sign-up');
                    navigate(`/sign-up`);
                }
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        }
        if (showMobileLogin) {
            const loginPayload = {
                "country_code": formData.country_code,
                "mobile": formData.mobile,
                "device_type": 1, // 1:web, 2:android , 3: iOS
                "device_token": deviceToken,
            }
            response = await api.auth.mobileLogin(loginPayload);
            if (response?.status == true) {
                const { message } = response;
                console.log("OTP -> ", response.verification_code);

                setLoginOtp(response.verification_code);
                setShowMobileLogin(false);
                setShowEmailLogin(false);
                setShowVerification(true);
                toast.success(message);
                // resetForm();
            } else {
                toast.error(response?.message);
            }
            setIsLoading(false);
        }
        if (showVerification) {
            const loginPayload = {
                "mobile": formData.mobile,
                "otp": formData.otp,
            }
            response = await api.auth.loginVerification(loginPayload);

            if (response?.status === true) {
                if (response?.user?.completed_steps == 4) {
                    resetForm();
                    // check is he post job or not
                    const isReadyForJob = await api.job.isReadyForJob();

                    if (isReadyForJob?.is_approved_by_admin) {
                        window.location.href = '/dashboard';
                    } else {
                        window.location.href = '/pre-approved';
                    }

                } else {
                    // call the profile
                    // const profile = await api.profile.fetchProfile();
                    navigate(`/sign-up`);
                }
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        }

    };
    const resendOtp = async () => {
        setIsLoading(true);
        const loginPayload: any = {
            "country_code": country_code,
            "mobile": mobile,
            "device_type": 1, // 1:web, 2:android , 3: iOS
            "device_token": deviceToken,
        }
        const response = await api.auth.mobileLogin(loginPayload);
        if (response?.status === true) {
            // const { message } = response;
            setLoginOtp(response.verification_code);
            toast.success("OTP sent again to your mobile number");
        } else {
            toast.error(response?.message);
        }
        setIsLoading(false);
    };
    const resetForm = () => {
        clearErrors();
        setState(prevState => ({
            ...prevState,
            email: '',
            password: '',
            country_code: '1',
            mobile: '',
            mobile_number: '',
            otp: '',
            otp1: '',
            otp2: '',
            otp3: '',
            otp4: '',
        }));
        setIsLoading(false);
    }

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: value,
        }));
        // trigger(name);
    };
    const onMobileChange = (value: any, data: any, event: any, formattedValue: any) => {
        // console.log(data.dialCode, value.slice(data.dialCode.length));
        setState(prevState => ({
            ...prevState,
            mobile_number: formattedValue,
            country_code: data.dialCode,
            mobile: value.slice(data.dialCode.length),
        }));
    };

    const handleOtpChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, maxLength } = event.target;
        let verificationCode = '';
        switch (name) {
            case 'otp1':
                verificationCode = `${value}${otp2}${otp3}${otp4}`;
                break;
            case 'otp2':
                verificationCode = `${otp1}${value}${otp3}${otp4}`;
                break;
            case 'otp3':
                verificationCode = `${otp1}${otp2}${value}${otp4}`;
                break;
            case 'otp4':
                verificationCode = `${otp1}${otp2}${otp3}${value}`;
                break;
        }
        setState(prevState => ({
            ...prevState,
            [name]: value,
            otp: verificationCode
        }));
        // trigger(name);

        const [fieldName, fieldIndex] = name.split("otp");
        let fieldIntIndex = parseInt(fieldIndex, 10);
        // Check if no of char in field == maxlength
        if (value.length >= maxLength) {
            switch (fieldIntIndex) {
                case 1:
                    inputRefTwo.current?.focus();
                    break
                case 2:
                    inputRefThree.current?.focus();
                    break
                case 3:
                    inputRefFour.current?.focus();
                    break
            }
        }
    };

    const handleLoginForm = () => {
        setShowMobileLogin(!showMobileLogin);
        setShowEmailLogin(!showEmailLogin);
    }
    const handleMobileLoginForm = () => {
        setShowMobileLogin(true);
        setShowEmailLogin(false);
        setShowVerification(false);
    }

    useEffect(() => {
        const rememberedEmail = localStorage.getItem('rememberedEmail');
        const rememberedPassword = localStorage.getItem('rememberedPassword');
        if (rememberedEmail || rememberedPassword) {
            setRememberMe(true);
            if (rememberedEmail) {
                setState(prevState => ({
                    ...prevState,
                    email: rememberedEmail,
                }));
            }
            if (rememberedPassword) {
                setState(prevState => ({
                    ...prevState,
                    password: rememberedPassword,
                }));
            }
        }
    }, []);

    return (

        <Grid container className={styles.container}>
            <Grid container size={{ md: 6, sm: 12, xs: 12 }} display="flex" justifyContent="center" alignItems="center" className={styles.background}>
                <Grid>
                    <Box className={styles.signupPrompt}>
                        <a href="/" className={styles.noUnderline}>
                            <Typography variant="h4" component="h1" className={styles.excellenceText}>
                                Post your Requirement and get your delivery Partner
                            </Typography>
                        </a>
                        <Box className={styles.authImageContainer}>
                            <Box className={styles.shadow}></Box>
                            <img src='/assets/images/truck.png' alt="Truck" className={styles.authImage} />
                        </Box>
                    </Box>
                </Grid>
            </Grid>
            <Grid container size={{ md: 6, sm: 12, xs: 12 }} display="flex" justifyContent="center" alignItems="center" className={styles.container}>
                <Grid>
                    <Container maxWidth="sm" sx={{ height: '100%' }} className={styles.mainBody}>
                        <Box className={styles.logoContainer}>
                            <img src="/assets/images/auth_logo.png" alt="Logo" className={styles.logo} />
                        </Box>
                        <form onSubmit={handleSubmit(onSubmit)} className='custom-Form'> {/* Wrap inputs in a form */}
                            <Box className={styles.loginForm}>
                                <Box className={styles.formContainer}>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                        {!showVerification ?
                                            <>
                                                <Typography variant="h4" gutterBottom className={styles.formTitle}>
                                                    Login to your account
                                                </Typography>
                                                <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                                                    Thank you for get back Conectar web applications, let's access your account and start posting your job requirement.
                                                </Typography>
                                            </>
                                            :
                                            <>
                                                <Typography variant="h4" gutterBottom className={styles.formTitle}>
                                                    Verify
                                                </Typography>
                                                <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                                                    We sent a 4-digit OTP to your mobile number <br /> <strong>{mobile}</strong>
                                                </Typography>
                                            </>
                                        }
                                        {showEmailLogin && (
                                            <>
                                                <TextField
                                                    label="Email ID"
                                                    variant="outlined"
                                                    fullWidth
                                                    margin="normal"
                                                    error={!!errors.email}
                                                    helperText={!!errors.email}
                                                    className={errors.email ? 'is-invalid' : ''}
                                                    {...register('email', { onChange: handleChange })}
                                                    value={email}
                                                    inputProps={{ autoComplete: "email" }}
                                                />
                                                <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                                <TextField
                                                    label="Password"
                                                    type={showPassword ? 'text' : 'password'}
                                                    variant="outlined"
                                                    fullWidth
                                                    margin="normal"
                                                    className={errors.password ? 'is-invalid' : ''}
                                                    {...register('password', { onChange: handleChange })}
                                                    value={password}
                                                    InputProps={{
                                                        endAdornment: (
                                                            <InputAdornment position="end">
                                                                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                                                                    {!showPassword ? <VisibilityOff /> : <Visibility />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        ),
                                                    }}
                                                    error={!!errors.password}
                                                    helperText={!!errors.password}
                                                    inputProps={{ autoComplete: "password" }}
                                                />
                                                <div className="invalid-feedback">{errors.password?.message?.toString()}</div>
                                                <Box className={styles.actionsContainer}>
                                                    <FormControlLabel
                                                        control={
                                                            <Checkbox
                                                                checked={rememberMe}
                                                                onChange={(e) => setRememberMe(e.target.checked)}
                                                                color="primary"
                                                            />
                                                        }
                                                        label="Remember Me"
                                                    />
                                                    <Typography variant="body2" color="textSecondary" className={styles.forgotPassword} onClick={() => navigate('/forgot-password')}>
                                                        Forgot Password?
                                                    </Typography>
                                                </Box>
                                                <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} onClick={submitForm}>
                                                    Login
                                                </Button>
                                                <Button type='button' variant="contained" color="primary" className={`${styles.otherButton} nomargin`} onClick={handleLoginForm}>
                                                    Login with mobile number
                                                </Button>
                                            </>
                                        )}
                                        {showMobileLogin && (
                                            <>
                                                <PhoneInput
                                                    country={'us'}
                                                    value={mobile_number}
                                                    onChange={onMobileChange}
                                                    inputProps={{
                                                        name: 'mobile',
                                                        autoFocus: true,
                                                    }}
                                                    containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                                                    inputStyle={{ borderColor: errors?.mobile ? '#d32f2f' : '#ccc', }}
                                                />
                                                <div className="invalid-feedback">{errors.mobile?.message?.toString()}</div>
                                                <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} style={{ marginTop: '20px' }} onClick={submitForm}>
                                                    Send Code
                                                </Button>
                                                <Button type='button' variant="contained" color="primary" className={styles.otherButton} onClick={handleLoginForm}>
                                                    Login with email
                                                </Button>
                                            </>
                                        )}
                                        {showVerification && (
                                            <Box className={styles.formContainer}>
                                                <Box sx={{ display: 'flex', flexDirection: 'column', marginBottom: '20px' }}>
                                                    <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "20px" }}>
                                                        <TextField
                                                            variant="outlined"
                                                            margin="normal"
                                                            error={!!errors.otp1}
                                                            helperText={!!errors.otp1}
                                                            className={`otpField ${errors.otp1 ? 'is-invalid' : ''}`}
                                                            {...register('otp1', { onChange: handleOtpChange })}
                                                            inputProps={{ maxLength: 1 }}
                                                            inputRef={inputRefOne}
                                                        />
                                                        <TextField
                                                            variant="outlined"
                                                            margin="normal"
                                                            error={!!errors.otp2}
                                                            helperText={!!errors.otp2}
                                                            className={`otpField ${errors.otp2 ? 'is-invalid' : ''}`}
                                                            {...register('otp2', { onChange: handleOtpChange })}
                                                            inputProps={{ maxLength: 1 }}
                                                            inputRef={inputRefTwo}
                                                        />
                                                        <TextField
                                                            variant="outlined"
                                                            margin="normal"
                                                            error={!!errors.otp3}
                                                            helperText={!!errors.otp3}
                                                            className={`otpField ${errors.otp3 ? 'is-invalid' : ''}`}
                                                            {...register('otp3', { onChange: handleOtpChange })}
                                                            inputProps={{ maxLength: 1 }}
                                                            inputRef={inputRefThree}
                                                        />
                                                        <TextField
                                                            variant="outlined"
                                                            margin="normal"
                                                            error={!!errors.otp4}
                                                            helperText={!!errors.otp4}
                                                            className={`otpField ${errors.otp4 ? 'is-invalid' : ''}`}
                                                            {...register('otp4', { onChange: handleOtpChange })}
                                                            inputProps={{ maxLength: 1 }}
                                                            inputRef={inputRefFour}
                                                        />
                                                    </Box>
                                                    <div className="invalid-feedback">{errors.otp?.message?.toString()}</div>
                                                </Box>
                                                <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.loginButton}`} onClick={submitForm}>Validate</Button>
                                                <Box>
                                                    <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '5px' }}>
                                                        Don’t get the code?
                                                    </Typography>
                                                    <Button color="primary" className={styles.resendButton} onClick={resendOtp}>
                                                        Resend
                                                    </Button>
                                                </Box>
                                            </Box>
                                        )}
                                    </Box>
                                </Box>
                            </Box>
                        </form>

                        <Box className={styles.authBottomContainer}>
                            {!showVerification ?
                                <>
                                    <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '10px' }}>
                                        Don’t have an account?
                                    </Typography>
                                    <Link to="/sign-up" color="primary" className={styles.signupButton}>
                                        Sign Up
                                    </Link>
                                </>
                                :
                                <>
                                    <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '10px' }}>
                                        Login with another number?
                                    </Typography>
                                    <Link to="#" onClick={handleMobileLoginForm} color="primary" className={styles.signupButton}>
                                        click here
                                    </Link>
                                </>
                            }

                        </Box>
                        {/* <Typography variant="body2" color="textSecondary" className={styles.copyright}>
                            Copyright © 2025 ITSC.
                        </Typography> */}
                    </Container>
                </Grid>
            </Grid>

        </Grid >
    );
};

export default Login;
