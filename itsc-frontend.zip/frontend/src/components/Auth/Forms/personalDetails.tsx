import { TextField, Typography, Box, Autocomplete } from '@mui/material';
import styles from '../../../styles/registration.module.css';
import { AccountBoxOutlined } from '@mui/icons-material';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    handleDateChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleStateChange: (event: React.ChangeEvent<HTMLInputElement>, value: any) => void;
    handleStateInputChange: (event: React.ChangeEvent<HTMLInputElement>, value: any) => void;
    handleCityChange: (event: React.ChangeEvent<HTMLInputElement>, value: any) => void;
    handleCityInputChange: (event: React.ChangeEvent<HTMLInputElement>, value: any) => void;
    handleFileChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleDragEnter: (event: any) => void;
    handleDragOver: (event: any) => void;
    handleDragLeave: (event: any) => void;
    handleDrop: (event: any) => void;
    firstName: string;
    lastName: string;
    dob: string;
    states: any;
    stateName: string;
    cities: any;
    cityName: string;
    zipCode: string;
    streetAddress: string;
    imageUrl: string;
    isDragging: boolean;
}

const PersonalDetails: React.FC<ChildProps> = ({ errors, register, handleChange, handleDateChange, handleStateChange, handleStateInputChange, handleCityChange, handleCityInputChange, firstName, lastName, dob, states, stateName, cities, cityName, zipCode, streetAddress, imageUrl, handleFileChange, handleDragEnter, handleDragOver, handleDragLeave, handleDrop, isDragging }) => {
    return (
        <Box className={styles.formContainer}>
            <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                <Box className={`${styles.fileUploadContainer} ${isDragging ? styles.dragging : ''}`}
                    onDragEnter={handleDragEnter}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}>
                    <Typography className={styles.ariaLabel}>
                        Profile Image
                    </Typography>
                    <label htmlFor="file-upload" className={styles.fileUpload} style={{ display: "flex", flexDirection: 'column', alignItems: 'center' }}>
                        {imageUrl ? (
                            <img
                                src={imageUrl}
                                className={styles.profileImage}
                                alt="Profile Image"
                            />
                        ) :
                            <AccountBoxOutlined style={{ width: '70px', height: '70px', color: '#AAAAAA' }} />
                        }
                        <span>
                            Drag and drop an image or{" "}
                            <span className="text-primary text-decoration-underline">
                                Browse
                            </span>
                        </span>
                    </label>
                    <label className={styles.fileFieldContainer}>
                        <TextField
                            type="file"
                            id="file-upload"
                            {...register('profileImage')}
                            onChange={handleFileChange}
                            className={`${styles.fileField} ${errors.profileImage ? 'is-invalid' : ''}`}
                            inputProps={{ accept: 'image/jpeg,image/png' }}
                        />
                    </label>
                </Box>
            </Box>
            <Box>
                {errors.profileImage && (
                    <Typography variant="body2" color="error" sx={{ mt: 1 }}>
                        {errors.profileImage.message}
                    </Typography>
                )}
            </Box>
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <TextField
                        label="First Name"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.firstName}
                        helperText={!!errors?.firstName}
                        className={`${styles.formControl} ${errors?.firstName ? 'is-invalid' : ''}`}
                        {...register('firstName', { onChange: handleChange })}
                        value={firstName}
                        inputProps={{ autoComplete: "firstName" }}
                    />
                    <div className="invalid-feedback">{errors.firstName?.message?.toString()}</div>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <TextField
                        label="Last Name"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.lastName}
                        helperText={!!errors?.lastName}
                        className={`${styles.formControl} ${errors?.lastName ? 'is-invalid' : ''}`}
                        {...register('lastName', { onChange: handleChange })}
                        value={lastName}
                        inputProps={{ autoComplete: "lastName" }}
                    />
                    <div className="invalid-feedback">{errors.lastName?.message?.toString()}</div>
                </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <TextField
                        label="Date of Birth"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        type="date"
                        error={!!errors?.dob}
                        helperText="" // Remove to avoid duplicate
                        className={`${styles.formControl} ${errors?.dob ? 'is-invalid' : ''}`}
                        {...register('dob', { onChange: handleDateChange })}
                        value={dob || ''} // Handle null/undefined values
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                    <div className="invalid-feedback">{errors.dob?.message?.toString()}</div>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <Autocomplete
                        disablePortal
                        options={Array.isArray(states) ? states : []}
                        renderInput={(params) => <TextField {...params} label="State" />}
                        margin="normal"
                        className={`formSelect ${styles.formControl} ${errors?.userState ? 'is-invalid' : ''}`}
                        {...register('userState')}
                        onChange={handleStateChange}
                        onInputChange={handleStateInputChange}
                        value={stateName}
                        noOptionsText="No state found"
                    />
                    <div className="invalid-feedback">{errors.userState?.message?.toString()}</div>
                </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <Autocomplete
                        disablePortal
                        options={Array.isArray(cities) ? cities : []}
                        renderInput={(params) => <TextField {...params} label="City" />}
                        margin="normal"
                        className={`formSelect ${styles.formControl} ${errors?.city ? 'is-invalid' : ''}`}
                        {...register('city')}
                        onChange={handleCityChange}
                        onInputChange={handleCityInputChange}
                        value={cityName}
                        noOptionsText="No city found"
                    />
                    <div className="invalid-feedback">{errors.city?.message?.toString()}</div>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <TextField
                        label="Zip Code"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.zipCode}
                        helperText={!!errors?.zipCode}
                        className={`${styles.formControl} ${errors?.zipCode ? 'is-invalid' : ''}`}
                        {...register('zipCode', { onChange: handleChange })}
                        value={zipCode}
                        onChange={(e) => {
                            const numericValue = e.target.value.replace(/\D/g, '').slice(0, 6);
                            e.target.value = numericValue;
                            handleChange(e);
                        }}
                        inputProps={{
                            autoComplete: "zipCode",
                            inputMode: "numeric"
                        }}
                    />
                    <div className="invalid-feedback">
                        {errors?.zipCode?.message}
                    </div>
                </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                    <TextField
                        label="Street Address"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.streetAddress}
                        helperText={!!errors?.streetAddress}
                        className={`${styles.formControl} ${errors?.streetAddress ? 'is-invalid' : ''}`}
                        {...register('streetAddress', { onChange: handleChange })}
                        value={streetAddress}
                        inputProps={{ autoComplete: "streetAddress" }}
                    />
                    <div className="invalid-feedback">{errors.streetAddress?.message?.toString()}</div>
                </Box>
            </Box>
        </Box >

    );
};

export default PersonalDetails;
