import { use, useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { TextField, Button, Container, Typography, Select, MenuItem, FormControl, InputLabel, Box, Checkbox, FormControlLabel, InputAdornment, IconButton, Grid, FormHelperText } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import styles from '../../../styles/registration.module.css';


interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleCheckboxChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    password: string;
    confirmPassword: string;
    acceptedTerms: boolean;
    acceptedPolicy: boolean;
    acceptedOthers: boolean;
}
const CreatePassword: React.FC<ChildProps> = ({ errors, register, handleChange, handleCheckboxChange, password, confirmPassword, acceptedTerms, acceptedPolicy, acceptedOthers }) => {
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
    return (
        <Box className={styles.formContainer}>
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                <Box sx={{ width: "100%" }}>
                    <TextField
                        label="Password"
                        type={showPassword ? 'text' : 'password'}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        className={`${styles.formControl} ${errors?.password ? 'is-invalid' : ''}`}
                        {...register('password', { onChange: handleChange })}
                        value={password}
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                                        {!showPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                        error={!!errors.password}
                        helperText={!!errors.password}
                        inputProps={{ autoComplete: "password" }}
                    />
                    <div className="invalid-feedback" >{errors.password?.message?.toString()}</div>
                    <p className={styles.helpText}>Have at least 8 characters</p>
                    <p className={styles.helpText}>Have at least one numeric characters</p>
                </Box>
                <Box sx={{ width: "100%" }}>
                    <TextField
                        label="Confirm Password"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        type={showConfirmPassword ? 'text' : 'password'}
                        value={confirmPassword}
                        // onChange={(e) => setConfirmPassword(e.target.value)}
                        error={!!errors?.confirmPassword}
                        helperText={!!errors?.confirmPassword}
                        className={`${styles.formControl} ${errors?.confirmPassword ? 'is-invalid' : ''}`}
                        {...register('confirmPassword', { onChange: handleChange })}
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                                        {!showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />
                    <div className="invalid-feedback" >{errors.confirmPassword?.message?.toString()}</div>
                    <p className={styles.helpText}>Have one special characters (Exp : $%&#@) </p>
                    <p className={styles.helpText}>Have at least one uppercase characters</p>
                </Box>
            </Box>
            <hr className={styles.hr} />
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                <Box sx={{ width: "100%" }}>
                    <FormControl error={!!errors?.acceptedTerms}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    color="secondary"
                                    {...register('acceptedTerms', { onChange: handleCheckboxChange })}
                                    value={acceptedTerms}
                                    checked={acceptedTerms}
                                />
                            }
                            label={
                                <Typography color="textSecondary" className={styles.formText}>
                                    I accept the{' '}
                                    <Link
                                        to="https://www.connectaload.com/terms-and-condition/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={styles.link}
                                    >
                                        <strong>Terms & Conditions</strong>
                                    </Link>.
                                </Typography>
                            }
                        />
                        <FormHelperText>{!acceptedTerms ? errors?.acceptedTerms?.message : ''}</FormHelperText>
                    </FormControl>

                    <FormControl error={!!errors?.acceptedPolicy}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    color="secondary"
                                    {...register('acceptedPolicy', { onChange: handleCheckboxChange })}
                                    value={acceptedPolicy}
                                    checked={acceptedPolicy}
                                />
                            }
                            label={
                                <Typography color="textSecondary" className={styles.formText}>
                                    I accept the{' '}
                                    <Link
                                        to="https://www.connectaload.com/privacy-policy/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={styles.link}
                                    >
                                        <strong>Privacy Policy</strong>
                                    </Link>.
                                </Typography>
                            }
                        />
                        <FormHelperText>{!acceptedPolicy ? errors?.acceptedPolicy?.message : ''}</FormHelperText>
                    </FormControl>
                </Box>
                <Box sx={{ width: "100%" }}>
                    <FormControl error={!!errors?.acceptedOthers}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    color="secondary"
                                    {...register('acceptedOthers', { onChange: handleCheckboxChange }

                                    )}
                                    value={acceptedOthers}
                                    checked={acceptedOthers}
                                />
                            }
                            label={
                                <Typography color="textSecondary" className={styles.formText}>
                                    I agree to all the{' '}
                                    <Link
                                        to="https://www.connectaload.com/services/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={styles.link}
                                    >
                                        <strong>Terms & Conditions</strong> and <strong>Services</strong>
                                    </Link>.
                                </Typography>
                            }
                        />
                        <FormHelperText>{!acceptedOthers ? errors?.acceptedOthers?.message : ''}</FormHelperText>
                    </FormControl>
                </Box>
            </Box >
        </Box >

    );
};

export default CreatePassword;
