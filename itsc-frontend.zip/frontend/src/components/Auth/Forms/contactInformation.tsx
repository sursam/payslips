import { TextField, Box } from '@mui/material';
import styles from '../../../styles/registration.module.css';
import PhoneInput from 'react-phone-input-2';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onMobileChange: (value: any, data: any, event: React.ChangeEvent<HTMLInputElement>, formattedValue: any) => void;
    email: string;
    mobileNumber: string;
}
const ContactInformation: React.FC<ChildProps> = ({ errors, register, handleChange, onMobileChange, email, mobileNumber }) => {
    return (
        <Box className={styles.formContainer}>
            <Box sx={{ display: "flex", flexDirection: { xs: 'column', sm: 'column', md: 'column', lg: 'row' }, justifyContent: "space-between", gap: { xs: '0', sm: '20px', md: '30px' } }}>
                {/* Email Input */}
                <Box sx={{ flex: 1 }}>
                    <TextField
                        label="Email ID"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.email}
                        helperText={!!errors?.email}
                        className={`${styles.formControl} ${errors?.email ? 'is-invalid' : ''}`}
                        {...register('email', { onChange: handleChange })}
                        value={email}
                    />
                    <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                </Box>
                {/* Phone Input */}
                <Box sx={{ flex: 1 }}>
                    <PhoneInput
                        country={'us'}
                        value={mobileNumber}
                        onChange={onMobileChange}
                        containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                        inputProps={{
                            name: 'mobile',
                            autoFocus: true,
                        }}
                        inputStyle={{
                            borderColor: errors?.mobile ? '#d32f2f' : '#ccc',
                        }}
                    />
                    <div className="invalid-feedback" >{errors.mobile?.message?.toString()}</div>
                </Box>
            </Box>
        </Box >

    );
};

export default ContactInformation;
