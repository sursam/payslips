import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CardContent, Card, Typography, CardActionArea, Box, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Slide, Grid } from '@mui/material';
import { TransitionProps } from '@mui/material/transitions';
import styles from '../../../styles/registration.module.css';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    paymentTerms: number;
    handlePaymentTerms: (value: number) => void;
}

const Transition = React.forwardRef(function Transition(
    props: TransitionProps & {
        children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>,
) {
    return <Slide direction="down" ref={ref} {...props} />;
});

const MakePayment: React.FC<ChildProps> = ({ errors, register, handleChange, paymentTerms, handlePaymentTerms }) => {
    const [selectedValue, setSelectedValue] = useState<any>(paymentTerms || '7');
    const [selectedOtherValue, setSelectedOtherValue] = useState<string | null>(null);

    // Effect to set default value and notify parent component
    useEffect(() => {
        if (!paymentTerms) {
            handlePaymentTerms(7);
            setSelectedValue('7');
        }
    }, [paymentTerms, handlePaymentTerms]);

    const handleSelect = (value: string | number) => {
        switch (value) {
            case 'Others':
                setOpenDialog(!openDialog);
                break;
            case 'Instant Payment':
                setSelectedValue(value);
                setSelectedOtherValue(null);
                break;
            default:
                setSelectedValue(value);
                const numericValue = Number(value);
                handlePaymentTerms(numericValue);
                if (openDialog) {
                    setOpenDialog(!openDialog);
                    setSelectedOtherValue('Others');
                } else {
                    setSelectedOtherValue(null);
                }
        }
    };
    const options = [
        { label: 'Instant Payment', unit: '' },
        { label: '7', unit: 'Days' },
        { label: '15', unit: 'Days' },
        { label: '30', unit: 'Days' },
        { label: 'Others', unit: '' },
    ];

    const [openDialog, setOpenDialog] = React.useState(false);

    const handleDialogOpen = () => {
        setOpenDialog(!openDialog);
    };

    const elements = [];
    for (let i = 1; i <= 30; i++) {
        elements.push(
            <Grid size={{ md: 2, sm: 2, xs: 2 }} className={styles.dayContainer} key={i}>
                <Typography variant="h5" className={`${styles.dayLink} ${(selectedOtherValue == 'Others' && selectedValue === i) ? styles.selected : ''}`} onClick={() => handleSelect(i)}>
                    {i}
                </Typography>
            </Grid>
        );
    }

    const getDaySuffix = (day: any) => {
        if (day > 3 && day < 21) return 'th'; // Handles 11th, 12th, 13th, etc.
        switch (day % 10) {
            case 1:
                return 'st';
            case 2:
                return 'nd';
            case 3:
                return 'rd';
            default:
                return 'th';
        }
    };

    return (
        <>
            <Box
                sx={{
                    width: '100%',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(min(175px, 100%), 1fr))',
                    gap: 2,
                    marginTop: '25px',
                    marginBottom: '50px',
                }}
            >
                {options.map((option) => (
                    <Card key={option.label} className={styles.paymentOption}>
                        <CardActionArea
                            onClick={() => handleSelect(option.label)}
                            sx={{
                                height: '100%',
                                backgroundColor: (selectedValue === option.label || selectedOtherValue === option.label) ? '#E3F2FD' : 'transparent',
                                border: (selectedValue === option.label || selectedOtherValue === option.label) ? '2px solid #2196F3' : '1px solid transparent',
                                // transform: selectedValue === option.label ? 'scale(1.02)' : 'scale(1)',
                                transition: 'all 0.3s ease-in-out',
                                '&:hover': {
                                    backgroundColor: '#F5F5F5',
                                    // transform: 'scale(1.01)',
                                },
                            }}
                        >
                            <CardContent className={styles.paymentBox} sx={{ display: 'flex', gap: '25px', padding: 2 }}>
                                {option.unit ? (
                                    <>
                                        <Typography
                                            variant="h5"
                                            component="div"
                                            sx={{
                                                border: '1px solid #DCEFFF',
                                                backgroundColor: '#DCEFFF',
                                                borderRadius: '50%',
                                                padding: '1px',
                                                width: '40px',
                                                height: '40px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                textAlign: 'center',
                                                fontSize: '16px',
                                                fontWeight: '600',
                                            }}
                                        >
                                            {option.label}
                                        </Typography>
                                        <Typography
                                            variant="body2"
                                            color="text.secondary"
                                            sx={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                fontSize: '16px',
                                                fontWeight: '500',
                                                fontFamily: 'Poppins',
                                            }}
                                        >
                                            {option.unit}
                                        </Typography>
                                    </>
                                ) : (
                                    <Typography
                                        variant="h5"
                                        component="div"
                                        sx={{ fontSize: '18px', fontWeight: '600', fontFamily: 'Poppins', }}
                                    >
                                        {option.label}
                                    </Typography>
                                )}
                            </CardContent>
                        </CardActionArea>
                    </Card>
                ))}
            </Box>

            {errors.paymentTerms && (
                <Typography
                    variant="body2"
                    color="error"
                    sx={{ mt: 1, fontSize: '14px', fontFamily: 'Poppins' }}
                >
                    {errors.paymentTerms.message}
                </Typography>
            )}

            {(selectedValue != null && selectedValue != 'Others' && selectedValue != 'Instant Payment' || selectedOtherValue == 'Others') ?
                <Typography
                    className={styles.infoText}
                >
                    <span>Your payment will be deducted in every <label>{selectedValue}<sup>{getDaySuffix(selectedValue)}</sup></label> {(selectedValue > 1) ? 'days' : 'day'}</span>
                </Typography>
                : ''}

            <Dialog
                open={openDialog}
                slots={{
                    transition: Transition,
                }}
                keepMounted
                onClose={handleDialogOpen}
                aria-describedby="alert-dialog-slide-description"
                className="daysPicker"
            >
                <DialogTitle sx={{ fontWeight: 'bold' }}>{"Select Day"}</DialogTitle>
                <DialogContent sx={{ padding: '30px', maxWidth: '350px' }}>
                    <Grid container>
                        {elements}
                    </Grid>
                </DialogContent>
            </Dialog>
        </>

    );
};

export default MakePayment;
