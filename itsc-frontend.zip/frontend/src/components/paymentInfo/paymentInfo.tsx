import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import DoneOutlineIcon from '@mui/icons-material/DoneOutline';
import DoDisturbIcon from '@mui/icons-material/DoDisturb';
import {
    Box,
    CardContent,
    Menu,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid,
    Typography,
    Button,
    Modal,
    Slide,
    Container
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { SubContractorProps } from '../../types';
import { toast } from 'react-toastify';
import { can } from "../../utils/helper";
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import PaymentMethodForm from './paymentMethodForm';
import CloseIcon from '@mui/icons-material/Close';
import { STRIPE_PUBLISHABLE_KEY } from "../../config/config";
const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);
const ITEM_HEIGHT = 48;


const PaymentInfo: React.FC = () => {
    const userDetails = (typeof localStorage !== 'undefined') ? JSON.parse(localStorage.getItem('userDetails')) : null;
    console.log('userDetails', userDetails);
    const navigate = useNavigate();
    const [paymentMethods, setPaymentMethods] = useState<SubContractorProps[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const hasFetched = useRef(false);
    const [options] = useState(['Set As Default', 'Delete']);
    const [clientSecret, setClientSecret] = useState('');

    const [openInitStripeModal, setOpenInitStripeModal] = React.useState(false);
    const handleCloseInitStripe = () => {
        setOpenInitStripeModal(false);
    }
    const generateSetupIntent = async () => {
        const response: any = await api.job.generateSetupIntent();
        // console.log('SetupIntent', response);
        if (response) {
            setClientSecret(response.clientSecret);
        } else {
            console.error(response?.message);
        }
    }

    // Menu state
    const [menuState, setMenuState] = useState<{
        anchorEl: HTMLElement | null;
        openMenuId: string | null;
    }>({
        anchorEl: null,
        openMenuId: null
    });
    const fetchPaymentMethods = async () => {
        setIsLoading(true);
        try {
            const response = await api.job.fetchCustomerPaymentMethods();
            console.log('PaymentMethods', response?.data);
            if (response?.data) {
                setIsLoading(false);
                setPaymentMethods(response?.data || []);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch payment informations:", error);
            setPaymentMethods([]);
        } finally {
            hasFetched.current = true;
        }
    };
    const deletePaymentMethod = async (methodId: string) => {
        try {
            setIsLoading(true);
            const response = await api.job.deletePaymentMethod(methodId);
            if (response?.status) {
                toast.success(response?.message);
                if (userDetails.stripePaymentMethod == methodId) {
                    userDetails.stripePaymentMethod = null;
                    localStorage.setItem("userDetails", JSON.stringify(userDetails));
                }
                fetchPaymentMethods();
                setIsLoading(false);
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        } catch (error: any) {
            setIsLoading(false);
            throw error;
        }
    }
    const setDefaultPaymentMethod = async (methodId: string) => {
        try {
            setIsLoading(true);
            const customerId: string = userDetails.stripeCustomerId;
            const response = await api.job.updatePaymentMethod(methodId, customerId);
            if (response?.status) {
                toast.success(response?.message);
                userDetails.stripePaymentMethod = methodId;
                localStorage.setItem("userDetails", JSON.stringify(userDetails));
                fetchPaymentMethods();
                setIsLoading(false);
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        } catch (error: any) {
            setIsLoading(false);
            throw error;
        }
    }
    const addDefaultPaymentMethod = async (methodId: string) => {
        try {
            setIsLoading(true);
            const customerId: string = userDetails.stripeCustomerId;
            const response = await api.job.addDefaultPaymentMethod(methodId, customerId);
            if (response?.status) {
                // toast.success(response?.message);
                if (response?.data?.isAdded) {
                    userDetails.stripePaymentMethod = methodId;
                    localStorage.setItem("userDetails", JSON.stringify(userDetails));
                }
                window.location.reload();
                // handleCloseInitStripe();
                // fetchPaymentMethods();
                // setIsLoading(false);
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        } catch (error: any) {
            setIsLoading(false);
            throw error;
        }
    }
    // Separate useEffect for data fetching
    useEffect(() => {
        if (userDetails?.userRoleSlug != "super-admin" && userDetails?.userRoleSlug != "contractor") {
            navigate(`/dashboard`);
        }
        if (hasFetched.current) return;

        generateSetupIntent();

        fetchPaymentMethods();
    }, []);

    // Menu handlers
    const handleClick = (event: React.MouseEvent<HTMLElement>, userUuid: string) => {
        setMenuState({
            anchorEl: event.currentTarget,
            openMenuId: userUuid
        });
    };

    const handleClose = () => {
        setMenuState({
            anchorEl: null,
            openMenuId: null
        });
    };

    const handleOptionClick = (event: React.MouseEvent<HTMLElement>) => {
        const option = event.currentTarget.getAttribute('data-option');
        const methodId = event.currentTarget.getAttribute('data-id');

        if (option === 'Set As Default' && methodId) {
            const isConfirmed = window.confirm("Are you sure you want to set this payment info as default?");
            if (isConfirmed) {
                setDefaultPaymentMethod(methodId);
            }
        } else if (option === 'Delete' && methodId) {
            const isConfirmed = window.confirm("Are you sure you want to delete this payment info?");
            if (isConfirmed) {
                deletePaymentMethod(methodId);
            }
        }
        handleClose();
    };

    const handleAddPaymentMethod = async () => {
        try {
            setOpenInitStripeModal(true);
        } catch (error) {
            toast.error("Something went wrong while initializing payment.");
            console.error(error);
        }
    };

    return (

        <LayoutProvider pageTitle="Payment Informations">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    {(can(['add-sub-contractor']) && !isLoading) ?
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '0', justifyContent: 'right', alignItems: 'right', gap: "20px" }}>
                            <Button onClick={handleAddPaymentMethod} color="primary" className={styles.formButton} style={{ textDecoration: 'none', margin: '15px', color: '#fff' }}>Add Payment Info</Button>
                        </Box>
                        : ''
                    }
                    <CardContent className={styles.gridBoxwrap}>
                        <Box className={styles.dataContainer}>
                            {isLoading ? (
                                <Box className="loaderContainer">
                                    <Loader />
                                </Box>
                            ) : (
                                <div>
                                    <TableContainer>
                                        {paymentMethods.length > 0 ? (
                                            <Table className={styles.table} style={{ borderTop: '1px solid #ccc' }}>
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell>Sl No</TableCell>
                                                        <TableCell>Payment Info</TableCell>
                                                        <TableCell>Payment Gateway</TableCell>
                                                        <TableCell>Is Default?</TableCell>
                                                        <TableCell></TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {paymentMethods.map((paymentMethod: any, index) => {
                                                        const isOpen = menuState.openMenuId === paymentMethod.id;
                                                        return (
                                                            <TableRow key={paymentMethod.id}>
                                                                <TableCell>{index + 1}</TableCell>
                                                                <TableCell>
                                                                    {
                                                                        <>
                                                                            {paymentMethod.type == 'card' ?
                                                                                <>
                                                                                    <div><strong>Brand: </strong> {paymentMethod.card.brand}</div>
                                                                                    <div><strong>Card: </strong> .... .... .... {paymentMethod.card.last4}</div>
                                                                                </>
                                                                                : ''
                                                                            }
                                                                            {paymentMethod.type == 'link' ?
                                                                                <>
                                                                                    <div><strong>Email: </strong> {paymentMethod.link.email}</div>
                                                                                </>
                                                                                : ''
                                                                            }
                                                                            {paymentMethod.type == 'us_bank_account' ?
                                                                                <>
                                                                                    <div><strong>Bank: </strong> {paymentMethod.us_bank_account.bank_name}</div>
                                                                                    <div><strong>Account: </strong> .... .... .... {paymentMethod.us_bank_account.last4}</div>
                                                                                </>
                                                                                : ''
                                                                            }
                                                                            <div>
                                                                                <strong>Type: </strong> {
                                                                                    paymentMethod.type != 'us_bank_account' ? paymentMethod.type : 'bank'
                                                                                }
                                                                            </div>
                                                                        </>
                                                                    }
                                                                </TableCell>
                                                                <TableCell>Stripe</TableCell>
                                                                <TableCell>
                                                                    {
                                                                        (userDetails.stripePaymentMethod == paymentMethod.id) ? <DoneOutlineIcon /> : ''
                                                                    }
                                                                </TableCell>
                                                                <TableCell>
                                                                    <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                                                        <IconButton
                                                                            aria-label="more"
                                                                            id={`long-button`}
                                                                            aria-controls={isOpen ? `long-menu-${paymentMethod.id}` : undefined}
                                                                            aria-expanded={isOpen ? 'true' : undefined}
                                                                            aria-haspopup="true"
                                                                            onClick={(event) => handleClick(event, paymentMethod.id)}
                                                                        >
                                                                            <MoreVertIcon />
                                                                        </IconButton>
                                                                        <Menu
                                                                            id={`long-menu`}
                                                                            anchorEl={menuState.anchorEl}
                                                                            open={isOpen}
                                                                            onClose={handleClose}
                                                                            className={styles.menuList}
                                                                            slotProps={{
                                                                                paper: {
                                                                                    style: {
                                                                                        maxHeight: ITEM_HEIGHT * 4.5,
                                                                                        width: 'auto',
                                                                                        minWidth: '130px',
                                                                                    },
                                                                                },
                                                                                list: {
                                                                                    'aria-labelledby': `long-button-${paymentMethod.id}`,
                                                                                },
                                                                            }}
                                                                        >
                                                                            {options.map((option) => {
                                                                                const normalizedOption = option.toLowerCase().replace(/\s+/g, '');

                                                                                const iconProps = { sx: { fontSize: 18, marginRight: 1 } };
                                                                                let IconComponent;

                                                                                let isDisabled = false;

                                                                                switch (option) {
                                                                                    case 'Set As Default':
                                                                                        IconComponent = <ContentPasteIcon {...iconProps} />;
                                                                                        isDisabled = userDetails.stripePaymentMethod == paymentMethod.id;
                                                                                        break;
                                                                                    default:
                                                                                        IconComponent = <DoDisturbIcon {...iconProps} />;
                                                                                }
                                                                                return (
                                                                                    <MenuItem
                                                                                        key={option}
                                                                                        onClick={!isDisabled ? handleOptionClick : void (0)}
                                                                                        data-option={option}
                                                                                        data-id={paymentMethod?.id}
                                                                                        className={`${styles.menuItem} ${styles[normalizedOption]}`}
                                                                                        sx={{
                                                                                            display: 'flex',
                                                                                            alignItems: 'center',
                                                                                            gap: 1,
                                                                                            paddingY: 1,
                                                                                            paddingX: 2,
                                                                                            fontSize: 14,
                                                                                            color: 'text.primary',
                                                                                            backgroundColor: 'transparent',
                                                                                            '&:hover': {
                                                                                                backgroundColor: isDisabled ? 'transparent' : 'action.hover',
                                                                                            },
                                                                                            opacity: isDisabled ? 0.5 : 1,
                                                                                            cursor: isDisabled ? 'not-allowed' : 'pointer',
                                                                                        }}
                                                                                    >
                                                                                        {IconComponent}
                                                                                        {option}
                                                                                    </MenuItem>
                                                                                );
                                                                            })}
                                                                        </Menu>
                                                                    </Box>
                                                                </TableCell>
                                                            </TableRow>
                                                        );
                                                    })}
                                                </TableBody>
                                            </Table>
                                        ) : (
                                            <div className={styles.noDataContainer}>
                                                <Typography variant="h6" color="textSecondary" align="center">
                                                    <AssignmentLateIcon fontSize="large" />
                                                    <br />
                                                    No payment info found
                                                </Typography>
                                                <Typography variant="body2" color="textSecondary" align="center">
                                                    There are currently no payment info added to your account
                                                </Typography>
                                            </div>
                                        )}
                                    </TableContainer>
                                </div>
                            )}
                        </Box>
                        <Modal open={openInitStripeModal} onClose={handleCloseInitStripe} closeAfterTransition>
                            <Slide in={openInitStripeModal} direction="left">
                                <Box className={styles.modalBox}>
                                    <Box className={styles.modalHeader}>
                                        <Typography className={styles.modalTitle}>Add Your Payment Info</Typography>
                                        <IconButton onClick={handleCloseInitStripe} sx={{ color: 'red', border: '1px solid red', width: '20px', height: '20px' }}>
                                            <CloseIcon sx={{ fontSize: '20px' }} />
                                        </IconButton>
                                    </Box>
                                    <Container maxWidth="sm" sx={{ mt: 2 }}>
                                        <Elements
                                            stripe={stripePromise}
                                            options={{
                                                clientSecret: clientSecret,
                                                appearance: { theme: 'stripe' }
                                            }}
                                        >
                                            <PaymentMethodForm
                                                clientSecret={clientSecret}
                                                addDefaultPaymentMethod={addDefaultPaymentMethod}
                                            />
                                        </Elements>
                                    </Container>
                                </Box>
                            </Slide>
                        </Modal>
                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default PaymentInfo;
