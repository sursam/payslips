import React, { useEffect, useState, useRef } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import {
    Button,
    CircularProgress
} from '@mui/material';
import { toast } from 'react-toastify';

interface ChildProps {
    clientSecret: string;
    addDefaultPaymentMethod: (paymentMethod) => void;
}

const PaymentMethodForm: React.FC<ChildProps> = ({ clientSecret, addDefaultPaymentMethod }) => {
    const stripe = useStripe();
    const elements = useElements();
    const [loading, setLoading] = useState<boolean>(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        if (!stripe || !elements) {
            return;
        }

        const result = await stripe.confirmSetup({
            elements,
            // clientSecret,
            confirmParams: {
                return_url: window.location.href, // URL to redirect after setup
            },
            redirect: 'if_required',
        });

        if (result.error) {
            console.error('Error Message: ', result.error.message);
            toast.error(result.error.message);
            setLoading(false);
        } else {
            // const setupIntent = result.setupIntent;
            console.log('SetupIntent successful:', result);
            toast.success('Payment info successfully added');
            // Handle success, e.g., redirect or display message
            const paymentMethod = result.setupIntent.payment_method;
            addDefaultPaymentMethod(paymentMethod);
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            {clientSecret && <PaymentElement />}
            <Button
                type="submit"
                variant="contained"
                fullWidth
                disabled={loading || !stripe || !elements || !clientSecret}
                sx={{ mt: 3 }}
            >
                {loading ? (
                    <CircularProgress size={20} sx={{ color: 'white' }} />
                ) : (
                    `Add Payment Info`
                )}
            </Button>
        </form>
    );
};
export default PaymentMethodForm;