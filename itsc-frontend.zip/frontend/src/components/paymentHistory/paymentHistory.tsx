import React, { useEffect, useState, useCallback, useRef } from "react";
import LayoutProvider from "../../providers/LayoutProvider";
import moment from 'moment';
import { api } from '../../utils/api';
import {
	Box,
	Typography,
	Paper,
	Divider,
	Stack,
	Chip,
	Avatar,
	Skeleton,
	Alert,
	CircularProgress,
	TextField,
	Button,
	Grid
} from "@mui/material";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import PaidLoad from "./paidLoad";

// Type definitions based on API response
interface PaymentCard {
	brand: string;
	last4: string;
	exp_month: number;
	exp_year: number;
}

interface PaymentMethod {
	id: string;
	type: string;
	card?: PaymentCard;
}

interface PaymentIntent {
	payment_intent_id: string;
	amount_processed: number;
	currency: string;
	status: string;
	amount_received: number;
	created_at: string;
	capture_method: string;
	description: string;
	latest_charge: string | null;
}

interface PaymentEntry {
	paymentIntent: PaymentIntent;
	paymentMethod: PaymentMethod | null;
}

interface paidLoadDetails {
	id: number;
	unique_id: string;
	load_index: number;
	weight: string;
	job_id: number;
	load_cost: string;
	status: number;
}

// Status configuration with all possible statuses
const STATUS_CONFIG = {
	succeeded: {
		label: "Paid",
		color: "#2e7d32",
		bg: "#c8e6c9",
		icon: "✔️",
	},
	pending: {
		label: "Pending",
		color: "#f9a825",
		bg: "#fff9c4",
		icon: "⏳",
	},
	failed: {
		label: "Failed",
		color: "#c62828",
		bg: "#ffcdd2",
		icon: "❌",
	},
	processing: {
		label: "Processing",
		color: "#1976d2",
		bg: "#bbdefb",
		icon: "⚡",
	},
	requires_payment_method: {
		label: "Requires Payment",
		color: "#e65100",
		bg: "#ffe0b2",
		icon: "⚠️",
	},
	requires_confirmation: {
		label: "Requires Confirmation",
		color: "#6a1b9a",
		bg: "#e1bee7",
		icon: "🔔",
	},
	requires_action: {
		label: "Action Required",
		color: "#d32f2f",
		bg: "#ffcdd2",
		icon: "⚡",
	},
	canceled: {
		label: "Canceled",
		color: "#616161",
		bg: "#e0e0e0",
		icon: "🚫",
	},
} as const;

type PaymentStatus = keyof typeof STATUS_CONFIG;

// Helper function to capitalize card brand
const formatCardBrand = (brand: string): string => {
	return brand.charAt(0).toUpperCase() + brand.slice(1);
};

// Skeleton loading component
const PaymentSkeleton: React.FC = () => (
	<Paper
		elevation={2}
		sx={{
			display: "flex",
			justifyContent: "space-between",
			alignItems: "center",
			p: 3,
			borderRadius: 4,
			bgcolor: "#fff",
		}}
	>
		<Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
			<Skeleton variant="circular" width={48} height={48} animation="wave" />
			<Box>
				<Skeleton variant="text" width={120} height={20} animation="wave" />
				<Skeleton variant="text" width={160} height={16} animation="wave" />
			</Box>
		</Box>
		<Box sx={{ textAlign: "right" }}>
			<Skeleton variant="text" width={60} height={24} animation="wave" />
			<Skeleton
				variant="rounded"
				width={60}
				height={24}
				sx={{ mt: 0.5, borderRadius: 12 }}
				animation="wave"
			/>
		</Box>
	</Paper>
);

// Payment card component
interface PaymentCardProps {
	payment: PaymentEntry;
	index: number;
}

const PaymentCard: React.FC<PaymentCardProps> = ({ payment, index }) => {
	const [paidLoadDetails, setPaidLoadDetails] = useState<paidLoadDetails[]>([]);
	const [openPaidLoadModal, setOpenPaidLoadModal] = React.useState(false);
	const { paymentIntent, paymentMethod } = payment;

	const handleClosePaidLoadsModal = () => {
		setOpenPaidLoadModal(false);
	}

	// Get status configuration with fallback
	const status = STATUS_CONFIG[paymentIntent.status as PaymentStatus] || STATUS_CONFIG.pending;

	// Format amount - amount is already in dollars (not cents based on API)
	const amount = paymentIntent.amount_received.toFixed(2);

	// Format date
	const formattedDate = moment(paymentIntent.created_at).format('MMM DD, YYYY [at] h:mm A');

	// Get payment method display
	const getPaymentMethodText = () => {
		if (!paymentMethod) {
			return 'No payment method';
		}

		if (paymentMethod.type == 'card' && paymentMethod.card) {
			return `${formatCardBrand(paymentMethod.card.brand)} •••• ${paymentMethod.card.last4}`;
		}

		return formatCardBrand(paymentMethod.type);
	};

	const paymentMethodText = getPaymentMethodText();

	// Function to fetch paid load details
	const fetchPaidLoads = async (paymentIntentId: string) => {
		try {
			console.log("Fetching paid loads for:", paymentIntentId);
			const response = await api.payment.paidLoadDetails(paymentIntentId);
			console.log("Full response:", response);
			console.log("Response data:", response?.data);

			if (response?.data) {
				return response.data;
			} else {
				console.error("No data in response:", response);
				return null;
			}
		} catch (err) {
			console.error("Failed to fetch paid loads:", err);
			if (err.response) {
				console.error("Error response:", err.response.data);
				console.error("Error status:", err.response.status);
			}
			return null;
		}
	};

	const handleViewPaidLoadsModal = async (paymentIntentId: string) => {
		const details = await fetchPaidLoads(paymentIntentId);
		if (details) {
			setPaidLoadDetails(details);
			setOpenPaidLoadModal(true);
		} else {
			console.error("Could not load paid load details");
		}
	};

	return (
		<>
			<Paper
				elevation={4}
				sx={{
					position: "relative",
					display: "flex",
					flexDirection: { xs: 'column', md: 'row' },
					justifyContent: "space-between",
					alignItems: { xs: 'flex-start', md: 'center' },
					p: 3,
					borderRadius: 4,
					bgcolor: "#fff",
					transition: "transform 0.3s ease, box-shadow 0.3s ease",
					border: "1px solid #e0e0e0",
					cursor: "pointer",
					"&:hover": {
						transform: "scale(1.01)",
						boxShadow: "0 8px 24px rgba(0,0,0,0.1)",
					},
				}}
				onClick={() => handleViewPaidLoadsModal(paymentIntent.payment_intent_id)}
			>
				{/* Status Badge */}
				<Box
					sx={{
						position: "absolute",
						top: 8,
						right: 8,
						zIndex: 1,
					}}
				>
					<Chip
						label={status.label}
						size="small"
						sx={{
							fontWeight: 600,
							fontSize: "0.75rem",
							borderRadius: "8px",
							backgroundColor: status.bg,
							color: status.color,
							boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
						}}
					/>
				</Box>

				{/* Left Side */}
				<Box sx={{ display: "flex", alignItems: "center", gap: 2, pt: 2, flex: 1 }}>
					<Avatar
						sx={{
							bgcolor: status.bg,
							color: status.color,
							width: 48,
							height: 48,
							fontSize: 24,
						}}
					>
						{status.icon}
					</Avatar>

					<Box sx={{ flex: 1 }}>
						<Typography variant="subtitle1" fontWeight={600} sx={{ pr: 2 }}>
							{paymentIntent.description || `Payment #${index + 1}`}
						</Typography>
						<Typography variant="body2" color="text.secondary">
							{formattedDate}
						</Typography>
						<Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
							{paymentMethodText}
						</Typography>
						{paymentIntent.payment_intent_id && (
							<Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 0.5, fontFamily: 'monospace' }}>
								ID: {paymentIntent.payment_intent_id}
							</Typography>
						)}
					</Box>
				</Box>

				{/* Divider */}
				<Divider
					orientation="vertical"
					flexItem
					sx={{
						display: { xs: "none", md: "block" },
						mx: 3,
						borderColor: "#eee",
					}}
				/>

				{/* Right Side */}
				<Box sx={{ textAlign: { xs: 'left', md: 'right' }, mt: { xs: 2, md: 0 }, minWidth: 100 }}>
					<Typography
						variant="h6"
						fontWeight={700}
						sx={{
							color: paymentIntent.amount_received > 0 ? "#1976d2" : "#9e9e9e"
						}}
					>
						${amount}
					</Typography>
					<Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
						{paymentIntent.currency.toUpperCase()}
					</Typography>
					{paymentIntent.amount_processed !== paymentIntent.amount_received && (
						<Typography variant="caption" color="warning.main" sx={{ display: 'block', mt: 0.5 }}>
							Processed: ${paymentIntent.amount_processed.toFixed(2)}
						</Typography>
					)}
				</Box>
			</Paper>
			<PaidLoad
				paidLoads={paidLoadDetails}
				open={openPaidLoadModal}
				onClose={handleClosePaidLoadsModal}
			/>
		</>
	);
};

const PaymentHistory: React.FC = () => {
	const [loading, setLoading] = useState(true);
	const [loadingMore, setLoadingMore] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [paymentData, setPaymentData] = useState<PaymentEntry[]>([]);
	const [totalPaid, setTotalPaid] = useState<string>("0.00");
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(0);
	const [hasMore, setHasMore] = useState(true);
	const [startDate, setStartDate] = useState<string>('');
	const [endDate, setEndDate] = useState<string>('');
	const observerRef = useRef<HTMLDivElement>(null);
	const isFetchingRef = useRef(false);

	// Fetch payment history
	const fetchPaymentHistory = async (page: number, isInitial = false, filters?: { start_date?: string; end_date?: string }) => {
		// Prevent duplicate requests
		if (isFetchingRef.current) return;

		try {
			isFetchingRef.current = true;

			if (isInitial) {
				setLoading(true);
			} else {
				setLoadingMore(true);
			}
			setError(null);

			const response = await api.payment.paymentHistory(page, filters?.start_date, filters?.end_date);

			if (response?.data) {
				const { payments, total_paid } = response.data;
				const { pagination } = response;

				// Update payment data - append for infinite scroll
				if (isInitial) {
					setPaymentData(payments || []);
				} else {
					setPaymentData(prev => [...prev, ...(payments || [])]);
				}

				setTotalPaid(total_paid || "0.00");
				setCurrentPage(pagination?.current_page || 1);
				setTotalPages(pagination?.total_pages || 0);

				// Check if there are more pages
				const hasMorePages = pagination?.current_page < pagination?.total_pages;
				setHasMore(hasMorePages);
			}
		} catch (err) {
			console.error("Failed to fetch payment history:", err);
			setError("Failed to load payment history. Please try again later.");
		} finally {
			setLoading(false);
			setLoadingMore(false);
			isFetchingRef.current = false;
		}
	};

	// Intersection Observer for infinite scroll
	useEffect(() => {
		const observer = new IntersectionObserver(
			(entries) => {
				// When the observer element is visible and conditions are met
				if (
					entries[0].isIntersecting &&
					hasMore &&
					!loading &&
					!loadingMore &&
					currentPage < totalPages
				) {
					const filters = {
						start_date: startDate || undefined,
						end_date: endDate || undefined
					};
					fetchPaymentHistory(currentPage + 1, false, filters);
				}
			},
			{ threshold: 0.1 } // Trigger when 10% of the element is visible
		);

		if (observerRef.current) {
			observer.observe(observerRef.current);
		}

		return () => {
			if (observerRef.current) {
				observer.unobserve(observerRef.current);
			}
		};
	}, [fetchPaymentHistory, hasMore, loading, loadingMore, currentPage, totalPages, startDate, endDate]);

	// Initial load - fetch first page
	useEffect(() => {
		fetchPaymentHistory(1, true);
	}, []);

	// Handle filter application
	const handleApplyFilters = () => {
		const filters = {
			start_date: startDate || undefined,
			end_date: endDate || undefined
		};
		fetchPaymentHistory(1, true, filters);
	};

	// Handle filter reset
	const handleResetFilters = () => {
		setStartDate('');
		setEndDate('');
		fetchPaymentHistory(1, true);
	};

	return (
		<LayoutProvider pageTitle="Payment History">
			<Box
				sx={{
					p: { xs: 2, sm: 3 },
					maxWidth: 1200,
					mx: 'auto',
				}}
			>
				{/* Header with Date Filters */}
				<Paper elevation={2} sx={{ p: 3, mb: 4, borderRadius: 2 }}>
					<Grid container spacing={3} alignItems="center">
						<Grid size={{ xs: 12, md: 4 }}>
							<Typography
								variant="h5"
								fontWeight={600}
								sx={{
									color: '#2e7d32',
									display: 'flex',
									alignItems: 'center',
									gap: 1,
								}}
							>
								Total Paid: ${loading ? "..." : totalPaid}
							</Typography>
						</Grid>
						<Grid size={{ xs: 12, md: 8 }}>
							<Box sx={{
								display: 'flex',
								gap: 2,
								flexWrap: 'wrap',
								justifyContent: { xs: 'flex-start', md: 'flex-end' },
								alignItems: 'center'
							}}>
								<TextField
									label="Start Date"
									type="date"
									value={startDate}
									onChange={(e) => setStartDate(e.target.value)}
									InputLabelProps={{
										shrink: true,
									}}
									size="small"
									sx={{
										minWidth: 160,
										bgcolor: 'background.paper'
									}}
								/>
								<TextField
									label="End Date"
									type="date"
									value={endDate}
									onChange={(e) => setEndDate(e.target.value)}
									InputLabelProps={{
										shrink: true,
									}}
									size="small"
									sx={{
										minWidth: 160,
										bgcolor: 'background.paper'
									}}
								/>
								<Button
									variant="contained"
									color="primary"
									onClick={handleApplyFilters}
									disabled={loading}
									sx={{
										minWidth: 100,
										height: 40
									}}
								>
									Apply
								</Button>
								<Button
									variant="outlined"
									color="secondary"
									onClick={handleResetFilters}
									disabled={loading}
									sx={{
										minWidth: 100,
										height: 40
									}}
								>
									Reset
								</Button>
							</Box>
						</Grid>
					</Grid>
				</Paper>

				{/* Error Alert */}
				{error && (
					<Alert
						severity="error"
						icon={<ErrorOutlineIcon />}
						sx={{ mb: 3 }}
						onClose={() => setError(null)}
					>
						{error}
					</Alert>
				)}
				{/* Payment List */}
				<Stack spacing={3}>
					{loading ? (
						// Loading skeletons for initial load
						Array.from({ length: 5 }).map((_, index) => (
							<PaymentSkeleton key={index} />
						))
					) : paymentData.length === 0 ? (
						// Empty state
						<Paper
							elevation={2}
							sx={{
								p: 6,
								borderRadius: 4,
								textAlign: "center",
								bgcolor: "#f5f5f5",
							}}
						>
							<AccountBalanceWalletIcon
								sx={{ fontSize: 64, color: "#bdbdbd", mb: 2 }}
							/>
							<Typography variant="h6" color="text.secondary">
								No payment history found
							</Typography>
							<Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
								Your payment transactions will appear here
							</Typography>
						</Paper>
					) : (
						// Payment cards
						paymentData.map((payment, index) => (
							<PaymentCard
								key={payment.paymentIntent.payment_intent_id}
								payment={payment}
								index={index}
							/>
						))
					)}
				</Stack>

				{/* Intersection Observer Target */}
				<Box ref={observerRef} sx={{ height: 10, mt: 2 }} />

				{/* Loading indicator for infinite scroll */}
				{loadingMore && (
					<Box sx={{ display: 'flex', justifyContent: 'center', mt: 4, mb: 2 }}>
						<CircularProgress size={40} />
					</Box>
				)}
			</Box>
		</LayoutProvider>
	);
};

export default PaymentHistory;