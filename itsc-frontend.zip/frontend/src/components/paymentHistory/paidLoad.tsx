import React from "react";
import {
	Box,
	Slide,
	Modal,
	Typography,
	IconButton,
	Card,
	CardContent,
	Grid,
	Chip,
	Divider,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import styles from "../../styles/viewJob.module.css";

interface LoadDetails {
	id: number;
	job_id: number;
	load_cost: string;
	load_index: number;
	status: number;
	unique_id: string;
	weight: string;
}

interface ChildProps {
	paidLoads: LoadDetails[];
	open: boolean;
	onClose: () => void;
}

const PaidLoad: React.FC<ChildProps> = ({ paidLoads, open, onClose }) => {
	const totalCost = paidLoads.reduce((sum, load) => sum + parseFloat(load.load_cost), 0);
	const totalWeight = paidLoads.reduce((sum, load) => sum + parseFloat(load.weight), 0);

	return (
		<Modal
			open={open}
			onClose={onClose}
			closeAfterTransition
			aria-labelledby="transition-modal-title"
			aria-describedby="transition-modal-description"
			slotProps={{
				backdrop: { timeout: 500 },
			}}
		>
			<Slide in={open} direction="left" mountOnEnter unmountOnExit>
				<Box
					className={styles.modalBox}
				>
					{/* Header */}
					<div className={styles.modalHeader}>
						<Typography id="transition-modal-title" className={styles.modalTitle}>
							Paid Loads
						</Typography>
						<IconButton
							aria-label="close"
							onClick={onClose}
							sx={{
								color: 'red',
								border: '1px solid red',
								borderRadius: '4px',
								padding: '4px',
								'&:hover': {
									backgroundColor: 'rgba(255, 0, 0, 0.1)',
								}
							}}
						>
							<CloseIcon />
						</IconButton>
					</div>

					{/* Loads List */}
					<div className={styles.contentContainer}>
						{paidLoads.length == 0 ? (
							<Box sx={{ textAlign: "center", py: 6 }}>
								<LocalShippingIcon sx={{ fontSize: 64, color: "text.disabled", mb: 2 }} />
								<Typography variant="h6" color="text.secondary">
									No paid loads found
								</Typography>
							</Box>
						) : (
							<Grid container spacing={2}>
								{paidLoads.map((load) => (
									<Grid size={{ xs: 12 }} key={load.id}>
										<Card
											sx={{
												border: "1px solid #e0e0e0",
												transition: "all 0.2s ease",

											}}
										>
											<CardContent>
												<Box
													sx={{
														display: "flex",
														justifyContent: "space-between",
														alignItems: "flex-start",
														gap: 2,
													}}
												>
													<Box sx={{ display: "flex", alignItems: "center" }}>
														<Box
															sx={{
																bgcolor: "success.main",
																borderRadius: "50%",
																width: 40,
																height: 40,
																display: "flex",
																alignItems: "center",
																justifyContent: "center",
															}}
														>
															<CheckCircleIcon sx={{ color: "white", fontSize: 24 }} />
														</Box>
														<Box>
															<Typography variant="subtitle1" fontWeight={600}>
																Load No. {load.load_index}
															</Typography>
															<Typography
																variant="caption"
																color="text.secondary"
																sx={{ fontFamily: "monospace" }}
															>
																{load.unique_id}
															</Typography>
														</Box>
													</Box>

													<Chip
														label="Completed"
														size="small"
														color="success"
														sx={{
															fontWeight: 600,
															fontSize: "0.75rem",
														}}
													/>
												</Box>

												<Divider sx={{ my: 2 }} />

												<Grid container spacing={2}>
													<Grid size={{ xs: 4 }}>
														<Typography
															variant="caption"
															color="text.secondary"
															sx={{ display: "block", mb: 0.5 }}
														>
															Job ID
														</Typography>
														<Typography variant="body2" fontWeight={600}>
															#{load.job_id}
														</Typography>
													</Grid>

													<Grid size={{ xs: 4 }}>
														<Typography
															variant="caption"
															color="text.secondary"
															sx={{ display: "block", mb: 0.5 }}
														>
															Weight
														</Typography>
														<Typography variant="body2" fontWeight={600}>
															{parseFloat(load.weight).toFixed(2)} Tons
														</Typography>
													</Grid>

													<Grid size={{ xs: 4 }}>
														<Typography
															variant="caption"
															color="text.secondary"
															sx={{ display: "block", mb: 0.5 }}
														>
															Cost
														</Typography>
														<Typography
															variant="body2"
															fontWeight={700}
															color="primary"
														>
															${parseFloat(load.load_cost).toFixed(2)}
														</Typography>
													</Grid>
												</Grid>
											</CardContent>
										</Card>
									</Grid>
								))}
							</Grid>
						)}
					</div>
				</Box>
			</Slide>
		</Modal>
	);
};

export default PaidLoad;
