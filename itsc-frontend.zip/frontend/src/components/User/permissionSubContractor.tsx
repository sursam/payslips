import React, { useEffect, useState } from 'react';
import {
    Box,
    CardContent,
    Grid,
    Button,
    List,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Checkbox
} from '@mui/material';
import styles from '../../styles/user.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { api } from '../../utils/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useParams } from "react-router-dom";
import Loader from '../Loader/loader';
import { useNavigate } from 'react-router-dom';

interface SubContractor {
    fname: string;
    lname: string;
}

const PermissionSubContractor: React.FC = () => {
    const userDetails = (typeof localStorage !== 'undefined') ? JSON.parse(localStorage.getItem('userDetails')) : null;
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [permissions, setPermissions] = useState([]);
    const [userPermissions, setUserPermissions] = useState([]);
    const subContractorObject = {
        fname: '',
        lname: '',
    };
    const [subContractorDetails, setSubContractorDetails] = useState<SubContractor>(subContractorObject);

    const { uuid } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        if (userDetails?.userRoleSlug != "super-admin" && userDetails?.userRoleSlug != "contractor") {
            navigate(`/dashboard`);
        }
        getSubContractorPermissionList();
        fetchSubContractorDetails(uuid);
    }, [uuid]);

    const getSubContractorPermissionList = async () => {
        setIsLoading(true);
        let payload: any = {
            type: 1,
        };
        const response = await api.auth.getSubContractorPermissions(payload);
        console.log('Permissions', response.data);
        setPermissions(response.data);
        setIsLoading(false);
    }
    const fetchSubContractorDetails = async (uuid: string) => {
        try {
            const response: any = await api.auth.getUserDetails(uuid);
            if (response) {
                console.log("User Details:", response.data);
                let user = response.data.user;
                setSubContractorDetails(user);
                setUserPermissions(user.permissions);
            }
        } catch (error) {
            console.error("Failed to fetch sub contractor details:", error);
        }
    };

    const handleToggle = (value: number) => () => {
        const currentIndex = userPermissions.indexOf(value);
        const newChecked = [...userPermissions];

        if (currentIndex === -1) {
            newChecked.push(value);
        } else {
            newChecked.splice(currentIndex, 1);
        }

        setUserPermissions(newChecked);
    };

    const handlePermissions = async () => {
        setIsLoading(true);
        const payload = {
            "uuid": uuid,
            "permissions": userPermissions
        }
        const response = await api.auth.updateUserPermissions(payload);
        try {
            if (response.status) {
                toast.success(response.message);
                setTimeout(() => {
                    navigate('/sub-contractor-list');
                }, 1000);
            } else {
                toast.error('Permission updation failed');
            }
            setIsLoading(false);
        } catch (error) {
            console.log(error)
            toast.error(response.message);
            setIsLoading(false);
        }
    }

    return (
        <LayoutProvider pageTitle={`Permissions for ${subContractorDetails.fname} ${subContractorDetails.lname}`} backUrl="/sub-contractor-list">
            <ToastContainer />
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <form>
                        <CardContent className={styles.gridBoxwrap}>
                            <Box className={styles.formContainer}>
                                {isLoading ?
                                    <Box className="loaderContainer">
                                        <Loader />
                                    </Box>
                                    : ''
                                }
                                <Grid container spacing={0} sx={{ padding: '20px' }}>
                                    {Object.entries(permissions).map(([groupKey, permissionList]) => (
                                        <Grid size={{ md: 3, sm: 4, xs: 12 }} className={styles.formBox} sx={{ marginBottom: '25px' }}>
                                            <strong>{groupKey.toUpperCase()}</strong>
                                            {permissionList ?
                                                <Box sx={{ backgroundColor: '#f7f7f7ff', height: '93%', marginTop: '10px', border: '1px solid #dfddddff' }}>
                                                    <List sx={{ width: '100%', maxWidth: 360, bgcolor: '#f7f7f7ff', padding: '0' }} key={groupKey}>
                                                        {permissionList.map((permission, i) => (
                                                            <ListItem
                                                                key={i}
                                                                disablePadding
                                                                sx={{
                                                                    backgroundColor: '#f7f7f7ff',
                                                                    '&:hover': {
                                                                        backgroundColor: '#dfddddff',
                                                                    },
                                                                    paddingY: 0, // Spacing
                                                                }}
                                                            >
                                                                <ListItemButton role={undefined}
                                                                    onClick={handleToggle(permission.slug)}
                                                                    dense
                                                                >
                                                                    <ListItemIcon sx={{ minWidth: 'auto' }}>
                                                                        <Checkbox
                                                                            edge="start"
                                                                            checked={userPermissions.includes(permission.slug)}
                                                                            tabIndex={-1}
                                                                            disableRipple
                                                                            inputProps={{ 'aria-labelledby': `checkbox-list-label-${permission.slug}` }}
                                                                            sx={{
                                                                                'padding': '5px 9px'
                                                                            }}
                                                                        />
                                                                    </ListItemIcon>
                                                                    <ListItemText id={`checkbox-list-label-${permission.slug}`} primary={permission.name} />
                                                                </ListItemButton>

                                                            </ListItem>
                                                        ))}
                                                    </List>
                                                </Box>
                                                : ''}
                                        </Grid>
                                    ))}

                                </Grid>
                            </Box >
                        </CardContent>
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '0px', justifyContent: 'center', alignItems: 'center', gap: "20px" }}>
                            <Button type='button' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.formButton}`} onClick={handlePermissions}>
                                Update
                            </Button>
                        </Box>
                    </form>
                </Grid>
            </Grid>

        </LayoutProvider>
    );
};

export default PermissionSubContractor;
