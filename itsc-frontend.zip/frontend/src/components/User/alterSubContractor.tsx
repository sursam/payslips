import React, { useEffect, useState } from 'react';
import {
    Box,
    CardContent,
    Grid,
    Button,
    TextField,
    FormControl,
    Autocomplete
} from '@mui/material';
import styles from '../../styles/user.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { api } from '../../utils/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Loader from '../Loader/loader';
import PhoneInput from 'react-phone-input-2';
import MakePayment from '../Auth/Forms/makePayment';
import { useParams, useNavigate } from 'react-router-dom';
import { can } from "../../utils/helper";

interface SubContractorForm {
    firstName: string;
    lastName: string;
    email: string;
    mobileNumber: string;
    countryCode: string;
    mobile: string;
    dob: string;
    address: string;
    pinCode: string;
    userState: string;
    stateName: string;
    city: string;
    cityName: string;
    paymentTerms: number
}

const AlterSubContractor: React.FC = () => {
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);
    const [profile, setProfile] = React.useState<any>();
    const { uuid } = useParams();
    const navigate = useNavigate();
    const stateObject = {
        firstName: '',
        lastName: '',
        email: '',
        mobileNumber: '',
        countryCode: '',
        mobile: '',
        dob: '',
        address: '',
        pinCode: '',
        userState: '',
        stateName: '',
        city: '',
        cityName: '',
        paymentTerms: 0
    };
    var [state, setState] = useState<SubContractorForm>(stateObject);
    var {
        firstName,
        lastName,
        email,
        mobileNumber,
        dob,
        address,
        pinCode,
        stateName,
        cityName,
        paymentTerms
    } = state;

    useEffect(() => {
        getStateList();
        fetchProfile();
        if (uuid) {
            if (!can(['edit-sub-contractor'])) {
                navigate(`/dashboard`);
            }
            fetchSubContractorDetails(uuid);
        }
        if (!can(['add-sub-contractor'])) {
            navigate(`/dashboard`);
        }

    }, [uuid]);

    const fetchProfile = async () => {
        try {
            const response = await api.profile.fetchProfile();
            if (response) {
                console.log("profile Details:", response.data.user);
                setProfile(response.data.user);
            }
        } catch (error) {
            console.error("Failed to fetch notifications:", error);
        }
    };

    const fetchSubContractorDetails = async (uuid: string) => {
        try {
            const response: any = await api.auth.getUserDetails(uuid);
            if (response) {
                console.log("User Details:", response.data);
                let userData = response.data.user;
                setState(prevState => ({
                    ...prevState,
                    firstName: userData.fname,
                    lastName: userData.lname,
                    email: userData.email,
                    mobileNumber: `${userData.country_code}${userData.mobile}`,
                    countryCode: userData.country_code,
                    mobile: userData.mobile,
                    dob: userData.dob,
                    address: userData.address,
                    pinCode: userData.pincode,
                    userState: userData.state_details?.state_id,
                    stateName: userData.state_details?.state_name,
                    city: userData.city_details?.id,
                    cityName: userData.city_details?.name,
                    paymentTerms: userData.payment_terms
                }));
            }
        } catch (error) {
            console.error("Failed to fetch notifications:", error);
        }
    };

    const getStateList = async () => {
        setIsLoading(true);
        let payload: any = {
            country_code: 'US',
        };
        const response = await api.auth.statesByCountryCode(payload);
        // console.log('States', response.data);
        setStates(response.data);
        setIsLoading(false);
    }

    var validationObject = {
        firstName: Yup.string().required('First name is required'),
        lastName: Yup.string().required('Last name is required'),
        email: Yup.string().required('Email is required'),
        mobileNumber: Yup.string().required('Contact number is required'),
        dob: Yup.string().required('Date of birth is required'),
        userState: Yup.string().required('State is required'),
        city: Yup.string().required('City is required'),
        pinCode: Yup.string().required('Pin code is required'),
        address: Yup.string().required('Address is required'),
        // paymentTerms: Yup.number().required('Payment term is required'),
    };

    const validationSchema = Yup.object().shape(validationObject);
    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }
    const generatePassword = (pwordLength = 8) => {
        let chars = '0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let password = '';

        const array = new Uint32Array(chars.length);
        window.crypto.getRandomValues(array);

        for (let i = 0; i < pwordLength; i++) {
            password += chars[array[i] % chars.length];
        }
        return password;
    }

    const onSubmit = async (data: any) => {
        setIsLoading(true);

        const baseUrl = `${window.location.protocol}//${window.location.host}`;
        const password = generatePassword();
        console.log('Password', password);
        let formPayload = new FormData();
        formPayload.append('first_name', data.firstName);
        formPayload.append('last_name', data.lastName);
        formPayload.append('email', data.email);
        formPayload.append('password', password);
        formPayload.append('country_code', data.countryCode);
        formPayload.append('mobile', data.mobile);
        formPayload.append('registration_source', '2');
        formPayload.append('latitude', '22.87897398');
        formPayload.append('longitude', '78.978976');
        formPayload.append('dob', data.dob);
        formPayload.append('state_id', data.userState);
        formPayload.append('city_id', data.city);
        formPayload.append('address', data.address);
        formPayload.append('pin_code', data.pinCode);
        formPayload.append('role', 'sub-contractor');
        formPayload.append('device_token', '12345');
        formPayload.append('fcm_token', '12345');
        formPayload.append('device_type', '1');
        formPayload.append('added_by', profile?.id);
        formPayload.append('link', baseUrl);
        if (data.profileImage) {
            formPayload.append('image', data.profileImage);
        }
        var responseMember: any;
        if (!uuid) {
            responseMember = await api.auth.addUser(formPayload)
        } else {
            responseMember = await api.auth.updateUser(formPayload)
        }
        if (responseMember?.status) {
            if (!uuid) {
                const companyPayload = {
                    user_id: responseMember?.userDetails?.id,
                    company_legal_name: profile?.complete_profile_info?.company_legal_name,
                    company_dba: profile?.complete_profile_info?.company_dba,
                    country: profile?.complete_profile_info?.country_code,
                    phone_2: profile?.complete_profile_info?.phone_2,
                    tax_id: profile?.complete_profile_info?.tax_id,
                };
                const responseCompany = await api.auth.updateCompanyDetails(companyPayload);
                if (responseCompany?.status) {
                    const updatePaymentTermsPayload = {
                        pay_in: 1,
                        user_id: responseMember?.userDetails?.id
                    };
                    const isPaymentTermsUpdated = await api.auth.updatePaymentTermsByUser(updatePaymentTermsPayload)
                    if (isPaymentTermsUpdated) {
                        toast.success(responseMember?.message);
                        setTimeout(() => {
                            navigate('/sub-contractor-list');
                        }, 1000);
                    } else {
                        toast.error('Payment terms updation failed');
                    }
                } else {
                    toast.error('Company details updation failed');
                }
            } else {
                toast.success(responseMember?.message);
                setTimeout(() => {
                    navigate('/sub-contractor-list');
                }, 1000);
            }
            setIsLoading(false);
        }
        else {
            // console.error('Registration failed:');
            toast.error(responseMember?.message);
            setIsLoading(false);
        }
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        switch (name) {
            case 'pinCode':
                const numericValue = value.replace(/\D/g, '').slice(0, 6);
                setState(prevState => ({
                    ...prevState,
                    [name]: numericValue,
                }));
                break;
            default:
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
        }

        // trigger(name);
    };

    const onContactNumberChange = (value: any, data: any, event: any, formattedValue: any) => {
        setState(prevState => ({
            ...prevState,
            mobileNumber: formattedValue,
            countryCode: data.dialCode,
            mobile: value.slice(data.dialCode.length),
        }));
    };

    const handleDateChange = (e: any) => {
        setState(prevState => ({
            ...prevState,
            [e.target.name]: e.target.value
        }));
    };

    const handleStateChange = async (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        if (value?.id) {
            setState(prevState => ({
                ...prevState,
                userState: value?.id ?? '',
                city: '',
                cityName: '',
            }));
            const payload = {
                state_id: value.id
            };
            const response = await api.auth.citiesByStateId(payload);
            let citiesData = (response?.data?.length) ? response.data : [];
            setCities(citiesData);
        }
    };
    const handleStateInputChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            stateName: value ?? '',
        }));
    };
    const handleCityChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            city: value?.id ?? '',
        }));
    };
    const handleCityInputChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            cityName: value ?? '',
        }));
    };
    const handlePaymentTerms = (value: string | number) => {
        console.log('paymentTerms: ', Number(value));
        setState(prevState => ({
            ...prevState,
            paymentTerms: Number(value)
        }));
    };

    return (
        <LayoutProvider pageTitle={`${!uuid ? "Add User" : "Edit User"}`} backUrl="/sub-contractor-list">
            <ToastContainer />
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <form className='custom-Form' encType='multipart/form-data' onSubmit={handleSubmit(onSubmit)}>
                        <CardContent className={styles.gridBoxwrap}>
                            <Box className={styles.formContainer}>
                                {isLoading ?
                                    <Box className="loaderContainer">
                                        <Loader />
                                    </Box>
                                    : ''
                                }
                                <Grid container spacing={0} sx={{ padding: '20px' }}>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                label="First Name"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                value={firstName}
                                                className={`${styles.formControl} ${errors?.firstName ? 'is-invalid' : ''}`}
                                                {...register('firstName', { onChange: handleChange })}
                                                inputProps={{ autoComplete: "firstName" }}
                                            />
                                            <div className="invalid-feedback">{errors.firstName?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                label="Last Name"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                value={lastName}
                                                className={`${styles.formControl} ${errors?.lastName ? 'is-invalid' : ''}`}
                                                {...register('lastName', { onChange: handleChange })}
                                                inputProps={{ autoComplete: "lastName" }}
                                            />
                                            <div className="invalid-feedback">{errors.lastName?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                type='email'
                                                label="Email"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                value={email}
                                                className={`${styles.formControl} ${errors?.email ? 'is-invalid' : ''}`}
                                                {...register('email', { onChange: handleChange })}
                                                inputProps={{ autoComplete: "email" }}
                                            />
                                            <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <PhoneInput
                                                country={'us'}
                                                value={mobileNumber}
                                                onChange={onContactNumberChange}
                                                inputProps={{
                                                    name: 'mobileNumber',
                                                    autoFocus: false,
                                                }}
                                                containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                                                inputStyle={{ borderColor: errors?.mobileNumber ? '#d32f2f' : '#ccc', }}
                                            />
                                            <div className="invalid-feedback">{errors.mobileNumber?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                label="Date Of Birth"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                type="date"
                                                value={dob}
                                                className={`${styles.formControl} ${errors?.dob ? 'is-invalid' : ''}`}
                                                {...register('dob', { onChange: handleDateChange })}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    inputProps: {
                                                        max: new Date().toISOString().split('T')[0], // Set the minimum selectable date
                                                    },
                                                }}
                                            />
                                            <div className="invalid-feedback">{errors.dob?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <Autocomplete
                                                disablePortal
                                                options={Array.isArray(states) ? states : []}
                                                renderInput={(params) => <TextField {...params} label="State" />}
                                                className={`formSelect ${errors?.userState ? 'is-invalid' : ''}`}
                                                {...register('userState')}
                                                onChange={handleStateChange}
                                                onInputChange={handleStateInputChange}
                                                value={stateName}
                                                noOptionsText="No state found"
                                            />
                                            <div className="invalid-feedback">{errors.userState?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <Autocomplete
                                                disablePortal
                                                options={Array.isArray(cities) ? cities : []}
                                                renderInput={(params) => <TextField {...params} label="City" />}
                                                className={`formSelect ${errors?.city ? 'is-invalid' : ''}`}
                                                {...register('city')}
                                                onChange={handleCityChange}
                                                onInputChange={handleCityInputChange}
                                                value={cityName}
                                                noOptionsText="No city found"
                                            />
                                            <div className="invalid-feedback">{errors.city?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                label="Zip Code"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                value={pinCode}
                                                className={`${styles.formControl} ${errors?.pinCode ? 'is-invalid' : ''}`}
                                                {...register('pinCode', { onChange: handleChange })}
                                                inputProps={{ autoComplete: "pinCode" }}
                                            />
                                            <div className="invalid-feedback">{errors.pinCode?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <FormControl fullWidth>
                                            <TextField
                                                label="Street Address"
                                                variant="outlined"
                                                fullWidth
                                                margin="normal"
                                                value={address}
                                                className={`${styles.formControl} ${errors?.address ? 'is-invalid' : ''}`}
                                                {...register('address', { onChange: handleChange })}
                                                inputProps={{ autoComplete: "address" }}
                                            />
                                            <div className="invalid-feedback">{errors.address?.message?.toString()}</div>
                                        </FormControl>
                                    </Grid>
                                    {/* {!uuid ?
                                        <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.formBox}>
                                            <MakePayment
                                                errors={errors}
                                                register={register}
                                                handleChange={handleChange}
                                                paymentTerms={paymentTerms}
                                                handlePaymentTerms={handlePaymentTerms}
                                            />
                                        </Grid>
                                        : ''} */}
                                </Grid>
                            </Box >
                        </CardContent>
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '0px', justifyContent: 'center', alignItems: 'center', gap: "20px" }}>
                            <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.formButton}`} onClick={submitForm}>
                                {!uuid ? 'Submit' : 'Update'}
                            </Button>
                        </Box>
                    </form>
                </Grid>
            </Grid>

        </LayoutProvider>
    );
};

export default AlterSubContractor;
