import React, { useEffect } from 'react';
import {
    Box,
    CardContent,
    Grid,
    Typography
} from '@mui/material';
import styles from '../../styles/user.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { api } from '../../utils/api';
import 'react-toastify/dist/ReactToastify.css';
import { useParams, useNavigate } from "react-router-dom";
import Loader from '../Loader/loader';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import MobileIcon from '@mui/icons-material/MobileFriendly';
import CalendarIcon from '@mui/icons-material/CalendarMonthOutlined';
import AddressIcon from '@mui/icons-material/LocationCityOutlined';
import CompanyIcon from '@mui/icons-material/Apartment';
import PhoneIcon from '@mui/icons-material/Phone';
import ReceiptIcon from '@mui/icons-material/Receipt';
import PaymentIcon from '@mui/icons-material/Payment';
import { can } from "../../utils/helper";

const ViewSubContractor: React.FC = () => {
    const [userDetails, setUserDetails] = React.useState<any>();
    const { uuid } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        if (!can(['view-sub-contractor'])) {
            navigate(`/dashboard`);
        }
        fetchSubContractorDetails(uuid);
    }, [uuid]);

    const fetchSubContractorDetails = async (uuid: string) => {
        try {
            const response: any = await api.auth.getUserDetails(uuid);
            if (response) {
                console.log("User Details:", response.data);
                setUserDetails(response.data.user);
            }
        } catch (error) {
            console.error("Failed to fetch notifications:", error);
        }
    };

    const getDaySuffix = (day: any) => {
        if (day > 3 && day < 21) return 'th'; // Handles 11th, 12th, 13th, etc.
        switch (day % 10) {
            case 1:
                return 'st';
            case 2:
                return 'nd';
            case 3:
                return 'rd';
            default:
                return 'th';
        }
    };

    return (
        <LayoutProvider pageTitle="View Users" backUrl="/sub-contractor-list">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <Box className={styles.formContainer}>
                            {!userDetails ?
                                <Box className="loaderContainer">
                                    <Loader />
                                </Box>
                                :
                                <Grid container spacing={0} sx={{ padding: '40px' }}>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox} sx={{ mb: 2 }}>
                                        <Typography gutterBottom sx={{
                                            color: '#005DAA',
                                            fontSize: 18,
                                            fontFamily: 'Poppins',
                                            fontWeight: 600,
                                            mb: 2
                                        }}>
                                            Personal Info
                                        </Typography>
                                        <Box sx={{ ml: 1 }}>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <PersonIcon /> <strong>Name: </strong>{`${userDetails?.fname} ${userDetails?.lname}`}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <EmailIcon /> <strong>Email: </strong>{userDetails?.email}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <MobileIcon /> <strong>Mobile Number: </strong>{`+${userDetails?.country_code}${userDetails?.mobile}`}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <CalendarIcon /> <strong>Date Of Birth: </strong> {userDetails?.dob ? new Date(userDetails?.dob).toLocaleDateString('en-GB', {
                                                    day: '2-digit',
                                                    month: 'short',
                                                    year: 'numeric'
                                                }) : '-- --- ----'}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <AddressIcon /> <strong>Address: </strong>{`${userDetails?.address}, ${userDetails?.city_details?.name}, ${userDetails?.state_details?.state_name}, ${userDetails?.pincode}`}
                                            </Typography>
                                        </Box>
                                    </Grid>
                                    {/* <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox} sx={{ mb: 2 }}>
                                        <Typography gutterBottom sx={{
                                            color: '#005DAA',
                                            fontSize: 18,
                                            fontFamily: 'Poppins',
                                            fontWeight: 600,
                                            mb: 2
                                        }}>
                                            Company Info
                                        </Typography>
                                        <Box sx={{ ml: 1 }}>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <CompanyIcon /> <strong>Company Name: </strong>{userDetails?.complete_profile_info?.company_legal_name}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <ReceiptIcon /> <strong>Company DBA: </strong>{userDetails?.complete_profile_info?.company_dba}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <ReceiptIcon /> <strong>Company EIN / TAX ID: </strong>{userDetails?.complete_profile_info?.tax_id}
                                            </Typography>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <PhoneIcon /> <strong>Phone Number: </strong>{`+${userDetails?.complete_profile_info?.country_code}${userDetails?.complete_profile_info?.phone_2}`}
                                            </Typography>

                                        </Box>
                                    </Grid>
                                    <Grid size={{ md: 6, sm: 12, xs: 12 }} className={styles.formBox}>
                                        <Typography gutterBottom sx={{
                                            color: '#005DAA',
                                            fontSize: 18,
                                            fontFamily: 'Poppins',
                                            fontWeight: 600,
                                            mb: 2
                                        }}>
                                            Payment Info
                                        </Typography>
                                        <Box sx={{ ml: 1 }}>
                                            <Typography sx={{
                                                fontSize: 14,
                                                fontWeight: 500,
                                                fontFamily: 'Poppins',
                                                color: '#333',
                                                mb: 2,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1
                                            }}>
                                                <PaymentIcon /> <Typography
                                                    className={styles.infoText}
                                                >
                                                    {userDetails?.payment_terms ?
                                                        <span>Payment will be deducted in every <label>{userDetails?.payment_terms}<sup>{getDaySuffix(userDetails?.payment_terms)}</sup></label> {(userDetails?.payment_terms > 1) ? 'days' : 'day'}</span>
                                                        :
                                                        <span>Instant Payment</span>
                                                    }
                                                </Typography>
                                            </Typography>
                                        </Box>
                                    </Grid> */}
                                </Grid>
                            }
                        </Box>
                    </CardContent>
                </Grid>
            </Grid>

        </LayoutProvider>
    );
};

export default ViewSubContractor;
