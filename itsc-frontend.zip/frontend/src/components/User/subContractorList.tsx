import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../../utils/api';
import Loader from '../Loader/loader';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import moment from 'moment';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
import EditIcon from '@mui/icons-material/Edit';
import PermissionIcon from '@mui/icons-material/Settings';
import DoDisturbIcon from '@mui/icons-material/DoDisturb';
import {
    Box,
    CardContent,
    Menu,
    MenuItem,
    Pagination,
    PaginationItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid,
    Typography,
    Button
} from '@mui/material';
import styles from '../../styles/user.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import { SubContractorProps } from '../../types';
import { toast } from 'react-toastify';
import { can } from "../../utils/helper";
// const options = [
//     'View',
//     'Edit',
//     'Permissions',
//     'Delete'
// ];

const ITEM_HEIGHT = 48;

const SubContractorList: React.FC = () => {
    const userDetails = (typeof localStorage !== 'undefined') ? JSON.parse(localStorage.getItem('userDetails')) : null;
    const navigate = useNavigate();
    const [subContractors, setSubContractors] = useState<SubContractorProps[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const hasFetched = useRef(false);
    const [options, setOptions] = useState([]);

    // Menu state
    const [menuState, setMenuState] = useState<{
        anchorEl: HTMLElement | null;
        openUserUuid: string | null;
    }>({
        anchorEl: null,
        openUserUuid: null
    });
    const fetchSubContractors = async (page: number) => {
        setIsLoading(true);
        try {
            const response = await api.auth.getSubContractorList(page);
            if (response?.data) {
                setIsLoading(false);
                setSubContractors(response?.data || []);
                setTotalPages(response?.pagination?.total_pages || 0);
                setCurrentPage(response?.pagination?.current_page || 1);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch sub contractors:", error);
            setSubContractors([]);
        } finally {
            hasFetched.current = true;
        }
    };
    const deleteSubContractor = async (userUuid: string) => {
        try {
            const response = await api.auth.deleteUser(userUuid);
            if (response?.status) {
                toast.success(response?.message);
                fetchSubContractors(currentPage);
            } else {
                toast.error(response?.message);
            }
        } catch (error: any) {
            throw error;
        }
    }
    // Separate useEffect for data fetching
    useEffect(() => {
        if (!can(['view-sub-contractor'])) {
            navigate(`/dashboard`);
        }
        setOptions([
            'View'
        ]);
        if (can(['edit-sub-contractor'])) {
            setOptions(prevState => ([
                ...prevState,
                'Edit'
            ]));
        }
        if (userDetails?.userRoleSlug == "super-admin" || userDetails?.userRoleSlug == "contractor") {
            setOptions(prevState => ([
                ...prevState,
                'Permissions'
            ]));
        }
        if (can(['delete-sub-contractor'])) {
            setOptions(prevState => ([
                ...prevState,
                'Delete'
            ]));
        }
        if (hasFetched.current) return;
        fetchSubContractors(currentPage);
    }, []);

    // Menu handlers
    const handleClick = (event: React.MouseEvent<HTMLElement>, userUuid: string) => {
        setMenuState({
            anchorEl: event.currentTarget,
            openUserUuid: userUuid
        });
    };

    const handleClose = () => {
        setMenuState({
            anchorEl: null,
            openUserUuid: null
        });
    };

    const handleOptionClick = (event: React.MouseEvent<HTMLElement>) => {
        const option = event.currentTarget.getAttribute('data-option');
        const userUuid = event.currentTarget.getAttribute('data-user-uuid');

        if (option === 'View' && userUuid) {
            navigate(`/view-sub-contractor/${userUuid}`);
        } else if (option === 'Edit' && userUuid) {
            navigate(`/edit-sub-contractor/${userUuid}`);
        } else if (option === 'Permissions' && userUuid) {
            navigate(`/sub-contractor-permissions/${userUuid}`);
        } else if (option === 'Delete' && userUuid) {
            const isConfirmed = window.confirm("Are you sure you want to delete this sub contractor?");
            if (isConfirmed) {
                deleteSubContractor(userUuid);
            }
        }
        handleClose();
    };

    const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
        setCurrentPage(page);
        fetchSubContractors(page);
        hasFetched.current = false;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (

        <LayoutProvider pageTitle="User List">
            <Grid container spacing={3}>
                <Grid size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    {can(['add-sub-contractor']) ?
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '0', justifyContent: 'right', alignItems: 'right', gap: "20px" }}>
                            <Link to="/add-sub-contractor" color="primary" className={styles.formButton} style={{ textDecoration: 'none', margin: '15px', color: '#fff' }}>Add User</Link>
                            {/* <Button type='button' variant="contained" color="primary" className={styles.formButton}>
                            
                        </Button> */}
                        </Box>
                        : ''
                    }
                    <CardContent className={styles.gridBoxwrap}>
                        <Box className={styles.dataContainer}>
                            {isLoading ? (
                                <Box className="loaderContainer">
                                    <Loader />
                                </Box>
                            ) : (
                                <div>
                                    <TableContainer>
                                        {subContractors.length > 0 ? (
                                            <Table className={styles.table} style={{ borderTop: '1px solid #ccc' }}>
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell>Sl No</TableCell>
                                                        <TableCell>Name</TableCell>
                                                        <TableCell>Email</TableCell>
                                                        <TableCell>State</TableCell>
                                                        <TableCell>City</TableCell>
                                                        <TableCell>Created On</TableCell>
                                                        <TableCell></TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {subContractors.map((subContractor, index) => {
                                                        const isOpen = menuState.openUserUuid === subContractor.uuid;
                                                        return (
                                                            <TableRow key={subContractor.uuid}>
                                                                <TableCell>{index + 1}</TableCell>
                                                                <TableCell>{`${subContractor?.first_name} ${subContractor?.last_name}`}</TableCell>
                                                                <TableCell>{subContractor?.email}</TableCell>
                                                                <TableCell>{subContractor?.state?.name}</TableCell>
                                                                <TableCell>{subContractor?.city?.name}</TableCell>
                                                                <TableCell>{moment(subContractor?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                                <TableCell>
                                                                    <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                                                        <IconButton
                                                                            aria-label="more"
                                                                            id={`long-button`}
                                                                            aria-controls={isOpen ? `long-menu-${subContractor.uuid}` : undefined}
                                                                            aria-expanded={isOpen ? 'true' : undefined}
                                                                            aria-haspopup="true"
                                                                            onClick={(event) => handleClick(event, subContractor.uuid)}
                                                                        >
                                                                            <MoreVertIcon />
                                                                        </IconButton>
                                                                        <Menu
                                                                            id={`long-menu`}
                                                                            anchorEl={menuState.anchorEl}
                                                                            open={isOpen}
                                                                            onClose={handleClose}
                                                                            className={styles.menuList}
                                                                            slotProps={{
                                                                                paper: {
                                                                                    style: {
                                                                                        maxHeight: ITEM_HEIGHT * 4.5,
                                                                                        width: 'auto',
                                                                                        minWidth: '130px',
                                                                                    },
                                                                                },
                                                                                list: {
                                                                                    'aria-labelledby': `long-button-${subContractor.uuid}`,
                                                                                },
                                                                            }}
                                                                        >
                                                                            {options.map((option) => {
                                                                                // const isSelected = option === 'View';
                                                                                const normalizedOption = option.toLowerCase().replace(/\s+/g, '');

                                                                                const iconProps = { sx: { fontSize: 18, marginRight: 1 } };
                                                                                let IconComponent;

                                                                                switch (option) {
                                                                                    case 'View':
                                                                                        IconComponent = <ContentPasteIcon {...iconProps} />;
                                                                                        break;
                                                                                    case 'Edit':
                                                                                        IconComponent = <EditIcon {...iconProps} />;
                                                                                        break;
                                                                                    case 'Permissions':
                                                                                        IconComponent = <PermissionIcon {...iconProps} />;
                                                                                        break;
                                                                                    default:
                                                                                        IconComponent = <DoDisturbIcon {...iconProps} />;
                                                                                }
                                                                                return (
                                                                                    <MenuItem
                                                                                        key={option}
                                                                                        onClick={handleOptionClick}
                                                                                        data-option={option}
                                                                                        data-user-uuid={subContractor?.uuid}
                                                                                        className={`${styles.menuItem} ${styles[normalizedOption]}`}
                                                                                        sx={{
                                                                                            display: 'flex',
                                                                                            alignItems: 'center',
                                                                                            gap: 1,
                                                                                            paddingY: 1,
                                                                                            paddingX: 2,
                                                                                            fontSize: 14,
                                                                                            color: 'text.primary',
                                                                                            backgroundColor: 'transparent',
                                                                                            '&:hover': 'action.hover',
                                                                                            opacity: 1,
                                                                                            cursor: 'pointer',
                                                                                        }}
                                                                                    >
                                                                                        {IconComponent}
                                                                                        {option}
                                                                                    </MenuItem>
                                                                                );
                                                                            })}
                                                                        </Menu>
                                                                    </Box>
                                                                </TableCell>
                                                            </TableRow>
                                                        );
                                                    })}
                                                </TableBody>
                                            </Table>
                                        ) : (
                                            <div className={styles.noDataContainer}>
                                                <Typography variant="h6" color="textSecondary" align="center">
                                                    <AssignmentLateIcon fontSize="large" />
                                                    <br />
                                                    No sub contractors found
                                                </Typography>
                                                <Typography variant="body2" color="textSecondary" align="center">
                                                    There are currently no sub contractors matching your criteria
                                                </Typography>
                                            </div>
                                        )}
                                    </TableContainer>

                                    {/* Pagination Section - only show when there's data and multiple pages */}
                                    {!isLoading && subContractors.length > 0 && (
                                        <Box
                                            display="flex"
                                            justifyContent="center"
                                            mt={3}
                                            mb={2}
                                            className={styles.paginationContainer}
                                            sx={{ float: 'right' }}
                                        >
                                            <Pagination
                                                count={totalPages}
                                                page={currentPage}
                                                onChange={handlePageChange}
                                                color="primary"
                                                showFirstButton
                                                showLastButton
                                                shape="rounded"
                                                siblingCount={1}
                                                boundaryCount={1}
                                            />
                                        </Box>
                                    )}
                                </div>
                            )}
                        </Box>
                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider>
    );
};

export default SubContractorList;
