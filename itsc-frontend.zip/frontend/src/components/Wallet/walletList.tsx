import React, { useState, useEffect, useMemo } from 'react';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import { Box, Divider, Typography } from '@mui/material';
import styles from '../../styles/wallet.module.css';
import {
  Card,
  CardContent,
  TextField,
  Button,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  Paper,
  IconButton,
  Pagination
} from '@mui/material';
import { tableCellClasses } from '@mui/material/TableCell';
import { ArrowForward } from '@mui/icons-material';
import { walletDetails, walletRecharge, transactionDetails } from "../../context/walletContext"
import FilterListIcon from '@mui/icons-material/FilterList';
import { styled } from '@mui/material/styles';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAngleDown } from '@fortawesome/free-solid-svg-icons';
import { walletrecharge, transDetails, RowData } from '../../types';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import Alert from '@mui/material/Alert';


/************************** */
interface Column {
  id: 'transaction_date' | 'amount' | 'type' | 'payment_status' | 'payment_type' | 'message';
  label: string;
  minWidth?: number;
  align?: 'left';
  color?: '#484848'
}

const columns: readonly Column[] = [
  {
    id: 'transaction_date',
    label: 'Date',
    minWidth: 120
  },
  {
    id: 'amount',
    label: 'Amount',
    minWidth: 120
  },
  {
    id: 'type',
    label: 'Type',
    minWidth: 120
  },
  {
    id: 'payment_status',
    label: 'Status',
    minWidth: 120
  },
  {
    id: 'payment_type',
    label: 'Payemnt Type',
    minWidth: 120
  },
  {
    id: 'message',
    label: 'Message',
    minWidth: 200
  },
];

const WalletList: React.FC = () => {

  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [addMoney, setAddMoney] = useState<number | any>();
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [rows, setRows] = useState<any>([]);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const memberId = localStorage.getItem("member_id")!

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage - 1); // Convert to 0-based index
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };
  const navigate = useNavigate();

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  }
  const getWalletDetails = async () => {
    // To get wallet balance
    const response = await api.Wallet.walletDetails();
    // const response = await walletDetails();
    setWalletBalance(response?.amount);

    // To get list of transactions
    // const transDetailsObj: transDetails = {
    //   member_id: memberId
    // };
    // const transaction_list = await api.Wallet.transactionDetails(transDetailsObj);
    // const transaction_list = await transactionDetails(transDetailsObj);
    const transaction_list = await api.Wallet.transactionList(memberId)
    let data = transaction_list?.data?.data
    if (data?.length) {
      setRows(data);
    }
  }
  useEffect(() => {
    getWalletDetails();
  }, [])

  useEffect(() => {
    setPage(0);
  }, [rows]);

  const handleMoneyAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value)
    if (!isNaN(value)) {
      setAddMoney(value)
    } else {
      setAddMoney(null)
    }
  }
  const addWalletMoney = async () => {
    let payload: walletrecharge = {
      member_id: memberId,
      wallet_amount: addMoney !== null ? addMoney : null
    }
    const rechargeResponse = await api.Wallet.walletRecharge(payload);
    // const rechargeResponse = await walletRecharge(payload);
    const transactionId = rechargeResponse?.stripePayment?._id

    navigate('/stripe-payment', {
      state: {
        stripePayment: rechargeResponse?.stripePayment,
        response: rechargeResponse?.paymentData,
        transId: transactionId
      }
    })
  }

  console.log({ rows })
  return (
    <>
      <Box className={styles.container}>
        <Sidebar isOpen={isSidebarOpen} />
        <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
        <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '5px', transition: 'margin-left 0.3s' }}>
          <Stack direction="row">

            <Card sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 2,
              flex: 1,
              borderRadius: 4,
              p: '32px',
              m: '20px',
              maxWidth: '350px',
              boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
              background: '#f8f9fa',
            }}>
              <img src='/assets/images/wallet.png' alt="Wallet" className={styles.walletIcon}
              />

              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                <p style={{ fontSize: '16px', fontWeight: 500, color: '#6c757d', marginBottom: '10px' }}>
                  Wallet Points
                </p>
                <p className={styles.wallet_balance} style={{ fontSize: '28px', fontWeight: 700 }}>
                  {walletBalance?.toFixed(2) || "0.00"}
                </p>
              </Box>

              {/* Vertical Line */}
              {/* <Divider orientation="vertical" flexItem /> */}

              {/* <img src='/assets/images/withdraw.png' alt="Wallet" className={styles.walletIcon} />
              <Box>
                <p color="textSecondary">Withdrawn Money</p>
                <p className={styles.wallet_balance}> $ {walletBalance || 0}</p>
              </Box> */}
            </Card>


            <Card sx={{ flex: 1, borderRadius: 3, m: '20px', border: '1px solid #00A99042' }}>
              <CardContent>
                <h4 className={styles.addmoney}>Add Money To Wallet</h4>
                <p className={styles.addmoney_text}>
                  Add money to your wallet and use it for your transactions.
                </p>
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 2, position: 'relative' }}>
                  <Box className={styles.phoneinput}>
                    <Box className={styles.countrycode}>
                      $
                      {/* <FontAwesomeIcon icon={faAngleDown} className={styles.angleicon} /> */}
                    </Box>
                    <hr className={styles.divider} />
                    <TextField
                      id="amount"
                      className={styles.phonenumber}
                      variant="standard"
                      value={addMoney}
                      onChange={handleMoneyAdd}
                      placeholder='Enter amount'
                      required
                    />

                    <Button
                      variant="contained"
                      sx={{
                        ml: 2,
                        minWidth: '71px',
                        height: '71px'
                      }}
                      className={styles.addmoney_btn}
                      onClick={addWalletMoney}
                    >
                      <ArrowForward />
                    </Button>
                  </Box>
                </Box>
                <Typography className={styles.addmoney_text} sx={{ mt: 1, fontSize: '12px', color: '#59b2ae' }}>
                  <Alert severity="warning">1 point equivalent to $1.</Alert>
                </Typography>


              </CardContent>
            </Card>

          </Stack>

          <Box sx={{ width: '96%', marginLeft: '20px' }}>

            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
              <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      {columns.map((column) => (
                        <TableCell
                          key={column.id}
                          align={column.align}
                          style={{ minWidth: column.minWidth }}
                        >
                          {column.label}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((row: any) => {
                        return (
                          <TableRow hover role="checkbox" tabIndex={-1} key={row.id}>
                            <TableCell>
                              {row.transaction_date}
                            </TableCell>
                            <TableCell
                              style={{ color: row.payment_status === "PENDING" || row.transaction_status === "DEBITED" ? "red" : "green" }}
                              align="left"
                            >
                              $ {row.amount}
                            </TableCell>
                            <TableCell
                              style={{ color: row.payment_status === "PENDING" || row.transaction_status === "DEBITED" ? "red" : "green" }}
                              align="left"
                            >
                              {row.transaction_status ?? '-'}
                            </TableCell>
                            <TableCell
                              style={{ color: row.payment_status === "PENDING" ? "red" : "green" }}
                              align="left"
                            >
                              {row.payment_status}
                            </TableCell>
                            {/* <TableCell align="left">{row.status}</TableCell> */}
                            <TableCell align="left">{row?.payment_type?.toUpperCase()}</TableCell>
                            <TableCell align="left">{row?.message?.toUpperCase()}</TableCell>
                          </TableRow>

                        );
                      })}
                  </TableBody>
                </Table>
              </TableContainer>
              <Stack spacing={2} sx={{ marginTop: 2, marginBottom: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
                <Pagination
                  count={Math.ceil(rows.length / rowsPerPage)} // Calculate total pages
                  page={page + 1} // MUI Pagination is 1-based
                  onChange={handleChangePage}
                  color="primary"
                />
              </Stack>
            </Paper>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default WalletList;
