import React, { useEffect, useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
// import {
//   PaymentElement,
//   Elements,
//   useStripe,
//   useElements,
// } from '@stripe/react-stripe-js';
import { useLocation } from 'react-router-dom';
import { Box, Card, Button } from '@mui/material';
import styles from '../../styles/wallet.module.css';
import { StripePaymentElementChangeEvent } from "@stripe/stripe-js";
import { paymentReceived } from '../../context/walletContext';
import { useNavigate } from 'react-router-dom';
import { CheckoutFormProps, VerifyPaymentType } from '../../types';
import { STRIPE_PAYMENT_STATUS } from '../../constants/stripe';
import { api } from '../../utils/api';
// import { STRIPE_PUBLISHABLE_KEY } from '../../config/config';

export const LOCAL_STRIPE_PUBLISHABLE_KEY = "pk_test_51NdpkRBuHqQNZg72XOlkNZRZZO9aXVTnGAyzbNP8QXJkZwW5gVY9r3PxjNQ6e9Yz5htDWyIKuMRaAHmS5EZfk4Oz00sCUF6Kvr"

const StripePayment = () => {
  const location = useLocation();
  const { state } = location;
  const [stripePromise, setStripePromise] = useState<any>(null);

  useEffect(() => {
    const loadStripeInstance = async () => {

      const stripe = await loadStripe(LOCAL_STRIPE_PUBLISHABLE_KEY);
      setStripePromise(stripe);
    };
    loadStripeInstance();
  }, []);

  // Customizable Stripe PaymentElement appearance style
  // Define the appearance object here
  const appearance = {
    theme: 'flat' as 'flat',
    variables: {
      fontWeightNormal: '500',
      borderRadius: '2px',
      colorPrimary: '#00B4AA',
      tabIconSelectedColor: '#fff',
      gridRowSpacing: '16px'
    },
    rules: {
      '.Tab, .Input, .Block, .CheckboxInput, .CodeInput': {
        boxShadow: '0px 3px 10px rgba(18, 42, 66, 0.08)'
      },
      '.Block': {
        borderColor: 'transparent'
      },
      '.BlockDivider': {
        backgroundColor: '#00B4AA'
      },
      '.Tab, .Tab:hover, .Tab:focus': {
        border: '0'
      },
      '.Tab--selected, .Tab--selected:hover': {
        backgroundColor: '#00B4AA1F',
        color: '#00B4AA'
      }
    }
  };


  const options = {
    clientSecret: state?.response?.client_secret || "",
    appearance,
  };

  return (
    <div className="App" style={{ minHeight: '100vh', backgroundColor: '#121212', padding: 20 }}>
      {/* {state?.response?.client_secret && stripePromise && (
        <Elements options={options} stripe={stripePromise}>
          <CheckoutForm id={state?.transId as string} stripeData={state?.stripePayment} />
        </Elements>
      )} */}
    </div>
  );
};

export default StripePayment;

const CheckoutForm: React.FC<CheckoutFormProps> = ({ id, stripeData }) => {

  // const stripe = useStripe();
  // const elements = useElements();
  const navigate = useNavigate();

  const [isPaymentComplete, setIsPaymentComplete] = useState(false);
  const [errorMessage, setErrorMessage] = useState<any | null>(null);

  const handlePaymentElementChange = (event: StripePaymentElementChangeEvent) => {
    setIsPaymentComplete(event.complete);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    // if (!stripe || !elements) {
    //   console.error('Stripe.js has not yet loaded.');
    //   return;
    // }

    // try {
    //   const result = await stripe.confirmPayment({
    //     elements,
    //     confirmParams: {
    //       return_url: `${process.env.REACT_APP_API_URL}confirm`,
    //     },
    //     redirect: 'if_required',
    //   });

    //   if (result?.error) {
    //     setErrorMessage(result?.error?.message);
    //     console.error("Payment error:", result.error);
    //   } else {
    //     console.log('Payment succeeded:', result);
    //     await handlePostPayment(result);
    //   }
    // } catch (error) {
    //   console.error("Error confirming payment:", error);
    // }
  };

  const handlePostPayment = async (result: any) => {
    try {
      let verifyPayload: VerifyPaymentType = {
        "status": STRIPE_PAYMENT_STATUS.success,
        "member_id": stripeData?.member_objectId,
        "paymentIntent_id": stripeData?.payment_intent_id,
        "payment_respons": {
          "id": stripeData?.payment_intent_id,
          "object": stripeData?.payment_intent_id,
          "amount": stripeData?.payment_data?.amount,
          "amount_capturable": stripeData?.payment_data?.amount_capturable,
          "amount_received": stripeData?.payment_data?.amount_received,
          "application": stripeData?.payment_data?.application
        }
      }
      const response = await api.Wallet.paymentReceived(verifyPayload, id)
      // const response = await paymentReceived(verifyPayload, id)
      if (response) {
        setTimeout(() => {
          navigate('/wallet')
        }, 3000);
        navigate('/confirm')
      }
    } catch (error) {
      console.log(error)
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 900, margin: '0 auto' }}>
      <Box sx={{
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        alignItems: 'flex-start',
        justifyContent: 'space-around',
        gap: 4,
        backgroundColor: '#00B4AA',
        padding: 3,
        borderRadius: 3,
        boxShadow: '0 0 10px rgba(0,0,0,0.6)'
      }}>
        <Box sx={{
          flex: 1,
          minWidth: 280,
          borderRadius: 2,
          padding: 4,
        }}>
          {/* <PaymentElement onChange={handlePaymentElementChange} /> */}
        </Box>
        <Box sx={{ minWidth: 320 }}>
          <Card sx={{
            flex: 1,
            borderRadius: 5,
            p: 3,
            m: '20px 0',
            width: '100%',
            backgroundColor: '#F3FFFD',
            boxShadow: '0 8px 24px rgba(79,70,229,0.3)',
            color: '#f9fafb'
          }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: '20px', mb: 1 }}>
              <p className={styles.payamount}>Subtotal (1 item)</p>
              <p className={styles.payamount}>${stripeData?.amount}</p>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <p className={styles.payamount}>Shipping</p>
              <p className={styles.payamount}>Free</p>
            </Box>
            <hr style={{ borderColor: '#4f46e5', marginBottom: 16 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <p className={styles.paytotal}>Total</p>
              <p className={styles.paytotal}>${stripeData?.amount}</p>
            </Box>
            <Button
              type="submit"
              // disabled={!stripe || !isPaymentComplete}
              variant="contained"
              fullWidth
              sx={{
                mt: 4,
                backgroundColor: '#00B4AA !important',
                '&:hover': {
                  backgroundColor: '#4338ca !important',
                },
                padding: '12px 0',
                borderRadius: 3,
                fontWeight: '600',
                fontSize: '1rem',
                color: '#ffff !important',
                textTransform: 'none',
              }}
            >
              Place Order
            </Button>
          </Card>
        </Box>
      </Box>
      {errorMessage && (
        <Box sx={{ color: '#ef4444', mt: 2, textAlign: 'center', fontWeight: '600' }}>
          {errorMessage}
        </Box>
      )}
    </form>
  );
};

