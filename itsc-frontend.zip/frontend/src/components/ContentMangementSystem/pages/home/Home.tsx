import { aboutusimg01, aboutustextbg01, cirneco_dell_etna_running, DownloadOurApp, freepik_br01, leftarrow01, reviewimg01, Subtract, video_gif } from "../../../../assets";
import Blog from "./blog/Blog";
import Marquee from "./marquee/Marquee";
import Subscription from "./subscription/Subscription";
import { useInView } from 'react-intersection-observer';


const Home = () => {
	const [ref, inView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.1, // Trigger when 10% of the image is visible
	});
	const [aboutRef, inAboutView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.1, // Trigger when 10% of the image is visible
	});
	const [marqueeRef, inMarqueeView] = useInView({
		triggerOnce: true, // Trigger animation only once
		threshold: 0.1, // Trigger when 10% of the image is visible
	});
	return (
		<>
			{/* <!-- TopBanner Section --> */}
			<div className="topbanner-section">
				<div className="row">
					<div className="col-lg-5 col-md-5 col-12">
						<div className="bannerimg wow animate fadeInLeft" style={{ animationDelay: '0.5s', animationDuration: '2s' }}>
							<img src={freepik_br01} alt="" />
						</div>
					</div>

					<div className="col-lg-7 col-md-7 col-12">
						<div className="bannercarousel-text wow animate__animated animate__slideInRight" style={{ animationDelay: '0.5s', animationDuration: '2s' }}>
							<h5>Greyhound Racing</h5>
							<h2>Unmatched Excellence</h2>

							<div className="reviewscard">
								<div className="reviewscard-img">
									<img src={reviewimg01} className="img-fluid" alt="" />
								</div>{" "}
								<h6>10k+ Members</h6>{" "}
							</div>
						</div>
					</div>
				</div>
			</div>
			{/* <!-- TopBanner Section End --> */}

			{/* <!-- About Us Section --> */}
			<div id="about" className="aboutus-section">
				<div ref={ref}
					className="aboutustextbg">
					<img src={aboutustextbg01} className="img-fluid" alt="" />
				</div>
				<div className="container-fluid">
					<div className="row">
						<div className="col-lg-4 col-md-4 col-12">
							<div ref={aboutRef}
								className={`aboutus-card wow animate__animated ${inAboutView ? 'animate__slideInLeft' : ''}`}>
								<div className="aboutusimg01">
									<img src={aboutusimg01} className="img-fluid" alt="" />
								</div>
								<div className="leftarrow01">
									<img src={leftarrow01} className="" alt="" />
								</div>
							</div>
						</div>

						<div className="col-lg-8 col-md-8 col-12">
							<div ref={aboutRef}
								className={`aboutus-cardtext wow animate__animated ${inAboutView ? 'animate__slideInRight' : ''}`}>
								<h2>About Us</h2>
								<p>
									Winners Are Grinners® is driven by a proficient team of
									greyhound racing experts based in NSW, ready to provide you
									with tips for greyhound and horse racing in Australia. These
									tips enhance the chances of racing enthusiasts making informed
									bets that can lead to profitable outcomes.
								</p>
								<p>
									As a well-established entity in the industry, we stay ahead of
									the curve with the latest updates on greyhound racing results,
									utilising this information to strategise our next moves.
									Together, we collaborate to formulate the most effective
									strategies for optimal success.
								</p>
								<a href="/about-us" className="readbtn">
									Read More
								</a>
							</div>
						</div>
					</div>

					<div id="dogs" ref={ref}
						className={`dogdemonstration wow animate__animated ${inView ? 'animate__slideInUp' : ''}`}>
						<h3>Dog Demonstration</h3>
						<p>
							Witnessing a greyhound in full sprint is an unparalleled
							spectacle. We recognise and share your passion for this
							extraordinary sport, aiming to ensure that you not only enjoy the
							experience but also have the opportunity to earn money in the
							process.
						</p>
						<div className="dogdemonstration-video">
							<a href={video_gif} target="_blank"
								className="portfokio-lightbox">
								<div className="videosect-bg">
									<img src={video_gif} alt="" />
								</div>
							</a>

							{/* <div className="video-section-inner">
								<a
									href="https://www.youtube.com/embed/CEOc2bGV3j8"
									target="_blank"
									className="portfokio-lightbox"
									data-bs-toggle="modal"
									data-bs-target="#myModal"
								>
								</a>
								<div id="overlay"></div>
							</div> */}
						</div>
					</div>
				</div>
				<div className="cirneco-dell">
					<img src={cirneco_dell_etna_running} className="" alt="" />
				</div>
			</div>
			{/* <!-- About Us Section End --> */}

			{/* <!-- Greyhound Racing Shop Section --> */}
			<div
				id="membership" ref={marqueeRef} className={`greyhoundracing-section wow animate__animated ${inMarqueeView ? 'animate__slideInUp' : ''}`}
			>
				<div className="subtractcard">
					<img src={Subtract} className="" alt="" />
				</div>
				<Marquee />

				<div className="row">
					<div className="col-lg-5 col-md-5 col-12">
						<div className="downloadapp">
							<img src={DownloadOurApp} className="" alt="" />
						</div>
					</div>

					<div className="col-lg-7 col-md-7 col-12">
						<div className="greyhoundracing-text">
							<h3>Greyhound Racing Shop</h3>
							<p>
								Receive premium greyhound and horse racing tips from the top
								racing enthusiast in Australia. Select your choice of membership
								duration
							</p>

							<Subscription />
						</div>

						<div className="ourblogs">
							<h3>Our Blogs</h3>
							<p>Receive premium greyhound and horse racing tips.</p>
							<Blog />
						</div>
					</div>
				</div>
			</div>
			{/* <!-- Greyhound Racing Shop Section --> */}
		</>
	);
}

export default Home