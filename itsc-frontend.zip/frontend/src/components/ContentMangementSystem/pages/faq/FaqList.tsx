import * as React from 'react';
import { styled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, {
	AccordionSummaryProps,
	accordionSummaryClasses,
} from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';

const FaqList = () => {
	const Accordion = styled((props: AccordionProps) => (
		<MuiAccordion disableGutters elevation={0} square {...props} />
	))(({ theme }) => ({
		border: `1px solid ${theme.palette.divider}`,
		'&:not(:last-child)': {
			borderBottom: 0,
		},
		'&::before': {
			display: 'none',
		},
	}));

	const AccordionSummary = styled((props: AccordionSummaryProps) => (
		<MuiAccordionSummary
			expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
			{...props}
		/>
	))(({ theme }) => ({
		backgroundColor: 'rgba(0, 0, 0, .03)',
		flexDirection: 'row-reverse',
		[`& .${accordionSummaryClasses.expandIconWrapper}.${accordionSummaryClasses.expanded}`]:
		{
			transform: 'rotate(90deg)',
		},
		[`& .${accordionSummaryClasses.content}`]: {
			marginLeft: theme.spacing(1),
		},
		...theme.applyStyles('dark', {
			backgroundColor: 'rgba(255, 255, 255, .05)',
		}),
	}));

	const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
		padding: theme.spacing(2),
		borderTop: '1px solid rgba(0, 0, 0, .125)',
	}));

	const [expanded, setExpanded] = React.useState<string | false>('panel1');

	const handleChange =
		(panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
			setExpanded(newExpanded ? panel : false);
		};
	return (
		<>
			<div>
				<Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
					<AccordionSummary aria-controls="panel1d-content" id="panel1d-header">
						<Typography component="span">Where does it come from?</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							Winners Are Grinners is inspired by the rich tradition of dog racing, where participants can invest in a dog's performance. The concept allows users to buy shares in a racing dog, and when the dog wins, they receive a share of the prize money. This innovative approach combines the thrill of racing with investment opportunities, making it accessible for everyone.
						</Typography>
					</AccordionDetails>
				</Accordion>
				<Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
					<AccordionSummary aria-controls="panel2d-content" id="panel2d-header">
						<Typography component="span">It is a long established fact that a reader will be distracted by the readable content</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							At Winners Are Grinners, we understand that clear and engaging content is crucial for our users. Our platform is designed to provide straightforward information about each dog, race outcomes, and investment opportunities, ensuring that you stay informed and focused on your racing experience.
						</Typography>
					</AccordionDetails>
				</Accordion>
				<Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
					<AccordionSummary aria-controls="panel3d-content" id="panel3d-header">
						<Typography component="span">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							Much like the variations of Lorem Ipsum, our platform has evolved through user feedback and industry insights. We continuously refine our features and services to ensure that we meet the needs of our community while maintaining transparency and trust in the dog racing process.
						</Typography>
					</AccordionDetails>
				</Accordion>
				<Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
					<AccordionSummary aria-controls="panel4d-content" id="panel4d-header">
						<Typography component="span">All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							Unlike generic platforms, Winners Are Grinners offers a unique and interactive experience tailored to dog racing enthusiasts. We provide real-time updates, in-depth statistics about each dog, and a vibrant community, making our platform the go-to destination for dog racing investments.
						</Typography>
					</AccordionDetails>
				</Accordion>
				<Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
					<AccordionSummary aria-controls="panel5d-content" id="panel5d-header">
						<Typography component="span">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							Similarly, Winners Are Grinners is not just about random bets; it's built on a foundation of expertise, passion for dog racing, and community engagement. We aim to educate users about the sport and create a sense of camaraderie among investors, making every race an exciting event.
						</Typography>
					</AccordionDetails>
				</Accordion>
				<Accordion expanded={expanded === 'panel6'} onChange={handleChange('panel6')}>
					<AccordionSummary aria-controls="panel6d-content" id="panel6d-header">
						<Typography component="span">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</Typography>
					</AccordionSummary>
					<AccordionDetails>
						<Typography>
							Just as there are numerous versions of Lorem Ipsum, our platform embraces creativity and fun in dog racing. We encourage our community to engage in friendly competition and share their experiences, fostering a lively atmosphere where everyone can enjoy the excitement of racing together.
						</Typography>
					</AccordionDetails>
				</Accordion>
			</div>
		</>
	);
}

export default FaqList;
