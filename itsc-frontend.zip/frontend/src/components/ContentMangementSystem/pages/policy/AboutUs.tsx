import React, { useEffect, useState } from 'react';
import { aboutpage_img02, freepik_br01, innerbanner, up_arrow } from "../../../../assets";
import Footer from "../../shared/footer/Footer";
import Navbar from '../../shared/navbar/Navbar';

// CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../../ContentMangementSystem/globalStyles/stellarnav.css";
import "../../../ContentMangementSystem/globalStyles/animate.css";
import "../../../ContentMangementSystem/globalStyles/style.css";
import "../../../ContentMangementSystem/globalStyles/responsive.css";



const AboutUs = () => {
	const [isVisible, setIsVisible] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	return (
		<>
			<div className="flex flex-col gap-4">
				<Navbar />

				{/* <!-- Inner Banner Section --> */}
				<section className="breadcumb">
					<div className="swiper-slide breadcumb"><img src={innerbanner} alt="" className="img-fluid" />
						<div id="overlay"></div>
						<div className="hero-content">
							<div className="hero-content-upper">
								<div className="container">
									<h2 className="wow animate fadeInUp">ABOUT US</h2>
								</div>
							</div>
						</div>
					</div>
				</section>
				{/* <!-- Inner Banner Section End --> */}

				{/* <!-- AboutPage Section --> */}
				<div className="aboutpage-section wow animate fadeInUp">
					<div className="container-fluid">
						<p>Winners Are Grinners® is driven by a proficient team of greyhound racing experts based in NSW, ready to provide you with tips for greyhound and horse racing in Australia. These tips enhance the chances of racing enthusiasts making informed bets that can lead to profitable outcomes.  As a well-established entity in the industry, we stay ahead of the curve with the latest updates on greyhound racing results, utilising this information to strategise our next moves. Together, we collaborate to formulate the most effective strategies for optimal success.</p>

						<div className="aboutpageimg"><img className="" src={aboutpage_img02} alt="" title="" /></div>

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>


					</div>


					<div className="row">

						<div className="col-lg-5 col-md-5 col-12">
							<div className="aboutpage-left">
								<img src={freepik_br01} className="" alt="" />
							</div>
						</div>

						<div className="col-lg-7 col-md-7 col-12">
							<div className="aboutpage-right">
								<p>Winners Are Grinners® is driven by a proficient team of greyhound racing experts based in NSW, ready to provide you with tips for greyhound and horse racing in Australia. These tips enhance the chances of racing enthusiasts making informed bets that can lead to profitable outcomes.  As a well-established entity in the industry, we stay ahead of the curve with the latest updates on greyhound racing results, utilising this information to strategise our next moves. Together, we collaborate to formulate the most effective strategies for optimal success.</p>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
							</div>
						</div>

					</div>

				</div>
				{/* <!-- AboutPage Section End --> */}

				<Footer />
				<div className={`go-top ${isVisible ? 'active' : ''}`} onClick={scrollToTop}>
					<img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" />
				</div>
			</div>
		</>
	);
}

export default AboutUs;
