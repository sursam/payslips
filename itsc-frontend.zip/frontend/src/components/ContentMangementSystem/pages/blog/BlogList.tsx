import React, { useEffect, useState } from 'react';
import Footer from "../../shared/footer/Footer";
import Navbar from '../../shared/navbar/Navbar';

// CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../../ContentMangementSystem/globalStyles/stellarnav.css";
import "../../../ContentMangementSystem/globalStyles/animate.css";
import "../../../ContentMangementSystem/globalStyles/style.css";
import "../../../ContentMangementSystem/globalStyles/responsive.css";

import { blogsimg01, innerbanner, left_arrow, right_arrow, up_arrow } from '../../../../assets';

const BlogList = () => {
	const [isVisible, setIsVisible] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	return (
		<>
			<div className="flex flex-col gap-4">
				<Navbar />

				{/* <!-- Inner Banner Section --> */}
				<section className="breadcumb">
					<div className="swiper-slide breadcumb"><img src={innerbanner} alt="" className="img-fluid" />
						<div id="overlay"></div>
						<div className="hero-content">
							<div className="hero-content-upper">
								<div className="container">
									<h2 className="wow animate fadeInUp">Blogs</h2>
								</div>
							</div>
						</div>
					</div>
				</section>
				{/* <!-- Inner Banner Section End --> */}

				{/* <!-- BlogsPage Section --> */}
				<div className="blogspage-section wow animate fadeInUp">
					<div className="container-fluid">
						<div className="row">

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

						</div>

						<nav aria-label="Page navigation example mt-4">
							<ul className="pagination justify-content-center">
								<li className="page-item">
									<a className="page-link link-prev" href="#" aria-label="Previous">
										<img src={left_arrow} alt="" style={{ width: "20%" }} />
									</a>
								</li>
								<li className="page-item"><a className="page-link active" href="#">1</a></li>
								<li className="page-item"><a className="page-link" href="#">2</a></li>
								<li className="page-item"><a className="page-link" href="#">3</a></li>
								<li className="page-item">
									<a className="page-link link-next" href="#" aria-label="Next">
										<img src={right_arrow} alt="" style={{ width: "20%" }} />
									</a>
								</li>
							</ul>
						</nav>

					</div>


				</div>
				{/* <!-- BlogsPage Section End --> */}

				<Footer />
				<div className={`go-top ${isVisible ? 'active' : ''}`} onClick={scrollToTop}>
					<img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" />
				</div>
			</div>
		</>
	);
}

export default BlogList;
