import React, { useEffect, useState } from 'react';
import Footer from "../../shared/footer/Footer";
import Navbar from '../../shared/navbar/Navbar';

// CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../../ContentMangementSystem/globalStyles/stellarnav.css";
import "../../../ContentMangementSystem/globalStyles/animate.css";
import "../../../ContentMangementSystem/globalStyles/style.css";
import "../../../ContentMangementSystem/globalStyles/responsive.css";


import { bannerblog, blogsimg01, up_arrow } from '../../../../assets';

const BlogDetails = () => {
	const [isVisible, setIsVisible] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	return (
		<>
			<div className="flex flex-col gap-4">
				<Navbar />

				{/* <!-- Blog Details Banner Section --> */}
				<section className="bannerblog-details">
					<img src={bannerblog} alt="" className="img-fluid" />
					<div id="overlay"></div>
					<div className="bannerblog-detailtext">
						<h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h5>
						<h6>10 May 2025  |  By Admin</h6>
					</div>
				</section>
				{/* <!-- Blog Details Banner Section End --> */}


				{/* <!-- BlogsPage Section --> */}
				<div className="blogspage-section wow animate fadeInUp">
					<div className="container-fluid">

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>

						<h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>

					</div>
				</div>
				{/* <!-- BlogsPage Section End --> */}


				{/* <!-- Related Blogs Section --> */}
				<div className="relatedblog-section wow animate fadeInUp">
					<div className="container-fluid">
						<h3>Related Blogs</h3>

						<div className="row">

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>

							<div className="col-lg-3 col-md-6 col-12">
								<div className="blogscard">
									<div className="blogsimg"><img src={blogsimg01} alt="" /></div>
									<h5>POSTED DATE <a href="/blog-details">12 Jan 2025</a></h5>
									<p>Winners Are Grinners® has been crafted by experts deeply immersed in the wo...</p>
									<a href="/blog-details" className="readlink">Read More</a>
								</div>
							</div>



						</div>

					</div>
				</div>
				{/* <!-- Related Blogs Section End --> */}

				<Footer />
				<div className={`go-top ${isVisible ? 'active' : ''}`} onClick={scrollToTop}>
					<img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" />
				</div>
			</div>
		</>
	);
}

export default BlogDetails;
