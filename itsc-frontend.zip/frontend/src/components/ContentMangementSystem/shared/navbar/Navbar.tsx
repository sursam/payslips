import React, { useEffect, useState } from "react";
import { logo } from "../../../../assets";
import { Link, useLocation } from 'react-router-dom';

const Navbar = () => {
	const [isScrolled, setIsScrolled] = useState(false);
	const [isMobile, setIsMobile] = useState(false);
	const [menuOpen, setMenuOpen] = useState(false);
	const location = useLocation();
	const currentPath = location.pathname;

	const handleScroll = () => {
		setIsScrolled(window.scrollY > 50);
	};

	const handleResize = () => {
		setIsMobile(window.innerWidth <= 1024);
		if (window.innerWidth > 1024) {
			setMenuOpen(false); // Close menu when switching to desktop
		}
	};

	const toggleMenu = () => {
		setMenuOpen(!menuOpen);
	};

	useEffect(() => {
		window.addEventListener("scroll", handleScroll);
		window.addEventListener("resize", handleResize);

		// Set initial state for mobile mode
		handleResize();

		return () => {
			window.removeEventListener("scroll", handleScroll);
			window.removeEventListener("resize", handleResize);
		};
	}, []);

	return (
		<nav className={`main-nav ${isScrolled ? "scroll" : ""}`}>
			<div className="container-fluid">
				<div className="headerWrap">
					{/* Logo Section */}

					<div className="logo animate__animated animate__rotateIn">
						<a href="/" className="navbar-brand">
							<img
								src={logo}
								alt="Winners Are Grinners"
								title="Winners Are Grinners"
							/>
						</a>
					</div>


					{/* Toggle Button for Mobile */}
					{isMobile && (
						<button
							className="menu-toggle"
							onClick={toggleMenu}
						// style={{
						// 	background: "transparent",
						// 	border: "none",
						// 	fontSize: "24px",
						// 	position: "absolute",
						// 	top: "15px",
						// 	right: "20px",
						// 	cursor: "pointer",
						// }}
						>
							<span className="menuBar"></span>
							<span className="menuBar"></span>
							<span className="menuBar"></span>
						</button>
					)}

					{/* Navigation Links */}
					<div id="main-nav"
						className={`stellarnav ${menuOpen ? "open" : ""
							}`}
					// style={{
					// 	display: isMobile ? (menuOpen ? "block" : "none") : "flex",
					// 	flexDirection: isMobile ? "column" : "row",
					// 	alignItems: isMobile ? "flex-start" : "center",
					// 	backgroundColor: isMobile ? "#fff" : "transparent",
					// 	position: isMobile ? "absolute" : "static",
					// 	top: isMobile ? "60px" : "auto",
					// 	right: isMobile ? "0" : "auto",
					// 	width: isMobile ? "100%" : "auto",
					// 	padding: isMobile ? "20px" : "0",
					// }}
					>
						<ul>
							<li>
								<a href="/" className={currentPath === '/' ? 'active' : ''}>
									Home
								</a>
							</li>
							<li>
								<a href="/blog" className={currentPath === '/blog' ? 'active' : ''}>Blogs</a>
							</li>
							<li>
								<a href="/#membership" className={currentPath === '/#membership' ? 'active' : ''}>Membership</a>
							</li>
							<li>
								<a href="/faq" className={currentPath === '/faq' ? 'active' : ''}>FAQ</a>
							</li>
							<li>
								<a href="/about-us" className={currentPath === '/about-us' ? 'active' : ''}>About Us</a>
							</li>
							<li>
								<a href="/contact" className={currentPath === '/contact' ? 'active' : ''}>Contact</a>
							</li>
						</ul>

						{/* Member Login Button */}
						<div className="rightlink animate__animated animate__rotateIn">
							<a href="/" className="brochurebtn">
								Member Login
							</a>
						</div>
					</div>
				</div>
			</div>
		</nav>
	);
};

export default Navbar;
