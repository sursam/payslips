import React from "react";
import { app_store, facebook, footerlogo01, google_play, twitter, youtube_circle } from "../../../../assets";

const Footer = () => {
	const currentYear = new Date().getFullYear();

	return (
		<>
			{/* <!-- Footer --> */}
			<footer className="footer">
				<div className="container-fluid">
					<div className="footertop"></div>

					<div className="row">
						<div className="col-lg-3 col-md-6 col-12">
							<div className="footer-links">
								<div className="footerlogo">
									<a href="/">
										<img
											className=""
											src={footerlogo01}
											alt=""
											title="Winners Are Grinners"
										/>
									</a>
								</div>
								<div className="social-icon">
									<ul>
										<li>
											<a href="https://www.facebook.com/">
												<img src={facebook} alt="" />
											</a>
										</li>
										<li>
											<a href="https://twitter.com">
												<img src={twitter} alt="" />
											</a>
										</li>
										<li>
											<a href="https://www.youtube.com/">
												<img src={youtube_circle} alt="" />
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>

						<div className="col-lg-3 col-md-6 col-12">
							<div className="footer-links">
								<h2>Quick Links</h2>
								<ul>
									<li>
										<a href="/">Home</a>
									</li>
									<li>
										<a href="/about-us">About Us</a>
									</li>
									<li>
										<a href="/#membership">Membership</a>
									</li>
									<li>
										<a href="/blog">Blogs</a>
									</li>
									<li>
										<a href="/contact">Contact Us</a>
									</li>
								</ul>
							</div>
						</div>

						<div className="col-lg-3 col-md-6 col-12">
							<div className="footer-links">
								<h2>Important Links</h2>
								<ul>
									<li>
										<a href="/terms-condition">Terms & Conditions</a>
									</li>
									<li>
										<a href="/privacy-policy">Privacy Policy</a>
									</li>
									<li>
										<a href="/faq">FAQ’s</a>
									</li>
								</ul>
							</div>
						</div>

						<div className="col-lg-3 col-md-6 col-12">
							<div className="footer-links">
								<h2>Download App</h2>

								<div className="download-app">
									<a href="#">
										<img
											className=""
											src={google_play}
											alt=""
											title=""
										/>
									</a>{" "}
									<a href="#">
										<img className="" src={app_store} alt="" title="" />
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div className="container-fluid">
					<div className="copyright">
						<div className="row">
							<div className="col-lg-12 col-md-12 col-12 copyright-left">
								© {currentYear} – <a href="/">Winners Are Grinners®</a> | All rights
								reserved, {currentYear}
							</div>
						</div>
					</div>
				</div>
			</footer>
			{/* <!-- Footer End --> */}
		</>
	);
}

export default Footer