import React, { useEffect, useState } from 'react';
import Home from "./pages/home/Home";
import Footer from "./shared/footer/Footer";
import Navbar from "./shared/navbar/Navbar";

// CSS
import "../ContentMangementSystem/globalStyles/stellarnav.css";
import "../ContentMangementSystem/globalStyles/style.css";
// import "../ContentMangementSystem/globalStyles/animate.css";
import "../ContentMangementSystem/globalStyles/responsive.css";

import { Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
// import 'animate.css';
import { up_arrow } from '../../assets';

const MasterCMS = () => {
	const [isVisible, setIsVisible] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	return (
		<div className="flex flex-col gap-4">
			<Navbar />
			<Home />
			<Footer />
			<div className={`go-top ${isVisible ? 'active' : ''}`}
				onClick={scrollToTop}><img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" /></div>
		</div>
	);
}

export default MasterCMS;