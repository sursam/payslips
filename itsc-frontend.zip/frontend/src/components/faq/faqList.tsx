import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../utils/api';
import { can } from "../../utils/helper";
import {
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Typography,
	Box,
	Link,
	Skeleton
} from '@mui/material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import LayoutProvider from '../../providers/LayoutProvider';
import { toast } from 'react-toastify';
import Loader from '../Loader/loader';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import { FaqProps } from '../../types';

function stripHtmlTags(html: string) {
	if (!html) return '';
	const doc = new DOMParser().parseFromString(html, 'text/html');

	return doc.body.textContent || '';
}

const FaqSkleton: React.FC = () => {
	return (
		<Box
			sx={{
				mb: 3,
				boxShadow: 3,
				borderRadius: 2,
				overflow: 'hidden',
				backgroundColor: '#f0f0f0',
			}}
		>
			{/* Simulated Accordion Header */}
			<Box
				sx={{
					backgroundColor: '#cfd8dc',
					px: 2,
					py: 1.5,
				}}
			>
				<Skeleton variant="text" width="60%" height={24} animation="wave" />
			</Box>

			{/* Simulated Accordion Details */}
			<Box sx={{ px: 3, py: 2 }}>
				<Skeleton variant="text" width="90%" height={20} animation="wave" sx={{ mb: 1 }} />
				<Skeleton variant="text" width="80%" height={20} animation="wave" sx={{ mb: 1 }} />
			</Box>
		</Box>
	);
};

const FaqList: React.FC = () => {
	const [expandedIndex, setExpandedIndex] = useState<number | false>(0);
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [faqs, setFaqs] = useState<FaqProps[]>([]);
	const navigate = useNavigate();

	const fetchFaqs = async () => {
		setIsLoading(true);
		try {
			const response = await api.faq.fetchFaq();
			console.log(response);

			if (response) {
				setIsLoading(false);
				setFaqs(response);

			} else {
				setIsLoading(false);
				toast.error(response?.message || 'Failed to fetch FAQs');
			}
		} catch (error) {
			setIsLoading(false);
			toast.error('Something went wrong while fetching FAQs');
		}
	};

	useEffect(() => {
		if (!can(['view-faq'])) {
			navigate(`/dashboard`);
		}
		fetchFaqs();
	}, []);

	const getYouTubeThumbnail = (url: string): string | null => {
		const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^\s&]+)/);
		return match ? `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg` : null;
	};

	return (
		<LayoutProvider pageTitle="FAQs">
			{isLoading ? (
				Array.from({ length: 3 }).map((_, index) => (
					<FaqSkleton key={index} />
				))
			) : (
				<Box sx={{ px: { xs: 2, md: 4 }, py: 3 }}>

					{faqs && faqs.length > 0 ? (
						faqs.map((faq, index) => {

							const thumbnailUrl = faq.link && getYouTubeThumbnail(faq.link);

							return (
								<Accordion
									key={index}
									expanded={expandedIndex === index}
									onChange={() =>
										setExpandedIndex(expandedIndex === index ? false : index)
									}
									sx={{
										mb: 3,
										boxShadow: 3,
										borderRadius: 2,
										transition: '0.3s',
										'&:hover': {
											boxShadow: 6,
										},
									}}
								>
									<AccordionSummary
										expandIcon={<ArrowDropDownIcon sx={{ color: '#fff' }} />}
										aria-controls={`panel${index}-content`}
										id={`panel${index}-header`}
										sx={{
											backgroundColor: '#005daa',
											borderRadius: '10px',
											px: 2,
											py: 1.5,
										}}
									>
										<Typography
											component="span"
											sx={{
												color: '#fff',
												fontWeight: 500,
												wordWrap: 'break-word',
												wordBreak: 'break-word',
												overflowWrap: 'break-word'
											}}
										>
											{faq.question}
										</Typography>
									</AccordionSummary>

									<AccordionDetails sx={{ px: 3, py: 2 }}>
										<Typography
											sx={{
												mb: 2,
												fontSize: '1rem',
												lineHeight: 1.6,
												wordWrap: 'break-word',
												wordBreak: 'break-word',
												overflowWrap: 'break-word'
											}}
										>
											{stripHtmlTags(faq.answer)}
										</Typography>

										{thumbnailUrl && (
											<Box sx={{ mb: 2 }}>
												<Link href={faq.link} target="_blank" rel="noopener noreferrer">
													<Box
														component="img"
														src={thumbnailUrl}
														alt="YouTube Thumbnail"
														sx={{
															width: '100%',
															maxWidth: 500,
															borderRadius: 2,
															cursor: 'pointer',
															transition: '0.3s',
															'&:hover': {
																transform: 'scale(1.02)',
															},
														}}
													/>
												</Link>
											</Box>
										)}

										{faq.link && faq.link != "No Link" && (
											<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
												<PlayCircleOutlineIcon color="primary" />
												<Link
													href={faq.link}
													target="_blank"
													rel="noopener noreferrer"
													underline="hover"
													sx={{
														fontSize: '0.95rem',
														wordWrap: 'break-word',
														wordBreak: 'break-word',
														overflowWrap: 'break-word'
													}}
												>
													Watch Video
												</Link>
											</Box>
										)}
									</AccordionDetails>
								</Accordion>
							);
						})
					) : (
						<Box
							sx={{
								display: 'flex',
								flexDirection: 'column',
								alignItems: 'center',
								justifyContent: 'center',
								py: 6,
								px: 3,
								textAlign: 'center',
								backgroundColor: '#f5f5f5',
								borderRadius: 2,
								border: '1px dashed #ddd',
							}}
						>
							<HelpOutlineIcon
								sx={{
									fontSize: 60,
									color: '#bbb',
									mb: 2
								}}
							/>
							<Typography
								variant="h6"
								sx={{
									color: '#666',
									mb: 1,
									fontWeight: 500
								}}
							>
								No FAQs Available
							</Typography>
							<Typography
								variant="body2"
								sx={{
									color: '#888'
								}}
							>
								There are currently no frequently asked questions to display.
							</Typography>
						</Box>
					)}
				</Box>
			)}
		</LayoutProvider>
	);
};

export default FaqList;
