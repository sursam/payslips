import React, { useEffect, useState } from 'react';
import { api } from '../../utils/api';
import moment from 'moment';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import { useNavigate } from 'react-router-dom';
import Loader from '../Loader/loader';
import {
    Avatar,
    Box,
    Grid,
    Card,
    CardContent,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableRow,
    Typography,
} from '@mui/material';
import 'react-toastify/dist/ReactToastify.css';
import styles from '../../styles/profile.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import ContactEmergencyOutlinedIcon from '@mui/icons-material/ContactEmergencyOutlined';
import { toast } from 'react-toastify';

interface Profile {
    fname: string;
    lname: string;
    profile_image: string;
    days_ago: string;
    my_jobs: string;
    average_rating: string;
    email: string;
    dob: string;
    mobile: string;
    country_code: string;
    complete_profile_info: {
        company_legal_name: string;
        company_dba: string;
        phone_2: string;
        tax_id: string;
    };
    address: string;
    state_details: {
        // state_id: string;
        state_name: string;
    };
    city_details: {
        // id: string;
        name: string;
    };
    pincode: string;
    country_details: {
        // country_id: string;
        country_name: string;
    };

    // city: string;
    // state: string;
    // country: string;
}

const ViewProfile: React.FC = () => {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [profileData, setProfileData] = useState<Profile | null>(null);

    const fetchProfileData = async () => {
        setIsLoading(true);
        try {
            const response = await api.profile.fetchProfile();
            if (response.status) {
                setIsLoading(false);
                console.log("profile:", response.data.user);
                setProfileData(response.data.user);
            } else {
                toast.error(response?.message);
                setIsLoading(false);
            }
        } catch (error) {
            setIsLoading(false);
            console.error("Failed to fetch jobs:", error);
        }
    };

    useEffect(() => {
        fetchProfileData();
    }, []);
    const handleEditProfile = () => {
        navigate('/profile/edit');
    };
    return (
        <LayoutProvider pageTitle="Profile">
            <Grid container spacing={3} sx={{ marginBottom: '0px', position: 'relative', padding: '0px' }}>
                {isLoading ?
                    <Box className="loaderContainer">
                        <Loader />
                    </Box>
                    : ''
                }
                <Grid>
                    <CardContent className={styles.gridBoxwrap} sx={{ padding: '0 !important', margin: '0' }}>
                        {/* Image Card */}
                        <Card sx={{ borderRadius: 2, boxShadow: 3, p: 2 }}>
                            <div style={{ "position": "relative", }} className='fewrqwd'>

                                <div className={styles.cardTitle} style={{ "height": "260px" }}>
                                    <img
                                        src='/assets/images/background.png'
                                        alt="Profile Background"
                                        style={{
                                            width: '100%',
                                            height: '100%',
                                            borderRadius: '8px',
                                            objectFit: 'cover'
                                        }}
                                    />
                                </div>

                                {/* Profile Summary Card */}
                                <Card className='testingcard' sx={{
                                    borderRadius: 2,
                                    boxShadow: 3,
                                    padding: { xs: 2, md: 3 },
                                    maxWidth: 'calc(100% - 60px)',
                                    width: '100%',
                                    mx: 'auto',
                                    marginTop: '-60px',
                                    // position: "absolute",
                                    // top: "60%",
                                    // left: "0",
                                    // transform: "translateX(-50%)",
                                    right: '0',
                                    position: 'relative',
                                    zIndex: "2",
                                    minHeight: "476px",
                                    overflow: "visible",
                                    boxSizing: 'border-box'
                                }}>
                                    <IconButton
                                        sx={{
                                            position: 'absolute',
                                            top: -9,
                                            right: -7,
                                            backgroundColor: '#f0f0f0',
                                            boxShadow: 1,
                                            '&:hover': {
                                                backgroundColor: '#e0e0e0'
                                            }
                                        }}
                                        aria-label="edit profile"
                                        onClick={handleEditProfile}
                                    >
                                        <EditIcon sx={{ color: '#333' }} />
                                    </IconButton>
                                    <Box sx={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        flexWrap: 'wrap',
                                        gap: 2,
                                        border: '1px solid #ddd',
                                        padding: '10px',
                                        borderRadius: '10px'
                                    }}>
                                        {/* Left: Avatar and Name */}
                                        <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                                            <Avatar
                                                alt="Remy Sharp"
                                                src={profileData?.profile_image}
                                                sx={{ width: '100px', height: 100, border: '1px solid #f3f3f3' }}
                                            />
                                            <Box>
                                                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>{profileData?.fname} {profileData?.lname}</Typography>
                                                <Typography variant="body2" sx={{ fontSize: '14px', lineHeight: '1.2', color: '#64748b' }}>Contractor</Typography>
                                            </Box>
                                        </Box>
                                        {/* Member Since */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Member</Typography>
                                            <Typography variant="h6" sx={{ fontSize: '14px', lineHeight: '1.2', color: '#64748b' }}>{profileData?.days_ago} Days</Typography>
                                        </Box>

                                        {/* Posted Jobs */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Posted Jobs</Typography>
                                            <Typography variant="h6" sx={{ fontSize: '14px', lineHeight: '1.2', color: '#64748b' }}>{profileData?.my_jobs}</Typography>
                                        </Box>

                                        {/* Ratings */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Rating</Typography>
                                            <Typography variant="h6" sx={{ fontSize: '14px', lineHeight: '1.2', color: '#64748b' }}>{profileData?.average_rating}</Typography>
                                        </Box>
                                    </Box>
                                    <TableContainer sx={{ marginTop: 2, }}>
                                        <Table sx={{
                                            tableLayout: 'fixed',
                                            '& .MuiTableCell-root': {
                                                width: '50%',
                                                height: 'auto',
                                                border: '1px solid #ddd',
                                                textAlign: 'center',
                                                verticalAlign: 'middle',
                                                whiteSpace: 'nowrap',
                                                textOverflow: 'ellipsis'
                                            }
                                        }}>
                                            <TableBody>
                                                <TableRow>
                                                    <TableCell sx={{ paddingTop: '8px', paddingBottom: '8px' }}>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            flexDirection: 'row',
                                                            alignItems: 'center',
                                                            gap: 1
                                                        }}>
                                                            <Typography sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                                Email ID:
                                                            </Typography>
                                                            <Typography className='treamoneLine' sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                                {profileData?.email}
                                                            </Typography>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Date Of Birth:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {moment(profileData?.dob).format('MMMM Do YYYY')}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>

                                                <TableRow>
                                                    <TableCell>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            flexDirection: 'row',
                                                            alignItems: 'center',
                                                            gap: 2
                                                        }}>
                                                            <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                                Mobile Number:
                                                            </Typography>
                                                            <Typography variant="body1">
                                                                +{profileData?.country_code}-{profileData?.mobile}
                                                            </Typography>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Company Name:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.complete_profile_info?.company_legal_name ? profileData?.complete_profile_info?.company_legal_name : 'N/A'}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Address:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.address}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Company DBA:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.complete_profile_info?.company_dba ? profileData?.complete_profile_info?.company_dba : 'N/A'}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            flexDirection: 'row',
                                                            alignItems: 'center',
                                                            gap: 2
                                                        }}>
                                                            <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                                Country:
                                                            </Typography>
                                                            <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                                {profileData?.complete_profile_info?.phone_2 ? profileData?.country_details?.country_name : ''}
                                                            </Typography>
                                                        </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Company Ph No.:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.complete_profile_info?.phone_2 ? + profileData?.complete_profile_info?.phone_2 : 'N/A'}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            State:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.state_details?.state_name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            EIN / TAX ID:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profileData?.complete_profile_info?.tax_id?.length >= 4
                                                                ? `*** *** ${profileData.complete_profile_info.tax_id.slice(-3)}`
                                                                : 'N/A'}
                                                        </Typography>

                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            City:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.city_details?.name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{ fontWeight: 'bold', fontSize: '14px', lineHeight: '1.2' }}>
                                                            Zip Code:
                                                        </Typography>
                                                        <Typography variant="body1" sx={{ fontSize: '14px', lineHeight: '1.2' }}>
                                                            {profileData?.pincode}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Card>
                            </div>
                        </Card>
                    </CardContent>
                </Grid>
            </Grid>
        </LayoutProvider >
    );
};

export default ViewProfile;