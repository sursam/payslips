import React, { useEffect, useRef, useState } from 'react';
import { Avatar, AppBar, Toolbar, Typography, IconButton, Menu, MenuItem, Modal, TextField, Button, Box, InputAdornment } from '@mui/material';
import styles from '../../styles/header.module.css'
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext'; // Import the AuthContext
import Badge from '@mui/material/Badge';
import { MenuOutlined, ArrowBackOutlined, NotificationsOutlined, ShoppingCartOutlined, ExpandMoreOutlined, ExpandLessOutlined, Person2Outlined, KeyOutlined, LogoutOutlined, PaymentOutlined } from '@mui/icons-material';
import CampaignSharpIcon from '@mui/icons-material/CampaignSharp';
import { api } from '../../utils/api';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { ToastContainer, toast } from 'react-toastify';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import moment from 'moment';
import { can } from "../../utils/helper";

interface HeaderProps {
    isOpen: boolean;
    toggleSidebar: () => void;
}
interface UpdatePasswordForm {
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
}
interface Profile {
    fname: string;
    lname: string;
    country_code: string;
    mobile: string;
    email: string;
    dob: string;
    address: string;
    days_ago: string;
    my_jobs: string;
    average_rating: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    profile_image: string;
    total_unread_job_alerts: number;
    total_normal_job_alerts: number;
}
const languages = [
    { code: 'en', label: 'English', icon: '/assets/images/english.png' },
    { code: 'es', label: 'Español', icon: '/assets/images/span-flag.png' },
];

const Header: React.FC<HeaderProps> = ({ isOpen, toggleSidebar }) => {

    // const user = useSelector((state: RootState) => state.auth);
    // const token = useSelector((state: RootState) => state.auth.token);
    // const isAuthenticated = useSelector((state: RootState) => state.auth.isLoggedIn);

    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const [showNoti, setShowNoti] = React.useState(false);
    const [showJobNoti, setShowJobNoti] = React.useState(false);
    const [showAnnounce, setShowAnnounce] = React.useState(false);
    const [announcementList, setAnnouncementList] = React.useState<any>([]);
    const [imageUrl, setImageUrl] = React.useState<any>();
    const [notificationList, setNotificationList] = React.useState<any>([]);
    const [jobNotificationList, setJobNotificationList] = React.useState<any>([]);
    const [profile, setProfile] = React.useState<Profile>();
    const [openChangePasswordModal, setOpenChangePasswordModal] = React.useState(false);
    const [showOldPassword, setShowOldPassword] = useState<boolean>(false);
    const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
    const [open, setOpen] = React.useState(false);
    const [selectedLang, setSelectedLang] = useState('en');
    const navigate = useNavigate();
    const { logout } = useAuth(); // Get the logout function from context

    const location = useLocation(); // Get the current location
    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const notificationRef = useRef<HTMLDivElement>(null);
    const jobNotificationRef = useRef<HTMLDivElement>(null);
    const announcementRef = useRef<HTMLDivElement>(null);

    const [age, setAge] = React.useState<string | number>('');
    const [languageOpen, setLanguageOpen] = React.useState(false);

    const handleChange = (event: SelectChangeEvent<typeof age>) => {
        setAge(event.target.value);
    };

    const handleLanguageClose = () => {
        setLanguageOpen(false);
    };

    const handleLanguageOpen = () => {
        setLanguageOpen(true);
    };

    // validation for change password modal
    const validationSchema = Yup.object().shape({
        oldPassword: Yup.string().required('Old password is required'),
        newPassword: Yup.string()
            .required('New Password is required')
            .min(8, 'New Password must be at least 8 characters')
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/,
                'New Password must include at least one uppercase letter, one lowercase letter, one number, and one special character'
            ),
        confirmPassword: Yup.string()
            .required('Confirm password is required')
            .oneOf([Yup.ref('newPassword')], 'Passwords must match'),
    });
    var formOptions = { resolver: yupResolver(validationSchema) };
    // Form setup with proper default values
    const { register, handleSubmit, formState: { errors } } = useForm(formOptions);

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleProfileClick = () => {
        navigate('/profile');
    };

    useEffect(() => {
        fetchProfile();
        // fetchNotifications();
        // fetchJobNotifications();
    }, []);

    const fetchProfile = async () => {
        try {
            const response = await api.profile.fetchProfile();
            if (response) {
                setProfile(response.data.user);
            }
        } catch (error) {
            console.error("Failed to fetch notifications:", error);
        }
    };
    const fetchNotifications = async () => {
        const notiresponse = await api.notifications.fetchNotifications();
        if (notiresponse.length > 0) {
            setNotificationList(notiresponse);
        }
    }
    const fetchJobNotifications = async () => {
        const jobNotiResponse = await api.notifications.fetchJobNotification();
        if (jobNotiResponse.length > 0) {
            setJobNotificationList(jobNotiResponse);
        }
    }

    const handleAnnouncementClick = async () => {
        setShowAnnounce(!showAnnounce)
        const response = await api.Announcement.fetchAnnouncements();
        setAnnouncementList(response)
    };
    const handleNotification = async () => {
        setShowJobNoti(false);
        // setShowNoti(!showNoti);
        const notiresponse = await api.notifications.fetchNotifications();
        if (notiresponse.length > 0) {
            setShowNoti(!showNoti);
            setNotificationList(notiresponse);
        }
    }
    const handleJobNotification = async () => {
        setShowNoti(false);
        // setShowJobNoti(!showJobNoti);
        const jobNotiResponse = await api.notifications.fetchJobNotification();
        if (jobNotiResponse.length > 0) {
            setShowJobNoti(!showJobNoti);
            setJobNotificationList(jobNotiResponse);
        }
    }
    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = async () => {
        await api.auth.logout();
        logout();
        navigate('/');
        handleClose();
    };
    const handleLanguageChange = (event) => {
        setSelectedLang(event.target.value);
        // Optional: trigger language change logic here
    };
    const handleAllNoti = () => {
        navigate('/notification');
    }
    const handleJobNotifications = () => {
        navigate('/job-notification');
    }
    const handleShowAnnouncement = () => {
        navigate('/announcements', { state: { announcementList } });
    }
    const handleClickOutside = (event: MouseEvent) => {
        if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
            setShowNoti(false)
        }
        if (jobNotificationRef.current && !jobNotificationRef.current.contains(event.target as Node)) {
            setShowJobNoti(false)
        }
        if (announcementRef.current && !announcementRef.current.contains(event.target as Node)) {
            setShowAnnounce(false)
        }
    }
    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);
    useEffect(() => {
        let objectUrl: any;

        announcementList.map((list: any) => {
            if (list.image instanceof File) {
                objectUrl = URL.createObjectURL(list?.image);
                setImageUrl(objectUrl);
            } else {
                setImageUrl(list?.image);
            }
        })

        return () => {
            if (objectUrl) {
                URL.revokeObjectURL(objectUrl);
            }
        };
    }, [announcementList]);
    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleModalClose = () => {
        setOpen(false);
    };
    // update password api call
    const onSubmit = async (data: UpdatePasswordForm) => {
        try {
            const payload = {
                old_password: data.oldPassword,
                new_password: data.newPassword,
                confirm_password: data.confirmPassword
            };


            // Submit to API
            const response = await api.profile.changePassword(payload);
            if (response?.status) {
                toast.success('password changed successfully');
                handleModalClose();
            } else {
                toast.error(response?.message);
            }
        } catch (error) {
            console.error('Error updating password', error);
        }
    };
    return (
        <>
            <AppBar position="static" className={styles.navBar}>
                <Toolbar className={styles.header} sx={{ marginLeft: isOpen ? '251px' : '60px', transition: 'margin-left 0.3s' }}>
                    <IconButton onClick={toggleSidebar} className={styles.toggleButton}>
                        <MenuOutlined style={{ width: '30px', height: '30px', color: '#283c50' }}></MenuOutlined>
                    </IconButton>
                    <div className={styles.icons}>
                        <div className={styles.lagBox}>
                            <FormControl fullWidth variant="outlined" size="small" className='lanField'>
                                <Select
                                    labelId="language-select-label"
                                    value={selectedLang}
                                    onChange={handleLanguageChange}
                                    label="Language"
                                >
                                    {languages.map(lang => (
                                        <MenuItem key={lang.code} value={lang.code}>
                                            <img src={lang.icon} style={{ width: 24, height: 24, marginRight: 1 }} />
                                            {lang.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </div>
                        {can(['view-job-notifications']) ?
                            <div className={styles.iconBox}>
                                <IconButton color="inherit" onClick={handleJobNotification}>
                                    {profile?.total_unread_job_alerts > 0 ? (
                                        <Badge badgeContent={profile?.total_unread_job_alerts > 0 ? profile?.total_unread_job_alerts : ''} color="error">
                                            <CampaignSharpIcon style={{ width: '30px', height: '30px', color: '#666666' }}></CampaignSharpIcon>
                                        </Badge>
                                    ) : (
                                        <CampaignSharpIcon style={{ width: '30px', height: '30px', color: '#666666' }}></CampaignSharpIcon>
                                    )}
                                </IconButton>

                            </div>
                            : ''
                        }
                        <div className={styles.iconBox}>
                            <IconButton color="inherit" onClick={handleNotification}>
                                {profile?.total_normal_job_alerts > 0 ? (
                                    <Badge badgeContent={profile?.total_normal_job_alerts > 0 ? profile?.total_normal_job_alerts : ''} color="error">
                                        <NotificationsOutlined style={{ width: '30px', height: '30px', color: '#666666' }}></NotificationsOutlined>
                                    </Badge>
                                ) : (
                                    <NotificationsOutlined style={{ width: '30px', height: '30px', color: '#666666' }}></NotificationsOutlined>
                                )}
                            </IconButton>
                        </div>
                        <div className={styles.iconBox}>
                            <IconButton color="inherit" onClick={handleClick}>
                                <img src={profile?.profile_image || '/assets/images/profile-picture.svg'}
                                    alt="User "
                                    style={{ width: '35px', height: '35px', borderRadius: '50%' }} />
                                {
                                    Boolean(anchorEl) ?
                                        <ExpandLessOutlined sx={{ width: '20px', height: '20px', color: '#666666' }} />
                                        :
                                        <ExpandMoreOutlined sx={{ width: '20px', height: '20px', color: '#666666' }} />
                                }
                            </IconButton>
                        </div>
                    </div>
                    <Menu
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={handleClose}
                        className={styles.headerDropdownMenu}
                    >
                        <MenuItem className={`${styles.menuItem} ${styles.borderBottom}`} onClick={handleProfileClick}>
                            <img src={profile?.profile_image || '/assets/images/profile-picture.svg'} alt="User " style={{ width: '40px', height: '40px', paddingRight: '15px' }} />
                            <div>
                                <Typography className={styles.menuTitle}>{`${userDetails.firstName} ${userDetails.lastName}`}</Typography>
                                <Typography className={styles.menuSubTitle}>{userDetails.email}</Typography>
                            </div>
                        </MenuItem>
                        <MenuItem className={styles.menuItem} onClick={handleProfileClick}>
                            <Person2Outlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Profile Details
                        </MenuItem>
                        <MenuItem className={styles.menuItem} onClick={handleClickOpen} >
                            <KeyOutlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Change Password
                        </MenuItem>
                        {(userDetails?.userRoleSlug == "super-admin" || userDetails?.userRoleSlug == "contractor") ?
                            <MenuItem className={`${styles.menuItem} ${styles.borderBottom}`} onClick={() => navigate('/payment-info')}>
                                <PaymentOutlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Payment Informations
                            </MenuItem>
                            : ''
                        }
                        <MenuItem className={styles.menuItem} onClick={handleLogout}>
                            <LogoutOutlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Logout
                        </MenuItem>
                    </Menu>
                </Toolbar>
            </AppBar>



            {showNoti && (
                <div className={styles.notificationContainer} ref={notificationRef}>
                    <h2 className={styles.notiHeader}> Notifications</h2>

                    {notificationList.length > 0 ? (
                        <>
                            {notificationList.slice(0, 3).map((noti: any, index: number) => {
                                const isLast = index === Math.min(notificationList.length, 3) - 1;
                                return (
                                    <div
                                        key={index}
                                        className={styles.notification}
                                    >
                                        <div className={styles.notificationIcon}>
                                            <IconButton color="inherit">
                                                <img
                                                    src="/assets/images/bell.png"
                                                    alt="Notifications"
                                                    style={{ width: '24px', height: '24px' }}
                                                />
                                            </IconButton>
                                        </div>
                                        <div className={styles.notificationText}>
                                            <p className={styles.notiDescription}>{noti.description}</p>
                                            <span className={styles.notiTimestamp}>
                                                {moment(noti?.created_at).fromNow()}
                                            </span>
                                        </div>
                                    </div>
                                );
                            })}


                            {notificationList.length > 3 && (
                                <button className={styles.notiBtn} onClick={handleAllNoti}>
                                    View All Notifications
                                </button>
                            )}
                        </>
                    ) : (
                        <div className={styles.notificationEmpty}>
                            <p>No new notifications at the moment</p>
                        </div>
                    )}
                </div>
            )}
            {showJobNoti && (
                <div className={styles.notificationContainer} ref={jobNotificationRef}>
                    <h2 className={styles.notiHeader}> Job Notifications</h2>

                    {jobNotificationList.length > 0 ? (
                        <>
                            {jobNotificationList.slice(0, 3).map((noti: any, index: number) => {
                                const isLast = index === Math.min(jobNotificationList.length, 3) - 1;
                                return (
                                    <div
                                        key={index}
                                        className={styles.notification}
                                    >
                                        <div className={styles.notificationIcon}>
                                            <IconButton color="inherit">
                                                <img
                                                    src="/assets/images/bell.png"
                                                    alt="Notifications"
                                                    style={{ width: '24px', height: '24px' }}
                                                />
                                            </IconButton>
                                        </div>
                                        <div className={styles.notificationText}>
                                            <p className={styles.notiDescription}>{noti.description}</p>
                                            <span className={styles.notiTimestamp}>
                                                {moment(noti?.created_at).fromNow()}
                                            </span>
                                        </div>
                                    </div>
                                );
                            })}


                            {jobNotificationList.length > 3 && (
                                <button className={styles.notiBtn} onClick={handleJobNotifications}>
                                    View All Notifications
                                </button>
                            )}
                        </>
                    ) : (
                        <div className={styles.notificationEmpty}>
                            <p>No new notifications at the moment</p>
                        </div>
                    )}
                </div>
            )}

            <Dialog
                open={open}
                onClose={handleModalClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                    sx: { width: '500px', maxWidth: '90%' } // adjust the width as needed
                }}
            >
                <DialogTitle id="alert-dialog-title">
                    {"Change Password"}
                </DialogTitle>
                <DialogContent>
                    <form className="custom-Form" onSubmit={handleSubmit(onSubmit)}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="Old Password"
                                type={showOldPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.oldPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowOldPassword(!showOldPassword)} edge="end">
                                                {!showOldPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.oldPassword}
                                helperText={!!errors?.oldPassword}

                                {...register('oldPassword')}
                            />
                            <div className="invalid-feedback">{errors.oldPassword?.message?.toString()}</div>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="New Password"
                                type={showNewPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.newPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowNewPassword(!showNewPassword)} edge="end">
                                                {!showNewPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.newPassword}
                                helperText={!!errors?.newPassword}

                                {...register('newPassword')}
                            />
                            <div className="invalid-feedback">{errors.newPassword?.message?.toString()}</div>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="Confirm Password"
                                type={showConfirmPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.confirmPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowConfirmPassword(!showConfirmPassword)} edge="end">
                                                {!showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.confirmPassword}
                                helperText={!!errors?.confirmPassword}

                                {...register('confirmPassword')}
                            />
                            <div className="invalid-feedback">{errors.confirmPassword?.message?.toString()}</div>
                        </Box>
                        <div className={styles.formButtonWrap}>
                            <Button onClick={handleModalClose}>Cancel</Button>
                            <Button
                                type='submit'
                                variant="contained"
                                color="primary"
                                className={styles.formButton}
                            >
                                Update
                            </Button>
                        </div>
                    </form>
                </DialogContent>
            </Dialog >
        </>
    );
};

export default React.memo(Header);
// export default Header;