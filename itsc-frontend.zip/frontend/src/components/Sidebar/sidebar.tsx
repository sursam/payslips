import React, { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';
import styles from '../../styles/header.module.css';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { DashboardOutlined, ChevronRightOutlined, ExpandLess, BusinessCenterOutlined, CasesOutlined, CardTravelOutlined, LocalShippingOutlined, PolicyOutlined, StarBorderOutlined, PeopleAltOutlined, PeopleOutlined, PersonAddAltOutlined } from '@mui/icons-material';
import PolicyIcon from '@mui/icons-material/Policy';
import CopyrightIcon from '@mui/icons-material/Copyright';
import GavelIcon from '@mui/icons-material/Gavel';
import LocationSearchingIcon from '@mui/icons-material/LocationSearching';
import HelpCenterIcon from '@mui/icons-material/HelpCenter';
import PaymentsOutlinedIcon from '@mui/icons-material/PaymentsOutlined';
import { can } from "../../utils/helper";

import PostJobLink from '../../components/Dashboard/parts/postJobLink';

interface SidebarProps {
    isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
    const isSubContractor = typeof localStorage !== "undefined" && localStorage.getItem("isSubContractor") === "true";
    const [activeItem, setActiveItem] = useState<string | null>(null);
    const [isUserManagementOpen, setUserManagementOpen] = useState(false);
    const [isJobOpen, setJobOpen] = useState(false);
    const [isLegalOpen, setIsLegalOpen] = useState(false);
    const [isSubContractorOpen, setSubContractorOpen] = useState(false);
    const [isRacesOpen, setRacesOpen] = useState(false);
    const [isSettingsOpen, setSettingsOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        setActiveItem(location.pathname);
        if (location.pathname === '/admin' || location.pathname === '/member') {
            setUserManagementOpen(true);
        } else {
            setUserManagementOpen(false);
        }
    }, [location.pathname]);

    useEffect(() => {
        setActiveItem(location.pathname);
        if (location.pathname === '/subscription' || location.pathname === '/plateformcharges') {
            setSettingsOpen(true);
        } else {
            setSettingsOpen(false);
        }
    }, [location.pathname]);

    const handleMenuItemClick = (item: string) => {

        if (item === '/users') {
            setUserManagementOpen(!isUserManagementOpen);
        } else {
            setActiveItem(item);
            navigate(item);
        }
    };

    const handleJobManagementClick = () => {
        setJobOpen(!isJobOpen); // Toggle Races submenu
    };
    const handleLegalClick = () => {
        setIsLegalOpen(!isLegalOpen);
    }
    const handleSubContractorClick = () => {
        setSubContractorOpen(!isSubContractorOpen); // Toggle Races submenu
    };
    const handleRaceManagementClick = () => {
        setRacesOpen(!isRacesOpen); // Toggle Races submenu
    };

    // const toggleUserManagement = () => {
    //     setUserManagementOpen(!isUserManagementOpen);
    //     if (!isUserManagementOpen) {
    //         setActiveItem('/users');
    //     } else {
    //         setActiveItem(null);
    //     }
    // };

    const toggleSettings = () => {
        setSettingsOpen(!isSettingsOpen);
        if (!isSettingsOpen) {
            setActiveItem('/settings');
        } else {
            setActiveItem(null);
        }
    };

    const handleSubMenuClick = (item: string, event: React.MouseEvent) => {
        event.stopPropagation();
        setActiveItem(item);
        if (item == '/post-job') {
            window.location.href = item;
        }
        else {
            navigate(item);
        }
    };

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    // console.log('userDetails----', localStorage.getItem('userDetails'));
    const firstName = userDetails.firstName || '';
    const lastName = userDetails.lastName || '';
    const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    const userRole = userDetails.userRole;

    return (
        <>
            <Box className={`${styles.sidebar} ${isOpen ? styles.open : styles.closed}`}>
                <Box className={styles.headerContainer}>

                    <img src='/assets/images/logo.png' alt="Logo" className={styles.logo} />

                    <img src='/assets/images/logo-short.png' alt="Logo" className={styles.logosrt} />

                </Box>
                {isOpen ?
                    <div className={styles.menuCaptionContainer}>
                        <Typography className={styles.menuCaption}>Navigation</Typography>
                    </div>
                    : ''
                }
                <div className={styles.menu}>
                    <div className={`${styles.menuItem} ${activeItem === '/dashboard' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/dashboard')}>
                        <DashboardOutlined className={styles.menuIcon}></DashboardOutlined>
                        <Typography className={styles.menuLabel}>Dashboard</Typography>
                    </div>

                    {(userRole === 'SUPER ADMIN' || userRole === 'ADMIN') && (
                        <div className={styles.menuItem} onClick={() => handleMenuItemClick('/users')}>
                            <img src='/assets/images/users_mngt.png' alt="User  Management" className={styles.menuIcon} />
                            {isOpen && (
                                <Typography variant="body1">
                                    User Management
                                    {isUserManagementOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>
                            )}
                        </div>
                    )}
                    {isUserManagementOpen && userRole === 'SUPER ADMIN' && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/admin' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/admin', event)}>
                                <img src='/assets/images/user.png' alt="Admin" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Admin</Typography>}
                            </div>
                        </div>
                    )}
                    {isUserManagementOpen && (userRole === 'SUPER ADMIN' || userRole === 'ADMIN') && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/member' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/member', event)}>
                                <img src='/assets/images/user.png' alt="Member" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Member</Typography>}
                            </div>
                        </div>
                    )}

                    {can(['view-job', 'add-job', 'edit-job', 'delete-job', 'cancel-job', 'verify-job', 'view-notifications']) ?
                        <>
                            <div className={`${styles.menuItem} ${activeItem === '/jobs' ? styles.active : ''}`} onClick={handleJobManagementClick}>
                                <BusinessCenterOutlined className={styles.menuIcon}></BusinessCenterOutlined>

                                <Typography className={styles.menuLabel}>
                                    Jobs
                                    {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>

                            </div>
                            {isJobOpen && (
                                <div className={styles.subMenu}>
                                    {can(['view-job', 'add-job', 'edit-job', 'delete-job', 'cancel-job', 'verify-job', 'view-notifications']) ?
                                        <div className={`${styles.menuItem} ${activeItem === '/job-list' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/job-list', event)}>
                                            <CasesOutlined className={styles.menuIcon}></CasesOutlined>
                                            {isOpen && <Typography className={styles.menuLabel}>Job List</Typography>}
                                        </div>
                                        : ''
                                    }
                                    {can(['add-job']) ?
                                        <PostJobLink redirectTo='/post-job'>
                                            <div className={`${styles.menuItem} ${activeItem === '/post-job' ? styles.active : ''}`}>
                                                <CardTravelOutlined className={styles.menuIcon}></CardTravelOutlined>
                                                {isOpen && <Typography className={styles.menuLabel}>Post New Job</Typography>}
                                            </div>
                                        </PostJobLink>
                                        : ''
                                    }
                                </div>
                            )}
                        </>
                        : ''
                    }
                    {can(['view-loads']) ?
                        <div className={`${styles.menuItem} ${activeItem === '/live-trucks' ? styles.active : ''}`} onClick={(event) => handleMenuItemClick('/live-trucks')}>
                            <LocalShippingOutlined className={styles.menuIcon} />

                            <Typography className={styles.menuLabel}>
                                Live Trucks
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>

                        </div>
                        : ''
                    }
                    {can(['verify-job']) ?
                        <div className={`${styles.menuItem} ${activeItem === '/job-action' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/job-action')}>
                            <LocalShippingOutlined className={styles.menuIcon} />

                            <Typography className={styles.menuLabel}>
                                Job Action
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>

                        </div>
                        : ''
                    }
                    {can(['view-legals']) ?
                        <>
                            <div className={`${styles.menuItem} ${activeItem === '/legal' ? styles.active : ''}`} onClick={handleLegalClick}>
                                <PolicyOutlined className={styles.menuIcon} />

                                <Typography className={styles.menuLabel}>
                                    Legal
                                    {isLegalOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>

                            </div>
                            {isLegalOpen && (
                                <div className={styles.subMenu}>
                                    <Link to="https://www.connectaload.com/copyright" className={styles.menuItem} style={{ textDecoration: 'none' }} target='_blank'>
                                        <CopyrightIcon className={styles.menuIcon} />
                                        {isOpen && <Typography className={styles.menuLabel}>Copyright</Typography>}
                                    </Link>
                                    <Link to="https://www.connectaload.com/terms-and-condition/" className={styles.menuItem} style={{ textDecoration: 'none' }} target='_blank'>
                                        <GavelIcon className={styles.menuIcon} />
                                        {isOpen && <Typography className={styles.menuLabel}>Terms & Conditions</Typography>}
                                    </Link>
                                    <Link to="https://www.connectaload.com/privacy-policy/" className={styles.menuItem} style={{ textDecoration: 'none' }} target='_blank'>
                                        <PolicyIcon className={styles.menuIcon} />
                                        {isOpen && <Typography className={styles.menuLabel}>Privacy Policy</Typography>}
                                    </Link>
                                    <Link to="https://www.connectaload.com/services/" className={styles.menuItem} style={{ textDecoration: 'none' }} target='_blank'>
                                        <LocationSearchingIcon className={styles.menuIcon} />
                                        {isOpen && <Typography className={styles.menuLabel}>Location Info</Typography>}
                                    </Link>
                                </div>
                            )}
                        </>
                        : ''
                    }

                    {can(['view-sub-contractor', 'add-sub-contractor', 'edit-sub-contractor', 'delete-sub-contractor']) ?
                        <>
                            <div className={`${styles.menuItem} ${activeItem === '/sub-contractors' ? styles.active : ''}`} onClick={handleSubContractorClick}>
                                <PeopleAltOutlined className={styles.menuIcon}></PeopleAltOutlined>

                                <Typography className={styles.menuLabel}>
                                    Users
                                    {isSubContractorOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>

                            </div>
                            {isSubContractorOpen && (
                                <div className={styles.subMenu}>
                                    {can(['view-sub-contractor']) ?
                                        <div className={`${styles.menuItem} ${activeItem === '/sub-contractor-list' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/sub-contractor-list', event)}>
                                            <PeopleOutlined className={styles.menuIcon}></PeopleOutlined>
                                            {isOpen && <Typography className={styles.menuLabel}>User List</Typography>}
                                        </div>
                                        : ''
                                    }
                                    {can(['add-sub-contractor']) ?
                                        <div className={`${styles.menuItem} ${activeItem === '/add-sub-contractor' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/add-sub-contractor', event)}>
                                            <PersonAddAltOutlined className={styles.menuIcon}></PersonAddAltOutlined>
                                            {isOpen && <Typography className={styles.menuLabel}>Add User</Typography>}
                                        </div>
                                        : ''
                                    }
                                </div>
                            )}
                        </>
                        : ''
                    }
                    {can(['view-ratings']) ?
                        <div className={`${styles.menuItem} ${activeItem === '/my-ratings' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/my-ratings')}>
                            <StarBorderOutlined className={styles.menuIcon} />

                            <Typography className={styles.menuLabel}>
                                My Ratings
                            </Typography>

                        </div>
                        : ''
                    }
                    {can(['view-faq']) ?
                        <div className={`${styles.menuItem} ${activeItem === '/faqs' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/faqs')}>
                            <HelpCenterIcon className={styles.menuIcon} />

                            <Typography className={styles.menuLabel}>
                                FAQs
                            </Typography>

                        </div>
                        : ''
                    }
                    {!isSubContractor ?
                        <div className={`${styles.menuItem} ${activeItem === '/payment-history' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/payment-history')}>
                            <PaymentsOutlinedIcon className={styles.menuIcon} />

                            <Typography className={styles.menuLabel}>
                                Payment History
                            </Typography>

                        </div>
                        : ''
                    }
                </div>
            </Box>
        </>
    );
};

export default Sidebar;