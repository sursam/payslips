import axios from "axios";
import { StatusCodes } from "http-status-codes";
import { API_URL } from "../../config/config";
import { Endpoint, Headers, Params, Payload } from "../../@types/api/api.types";

const get = async (endpoint: Endpoint, headers: Headers, params: Params = {}) => {
	try {
		const response = await axios.get(`${API_URL}${endpoint}`, {
			headers,
			params
		});
		const { status } = response;
		if (status === StatusCodes.OK) {
			return response;
		}
	} catch (error) {
		console.log("error", error);
		throw error;
	}
};

const post = async (endpoint: Endpoint, payload: Payload, headers: Headers) => {
	try {
		const response = await axios.post(`${API_URL}${endpoint}`, payload, {
			headers
		});
		// console.log("response", response);
		const { status } = response;
		// console.log("status", status);
		if (status === StatusCodes.CREATED || status === StatusCodes.OK) {
			return response;
		}
	} catch (error) {
		console.log("error", error);
		throw error;
	}
};

const put = async (endpoint: Endpoint, payload: Payload, headers: Headers) => {
	try {
		const response = await axios.put(`${API_URL}${endpoint}`, payload, {
			headers
		});
		const { status } = response;
		if (status === StatusCodes.OK) {
			return response;
		}
	} catch (error) {
		console.log("error", error);
		throw error;
	}
};

const patch = async (endpoint: Endpoint, payload: Payload, headers: Headers) => {
	try {
		const response = await axios.patch(`${API_URL}${endpoint}`, payload, {
			headers
		});
		const { status } = response;
		if (status === StatusCodes.OK) {
			return response;
		}
	} catch (error) {
		console.log("error", error);
		throw error;
	}
};

const del = async (endpoint: Endpoint, headers: Headers) => {
	try {
		const response = await axios.delete(`${API_URL}${endpoint}`, {
			headers
		});
		const { status } = response;
		if (status === StatusCodes.OK) {
			return response;
		}
	} catch (error) {
		console.log("error", error);
		throw error;
	}
};

export const request = {
	fetch,
	get,
	post,
	put,
	patch,
	del
};
