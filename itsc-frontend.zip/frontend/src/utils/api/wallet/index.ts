import {
	walletDetails,
	walletRecharge,
	transactionUpdate,
	transactionDetails,
	paymentReceived,
	transactionList
} from "./wallet";

export const Wallet = {
	walletDetails,
	walletRecharge,
	transactionUpdate,
	transactionDetails,
	paymentReceived,
	transactionList
};
