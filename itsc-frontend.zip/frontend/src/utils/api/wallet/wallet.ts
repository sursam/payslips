import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { MESSAGE } from "../../../constants/api/message";
import { walletrecharge, transUpdate, transDetails, TransactionResponse } from "../../../types";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

const initialRoute = "transaction";

export const walletDetails = async () => {
	try {
		const endpoint = `${initialRoute}/wallet-details`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			console.log({ response });
			return response.data.result;
		} else {
			throw new Error(`Unable to fetch data: ${response?.statusText}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const transactionList = async (id: string) => {
	try {
		const endpoint = `${initialRoute}/transaction-list/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		} else {
			throw new Error(`Unable to fetch data: ${response?.statusText}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const walletRecharge = async (_payload: walletrecharge) => {
	try {
		const endpoint = `${initialRoute}/wallet-recharge`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const stripePayment = response.data.data.stripePayment;
			const paymentData = stripePayment.payment_data; // This can be simplified

			return { stripePayment, paymentData };
		} else {
			throw new Error(`Unable to fetch data: ${response?.statusText}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		} // Return null or handle the error as needed
	}
};

export const transactionUpdate = async (_payload: transUpdate) => {
	try {
		const endpoint = `${initialRoute}/transaction-update`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		} else {
			throw new Error(`Unable to fetch data: ${response?.statusText}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const transactionDetails = async (_payload: transDetails) => {
	try {
		const endpoint = `${initialRoute}/transaction-deatils-list`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		} else {
			throw new Error(`Unable to fetch data: ${response?.statusText}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const paymentReceived = async (_payload: {}, id: string) => {
	try {
		const endpoint = `${initialRoute}/verify-payment/${id}`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await put(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		} else {
			throw new Error(`Unexpected response status: ${response?.status}`);
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
