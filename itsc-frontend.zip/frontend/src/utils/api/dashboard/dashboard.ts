import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
// import { MESSAGE } from "../../../constants/api/message";

const { get } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getRaceResultList = async () => {
	try {
		const endpoint = "race-result/list";
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getUpcomingRace = async () => {
	try {
		const endpoint = "race/up-comming-race/upcomming";
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getTotalCount = async (id: string) => {
	try {
		const endpoint = `dashboard/member/total-counts/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getownerCount = async () => {
	try {
		const endpoint = `dashboard/details/group-owner`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getmemberCount = async (id: string) => {
	try {
		const endpoint = `dashboard/details/member/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			// alert(message);
		} else {
			throw error;
		}
	}
};
