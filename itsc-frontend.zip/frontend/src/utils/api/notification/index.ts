import { getNotifications, jobNotification } from "./notification";

export const notification = { getNotifications, jobNotification };
