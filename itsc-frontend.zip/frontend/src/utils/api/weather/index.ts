import { getForeCastUrl, forecastData } from "./weather";

export const weather = { getForeCastUrl, forecastData };
