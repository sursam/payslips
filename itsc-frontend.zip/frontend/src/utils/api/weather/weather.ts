import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { WEATHER_APP_URL } from "../../Constants";
import axios from "axios";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getForeCastUrl = async (latitude: number, longitude: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `${WEATHER_APP_URL}points/${latitude},${longitude}`;
		const response = await axios.get(endpoint);
		if (response) {
			if (response?.data?.properties?.forecast) {
				return response?.data?.properties?.forecast;
			}
		} else {
			return null;
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const forecastData = async (url: string) => {
	try {
		const response = await axios.get(url);
		if (response) {
			if (response?.data?.properties?.forecast) {
				return response?.data?.properties?.forecast;
			}
		} else {
			return null;
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
