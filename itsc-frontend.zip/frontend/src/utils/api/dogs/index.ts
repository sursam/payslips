import {
	addDog,
	getDogList,
	fetchDogList,
	updateDog,
	fetchDogById,
	changeDogStatus,
	deleteDog,
	addToCart,
	updateCartItem,
	fetchCartItems,
	deleteCartItem,
	purchaseDog,
	getMemberDogsList
} from "./dogList";

export const dogs = {
	addDog,
	getDogList,
	fetchDogList,
	updateDog,
	fetchDogById,
	changeDogStatus,
	deleteDog,
	addToCart,
	updateCartItem,
	fetchCartItems,
	deleteCartItem,
	purchaseDog,
	getMemberDogsList
};
