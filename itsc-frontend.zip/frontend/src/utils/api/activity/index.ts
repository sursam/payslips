import { getBanners, getMyReviews } from "./activity";

export const activity = { getBanners, getMyReviews };
