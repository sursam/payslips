import {
	getSubscriptionList,
	createAdminSubscription,
	editSubscription,
	updateSubscription,
	addupdate,
	editPlatform,
	getSettingsList,
	subscriptionPaymentReceived,
	createSubscription
} from "./subscription";

export const settings = {
	getSubscriptionList,
	createAdminSubscription,
	editSubscription,
	updateSubscription,
	addupdate,
	editPlatform,
	getSettingsList,
	subscriptionPaymentReceived,
	createSubscription
};
