import { auth } from "./auth";
import { settings } from "./settings";
import { Wallet } from "./wallet";
import { race } from "./race";
import { Announcement } from "./announcement";
import { dogs } from "./dogs";
import { reward } from "./rewards";
import { result } from "./results";
import { dashboard } from "./dashboard";
import { job } from "./job";
import { notification } from "./notification";
import { activity } from "./activity";
import { faqs } from "./faq";
import { stripe } from "./stripe";
import { getProfile, updateProfile, changePassword } from "./auth/profile";
import { weather } from "./weather";
import { payment } from "./payment";

export const api = {
	auth: {
		login: auth.login,
		logout: auth.logout,
		mobileLogin: auth.mobileLogin,
		loginVerification: auth.loginVerification,
		signupVerification: auth.signupVerification,
		checkEmailOrPhoneExists: auth.checkEmailOrPhoneExists,
		registerUser: auth.registerUser,
		addUser: auth.addUser,
		updateUser: auth.updateUser,
		deleteUser: auth.deleteUser,
		getUserDetails: auth.getUserDetails,
		updateUserPermissions: auth.updateUserPermissions,
		getSubContractorList: auth.getSubContractorList,
		addCompanyDetails: auth.addCompanyDetails,
		updateCompanyDetails: auth.updateCompanyDetails,
		updatePaymentTerms: auth.updatePaymentTerms,
		updatePaymentTermsByUser: auth.updatePaymentTermsByUser,
		fetchProfile: auth.fetchProfile,
		updateProfile: auth.updateProfile,
		changePassword: auth.changePassword,
		countries: auth.countries,
		statesByCountryCode: auth.statesByCountryCode,
		citiesByStateId: auth.citiesByStateId,
		forgotPassword: auth.forgotPassword,
		otpVerification: auth.otpVerification,
		resetPassword: auth.resetPassword,
		getSubContractorPermissions: auth.getSubContractorPermissions
	},
	job: {
		getActiveJobs: job.getActiveJobs,
		runningLiveLoads: job.runningLiveLoads,
		getMyJobs: job.getMyJobs,
		getMaterialTypeList: job.getMaterialTypeList,
		getLoadTypeList: job.getLoadTypeList,
		getEquipmentTypeList: job.getEquipmentTypeList,
		getTruckTypeList: job.getTruckTypeList,
		getMyPostedJobCounting: job.getMyPostedJobCounting,
		calculateLoad: job.calculateLoad,
		getJobDetails: job.getJobDetails,
		fetchJobDetails: job.fetchJobDetails,
		viewJobDetails: job.viewJobDetails,
		getJobLoads: job.getJobLoads,
		getNearestTruckers: job.getNearestTruckers,
		notifyTruckers: job.notifyTruckers,
		postJob: job.postJob,
		changeLoadPrice: job.changeLoadPrice,
		changeTruckType: job.changeTruckType,
		getRunningJobs: job.getRunningJobs,
		getRunningJobLoads: job.getRunningJobLoads,
		getRunningJobLoadDetails: job.getRunningJobLoadDetails,
		fetchTruckerCurrentLocation: job.fetchTruckerCurrentLocation,
		getDriverEndJobRequest: job.getDriverEndJobRequest,
		approveDriverEndJobRequest: job.approveDriverEndJobRequest,
		isReadyForJob: job.isReadyForJob,
		getPastJobCompanyDetails: job.getPastJobCompanyDetails,
		getExistingCompanies: job.getExistingCompanies,
		submitRating: job.submitRating,
		pendingJobActions: job.pendingJobActions,
		cancelJob: job.cancelJob,
		generateSetupIntent: job.generateSetupIntent,
		fetchCustomerPaymentMethods: job.fetchCustomerPaymentMethods,
		updatePaymentMethod: job.updatePaymentMethod,
		addDefaultPaymentMethod: job.addDefaultPaymentMethod,
		deletePaymentMethod: job.deletePaymentMethod
	},
	settings: {
		getSubscriptionList: settings.getSubscriptionList,
		createAdminSubscription: settings.createAdminSubscription,
		editSubscription: settings.editSubscription,
		updateSubscription: settings.updateSubscription,
		addupdate: settings.addupdate,
		editPlatform: settings.editPlatform,
		getSettingsList: settings.getSettingsList,
		subscriptionPaymentReceived: settings.subscriptionPaymentReceived,
		createSubscription: settings.createSubscription
	},
	Wallet: {
		walletDetails: Wallet.walletDetails,
		walletRecharge: Wallet.walletRecharge,
		transactionUpdate: Wallet.transactionUpdate,
		transactionDetails: Wallet.transactionDetails,
		paymentReceived: Wallet.paymentReceived,
		transactionList: Wallet.transactionList
	},
	race: {
		addRace: race.addRace,
		getRaceList: race.getRaceList,
		updateRace: race.updateRace,
		deleteRace: race.deleteRace,
		fetchRaceById: race.fetchRaceById
	},
	Announcement: {
		fetchAnnouncements: Announcement.fetchAnnouncements,
		addAnnouncement: Announcement.addAnnouncement,
		editAnnouncement: Announcement.editAnnouncement,
		deleteAnnouncement: Announcement.deleteAnnouncement,
		fetchNotifications: Announcement.fetchNotifications
	},
	dogs: {
		addDog: dogs.addDog,
		getDogList: dogs.getDogList,
		fetchDogList: dogs.fetchDogList,
		updateDog: dogs.updateDog,
		fetchDogById: dogs.fetchDogById,
		changeDogStatus: dogs.changeDogStatus,
		deleteDog: dogs.deleteDog,
		addToCart: dogs.addToCart,
		updateCartItem: dogs.updateCartItem,
		fetchCartItems: dogs.fetchCartItems,
		deleteCartItem: dogs.deleteCartItem,
		purchaseDog: dogs.purchaseDog,
		getMemberDogsList: dogs.getMemberDogsList
	},
	reward: {
		addReward: reward.addReward,
		getRewardList: reward.getRewardList,
		updateReward: reward.updateReward,
		deleteReward: reward.deleteReward,
		fetchRewardById: reward.fetchRewardById,
		getRaceWiseDogList: reward.getRaceWiseDogList
	},
	result: {
		addResult: result.addResult,
		getResultList: result.getResultList,
		updateResult: result.updateResult,
		deleteResult: result.deleteResult,
		fetchResultById: result.fetchResultById
	},
	dashboard: {
		getRaceResultList: dashboard.getRaceResultList,
		getUpcomingRace: dashboard.getUpcomingRace,
		getTotalCount: dashboard.getTotalCount,
		getownerCount: dashboard.getownerCount,
		getmemberCount: dashboard.getmemberCount
	},
	profile: {
		fetchProfile: getProfile,
		updateProfile: updateProfile,
		changePassword: changePassword
	},
	notifications: {
		fetchNotifications: notification.getNotifications,
		fetchJobNotification: notification.jobNotification
	},
	activity: {
		fetchActivity: activity.getBanners,
		fetchMyReviews: activity.getMyReviews
	},
	faq: {
		fetchFaq: faqs.getFaqs
	},
	stripe: {
		initStripe: stripe.initStripe,
		finalizePayment: stripe.finalizePayment
	},
	weather: {
		getForeCastUrl: weather.getForeCastUrl,
		getForeCast: weather.forecastData
	},
	payment: {
		paymentHistory: payment.paymentHistory,
		paidLoadDetails: payment.paidLoadDetails
	}
};
