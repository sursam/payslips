import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { auth } from "../auth";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const initStripe = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/initiate-payment`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};

		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		} else {
			const { status, message } = response.data;
			return { status, message };
		}
	} catch (error: any) {
		throw error;
	}
};

export const finalizePayment = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/payment-completion`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		} else {
			const { status, message } = response.data;
			return { status, message };
		}
	} catch (error: any) {
		throw error;
	}
};
