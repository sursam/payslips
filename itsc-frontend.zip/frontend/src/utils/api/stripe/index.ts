import { initStripe, finalizePayment } from "./stripe";

export const stripe = {
	initStripe,
	finalizePayment
};
