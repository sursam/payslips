import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const paymentHistory = async (page: number, startDate?: string, endDate?: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		let endpoint = `contractor/get-payment-history?page=${page}`;
		if (startDate) {
			endpoint += `&start_date=${encodeURIComponent(startDate)}`;
		}
		if (endDate) {
			endpoint += `&end_date=${encodeURIComponent(endDate)}`;
		}
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				return {
					data: response.data.data,
					pagination: response.data.pagination
				};
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error) {
		throw error;
	}
};

export const paidLoadDetails = async (paymentIntentId: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endPoint = `contractor/get-paid-load-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endPoint, { payment_intent_id: paymentIntentId }, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { data } = response;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error) {
		throw error;
	}
};
