import { paymentHistory, paidLoadDetails } from "./paymentHistory";
export const payment = { paymentHistory, paidLoadDetails };
