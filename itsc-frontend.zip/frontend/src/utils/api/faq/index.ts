import { getFaqs } from "./faq";

export const faqs = {
	getFaqs
};
