import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";

const { get } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getFaqs = async () => {
	try {
		const endpoint = `app-faqs`;
		const response = await get(endpoint, headers);
		if (response) {
			if (response.data.status) {
				console.log(response.data);
				const { status, message, data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
