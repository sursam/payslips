import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { toast } from "react-toastify";
const { post, get, put, del } = request;
const { Authorization, Bearer } = AUTHORIZATION;
export type RacePayload = {
    title: any;
    race_name: string;
    type: number;
    location: string;
    race_date: string;
    race_time: string;
    country: string;
    country_image?: string; // base64 encoded image string
    grade: string;
    dogs: Array<{
        rug_number: string;
        dog_object_id: string;
        box_number: string;
        rug_image?: string; // base64 encoded image string
    }>;
};

export const addRace = async (payload: RacePayload): Promise<{ message: string; result: any } | null> => {
    try {
        const endpoint = `race/add`;
        const authHeaders = {
            ...headers,
            [Authorization]: Bearer,
        };

        // Ensure correct POST structure
        const response = await post(endpoint, payload, authHeaders);

        if (response?.data?.message === MESSAGE.post.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};


// Function to fetch race list
export const getRaceList = async (): Promise<{ message: string; result: any } | null> => {
    try {
        const endpoint = `race/list`;
        const authHeaders = {
            ...headers,
            [Authorization]: Bearer,
        };

        const response = await get(endpoint, authHeaders);
        console.log("API Response:", response);

        if (response?.data?.message === MESSAGE.get.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};

// **Update Race**
export const updateRace = async (id: string, payload: RacePayload): Promise<{ message: string; result: any } | null> => {
    try {
        const endpoint = `race/update/${id}`;
        const authHeaders = {
            ...headers,
            [Authorization]: Bearer,
        };

        const response = await put(endpoint, payload, authHeaders);
        console.log("API Response:", response);

        if (response?.data?.message === MESSAGE.put.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};

// **Delete Race**
export const deleteRace = async (id: string): Promise<{ message: string; result: any } | null> => {
    try {
        const endpoint = `/race/delete/${id}`;
        const authHeaders = {
            ...headers,
            [Authorization]: Bearer,
        };

        const response = await del(endpoint, authHeaders);
        console.log("API Response:", response);

        if (response?.data?.message === MESSAGE.delete.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};

// **Fetch Race by ID**
export const fetchRaceById = async (id: string): Promise<{ message: string; result: any } | null> => {
    try {
        const endpoint = `race/edit/${id}`;
        const authHeaders = {
            ...headers,
            [Authorization]: Bearer,
        };

        const response = await get(endpoint, authHeaders);
        console.log("API Response:", response);

        if (response?.data?.message === MESSAGE.get.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};