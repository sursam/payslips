import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { auth } from "../auth";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getMyPostedJobCounting = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/count-my-total-jobs`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};

export const getActiveJobs = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}

	try {
		const endpoint = `my-active-job-cordinates`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const runningLiveLoads = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/get-running-job-loads`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getMyJobs = async (status: number, currentDateTime: string, page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/manage-job?status=${status}&currentDateTime=${currentDateTime}&page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data, pagination } = response.data;
				return { data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getMaterialTypeList = async () => {
	try {
		const endpoint = `materials`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getLoadTypeList = async () => {
	try {
		const endpoint = `load-types`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getEquipmentTypeList = async () => {
	try {
		const endpoint = `equipments`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getTruckTypeList = async () => {
	try {
		const endpoint = `truck-types`;
		const response = await get(endpoint, headers);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const isReadyForJob = async () => {
	const token = localStorage.getItem("@jwt");

	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `is-ready-for-job`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status) {
			if (response.data.status) {
				const { status, message, data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const postJob = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/post-job-v1`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const calculateLoad = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/calculate-load`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getJobDetails = async (id: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/job-details/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data } = response.data;
				return { status, message, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const fetchJobDetails = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/fetch-job-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data } = response.data;
				return { status, message, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const viewJobDetails = async (id: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/job-details/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getJobLoads = async (id: any, page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/get-Job-loads-contractor?job_id=${id}&page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, pagination } = response.data;
				return { data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getNearestTruckers = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/get-nearest-truckers`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const notifyTruckers = async (jobId: string, userId: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			job_id: jobId,
			user_id: userId
		};
		const endpoint = `contractor/notified-nearest-truckers`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const changeLoadPrice = async (jobId: string, loadId: string, price: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			job_id: jobId,
			load_id: loadId,
			amount: price
		};
		const endpoint = `contractor/update-load-amount`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const changeTruckType = async (jobId: string, truckTypeIds: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			job_id: jobId,
			truck_type_ids: truckTypeIds
		};
		const endpoint = `contractor/change-truck-types`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getDriverEndJobRequest = async (jobId: string, loadId: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/show-load-completion-request`;
		const payload = {
			job_id: jobId,
			load_id: loadId
		};
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				console.log("getDriverEndJobRequest response", response.data);

				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
// export const approveDriverEndJobRequest = async (payload: any) => {
// 	const token = localStorage.getItem("@jwt");
// 	if (!token) {
// 		throw new Error("No token found");
// 	}
// 	try {
// 		const endpoint = `contractor/accept-reject-load-confirmation`;
// 		const authHeaders = {
// 			...headers,
// 			[Authorization]: `Bearer ${token}`,
// 			"Content-Type": "multipart/form-data"
// 		};
// 		const response = await post(endpoint, payload, authHeaders);
// 		if (response) {
// 			if (response?.data?.status) {
// 				// check does his payment needed or not
// 				const shouldUserHaveToPay = await isReadyForJob();
// 				if (shouldUserHaveToPay) {
// 					const localStorageKey = "doesPaymentNeeded";
// 					if (localStorage.getItem(localStorageKey) != null) {
// 						localStorage.setItem(localStorageKey, JSON.stringify(shouldUserHaveToPay.is_payment_needed));
// 					} else {
// 						localStorage.setItem(localStorageKey, JSON.stringify(shouldUserHaveToPay.is_payment_needed));
// 					}
// 				}
// 				const { status, message } = response.data;
// 				return { status, message };
// 			} else {
// 				const { status, message } = response.data;
// 				return { status, message };
// 			}
// 		}
// 	} catch (error: any) {
// 		console.log("Error", error);
// 		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
// 			const { message } = error.response.data;
// 			return { message };
// 			// alert(message);
// 		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
// 			const { message } = error.response.data;
// 			return { message };
// 			// alert(message);
// 		} else {
// 			throw error;
// 		}
// 	}
// };

export const approveDriverEndJobRequest = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) throw new Error("No token found");

	try {
		const endpoint = `contractor/accept-reject-load-confirmation`;
		const authHeaders = {
			...headers,
			Authorization: `Bearer ${token}`,
			"Content-Type": "multipart/form-data"
		};

		const response = await post(endpoint, payload, authHeaders);
		const { data } = response || {};

		if (!data) throw new Error("Invalid response from server");

		const { status, message } = data;

		if (status) {
			// Check if user needs to pay
			const shouldUserHaveToPay = await isReadyForJob();

			if (shouldUserHaveToPay) {
				localStorage.setItem("doesPaymentNeeded", JSON.stringify(shouldUserHaveToPay.is_payment_needed));
			}
		}

		return { status, message };
	} catch (error: any) {
		console.error("Error:", error);

		const statusCode = error?.response?.status;
		const message = error?.response?.data?.message || "Something went wrong.";

		switch (statusCode) {
			case StatusCodes.BAD_REQUEST:
			case StatusCodes.UNAUTHORIZED:
				return { message };
			default:
				throw error;
		}
	}
};

export const getRunningJobs = async (page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/running-jobs?page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data, pagination } = response.data;
				return { data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getRunningJobLoads = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/running-job-loads`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getRunningJobLoadDetails = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/running-job-loads-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const fetchTruckerCurrentLocation = async (payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/update-my-current-location`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getPastJobCompanyDetails = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/get-past-job-company-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getExistingCompanies = async () => {
	try {
		const endpoint = `contractor/get-existing-companies`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const submitRating = async (payload: object) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/add-feedback`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status) {
				console.log("submitRating response", response.data);

				const { status, message } = response.data;
				return { status, message };
			} else {
				console.log("submitRating response error", response.data);

				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const pendingJobActions = async (page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/pending-verification-or-cancellation-jobs?page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				const { data, pagination } = response.data;
				return { data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const cancelJob = async (jobId: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			job_id: jobId
		};
		const endpoint = `contractor/cancel-job`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};

export const generateSetupIntent = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
		};
		const endpoint = `contractor/generate-setup-intent`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message } = response.data;
				const { clientSecret } = response.data.data;
				return { status, message, clientSecret };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const fetchCustomerPaymentMethods = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}

	try {
		const endpoint = `contractor/fetch-customer-payment-methods`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status) {
				// console.log(response.data.data);
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const deletePaymentMethod = async (methodId: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			payment_method_id: methodId
		};
		const endpoint = `contractor/delete-payment-method`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const updatePaymentMethod = async (methodId: string, customerId: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			payment_method_id: methodId,
			customer_id: customerId,
		};
		const endpoint = `contractor/update-payment-method`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const addDefaultPaymentMethod = async (methodId: string, customerId: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			payment_method_id: methodId,
			customer_id: customerId,
		};
		const endpoint = `contractor/add-default-payment-method`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message, data } = response.data;
				return { status, message, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};