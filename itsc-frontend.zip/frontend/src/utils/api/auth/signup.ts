/* eslint-disable arrow-parens */
import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
// import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { VerificationPayload } from "../../../types";
import { toast } from "react-toastify";
const { post, get } = request;
const { Authorization, Bearer } = AUTHORIZATION;

const initialRoute = "auth";
interface ChangePassword {
	email: string;
	oldPassword: string;
	newPassword: string;
	confirmPassword: string;
}
export const signupVerification = async (_payload: VerificationPayload) => {
	try {
		const endpoint = `${initialRoute}/email-verification-with-password-change`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const checkEmailOrPhoneExists = async (_payload: any) => {
	try {
		const endpoint = `email-or-phone-exist`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers
		};
		const response = await post(endpoint, payload, authHeaders);
		console.log("response", response);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const registerUser = async (_payload: any) => {
	console.log("payload", _payload);

	try {
		// const payload = JSON.stringify(_payload);
		const endpoint = `registration`;
		const authHeaders = {
			...headers,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { token, user, isSubContractor } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role,
					userRoleSlug: user.user_role_slug,
					permissions: user.permissions,
					stripePaymentMethod: user.stripe_payment_method,
					stripeCustomerId: user.stripe_customer_id
				};
				localStorage.setItem("isSubContractor", JSON.stringify(isSubContractor));
				localStorage.setItem("@jwt", token);
				localStorage.setItem("userDetails", JSON.stringify(userDetails));
				localStorage.setItem("completedSteps", user.completed_steps);
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const addUser = async (_payload: any) => {
	console.log("payload", _payload);

	try {
		const endpoint = `registration`;
		const authHeaders = {
			...headers,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { user } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role
				};
				return { status, message, userDetails };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const updateUser = async (_payload: any) => {
	console.log("payload", _payload);

	try {
		// const payload = JSON.stringify(_payload);
		const endpoint = `update-user`;
		const authHeaders = {
			...headers,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { user } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role
				};
				return { status, message, userDetails };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const deleteUser = async (userUuid: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const payload = {
			uuid: userUuid
		};
		const endpoint = `delete-user`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response?.data?.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getUserDetails = async (uuid: string) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		// 	setUser(null); // Clear user state if no token
		throw new Error("No token found");
	}
	try {
		const endpoint = `get-user-details/${uuid}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { status, message, data } = response.data;
			// console.log("User Details:", data);
			return { status, message, data };
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const updateUserPermissions = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		// 	setUser(null); // Clear user state if no token
		throw new Error("No token found");
	}
	try {
		// const payload = JSON.stringify(_payload);
		const endpoint = `update-user-permissions`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getSubContractorList = async (page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `get-subcontractor-list?page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message, data, pagination } = response.data;
				return { status, message, data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const addCompanyDetails = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `add-professional-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response && response.data.status === true) {
			console.log(response);

			// Call updatePaymentTerms after successful company details addition
			try {
				const paymentPayload = {
					pay_in: 1
				};
				const paymentTermsResponse = await updatePaymentTerms(paymentPayload);
				console.log(paymentTermsResponse);

				if (paymentTermsResponse?.status === true) {
					// Set completedSteps from payment terms response
					if (paymentTermsResponse.data?.completed_steps) {
						localStorage.setItem("completedSteps", paymentTermsResponse.data.completed_steps);
					}
					// setup payment method
					const paymentMethodPayload = {
						payment_method: 2
					};
					const shouldPaymentNeeded = await isReadyForJob();
					if (shouldPaymentNeeded) {
						localStorage.setItem(
							"doesPaymentNeeded",
							JSON.stringify(shouldPaymentNeeded.is_payment_needed)
						);
					}
					const paymentMethodResponse = await setupPaymentMethod(paymentMethodPayload);
					if (paymentMethodResponse?.status) {
						const userProfileDetails = await getProfileDetails();
						const userDetails = {
							id: userProfileDetails?.id,
							firstName: userProfileDetails?.fname,
							lastName: userProfileDetails?.lname,
							email: userProfileDetails?.email,
							mobile: userProfileDetails?.mobile,
							userRole: userProfileDetails?.user_role,
							userRoleSlug: userProfileDetails?.user_role_slug,
							permissions: userProfileDetails?.permissions,
							stripePaymentMethod: userProfileDetails?.stripe_payment_method,
							stripeCustomerId: userProfileDetails?.stripe_customer_id
						};
						localStorage.setItem("userDetails", JSON.stringify(userDetails));
						toast.success("Registration Successfully Completed");
					} else {
						toast.error(paymentMethodResponse?.message);
					}
				} else {
					// Fallback to company details completedSteps if payment terms fails
					localStorage.setItem("completedSteps", response.data.data.completed_steps);
					toast.warning("Company details saved, but payment terms update failed");
				}
			} catch (paymentError) {
				console.error("Payment terms update failed:", paymentError);
				// Fallback to company details completedSteps
				localStorage.setItem("completedSteps", response.data.data.completed_steps);
				toast.warning("Company details saved, but payment terms update failed");
			}

			const { status, message } = response.data;
			return { status, message };
		} else {
			const { status, message } = response.data;
			return { status, message };
		}
	} catch (error: any) {
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
		} else {
			toast.error("An unexpected error occurred");
			throw error;
		}
	}
};
export const updateCompanyDetails = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `update-company-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const updatePaymentTerms = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `update-payment-terms`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { data, status, message } = response.data;
				return { data, status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const updatePaymentTermsByUser = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `update-payment-terms-by-user`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const setupPaymentMethod = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const endpoint = `update-payment-payout-method`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status) {
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const fetchProfile = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		// 	setUser(null); // Clear user state if no token
		throw new Error("No token found");
	}
	try {
		const endpoint = `${initialRoute}/get-profile`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { userDetails } = response?.data?.result;
			return {
				first_name: userDetails.first_name || "",
				middle_name: userDetails.middle_name || "",
				last_name: userDetails.last_name || "",
				phone_number: userDetails.phone_number || "",
				email: userDetails.email || "",
				date_of_birth: userDetails.date_of_birth || null,
				user_name: userDetails.user_name || "",
				gender: userDetails.gender || "",
				address_line_1: userDetails.address_line_1 || "",
				address_line_2: userDetails.address_line_2 || "",
				city: userDetails.city || "",
				state: userDetails.state || "",
				country: userDetails.country || "",
				ZIP: userDetails.ZIP || "",
				contact_label: userDetails.contact_label || "",
				phone_extension: userDetails.phone_extension || "",
				profilePicture: null, // Handle profile picture separately if needed
				role: userDetails.role || ""
			};
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const updateProfile = async (_payload: FormData) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `${initialRoute}/update-profile`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const changePassword = async (_payload: ChangePassword) => {
	const token = localStorage.getItem("@jwt"); // Retrieve the token from local storage
	if (!token) {
		throw new Error("No token found"); // Handle case where token is not available
	}

	try {
		const endpoint = `${initialRoute}/password-change`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const fetchDogs = async () => {
	try {
		const endpoint = `member/dog/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const logout = async () => {
	try {
		const endpoint = `logout`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		console.log(authHeaders);
		const response = await get(endpoint, authHeaders);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getSubContractorPermissions = async (_payload: FormData) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = "fetch-permissions";
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				const { status, message, data } = response.data;
				return { status, message, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
		} else {
			throw error;
		}
	}
};

export const isReadyForJob = async () => {
	const token = localStorage.getItem("@jwt");

	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `is-ready-for-job`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status) {
			if (response.data.status) {
				const { status, message, data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const getProfileDetails = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}

	try {
		const endpoint = `my-profile`;
		const authHeaders = {
			...headers,
			Authorization: `Bearer ${token}`
		};

		const response = await get(endpoint, authHeaders);

		if (response?.data?.status && response.data?.data?.user) {
			return response.data.data.user;
		}

		// Handle known error responses
		const { status, message } = response.data || {};
		return { status, message };
	} catch (error: any) {
		console.log("Error", error);

		if (
			error?.response?.status === StatusCodes.BAD_REQUEST ||
			error?.response?.status === StatusCodes.UNAUTHORIZED
		) {
			const { message } = error.response.data;
			return { message };
		}

		throw error;
	}
};
