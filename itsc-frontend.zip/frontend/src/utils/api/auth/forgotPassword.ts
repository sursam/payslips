/* eslint-disable arrow-parens */
import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
const { post } = request;

export type ForgotPasswordTypes = {
	email: string;
};
export type OtpVerificationTypes = {
	email: string;
	otp: number;
};
export type ResetPasswordTypes = {
	email: string;
	password: string;
};
export const forgotPassword = async (_payload: ForgotPasswordTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `forget-password-token`;
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { email, otp } = response.data.data;
				return { status, message, email, otp };
			}else{
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log('Error', error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const otpVerification = async (_payload: OtpVerificationTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `verify-token`;
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			}else{
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log('Error', error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const resetPassword = async (_payload: ResetPasswordTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `change-password`;
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			}else{
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log('Error', error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
