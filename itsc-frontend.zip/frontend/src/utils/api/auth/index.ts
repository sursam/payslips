import { login, mobileLogin, loginVerification, countries, statesByCountryCode, citiesByStateId } from "./login";
import { getProfile } from "./profile";
import { forgotPassword, otpVerification, resetPassword } from "./forgotPassword";
import {
	signupVerification,
	checkEmailOrPhoneExists,
	registerUser,
	addUser,
	updateUser,
	deleteUser,
	getUserDetails,
	updateUserPermissions,
	getSubContractorList,
	addCompanyDetails,
	updateCompanyDetails,
	updatePaymentTerms,
	updatePaymentTermsByUser,
	fetchProfile,
	updateProfile,
	changePassword,
	getSubContractorPermissions,
	logout
} from "./signup";

export const auth = {
	login,
	logout,
	mobileLogin,
	loginVerification,
	signupVerification,
	checkEmailOrPhoneExists,
	registerUser,
	addUser,
	updateUser,
	deleteUser,
	getUserDetails,
	updateUserPermissions,
	getSubContractorList,
	addCompanyDetails,
	updateCompanyDetails,
	updatePaymentTerms,
	updatePaymentTermsByUser,
	fetchProfile,
	updateProfile,
	changePassword,
	countries,
	statesByCountryCode,
	citiesByStateId,
	forgotPassword,
	otpVerification,
	resetPassword,
	getProfile,
	getSubContractorPermissions
};
