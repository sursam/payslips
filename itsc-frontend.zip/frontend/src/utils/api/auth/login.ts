/* eslint-disable arrow-parens */
import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
const { get, post } = request;
const { Authorization, Bearer } = AUTHORIZATION;

// const initialRoute = "auth";

export type LoginTypes = {
	email: string;
	password: string;
	device_type: number;
	device_token: string;
	fcm_token: string;
};
export type MobileLoginTypes = {
	country_code: number;
	mobile: string;
	device_type: number;
	device_token: string;
};
export type LoginVerificationTypes = {
	mobile: string;
	otp: number;
};
export type StateTypes = {
	country_code: string;
};
export type CityTypes = {
	state_id: number;
};

export const login = async (_payload: LoginTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `email-login`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status == true) {
				// console.log(response);
				const { status, message } = response.data;
				const { token, user, isSubContractor } = response.data.data;
				if (user && (user.user_role_slug == "contractor" || user.user_role_slug == "sub-contractor")) {
					const userDetails = {
						id: user.id,
						firstName: user.fname,
						lastName: user.lname,
						email: user.email,
						mobile: user.mobile,
						userRole: user.user_role,
						userRoleSlug: user.user_role_slug,
						completedSteps: user.completed_steps,
						profileImage: user.profile_image,
						permissions: user.permissions,
						stripePaymentMethod: user.stripe_payment_method,
						stripeCustomerId: user.stripe_customer_id
					};
					localStorage.setItem("isSubContractor", JSON.stringify(isSubContractor));
					localStorage.setItem("@jwt", token);
					localStorage.setItem("completedSteps", user.completed_steps);
					localStorage.setItem("userDetails", JSON.stringify(userDetails));
					// call the api is his payment needed or not
					const shouldUserHaveToPay = await isReadyForJob();
					if (shouldUserHaveToPay) {
						localStorage.setItem(
							"doesPaymentNeeded",
							JSON.stringify(shouldUserHaveToPay.is_payment_needed)
						);
					}
					return { status, message, user };
				} else {
					let status = false;
					let message = "Sorry! You are not a contractor";
					return { status, message };
				}
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const mobileLogin = async (_payload: MobileLoginTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `login-with-phone`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status === true) {
				// console.log(response.data);
				if (
					response.data.data.user_role_slug == "contractor" ||
					response.data.data.user_role_slug == "sub-contractor"
				) {
					const { status, message } = response.data;
					const { verification_code } = response.data.data;
					return { status, message, verification_code };
				} else {
					let status = false;
					let message = "Sorry! You are not a contractor";
					return { status, message };
				}
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const countries = async () => {
	try {
		const endpoint = `countries`;
		const response = await get(endpoint, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const statesByCountryCode = async (_payload: StateTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `states-by-country`;
		// console.log(endpoint);
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const citiesByStateId = async (_payload: CityTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `cities-by-state`;
		// console.log(endpoint);
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const loginVerification = async (_payload: LoginVerificationTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `verify-otp`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status === true) {
				console.log(response);
				const { status } = response.data;
				const { token, user, isSubContractor, message } = response.data.data;

				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role,
					userRoleSlug: user.user_role_slug,
					completedSteps: user.completed_steps,
					profileImage: user.profile_image,
					permissions: user.permissions,
					stripePaymentMethod: user.stripe_payment_method,
					stripeCustomerId: user.stripe_customer_id
				};
				localStorage.setItem("isSubContractor", JSON.stringify(isSubContractor));
				localStorage.setItem("@jwt", token);
				localStorage.setItem("completedSteps", user.completed_steps);
				localStorage.setItem("userDetails", JSON.stringify(userDetails));
				// call the api is his payment needed or not
				const shouldUserHaveToPay = await isReadyForJob();
				if (shouldUserHaveToPay) {
					localStorage.setItem("doesPaymentNeeded", JSON.stringify(shouldUserHaveToPay.is_payment_needed));
				}
				return { status, message, user };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const isReadyForJob = async () => {
	const token = localStorage.getItem("@jwt");

	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `is-ready-for-job`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status) {
			if (response.data.status) {
				const { status, message, data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
