import { addResult, deleteResult, fetchResultById, getResultList, updateResult } from "./resultList";

export const result = {
	addResult,
	getResultList,
	updateResult,
	deleteResult,
	fetchResultById
};
