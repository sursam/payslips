import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { toast } from "react-toastify";
const { post, get, put, del } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export type ResultPayload = {
    race_object_id: string;
    race_round_no: string;
    race_date: string;
    grade: string;
    round: Array<{
        time: string;
        winners: Array<{
            position: string;
            dog_object_id: string;
            box_number: string;
            race_completion_time: string;
            mgn: string;
            split: string;
            in_run: string;
            weight: string;
            dog_price: string;
        }>;
    }>;
};


export const addResult = async (payload: ResultPayload): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/add`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		// Ensure correct POST structure
		const response = await post(endpoint, payload, authHeaders);

		if (response?.data?.message === MESSAGE.post.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};


// Function to fetch race list
export const getResultList = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Update Race**
export const updateResult = async (id: string, payload: ResultPayload): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/update/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await put(endpoint, payload, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.put.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Delete Race**
export const deleteResult = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `/race/delete/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await del(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.delete.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Fetch Race by ID**
export const fetchResultById = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race-result/edit/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};