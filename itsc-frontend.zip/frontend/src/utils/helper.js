export const can = (accessPermissions) => {
    const userDetails = (typeof localStorage !== 'undefined') ? JSON.parse(localStorage.getItem('userDetails')) : null;
    const permissions = userDetails ? userDetails.permissions : [];
    // console.log('userDetails ->', userDetails)

    return (userDetails?.userRoleSlug == "super-admin" || userDetails?.userRoleSlug == "contractor" || (permissions.length && permissions.filter(x => accessPermissions.includes(x)).length));
}