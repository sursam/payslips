import React, { ReactNode } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PublicRoute: React.FC = () => {
    const { user } = useAuth();
    const token = localStorage.getItem('@jwt'); // Check for token in local storage
    const completedSteps: any = (typeof localStorage !== 'undefined') ? localStorage.getItem('completedSteps') : null;
    // console.log(!completedSteps ? true : false);
    // console.log('completedSteps ---', completedSteps);

    return (!user && !completedSteps && !token || (token && completedSteps && completedSteps < 4)) ? <Outlet /> : <Navigate to="/dashboard" />;
};

export default PublicRoute;