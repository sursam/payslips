// import React from 'react';
// import { Outlet, Navigate } from 'react-router-dom';
// import { useAuth } from '../context/AuthContext';

// const PrivateRoute: React.FC = () => {
//     const { user } = useAuth();
//     const token = localStorage.getItem('@jwt'); // Check for token in local storage
//     const completedSteps: any = localStorage.getItem('completedSteps') || null;
//     console.log('private completedSteps ---', completedSteps);

//     return user || token && (!completedSteps || (completedSteps && completedSteps == 4)) ? <Outlet /> : ((completedSteps == 1 || completedSteps == 2) ? <Navigate to="/sign-up" replace /> : <Navigate to="/" replace />);
// };

// export default PrivateRoute;
import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PrivateRoute: React.FC = () => {
    const { user, isLoading, isAuthenticated } = useAuth();

    // Function to get valid token
    const getValidToken = () => {
        const token = localStorage.getItem('@jwt') || localStorage.getItem('token');
        return token && token !== 'null' && token !== 'undefined' ? token : null;
    };

    // Function to get completed steps
    const getCompletedSteps = () => {
        const steps = localStorage.getItem('completedSteps');
        return steps && steps !== 'null' && steps !== 'undefined' ? parseInt(steps) : null;
    };

    // Show loading spinner while authentication is being checked
    if (isLoading) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                fontSize: '18px'
            }}>
                Loading...
            </div>
        );
    }

    const token = getValidToken();
    const completedSteps = getCompletedSteps();

    console.log('PrivateRoute Check:', {
        hasUser: !!user,
        hasToken: !!token,
        isAuthenticated,
        completedSteps
    });

    // Check if user is authenticated (either through context or valid token)
    const userIsAuthenticated = isAuthenticated || (user && token);

    if (!userIsAuthenticated) {
        console.log('User not authenticated - redirecting to login');
        return <Navigate to="/" replace />;
    }

    // Handle incomplete registration steps
    if (completedSteps !== null && completedSteps !== 4) {
        if (completedSteps === 1 || completedSteps === 2) {
            console.log('Incomplete registration steps - redirecting to sign-up');
            return <Navigate to="/sign-up" replace />;
        } else if (completedSteps === 3) {
            // You might want to redirect to a specific step completion page
            console.log('Registration step 3 - might need specific handling');
            return <Navigate to="/sign-up" replace />;
        } else {
            console.log('Invalid completion step - redirecting to login');
            return <Navigate to="/" replace />;
        }
    }

    // All checks passed, render protected content
    return <Outlet />;
};

export default PrivateRoute;