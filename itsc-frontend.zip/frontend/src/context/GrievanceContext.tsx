import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';

interface Reply {
    _id: string;
    message: string;
    repliedBy: {
        role: string;
        replyTime: string;
    };
}

interface Grievance {
    _id?: string;
    description: string;
    createdAt?: string;
    reply?: Reply[]; // Change from `string[]` to `Reply[]`
}


interface GrievanceContextType {
    grievances: Grievance[];
    fetchGrievances: () => Promise<void>;
    addGrievance: (grievance: Grievance) => Promise<void>;
    replyToGrievance: (id: string, reply: { message: string }) => Promise<void>;
    deleteGrievance: (id: string) => Promise<void>;
}

const GrievanceContext = createContext<GrievanceContextType | undefined>(undefined);

export const GrievanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [grievances, setGrievances] = useState<Grievance[]>([]);

    const fetchGrievances = useCallback(async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}grievence/list`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch grievance list');
            }

            const data = await response.json();
            setGrievances(data.result);
        } catch (error) {
            console.error('Error fetching grievances:', error);
        }
    }, []);

    const addGrievance = useCallback(async (grievance: Grievance): Promise<void> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}grievence/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify(grievance),
            });

            if (!response.ok) {
                throw new Error('Failed to add grievance');
            }
            // Fetch grievances again after adding
            await fetchGrievances();
            // const newGrievance = await response.json();
            // setGrievances((prevGrievances) => [...prevGrievances, newGrievance]);
        } catch (error) {
            console.error('Error adding grievance:', error);
        }
    }, []);

    const replyToGrievance = useCallback(async (id: string, reply: { message: string }): Promise<void> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}grievence/reply/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify(reply),
            });

            if (!response.ok) {
                throw new Error('Failed to reply to grievance');
            }
            // Fetch grievances again after adding
            await fetchGrievances();
            // const updatedGrievance = await response.json();
            // setGrievances((prevGrievances) =>
            //     prevGrievances.map(grievance =>
            //         grievance._id === updatedGrievance._id ? updatedGrievance : grievance
            //     )
            // );
        } catch (error) {
            console.error('Error replying to grievance:', error);
        }
    }, []);

    const deleteGrievance = useCallback(async (id: string): Promise<void> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}grievence/delete/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to delete grievance');
            }

            setGrievances((prevGrievances) => prevGrievances.filter(grievance => grievance._id !== id));
        } catch (error) {
            console.error('Error deleting grievance:', error);
        }
    }, []);

    return (
        <GrievanceContext.Provider value={{ grievances, fetchGrievances, addGrievance, deleteGrievance, replyToGrievance }}>
            {children}
        </GrievanceContext.Provider>
    );
};

export const useGrievance = (): GrievanceContextType => {
    const context = React.useContext(GrievanceContext);
    if (context === undefined) {
        throw new Error('useGrievance must be used within a GrievanceProvider');
    }
    return context;
};