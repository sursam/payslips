import React, { createContext, useState, useCallback, ReactNode } from 'react';

// Define the types for the API response
interface Race {
	_id: string;
	title: string;
	location: string;
	raceDate: string;
	grade: string;
	round: any[]; // You can define a more specific type if needed
}

interface RaceResponse {
	message: string;
	result: Race[];
}
interface Reward {
	_id?: string;
	subject: string;
	description: string;
	link?: string;
	imageUrl?: string; // URL for the uploaded image if provided by API
	createdAt?: string;
}

interface RewardCreatePayload {
	rewardType: string; // "GIFTS" or "POINTS"
	description: string;
	points?: number;
}

interface RewardUpdatePayload {
	subject: string;
	description: string;
	link?: string;
}

interface RewardContextType {
	Rewards: Reward[];
	fetchRewards: () => Promise<void>;
	addReward: (payload: RewardCreatePayload & { dogId: string }) => Promise<Reward | null>;
	editReward: (id: string, payload: RewardUpdatePayload) => Promise<void>;
	deleteReward: (id: string) => Promise<void>;
	fetchDogMembers: (dogId: string) => Promise<{ name: string; shareUnit: number }[]>;
	fetchRaces: () => Promise<Race[]>; // Add fetchRaces to context
}

const RewardContext = createContext<RewardContextType | undefined>(undefined);

export const RewardProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
	const [Rewards, setRewards] = useState<Reward[]>([]);
	const [dogMembers, setDogMembers] = useState<{ name: string; shareUnit: number }[]>([]);
	const [races, setRaces] = useState<Race[]>([]); // State for races

	const fetchRewards = useCallback(async () => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}Reward_v2/list`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) throw new Error('Failed to fetch Reward list');

			const data = await response.json();
			setRewards(data.result);
		} catch (error) {
			console.error('Error fetching Rewards:', error);
		}
	}, []);

	const fetchRaces = useCallback(async (): Promise<Race[]> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}race/list`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) throw new Error('Failed to fetch races');

			const data: RaceResponse = await response.json(); // Type the response
			setRaces(data.result); // Set the races state
			return data.result; // Return the races
		} catch (error) {
			console.error('Error fetching races:', error);
			return []; // Return an empty array on error
		}
	}, []);

	const addReward = async (payload: RewardCreatePayload & { dogId: string }): Promise<Reward | null> => {
		try {
			// Convert the payload into FormData
			const formData = new FormData();
			formData.append('rewardType', payload.rewardType);
			formData.append('description', payload.description);
			if (payload.points) {
				formData.append('points', payload.points.toString());
			}
			// formData.append('dogId', payload.dogId);

			const response = await fetch(`${process.env.REACT_APP_API_URL}win-price/distribution-rewards`, {
				method: 'POST',
				body: formData,
				headers: {
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
					'Accept': 'application/json',
				},
			});

			if (!response.ok) {
				throw new Error('Failed to add reward');
			}

			await fetchRewards(); // Refresh the reward list after adding a new reward  

			return await response.json(); // Return the newly created reward
		} catch (error) {
			console.error('Error adding reward:', error);
			return null;
		}
	};


	const editReward = useCallback(async (id: string, payload: RewardUpdatePayload): Promise<void> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}Reward_v2/update/${id}`, {
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
				body: JSON.stringify(payload),
			});

			if (!response.ok) {
				const errorData = await response.json();
				throw new Error(`Failed to edit reward: ${errorData.message || response.statusText}`);
			}

			await fetchRewards();
		} catch (error) {
			console.error('Error updating Reward:', error);
			throw error;
		}
	}, [fetchRewards]);

	const deleteReward = useCallback(async (id: string): Promise<void> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}Reward_v2/delete/${id}`, {
				method: 'DELETE',
				headers: {
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) throw new Error('Failed to delete Reward');

			setRewards((prevRewards) => prevRewards.filter((Reward) => Reward._id !== id));
		} catch (error) {
			console.error('Error deleting Reward:', error);
		}
	}, []);

	const fetchDogMembers = useCallback(async (dogId: string): Promise<{ name: string; shareUnit: number }[]> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}purches/get-dog-id-wise-member-list/${dogId}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) throw new Error('Failed to fetch dog members');

			const data = await response.json();
			setDogMembers(data.result);
			return data.result;
		} catch (error) {
			console.error('Error fetching dog members:', error);
			setDogMembers([]);
			return [];
		}
	}, []);

	return (
		<RewardContext.Provider value={{ Rewards, fetchRewards, addReward, editReward, deleteReward, fetchDogMembers, fetchRaces }}>
			{children}
		</RewardContext.Provider>
	);
};

export const useReward = (): RewardContextType => {
	const context = React.useContext(RewardContext);
	if (context === undefined) throw new Error('useReward must be used within a RewardProvider');
	return context;
};
