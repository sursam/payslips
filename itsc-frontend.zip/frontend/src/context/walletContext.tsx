import ApiConnection from '../ApiConnection';
import { walletrecharge, transUpdate, transDetails, TransactionResponse } from '../types';
import { AxiosResponse } from 'axios';


export const walletDetails = async () => {
    try {
        const response = await ApiConnection.get('transaction/wallet-details',
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                }
            });
        if (response.status === 200) {
            return response.data.result
        } else {
            throw new Error(`Unable to fetch data: ${response.statusText}`)
        }
    } catch (error) {
        console.log(error)
    }
}
export const walletRecharge = async (payload: walletrecharge): Promise<{ stripePayment: any; paymentData: any } | null> => {
    try {
        const response = await ApiConnection.post('transaction/wallet-recharge', payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                }
            });

        if (response.status === 200) {
            const stripePayment = response.data.data.stripePayment;
            const paymentData = stripePayment.payment_data; // This can be simplified

            return { stripePayment, paymentData };
        } else {
            throw new Error(`Unable to fetch data: ${response.statusText}`);
        }
    } catch (error) {
        console.error(error); // Use console.error for error logging
        return null; // Return null or handle the error as needed
    }
}

export const transactionUpdate = async (payload: transUpdate) => {
    try {
        const response = await ApiConnection.post('transaction/transaction-update', payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                }
            })
        if (response.status === 200) {
            return response
        } else {
            throw new Error(`Unable to fetch data: ${response.statusText}`)
        }
    } catch (error) {
        console.log(error)
    }
}

export const transactionDetails = async (mem_id: transDetails): Promise<TransactionResponse> => {
    try {
        const response = await ApiConnection.post('transaction/transaction-deatils-list', mem_id, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
            }
        });
        if (response.status === 200) {
            return response;
        } else {
            throw new Error(`Unable to fetch data: ${response.statusText}`);
        }
    } catch (error) {
        throw error;
    }
};

// export const paymentReceived = async (payload) => {
//     return await ApiConnection.post('transaction/received-payment', payload)
// }

export const paymentReceived = async (payload: {}, id: string) => {
    try {
        const response = await ApiConnection.put(`transaction/verify-payment/${id}`, payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                }
            })
        if (response.status === 200) {
            return response
        } else {
            throw new Error(`Unexpected response status: ${response.status}`);
        }
    } catch (error) {
        console.error('Error receiving wallet payment:', error);
        throw error;
    }
}