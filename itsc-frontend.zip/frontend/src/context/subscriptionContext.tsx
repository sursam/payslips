// import { log } from "util";
import ApiConnection from "../ApiConnection";
import { SubscriptionType, SubscriptionListResponse } from "../types";

export const getSubscriptionList = async (): Promise<any> => {
    try {
        const response = await ApiConnection.get<SubscriptionListResponse>('subscription/list')
        console.log('Subscription list response:', response.data);

        if (response.status === 200) {
            return response
        } else {
            throw new Error(`Unexpected response status: ${response.status}`)
        }
    } catch (error) {
        console.error('Error retreving subscription list:', error);
        throw error
    }
}

export const createSubscription = async (payload: SubscriptionType) => {
    try {
        const response = await ApiConnection.post(`member/subscription/create`, payload);
        if (response.status === 200 || response.status === 201) {
            return response
        } else {
            throw new Error(`Unexpected response status: ${response.status}`)
        }
    } catch (error) {
        console.error('Error retreving subscription list:', error);
        throw error
    }
}

export const subscriptionPaymentReceived = async (payload: {}, id: string) => {
    try {
        const response = await ApiConnection.put(`transaction/verify-subscription-payment/${id}`, payload)
        if (response.status === 200) {
            return response
        } else {
            throw new Error(`Unexpected response status: ${response.status}`);
        }
    } catch (error) {
        console.error('Error receiving wallet payment:', error);
        throw error;
    }
}