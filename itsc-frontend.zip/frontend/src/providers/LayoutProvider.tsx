import React, { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, IconButton
} from '@mui/material';
import Header from '../components/Header/header';
import Sidebar from '../components/Sidebar/sidebar';

import styles from '../styles/header.module.css';
import { CalendarMonthOutlined, ArrowBackOutlined } from '@mui/icons-material';
import { useNavigate } from "react-router-dom";

interface LayoutProps {
  children: any;
  pageTitle?: string;
  backUrl?: string;
}
const LayoutProvider: React.FC<LayoutProps> = ({ children, pageTitle, backUrl }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const navigate = useNavigate();
  const toggleSidebar = useCallback(() => {
    setSidebarOpen(prev => !prev);
  }, []);
  useEffect(() => {
    // Update the time every second
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);

    // Clean up the interval when the component unmounts
    return () => clearInterval(timer);
  }, []);
  return (
    <Box className={styles.container}>
      <Sidebar isOpen={isSidebarOpen} />
      <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <Box className={`${styles.BodyWrap} ${isSidebarOpen ? styles.openbd : styles.closedbd}`}>
        <div className={styles.pageHeader}>
          <Box className={styles.pageHeaderTitle}>
            {backUrl ?
              <IconButton onClick={() => navigate(backUrl)} className={styles.toggleButton}>
                <ArrowBackOutlined style={{ width: '25px', height: '25px', color: '#283c50' }}></ArrowBackOutlined>
              </IconButton>
              : ''}
            <h5>{pageTitle}</h5>
          </Box>
          <div className={styles.pageHeaderTime}>
            <CalendarMonthOutlined style={{ width: '17px', height: '17px', color: '#005DAB', marginRight: '5px', verticalAlign: 'middle' }} />
            <label style={{ verticalAlign: 'middle' }}>
              {currentDateTime.toLocaleString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false }).replace('at', '|')}
            </label>

          </div>
        </div>
        <Box className="contentBody">
          {children}
        </Box>
        <Box className={styles.pageFooter}>
          <Typography className={styles.pageFooterText}>Copyright &copy; {currentDateTime.toLocaleString('en-US', { year: 'numeric' })}</Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default LayoutProvider;
