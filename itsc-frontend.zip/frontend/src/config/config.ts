export const headers = {
	Accept: "application/json",
	"Content-Type": "application/json"
};

const SITE_ENV = process.env.REACT_APP_SITE_ENV;

export const API_URL =
	SITE_ENV === "PROD"
		? process.env.REACT_APP_API_PROD_URL
		: SITE_ENV === "DEV"
		? process.env.REACT_APP_API_DEV_URL
		: process.env.REACT_APP_API_LOCAL_URL;

export const GOOGLE_MAPS_API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;

export const STRIPE_PUBLISHABLE_KEY =
	SITE_ENV === "PROD"
		? process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY_PROD
		: SITE_ENV === "DEV"
		? process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY_DEV
		: process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY_LOCAL;
