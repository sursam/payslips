import { Field, InputType, OmitType, PartialType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { LocationInput } from '@/resources/properties/dto/location.input'

@InputType()
export class UpdateHostProfileInput extends PartialType(
  OmitType(
    HostEntity,
    ['id', 'userId', 'property', 'businessLocation', 'stripeAccountDetails'],
    InputType,
  ),
) {
  @IsOptional()
  @Field(() => LocationInput, { nullable: true })
  businessLocation: LocationInput
}
