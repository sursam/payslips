import { forwardRef, Module } from '@nestjs/common'

import { StripeBusinessModule } from '@/common/services/integrations/stripe/business/stripe-business.module'
import { BookingsModule } from '@/resources/bookings/bookings.module'
import { HostsResolver } from '@/resources/hosts/hosts.resolver'
import { HostsService } from '@/resources/hosts/hosts.service'
import { PropertiesModule } from '@/resources/properties/properties.module'
import { UsersModule } from '@/resources/users/users.module'

@Module({
  imports: [UsersModule, StripeBusinessModule, BookingsModule, forwardRef(() => PropertiesModule)],
  providers: [HostsService, HostsResolver],
  exports: [HostsService],
})
export class HostsModule {}
