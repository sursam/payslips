import { type Host, type RmsMapping, type User } from '@prisma/client'

export class HostProfileChangedEvent {
  public host

  constructor(host: Host & { user: User & { rmsMapping: RmsMapping | null } }) {
    this.host = host
  }
}
