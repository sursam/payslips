import { BadRequestException, Headers, UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql'
import { Prisma, UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { RequestedFieldsDecorator } from '@/common/decorators/requested-fields.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenPayload, JwtTokenService } from '@/common/services/jwt-token/jwt-token.service'
import { CreateHostProfileInput } from '@/resources/hosts/dto/create-host-profile.input'
import { UpdateHostProfileInput } from '@/resources/hosts/dto/update-host-profile.input'
import { HostEntity } from '@/resources/hosts/entities/host.entity'
import { HostUserEntity } from '@/resources/hosts/entities/host-user.entity'
import { HostsService } from '@/resources/hosts/hosts.service'
import { UsersService } from '@/resources/users/users.service'

@Roles(UserRole.HOST)
@UseGuards(JwtAuthGuard, RolesGuard)
@Resolver(() => HostEntity)
export class HostsResolver {
  constructor(
    private readonly hostsService: HostsService,
    private readonly usersService: UsersService,
    private readonly jwtTokenService: JwtTokenService,
  ) {}

  @Query(() => HostUserEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  host(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: Prisma.UserSelect,
  ): Promise<HostUserEntity | null> {
    return this.usersService.findUnique(userDetails.email, select)
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  async createHostProfile(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: CreateHostProfileInput,
  ): Promise<MessageInterfaceEntity> {
    const user = await this.usersService.findUnique(userDetails.email, {
      role: true,
      host: true,
      id: true,
      firstName: true,
      lastName: true,
      email: true,
    })

    if (!user) {
      throw new BadRequestException(`Can't find a user`)
    }

    await this.hostsService.upsert(user, input)

    return { message: 'Host profile is created' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  async updateHostProfile(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdateHostProfileInput,
  ): Promise<MessageInterfaceEntity> {
    const user = await this.usersService.findUnique(userDetails.email, { id: true })
    const hostProfile = await this.hostsService.findUnique({ userId: user?.id }, { id: true })

    if (!hostProfile) {
      throw new BadRequestException(`Can't find a host profile for current user`)
    }

    await this.hostsService.updateProfile(hostProfile.id, input)

    return { message: 'Host profile is updated' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  async pauseHostAccount(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    await this.hostsService.pauseAccount(userDetails)

    return { message: 'Host account is paused' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  async unpauseHostAccount(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
  ): Promise<MessageInterfaceEntity> {
    await this.hostsService.unpauseAccount(userDetails)

    return { message: 'Host account is unpaused' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(HostsResolver.name)
  async deactivateHostAccount(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Context() ctx: ContextServer,
  ): Promise<MessageInterfaceEntity> {
    await this.hostsService.deactivateAccount(userDetails)

    this.jwtTokenService.clearTokenFromCookie(ctx.res)

    return { message: 'Host account is deactivated' }
  }
}
