import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { StripePublicAccountEntity } from '@/common/services/integrations/stripe/business/entities/stripe-business-account.entity'
import { HostInterface } from '@/resources/hosts/interfaces/host.interface'
import { LocationEntity } from '@/resources/properties/entities/location.entity'
import { PropertyEntity } from '@/resources/properties/entities/property.entity'

@ObjectType({
  implements: () => [HostInterface],
})
export class HostEntity extends HostInterface {
  @IsOptional()
  @Field(() => LocationEntity, { nullable: true })
  businessLocation?: LocationEntity | null

  @IsOptional()
  @Field(() => PropertyEntity, { nullable: true })
  property?: PropertyEntity | null

  @IsOptional()
  @Field(() => StripePublicAccountEntity, { nullable: true })
  stripeAccountDetails?: StripePublicAccountEntity | null
}
