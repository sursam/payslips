import { Field, Float, Int, ObjectType } from '@nestjs/graphql'

import { PaginationInterfaceEntity } from '@/common/interfaces/pagination.inteface'

@ObjectType()
class User {
  @Field(() => String)
  displayName: string
}

@ObjectType()
export class ReviewEntity {
  @Field(() => Float)
  score: number

  @Field(() => String)
  content: string

  @Field(() => String)
  title: string

  @Field(() => String)
  createdAt: string

  @Field(() => Int)
  productId: number

  @Field(() => User)
  user: User
}

@ObjectType()
class ReviewsPaginationEntity extends PaginationInterfaceEntity {}

@ObjectType()
export class ReviewsEntity {
  @Field(() => [ReviewEntity])
  readonly data: ReviewEntity[]

  @Field(() => ReviewsPaginationEntity)
  readonly pagination: ReviewsPaginationEntity
}
