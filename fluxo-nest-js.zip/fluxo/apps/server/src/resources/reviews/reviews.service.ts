import { UTCDate } from '@date-fns/utc'
import { HttpService } from '@nestjs/axios'
import { BadRequestException, Injectable, Logger } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { OnEvent } from '@nestjs/event-emitter'
import { Cron, CronExpression } from '@nestjs/schedule'
import { AxiosError } from 'axios'
import { format } from 'date-fns'
import { delay } from 'es-toolkit'

import { AppConfig } from '@/common/config/configuration'
import { Events } from '@/common/enums'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { convertCentsToUnits } from '@/common/utils'
import { PropertyUpdatedEvent } from '@/resources/properties/events/property-updated.event'

import { PropertyCreatedEvent } from '../properties/events/property-created.event'
import { ReviewInput } from './dto/review.input'
import { ReviewsInput } from './dto/reviews.input'
import { ReviewsEntity } from './entities/reviews.entity'
import { ReviewScoreResponse } from './interfaces/review-score.interface'
import { ReviewMeta, ReviewsMetaResponse, ReviewsResponse } from './interfaces/reviews.interface'

@Injectable()
export class ReviewsService {
  private readonly baseUrl = 'https://api.yotpo.com'
  private readonly baseCdnUrl = 'https://api-cdn.yotpo.com'
  private readonly logger = new Logger(ReviewsService.name)
  private readonly apiKey = this.configService.get('yotpo.apiKey', { infer: true })
  private readonly secretKey = this.configService.get('yotpo.apiSecret', { infer: true })

  private accessToken: string | null = null
  private tokenExpiry: Date | null = null

  constructor(
    private readonly prismaService: PrismaService,
    private readonly httpService: HttpService,
    private configService: ConfigService<AppConfig>,
  ) {}

  private async getAccessToken(): Promise<string> {
    const now = new Date()

    if (this.accessToken && this.tokenExpiry && now < this.tokenExpiry) {
      return this.accessToken
    }

    const payload = {
      client_id: this.apiKey,
      client_secret: this.secretKey,
      grant_type: 'client_credentials',
    }

    const { data } = await this.httpService.axiosRef.post<{
      access_token: string
      expires_in: number
      error?: string
    }>(`${this.baseUrl}/oauth/token`, payload)

    if (data.error) {
      throw new BadRequestException(`Yotpo retrieval token error: ${data.error}`)
    }

    this.accessToken = data.access_token
    /**
     *  Cache token for 24 hours
     */
    this.tokenExpiry = new Date(now.getTime() + 24 * 60 * 60 * 1000)
    this.logger.log(`Fetched new access token.`)

    return this.accessToken
  }

  private async processRequest(request: () => Promise<void>): Promise<void> {
    try {
      await request()
    } catch (error) {
      if (error instanceof AxiosError && error.response) {
        this.logger.error('Yotpo API Error:', {
          status: error.response.status,
          statusText: error.response.statusText,
          data: error.response.data,
        })
        throw new BadRequestException(error.response.data)
      } else {
        this.logger.error('Unexpected Error:', error)
        throw new BadRequestException('Unexpected error occurred')
      }
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT, { timeZone: 'America/Los_Angeles' })
  async syncReviewsScore(): Promise<void> {
    const perPage = 100
    let page = 1
    let isFinished = false

    while (!isFinished) {
      try {
        const { data } = await this.httpService.axiosRef.get<ReviewScoreResponse>(
          `${this.baseCdnUrl}/v1/apps/${this.apiKey}/bottom_lines?count=${perPage}&page=${page}`,
        )

        const bottomLines = data.response?.bottomlines ?? []
        const totalPerPage = bottomLines.length

        this.logger.log(`Reviews per page: ${totalPerPage}, page: ${data.response?.page}`)

        if (totalPerPage === 0) {
          this.logger.log('No bottom lines, exiting the cron job..')
          isFinished = true
          break
        }

        await Promise.all(
          bottomLines.map(async (bottomLine) => {
            return this.prismaService.property.update({
              where: { id: bottomLine.domain_key },
              data: {
                score: bottomLine.product_score,
                totalReviews: bottomLine.total_reviews,
              },
            })
          }),
        )

        if (totalPerPage < perPage) {
          isFinished = true
          break
        }
        page += 1

        await delay(2000)
      } catch (error) {
        this.logger.error(`Error syncing reviews on page ${page}: `, error)
        isFinished = true
      }
    }
  }

  @OnEvent(Events.PROPERTY_CREATED)
  async addProduct(payload: PropertyCreatedEvent): Promise<void> {
    const { property } = payload

    const [dayPass, accessToken] = await Promise.all([
      this.prismaService.dayPass.findUnique({
        where: { propertyId: property.id },
        select: { dailyCost: true },
      }),
      this.getAccessToken(),
    ])

    await this.processRequest(() => {
      return this.httpService.axiosRef.post(
        `${this.baseUrl}/core/v3/stores/${this.apiKey}/products`,
        {
          product: {
            status: 'active',
            external_id: property.id,
            name: property.name,
            description: property.description,
            url: 'https://fluxo-web.vercel.app/search',
            price: dayPass?.dailyCost ? convertCentsToUnits(dayPass.dailyCost) : undefined,
            sku: property.id,
          },
        },
        {
          headers: {
            'X-Yotpo-Token': accessToken,
          },
        },
      )
    })
  }

  @OnEvent(Events.PROPERTY_UPDATED)
  async updateProduct(payload: PropertyUpdatedEvent): Promise<void> {
    const property = await this.prismaService.property.findUniqueOrThrow({
      where: { id: payload.id },
      select: { id: true, name: true, description: true },
    })

    const [dayPass, accessToken] = await Promise.all([
      this.prismaService.dayPass.findUnique({
        where: { propertyId: property.id },
        select: { dailyCost: true },
      }),
      this.getAccessToken(),
    ])

    const { data: yotpoProducts } = await this.httpService.axiosRef.get<
      { yotpo_id: string }[] | null[] | null
    >(`${this.baseUrl}/v3/stores/${this.apiKey}/products?external_ids=${property.id}`, {
      headers: {
        'X-Yotpo-Token': accessToken,
      },
    })

    const yotpoProduct = yotpoProducts?.find((product) => product?.yotpo_id === property.id)
    if (!yotpoProduct) {
      this.logger.log(`Property ${property.id} is missing from Yotpo account`)
      return
    }

    await this.processRequest(async () => {
      return this.httpService.axiosRef.patch(
        `${this.baseUrl}/core/v3/stores/${this.apiKey}/products/${yotpoProduct.yotpo_id}`,
        {
          product: {
            name: property.name,
            description: property.description,
            price: dayPass?.dailyCost ? convertCentsToUnits(dayPass.dailyCost) : undefined,
          },
        },
        {
          headers: {
            'X-Yotpo-Token': accessToken,
          },
        },
      )
    })
  }

  async createReview(input: ReviewInput, ctx: ContextServer): Promise<MessageInterfaceEntity> {
    const userDetails = ctx.req.userDetails

    const [user, property, accessToken] = await Promise.all([
      this.prismaService.user.findUniqueOrThrow({
        where: { id: userDetails?.id },
        include: { guest: true },
      }),
      this.prismaService.property.findUniqueOrThrow({ where: { id: input.propertyId } }),
      this.getAccessToken(),
    ])

    const bookingReview = await this.prismaService.bookingReview.findFirst({
      where: {
        propertyId: property.id,
        guestId: user.guest?.id,
      },
    })

    if (bookingReview) {
      throw new BadRequestException('You have already left review for this booking.')
    }

    const payload = {
      appkey: this.apiKey,
      domain: process.env.NEXT_PUBLIC_WEB_APP_URL,

      sku: property.id,
      product_title: property.name,
      product_image_url: property.logoUrl,
      product_url: `${process.env.NEXT_PUBLIC_WEB_APP_URL}/venue/${property.id}`,

      display_name: `${user.firstName} ${user.lastName}`,
      email: user.email,

      customer_metadata: {
        custom_properties: [
          {
            name: 'user_profile_image_url',
            value: user.guest?.profileImageUrl,
          },
        ],
      },

      review_content: input.comments ?? '-',
      review_title: input.mainHighlight,
      review_score: input.score,
    }

    await this.processRequest(() => {
      return this.httpService.axiosRef.post(`${this.baseUrl}/v1/widget/reviews`, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })
    })

    if (user.guest) {
      await this.prismaService.bookingReview.create({
        data: {
          reviewScore: input.score,
          guestId: user.guest.id,
          propertyId: property.id,
        },
      })
    }

    return { message: 'ok' }
  }

  async findReviews(input: ReviewsInput): Promise<ReviewsEntity> {
    // Available sort values: date, votes_up, votes_down, time, rating, reviewer_type
    // https://develop.yotpo.com/reference/all-reviews
    const { page = 1, take = 10, order = 'desc', sort = 'date' } = input.pagination

    const { data } = await this.httpService.axiosRef.get<ReviewsResponse>(
      `${this.baseCdnUrl}/v1/widget/${this.apiKey}/products/${input.propertyId}/reviews.json?page=${page}&per_page=${take}&sort=${sort}&direction=${order}`,
    )

    /**
     * At the Dev Standup on December 9 decided not to output user profile image URL so far
     */
    // const accessToken = await this.getAccessToken()
    //
    // const metadata = await Promise.all(
    //   data.response.reviews.map(async (review) => {
    //     return this.httpService.axiosRef.get<ReviewsResponse>(
    //       `${this.baseUrl}/v1/apps/${this.apiKey}/reviews/${review.id}/metadata?utoken=${accessToken}`,
    //     )
    //   }),
    // )
    //

    const { pagination } = data.response

    return {
      data: data.response.reviews.map((review) => ({
        score: review.score,
        content: review.content,
        title: review.title,
        createdAt: review.created_at,
        productId: review.product_id,
        user: {
          displayName: review.user.display_name,
        },
      })),
      pagination: {
        order,
        page,
        sort,
        take,
        total: pagination.total,
        pages: Math.ceil(pagination.total / pagination.per_page),
      },
    }
  }

  async findReviewsSinceDate(date: UTCDate): Promise<ReviewMeta[]> {
    const reviews: ReviewMeta[] = []

    const perPage = 100
    let page = 1
    let isFinished = false

    const accessToken = await this.getAccessToken()

    while (!isFinished) {
      try {
        const formattedDate = format(date, 'yyyy-MM-dd')

        const { data } = await this.httpService.axiosRef.get<ReviewsMetaResponse>(
          `${this.baseCdnUrl}/v1/apps/${this.apiKey}/reviews?utoken=${accessToken}&count=${perPage}&page=${page}&since_date=${formattedDate}`,
        )

        const reviewsForPage = data.reviews ?? []

        if (reviewsForPage.length === 0) {
          break
        }

        reviews.push(...reviewsForPage)
        page += 1

        await delay(1000)
      } catch (error) {
        this.logger.error(`Error getting reviews on page ${page}: `, error)
        isFinished = true
      }
    }

    return reviews
  }

  async importProducts(): Promise<MessageInterfaceEntity> {
    const properties = await this.prismaService.property.findMany({
      include: {
        dayPass: {
          select: {
            dailyCost: true,
          },
        },
      },
    })

    if (!properties.length) {
      this.logger.log('No properties found for import.')

      return { message: 'ok' }
    }

    const accessToken = await this.getAccessToken()

    await Promise.all(
      properties.map(async (property) => {
        await this.processRequest(() => {
          return this.httpService.axiosRef.post(
            `${this.baseUrl}/core/v3/stores/${this.apiKey}/products`,
            {
              product: {
                status: 'active',
                external_id: property.id,
                name: property.name,
                description: property.description,
                url: `${process.env.NEXT_PUBLIC_WEB_APP_URL}/venue/${property.id}`,
                price: property.dayPass?.dailyCost
                  ? convertCentsToUnits(property.dayPass.dailyCost)
                  : undefined,
                sku: property.id,
              },
            },
            {
              headers: {
                'X-Yotpo-Token': accessToken,
              },
            },
          )
        })

        this.logger.log(`Successfully imported property with ID: ${property.id}`)
      }),
    )

    return { message: 'ok' }
  }
}
