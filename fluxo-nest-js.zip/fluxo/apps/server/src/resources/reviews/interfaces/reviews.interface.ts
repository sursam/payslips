interface Review {
  id: number
  score: number
  content: string
  title: string
  created_at: string
  product_id: number
  user: {
    user_id: number
    social_image: string | null
    display_name: string
  }
}

export interface ReviewsResponse {
  status: {
    code: number
    message: string
  }
  response: {
    bottomline?: {
      total_review: number
      average_score: number
    }
    reviews: Review[]
    pagination: {
      page: number
      per_page: number
      total: number
    }
  }
}

export interface ReviewMeta {
  id: number
  sku: string
  created_at: string
  updated_at: string
}

export interface ReviewsMetaResponse {
  reviews?: ReviewMeta[]
}
