import { UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'

import { ReviewInput } from './dto/review.input'
import { ReviewsInput } from './dto/reviews.input'
import { ReviewsEntity } from './entities/reviews.entity'
import { ReviewsService } from './reviews.service'

@Resolver()
export class ReviewsResolver {
  constructor(private readonly reviewsService: ReviewsService) {}

  @Roles(UserRole.GUEST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(ReviewsResolver.name)
  createReview(
    @Args('input') input: ReviewInput,
    @Context() ctx: ContextServer,
  ): Promise<MessageInterfaceEntity> {
    return this.reviewsService.createReview(input, ctx)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => ReviewsEntity)
  @ErrorGraphqlHandlingDecorator(ReviewsResolver.name)
  reviews(@Args('input') input: ReviewsInput): Promise<ReviewsEntity> {
    return this.reviewsService.findReviews(input)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(ReviewsResolver.name)
  importProducts(): Promise<MessageInterfaceEntity> {
    return this.reviewsService.importProducts()
  }
}
