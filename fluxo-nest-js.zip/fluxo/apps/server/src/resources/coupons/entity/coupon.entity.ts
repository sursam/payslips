import { ObjectType, Field } from '@nestjs/graphql';

@ObjectType()
export class Coupon {
  @Field()
  id: string;

  @Field(() => Number, { nullable: true })
  amount_off?: number | null;

  @Field()
  created_at: Date;

  @Field(() => String, { nullable: true })
  currency?: string | null;

  @Field()
  duration: string;

  @Field(() => Number, { nullable: true })
  duration_in_months?: number | null;

  @Field()
  livemode: boolean;

  @Field(() => Number, { nullable: true })
  max_redemptions?: number | null;

  @Field(() => String, { nullable: true })
  name?: string | null;

  @Field(() => Number, { nullable: true })
  percent_off?: number | null;

  @Field(() => Date, { nullable: true })
  redeem_by?: Date | null;

  @Field()
  times_redeemed: number;

  @Field()
  valid: boolean;
}
