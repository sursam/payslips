import { Module } from '@nestjs/common';
import { CouponService } from './coupons.service';
import { CouponResolver } from './coupons.resolver';

@Module({
  providers: [CouponService, CouponResolver],
  exports: [CouponService],
})
export class CouponsModule {}
