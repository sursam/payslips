import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/common/services/prisma/prisma.service';
import { CouponValidationResult } from './dto/coupon-validation-result.dto';
import { times } from 'es-toolkit/compat';
import { UserCouponsResult } from './dto/coupon-user-result.dto';

@Injectable()
export class CouponService {
  constructor(private readonly prisma: PrismaService) {}

  async getAllCoupons() {
    const coupons = await this.prisma.stripeCoupons.findMany();

    console.log('Fetched coupons from database:', coupons);

    return coupons.map((coupon) => ({
      ...coupon,
      amount_off: coupon.amount_off ? coupon.amount_off / 100 : undefined,
      currency: coupon.currency ?? undefined,
      duration_in_months: coupon.duration_in_months ?? undefined,
      max_redemptions: coupon.max_redemptions ?? undefined,
      name: coupon.name ?? undefined,
      percent_off: coupon.percent_off ?? undefined,
      redeem_by: coupon.redeem_by ? new Date(Number(coupon.redeem_by)) : undefined,
      created_at: new Date(Number(coupon.created_at)),
    }));
  }

  async getCouponById(id: string) {
    return this.prisma.stripeCoupons.findUnique({ where: { id } });
  }
  

  async validateCoupon(
    userId: string,
    couponCode: string,
    bookingAmount: number,
  ): Promise<CouponValidationResult> {
    const coupon = await this.prisma.stripeCoupons.findUnique({ where: { id: couponCode } });
    if (!coupon) return { valid: false, reason: 'This code is invalid.' };
  
    // Expiry Date Check
    if (coupon.redeem_by && new Date(Number(coupon.redeem_by)) < new Date()) {
      return { valid: false, reason: 'Coupon expired' };
    }
  
    // Check coupon duration rules for all durations
    if (coupon.duration === 'once' && coupon.times_redeemed > 0) {
        return { valid: false, reason: 'Coupon can only be redeemed once.' };
    } else if (coupon.duration === 'forever') {
      if (coupon.max_redemptions !== null && coupon.times_redeemed >= coupon.max_redemptions) {
        return { valid: false, reason: 'Max redemptions exceeded for this forever coupon.' };
      }
    } else if (coupon.duration === 'repeating') {
      const currentDate = new Date();
      const startDate = new Date(Number(coupon.created_at));
      const durationMonths = coupon.duration_in_months || 0;
      const endDate = new Date(startDate.setMonth(startDate.getMonth() + durationMonths));
  
      if (currentDate > endDate) {
        return { valid: false, reason: 'Coupon validity period has expired.' };
      }
  
      if (coupon.max_redemptions !== null && coupon.times_redeemed >= coupon.max_redemptions) {
        return { valid: false, reason: 'Max redemptions exceeded for this repeating coupon.' };
      }
    }

    // Check if the user has already used this specific coupon
    const userSpecificCoupon = await this.prisma.stripeCouponUsage.count({
      where: { userId, couponCode },
    });
    if (userSpecificCoupon > 0) {
      return { valid: false, reason: 'Coupon already used by this user' };
    }

    // Booking constraints validation
    const minBookingAmount = coupon.amount_off ? coupon.amount_off / 100 : 0;
    if(minBookingAmount != 0){
      if (bookingAmount < minBookingAmount) {
        return { valid: false, reason: 'Minimum booking amount required' };
      }
    }else if(bookingAmount == 0){
      return { valid: false, reason: 'Minimum booking amount required' };
    }

    return { valid: true, reason: 'Valid coupon.' };
  }

  // Update Database after coupon is used
  async userCoupon(userId: string, couponCode: string): Promise<UserCouponsResult> {
      // Update the coupon's times_redeemed
      await this.prisma.stripeCoupons.updateMany({
        where: { name : couponCode },
        data: {
          times_redeemed: {
            increment: 1,
          },
        },
      });

      // Create a new record in the StripeCouponUsage table
      await this.prisma.stripeCouponUsage.create({
        data: {
          userId,
          couponCode,
        },
      });

      // Return a UserCouponsResult object
      return { valid: true, reason: 'updated', userId, couponCode };
  }

}



