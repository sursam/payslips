import { ObjectType, Field } from '@nestjs/graphql';

@ObjectType()
export class CouponValidationResult {
  @Field()
  valid: boolean;

  @Field()
  reason: string;
}
