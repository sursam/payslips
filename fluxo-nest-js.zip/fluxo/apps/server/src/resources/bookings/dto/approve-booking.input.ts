import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

import { AddressInput } from '@/common/services/integrations/stripe/customers/dto/checkout.input'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@InputType()
export class ApproveBookingInput extends PickType(BookingPassEntity, ['id'], InputType) {
  // TODO: temp before https://github.com/materialize-labs/fluxo_backend/pull/40 merged
  @IsNotEmpty()
  @Field(() => AddressInput)
  addressForTaxes: AddressInput
}
