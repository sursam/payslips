import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { BookingTimeline } from '@/common/enums'
import { PaginationInterfaceInput } from '@/common/interfaces/pagination.inteface'

@InputType()
export class GuestBookingsInput extends PickType(
  PaginationInterfaceInput,
  ['pagination'],
  InputType,
) {
  @IsOptional()
  @Field(() => BookingTimeline, { nullable: true })
  timeline: BookingTimeline | null
}
