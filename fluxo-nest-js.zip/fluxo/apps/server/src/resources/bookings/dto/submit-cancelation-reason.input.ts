import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

@InputType()
export class SubmitCancelationReasonInput extends PickType(BookingPassEntity, ['id'], InputType) {
  @IsNotEmpty()
  @Field()
  cancelationReason: string
}
