import { InputType, PickType, registerEnumType } from '@nestjs/graphql'

import { BookingTimeline } from '@/common/enums'
import { BookingPassEntity } from '@/resources/bookings/entities/booking-pass.entity'

registerEnumType(BookingTimeline, {
  name: 'BookingTimeline',
})

@InputType()
export class BookingPassInput extends PickType(BookingPassEntity, ['groupId'], InputType) {}
