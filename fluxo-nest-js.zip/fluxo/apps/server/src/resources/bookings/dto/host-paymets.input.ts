import { Field, InputType, PickType } from '@nestjs/graphql'
import { PaymentStatus } from '@prisma/client'
import { IsOptional } from 'class-validator'

import { PaginationInterfaceInput } from '@/common/interfaces/pagination.inteface'

@InputType()
export class HostPaymentsInput extends PickType(
  PaginationInterfaceInput,
  ['pagination', 'search'],
  InputType,
) {
  @IsOptional()
  @Field(() => Date, { nullable: true })
  date: Date | null

  @IsOptional()
  @Field(() => PaymentStatus, { nullable: true })
  status: PaymentStatus

  @IsOptional()
  @Field(() => Boolean, { nullable: true })
  refunded: boolean
}
