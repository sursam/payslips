import { UTCDate } from '@date-fns/utc'
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { Cron, CronExpression } from '@nestjs/schedule'
import { BookingEntityType, BookingStatus, Prisma, RmsEntityType } from '@prisma/client'
import {
  add,
  differenceInHours,
  endOfDay,
  isToday,
  isTomorrow,
  startOfDay,
  subDays,
  subYears,
} from 'date-fns'
import { delay, isNotNil, merge, sample } from 'es-toolkit'
import { customAlphabet } from 'nanoid'
import pLimit from 'p-limit'

import { BookingTimeline, Events } from '@/common/enums'
import {
  createPaginatedResponse,
  getPrismaPagination,
  PaginatedSelect,
} from '@/common/pagination-utils'
import { RmsCloudService } from '@/common/services/integrations/rms-cloud/rms-cloud.service'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { bookingStatusTransitions, isPropertyInactive } from '@/common/utils'
import { ApproveBookingInput } from '@/resources/bookings/dto/approve-booking.input'
import { CancelBookingAsGuestInput } from '@/resources/bookings/dto/cancel-booking-as-guest.input'
import { CancelBookingAsHostInput } from '@/resources/bookings/dto/cancel-booking-as-host.input'
import { CheckInBookingInput } from '@/resources/bookings/dto/check-in-booking.input'
import { CreateBookingInput } from '@/resources/bookings/dto/create-booking.input'
import { DeclineBookingInput } from '@/resources/bookings/dto/decline-booking.input'
import { GuestBookingsInput } from '@/resources/bookings/dto/guest-bookings.input'
import { HostBookingsInput } from '@/resources/bookings/dto/host-bookings.input'
import { HostPaymentsInput } from '@/resources/bookings/dto/host-paymets.input'
import { SubmitCancelationReasonInput } from '@/resources/bookings/dto/submit-cancelation-reason.input'
import { GuestsService } from '@/resources/guests/guests.service'
import { GuestBookingCancellationEvent } from '@/resources/notifications/events/guest-booking-cancellation.event'
import { GuestBookingConfirmationEvent } from '@/resources/notifications/events/guest-booking-confirmation.event'
import { GuestBookingRequestApprovedEvent } from '@/resources/notifications/events/guest-booking-request-approved.event'
import { GuestBookingRequestDeclinedEvent } from '@/resources/notifications/events/guest-booking-request-declined.event'
import { GuestCheckedInEvent } from '@/resources/notifications/events/guest-checked-in.event'
import { GuestCheckedOutEvent } from '@/resources/notifications/events/guest-checked-out.event'
import { HostBookingCancellationEvent } from '@/resources/notifications/events/host-booking-cancellation.event'
import { HostBookingConfirmationEvent } from '@/resources/notifications/events/host-booking-confirmation.event'
import { HostBookingRequestEvent } from '@/resources/notifications/events/host-booking-request.event'

@Injectable()
export class BookingsService {
  private CANCELLATION_REFUND_TIME_LIMIT = 48 // 48 hours before booking arrival date
  private readonly logger = new Logger(BookingsService.name)

  constructor(
    private readonly prismaService: PrismaService,
    private readonly rmsCloudService: RmsCloudService,
    private readonly guestsService: GuestsService,
    private readonly stripeCustomersService: StripeCustomersService,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  @Cron(CronExpression.EVERY_MINUTE)
  private async handleRTBPencilBookingsExpiration() {
    const now = new UTCDate()
    const expiredRTBPencilBookings = await this.prismaService.bookingPass.findMany({
      where: {
        bookingStatus: { in: [BookingStatus.PENCIL_RTB] },
        expiresAt: { lte: now },
      },
      select: {
        id: true,
      },
    })

    if (expiredRTBPencilBookings.length === 0) {
      return
    }

    const limit = pLimit(3)

    await Promise.all(
      expiredRTBPencilBookings.map((booking) =>
        limit(async () => {
          await this.updateStatus(
            booking.id,
            BookingStatus.CANCELED_BY_SYSTEM,
            'Payment is not received',
          )

          await delay(500)
        }),
      ),
    )
  }

  /*
    Run the update every hour to handle the cases where RMS is unavailable and the job fails.
    The best solution would be to implement something like queues and retry functionality, but this approach is the simplest.
    If the previous update was successful, the process will skip the update
    because the previous day will not have bookings in the "Arrived" and "Confirmed" statuses
    (as they would already have been updated, assuming it is still the same day).
  */
  @Cron(CronExpression.EVERY_HOUR)
  private async updateOldBookingsStatus() {
    const now = new UTCDate()
    const yesterday = subDays(now, 1)
    const oldBookings = await this.prismaService.bookingPass.findMany({
      where: {
        bookingStatus: { in: [BookingStatus.ARRIVED, BookingStatus.CONFIRMED] },
        departureDate: { lte: endOfDay(yesterday) },
      },
      select: {
        id: true,
        confirmationNumber: true,
        arrivalDate: true,
        departureDate: true,
        groupId: true,
        guestId: true,
        bookingStatus: true,
        guest: { select: { userId: true } },
      },
    })

    if (oldBookings.length === 0) {
      return
    }

    const limit = pLimit(5)

    const guests: string[] = []

    await Promise.all(
      oldBookings.map((booking) =>
        limit(async () => {
          if (booking.bookingStatus === 'ARRIVED') {
            if (booking.guestId && !guests.includes(booking.guestId)) {
              this.sendGuestRateExperienceNotification(booking)

              guests.push(booking.guestId)
            }

            await this.updateStatus(booking.id, BookingStatus.DEPARTED)
          } else if (booking.bookingStatus === 'CONFIRMED') {
            await this.updateStatus(booking.id, BookingStatus.NO_SHOW)
          }

          await delay(1000)
        }),
      ),
    )
  }

  public async findUnique(input: { id: string }, select: Prisma.BookingPassSelect) {
    return this.prismaService.bookingPass.findUnique({ where: { id: input.id }, select })
  }

  public async findMany(args: Prisma.BookingPassFindManyArgs) {
    return this.prismaService.bookingPass.findMany(args)
  }

  public async submitCancelationReason(
    input: SubmitCancelationReasonInput,
    userDetails: JwtTokenPayload,
  ) {
    const guest = await this.guestsService.findUnique({
      where: { userId: userDetails.id, bookingPasses: { some: { id: input.id } } },
    })

    if (!guest?.id) {
      throw new UnauthorizedException('Current guest user is not the owner of that booking')
    }

    const updatedBooking = await this.prismaService.bookingPass.update({
      where: { id: input.id },
      data: { bookingStatus: BookingStatus.CANCELED_BY_GUEST },
      select: { rmsMapping: { select: { rmsId: true } } },
    })

    await this.rmsCloudService.updateReservationStatus({
      reservationId: updatedBooking.rmsMapping.rmsId,
      newStatus: BookingStatus.CANCELED_BY_GUEST,
      cancelationNote: input.cancelationReason,
    })
  }

  public async cancelBookingAsGuest(
    input: CancelBookingAsGuestInput,
    userDetails: JwtTokenPayload,
  ) {
    const guest = await this.guestsService.findUnique({
      where: { userId: userDetails.id, bookingPasses: { some: { id: input.id } } },
    })

    if (!guest?.id) {
      throw new UnauthorizedException('Current guest user is not the owner of that booking')
    }

    const bookingPass = await this.findUnique(
      { id: input.id },
      {
        bookingEntityType: true,
        bookingStatus: true,
        id: true,
        confirmationNumber: true,
        arrivalDate: true,
        departureDate: true,
        groupId: true,
        dayPassId: true,
        spaceId: true,
      },
    )

    if (bookingPass) {
      const hostUserId = await this.findHostUserIdByBookingPass(bookingPass)

      if (hostUserId) {
        this.sendHostBookingCanceledNotification(hostUserId, bookingPass, guest)
      } else {
        this.logger.error(`Could not find host user fo booking with ID: ${input.id}`)
      }
      this.sendGuestBookingCanceledNotification(userDetails.id, bookingPass)
    } else {
      this.logger.error(`Could not find booking with ID: ${input.id}`)
    }

    await this.updateStatus(input.id, BookingStatus.CANCELED_BY_GUEST)
  }

  public async cancelBookingAsHost(input: CancelBookingAsHostInput, userDetails: JwtTokenPayload) {
    const isHostOwner = await this.isBookedVenueOwnedByHost(userDetails.id, input.id)

    if (!isHostOwner) {
      throw new UnauthorizedException(
        'Current host user is not the owner of the venue of this booking',
      )
    }

    const bookingPass = await this.findUnique(
      { id: input.id },
      {
        bookingStatus: true,
        id: true,
        guest: {
          select: {
            userId: true,
          },
        },
        confirmationNumber: true,
        arrivalDate: true,
        departureDate: true,
        groupId: true,
      },
    )

    if (bookingPass?.guest?.userId) {
      this.sendGuestBookingCanceledNotification(bookingPass.guest.userId, bookingPass)
    } else {
      this.logger.error(`Could not find user for booking with ID: ${input.id}`)
    }

    await this.updateStatus(input.id, BookingStatus.CANCELED_BY_HOST)
  }

  public async cancelPencilBookingOnPaymentFailure(bookingGroupId: string) {
    try {
      const pencilBookings = await this.prismaService.bookingPass.findMany({
        where: {
          groupId: bookingGroupId,
          bookingStatus: { in: [BookingStatus.PENCIL, BookingStatus.PENCIL_RTB] },
        },
        select: {
          id: true,
          rmsMapping: { select: { rmsId: true } },
        },
      })

      if (!pencilBookings.length) {
        this.logger.warn(`No pencil bookings found for group ID: ${bookingGroupId}`)
        return
      }

      await Promise.all(
        pencilBookings.map(async (booking) => {
          if (booking.rmsMapping.rmsId) {
            await this.rmsCloudService.updateReservationStatus({
              reservationId: booking.rmsMapping.rmsId,
              newStatus: BookingStatus.CANCELED_BY_SYSTEM,
              cancelationNote: 'Canceled on payment failure',
            })
          }

          await this.prismaService.bookingPass.update({
            where: { id: booking.id },
            data: { bookingStatus: BookingStatus.CANCELED_BY_SYSTEM },
          })
        }),
      )

      this.logger.log(`Successfully canceled pencil bookings for group ID: ${bookingGroupId}`)
    } catch (error) {
      this.logger.error(`Failed to cancel pencil bookings for group ID: ${bookingGroupId}`, error)
      throw new InternalServerErrorException(
        `Failed to cancel pencil bookings for group ID: ${bookingGroupId}`,
      )
    }
  }

  public async findHostBookings(
    input: HostBookingsInput,
    { data: { select } }: PaginatedSelect<Prisma.BookingPassSelect>,
    userDetails: JwtTokenPayload,
  ) {
    const hostPropertyOwnershipCondition = { property: { host: { userId: userDetails.id } } }
    const andCondition = [
      {
        AND: [
          {
            OR: [
              { space: hostPropertyOwnershipCondition },
              { dayPass: hostPropertyOwnershipCondition },
            ],
          },
          { bookingStatus: { not: BookingStatus.PENCIL } },
          {
            ...(isNotNil(input.timeline)
              ? this.getBookingTimelineCondition(
                  input.timeline,
                  input.includeRTBBookingsInUpcoming ?? false,
                )
              : {}),
          },
        ],
      },
    ] as Prisma.BookingPassWhereInput[]

    // If date exists, return booking only for the selected day
    if (input.date) {
      const utcDate = new UTCDate(input.date)

      andCondition.push({
        arrivalDate: { gte: startOfDay(utcDate), lte: endOfDay(utcDate) },
      })
    }

    if (input.search) {
      andCondition.push({
        OR: [
          { guest: { user: { firstName: { contains: input.search || '', mode: 'insensitive' } } } },
          { guest: { user: { lastName: { contains: input.search || '', mode: 'insensitive' } } } },
          { confirmationNumber: { contains: input.search || '', mode: 'insensitive' } },
        ],
      })
    }

    const { orderBy, take, skip } = getPrismaPagination(input.pagination)
    const where = { AND: andCondition }

    const [data, total] = await this.prismaService.$transaction([
      this.prismaService.bookingPass.findMany({
        where,
        select: merge(select, {
          group: {
            select: {
              baseTotalPrice: true,
              totalPrice: true,
              fees: true,
              bookingFee: true,
              transactionFee: true,
              taxes: true,
            },
          },
        }),
        take,
        skip,
        orderBy,
      }),
      this.prismaService.bookingPass.count({ where }),
    ])

    return createPaginatedResponse({
      data,
      total,
      pagination: input.pagination,
    })
  }

  public async findGuestBookings(
    input: GuestBookingsInput,
    { data: { select } }: PaginatedSelect<Prisma.BookingPassSelect & { reviewScore?: number }>,
    userDetails: JwtTokenPayload,
  ) {
    const andCondition = [
      {
        guest: { userId: userDetails.id },
        bookingStatus: { not: BookingStatus.PENCIL },
        ...(isNotNil(input.timeline) ? this.getBookingTimelineCondition(input.timeline) : {}),
      },
    ] as Prisma.BookingPassWhereInput[]

    const { orderBy, take, skip } = getPrismaPagination(input.pagination)
    const where = { AND: andCondition }

    const { reviewScore, ...otherSelectProps } = select

    const [bookingPasses, total, guest] = await this.prismaService.$transaction([
      this.prismaService.bookingPass.findMany({
        where,
        select: merge(otherSelectProps, {
          group: {
            select: {
              baseTotalPrice: true,
              totalPrice: true,
              fees: true,
              bookingFee: true,
              transactionFee: true,
              taxes: true,
            },
          },
          space: {
            select: {
              propertyId: true,
            },
          },
          dayPass: {
            select: {
              propertyId: true,
            },
          },
        }),
        take,
        skip,
        orderBy,
      }),
      this.prismaService.bookingPass.count({ where }),
      this.prismaService.guest.findUnique({
        where: { userId: userDetails.id },
        select: { id: true },
      }),
    ])

    const reviewsConditions = bookingPasses
      .filter((pass) => pass.space?.propertyId ?? pass.dayPass?.propertyId)
      .map((pass) => ({
        guestId: guest?.id!,
        propertyId: pass.space?.propertyId ?? pass.dayPass?.propertyId,
      }))

    const reviews = await this.prismaService.bookingReview.findMany({
      where: {
        OR: reviewsConditions,
      },
      select: {
        reviewScore: true,
        property: { select: { id: true } },
        guest: { select: { id: true } },
      },
    })

    const data = bookingPasses.map((bookingPass) => {
      const propertyId = bookingPass.space?.propertyId || bookingPass.dayPass?.propertyId

      const review = reviews.find(
        (item) => item.guest.id === guest?.id && item.property.id === propertyId,
      )

      return {
        ...bookingPass,
        reviewScore: review?.reviewScore ?? null,
      }
    })

    return createPaginatedResponse({
      data,
      total,
      pagination: input.pagination,
    })
  }

  public async findHostPayments(
    input: HostPaymentsInput,
    { data: { select } }: PaginatedSelect<Prisma.BookingPassGroupSelect>,
    userDetails: JwtTokenPayload,
  ) {
    const hostPropertyOwnershipCondition = { property: { host: { userId: userDetails.id } } }
    const andCondition = [
      {
        AND: [
          {
            OR: [
              { space: hostPropertyOwnershipCondition },
              { dayPass: hostPropertyOwnershipCondition },
            ],
          },
        ],
      },
    ] as Prisma.BookingPassWhereInput[]

    if (input.date) {
      // TODO: check if need to include updated date/capture date
      const utcDate = new UTCDate(input.date)
      andCondition.push({
        OR: [{ createdAt: { gte: startOfDay(utcDate), lte: endOfDay(new Date()) } }],
      })
    }

    if (input.search) {
      andCondition.push({
        OR: [
          { guest: { user: { firstName: { contains: input.search || '', mode: 'insensitive' } } } },
          { guest: { user: { lastName: { contains: input.search || '', mode: 'insensitive' } } } },
          { confirmationNumber: { contains: input.search || '', mode: 'insensitive' } },
        ],
      })
    }

    const paymentStatusCondition: Prisma.BookingPassGroupWhereInput = {}
    if (input.status) {
      if (input.status === 'REFUNDED') {
        paymentStatusCondition.refunded = true
      } else {
        paymentStatusCondition.refunded = false
        paymentStatusCondition.paymentStatus = input.status
      }
    }

    const { orderBy, take, skip } = getPrismaPagination(input.pagination)

    const finalOrderBy: Prisma.BookingPassGroupOrderByWithRelationInput[] = [
      { refunded: 'asc' }, // refunded orders appear last
      ...(Array.isArray(orderBy) ? orderBy : [orderBy]),
    ]

    const where = { AND: andCondition }

    const [bookingGroups, total] = await this.prismaService.$transaction([
      this.prismaService.bookingPassGroup.findMany({
        where: {
          ...paymentStatusCondition,
          bookingPasses: {
            some: where, // Filter on related booking passes
          },
        },
        select: {
          ...select,
          bookingPasses: {
            include: {
              guest: {
                include: {
                  user: true,
                },
              },
            },
          },
        },
        take,
        skip,
        orderBy: input.pagination.sort === 'guest.user.firstName' ? undefined : finalOrderBy,
      }),
      this.prismaService.bookingPassGroup.count({
        where: {
          ...paymentStatusCondition,
          bookingPasses: {
            some: where,
          },
        },
      }),
    ])

    // workaround cause prisma doesn't support nested group sorting
    if (input.pagination.sort === 'guest.user.firstName') {
      bookingGroups.sort((a, b) => {
        return (
          (a.bookingPasses[0]?.guest?.user?.firstName ?? '').localeCompare(
            b.bookingPasses[0]?.guest?.user?.firstName ?? '',
          ) * (input.pagination.order === 'desc' ? -1 : 1)
        )
      })
    }

    return createPaginatedResponse({
      data: bookingGroups,
      total,
      pagination: input.pagination,
    })
  }

  public async checkIn(input: CheckInBookingInput, userDetails: JwtTokenPayload) {
    const isHostOwner = await this.isBookedVenueOwnedByHost(userDetails.id, input.id)

    if (!isHostOwner) {
      throw new UnauthorizedException(
        `Can't 'check in' the booking because current host is not the owner of this booking`,
      )
    }
    // Works only for space bookings
    const previouslyArrivedBooking = await this.prismaService.bookingPass.findFirst({
      where: {
        bookingStatus: BookingStatus.ARRIVED,
        OR: [
          { space: { bookingPasses: { some: { id: input.id } } } },
          { dayPass: { bookingPasses: { some: { id: input.id } } } },
        ],
      },
      select: {
        id: true,
        confirmationNumber: true,
        arrivalDate: true,
        departureDate: true,
        groupId: true,
        guest: { select: { userId: true } },
      },
    })

    // Move previously arrived booking status to DEPARTED, and a new booking status to ARRIVED
    if (previouslyArrivedBooking) {
      this.sendGuestRateExperienceNotification(previouslyArrivedBooking)

      await this.updateStatus(previouslyArrivedBooking.id, BookingStatus.DEPARTED)
    }

    await this.sendGuestCheckInConfirmationNotification(input.id)

    await this.updateStatus(input.id, BookingStatus.ARRIVED)
  }

  public async approve(input: ApproveBookingInput, userDetails: JwtTokenPayload) {
    const isHostOwner = await this.isBookedVenueOwnedByHost(userDetails.id, input.id)

    if (!isHostOwner) {
      throw new UnauthorizedException(
        `Can't approve the booking because current host is not the owner of this booking`,
      )
    }

    const bookingPass = await this.findUniqueBookingPass(input.id)

    if (!bookingPass) {
      throw new BadRequestException(`No booking pass found`)
    }

    await this.stripeCustomersService.submitBookingPayment({
      paymentIntentId: bookingPass.group?.paymentIntentId ?? '',
      confirmationNumbers: bookingPass.confirmationNumber,
      bookingEntityType: bookingPass.bookingEntityType,
      bookingGroupId: bookingPass.group?.id ?? '',
      userId: userDetails.id,
      basePrice: bookingPass.basePrice,
      totalBasePrice: bookingPass.basePrice,
      addressForTaxes: input.addressForTaxes,
      onPaymentFailure: async () => {
        await this.cancelPencilBookingOnPaymentFailure(bookingPass.group?.id ?? '')
      },
    })

    this.sendGuestBookingRequestApprovedNotification(bookingPass)

    await this.updateStatus(input.id, BookingStatus.CONFIRMED)
  }

  public async decline(input: DeclineBookingInput, userDetails: JwtTokenPayload) {
    const isHostOwner = await this.isBookedVenueOwnedByHost(userDetails.id, input.id)

    if (!isHostOwner) {
      throw new UnauthorizedException(
        `Can't approve the booking because current host is not the owner of this booking`,
      )
    }

    const bookingPass = await this.findUniqueBookingPass(input.id)

    if (!bookingPass) {
      throw new BadRequestException(`No booking pass found`)
    }

    this.sendGuestBookingRequestDeclinedNotification(bookingPass)

    await this.updateStatus(input.id, BookingStatus.CANCELED_BY_HOST)
  }

  public async updateStatus(
    id: string,
    newStatus: BookingStatus,
    cancelationReason?: string | null,
  ) {
    const bookingPass = await this.findUnique(
      { id },
      {
        bookingStatus: true,
        id: true,
        guestId: true,
        arrivalDate: true,
        groupId: true,
        rmsMapping: { select: { rmsId: true } },
      },
    )
    const isCancelationStatusTransition = [
      BookingStatus.CANCELED_BY_HOST,
      BookingStatus.CANCELED_BY_GUEST,
      BookingStatus.CANCELED_BY_SYSTEM,
    ].some((status) => status === newStatus)

    if (!bookingPass) {
      throw new BadRequestException('Booking pass not found')
    }

    const isBookingStatusTransitionAllowed = this.isStatusChangeAllowed(
      bookingPass.bookingStatus,
      newStatus,
    )

    if (!isBookingStatusTransitionAllowed) {
      throw new ConflictException(
        `Changing the booking status from ${bookingPass.bookingStatus} to ${newStatus} is not allowed`,
      )
    }

    if (isCancelationStatusTransition) {
      const isPencilStatus = [BookingStatus.PENCIL, BookingStatus.PENCIL_RTB].some(
        (status) => status === bookingPass.bookingStatus,
      )
      const isRefundAvailable = this.isWithinCancelationRefundTimeLimit(bookingPass.arrivalDate)
      const bookingPassGroup = await this.prismaService.bookingPass.findMany({
        where: { groupId: bookingPass.groupId },
        select: { id: true, bookingStatus: true, rmsMapping: { select: { rmsId: true } } },
      })

      if (!isRefundAvailable && !isPencilStatus && newStatus === BookingStatus.CANCELED_BY_HOST) {
        throw new ForbiddenException(
          `Guest bookings cannot be canceled within 48 hours of the booking's arrival date`,
        )
      }

      // Day pass group booking logic, update status to canceled for each booking pass in a group
      if (bookingPassGroup.length > 1) {
        const isBookingStatusChangeAllowedForAllGroupPasses = bookingPassGroup.every(
          (bookingPassInGroup) =>
            this.isStatusChangeAllowed(bookingPassInGroup.bookingStatus, newStatus),
        )

        if (!isBookingStatusChangeAllowedForAllGroupPasses) {
          throw new ConflictException(
            `Some bookings in the booking group ${bookingPass.groupId} have a status that does not allow cancellation`,
          )
        }

        await Promise.all(
          bookingPassGroup.map(async (bookingPassInGroup) => {
            await this.rmsCloudService.updateReservationStatus({
              reservationId: bookingPassInGroup.rmsMapping.rmsId,
              newStatus,
              cancelationNote: cancelationReason ? cancelationReason : undefined,
            })

            await this.prismaService.bookingPass.update({
              where: { id: bookingPassInGroup.id },
              data: { bookingStatus: newStatus },
            })
          }),
        )
      } else {
        await this.rmsCloudService.updateReservationStatus({
          reservationId: bookingPass.rmsMapping.rmsId,
          newStatus,
          cancelationNote: cancelationReason ? cancelationReason : undefined,
        })

        await this.prismaService.bookingPass.update({
          where: { id },
          data: { bookingStatus: newStatus },
        })
      }

      if (isRefundAvailable && !isPencilStatus) {
        // Stripe payment refund logic
        if (!bookingPass.groupId) {
          throw new BadRequestException("Can't find booking group id for refund")
        }

        const bookingGroup = await this.prismaService.bookingPassGroup.findUnique({
          where: { id: bookingPass.groupId },
        })

        if (!bookingGroup) {
          throw new BadRequestException("Can't find booking group for refund")
        }

        await this.stripeCustomersService.refund(bookingGroup)
      }

      if (newStatus === BookingStatus.CANCELED_BY_HOST) {
        if (bookingPass.guestId) {
          this.sendGuestBookingCanceledNotification(bookingPass.guestId, bookingPass)
        } else {
          this.logger.error(`Could not find guest for booking ${bookingPass.id}`)
        }
      }
    }

    await this.rmsCloudService.updateReservationStatus({
      reservationId: bookingPass.rmsMapping.rmsId,
      newStatus,
      cancelationNote: cancelationReason ? cancelationReason : undefined,
    })

    await this.prismaService.bookingPass.update({
      where: { id },
      data: { bookingStatus: newStatus },
    })
  }

  private async findUniqueBookingPass(bookingPassId: string) {
    return this.prismaService.bookingPass.findUnique({
      where: { id: bookingPassId },
      include: {
        guest: { select: { userId: true } },
        group: { select: { id: true, paymentIntentId: true } },
      },
    })
  }

  private async isBookedVenueOwnedByHost(userId: string, bookingPassId: string) {
    const host = await this.prismaService.host.findUnique({
      where: {
        userId,
        property: {
          OR: [
            { spaces: { some: { bookingPasses: { some: { id: bookingPassId } } } } },
            { dayPass: { bookingPasses: { some: { id: bookingPassId } } } },
          ],
        },
      },
      select: { id: true },
    })

    return Boolean(host)
  }

  private isStatusChangeAllowed(currentStatus: BookingStatus, newStatus: BookingStatus): boolean {
    return bookingStatusTransitions[currentStatus].includes(newStatus)
  }

  private isWithinCancelationRefundTimeLimit(arrivalDate: Date) {
    const now = new Date()
    const hoursDifference = differenceInHours(arrivalDate, now)

    return hoursDifference >= this.CANCELLATION_REFUND_TIME_LIMIT
  }

  private getBookingTimelineCondition(
    timeline: BookingTimeline,
    includeRTBBookingsInUpcoming = false,
  ) {
    const bookingStatusesAllowedInPastSection = [
      BookingStatus.CANCELED_BY_GUEST,
      BookingStatus.CANCELED_BY_HOST,
      BookingStatus.CANCELED_BY_SYSTEM,
      BookingStatus.NO_SHOW,
      BookingStatus.DEPARTED,
    ]
    const rtbBookingsCondition = {
      bookingStatus: { in: [BookingStatus.PENCIL_RTB] },
    } as Prisma.BookingPassWhereInput

    if (timeline === BookingTimeline.PAST) {
      return {
        OR: [
          {
            bookingStatus: {
              in: bookingStatusesAllowedInPastSection,
            },
          },
        ],
      } as Prisma.BookingPassWhereInput
    }

    if (timeline === BookingTimeline.PENDING) {
      return rtbBookingsCondition
    }

    return {
      OR: [
        {
          bookingStatus: { in: [BookingStatus.CONFIRMED, BookingStatus.ARRIVED] },
        },
        includeRTBBookingsInUpcoming ? { ...rtbBookingsCondition } : undefined,
      ].filter(Boolean),
    } as Prisma.BookingPassWhereInput
  }

  private async generateUniqueBookingConfirmationNumber(): Promise<string> {
    const nanoid = customAlphabet('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', 7)
    const firstNumber = customAlphabet('0123456789', 1) // Just to make booking confirmation number look good, we ensure there's a number after FL (FL4LA2389X)
    let confirmationNumber: string
    let confirmationNumberAlreadyExists: boolean
    let attempts = 0

    do {
      confirmationNumber = `${firstNumber()}${nanoid()}`

      if (attempts > 10) break

      const count = await this.prismaService.bookingPass.count({
        where: { confirmationNumber },
      })

      confirmationNumberAlreadyExists = count > 0
      attempts += 1
    } while (confirmationNumberAlreadyExists)

    return `FL${confirmationNumber}`
  }

  public async createBooking(
    input: CreateBookingInput,
    userDetails: JwtTokenPayload,
    select: Prisma.BookingPassSelect,
  ) {
    try {
      const guest = await this.prismaService.guest.findUnique({
        where: { userId: userDetails.id },
        select: {
          id: true,
          phoneNumber: true,
          user: {
            select: {
              firstName: true,
              lastName: true,
              email: true,
              rmsMapping: { select: { rmsId: true } },
            },
          },
        },
      })
      const hostOwner = await this.prismaService.host.findFirst({
        where: {
          property: {
            OR: [
              { spaces: { some: { id: input.fluxoAreaId } } },
              { dayPass: { id: input.fluxoAreaId } },
            ],
          },
        },
        select: { id: true, userId: true, status: true },
      })

      if (!hostOwner || isPropertyInactive(hostOwner)) {
        throw new ForbiddenException('The booking of paused or deactivated venue is not allowed')
      }

      if (!guest?.user.rmsMapping) {
        throw new BadRequestException("Can't find guest profile")
      }

      const utcArrivalDate = new UTCDate(input.arrivalDate)
      const utcDepartureDate = new UTCDate(input.departureDate)
      const expiryDate15MinutesFromNow = add(new UTCDate(), { minutes: 15 })
      const expiryDate24HoursFromNow = add(new UTCDate(), { hours: 24 })

      const bookingPassGroup = await this.prismaService.bookingPassGroup.create({
        data: {
          paymentIntentId: input.paymentIntentId,
          baseTotalPrice: input.basePrice,
        },
        select: { id: true },
      })
      const bookingArrivalDate =
        input.bookingEntityType === BookingEntityType.DAY_PASS
          ? startOfDay(utcArrivalDate)
          : utcArrivalDate
      const bookingDepartureDate =
        input.bookingEntityType === BookingEntityType.DAY_PASS
          ? endOfDay(utcDepartureDate)
          : utcDepartureDate
      const baseBookingPassData = {
        arrivalDate: bookingArrivalDate,
        departureDate: bookingDepartureDate,
        bookingEntityType: input.bookingEntityType,
        notes: input.notes,
        guest: { connect: { userId: userDetails.id } },
        dayPass:
          input.bookingEntityType === BookingEntityType.DAY_PASS
            ? { connect: { id: input.fluxoAreaId } }
            : undefined,
        space:
          input.bookingEntityType === BookingEntityType.SPACE
            ? { connect: { id: input.fluxoAreaId } }
            : undefined,
      } as Omit<
        Prisma.BookingPassCreateInput,
        'seats' | 'confirmationNumber' | 'basePrice' | 'rmsMapping'
      >
      const guestDetailsForRms = {
        guestId: Number(guest.user.rmsMapping.rmsId),
        guestGiven: guest.user.firstName,
        guestSurname: guest.user.lastName,
        guestEmail: guest.user.email,
        guestMobile: guest.phoneNumber ?? '',
      }

      // Day Pass booking
      if (input.bookingEntityType === BookingEntityType.DAY_PASS) {
        const bookingPasses = []
        const confirmationNumbers = []

        const dayPass = await this.prismaService.dayPass.findUnique({
          where: { id: input.fluxoAreaId },
          select: {
            rmsMappings: { select: { rmsCategoryId: true } },
            property: { select: { rmsMapping: { select: { rmsId: true } } } },
          },
        })

        if (dayPass?.rmsMappings.length === 0 || !dayPass?.property.rmsMapping) {
          throw new InternalServerErrorException('Could not find a RMS mappings')
        }

        const dayPassAreas = await this.rmsCloudService.availableAreas({
          categoryIds: [dayPass.rmsMappings[0].rmsCategoryId ?? 0],
          dateFrom: bookingArrivalDate.toISOString(),
          dateTo: bookingDepartureDate.toISOString(),
          propertyId: dayPass.property.rmsMapping.rmsId,
        })
        // Remove deleted day passes from that array
        let availableDayPassAreas = dayPassAreas.filter(
          (area) => !area.name.startsWith(this.rmsCloudService.DELETED_AREA_MARKER),
        )

        if (availableDayPassAreas.length < input.seats) {
          throw new BadRequestException(
            `Not enough day passes to book. Available: ${availableDayPassAreas.length}, requested: ${input.seats}`,
          )
        }

        let bookingPass = null

        for (let i = 0; i < input.seats; i++) {
          const randomAvailableDayPass = sample(availableDayPassAreas)

          const rmsReservation = await this.rmsCloudService.createPencilReservation({
            areaId: randomAvailableDayPass.id,
            categoryId: randomAvailableDayPass.categoryId,
            arrivalDate: this.rmsCloudService.formatToRMSDate(bookingArrivalDate),
            departureDate: this.rmsCloudService.formatToRMSDate(bookingDepartureDate),
            expiryDate: this.rmsCloudService.formatToRMSDate(expiryDate15MinutesFromNow),
            note: input.notes ?? '',
            ...guestDetailsForRms,
          })

          if (!rmsReservation.id) {
            throw new InternalServerErrorException('Could not create a pencil reservation in RMS')
          }

          const confirmationNumber = await this.generateUniqueBookingConfirmationNumber()

          confirmationNumbers.push(confirmationNumber)

          const newBookingPass = await this.prismaService.bookingPass.create({
            data: {
              ...baseBookingPassData,
              bookingStatus: BookingStatus.PENCIL,
              expiresAt: expiryDate15MinutesFromNow, // Expires in 15 minutes for non-RTB spaces and day passes
              basePrice: input.basePrice / input.seats,
              seats: 1,
              confirmationNumber,
              rmsDayPassId: randomAvailableDayPass.id,
              group: { connect: { id: bookingPassGroup.id } },
              rmsMapping: {
                create: {
                  rmsEntityType: RmsEntityType.RESERVATION,
                  rmsId: rmsReservation.id,
                  rmsCategoryId: rmsReservation.categoryId,
                },
              },
            },
            // TODO: test notifications after update or refactor to just select as Prisma.BookingPassSelect
            select: merge(select, {
              id: true,
              confirmationNumber: true,
              arrivalDate: true,
              departureDate: true,
              notes: true,
              bookingEntityType: true,
              bookingStatus: true,
              seats: true,
              basePrice: true,
              guestId: true,
              dayPassId: true,
              spaceId: true,
              groupId: true,
              group: {
                select: {
                  baseTotalPrice: true,
                  totalPrice: true,
                  fees: true,
                  taxes: true,
                  bookingFee: true,
                  transactionFee: true,
                },
              },
              space: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                  capacity: true,
                  hourlyCost: true,
                  dailyCost: true,
                  manualBookingApproval: true,
                  propertyId: true,
                  images: true,
                  property: {
                    select: {
                      id: true,
                      name: true,
                      logoUrl: true,
                      description: true,
                      score: true,
                      totalReviews: true,
                      wifiName: true,
                      wifiPassword: true,
                      hostId: true,
                      neighborhood: true,
                      heroImage: true,
                      location: {
                        select: {
                          address: true,
                        },
                      },
                      host: {
                        select: {
                          businessContact: true,
                        },
                      },
                    },
                  },
                },
              },
              dayPass: {
                select: {
                  id: true,
                  quantity: true,
                  dailyCost: true,
                  propertyId: true,
                  property: {
                    select: {
                      id: true,
                      name: true,
                      logoUrl: true,
                      description: true,
                      score: true,
                      totalReviews: true,
                      wifiName: true,
                      wifiPassword: true,
                      hostId: true,
                      neighborhood: true,
                      heroImage: true,
                      location: {
                        select: {
                          address: true,
                        },
                      },
                      host: {
                        select: {
                          businessContact: true,
                        },
                      },
                    },
                  },
                },
              },
              guest: {
                select: {
                  id: true,
                  userId: true,
                  profileImageUrl: true,
                  user: {
                    select: {
                      firstName: true,
                      lastName: true,
                    },
                  },
                },
              },
            }) as Prisma.BookingPassSelect,
          })

          if (i === 0) {
            bookingPass = newBookingPass
          }

          bookingPasses.push(newBookingPass)
          // Remove the available area that match the recently created reservation areaId
          availableDayPassAreas = availableDayPassAreas.filter(
            (area) => area.id !== rmsReservation.areaId,
          )
        }

        await this.stripeCustomersService.submitBookingPayment({
          paymentIntentId: input.paymentIntentId,
          confirmationNumbers: confirmationNumbers.join(', '),
          bookingEntityType: input.bookingEntityType,
          bookingGroupId: bookingPassGroup.id,
          userId: userDetails.id,
          basePrice: input.basePrice / input.seats,
          totalBasePrice: input.basePrice,
          addressForTaxes: input.addressForTaxes,
          onPaymentFailure: async () => {
            await this.cancelPencilBookingOnPaymentFailure(bookingPassGroup.id)
          },
        })


        if (bookingPass) {
          await this.sendHostBookingConfirmationNotification(bookingPass, hostOwner.id)
        }

        return bookingPasses
      }

      // Space booking
      const space = await this.prismaService.space.findUnique({
        where: { id: input.fluxoAreaId },
        select: {
          property: { select: { rmsMapping: { select: { rmsId: true } } } },
          rmsMapping: { select: { rmsId: true, rmsCategoryId: true } },
          manualBookingApproval: true,
        },
      })

      if (!space?.rmsMapping || !space.property.rmsMapping) {
        throw new InternalServerErrorException(
          `Can't find the RMS mapping for Space with id: ${input.fluxoAreaId}`,
        )
      }

      if (
        space.manualBookingApproval &&
        (isToday(bookingArrivalDate) || isTomorrow(bookingArrivalDate))
      ) {
        throw new ForbiddenException(
          'Booking RTB space with the arrival date set for today or tomorrow is not allowed',
        )
      }

      const spaceExpiryDate = space.manualBookingApproval
        ? expiryDate24HoursFromNow
        : expiryDate15MinutesFromNow

      const rmsReservation = await this.rmsCloudService.createPencilReservation({
        areaId: space.rmsMapping.rmsId,
        categoryId: space.rmsMapping.rmsCategoryId ?? 0,
        arrivalDate: this.rmsCloudService.formatToRMSDate(bookingArrivalDate),
        departureDate: this.rmsCloudService.formatToRMSDate(bookingDepartureDate),
        expiryDate: this.rmsCloudService.formatToRMSDate(spaceExpiryDate),
        note: input.notes ?? '',
        ...guestDetailsForRms,
      })

      if (!rmsReservation.id) {
        throw new InternalServerErrorException('Could not create a pencil reservation in RMS')
      }

      const confirmationNumber = await this.generateUniqueBookingConfirmationNumber()
      const newBookingPass = await this.prismaService.bookingPass.create({
        data: {
          ...baseBookingPassData,
          bookingStatus: space.manualBookingApproval
            ? BookingStatus.PENCIL_RTB
            : BookingStatus.PENCIL,
          expiresAt: spaceExpiryDate,
          basePrice: input.basePrice,
          seats: input.seats,
          group: { connect: { id: bookingPassGroup.id } },
          confirmationNumber,
          rmsMapping: {
            create: {
              rmsEntityType: RmsEntityType.RESERVATION,
              rmsId: rmsReservation.id,
              rmsCategoryId: rmsReservation.categoryId,
            },
          },
        },

        // TODO: test notifications after update or refactor to just select as Prisma.BookingPassSelect
        select: merge(select, {
          id: true,
          confirmationNumber: true,
          arrivalDate: true,
          departureDate: true,
          notes: true,
          bookingEntityType: true,
          bookingStatus: true,
          seats: true,
          basePrice: true,
          guestId: true,
          dayPassId: true,
          spaceId: true,
          groupId: true,
          group: {
            select: {
              baseTotalPrice: true,
              totalPrice: true,
              fees: true,
              taxes: true,
              bookingFee: true,
              transactionFee: true,
            },
          },
          space: {
            select: {
              id: true,
              name: true,
              description: true,
              capacity: true,
              hourlyCost: true,
              dailyCost: true,
              manualBookingApproval: true,
              propertyId: true,
              images: true,
              property: {
                select: {
                  id: true,
                  name: true,
                  logoUrl: true,
                  description: true,
                  score: true,
                  totalReviews: true,
                  wifiName: true,
                  wifiPassword: true,
                  hostId: true,
                  neighborhood: true,
                  heroImage: true,
                  location: {
                    select: {
                      address: true,
                    },
                  },
                  host: {
                    select: {
                      businessContact: true,
                    },
                  },
                },
              },
            },
          },
          dayPass: {
            select: {
              id: true,
              quantity: true,
              dailyCost: true,
              propertyId: true,
              property: {
                select: {
                  id: true,
                  name: true,
                  logoUrl: true,
                  description: true,
                  score: true,
                  totalReviews: true,
                  wifiName: true,
                  wifiPassword: true,
                  hostId: true,
                  neighborhood: true,
                  heroImage: true,
                  location: {
                    select: {
                      address: true,
                    },
                  },
                  host: {
                    select: {
                      businessContact: true,
                    },
                  },
                },
              },
            },
          },
          guest: {
            select: {
              id: true,
              userId: true,
              profileImageUrl: true,
              user: {
                select: {
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
        }) as Prisma.BookingPassSelect,
      })

      if (space.manualBookingApproval) {
        await this.sendHostBookingRequestNotification(
          hostOwner.userId,
          confirmationNumber,
          newBookingPass,
          newBookingPass.guestId,
        )
      } else {
        await this.stripeCustomersService.submitBookingPayment({
          paymentIntentId: input.paymentIntentId,
          confirmationNumbers: confirmationNumber,
          bookingEntityType: input.bookingEntityType,
          bookingGroupId: bookingPassGroup.id,
          userId: userDetails.id,
          basePrice: input.basePrice,
          totalBasePrice: input.basePrice,
          addressForTaxes: input.addressForTaxes,
          onPaymentFailure: async () => {
            await this.cancelPencilBookingOnPaymentFailure(bookingPassGroup.id)
          },
        })

        await this.sendHostBookingConfirmationNotification(newBookingPass, hostOwner.id)
      }

      return [newBookingPass]
    } catch (e) {
      this.logger.error(`Booking creation failed: ${e}`)
      throw e
    }
  }

  public async confirmPencilBooking(
    bookingGroupId?: string,
    bookingEntityType?: BookingEntityType,
  ): Promise<string> {
    if (!bookingGroupId || !bookingEntityType) {
      throw new InternalServerErrorException(
        'Could not get the booking group id or entity type from stripe payment webhook',
      )
    }

    const bookingPasses = await this.prismaService.bookingPass.findMany({
      where: {
        groupId: bookingGroupId,
        bookingStatus: { in: [BookingStatus.PENCIL, BookingStatus.PENCIL_RTB] },
      },
      select: {
        id: true,
        confirmationNumber: true,
        arrivalDate: true,
        departureDate: true,
        rmsMapping: true,
        seats: true,
        basePrice: true,
        dayPass: {
          select: {
            property: { select: { hostId: true, rmsMapping: { select: { rmsId: true } } } },
          },
        },
        space: {
          select: {
            manualBookingApproval: true,
            property: { select: { hostId: true, rmsMapping: { select: { rmsId: true } } } },
          },
        },
        guest: {
          select: {
            id: true,
            profileImageUrl: true,
            userId: true,
            user: { select: { id: true, email: true } },
          },
        },
        groupId: true,
      },
    })
    const bookingProperty =
      bookingEntityType === BookingEntityType.DAY_PASS
        ? bookingPasses[0]?.dayPass?.property
        : bookingPasses[0]?.space?.property
    const hostId = bookingProperty?.hostId

    if (bookingPasses.length === 0) {
      throw new NotFoundException('Booking not found')
    }

    let notificationSent = false

    for await (const bookingPass of bookingPasses) {
      await this.rmsCloudService.updateReservation({
        reservationId: bookingPass.rmsMapping.rmsId,
        rateTypeId: this.rmsCloudService.DEFAULT_RATE_TYPE_ID,
        userDefined5: `Contact: ${bookingPass.guest?.user.email}`,
        propertyId: bookingProperty?.rmsMapping?.rmsId,
        adults: bookingPass.seats,
      })

      await this.updateStatus(bookingPass.id, BookingStatus.CONFIRMED)

      await this.prismaService.bookingPass.update({
        where: { id: bookingPass.id },
        data: { expiresAt: null },
      })

      if (!notificationSent) {
        this.sendGuestBookingConfirmationNotification(bookingPass)
        notificationSent = true
      }
    }

    return hostId ?? ''
  }

  private sendGuestBookingRequestApprovedNotification(booking: {
    id: string
    departureDate: Date
    arrivalDate: Date
    guest: { userId: string } | null
    confirmationNumber: string
    group: { id: string } | null
  }) {
    if (booking.guest?.userId) {
      // Trigger Guest Notification -> Booking Request Approved
      this.eventEmitter.emit(
        Events.GUEST_BOOKING_REQUEST_APPROVED,
        new GuestBookingRequestApprovedEvent(
          booking.guest.userId,
          booking.id,
          booking.confirmationNumber,
          booking.group?.id ?? '',
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking ${booking.id}`)
    }
  }

  private sendGuestBookingRequestDeclinedNotification(booking: {
    id: string
    departureDate: Date
    arrivalDate: Date
    guest: { userId: string } | null
    confirmationNumber: string
    group: { id: string } | null
  }) {
    if (booking.guest?.userId) {
      // Trigger Guest Notification -> Booking Request Declined
      this.eventEmitter.emit(
        Events.GUEST_BOOKING_REQUEST_DECLINED,
        new GuestBookingRequestDeclinedEvent(
          booking.guest.userId,
          booking.id,
          booking.confirmationNumber,
          booking.group?.id ?? '',
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking ${booking.id}`)
    }
  }

  private async sendGuestCheckInConfirmationNotification(bookingPassId: string) {
    const bookingPass = await this.prismaService.bookingPass.findUnique({
      where: { id: bookingPassId },
      select: {
        id: true,
        confirmationNumber: true,
        groupId: true,
        guest: {
          select: {
            userId: true,
          },
        },
      },
    })

    if (bookingPass?.guest?.userId) {
      // Trigger Guest Notification -> Check In Confirmation

      this.eventEmitter.emit(
        Events.GUEST_CHECKED_IN,
        new GuestCheckedInEvent(
          bookingPass.guest.userId,
          bookingPass.id,
          bookingPass.confirmationNumber,
          bookingPass.groupId,
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking pass ID: ${bookingPassId}`)
    }
  }

  private async sendHostBookingRequestNotification(
    userId: string,
    confirmationNumber: string,
    booking: {
      id: string
      departureDate: Date
      arrivalDate: Date
      bookingStatus: BookingStatus
      confirmationNumber: string
      groupId: string | null
    },
    guestId: string | null,
  ) {
    // Trigger Host Notification -> Booking Request

    if (!guestId) {
      this.logger.error(`Could not find guest for booking ${booking.id}`)
      return
    }

    const guest = await this.prismaService.guest.findUnique({
      where: { id: guestId },
      select: {
        id: true,
        profileImageUrl: true,
        user: {
          select: {
            id: true,
          },
        },
      },
    })

    if (guest) {
      this.eventEmitter.emit(
        Events.HOST_BOOKING_REQUEST,
        new HostBookingRequestEvent(
          userId,
          booking.id,
          confirmationNumber,
          booking.groupId,
          guest.id,
          guest.profileImageUrl,
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking ${booking.id}`)
    }
  }

  private sendHostBookingCanceledNotification(
    userId: string,
    bookingPass: {
      id: string
      departureDate: Date
      arrivalDate: Date
      bookingStatus: BookingStatus
      guest: { userId: string } | null
      confirmationNumber: string
      groupId: string | null
    },
    guest: { id: string; profileImageUrl: string | null },
  ) {
    // Trigger Host Notification -> Booking Cancellation
    this.eventEmitter.emit(
      Events.HOST_BOOKING_CANCELED,
      new HostBookingCancellationEvent(
        userId,
        bookingPass.id,
        bookingPass.confirmationNumber,
        bookingPass.groupId,
        guest.id,
        guest.profileImageUrl,
      ),
    )
  }

  private sendGuestBookingCanceledNotification(
    guestId: string,
    bookingPass: {
      id: string
      departureDate: Date
      arrivalDate: Date
      bookingStatus: BookingStatus
      guest: { userId: string } | null
      confirmationNumber: string
      groupId: string | null
    },
  ) {
    // Trigger Guest Notification -> Booking Cancellation
    this.eventEmitter.emit(
      Events.GUEST_BOOKING_CANCELED,
      new GuestBookingCancellationEvent(
        guestId,
        bookingPass.id,
        bookingPass.confirmationNumber,
        bookingPass.groupId,
      ),
    )
  }

  private sendGuestRateExperienceNotification(booking: {
    id: string
    departureDate: Date
    arrivalDate: Date
    guest: { userId: string } | null
    confirmationNumber: string
    groupId: string | null
  }) {
    if (booking.guest?.userId) {
      // Trigger Guest Notification -> Rate Experience
      this.eventEmitter.emit(
        Events.GUEST_CHECKED_OUT,
        new GuestCheckedOutEvent(
          booking.guest.userId,
          booking.id,
          booking.confirmationNumber,
          booking.groupId,
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking ${booking.id}`)
    }
  }

  private async sendHostBookingConfirmationNotification(
    bookingPass: {
      id: string
      departureDate: Date
      arrivalDate: Date
      guest: { id: string; profileImageUrl: string | null } | null
      confirmationNumber: string
      groupId: string | null
    },
    hostId?: string | null,
  ) {
    if (hostId) {
      const host = await this.prismaService.host.findUnique({
        select: { userId: true },
        where: { id: hostId },
      })

      if (host) {
        // Trigger Host Notification -> Booking Confirmation
        this.eventEmitter.emit(
          Events.HOST_BOOKING_CONFIRMED,
          new HostBookingConfirmationEvent(
            host.userId,
            bookingPass.id,
            bookingPass.confirmationNumber,
            bookingPass.groupId,
            bookingPass.guest?.id,
            bookingPass.guest?.profileImageUrl,
          ),
        )
      } else {
        this.logger.error(`Could not find host for booking ${bookingPass.id}`)
      }
    } else {
      this.logger.error(`Could not find host ID for booking ${bookingPass.id}`)
    }
  }

  private sendGuestBookingConfirmationNotification(bookingPass: {
    id: string
    departureDate: Date
    arrivalDate: Date
    guest: { id: string; userId: string; profileImageUrl: string | null } | null
    confirmationNumber: string
    groupId: string | null
  }) {
    if (bookingPass.guest?.id) {
      // Trigger Guest Notification -> Booking Confirmation
      this.eventEmitter.emit(
        Events.GUEST_BOOKING_CONFIRMED,
        new GuestBookingConfirmationEvent(
          bookingPass.guest.userId,
          bookingPass.id,
          bookingPass.confirmationNumber,
          bookingPass.groupId,
        ),
      )
    } else {
      this.logger.error(`Could not find guest for booking ${bookingPass.id}`)
    }
  }

  private async findHostUserIdByBookingPass(bookingPass: {
    id: string
    bookingEntityType: BookingEntityType
    dayPassId: string | null
    spaceId: string | null
    departureDate: Date
    arrivalDate: Date
    bookingStatus: BookingStatus
    guest: { userId: string } | null
    confirmationNumber: string
    groupId: string | null
  }) {
    if (bookingPass.bookingEntityType === BookingEntityType.DAY_PASS && bookingPass.dayPassId) {
      const dayPass = await this.prismaService.dayPass.findUnique({
        where: {
          id: bookingPass.dayPassId,
        },
        select: {
          id: true,
          property: {
            select: {
              host: {
                select: {
                  userId: true,
                },
              },
            },
          },
        },
      })

      return dayPass?.property.host?.userId
    }

    if (bookingPass.spaceId) {
      const space = await this.prismaService.space.findUnique({
        where: {
          id: bookingPass.spaceId,
        },
        select: {
          id: true,
          property: {
            select: {
              host: {
                select: {
                  userId: true,
                },
              },
            },
          },
        },
      })

      return space?.property.host?.userId
    }

    return null
  }

  async bookingsStatistics() {
    const now = new Date()
    const oneYearAgo = subYears(now, 1)

    return this.prismaService.$queryRaw`
        SELECT to_char(created_at, 'YYYY-MM') AS month,
      COUNT(*)::INTEGER AS count
        FROM "BookingPassGroup"
        WHERE created_at BETWEEN ${oneYearAgo}
          AND ${now}
        GROUP BY to_char(created_at, 'YYYY-MM')
        ORDER BY to_char(created_at, 'YYYY-MM') ASC;
    `
  }
}
