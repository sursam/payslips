import { Field, ObjectType, registerEnumType } from '@nestjs/graphql'
import { PaymentStatus } from '@prisma/client'
import { IsEnum, IsNotEmpty } from 'class-validator'

registerEnumType(PaymentStatus, {
  name: 'PaymentStatus',
})

@ObjectType()
export class BookingGroupEntity {
  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  baseTotalPrice: number

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  totalPrice: number

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  fees: number

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  bookingFee: number

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  transactionFee: number

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  taxes: number

  @IsNotEmpty()
  @Field(() => Boolean, { nullable: true })
  refunded: boolean

  @IsNotEmpty()
  @Field(() => Number, { nullable: true })
  refundedAmount: number

  @IsNotEmpty()
  @IsEnum(PaymentStatus)
  @Field(() => PaymentStatus)
  paymentStatus: PaymentStatus
}
