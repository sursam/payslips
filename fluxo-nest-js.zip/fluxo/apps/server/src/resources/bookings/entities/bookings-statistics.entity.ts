import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@ObjectType()
export class BookingsStatisticsEntity {
  @IsNotEmpty()
  @Field(() => String)
  month: string

  @IsNotEmpty()
  @Field(() => Number)
  count: number
}
