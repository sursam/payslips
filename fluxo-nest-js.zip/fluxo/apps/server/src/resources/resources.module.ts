import { Module } from '@nestjs/common'

import { AuthModule } from '@/resources/auth/auth.module'
import { AvailabilityModule } from '@/resources/availability/availability.module'
import { BookingsModule } from '@/resources/bookings/bookings.module'
import { GuestsModule } from '@/resources/guests/guests.module'
import { HostsModule } from '@/resources/hosts/hosts.module'
import { ImagesModule } from '@/resources/images/images.module'
import { NotificationsModule } from '@/resources/notifications/notifications.module'
import { PropertiesModule } from '@/resources/properties/properties.module'
import { UsersModule } from '@/resources/users/users.module'
import { CouponsModule } from './coupons/coupons.module';

@Module({
  imports: [
    AuthModule,
    UsersModule,
    GuestsModule,
    HostsModule,
    PropertiesModule,
    ImagesModule,
    BookingsModule,
    NotificationsModule,
    AvailabilityModule,
    CouponsModule,
  ],
})
export class ResourcesModule {}
