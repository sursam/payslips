import { Module } from '@nestjs/common'

import { AWSModule } from '@/common/services/integrations/aws/aws.module'
import { PresignedUrlResolver } from '@/resources/images/presigned-url.resolver'

@Module({
  providers: [PresignedUrlResolver],
  imports: [AWSModule],
  exports: [],
})
export class ImagesModule {}
