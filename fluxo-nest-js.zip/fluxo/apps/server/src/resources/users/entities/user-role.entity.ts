import { ObjectType, PickType } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { UserInterface } from '@/resources/users/interfaces/user.interface'

@ObjectType()
export class UserRoleEntity extends PickType(UserInterface, ['role'], ObjectType) {
  role: UserRole
}
