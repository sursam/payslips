import { type Guest, type RmsMapping, type User } from '@prisma/client'

export class GuestProfileChangedEvent {
  public guest

  constructor(guest: Guest & { user: User & { rmsMapping: RmsMapping | null } }) {
    this.guest = guest
  }
}
