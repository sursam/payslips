import { BadRequestException, Injectable } from '@nestjs/common'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { Prisma } from '@prisma/client'
import { merge, omit } from 'es-toolkit'

import { Events } from '@/common/enums'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { CreateGuestProfileInput } from '@/resources/guests/dto/create-guest-profile.input'
import { UpdateGuestProfileInput } from '@/resources/guests/dto/update-guest-profile.input'
import { GuestUserEntity } from '@/resources/guests/entities/guest-user.entity'
import { GuestAccountDeactivatedEvent } from '@/resources/guests/events/guest-account-deactivated.event'
import { GuestProfileChangedEvent } from '@/resources/guests/events/guest-profile-changed.event'
import { LocationInput } from '@/resources/properties/dto/location.input'
import { LocationsService } from '@/resources/properties/locations.service'

@Injectable()
export class GuestsService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    private readonly locationService: LocationsService,
    private readonly stripeCustomersService: StripeCustomersService,
  ) {}

  public async upsert(user: GuestUserEntity, input: CreateGuestProfileInput): Promise<void> {
    const { location, ...guestData } = omit(input, ['firstName', 'lastName'])
    const isProfileCreatedNow = !user.guest
    const upsertResult = await this.prismaService.guest.upsert({
      where: { userId: user.id },
      create: merge(
        { user: { connect: { id: user.id } } },
        { ...(guestData as Omit<Prisma.GuestCreateInput, 'user'>) },
      ),
      update: guestData,
      include: {
        user: { include: { guest: true, rmsMapping: true } },
      },
    })

    await this.updateLocation(upsertResult.id, location)

    // Create the contact only when the user creates the profile for the first time
    if (isProfileCreatedNow) {
      await this.stripeCustomersService.createCustomerAccount({ user: upsertResult.user })

      this.eventEmitter.emit(
        Events.GUEST_PROFILE_CREATED,
        new GuestProfileChangedEvent(upsertResult),
      )
    }
  }

  public async updateProfile(userId: string, input: UpdateGuestProfileInput): Promise<void> {
    const { location, ...guestInput } = omit(input, ['firstName', 'lastName'])

    const updatedProfile = await this.prismaService.guest.update({
      where: { userId },
      data: guestInput,
      include: { user: { include: { rmsMapping: true } } },
    })

    await this.updateLocation(updatedProfile.id, location)

    this.eventEmitter.emit(
      Events.GUEST_PROFILE_UPDATED,
      new GuestProfileChangedEvent(updatedProfile),
    )
  }

  public async findUnique(args: Prisma.GuestFindUniqueArgs) {
    return this.prismaService.guest.findUnique(args)
  }

  private async updateLocation(guestId: string, location?: LocationInput): Promise<void> {
    try {
      await this.prismaService.location.delete({ where: { guestId } })
    } catch {
      /* If the location doesn't exist that's fine */
    }

    if (location) await this.locationService.create(location, { guestId }, this.prismaService)
  }

  public async deactivateAccount(userDetails: JwtTokenPayload): Promise<void> {
    const userCount = await this.prismaService.user.count({
      where: { id: userDetails.id },
    })

    if (userCount === 0) {
      throw new BadRequestException('User not found')
    }

    this.eventEmitter.emit(
      Events.GUEST_ACCOUNT_DEACTIVATED,
      new GuestAccountDeactivatedEvent(userDetails.id, userDetails.email),
    )

    await this.prismaService.user.delete({ where: { id: userDetails.id } })
  }
}
