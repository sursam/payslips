import { Field, InputType, OmitType, PartialType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { LocationInput } from '@/resources/properties/dto/location.input'

import { GuestEntity } from '../entities/guest.entity'

@InputType()
export class UpdateGuestProfileInput extends PartialType(
  OmitType(GuestEntity, ['id', 'userId', 'location'], InputType),
) {
  @IsOptional()
  @Field({ nullable: true })
  firstName: string

  @IsOptional()
  @Field({ nullable: true })
  lastName: string

  @IsOptional()
  @Field(() => LocationInput, { nullable: true })
  location: LocationInput
}
