import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { Guest } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

@InterfaceType()
export class GuestInterface implements Guest {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  userId: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  bio: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  profileImageUrl: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  phoneNumber: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  phoneNumberCountry: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  jobTitle: string | null

  @IsOptional()
  @Field(() => Date, { nullable: true })
  dateOfBirth: Date | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  speaks: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  pronouns: string | null
}
