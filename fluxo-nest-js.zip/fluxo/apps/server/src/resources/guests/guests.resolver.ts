import { BadRequestException, UseGuards } from '@nestjs/common'
import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql'
import { Prisma, UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { RequestedFieldsDecorator } from '@/common/decorators/requested-fields.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenPayload, JwtTokenService } from '@/common/services/jwt-token/jwt-token.service'
import { CreateGuestProfileInput } from '@/resources/guests/dto/create-guest-profile.input'
import { UpdateGuestProfileInput } from '@/resources/guests/dto/update-guest-profile.input'
import { GuestEntity } from '@/resources/guests/entities/guest.entity'
import { GuestUserEntity } from '@/resources/guests/entities/guest-user.entity'
import { GuestsService } from '@/resources/guests/guests.service'
import { UsersService } from '@/resources/users/users.service'

@Roles(UserRole.GUEST)
@UseGuards(JwtAuthGuard, RolesGuard)
@Resolver(() => GuestEntity)
export class GuestsResolver {
  constructor(
    private readonly guestsService: GuestsService,
    private readonly usersService: UsersService,
    private readonly jwtTokenService: JwtTokenService,
  ) {}

  @Query(() => GuestUserEntity)
  @ErrorGraphqlHandlingDecorator(GuestsResolver.name)
  guest(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @RequestedFieldsDecorator() select: Prisma.UserSelect,
  ): Promise<GuestUserEntity | null> {
    return this.usersService.findUnique(userDetails.email, select)
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(GuestsResolver.name)
  async createGuestProfile(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: CreateGuestProfileInput,
  ): Promise<MessageInterfaceEntity> {
    const user = await this.usersService.findUnique(userDetails.email, {
      role: true,
      guest: true,
      id: true,
    })

    if (!user) {
      throw new BadRequestException(`Can't find a user`)
    }

    await this.usersService.update({
      where: { id: user.id },
      data: { firstName: input.firstName, lastName: input.lastName },
    })
    await this.guestsService.upsert(user, input)

    return { message: 'Guest profile is created' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(GuestsResolver.name)
  async updateGuestProfile(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: UpdateGuestProfileInput,
  ): Promise<MessageInterfaceEntity> {
    const user = await this.usersService.findUnique(userDetails.email, {
      role: true,
      guest: true,
      id: true,
    })

    if (!user) {
      throw new BadRequestException(`Can't find a user`)
    }

    await this.usersService.update({
      where: { id: user.id },
      data: { firstName: input.firstName, lastName: input.lastName },
    })
    await this.guestsService.updateProfile(user.id, input)

    return { message: 'Guest profile is updated' }
  }

  @Mutation(() => MessageInterfaceEntity)
  @ErrorGraphqlHandlingDecorator(GuestsResolver.name)
  async deactivateGuestAccount(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Context() ctx: ContextServer,
  ): Promise<MessageInterfaceEntity> {
    await this.guestsService.deactivateAccount(userDetails)

    this.jwtTokenService.clearTokenFromCookie(ctx.res)

    return { message: 'Guest account is deactivated' }
  }
}
