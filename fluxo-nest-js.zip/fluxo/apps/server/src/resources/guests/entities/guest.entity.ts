import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { GuestInterface } from '@/resources/guests/interfaces/guest.interface'
import { LocationEntity } from '@/resources/properties/entities/location.entity'
import { UserEntity } from '@/resources/users/entities/user.entity'

@ObjectType({
  implements: () => [GuestInterface],
})
export class GuestEntity extends GuestInterface {
  @IsOptional()
  @Field(() => LocationEntity, { nullable: true })
  location?: LocationEntity | null
}

@ObjectType()
export class GuestEntityWithUser extends GuestEntity {
  @IsOptional()
  @Field(() => UserEntity)
  user: UserEntity
}
