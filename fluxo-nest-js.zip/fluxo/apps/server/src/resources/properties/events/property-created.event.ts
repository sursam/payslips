import { type Prisma } from '@prisma/client'

export class PropertyCreatedEvent {
  public property
  public email

  constructor(
    property: Prisma.PropertyGetPayload<{
      include: { attributes: true }
    }>,
    email: string,
  ) {
    this.property = property
    this.email = email
  }
}
