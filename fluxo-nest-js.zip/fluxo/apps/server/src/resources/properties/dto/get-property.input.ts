import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { PropertyEntity } from '@/resources/properties/entities/property.entity'

@InputType()
export class GetPropertyInput extends PickType(PropertyEntity, ['id'], InputType) {
  @IsOptional()
  @Field({ nullable: true })
  coordinates: string
}
