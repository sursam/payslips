import { Field, InputType } from '@nestjs/graphql'
import { AttributeType } from '@prisma/client'
import { IsOptional } from 'class-validator'

@InputType()
export class AttributesInput {
  @IsOptional()
  @Field(() => [AttributeType], { nullable: true })
  type?: AttributeType[]
}
