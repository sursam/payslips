import { Field, ID, InputType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { DayPassInput } from '@/resources/properties/dto/day-pass.input'
import { LocationInput } from '@/resources/properties/dto/location.input'
import { SpacesInput } from '@/resources/properties/dto/spaces.input'
import { PropertyEntity } from '@/resources/properties/entities/property.entity'

@InputType()
export class CreatePropertyInput extends PickType(
  PropertyEntity,
  [
    'logoUrl',
    'neighborhood',
    'unlistedDays',
    'wifiPassword',
    'wifiName',
    'description',
    'name',
    'images',
    'heroImage',
  ],
  InputType,
) {
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput])
  availability: AvailabilityInput[]

  @IsOptional()
  @Field(() => [ID], { nullable: true })
  attributeIds?: string[] | null

  @IsOptional()
  @Field(() => DayPassInput, { nullable: true })
  dayPass?: DayPassInput | null

  @IsOptional()
  @Field(() => [SpacesInput], { nullable: true })
  spaces?: SpacesInput[] | null

  @IsOptional()
  @Field(() => LocationInput, { nullable: true })
  location?: LocationInput | null
}
