import { Field, ID, InputType, PartialType, PickType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityInput } from '@/resources/properties/dto/availability.input'
import { LocationWithLatLngInput } from '@/resources/properties/dto/location.input'
import { PropertyEntity } from '@/resources/properties/entities/property.entity'

@InputType()
export class UpdatePropertyInput extends PartialType(
  PickType(
    PropertyEntity,
    [
      'logoUrl',
      'neighborhood',
      'unlistedDays',
      'wifiPassword',
      'wifiName',
      'description',
      'name',
      'images',
      'heroImage',
    ],
    InputType,
  ),
) {
  @IsNotEmpty()
  @Field(() => ID)
  propertyId: string

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityInput)
  @Field(() => [AvailabilityInput], { nullable: true })
  availability?: AvailabilityInput[]

  @IsOptional()
  @Field(() => [ID], { nullable: true })
  attributeIds?: string[] | null

  @IsOptional()
  @Field(() => LocationWithLatLngInput, { nullable: true })
  location?: LocationWithLatLngInput | null
}
