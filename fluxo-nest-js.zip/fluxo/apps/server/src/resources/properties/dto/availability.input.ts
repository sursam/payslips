import { InputType, PickType } from '@nestjs/graphql'

import { AvailabilityEntity } from '@/resources/properties/entities/availability.entity'

@InputType()
export class AvailabilityInput extends PickType(
  AvailabilityEntity,
  ['dayOfWeek', 'from', 'to'],
  InputType,
) {}
