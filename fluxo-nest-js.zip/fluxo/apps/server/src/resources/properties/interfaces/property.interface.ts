import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { Property } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

@InterfaceType()
export abstract class PropertyInterface implements Omit<Property, 'rmsMappingId'> {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  name: string

  @IsNotEmpty()
  @Field()
  createdAt: Date

  @IsNotEmpty()
  @Field()
  updatedAt: Date

  @IsNotEmpty()
  @Field()
  logoUrl: string

  @IsNotEmpty()
  @Field()
  description: string

  @IsNotEmpty()
  @Field()
  wifiName: string

  @IsNotEmpty()
  @Field()
  wifiPassword: string

  @IsNotEmpty()
  @Field(() => ID, { nullable: true })
  hostId: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  neighborhood: string | null

  @IsOptional()
  @Field(() => [Date])
  unlistedDays: Date[]

  @IsOptional()
  @Field(() => [String], { nullable: true })
  images: string[]

  @IsNotEmpty()
  @Field()
  heroImage: string

  @IsNotEmpty()
  @Field()
  score: number

  @IsNotEmpty()
  @Field()
  totalReviews: number
}
