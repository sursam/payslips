import { Field, ID, InterfaceType, registerEnumType } from '@nestjs/graphql'
import { Attribute, AttributeType } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

registerEnumType(AttributeType, {
  name: 'AttributeType',
})

@InterfaceType()
export abstract class AttributeInterface implements Omit<Attribute, 'rmsMappingId'> {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  name: string

  @IsOptional()
  @Field(() => Boolean, { nullable: true })
  standard: boolean | null

  @IsNotEmpty()
  @Field(() => AttributeType)
  type: AttributeType

  @IsOptional()
  @Field(() => String, { nullable: true })
  iconUrl: string | null
}
