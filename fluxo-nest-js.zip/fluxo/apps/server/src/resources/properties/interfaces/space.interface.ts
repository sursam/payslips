import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { Space } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

@InterfaceType()
export abstract class SpaceInterface
  implements Omit<Space, 'rmsMappingId' | 'createdAt' | 'updatedAt'>
{
  @IsNotEmpty()
  @Field()
  id: string

  @IsNotEmpty()
  @Field()
  name: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  description: string | null

  @IsNotEmpty()
  @Field()
  capacity: number

  @IsNotEmpty()
  @Field()
  hourlyCost: number

  @IsOptional()
  @Field(() => Number, { nullable: true })
  dailyCost: number | null

  @IsNotEmpty()
  @Field()
  manualBookingApproval: boolean

  @IsNotEmpty()
  @Field(() => ID)
  propertyId: string

  @IsOptional()
  @Field(() => [String], { nullable: true, defaultValue: [] })
  images: string[]
}
