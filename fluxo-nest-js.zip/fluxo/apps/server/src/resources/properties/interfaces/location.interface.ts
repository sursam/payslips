import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { Location } from '@prisma/client'
import { IsNotEmpty, IsOptional } from 'class-validator'

@InterfaceType()
export abstract class LocationInterface implements Location {
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  address: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  propertyId: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  guestId: string | null

  @IsOptional()
  @Field(() => String, { nullable: true })
  hostId: string | null
}
