import { Field, ID, InterfaceType } from '@nestjs/graphql'
import { DayPass } from '@prisma/client'
import { IsNotEmpty } from 'class-validator'

@InterfaceType()
export abstract class DayPassInterface
  implements Omit<DayPass, 'rmsMappingId' | 'createdAt' | 'updatedAt'>
{
  @IsNotEmpty()
  @Field(() => ID)
  id: string

  @IsNotEmpty()
  @Field()
  quantity: number

  @IsNotEmpty()
  @Field()
  dailyCost: number

  @IsNotEmpty()
  @Field()
  propertyId: string
}
