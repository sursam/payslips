import {
  BadRequestException,
  Controller,
  Get,
  Logger,
  OnModuleInit,
  Query,
  UnauthorizedException,
} from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { EventEmitter2 } from '@nestjs/event-emitter'

import { AppConfig } from '@/common/config/configuration'
import { Events } from '@/common/enums'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { PropertyCreatedEvent } from '@/resources/properties/events/property-created.event'

@Controller('property')
export class PropertyIntegrationsSyncController {
  private readonly logger = new Logger(PropertyIntegrationsSyncController.name)

  constructor(
    private readonly eventEmitter: EventEmitter2,
    private readonly prismaService: PrismaService,
    private readonly configService: ConfigService<AppConfig>,
  ) {}

  @Get('integrations-sync')
  async syncRmsProperty(
    @Query('propertyId') propertyId: string,
    @Query('rmsClientPassword') rmsClientPassword: string,
  ): Promise<void> {
    try {
      // We compare the rms password from the request with rms password in env variables for additional security protection
      if (
        this.configService.get('rmsCloud.authCredentials.clientPassword', { infer: true }) !==
        rmsClientPassword
      ) {
        throw new UnauthorizedException('Wrong RMS client password')
      }

      this.logger.debug(`Manually sending PROPERTY_CREATED event for property: ${propertyId}`)

      const property = await this.prismaService.property.findUniqueOrThrow({
        where: { id: propertyId },
        include: { attributes: true, host: { include: { user: true } } },
      })

      if (!property.host?.user.email) {
        throw new BadRequestException('Host email not found')
      }

      this.eventEmitter.emit(
        Events.PROPERTY_CREATED,
        new PropertyCreatedEvent(property, property.host.user.email),
      )
    } catch (e) {
      this.logger.error(e)
    }
  }
}
