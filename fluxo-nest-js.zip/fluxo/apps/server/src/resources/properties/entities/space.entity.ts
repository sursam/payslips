import { Field, ObjectType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AttributeEntity } from '@/resources/properties/entities/attribute.entity'
import { AvailabilityEntity } from '@/resources/properties/entities/availability.entity'
import { PropertyWithHostEntity } from '@/resources/properties/entities/property.entity'
import { UnlistedTimeEntity } from '@/resources/properties/entities/unlisted-time.entity'
import { SpaceInterface } from '@/resources/properties/interfaces/space.interface'

@ObjectType({
  implements: () => [SpaceInterface],
})
export class SpaceEntity extends SpaceInterface {
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityEntity)
  @Field(() => [AvailabilityEntity], { nullable: true })
  availability: AvailabilityEntity[] | null

  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => UnlistedTimeEntity)
  @Field(() => [UnlistedTimeEntity], { nullable: true })
  unlistedTime: UnlistedTimeEntity[] | null

  @IsOptional()
  @Field(() => [AttributeEntity], { nullable: true })
  attributes: AttributeEntity[] | null
}

@ObjectType()
export class SpaceEntityWithProperty extends SpaceEntity {
  @IsNotEmpty()
  @Field(() => PropertyWithHostEntity)
  property: PropertyWithHostEntity
}
