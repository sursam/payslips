import { ObjectType } from '@nestjs/graphql'

import { AttributeInterface } from '@/resources/properties/interfaces/attribute.interface'

@ObjectType({
  implements: () => [AttributeInterface],
})
export class AttributeEntity extends AttributeInterface {}
