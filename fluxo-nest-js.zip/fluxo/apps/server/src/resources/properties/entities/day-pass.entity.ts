import { Field, ObjectType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, IsOptional, ValidateNested } from 'class-validator'

import { AvailabilityEntity } from '@/resources/properties/entities/availability.entity'
import { PropertyWithHostEntity } from '@/resources/properties/entities/property.entity'
import { DayPassInterface } from '@/resources/properties/interfaces/day-pass.interface'

@ObjectType({
  implements: () => [DayPassInterface],
})
export class DayPassEntity extends DayPassInterface {
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AvailabilityEntity)
  @Field(() => [AvailabilityEntity], { nullable: true })
  availability: AvailabilityEntity[] | null
}

@ObjectType()
export class DayPassEntityWithProperty extends DayPassEntity {
  @IsNotEmpty()
  @Field(() => PropertyWithHostEntity)
  property: PropertyWithHostEntity
}
