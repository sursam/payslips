import { ObjectType } from '@nestjs/graphql'

import { UnlistedTimeInterface } from '@/resources/properties/interfaces/unlisted-time.interface'

@ObjectType({
  implements: () => [UnlistedTimeInterface],
})
export class UnlistedTimeEntity extends UnlistedTimeInterface {}
