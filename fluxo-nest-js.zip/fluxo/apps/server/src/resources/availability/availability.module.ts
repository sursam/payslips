import { Module } from '@nestjs/common'

import { RmsCloudModule } from '@/common/services/integrations/rms-cloud/rms-cloud.module'
import { AvailabilityResolver } from '@/resources/availability/availability.resolver'
import { AvailabilityService } from '@/resources/availability/availability.service'

@Module({
  imports: [RmsCloudModule],
  providers: [AvailabilityService, AvailabilityResolver],
  exports: [AvailabilityService],
})
export class AvailabilityModule {}
