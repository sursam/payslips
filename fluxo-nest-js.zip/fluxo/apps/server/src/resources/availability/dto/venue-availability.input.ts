import { Field, ID, InputType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@InputType()
export class VenueAvailabilityInput {
  @IsNotEmpty()
  @Field(() => ID)
  propertyId: string

  @IsNotEmpty()
  @Field(() => Date)
  date: Date
}
