import { Field, ObjectType } from '@nestjs/graphql'

import { TimeSlotInterface } from '@/resources/availability/interfaces/time-slot.interface'

@ObjectType({
  implements: () => [TimeSlotInterface],
})
export class TimeSlotWithAvailabilityEntity extends TimeSlotInterface {
  @Field()
  available: boolean
}
