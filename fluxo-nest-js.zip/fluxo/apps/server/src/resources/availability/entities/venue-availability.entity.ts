import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@ObjectType()
export class VenueAvailabilityEntity {
  @IsNotEmpty()
  @Field()
  availableDayPasses: number

  @IsNotEmpty()
  @Field(() => [String])
  availableSpacesIds: string[]
}
