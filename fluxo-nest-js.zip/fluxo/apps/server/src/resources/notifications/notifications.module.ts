import { Module } from '@nestjs/common'

import { ExpoPushModule } from '@/common/services/integrations/expo-push/expo-push.module'
import { HostsModule } from '@/resources/hosts/hosts.module'
import { NotificationsGateway } from '@/resources/notifications/notifications.gateway'
import { NotificationsResolver } from '@/resources/notifications/notifications.resolver'
import { NotificationsService } from '@/resources/notifications/notifications.service'
import { ReviewsModule } from '@/resources/reviews/reviews.module'

@Module({
  imports: [ExpoPushModule, HostsModule, ReviewsModule],
  providers: [NotificationsResolver, NotificationsService, NotificationsGateway],
  exports: [NotificationsService],
})
export class NotificationsModule {}
