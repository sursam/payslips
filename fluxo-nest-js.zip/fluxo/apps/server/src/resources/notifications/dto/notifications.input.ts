import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

import { PaginationInterfaceInput } from '@/common/interfaces/pagination.inteface'

@InputType()
export class NotificationsInput extends PickType(
  PaginationInterfaceInput,
  ['pagination'],
  InputType,
) {
  @IsOptional()
  @Field(() => Boolean, { nullable: true })
  readonly isRead?: boolean
}
