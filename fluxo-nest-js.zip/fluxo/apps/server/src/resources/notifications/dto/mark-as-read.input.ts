import { Field, InputType } from '@nestjs/graphql'
import { IsArray, IsNotEmpty } from 'class-validator'

@InputType()
export class MarkAsReadInput {
  @IsNotEmpty()
  @Field(() => [String])
  @IsArray()
  notificationIds: string[]
}
