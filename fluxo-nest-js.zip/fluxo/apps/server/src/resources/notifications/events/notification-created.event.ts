import { type NotificationEntity } from '@/resources/notifications/entities/notification.entity'

export class NotificationCreatedEvent {
  public notification

  constructor(notification: NotificationEntity) {
    this.notification = notification
  }
}
