import { HostBookingEvent } from '@/resources/notifications/events/host-booking.event'

export class HostBookingConfirmationEvent extends HostBookingEvent {}
