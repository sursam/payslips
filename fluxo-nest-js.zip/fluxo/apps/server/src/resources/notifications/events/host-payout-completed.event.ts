export class HostPayoutCompletedEvent {
  public userId: string

  constructor(userId: string) {
    this.userId = userId
  }
}
