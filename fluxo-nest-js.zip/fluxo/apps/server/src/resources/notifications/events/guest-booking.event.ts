export class GuestBookingEvent {
  public userId: string
  public bookingPassId: string
  public bookingConfirmationNumber: string
  public bookingTimeline: string
  public groupId: string | null

  constructor(
    userId: string,
    bookingPassId: string,
    bookingConfirmationNumber: string,
    groupId: string | null,
  ) {
    this.userId = userId
    this.bookingPassId = bookingPassId
    this.bookingConfirmationNumber = bookingConfirmationNumber
    this.groupId = groupId
  }
}
