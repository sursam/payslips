import { GuestBookingEvent } from '@/resources/notifications/events/guest-booking.event'

export class GuestBookingConfirmationEvent extends GuestBookingEvent {}
