import { UTCDate } from '@date-fns/utc'
import { Injectable, Logger } from '@nestjs/common'
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter'
import { Cron, CronExpression } from '@nestjs/schedule'
import {
  BookingEntityType,
  BookingStatus,
  NotificationType,
  Prisma,
  UserRole,
} from '@prisma/client'
import { delay } from 'es-toolkit'

import { Events } from '@/common/enums'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { TotalInterface } from '@/common/interfaces/total.interface'
import {
  createPaginatedResponse,
  getPrismaPagination,
  PaginatedSelect,
} from '@/common/pagination-utils'
import { ExpoPushService } from '@/common/services/integrations/expo-push/expo-push.service'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { HostAccountPausedEvent } from '@/resources/hosts/events/host-account-paused.event'
import { HostsService } from '@/resources/hosts/hosts.service'
import { MarkAsReadInput } from '@/resources/notifications/dto/mark-as-read.input'
import { NotificationsInput } from '@/resources/notifications/dto/notifications.input'
import { NotificationEntity } from '@/resources/notifications/entities/notification.entity'
import { GuestBookingCancellationEvent } from '@/resources/notifications/events/guest-booking-cancellation.event'
import { GuestBookingConfirmationEvent } from '@/resources/notifications/events/guest-booking-confirmation.event'
import { GuestBookingRequestApprovedEvent } from '@/resources/notifications/events/guest-booking-request-approved.event'
import { GuestBookingRequestDeclinedEvent } from '@/resources/notifications/events/guest-booking-request-declined.event'
import { GuestCheckedInEvent } from '@/resources/notifications/events/guest-checked-in.event'
import { GuestCheckedOutEvent } from '@/resources/notifications/events/guest-checked-out.event'
import { HostBookingCancellationEvent } from '@/resources/notifications/events/host-booking-cancellation.event'
import { HostBookingConfirmationEvent } from '@/resources/notifications/events/host-booking-confirmation.event'
import { HostBookingRequestEvent } from '@/resources/notifications/events/host-booking-request.event'
import { HostPayoutCompletedEvent } from '@/resources/notifications/events/host-payout-completed.event'
import { HostStripeStatusChangedEvent } from '@/resources/notifications/events/host-stripe-status-changed.event'
import { NotificationCreatedEvent } from '@/resources/notifications/events/notification-created.event'
import { NotificationsGateway } from '@/resources/notifications/notifications.gateway'
import { ReviewsService } from '@/resources/reviews/reviews.service'

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name)

  constructor(
    private readonly prismaService: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    private readonly notificationsGateway: NotificationsGateway,
    private readonly expoPush: ExpoPushService,
    private readonly hostsService: HostsService,
    private readonly reviewsService: ReviewsService,
  ) {}

  public async create(data: Prisma.NotificationUncheckedCreateInput): Promise<NotificationEntity> {
    const notification = await this.prismaService.notification.create({
      data,
    })

    this.eventEmitter.emit(Events.NOTIFICATION_CREATED, new NotificationCreatedEvent(notification))

    return notification
  }

  public async markAsRead({
    input,
    userDetails,
  }: {
    input: MarkAsReadInput
    userDetails: JwtTokenPayload
  }): Promise<MessageInterfaceEntity> {
    const where =
      userDetails.role === UserRole.HOST
        ? {
            host: { userId: userDetails.id },
            id: { in: input.notificationIds },
          }
        : {
            guest: { userId: userDetails.id },
            id: { in: input.notificationIds },
          }

    await this.prismaService.notification.updateMany({
      where,
      data: { isRead: true },
    })

    return { message: 'ok' }
  }

  public async markAllAsRead({
    userDetails,
  }: {
    userDetails: JwtTokenPayload
  }): Promise<MessageInterfaceEntity> {
    const where =
      userDetails.role === UserRole.HOST
        ? {
            host: { userId: userDetails.id },
          }
        : {
            guest: { userId: userDetails.id },
          }

    await this.prismaService.notification.updateMany({
      where,
      data: { isRead: true },
    })

    return { message: 'ok' }
  }

  public async findMany(
    input: NotificationsInput,
    userDetails: JwtTokenPayload,
    { data: { select } }: PaginatedSelect<Prisma.NotificationSelect>,
  ) {
    const { orderBy, take, skip } = getPrismaPagination(input.pagination)
    const where = {
      isRead: input.isRead,
      OR: [{ host: { userId: userDetails.id } }, { guest: { userId: userDetails.id } }],
    } as Prisma.NotificationWhereInput

    const [data, total] = await this.prismaService.$transaction([
      this.prismaService.notification.findMany({
        where,
        select,
        take,
        skip,
        orderBy,
      }),
      this.prismaService.notification.count({ where }),
    ])

    return createPaginatedResponse({
      data,
      total,
      pagination: input.pagination,
    })
  }

  public async findCount(userDetails: JwtTokenPayload): Promise<TotalInterface> {
    return {
      total: await this.prismaService.notification.count({
        where: {
          isRead: false,
          OR: [{ host: { userId: userDetails.id } }, { guest: { userId: userDetails.id } }],
        },
      }),
    }
  }

  @OnEvent(Events.NOTIFICATION_CREATED)
  private async sendNotification(notificationEvent: NotificationCreatedEvent) {
    this.notificationsGateway.sendAsync(notificationEvent.notification)

    if (notificationEvent.notification.expoPushToken) {
      await this.expoPush.sendAsync(
        notificationEvent.notification.expoPushToken,
        notificationEvent.notification.message,
        JSON.stringify(notificationEvent.notification),
        notificationEvent.notification.title,
      )
    }
  }

  /** Host notifications **/

  @OnEvent(Events.HOST_BOOKING_CONFIRMED)
  private async createHostBookingConfirmationNotification(event: HostBookingConfirmationEvent) {
    await this.createHostBookingNotification(event, Events.HOST_BOOKING_CONFIRMED)
  }

  @OnEvent(Events.HOST_BOOKING_REQUEST)
  private async createHostBookingRequestNotification(event: HostBookingRequestEvent) {
    await this.createHostBookingNotification(event, Events.HOST_BOOKING_REQUEST)
  }

  @OnEvent(Events.HOST_BOOKING_CANCELED)
  private async createHostBookingCancellationNotification(event: HostBookingCancellationEvent) {
    await this.createHostBookingNotification(event, Events.HOST_BOOKING_CANCELED)
  }

  @OnEvent(Events.HOST_PAYOUT_COMPLETED)
  private async createHostPayoutCompletedNotification(event: HostPayoutCompletedEvent) {
    const host = await this.findHost(event.userId)

    if (!host) {
      this.logger.log(`Host with userId ${event.userId} not found.`)

      return
    }

    const userName = `${host.user.firstName} ${host.user.lastName}`
    const { message, htmlMessage, title, type } = this.getEventDetails(Events.HOST_PAYOUT_COMPLETED)

    await this.create({
      recipientRole: UserRole.HOST,
      type,
      title,
      message,
      htmlMessage,
      metadata: {
        customer_name: userName,
      },
      isRead: false,
      guestId: null,
      hostId: host.id,
      expoPushToken: host.user.expoPushToken ?? '',
    })
  }

  @OnEvent(Events.HOST_STRIPE_STATUS_CHANGED)
  private async createHostStripeStatusChangedNotification(event: HostStripeStatusChangedEvent) {
    const host = await this.findHost(event.userId)

    if (!host) {
      this.logger.log(`Host with userId ${event.userId} not found.`)

      return
    }

    const userName = `${host.user.firstName} ${host.user.lastName}`
    const { message, htmlMessage, title, type } = this.getEventDetails(
      Events.HOST_STRIPE_STATUS_CHANGED,
    )

    await this.create({
      recipientRole: UserRole.HOST,
      type,
      title,
      message,
      htmlMessage,
      metadata: {
        customer_name: userName,
        kyc_status: event.kycStatus,
      },
      isRead: false,
      guestId: null,
      hostId: host.id,
      expoPushToken: host.user.expoPushToken ?? '',
    })
  }

  @OnEvent(Events.HOST_ACCOUNT_PAUSED)
  private async createHostAccountPausedNotification(event: HostAccountPausedEvent) {
    const { message, htmlMessage, title, type } = this.getEventDetails(Events.HOST_ACCOUNT_PAUSED)

    const host = await this.findHost(event.userId)

    if (!host) {
      this.logger.log(`Host with user ID ${event.userId} not found.`)

      return
    }

    await this.create({
      recipientRole: UserRole.HOST,
      type,
      title,
      message,
      htmlMessage,
      isRead: false,
      guestId: null,
      hostId: host.id,
      expoPushToken: host.user.expoPushToken ?? '',
    })
  }

  @Cron(CronExpression.EVERY_DAY_AT_7PM, { timeZone: 'America/New_York' })
  private async createTomorrowsBookingNotifications() {
    const nowUTC = new Date()
    const tomorrowUTC = new Date(nowUTC)
    tomorrowUTC.setDate(nowUTC.getDate() + 1)

    const startOfTomorrowUTC = new Date(
      Date.UTC(
        tomorrowUTC.getUTCFullYear(),
        tomorrowUTC.getUTCMonth(),
        tomorrowUTC.getUTCDate(),
        0,
        0,
        0,
        0,
      ),
    )

    const endOfTomorrowUTC = new Date(
      Date.UTC(
        tomorrowUTC.getUTCFullYear(),
        tomorrowUTC.getUTCMonth(),
        tomorrowUTC.getUTCDate(),
        23,
        59,
        59,
        999,
      ),
    )

    const baseBookingPassWhere = {
      guest: { isNot: null },
    } as Prisma.BookingPassWhereInput

    // Fetch bookings that are scheduled for tomorrow in EST
    const bookings = await this.prismaService.bookingPass.findMany({
      where: {
        ...baseBookingPassWhere,
        arrivalDate: { gte: startOfTomorrowUTC, lt: endOfTomorrowUTC },
        departureDate: { gt: startOfTomorrowUTC, lte: endOfTomorrowUTC },
        bookingStatus: BookingStatus.CONFIRMED,
      },
      select: {
        id: true,
        bookingStatus: true,
        bookingEntityType: true,
        dayPassId: true,
        dayPass: { select: { property: { select: { id: true, hostId: true } } } },
        spaceId: true,
        space: { select: { property: { select: { id: true, hostId: true } } } },
      },
    })

    // Create a map to store the number of bookings per host
    const hostBookingsCounts: Record<string, number> = {}

    // Count the number of bookings for each host
    for (const booking of bookings) {
      if (booking.bookingEntityType === BookingEntityType.DAY_PASS) {
        if (booking.dayPass?.property.hostId) {
          hostBookingsCounts[booking.dayPass.property.hostId] =
            (hostBookingsCounts[booking.dayPass.property.hostId] ?? 0) + 1
        }
      } else if (booking.space?.property.hostId) {
        hostBookingsCounts[booking.space.property.hostId] =
          (hostBookingsCounts[booking.space.property.hostId] ?? 0) + 1
      }
    }

    // Notify each host about their confirmed bookings for tomorrow
    for await (const [hostId, hostBookingsCount] of Object.entries(hostBookingsCounts)) {
      const host = await this.prismaService.host.findUnique({
        where: { id: hostId },
        select: { user: true },
      })

      if (!host) {
        this.logger.log(`Host with ID ${hostId} not found.`)
        continue
      }

      await this.create({
        recipientRole: UserRole.HOST,
        type: NotificationType.HOST_TOMORROWS_BOOKINGS,
        title: "Tomorrow's Bookings",
        message: `You have ${hostBookingsCount} bookings confirmed for tomorrow!`,
        htmlMessage: `You have <b>${hostBookingsCount}</b> bookings confirmed for tomorrow!`,
        metadata: {
          bookings_count: hostBookingsCount,
        },
        isRead: false,
        guestId: null,
        hostId,
        expoPushToken: host.user.expoPushToken ?? '',
      })
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_8AM, { timeZone: 'America/Los_Angeles' })
  private async createNewReviewsNotifications() {
    const now = new UTCDate()
    const yesterday = new UTCDate(now)

    yesterday.setDate(now.getDate() - 1)

    const reviews = await this.reviewsService.findReviewsSinceDate(yesterday)
    const uniqueHostIds = new Set<string>()

    for await (const review of reviews) {
      const propertyId = review.sku

      const property = await this.prismaService.property.findUnique({
        where: { id: propertyId },
        select: {
          id: true,
          hostId: true,
        },
      })

      if (!property) {
        this.logger.log(`Property with ID ${propertyId} not found.`)
      } else if (property.hostId) {
        uniqueHostIds.add(property.hostId)
      }
    }

    for (const hostId of uniqueHostIds) {
      const host = await this.prismaService.host.findFirstOrThrow({
        where: { id: hostId },
        select: { user: true },
      })

      await this.create({
        recipientRole: UserRole.HOST,
        type: NotificationType.HOST_NEW_REVIEW,
        title: 'New Reviews',
        message: 'You received new reviews yesterday!',
        htmlMessage: 'You received new reviews yesterday!',
        isRead: false,
        guestId: null,
        hostId,
        expoPushToken: host.user.expoPushToken ?? '',
      })
    }
  }

  /** /Host notifications **/

  /** Guest notifications **/

  @OnEvent(Events.GUEST_BOOKING_CONFIRMED)
  private async createGuestBookingConfirmationNotification(event: GuestBookingConfirmationEvent) {
    await this.createGuestBookingNotification(event, Events.GUEST_BOOKING_CONFIRMED)
  }

  @OnEvent(Events.GUEST_BOOKING_REQUEST_APPROVED)
  private async createGuestBookingRequestApprovedNotification(
    event: GuestBookingRequestApprovedEvent,
  ) {
    await this.createGuestBookingNotification(event, Events.GUEST_BOOKING_REQUEST_APPROVED)
  }

  @OnEvent(Events.GUEST_BOOKING_REQUEST_DECLINED)
  private async createGuestBookingRequestDeclinedNotification(
    event: GuestBookingRequestDeclinedEvent,
  ) {
    await this.createGuestBookingNotification(event, Events.GUEST_BOOKING_REQUEST_DECLINED)
  }

  @OnEvent(Events.GUEST_BOOKING_CANCELED)
  private async createGuestBookingCancellationNotification(event: GuestBookingCancellationEvent) {
    await this.createGuestBookingNotification(event, Events.GUEST_BOOKING_CANCELED)
  }

  @OnEvent(Events.GUEST_CHECKED_IN)
  private async createGuestCheckedInNotification(event: GuestCheckedInEvent) {
    await this.createGuestBookingNotification(event, Events.GUEST_CHECKED_IN)
  }

  @OnEvent(Events.GUEST_CHECKED_OUT)
  private async createGuestCheckedOutNotification(event: GuestCheckedOutEvent) {
    // Only when 15 minutes have passed since booking checking out, we should send this notification
    await delay(15 * 60 * 1000)

    await this.createGuestBookingNotification(event, Events.GUEST_CHECKED_OUT)
  }

  @Cron(CronExpression.EVERY_DAY_AT_7PM, { timeZone: 'America/New_York' })
  private async createBookingReminderNightBeforeNotifications() {
    const nowUTC = new Date()
    const tomorrowUTC = new Date(nowUTC)
    tomorrowUTC.setDate(nowUTC.getDate() + 1)

    const startOfTomorrowUTC = new Date(
      Date.UTC(
        tomorrowUTC.getUTCFullYear(),
        tomorrowUTC.getUTCMonth(),
        tomorrowUTC.getUTCDate(),
        0,
        0,
        0,
        0,
      ),
    )

    const endOfTomorrowUTC = new Date(
      Date.UTC(
        tomorrowUTC.getUTCFullYear(),
        tomorrowUTC.getUTCMonth(),
        tomorrowUTC.getUTCDate(),
        23,
        59,
        59,
        999,
      ),
    )

    const baseBookingPassWhere = {
      guest: { isNot: null },
    } as Prisma.BookingPassWhereInput

    const bookings = await this.prismaService.bookingPass.findMany({
      where: {
        ...baseBookingPassWhere,
        arrivalDate: { gte: startOfTomorrowUTC, lt: endOfTomorrowUTC },
        departureDate: { gt: startOfTomorrowUTC, lte: endOfTomorrowUTC },
        bookingStatus: BookingStatus.CONFIRMED,
      },
      select: {
        id: true,
        bookingStatus: true,
        bookingEntityType: true,
        confirmationNumber: true,
        departureDate: true,
        arrivalDate: true,
        guestId: true,
        groupId: true,
        dayPassId: true,
        dayPass: { select: { property: { select: { hostId: true } } } },
        spaceId: true,
        space: { select: { property: { select: { id: true, hostId: true } } } },
      },
    })

    const uniqueGroupBookings = bookings.reduce<Record<string, (typeof bookings)[0]>>(
      (acc, booking) => {
        if (booking.guestId) {
          acc[booking.guestId] = booking
        }
        return acc
      },
      {},
    )

    const guests: string[] = []

    for (const booking of Object.values(uniqueGroupBookings)) {
      if (booking.guestId && !guests.includes(booking.guestId)) {
        const { venueName, propertyId, venueLogoUrl } = await this.getVenueInfo(booking.id)
        const guest = await this.prismaService.guest.findUnique({
          where: { id: booking.guestId },
          select: { user: true },
        })

        if (!guest) {
          this.logger.log(`Guest with ID ${booking.guestId} not found.`)

          continue
        }

        await this.create({
          recipientRole: UserRole.GUEST,
          type: NotificationType.GUEST_BOOKING_REMINDER_NIGHT_BEFORE,
          title: 'Booking Reminder',
          message: `Enjoy your workday tomorrow at ${venueName}!`,
          htmlMessage: `Enjoy your workday tomorrow at <b>${venueName}!</b>`,
          metadata: {
            venue_name: venueName,
            venue_logo_url: venueLogoUrl,
            booking_pass_id: booking.id,
            booking_confirmation_number: booking.confirmationNumber,
            property_id: propertyId,
            group_id: booking.groupId,
            arrival_date: booking.arrivalDate,
            departure_date: booking.departureDate,
          },
          isRead: false,
          guestId: booking.guestId,
          hostId: null,
          expoPushToken: guest.user.expoPushToken ?? '',
        })

        guests.push(booking.guestId)
      }
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_8AM, { timeZone: 'America/New_York' })
  private async createBookingReminderDayOfNotifications() {
    const nowUTC = new Date()

    const startOfTodayUTC = new Date(
      Date.UTC(nowUTC.getUTCFullYear(), nowUTC.getUTCMonth(), nowUTC.getUTCDate(), 0, 0, 0, 0),
    )

    const endOfTodayUTC = new Date(
      Date.UTC(nowUTC.getUTCFullYear(), nowUTC.getUTCMonth(), nowUTC.getUTCDate(), 23, 59, 59, 999),
    )

    const baseBookingPassWhere = {
      guest: { isNot: null },
    } as Prisma.BookingPassWhereInput

    const bookings = await this.prismaService.bookingPass.findMany({
      where: {
        ...baseBookingPassWhere,
        arrivalDate: { gte: startOfTodayUTC, lt: endOfTodayUTC },
        departureDate: { gt: startOfTodayUTC, lte: endOfTodayUTC },
        bookingStatus: BookingStatus.CONFIRMED,
      },
      select: {
        id: true,
        bookingStatus: true,
        bookingEntityType: true,
        confirmationNumber: true,
        departureDate: true,
        arrivalDate: true,
        guestId: true,
        groupId: true,
        dayPassId: true,
        dayPass: { select: { property: { select: { hostId: true } } } },
        spaceId: true,
        space: { select: { property: { select: { id: true, hostId: true } } } },
      },
    })

    const uniqueGroupBookings = bookings.reduce<Record<string, (typeof bookings)[0]>>(
      (acc, booking) => {
        if (booking.guestId) {
          acc[booking.guestId] = booking
        }
        return acc
      },
      {},
    )

    const guests: string[] = []

    for (const booking of Object.values(uniqueGroupBookings)) {
      if (booking.guestId && !guests.includes(booking.guestId)) {
        const { venueName, propertyId, venueLogoUrl } = await this.getVenueInfo(booking.id)
        const guest = await this.prismaService.guest.findUnique({
          where: { id: booking.guestId },
          select: { user: true },
        })

        if (!guest) {
          this.logger.log(`Guest with ID ${booking.guestId} not found.`)
          continue
        }

        await this.create({
          recipientRole: UserRole.GUEST,
          type: NotificationType.GUEST_BOOKING_REMINDER_DAY_OF,
          title: 'Booking Reminder',
          message: `See you soon! Have your pass ready for check in!`,
          htmlMessage: `See you soon! Have your pass ready for check in!`,
          metadata: {
            venue_name: venueName,
            venue_logo_url: venueLogoUrl,
            booking_pass_id: booking.id,
            booking_confirmation_number: booking.confirmationNumber,
            property_id: propertyId,
            group_id: booking.groupId,
            arrival_date: booking.arrivalDate,
            departure_date: booking.departureDate,
          },
          isRead: false,
          guestId: booking.guestId,
          hostId: null,
          expoPushToken: guest.user.expoPushToken ?? '',
        })

        guests.push(booking.guestId)
      }
    }
  }

  /** /Guest notifications **/

  private async findHost(userId: string) {
    return await this.hostsService.findUnique(
      { userId },
      {
        id: true,
        user: {
          select: {
            firstName: true,
            lastName: true,
            expoPushToken: true,
          },
        },
      },
    )
  }

  private async findGuest(userId: string) {
    return this.prismaService.guest.findUnique({
      where: { userId },
      select: {
        id: true,
        user: {
          select: {
            firstName: true,
            lastName: true,
            expoPushToken: true,
          },
        },
      },
    })
  }

  private async findGuestById(guestId: string) {
    return this.prismaService.guest.findUnique({
      where: { id: guestId },
      select: {
        id: true,
        user: {
          select: {
            firstName: true,
            lastName: true,
            expoPushToken: true,
          },
        },
      },
    })
  }

  private async findBookingPass(bookingPassId: string) {
    return this.prismaService.bookingPass.findUnique({
      where: { id: bookingPassId },
      select: {
        spaceId: true,
        dayPassId: true,
      },
    })
  }

  private async findSpace(spaceId: string) {
    return this.prismaService.space.findUnique({
      where: { id: spaceId },
      select: {
        property: {
          select: {
            id: true,
            name: true,
            logoUrl: true,
          },
        },
      },
    })
  }

  private async findDayPass(dayPassId: string) {
    return this.prismaService.dayPass.findUnique({
      where: { id: dayPassId },
      select: {
        property: {
          select: {
            id: true,
            name: true,
            logoUrl: true,
          },
        },
      },
    })
  }

  private async getVenueInfo(bookingPassId: string) {
    let venueName = ''
    let space = null
    let dayPass = null
    let propertyId = null
    let venueLogoUrl = null

    const bookingPass = await this.findBookingPass(bookingPassId)

    if (!bookingPass) {
      this.logger.log(`Booking Pass with ID ${bookingPassId} not found.`)

      return { venueName, space, propertyId, venueLogoUrl }
    }

    if (bookingPass.spaceId) {
      space = await this.findSpace(bookingPass.spaceId)

      if (space) {
        venueName = space.property.name
        propertyId = space.property.id
        venueLogoUrl = space.property.logoUrl
      }
    } else {
      if (!bookingPass.dayPassId) {
        this.logger.log(`Booking Pass with ID ${bookingPassId} does not have a space or day pass.`)

        return { venueName, space, propertyId, venueLogoUrl }
      }

      dayPass = await this.findDayPass(bookingPass.dayPassId)

      if (dayPass) {
        venueName = dayPass.property.name
        propertyId = dayPass.property.id
        venueLogoUrl = dayPass.property.logoUrl
      }
    }

    return { venueName, space, propertyId, venueLogoUrl }
  }

  private async createHostBookingNotification(
    event: HostBookingCancellationEvent | HostBookingRequestEvent | HostBookingConfirmationEvent,
    eventType: Events,
  ) {
    const host = await this.findHost(event.userId)

    if (!host) {
      this.logger.log(`Host with userId ${event.userId} not found.`)

      return
    }

    if (!event.guestId) {
      this.logger.log(`Host booking confirmation event does not have a guestId.`)
      return
    }

    const guest = await this.findGuestById(event.guestId)

    if (!guest) {
      this.logger.log(`Guest with userId ${event.guestId} not found.`)
      return
    }

    const userName = `${guest.user.firstName} ${guest.user.lastName}`

    const { venueName, space, propertyId, venueLogoUrl } = await this.getVenueInfo(
      event.bookingPassId,
    )

    if (venueName) {
      const { message, htmlMessage, title, type } = this.getEventDetails(
        eventType,
        venueName,
        Boolean(space),
        userName,
      )

      await this.create({
        recipientRole: UserRole.HOST,
        type,
        title,
        message,
        htmlMessage,
        metadata: {
          customer_name: userName,
          venue_name: venueName,
          venue_logo_url: venueLogoUrl,
          booking_pass_id: event.bookingPassId,
          booking_confirmation_number: event.bookingConfirmationNumber,
          property_id: propertyId,
          group_id: event.groupId,
          guest_id: event.guestId,
          guest_logo: event.guestLogo,
        },
        isRead: false,
        guestId: null,
        hostId: host.id,
        expoPushToken: host.user.expoPushToken ?? '',
      })
    }
  }

  private async guestCheckedOutEventValidation(
    guestId: string,
    propertyId: string,
    eventType: Events,
  ) {
    if (eventType !== Events.GUEST_CHECKED_OUT) {
      return true
    }

    const isBookingReviewAlreadyExist = await this.prismaService.bookingReview.findFirst({
      where: {
        guestId,
        propertyId,
      },
    })

    return !isBookingReviewAlreadyExist
  }

  private async createGuestBookingNotification(
    event:
      | GuestBookingConfirmationEvent
      | GuestBookingRequestApprovedEvent
      | GuestBookingRequestDeclinedEvent
      | GuestBookingCancellationEvent
      | GuestCheckedInEvent
      | GuestCheckedOutEvent,
    eventType: Events,
  ) {
    const guest = await this.findGuest(event.userId)

    if (!guest) {
      this.logger.log(`Guest with userId ${event.userId} not found.`)

      return
    }

    const userName = `${guest.user.firstName} ${guest.user.lastName}`
    const { venueName, space, propertyId, venueLogoUrl } = await this.getVenueInfo(
      event.bookingPassId,
    )

    if (!(await this.guestCheckedOutEventValidation(guest.id, propertyId!, eventType))) {
      this.logger.log(`[propertyId: ${propertyId}]: Guest already left review for ${venueName}`)

      return
    }

    if (venueName) {
      const { message, htmlMessage, title, type } = this.getEventDetails(
        eventType,
        venueName,
        Boolean(space),
        userName,
      )

      let skip = false

      if (eventType === Events.GUEST_CHECKED_OUT) {
        const today = new Date()
        today.setHours(0, 0, 0, 0)

        // Check existing notification
        const existingNotification = await this.prismaService.notification.findFirst({
          where: {
            type,
            title,
            message,
            createdAt: {
              gte: today,
            },
            guestId: guest.id,
          },
          select: {
            id: true,
          },
        })

        if (existingNotification) {
          skip = true
        }
      }

      if (!skip) {
        await this.create({
          recipientRole: UserRole.GUEST,
          type,
          title,
          message,
          htmlMessage,
          metadata: {
            customer_name: userName,
            venue_name: venueName,
            venue_logo_url: venueLogoUrl,
            booking_pass_id: event.bookingPassId,
            booking_confirmation_number: event.bookingConfirmationNumber,
            property_id: propertyId,
            group_id: event.groupId,
          },
          isRead: false,
          guestId: guest.id,
          hostId: null,
          expoPushToken: guest.user.expoPushToken ?? '',
        })
      }
    }
  }

  private getEventDetails(
    eventType: Events,
    venueName?: string,
    space?: boolean,
    userName?: string,
  ): {
    message: string
    htmlMessage: string
    title: string
    type: NotificationType
  } {
    switch (eventType) {
      case Events.HOST_BOOKING_CONFIRMED:
        return {
          message: `${userName} has booked a ${space ? 'space' : 'day pass'} at ${venueName}!`,
          htmlMessage: `<b>${userName}</b> has booked a ${space ? 'space' : 'day pass'} at <b>${venueName}</b>!`,
          title: 'Booking Confirmation',
          type: NotificationType.HOST_BOOKING_CONFIRMATION,
        }
      case Events.HOST_BOOKING_REQUEST:
        return {
          message: `${userName} has requested to book a ${space ? 'space' : 'day pass'} at ${venueName}!`,
          htmlMessage: `<b>${userName}</b> has requested to book a <b>${space ? 'space' : 'day pass'}</b> at <b>${venueName}</b>!`,
          title: 'Booking Request',
          type: NotificationType.HOST_BOOKING_REQUEST,
        }
      case Events.HOST_BOOKING_CANCELED:
        return {
          message: `${userName} has cancelled their booking at ${venueName}!`,
          htmlMessage: `<b>${userName}</b> has cancelled their booking at <b>${venueName}</b>!`,
          title: 'Booking Cancellation',
          type: NotificationType.HOST_BOOKING_CANCELLATION,
        }
      case Events.HOST_PAYOUT_COMPLETED:
        return {
          message: `You've received a payout!`,
          htmlMessage: `You've received a payout!`,
          title: 'Payout Complete',
          type: NotificationType.HOST_PAYOUT_COMPLETED,
        }
      case Events.HOST_STRIPE_STATUS_CHANGED:
        return {
          message: `There's a change in status with your Stripe account, please login to view message!`,
          htmlMessage: `There's a change in status with your Stripe account, please login to view message!`,
          title: 'Stripe Status Changed',
          type: NotificationType.HOST_STRIPE_KYC_ISSUE_OR_STATUS_CHANGE,
        }
      case Events.HOST_ACCOUNT_PAUSED:
        return {
          message: `Your account is now paused. To allow new bookings, contact fluxo support to unpause your account.`,
          htmlMessage: `Your account is now paused. To allow new bookings, contact fluxo support to unpause your account.`,
          title: 'Account Paused',
          type: NotificationType.HOST_ACCOUNT_PAUSED,
        }
      case Events.GUEST_BOOKING_CONFIRMED:
        return {
          message: `Your booking for ${venueName} has been confirmed!`,
          htmlMessage: `Your booking for <b>${venueName}</b> has been confirmed!`,
          title: 'Booking Confirmation',
          type: NotificationType.GUEST_BOOKING_CONFIRMATION,
        }
      case Events.GUEST_BOOKING_REQUEST_APPROVED:
        return {
          message: `Your request to book ${space ? 'space' : 'day pass'} at ${venueName} has been approved!`,
          htmlMessage: `Your request to book <b>${space ? 'space' : 'day pass'}</b> at <b>${venueName}</b> has been approved!`,
          title: 'Booking Request Approved',
          type: NotificationType.GUEST_BOOKING_REQUEST_APPROVED,
        }
      case Events.GUEST_BOOKING_REQUEST_DECLINED:
        return {
          message: `Your request to book ${space ? 'space' : 'day pass'} at ${venueName} has been declined!`,
          htmlMessage: `Your request to book <b>${space ? 'space' : 'day pass'}</b> at <b>${venueName}</b> has been declined!`,
          title: 'Booking Request Declined',
          type: NotificationType.GUEST_BOOKNING_REQUEST_DECLINED,
        }
      case Events.GUEST_BOOKING_CANCELED:
        return {
          message: `Your booking for ${venueName} has been cancelled!`,
          htmlMessage: `Your booking for <b>${venueName}</b> has been cancelled!`,
          title: 'Booking Cancelled',
          type: NotificationType.GUEST_BOOKING_CANCELLATION,
        }
      case Events.GUEST_CHECKED_IN:
        return {
          message: `You've been checked in at ${venueName}!`,
          htmlMessage: `You've been checked in at <b>${venueName}</b>!`,
          title: 'Check In Confirmation',
          type: NotificationType.GUEST_CHECK_IN_NOTIFICATIONS,
        }
      case Events.GUEST_CHECKED_OUT:
        return {
          message: `Leave a review for ${venueName}!`,
          htmlMessage: `Leave a review for <b>${venueName}</b>!`,
          title: 'Rate Experience',
          type: NotificationType.GUEST_RATE_EXPERIENCE_PROMPT,
        }
      default:
        return {
          message: `Unknown event type ${eventType}!`,
          htmlMessage: `Unknown event type <b>${eventType}</b>!`,
          title: 'Unknown Action',
          type: NotificationType.HOST_BOOKING_CONFIRMATION,
        }
    }
  }
}
