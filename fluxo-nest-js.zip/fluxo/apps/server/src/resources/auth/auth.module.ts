import { Module } from '@nestjs/common'

import { EmailModule } from '@/common/services/email/email.module'
import { SocialAuthModule } from '@/common/services/integrations/social-auth/social-auth.module'
import { StripeBusinessModule } from '@/common/services/integrations/stripe/business/stripe-business.module'
import { StripeCustomersModule } from '@/common/services/integrations/stripe/customers/stripe-customers.module'
import { AuthResolver } from '@/resources/auth/auth.resolver'

import { UsersModule } from '../users/users.module'
import { AuthService } from './auth.service'

@Module({
  imports: [
    UsersModule,
    EmailModule,
    SocialAuthModule,
    StripeBusinessModule,
    StripeCustomersModule,
  ],
  providers: [AuthService, AuthResolver],
})
export class AuthModule {}
