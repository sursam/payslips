import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional } from 'class-validator'

import { UserInterface } from '@/resources/users/interfaces/user.interface'

@InputType()
export class VerifyCodeInput extends PickType(UserInterface, ['email'], InputType) {
  @IsNotEmpty()
  @Field()
  verificationCode: string

  @IsOptional()
  @Field({ defaultValue: true })
  withCookieAuth: boolean
}
