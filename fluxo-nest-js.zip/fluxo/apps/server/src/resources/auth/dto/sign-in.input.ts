import { Field, InputType, PickType } from '@nestjs/graphql'
import { IsNotEmpty, IsOptional, MaxLength, MinLength } from 'class-validator'

import { MessageGraphqlService } from '@/common/services/graphql/message-graphql.service'
import { UserInterface } from '@/resources/users/interfaces/user.interface'

const MessageService = new MessageGraphqlService()

@InputType()
export class SignInInput extends PickType(UserInterface, ['email'], InputType) {
  @MinLength(8, { message: MessageService.error('password', 'Minimum 8 characters') })
  @MaxLength(40, { message: MessageService.error('password', 'Maximum 40 characters') })
  @IsNotEmpty()
  @Field()
  password: string

  @IsOptional()
  @Field(() => Boolean, { nullable: true, defaultValue: false })
  readonly remember?: boolean
}
