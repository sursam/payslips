import { Inject, Injectable } from '@nestjs/common'

import {
  EMAIL_INTEGRATION_SERVICE,
  EmailIntegrationService,
} from '@/common/services/integrations/email-service-integration.interface'

@Injectable()
export class EmailService {
  constructor(
    @Inject(EMAIL_INTEGRATION_SERVICE)
    private readonly emailServiceIntegration: EmailIntegrationService,
  ) {}

  public async sendVerificationCode(
    email: string,
    verificationCode: string,
    isSignUp: boolean,
  ): Promise<void> {
    if (isSignUp) {
      await this.emailServiceIntegration.send({
        from: 'verification@fluxo.work',
        to: email,
        subject: 'fluxo | Verification code',
        html: `
        <h2 style="font-weight: 500">Thank you for registering with <b>fluxo</b>! We're excited to have you on board.</h2>
        <p>
          To complete your registration and verify your email address, please use the following code:
          <br/>
          <i><b style="font-size: 1.5rem; color: #475569;">${verificationCode}</b></i>
          <br/>
          Enter this code on the page to complete the process.
        </p>
        <p>
          If you did not request this verification, please ignore this email.
          <br/>
          If you have any questions or need assistance, feel free to contact our support team at ... .
        </p>
        <p>
          <i>Best regards,
            <br/>
            The <b style="font-size: 1.1rem">fluxo</b> Team
          </i>
        </p>
      </p>`,
      })
      return
    }

    await this.emailServiceIntegration.send({
      from: 'verification@fluxo.work',
      to: email,
      subject: 'fluxo | Forgot password',
      html: `
        <p>
          To restore your password, please use the following code:
          <br/>
          <i><b style="font-size: 1.5rem; color: #475569;">${verificationCode}</b></i>
          <br/>
          Enter this code on the page to complete the process.
        </p>
        <p>
          If you did not request the password reset, please ignore this email.
          <br/>
          If you have any questions or need assistance, feel free to contact our support team at ... .
        </p>
        <p>
          <i>Best regards,
            <br/>
            The <b style="font-size: 1.1rem">fluxo</b> Team
          </i>
        </p>
      </p>`,
    })
  }
}
