import crypto from 'node:crypto'

import { PutObjectCommand, S3Client } from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'
import { Injectable } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'

import { AppConfig } from '@/common/config/configuration'
import { PresignedUrlEntity } from '@/resources/images/entities/presigned-url.entity'

@Injectable()
export class AWSService {
  private readonly s3Client: S3Client

  constructor(private configService: ConfigService<AppConfig>) {
    const accessKeyId = this.configService.get('aws.accessKeyId', { infer: true })
    const secretAccessKey = this.configService.get('aws.secretAccessKey', { infer: true })
    // Make credentials undefined without access keys in the env variables, to make the IRSA work on the stage and prod environments
    const credentials =
      accessKeyId && secretAccessKey ? { accessKeyId, secretAccessKey } : undefined

    this.s3Client = new S3Client({
      region: this.configService.get('aws.region', { infer: true }),
      credentials,
    })
  }

  async generatePresignedUrl(key: string, contentType: string): Promise<PresignedUrlEntity> {
    const uniqueKey = `${crypto.randomUUID()}-${key}`
    const command = new PutObjectCommand({
      Bucket: this.configService.get('aws.s3DynamicBucketName', { infer: true }),
      Key: uniqueKey,
      ContentType: contentType,
    })

    return {
      presignedUrl: await getSignedUrl(this.s3Client, command, { expiresIn: 3600 }),
      fileUrl: `https://${this.configService.get('aws.s3FileUrl', { infer: true })}/${uniqueKey}`,
    }
  }
}
