export interface SendOptions {
  from: string
  to: string
  subject: string
  html: string
}

export interface EmailIntegrationService {
  send: ({ to, subject, html }: SendOptions) => Promise<void>
}

export const EMAIL_INTEGRATION_SERVICE = Symbol('EMAIL_INTEGRATION_SERVICE')
