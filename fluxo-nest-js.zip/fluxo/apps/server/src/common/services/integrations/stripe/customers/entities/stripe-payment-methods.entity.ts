import { Field, ObjectType } from '@nestjs/graphql'
import { IsOptional } from 'class-validator'

@ObjectType()
export class StripePaymentMethodEntity {
  @IsOptional()
  @Field(() => String, { nullable: true })
  brand: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  last4: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  exp_month: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  exp_year: string

  @IsOptional()
  @Field(() => String, { nullable: true })
  type: string
}
