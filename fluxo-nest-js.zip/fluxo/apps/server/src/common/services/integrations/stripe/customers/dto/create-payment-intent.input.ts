import { Field, InputType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@InputType()
export class CreatePaymentIntentInput {
  @IsNotEmpty()
  @Field(() => Number)
  basePrice: number

  @IsNotEmpty()
  @Field(() => Number)
  total: number

  @IsNotEmpty()
  @Field(() => String)
  hostId: string

  @IsNotEmpty()
  @Field(() => String)
  venueName: string
}
