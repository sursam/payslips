import { HttpService } from '@nestjs/axios'
import { Injectable, Logger, type OnModuleInit } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { Cron, CronExpression } from '@nestjs/schedule'
import { BookingStatus, Prisma } from '@prisma/client'
import { AxiosError, AxiosRequestConfig } from 'axios'
import { format } from 'date-fns'
import { camelCase, merge } from 'es-toolkit'
import pRetry from 'p-retry'
import { catchError, firstValueFrom } from 'rxjs'

import type { AppConfig } from '@/common/config/configuration'
import {
  RMSCloudAreaLite,
  RMSCloudAuthTokenResponse,
  RMSCloudAvailableAreaRequest,
  RMSCloudReservationBasic,
  RMSCloudReservationFull,
  RMSCloudReservationPatch,
  RMSCloudReservationPencil,
  RMSCloudReservationSearch,
  RMSCloudReservationStatus,
  RMSCloudReservationStatusStatusEnum,
} from '@/common/services/integrations/rms-cloud/rms-cloud-types'
import { PrismaService } from '@/common/services/prisma/prisma.service'

@Injectable()
export class RmsCloudService implements OnModuleInit {
  private readonly logger = new Logger(RmsCloudService.name)
  // RMS requirement - When using the POST function, always pass 'id' as '0' to create the next available record. https://app.swaggerhub.com/apis-docs/RMSHospitality/RMS_REST_API
  public readonly DEFAULT_POST_ID = 0
  public readonly DELETED_AREA_MARKER = 'DELETED'

  // Default rate type ID that we are using for all entities in RMS
  public DEFAULT_RATE_TYPE_ID

  constructor(
    private readonly configService: ConfigService<AppConfig>,
    private readonly httpService: HttpService,
    private readonly prismaService: PrismaService,
  ) {
    this.DEFAULT_RATE_TYPE_ID = Number(
      this.configService.get('rmsCloud.defaultRateTypeId', {
        infer: true,
      }),
    )
  }

  public async onModuleInit(): Promise<void> {
    try {
      await this.updateRmsServerUrl()
      await this.updateAuthToken()
    } catch (error) {
      if (error instanceof AxiosError) {
        this.logger.error('Failed to initialize RMS Cloud auth token/server URL', error.stack)
      }
    }
  }

  public async reservationsSearch(input: RMSCloudReservationSearch) {
    return await this.request<RMSCloudReservationBasic[]>('/reservations/search', {
      method: 'POST',
      params: {
        modelType: 'lite',
      },
      data: input,
    })
  }

  public async availableAreas(input: RMSCloudAvailableAreaRequest) {
    return await this.request<Required<RMSCloudAreaLite>[]>('/availableAreas', {
      method: 'POST',
      data: input,
    })
  }

  public async updateReservationStatus({
    reservationId,
    newStatus,
    cancelationNote,
  }: {
    reservationId: number
    newStatus: BookingStatus
    cancelationNote?: string
  }) {
    const rmsNewStatus = this.mapFluxoToRMSReservationStatus(newStatus)
    const rmsCancelationNote = this.getCancelationNote(newStatus, cancelationNote)

    return this.request<RMSCloudReservationFull>(`/reservations/${reservationId}/status`, {
      method: 'PUT',
      data: {
        reasonId: 1,
        status: rmsNewStatus,
        cancellationNote: rmsCancelationNote,
      } as RMSCloudReservationStatus,
    })
  }
  public mapFluxoToRMSReservationStatus(
    fluxoBookingStatus: BookingStatus,
  ): RMSCloudReservationStatusStatusEnum {
    const mapping = {
      [BookingStatus.PENCIL]: RMSCloudReservationStatusStatusEnum.Pencil,
      [BookingStatus.PENCIL_RTB]: RMSCloudReservationStatusStatusEnum.Pencil,
      [BookingStatus.ARRIVED]: RMSCloudReservationStatusStatusEnum.Arrived,
      [BookingStatus.CANCELED_BY_GUEST]: RMSCloudReservationStatusStatusEnum.Cancelled,
      [BookingStatus.CANCELED_BY_HOST]: RMSCloudReservationStatusStatusEnum.Cancelled,
      [BookingStatus.CANCELED_BY_SYSTEM]: RMSCloudReservationStatusStatusEnum.Cancelled,
      [BookingStatus.NO_SHOW]: RMSCloudReservationStatusStatusEnum.NoShow,
      [BookingStatus.CONFIRMED]: RMSCloudReservationStatusStatusEnum.Confirmed,
      [BookingStatus.DEPARTED]: RMSCloudReservationStatusStatusEnum.Departed,
    }

    return mapping[fluxoBookingStatus]
  }

  public mapRMSToFluxoBookingStatus(rmsReservationStatus: string): BookingStatus | null {
    const camelCaseReservationStatus = camelCase(
      rmsReservationStatus,
    ) as RMSCloudReservationStatusStatusEnum
    const mapping = {
      [RMSCloudReservationStatusStatusEnum.Pencil]: BookingStatus.PENCIL,
      [RMSCloudReservationStatusStatusEnum.Arrived]: BookingStatus.ARRIVED,
      [RMSCloudReservationStatusStatusEnum.Cancelled]: BookingStatus.CANCELED_BY_SYSTEM,
      [RMSCloudReservationStatusStatusEnum.NoShow]: BookingStatus.NO_SHOW,
      [RMSCloudReservationStatusStatusEnum.Confirmed]: BookingStatus.CONFIRMED,
      [RMSCloudReservationStatusStatusEnum.Departed]: BookingStatus.DEPARTED,
      [RMSCloudReservationStatusStatusEnum.Unconfirmed]: null,
      [RMSCloudReservationStatusStatusEnum.StopSell]: null,
      [RMSCloudReservationStatusStatusEnum.Quote]: null,
      [RMSCloudReservationStatusStatusEnum.Maintenance]: null,
      [RMSCloudReservationStatusStatusEnum.OwnerOccupied]: null,
    }

    return mapping[camelCaseReservationStatus] ?? null
  }

  public async updateReservation(
    data: RMSCloudReservationPatch & { reservationId: number },
  ): Promise<RMSCloudReservationBasic | undefined> {
    try {
      return await this.request<RMSCloudReservationBasic>(`/reservations/${data.reservationId}`, {
        method: 'PATCH',
        data,
      })
    } catch (e) {
      this.logger.error(`Pencil booking update failed: ${e}`)
      throw e
    }
  }

  public createPencilReservation(pencilReservationData: RMSCloudReservationPencil) {
    try {
      return this.request<RMSCloudReservationPencil>('/reservations/pencil', {
        method: 'POST',
        data: {
          id: this.DEFAULT_POST_ID,
          status: RMSCloudReservationStatusStatusEnum.Pencil,
          ...pencilReservationData,
        } as RMSCloudReservationPencil,
      })
    } catch (error) {
      this.logger.error(`Pencil booking creation failed: ${JSON.stringify(error, null, 2)}`)
      throw error
    }
  }

  private async getRmsConfiguration() {
    return this.prismaService.rmsConfiguration.findFirstOrThrow({
      select: { authToken: true, serverUrl: true },
    })
  }

  private async updateRmsConfiguration(args: Prisma.RmsConfigurationUpdateArgs) {
    await this.prismaService.rmsConfiguration.update(args)
  }

  @Cron(CronExpression.EVERY_10_HOURS)
  public async updateAuthToken(): Promise<void> {
    const authCredentials = this.configService.get('rmsCloud.authCredentials', { infer: true })
    const { serverUrl } = await this.getRmsConfiguration()
    const { data } = await firstValueFrom(
      this.httpService
        .post<RMSCloudAuthTokenResponse>(`${serverUrl}/authToken`, {
          ...authCredentials,
        })
        .pipe(
          catchError((error: AxiosError) => {
            this.logger.error(JSON.stringify(error, null, 2))
            throw error
          }),
        ),
    )

    await this.updateRmsConfiguration({ where: { id: 1 }, data: { authToken: data.token ?? '' } })

    this.logger.debug('Auth token update schedule completed')
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  private async updateRmsServerUrl(): Promise<void> {
    const clientId = this.configService.get('rmsCloud.authCredentials.clientId', { infer: true })
    const { serverUrl } = await this.getRmsConfiguration()
    const { data } = await firstValueFrom(
      this.httpService
        .get<string>(`${serverUrl}/clienturl/${clientId}`, { baseURL: serverUrl ?? '' })
        .pipe(
          catchError((error: AxiosError) => {
            this.logger.error(error.response?.data)
            throw error
          }),
        ),
    )

    await this.updateRmsConfiguration({ where: { id: 1 }, data: { serverUrl: data } })

    this.logger.debug('RMS Server URL update schedule completed')
  }

  public formatToRMSDate(date: Date) {
    return format(date, 'yyyy-MM-dd HH:mm:ss')
  }

  private getCancelationNote(newStatus: BookingStatus, cancelationNote?: string): string {
    if (cancelationNote) {
      return cancelationNote
    }

    // If fluxo status is Canceled - the reservation was canceled by guest, otherwise it was canceled by host
    if (
      this.mapFluxoToRMSReservationStatus(newStatus) ===
      RMSCloudReservationStatusStatusEnum.Cancelled
    ) {
      return newStatus === BookingStatus.CANCELED_BY_GUEST
        ? 'Canceled by guest'
        : 'Canceled by host'
    }

    return ''
  }

  public async request<T>(url: string, params: AxiosRequestConfig = {}): Promise<T> {
    const { authToken, serverUrl } = await this.getRmsConfiguration()
    const requestParams = merge(
      { headers: { authtoken: authToken }, url: `${serverUrl}${url}` },
      params,
    )

    return await pRetry(
      async () => {
        const { data } = await firstValueFrom(
          this.httpService.request<T>(requestParams).pipe(
            catchError((error: AxiosError) => {
              this.logger.warn(`RMS request error: ${requestParams.method} | ${requestParams.url}`)
              this.logger.warn(`Request data: ${JSON.stringify(requestParams.data, null, 2)}`)

              throw error
            }),
          ),
        )

        return data
      },
      {
        retries: 5,
        factor: 3,
        minTimeout: 1000,
        randomize: true,
        onFailedAttempt: (error) => {
          if (error.attemptNumber === 1) return

          this.logger.warn(
            `Attempt #${error.attemptNumber} failed. Retrying request ${requestParams.method} | ${requestParams.url}`,
          )
        },
        shouldRetry: (error) => {
          if (error instanceof AxiosError) {
            const response = error.response

            if (!response) {
              this.logger.warn(`Retrying request due to connection error: ${error.message}`)
              return true
            }

            if (response.status >= 500) {
              this.logger.warn(`Retrying request due to 5xx error: ${error.message}`)
              return true
            }
          }

          this.logger.error(`Non-retryable error: ${error.message}`)
          return false
        },
      },
    )
  }
}
