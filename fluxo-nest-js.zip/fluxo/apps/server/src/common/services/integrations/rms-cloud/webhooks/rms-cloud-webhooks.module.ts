import { Module } from '@nestjs/common'

import { RmsCloudWebhooksController } from '@/common/services/integrations/rms-cloud/webhooks/rms-cloud-webhooks.controller'
import { GuestsModule } from '@/resources/guests/guests.module'
import { HostsModule } from '@/resources/hosts/hosts.module'

import { RmsCloudModule } from '../rms-cloud.module'

@Module({
  imports: [RmsCloudModule, HostsModule, GuestsModule],
  providers: [],
  controllers: [RmsCloudWebhooksController],
  exports: [],
})
export class RmsCloudWebhooksModule {}
