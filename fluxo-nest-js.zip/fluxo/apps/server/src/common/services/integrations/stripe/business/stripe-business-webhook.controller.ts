import {
  BadRequestException,
  Controller,
  HttpStatus,
  Logger,
  Post,
  RawBodyRequest,
  Req,
  Res,
} from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { EventEmitter2 } from '@nestjs/event-emitter'
import { FastifyReply, FastifyRequest } from 'fastify'
import Stripe from 'stripe'

import { AppConfig } from '@/common/config/configuration'
import { Events, StripeConnectAccountStatus } from '@/common/enums'
import { StripeBusinessGateway } from '@/common/services/integrations/stripe/business/stripe-business.gateway'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { HostPayoutCompletedEvent } from '@/resources/notifications/events/host-payout-completed.event'
import { HostStripeStatusChangedEvent } from '@/resources/notifications/events/host-stripe-status-changed.event'

@Controller('webhooks')
export class StripeBusinessWebhookController {
  private readonly stripeClient: Stripe
  private readonly logger = new Logger(StripeBusinessWebhookController.name)

  constructor(
    private configService: ConfigService<AppConfig>,
    private readonly stripeService: StripeBusinessService,
    private readonly stripeGateway: StripeBusinessGateway,
    private readonly eventEmitter: EventEmitter2,
    private readonly prismaService: PrismaService,
  ) {
    const apiKey = this.configService.get('stripe.apiKey', { infer: true })
    this.stripeClient = new Stripe(apiKey ?? '')
  }

  @Post('stripe')
  async handleWebhook(
    @Req() req: RawBodyRequest<FastifyRequest>,
    @Res() res: FastifyReply,
  ): Promise<void> {
    const sig = req.headers['stripe-signature'] as string
    const endpointSecret = this.configService.get('stripe.whBusinessSecret', { infer: true })

    let event: Stripe.Event

    try {
      // Validate the webhook signature
      event = this.stripeClient.webhooks.constructEvent(
        req.rawBody ?? Buffer.from(''),
        sig,
        endpointSecret ?? '',
      )
    } catch (err) {
      this.logger.error('Webhook signature verification failed:', err)
      await res.status(HttpStatus.BAD_REQUEST).send(`Webhook Error: ${err}`)
      return
    }

    if (event.type === 'account.updated') {
      await this.onAccountUpdated(event)
    }

    if (event.type === 'payout.paid') {
      await this.onPayoutHandle(event)
    }

    await res.status(HttpStatus.OK).send()
  }

  async onAccountUpdated(event: Stripe.AccountUpdatedEvent) {
    const account = event.data.object
    const kycStatus = this.stripeService.getKYCStatus(account)
    this.logger.log(`KYC Status for account ${account.id}: ${kycStatus}`)
    await this.stripeService.updateBusinessAccountStatus(account.id, kycStatus)

    const { id: userId, email } = await this.stripeService.getUserByStripeId(account.id)

    if (userId) {
      const businessAccount = await this.stripeService.getBusinessAccount({ userId })

      if (
        (kycStatus === StripeConnectAccountStatus.VERIFIED &&
          !businessAccount.beenAlreadyVerified) ||
        kycStatus === StripeConnectAccountStatus.DISABLED
      ) {
        this.eventEmitter.emit(
          Events.HOST_STRIPE_STATUS_CHANGED,
          new HostStripeStatusChangedEvent(userId, kycStatus),
        )
      }

      // Fire property create event only when KYC verified so only then property is visible
      if (kycStatus === StripeConnectAccountStatus.VERIFIED) {
        await this.stripeService.unpauseHostAccount({ userId, email })

        if (!businessAccount.beenAlreadyVerified) {
          await this.prismaService.stripeBusinessAccount.update({
            where: { stripeId: businessAccount.stripeId },
            data: { beenAlreadyVerified: true },
          })
        }
      } else if (businessAccount.beenAlreadyVerified) {
        await this.stripeService.pauseHostAccount(userId, email)
      }
    } else {
      this.logger.error(`User with Stripe ID ${account.id} not found`)
    }

    this.stripeGateway.handleKycUpdate({
      status: kycStatus,
      errors: this.stripeService.getAccountErrors(account),
    })
  }

  async onPayoutHandle(event: Stripe.PayoutPaidEvent) {
    try {
      if (!event.account) {
        throw new BadRequestException('Stripe business account not found')
      }

      const { id: userId } = await this.stripeService.getUserByStripeId(event.account)

      this.eventEmitter.emit(Events.HOST_PAYOUT_COMPLETED, new HostPayoutCompletedEvent(userId))

      const {
        id,
        amount,
        status,
        balance_transaction: balanceTransactionId,
        failure_code: failureCode,
        statement_descriptor: statementDescriptor,
      } = event.data.object

      await this.prismaService.payoutsHistory.create({
        data: {
          businessStripeId: event.account,
          total: amount,
          status,
          payoutId: id,
          balanceTransactionId: balanceTransactionId as string,
          failureCode,
          statementDescriptor,
        },
      })
    } catch (err) {
      this.logger.error('Webhook payout failed:', err)
    }
  }
}
