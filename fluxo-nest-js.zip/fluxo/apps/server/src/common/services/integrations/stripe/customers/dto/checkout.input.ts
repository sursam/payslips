import { Field, InputType } from '@nestjs/graphql'
import { Type } from 'class-transformer'
import { IsNotEmpty, ValidateNested } from 'class-validator'

@InputType()
export class AddressInput {
  @IsNotEmpty()
  @Field(() => String)
  city: string

  @IsNotEmpty()
  @Field(() => String)
  state: string

  @IsNotEmpty()
  @Field(() => String)
  postal_code: string

  @IsNotEmpty()
  @Field(() => String)
  country: string
}

@InputType()
export class CheckoutTotalsInput {
  @IsNotEmpty()
  @Field(() => Number)
  price: number

  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => AddressInput)
  @Field(() => AddressInput)
  propertyAddress: AddressInput
}
