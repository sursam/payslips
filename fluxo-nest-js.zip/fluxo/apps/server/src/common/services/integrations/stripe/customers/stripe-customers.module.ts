import { forwardRef, Module } from '@nestjs/common'

import { StripeCustomersResolver } from '@/common/services/integrations/stripe/customers/stripe-customers.resolver'
import { StripeCustomersService } from '@/common/services/integrations/stripe/customers/stripe-customers.service'
import { StripeCustomersWebhookController } from '@/common/services/integrations/stripe/customers/stripe-customers-webhook.controller'
// eslint-disable-next-line import/no-cycle -- fixed with forwardRef
import { BookingsModule } from '@/resources/bookings/bookings.module'

@Module({
  imports: [forwardRef(() => BookingsModule)],
  controllers: [StripeCustomersWebhookController],
  providers: [StripeCustomersService, StripeCustomersResolver],
  exports: [StripeCustomersService],
})
export class StripeCustomersModule {}
