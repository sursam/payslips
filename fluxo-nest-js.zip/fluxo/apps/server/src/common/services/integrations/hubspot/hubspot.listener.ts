import { Client } from '@hubspot/api-client'
import { SimplePublicObject } from '@hubspot/api-client/lib/codegen/crm/companies'
import {
  AssociationSpecAssociationCategoryEnum,
  SimplePublicObjectInput,
  SimplePublicObjectInputForCreate,
} from '@hubspot/api-client/lib/codegen/crm/deals'
import { Injectable, Logger } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { OnEvent } from '@nestjs/event-emitter'
import { Attribute } from '@prisma/client'
import { format } from 'date-fns'
import { groupBy } from 'es-toolkit'

import type { AppConfig } from '@/common/config/configuration'
import { Events } from '@/common/enums'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { GuestAccountDeactivatedEvent } from '@/resources/guests/events/guest-account-deactivated.event'
import { GuestProfileChangedEvent } from '@/resources/guests/events/guest-profile-changed.event'
import { HostAccountDeactivatedEvent } from '@/resources/hosts/events/host-account-deactivated.event'
import { HostAccountPausedEvent } from '@/resources/hosts/events/host-account-paused.event'
import { HostProfileChangedEvent } from '@/resources/hosts/events/host-profile-changed.event'
import { PropertyCreatedEvent } from '@/resources/properties/events/property-created.event'
import { PropertyUpdatedEvent } from '@/resources/properties/events/property-updated.event'
import { LocationsService } from '@/resources/properties/locations.service'

@Injectable()
export class HubspotListener {
  private readonly logger = new Logger(HubspotListener.name)
  private client: Client

  constructor(
    private readonly configService: ConfigService<AppConfig>,
    private readonly locationsService: LocationsService,
    private readonly prismaService: PrismaService,
  ) {
    this.client = new Client({
      accessToken: this.configService.get('hubspot.apiKey', { infer: true }) ?? '',
    })
  }

  @OnEvent(Events.HOST_PROFILE_CREATED)
  private async handleHostProfileCreatedEvent(payload: HostProfileChangedEvent): Promise<void> {
    const { host } = payload
    const location = await this.locationsService.findUnique({ hostId: host.id })
    const contactProperties = {
      firstname: host.user.firstName,
      lastname: host.user.lastName,
      email: host.user.email,
      company: host.businessName,
      phone: host.businessPhoneNumber ?? '',
      contact_status: 'Active HOST Account',
      contact_type: 'Manager',
    }
    const isContactAlreadyExists = await this.getContactByEmail(host.user.email)

    let contact

    if (isContactAlreadyExists) {
      contact = await this.updateContact(
        {
          properties: contactProperties,
        },
        host.user.email,
      )
    } else {
      contact = await this.createContact({
        properties: contactProperties,
        associations: [],
      })
    }

    await this.createCompany({
      properties: {
        address: location?.address ?? '',
        phone: host.businessPhoneNumber ?? '',
      },
      associations: [
        {
          to: { id: contact.id },
          types: [
            {
              associationCategory: AssociationSpecAssociationCategoryEnum.HubspotDefined,
              associationTypeId: 280,
            },
          ],
        },
      ],
    })
  }

  @OnEvent(Events.HOST_ACCOUNT_DEACTIVATED)
  private async handleHostAccountDeactivatedEvent(
    payload: HostAccountDeactivatedEvent,
  ): Promise<void> {
    await this.updateContact(
      {
        properties: {
          contact_status: 'Deactivated HOST Account',
        },
      },
      payload.email,
    )
  }

  @OnEvent(Events.HOST_ACCOUNT_PAUSED)
  private async handleHostAccountPausedEvent(payload: HostAccountPausedEvent): Promise<void> {
    await this.updateContact(
      {
        properties: {
          contact_status: 'Paused HOST Account',
        },
      },
      payload.email,
    )
  }

  @OnEvent(Events.HOST_ACCOUNT_UNPAUSED)
  private async handleHostAccountUnpausedEvent(payload: HostAccountPausedEvent): Promise<void> {
    await this.updateContact(
      {
        properties: {
          contact_status: 'Active HOST Account',
        },
      },
      payload.email,
    )
  }

  @OnEvent(Events.HOST_PROFILE_UPDATED)
  private async handleHostProfileUpdatedEvent(payload: HostProfileChangedEvent): Promise<void> {
    const { host } = payload

    await this.updateContact(
      {
        properties: {
          firstname: host.user.firstName,
          lastname: host.user.lastName,
          email: host.user.email,
          company: host.businessName,
          mobilephone: host.businessPhoneNumber ?? '',
          contact_status: 'Active HOST Account',
          contact_type: 'Manager',
        },
      },
      host.user.email,
    )
  }

  private formatAttributeNames(attributesArr?: Attribute[]): string {
    return (
      attributesArr
        ?.filter((attribute) => !attribute.standard)
        .map((attribute) => attribute.name)
        .join(';') ?? ''
    )
  }

  @OnEvent(Events.PROPERTY_UPDATED)
  public async handlePropertyUpdatedEvent(payload: PropertyUpdatedEvent): Promise<void> {
    const property = await this.prismaService.property.findUniqueOrThrow({
      where: { id: payload.id },
      select: {
        name: true,
        id: true,
        neighborhood: true,
        attributes: true,
        host: { select: { user: { select: { email: true } } } },
      },
    })
    const attributesGroupedByType = groupBy(property.attributes, (attribute) => attribute.type)

    if (!property.host) {
      return
    }

    const contact = await this.getContactByEmail(property.host.user.email)

    if (!contact) {
      return
    }

    const associatedCompanies = await this.client.crm.associations.v4.basicApi.getPage(
      'contact',
      contact.id,
      'company',
    )

    await this.updateCompany(
      {
        properties: {
          name: property.name,
          neighborhood___all_ny: property.neighborhood ?? '',
          host_category: this.formatAttributeNames(attributesGroupedByType.PROPERTY_CATEGORY),
          features: this.formatAttributeNames(attributesGroupedByType.PROPERTY_FEATURE),
          vibes: this.formatAttributeNames(attributesGroupedByType.PROPERTY_VIBE),
          fluxo_venue_url: `${this.configService.get('app.url', { infer: true })}/venue/${property.id}`,
        },
      },
      associatedCompanies.results[0].toObjectId,
    )
  }

  @OnEvent(Events.PROPERTY_CREATED)
  private async handlePropertyCreatedEvent(payload: PropertyCreatedEvent): Promise<void> {
    const { property, email } = payload
    const attributesGroupedByType = groupBy(property.attributes, (attribute) => attribute.type)

    const contact = await this.getContactByEmail(email)

    if (!contact) {
      return
    }

    const associatedCompanies = await this.client.crm.associations.v4.basicApi.getPage(
      'contact',
      contact.id,
      'company',
    )

    await this.updateCompany(
      {
        properties: {
          name: property.name,
          neighborhood___all_ny: property.neighborhood ?? '',
          host_category: this.formatAttributeNames(attributesGroupedByType.PROPERTY_CATEGORY),
          features: this.formatAttributeNames(attributesGroupedByType.PROPERTY_FEATURE),
          vibes: this.formatAttributeNames(attributesGroupedByType.PROPERTY_VIBE),
          fluxo_venue_url: `${this.configService.get('app.url', { infer: true })}/venue/${property.id}`,
        },
      },
      associatedCompanies.results[0].toObjectId,
    )
  }

  @OnEvent(Events.GUEST_PROFILE_CREATED)
  private async handleGuestProfileCreatedEvent(payload: GuestProfileChangedEvent): Promise<void> {
    const { guest } = payload

    const guestLocation = await this.locationsService.findUnique({ guestId: guest.id })
    const contactProperties = {
      firstname: guest.user.firstName,
      lastname: guest.user.lastName,
      bio: guest.bio ?? '',
      email: guest.user.email,
      address: guestLocation?.address ?? '',
      mobilephone: guest.phoneNumber ?? '',
      jobtitle: guest.jobTitle ?? '',
      date_of_birth: guest.dateOfBirth ? format(guest.dateOfBirth, 'MM/dd/yyyy') : '',
      speaks: guest.speaks ?? '',
      pronouns: guest.pronouns ?? '',
      contact_status: 'Active fluxo Account',
      contact_type: 'Worker',
    }
    const isContactAlreadyExists = await this.getContactByEmail(guest.user.email)

    if (isContactAlreadyExists) {
      await this.updateContact(
        {
          properties: contactProperties,
        },
        guest.user.email,
      )

      return
    }

    await this.createContact({
      properties: contactProperties,
      associations: [],
    })
  }

  @OnEvent(Events.GUEST_ACCOUNT_DEACTIVATED)
  private async handleGuestAccountDeactivatedEvent(
    payload: GuestAccountDeactivatedEvent,
  ): Promise<void> {
    await this.updateContact(
      {
        properties: {
          contact_status: 'Deactivated fluxo Account',
        },
      },
      payload.email,
    )
  }

  @OnEvent(Events.GUEST_PROFILE_UPDATED)
  private async handleGuestProfileUpdatedEvent(payload: GuestProfileChangedEvent): Promise<void> {
    const { guest } = payload

    const guestLocation = await this.locationsService.findUnique({ guestId: guest.id })

    await this.updateContact(
      {
        properties: {
          firstname: guest.user.firstName,
          lastname: guest.user.lastName,
          bio: guest.bio ?? '',
          email: guest.user.email,
          address: guestLocation?.address ?? '',
          mobilephone: guest.phoneNumber ?? '',
          jobtitle: guest.jobTitle ?? '',
          date_of_birth: guest.dateOfBirth ? format(guest.dateOfBirth, 'MM/dd/yyyy') : '',
          speaks: guest.speaks ?? '',
          pronouns: guest.pronouns ?? '',
          contact_status: 'Active fluxo Account',
          contact_type: 'Worker',
        },
      },
      guest.user.email,
    )
  }

  private async createContact(
    contactData: SimplePublicObjectInputForCreate,
  ): Promise<SimplePublicObject> {
    try {
      const createContactResponse = await this.client.crm.contacts.basicApi.create(contactData)

      this.logger.log('Hubspot contact created successfully: ', createContactResponse.id)

      return createContactResponse
    } catch (error: unknown) {
      this.logger.error('Failed to create Hubspot contact')
      throw error
    }
  }

  private async updateContact(
    contactData: SimplePublicObjectInput,
    email: string,
  ): Promise<SimplePublicObject> {
    try {
      const updateContactResponse = await this.client.crm.contacts.basicApi.update(
        email,
        contactData,
        'email',
      )

      this.logger.log('Hubspot contact updated successfully: ', updateContactResponse)

      return updateContactResponse
    } catch (error: unknown) {
      this.logger.error('Failed to update Hubspot contact')
      throw error
    }
  }

  private async getContactByEmail(email: string): Promise<SimplePublicObject | null> {
    try {
      const contact = await this.client.crm.contacts.basicApi.getById(
        email,
        undefined,
        undefined,
        undefined,
        undefined,
        'email',
      )

      this.logger.log('Hubspot contact obtained successfully: ', contact.id)

      return contact
    } catch (error: unknown) {
      return null
    }
  }

  private async createCompany(companyData: SimplePublicObjectInputForCreate): Promise<void> {
    try {
      const createCompanyResponse = await this.client.crm.companies.basicApi.create(companyData)

      this.logger.log('Hubspot company created successfully: ', createCompanyResponse.id)
    } catch (error: unknown) {
      this.logger.error('Failed to create Hubspot company')
      throw error
    }
  }

  private async updateCompany(
    companyData: SimplePublicObjectInput,
    id: string,
  ): Promise<SimplePublicObject> {
    try {
      const updateCompanyResponse = await this.client.crm.companies.basicApi.update(id, companyData)

      this.logger.log('Hubspot company updated successfully: ', updateCompanyResponse.id)

      return updateCompanyResponse
    } catch (error: unknown) {
      this.logger.error('Failed to update Hubspot company')
      throw error
    }
  }
}
