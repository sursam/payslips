import { Body, Controller, Logger, Post } from '@nestjs/common'
import { BookingStatus, HostPauseSource, RmsEntityType, UserRole } from '@prisma/client'

import { RmsCloudService } from '@/common/services/integrations/rms-cloud/rms-cloud.service'
import {
  RMSCloudGuestBasic,
  RMSCloudGuestFull,
  RMSCloudReservationBasic,
  RMSCloudReservationStatusStatusEnum,
  RMSCloudWebhookSubscriptionResponse,
} from '@/common/services/integrations/rms-cloud/rms-cloud-types'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'
import { GuestsService } from '@/resources/guests/guests.service'
import { HostsService } from '@/resources/hosts/hosts.service'

enum WebhookEntityType {
  RESERVATION = 1,
  GUEST = 2,
}

@Controller()
export class RmsCloudWebhooksController {
  private readonly logger = new Logger(RmsCloudWebhooksController.name)

  constructor(
    private readonly prismaService: PrismaService,
    private readonly rmsCloudService: RmsCloudService,
    private readonly hostsService: HostsService,
    private readonly guestsService: GuestsService,
  ) {}

  @Post('rms-cloud-webhooks')
  private async handleWebhooks(
    @Body()
    payload: {
      subscription?: RMSCloudWebhookSubscriptionResponse
      data?: unknown
    },
  ) {
    // RMS cloud generated types are having errors
    const entityType = payload.subscription?.entityType as unknown as WebhookEntityType

    if (
      entityType === WebhookEntityType.RESERVATION &&
      payload.subscription?.subAction === 'Cancelled'
    ) {
      const data = payload.data as Required<Omit<RMSCloudReservationBasic, 'status'>> & {
        status: RMSCloudReservationStatusStatusEnum
      }

      const newFluxoBookingStatus = this.rmsCloudService.mapRMSToFluxoBookingStatus(data.status)

      if (!newFluxoBookingStatus) {
        this.logger.error(`Can't map RMS status: ${data.status} to fluxo status`)
        return
      }

      const rmsMapping = await this.prismaService.rmsMapping.findFirst({
        where: {
          rmsId: data.id,
          rmsEntityType: RmsEntityType.RESERVATION,
        },
        select: {
          bookingPass: { select: { id: true, bookingStatus: true } },
        },
      })

      if (!rmsMapping?.bookingPass?.id) {
        this.logger.error(`Booking pass to RMS reservation mapping not found`)
        return
      }

      const bookingStatus = rmsMapping.bookingPass.bookingStatus
      // Convert specific cancellation statuses to CANCELED_BY_SYSTEM
      const normalizedStatus =
        bookingStatus === BookingStatus.CANCELED_BY_HOST ||
        bookingStatus === BookingStatus.CANCELED_BY_GUEST
          ? BookingStatus.CANCELED_BY_SYSTEM
          : bookingStatus
      const isSameStatus = newFluxoBookingStatus === normalizedStatus

      if (isSameStatus) {
        return
      }

      this.logger.debug(
        `Updating booking pass ${rmsMapping.bookingPass.id} to status ${newFluxoBookingStatus}`,
      )

      await this.prismaService.bookingPass.update({
        where: { id: rmsMapping.bookingPass.id },
        data: { bookingStatus: newFluxoBookingStatus },
      })
    }

    if (entityType === WebhookEntityType.GUEST) {
      const data = payload.data as Required<Omit<RMSCloudGuestFull, 'title'>> & {
        title: UserRole
      }

      if (data.title === UserRole.GUEST) return

      const host = await this.prismaService.host.findFirst({
        where: { user: { rmsMapping: { rmsId: data.id } } },
        select: { status: true, pauseSource: true, user: { select: { email: true, id: true } } },
      })

      if (!host) return

      // Pause host account from RMS dashboard
      if (data.gstFree) {
        await this.hostsService.pauseAccount(
          { id: host.user.id, email: host.user.email },
          HostPauseSource.RMS,
        )

        this.logger.debug(`The host was paused from the RMS dashboard, userId: ${host.user.id}`)
      } else if (host.pauseSource === HostPauseSource.RMS) {
        await this.hostsService.unpauseAccount({ id: host.user.id, email: host.user.email }, true)

        this.logger.debug(`The host was unpaused from the RMS dashboard, userId: ${host.user.id}`)
      }
    }

    return { status: 'success' }
  }
}
