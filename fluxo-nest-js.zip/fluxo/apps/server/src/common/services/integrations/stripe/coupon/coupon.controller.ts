import { Controller, Get } from '@nestjs/common';
import { CouponService } from './coupon.service';

@Controller('coupon')
export class CouponController {
    constructor(private readonly couponService: CouponService) {}

    @Get('coupons')
    async getCoupons() {
        // const coupons = await this.couponService.getCoupons();

        // console.log('Coupons111111111', coupons); // Log the coupons for debugging
        // return coupons;
    }
}