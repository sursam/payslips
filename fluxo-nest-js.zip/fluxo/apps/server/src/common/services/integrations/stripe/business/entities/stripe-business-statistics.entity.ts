import { Field, ObjectType } from '@nestjs/graphql'
import { IsNotEmpty } from 'class-validator'

@ObjectType()
export class StripeBusinessStatisticsEntity {
  @IsNotEmpty()
  @Field(() => String)
  month: string

  @IsNotEmpty()
  @Field(() => Number)
  revenue: number
}

@ObjectType()
export class StripeBusinessUpcomingBookingsStatisticEntity {
  @IsNotEmpty()
  @Field(() => String)
  date: string

  @IsNotEmpty()
  @Field(() => Number)
  bookings: number

  @IsNotEmpty()
  @Field(() => Number)
  capacity: number
}
