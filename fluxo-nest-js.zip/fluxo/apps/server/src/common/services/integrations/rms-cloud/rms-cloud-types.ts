/* eslint-disable -- generated RMS Cloud API types */
/* tslint:disable -- generated RMS Cloud API types */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * Used:<br>GET /agents/{id}/accounts<br>POST /agents/{id}/createPropertyAccount<br>GET /companies/{id}/accounts<br>POST /companies/{id}/createPropertyAccount<br>GET /guests/{id}/accounts<br>POST /guests/{id}/createPropertyAccount
 * @example {"accountClass":"Guest","id":12345,"propertyId":1}
 */
export interface RMSCloudAccountBasic {
  accountClass?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
}

export enum RMSCloudAccountTypeEnum {
  Accomm = 'accomm',
  Extras = 'extras',
  Pabx = 'pabx',
  Gas = 'gas',
  Electric = 'electric',
  Water = 'water',
  Cash = 'cash',
  Internet = 'internet',
  Client = 'client',
  Agent = 'agent',
  Owner = 'owner',
  Ar = 'ar',
  Notional = 'notional',
  Holding = 'holding',
}

/**
 * Used:<br>GET /accountTypes
 * @example {"id":1,"name":"test"}
 */
export interface RMSCloudAccountTypes {
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>GET /reservations/{id}/actualAccount<br>POST /reservations/{id}/transferBalance<br>POST /reservations/actualAccount/search
 * @example {"accommodationBalance":26.09,"accountCurrencyView":"AUD","accountId":3168,"activeAccounts":1,"arBalance":300.12,"baseRate":551.67,"billCategoryType":"Deluxe Queen","createTotalRate":true,"currencyCode":"AUD","deposit":200,"depositRequiredByDate":"2017-08-25 17:30:00","discountAmount":20,"discountId":7,"discountName":"10% Off","discountReason":"Return customer","electricityBalance":32.58,"extrasBalance":89.36,"gasBalance":45.36,"hideRateOnCorrespondence":false,"internetBalance":10,"package":98.32,"phoneBalance":12,"reservationId":123459,"secondaryCurrency":{"accommodationBalance":10,"arBalance":0,"currencyCode":"USD","electricityBalance":10,"extrasBalance":15.25,"gasBalance":13.25,"internetBalance":55,"phoneBalance":89.56,"waterBalance":17.26},"secondDepositRequiredByDate":"25-08-2016 13:26:00","secondDeposit":100.1,"tax":16.33,"taxExemption":"Goverment Official","totalRate":800,"travelAgentCommissionPercentage":"15%","upgradeReason":"He's a good guy","waterBalance":81.02}
 */
export interface RMSCloudActualAccountBasic {
  /** @format currency */
  accommodationBalance?: number
  accountCurrencyView?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  activeAccounts?: number
  /** @format currency */
  arBalance?: number
  /** @format currency */
  baseRate?: number
  billCategoryType?: string
  createTotalRate?: boolean
  currencyCode?: string
  /** @format currency */
  deposit?: number
  /** @format date-time */
  depositRequiredByDate?: string
  /** @format currency */
  discountAmount?: number
  /** @format int32 */
  discountId?: number
  discountName?: string
  discountReason?: string
  /** @format currency */
  electricityBalance?: number
  /** @format currency */
  extrasBalance?: number
  /** @format currency */
  gasBalance?: number
  hideRateOnCorrespondence?: boolean
  /** @format currency */
  internetBalance?: number
  /** @format currency */
  package?: number
  /** @format currency */
  phoneBalance?: number
  /** @format int32 */
  reservationId?: number
  /** @format currency */
  secondDeposit?: number
  /** @format date-time */
  secondDepositRequiredByDate?: string
  secondaryCurrency?: RMSCloudActualAccountBasicSecondaryCurrency
  /** @format currency */
  tax?: number
  taxExemption?: string
  /** @format currency */
  totalRate?: number
  travelAgentCommissionPercentage?: string
  upgradeReason?: string
  /** @format currency */
  waterBalance?: number
}

export interface RMSCloudActualAccountBasicSecondaryCurrency {
  /** @format currency */
  accommodationBalance?: number
  /** @format currency */
  arBalance?: number
  currencyCode?: string
  /** @format currency */
  electricityBalance?: number
  /** @format currency */
  extrasBalance?: number
  /** @format currency */
  gasBalance?: number
  /** @format currency */
  internetBalance?: number
  /** @format currency */
  phoneBalance?: number
  /** @format currency */
  waterBalance?: number
}

/**
 * Used:<br>POST /availableAddOns
 * @example {"addOnType":"Car Park","addOnTypeId":2,"id":50,"name":"Car Park"}
 */
export interface RMSCloudAddOnArea {
  addOnType?: string
  /** @format int32 */
  addOnTypeId?: number
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>POST /availableAddOns
 * @example {"addOnTypeIds":[50,51],"dateFrom":"2019-11-17 00:00:00","dateTo":"2019-11-29 00:00:00"}
 */
export interface RMSCloudAddOnAvailabilityRequest {
  addOnTypeIds?: number[]
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-time
   */
  dateFrom?: string
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-string
   */
  dateTo?: string
}

/**
 * Used:<br>GET /properties/{id}/addOnType
 * @example {"id":50,"name":"Car Park","propertyId":1}
 */
export interface RMSCloudAddOnCategory {
  /** @format int32 */
  id?: number
  name?: string
  propertyId?: number
}

/**
 * Used:<br>GET /properties/{id}/ibe/addOnType (End Point comment out)
 * @example {"id":50,"name":"Car Park","propertyId":1}
 */
export interface RMSCloudAddOnTypeLite {
  /** @format int32 */
  id?: number
  name?: string
  propertyId?: number
}

/**
 * Used:<br>POST /agents/search<br>POST /companies/search
 * @example {"ids":[12,5,702],"idFrom":6,"idTo":12,"accountIds":[1242,5985,702],"agentType":"onlineAgent","createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","externalReferenceId":"65148","iataNumber":"6568GH","modifiedFrom":"2018-09-25 00:00:00","modifiedTo":"2018-09-27 00:00:00","name":"RMS Book Now","userDefined1":"String 20","userDefined2":"String 50","userDefined3":"String 50","userDefined4":"String 50","userDefined5":"String 50"}
 */
export interface RMSCloudAdvancedSearchRequest {
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined2?: string
  /** @maxLength 50 */
  userDefined3?: string
  /** @maxLength 50 */
  userDefined4?: string
  /** @maxLength 50 */
  userDefined5?: string
  accountIds?: number[]
  agentType?: RMSCloudAdvancedSearchRequestAgentTypeEnum
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  externalReferenceId?: string
  iataNumber?: string
  /** @format int32 */
  idFrom?: number
  /** @format int32 */
  idTo?: number
  ids?: number[]
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  name?: string
}

export enum RMSCloudAdvancedSearchRequestAgentTypeEnum {
  TravelAgent = 'travelAgent',
  OnlineAgent = 'onlineAgent',
  WholeSaler = 'wholeSaler',
  GroupAllotment = 'groupAllotment',
}

/** @example [{"name":"Travel Agent Allotments 05da6737-92ce-4db0-ac82-8a","groupAllotmentId":4175,"groupOptionId":192,"availableFor":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],"daysBeforeRelease":1,"releaseDate":"1900-01-01 00:00:00","releaseMethod":"DaysBefore","discountId":0,"discountReasonId":0,"doNotSellAboveAllotment":false,"fromDate":"2026-08-25 00:00:00","groupStatus":"NotSet","guaranteed":true,"setPermanently":false,"toDate":"2026-08-28 00:00:00","categoryAllotment":[{"propertyId":1,"categoryId":20,"categoryName":"Studio","allotment":1,"allotmentId":99266,"fromDate":"2026-08-25 00:00:00","toDate":"2026-08-28 00:00:00"},{"propertyId":1,"categoryId":23,"categoryName":"One Bedroom Suite","allotment":2,"allotmentId":99283,"fromDate":"2026-08-25 00:00:00","toDate":"2026-08-28 00:00:00"}],"allowUpgradesOutsideofAllotments":false,"holdOriginalSuiteTypeAvailabilityCount":false,"reportingADR":[{"categoryId":20,"reportingADR":0},{"categoryId":23,"reportingADR":0}]}] */
export interface RMSCloudAgentAllotments {
  allowUpgradesOutsideofAllotments?: boolean
  availableFor?: string[]
  categoryAllotment?: RMSCloudAgentAllotmentsCategoryAllotment[]
  /** @format int32 */
  daysBeforeRelease?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  discountReasonId?: number
  doNotSellAboveAllotment?: boolean
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  groupAllotmentId?: number
  /** @format int32 */
  groupOptionId?: number
  groupStatus?: string
  guaranteed?: boolean
  holdOriginalSuiteTypeAvailabilityCount?: boolean
  name?: string
  /** @format date-time */
  releaseDate?: string
  releaseMethod?: string
  reportingADR?: RMSCloudAgentAllotmentsReportingADR[]
  setPermanently?: boolean
  /** @format date-time */
  toDate?: string
}

export interface RMSCloudAgentAllotmentsCategoryAllotment {
  /** @format int32 */
  allotment?: number
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  toDate?: string
}

export interface RMSCloudAgentAllotmentsReportingADR {
  /** @format int32 */
  categoryId?: number
  /** @format float */
  reportingADR?: number
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /onlineAgents<br>GET /travelAgents<br>GET /wholesalers<br>
 * @example {"abn":"tr34937874937","address1":"Level 4, 1230 Nepean Hwy","address2":"","address3":"","bookingSourceId":4,"city":"Cheltenham","cityMasterId":2,"competitorMasterId":8,"countryId":2,"email":"fake@test.com.au","externalRefId":"4dfsf","fax":"25654 54568","iataNumber":"5dfddg","id":3,"inactive":false,"inactiveReason":"out of business","industryMasterId":7,"marketSegmentId":2,"name":"GuestLink","phone":"03 1234 56987","postcode":"2364a","salesSource":"westmeadows","state":"Vic","subMarketSegmentId":5,"tradingAs":"front","userDefined1":"String 20","userDefined2":"String 50","userDefined3":"String 50","userDefined4":"String 50","userDefined5":"String 50"}
 */
export interface RMSCloudAgentBasic {
  address1?: string
  address2?: string
  address3?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined2?: string
  /** @maxLength 50 */
  userDefined3?: string
  /** @maxLength 50 */
  userDefined4?: string
  /** @maxLength 50 */
  userDefined5?: string
  /** Australian Business Number */
  abn?: string
  /** @format int32 */
  bookingSourceId?: number
  city?: string
  /** @format int32 */
  cityMasterId?: number
  /** @format int32 */
  competitorMasterId?: number
  /** @format int32 */
  countryId?: number
  email?: string
  externalRefId?: string
  fax?: string
  iataNumber?: string
  id?: string
  inactive?: boolean
  inactiveReason?: string
  /** @format int32 */
  industryMasterId?: number
  /** @format int32 */
  marketSegmentId?: number
  name?: string
  phone?: string
  postcode?: string
  salesSource?: string
  state?: string
  /** @format int32 */
  subMarketSegmentId?: number
  tradingAs?: string
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /onlineAgents<br>GET /travelAgents<br>GET /wholesalers<br>
 * @example {"abn":"tr34937874937","address1":"Level 4, 1230 Nepean Hwy","address2":"","address3":"","agentType":"onlineAgent","availableToFranchise":false,"billingNote":"Always address bills to Bianca","bookingSourceId":7,"chargeBack":false,"city":"Cheltenham","cityMasterId":1,"cityMasterName":"Bangkok","competitorMasterId":2,"competitorMasterName":"Need Group","countryId":2,"createdById":45,"createdDate":"2018-09-13 00:00:00","creditHold":false,"email":"fake@test.com.au","externalRefId":4,"fax":"25654 54568","franchiseId":0,"glCodeID":8,"iatnNumber":"t895","id":3,"inactive":false,"inactiveReason":"out of business","industryMasterId":4,"marketSegmentId":3,"modifiedById":6,"modifiedDate":"2018-09-27 00:00:00","name":"GuestLink","notes":"Office is on holidays in July","parentId":1,"phone":"03 1234 56987","postcode":"2364a","salesSource":"Bega","state":"Vic","subMarketSegmentId":1,"tradingAs":"Company","userDefined1":"string 20","userDefined2":"string 50","userDefined3":"string 50","userDefined4":"string 50","userDefined5":"string 50"}
 */
export interface RMSCloudAgentFull {
  address1?: string
  address2?: string
  address3?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined2?: string
  /** @maxLength 50 */
  userDefined3?: string
  /** @maxLength 50 */
  userDefined4?: string
  /** @maxLength 50 */
  userDefined5?: string
  /** Australian Business Number */
  abn?: string
  /** @format int32 */
  accountId?: number
  agentType?: RMSCloudAgentFullAgentTypeEnum
  availableToFranchise?: boolean
  billingNote?: string
  /** @format int32 */
  bookingSourceId?: number
  chargeBack?: boolean
  city?: string
  /** @format int32 */
  cityMasterId?: number
  cityMasterName?: string
  /** @format int32 */
  competitorMasterId?: number
  competitorMasterName?: string
  countryId?: string
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  creditHold?: boolean
  email?: string
  externalRefId?: string
  fax?: string
  /** @format int32 */
  franchiseId?: number
  /** @format int32 */
  glCodeID?: number
  iataNumber?: string
  /** @format int32 */
  id?: number
  inActive?: boolean
  inactiveReason?: string
  /** @format int32 */
  industryMasterId?: number
  /** @format int32 */
  marketSegmentId?: number
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  name?: string
  notes?: string
  /** @format int32 */
  parentId?: number
  phone?: string
  postcode?: string
  salesSource?: string
  state?: string
  /** @format int32 */
  subMarketSegmentId?: number
  tradingAs?: string
}

export enum RMSCloudAgentFullAgentTypeEnum {
  TravelAgent = 'travelAgent',
  OnlineAgent = 'onlineAgent',
  WholeSaler = 'wholeSaler',
  GroupAllotment = 'groupAllotment',
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /onlineAgents<br>GET /travelAgents<br>GET /wholesalers<br>
 * @example {"id":3,"name":"GuestLink"}
 */
export interface RMSCloudAgentLite {
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>POST /groupAllotments/allotments/search
 * @example {"createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","fromDate":"2022-09-27 00:00:00","modifiedFrom":"2018-09-25 00:00:00","modifiedTo":"2018-09-27 00:00:00","propertyIds":[1,2],"ids":[12,5,702],"toDate":"2022-09-27 00:00:00"}
 */
export interface RMSCloudAllotmentSearch {
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  /** @format date-time */
  fromDate?: string
  ids?: number[]
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  propertyIds?: number[]
  /** @format date-time */
  toDate?: string
}

/** Not Used */
export interface RMSCloudAllowedProperties {
  /** @format int32 */
  clientId?: number
  clientName?: string
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /areas<br>POST /areas/search<br>GET /areas/{id}<br>GET /areas/{id}/interconnecting<br>GET /categories/{id}/areas
 * @example {"categoryId":2,"cleanStatus":"Clean","description":"Spacious, bright and outward facing rooms measuring 300 m2 and totally refurbished. The room comes with a modern, fully equipped bathroom finished in top quality bronze coloured ceramics and an independent entrance.","extension":"101","guestDescription":"","id":7,"inactive":true,"interconnecting":true,"keyNo1":"","keyNo2":"","name":"Room 3","maxOccupants":4,"propertyId":1}
 */
export interface RMSCloudAreaBasic {
  keyNo1?: string
  keyNo2?: string
  /** @format int32 */
  categoryId?: number
  /** @format enum - Vacant Dirty - Vacant Clean - Occupied - Vacant Inspect - Maintenance */
  cleanStatus?: string
  description?: string
  extension?: string
  guestDescription?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  interconnecting?: boolean
  /** @format int32 */
  maxOccupants?: number
  name?: string
  /** @format int32 */
  propertyId?: number
}

/**
 * Return a list of system default area clean statuses
 * @example [{"id":0,"name":"vacantClean"},{"id":1,"name":"vacantDirty"},{"id":2,"name":"vacantInspect"},{"id":3,"name":"occupied"},{"id":4,"name":"maintenance"}]
 */
export interface RMSCloudAreaCleanStatuses {
  /** @format int32 */
  id?: number
  name?: RMSCloudAreaCleanStatusesNameEnum
}

/**
 * Return custom area clean statuses
 * @example [{"id":1,"name":"status1","dirty":false},{"id":2,"name":"status2","dirty":false},{"id":3,"name":"status3","dirty":true}]
 */
export interface RMSCloudAreaCleanStatusesCustom {
  dirty?: boolean
  /** @format int32 */
  id?: number
  name?: string
}

export enum RMSCloudAreaCleanStatusesNameEnum {
  VacantClean = 'vacantClean',
  VacantDirty = 'vacantDirty',
  VacantInspect = 'vacantInspect',
  Occupied = 'occupied',
  Maintenance = 'maintenance',
}

/**
 * Used:<br>GET /areas/{id}/configuration<br>GET /areas/configuration/search
 * @example {"childrenAllowed":"Not Set","expiryDate":"2020-10-27 00:00:00","floor":"B3","id":1,"latitude":"-37.840935","length":20,"longitude":"144.946457","name":"room 5","numberOfBedrooms":1,"numberOfFullBaths":1,"numberOfHalfBaths":0,"numberOfShowers":1,"petsAllowed":true,"smokingAllowed":true,"squareMeters":300,"width":15}
 */
export interface RMSCloudAreaConfiguration {
  childrenAllowed?: boolean
  /** @format date-time */
  expiryDate?: string
  floor?: string
  /** @format int32 */
  id?: number
  latitude?: string
  length?: number
  longitude?: string
  name?: string
  /** @format int32 */
  numberOfBedrooms?: number
  /** @format int32 */
  numberOfFullBaths?: number
  /** @format int32 */
  numberOfHalfBaths?: number
  /** @format int32 */
  numberOfShowers?: number
  petsAllowed?: RMSCloudAreaConfigurationPetsAllowedEnum
  smokingAllowed?: RMSCloudAreaConfigurationSmokingAllowedEnum
  squareMeters?: number
  width?: number
}

export enum RMSCloudAreaConfigurationPetsAllowedEnum {
  NotSet = 'notSet',
  True = 'true',
  False = 'false',
}

export enum RMSCloudAreaConfigurationSmokingAllowedEnum {
  NotSet = 'notSet',
  True = 'true',
  False = 'false',
}

/**
 * Used:<br>GET /areas/{id}/dwellings
 * @example {"dwellingLength":[{"id":3,"name":"6 ft"},{"id":4,"name":"7 ft"}],"dwellingSlide":[{"id":7,"name":"Double decker"},{"id":8,"name":"Single decker"}],"dwellingType":[{"id":1,"name":"Passenger"},{"id":2,"name":"Tourist"}]}
 */
export interface RMSCloudAreaDwelling {
  dwellingLength?: RMSCloudDwellingLength[]
  dwellingSlide?: RMSCloudDwellingSlide[]
  dwellingType?: RMSCloudDwellingType[]
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /areas<br>POST /areas/search<br>GET /areas/{id}<br>GET /areas/{id}/interconnecting<br>GET /categories/{id}/areas
 * @example {"addressLine1":"16 Yonge Street","addressLine2":"West","addressLine3":" Northshier","areaStats":true,"categoryId":2,"cleanStatus":"Clean","createdDate":"2018-09-27 00:00:00","customCleanStatusId":1,"description":"Spacious, bright and outward facing rooms measuring 300 m2 and totally refurbished. The room comes with a modern, fully equipped bathroom finished in top quality bronze coloured ceramics and an independent entrance.","extension":"101","externalRef":"Ie29374","glCodeId":null,"googleMapLink":null,"guestDescription":null,"id":7,"inactive":true,"interconnecting":true,"keyNo1":null,"keyNo2":null,"name":"Room 3","maxOccupants":4,"modifiedDate":null,"postcode":"3015","printStatement":true,"propertyId":1,"state":"NSW","statisticsStatus":true,"town":"Atlanta","userDefined1":"string 100","userDefined2":"string 20","userDefined3":"string 20","userDefined4":"string 20","userDefined5":"string 20","userDefined6":"string 20","userDefined7":"string 20","userDefined8":"string 20","userDefined9":"string 20","userDefined10":"string 20"}
 */
export interface RMSCloudAreaFull {
  addressLine1?: string
  addressLine2?: string
  addressLine3?: string
  keyNumber1?: string
  keyNumber2?: string
  /** @maxLength 100 */
  userDefined1?: string
  /** @maxLength 20 */
  userDefined10?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  areaStats?: boolean
  /** @format int32 */
  categoryId?: number
  cleanStatus?: string
  /** @format date-time */
  createdDate?: string
  /** @format int32 */
  customCleanStatusId?: number
  description?: string
  extension?: string
  externalRef?: string
  /** @format int32 */
  glCodeId?: number
  googleMapLink?: string
  guestDescription?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  interconnecting?: boolean
  /** @format int32 */
  maxOccupants?: number
  /** @format date-time */
  modifiedDate?: string
  name?: string
  postcode?: string
  printStatement?: boolean
  /** @format int32 */
  propertyId?: number
  state?: string
  statisticsStatus?: boolean
  town?: string
}

/**
 * Return is based on ModelType.<br>Used:<br>GET /areas<br>POST /areas/search<br>GET /areas/{id}<br>GET /categories/{id}/areas
 * @example {"categoryId":3,"id":7,"name":"Room 3","propertyId":1}
 */
export interface RMSCloudAreaLite {
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  propertyId?: number
}

/**
 * Used:<br>POST /areas/search
 * @example {"areaNames":["01 012","01 013"],"categoryIds":[4,5,6],"cleanStatuses":["VacantClean","VacantDirty"],"createdFrom":"2019-11-17 00:00:00","createdTo":"2019-11-29 00:00:00","extensions":["101","302a"],"externalReferences":["Cal","10a"],"guestDescriptions":["room 4","room 5"],"idFrom":10,"ids":[4,12,15],"idTo":20,"inactive":true,"interconnecting":false,"keyNumbers":["11a","12a"],"modifiedFrom":"2020-11-29 00:00:00","modifiedTo":"2020-12-02 00:00:00","propertyIds":[1,3,4],"reservationIds":[10,20]}
 */
export interface RMSCloudAreaSearchRequest {
  areaNames?: string[]
  categoryIds?: number[]
  /** Valid Reservation Status */
  cleanStatuses?: RMSCloudAreaSearchRequestCleanStatusesEnum[]
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  extensions?: string[]
  externalReferences?: string[]
  guestDescriptions?: string[]
  /** @format int32 */
  idFrom?: number
  /** @format int32 */
  idTo?: number
  ids?: number[]
  inactive?: boolean
  interconnecting?: boolean
  keyNumbers?: string[]
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  propertyIds?: number[]
  reservationIds?: number[]
}

export enum RMSCloudAreaSearchRequestCleanStatusesEnum {
  VacantClean = 'VacantClean',
  VacantDirty = 'VacantDirty',
  Occupied = 'Occupied',
  VacantInspect = 'VacantInspect',
  Maintenance = 'Maintenance',
}

/**
 * Used:<br>POST /areas/attributes/search
 * @example {"areaId":5,"attributes":[{"id":1,"name":"Minibar","associatedTo":"Property","availableToIbe":true}],"categoryId":1,"propertyId":1}
 */
export interface RMSCloudAttributeCollection {
  /** @format int32 */
  areaId?: number
  attributes?: RMSCloudAttributes[]
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  propertyId?: number
}

/**
 * Used:<br>GET /areas/{id}/attributes<br>GET /attributes<br>GET /categories/{id}/attributes<br>GET /properties/{id}/attributes<br>
 * @example {"associatedTo":"Property","availableToIbe":true,"id":1,"name":"Minibar"}
 */
export interface RMSCloudAttributeFull {
  associatedTo?: string
  /** Only Applies to Property and category attributes */
  availableToIbe?: boolean
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Not Used
 * @example [{"id":1,"name":"Minibar","associatedTo":"Property","availableToIbe":true},{"id":2,"name":"Balcony","associatedTo":"Property","availableToIbe":true}]
 */
export interface RMSCloudAttributes {
  associatedTo?: string
  /** Only Applies to Property and category attributes */
  availableToIbe?: boolean
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>POST /auditTrail/search<br>POST /auditTrail/rates/search
 * @example {"createdDate":"2020-09-01 00:00:00","entityId":"5","fieldModified":"room","fieldModifiedId":"3","guestId":55895,"holdId":0,"id":12435,"newValue":"3","oldValue":"12","reason":"room upgrade","reservationId":12685,"userId":8,"username":"test","view":"Reservation"}
 */
export interface RMSCloudAuditTrailBasic {
  /** @format date-time */
  createdDate?: string
  entityId?: string
  fieldModified?: string
  /** @format int32 */
  fieldModifiedId?: number
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  holdId?: number
  /** @format int32 */
  id?: number
  newValue?: string
  oldValue?: string
  reason?: string
  /** @format int32 */
  reservationId?: number
  /** @format int32 */
  userId?: number
  username?: string
  view?: string
}

/**
 * Used:<br>POST /auditTrail/rates/search
 * @example {"auditTrailIdFrom":1610828,"auditTrailIdTo":1610828,"dateFrom":"2023-03-13 00:00:00","dateTo":"2023-03-14 00:00:00","rateIds":[2490]}
 */
export interface RMSCloudAuditTrailRateSearch {
  /** @format int32 */
  auditTrailIdFrom?: number
  /** @format int32 */
  auditTrailIdTo?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  propertyIds?: number[]
  rateIds?: number[]
  reservationIds?: number[]
}

/**
 * Used:<br>POST /auditTrail/search<br>
 * @example {"auditTrailIdFrom":1,"auditTrailIdTo":10,"dateFrom":"2020-09-27 00:00:00","dateTo":"2020-09-28 00:00:00","propertyIds":[1,2],"reservationIds":[1234,1546]}
 */
export interface RMSCloudAuditTrailSearch {
  /** @format int32 */
  auditTrailIdFrom?: number
  /** @format int32 */
  auditTrailIdTo?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  propertyIds?: number[]
  rateIds?: number[]
  reservationIds?: number[]
}

/**
 * Used:<br>POST /authToken
 * @example {"agentId":15,"agentPassword":"1h&29$vk449f8","clientId":11281,"clientPassword":"6k!Dp$N4","useTrainingDatabase":false,"moduleType":["kiosk"]}
 */
export interface RMSCloudAuthTokenRequest {
  /** @format int32 */
  agentId: number
  agentPassword: string
  /**
   * Request the Live credentials for this from the client
   * @format int32
   */
  clientId: number
  /** Request the Live credentials for this from the client, when requesting this use the wording 'Web Service password' */
  clientPassword: string
  moduleType: string[]
  /**
   * When set to 'True' this will allow you to connect to a copy of the customers data instead of their production data
   * @default false
   */
  useTrainingDatabase?: boolean
}

/**
 * Used:<br>POST /authToken
 * @example {"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZ2lkIjoiMTUiLCJjbGlk","expiryDate":"2024-07-13 00:14:42","rmsClientId":11281,"allowedProperties":[{"clientName":"API Test Database","clientId":11281},{"clientName":"Test property 1","clientId":11282},{"clientName":"Test property 2","clientId":11283},{"clientName":"Test property 3","clientId":11284}]}
 */
export interface RMSCloudAuthTokenResponse {
  allowedProperties?: RMSCloudAllowedProperties[]
  /** @format date-time */
  expiryDate?: string
  /** @format int32 */
  rmsClientId?: number
  token?: string
}

/**
 * Used:<br>POST /reservations/autoAllocateAreas
 * @example {"reservationIds":[165654,5464564,5465465]}
 */
export interface RMSCloudAutoAllocateAreaRequest {
  reservationIds?: number[]
}

/**
 * Used:<br>POST /reservations/autoAllocateAreas
 * @example {"areaId":12,"errorMessage":"","reservationId":162630,"success":true}
 */
export interface RMSCloudAutoAllocateAreaResponse {
  /** @format int32 */
  areaId?: number
  errorMessage?: string
  /** @format int32 */
  reservationId?: number
  success?: boolean
}

/** Not Used. */
export interface RMSCloudAvailabilityCategory {
  availability?: RMSCloudAvailabilityDate[]
  /** @format int32 */
  id?: number
  name?: string
}

/** Not Used. */
export interface RMSCloudAvailabilityDate {
  /** @format int32 */
  count?: number
  /** @format date */
  theDate?: string
}

/** Used:<br>POST /availabilityGrid */
export interface RMSCloudAvailabilityGridRequest {
  /** @format int32 */
  agentId?: number
  allotmentAssociationId?: RMSCloudAvailabilityGridRequestAllotmentAssociationIdEnum
  /** @format int32 */
  allotmentId?: number
  availabilityFilter?: RMSCloudAvailabilityGridRequestAvailabilityFilterEnum
  /**
   * A maximum of 90 days worth of data can be returned
   * @format date-time
   */
  dateFrom?: string
  /**
   * A maximum of 90 days worth of data can be returned
   * @format date-time
   */
  dateTo?: string
  /** @format int32 */
  propertyId?: number
  /** Will remove any dirty areas from todays availability */
  removeDirtyRoomsFromAvailabilityForToday?: boolean
  roomStatistics?: RMSCloudAvailabilityGridRequestRoomStatisticsEnum
}

export enum RMSCloudAvailabilityGridRequestAllotmentAssociationIdEnum {
  NotSet = 'NotSet',
  TravelAgent = 'TravelAgent',
  Wholesaler = 'Wholesaler',
}

export enum RMSCloudAvailabilityGridRequestAvailabilityFilterEnum {
  House = 'house',
  Full = 'full',
}

export enum RMSCloudAvailabilityGridRequestRoomStatisticsEnum {
  Ignore = 'ignore',
  True = 'true',
  False = 'false',
}

/**
 * Used:<br>POST /availabilityGrid
 * @example {"categories":[{"availability":[{"count":7,"theDate":"2021-11-05"},{"count":8,"theDate":"2021-11-06"}],"id":4,"name":""},{"availability":[{"count":13,"theDate":"2021-11-05"},{"count":5,"theDate":"2021-11-06"}],"id":5,"name":""}]}
 */
export interface RMSCloudAvailabilityGridResponse {
  categories?: RMSCloudAvailabilityCategory[]
}

/** Not Used. */
export interface RMSCloudAvailabilityRateCategory {
  /** @format int32 */
  billingCategoryId?: number
  /** @format int32 */
  categoryId?: number
  name?: string
  rates?: RMSCloudAvailabilityRateRate[]
}

/**
 * Used:<br>POST /availabilityRateGrid
 * @example {"adults":2,"agentId":1,"categoryIds":[4,3],"children":0,"dateFrom":"2019-11-17 00:00:00","dateTo":"2019-11-29 00:00:00","infants":0,"propertyId":1,"rateIds":[1380,1159]}
 */
export interface RMSCloudAvailabilityRateGridRequest {
  /** @format int32 */
  adults?: number
  /** @format int32 */
  agentId?: number
  categoryIds?: number[]
  /** @format int32 */
  children?: number
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-time
   */
  dateFrom?: string
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-string
   */
  dateTo?: string
  /** @format int32 */
  infants?: number
  /** @format int32 */
  propertyId?: number
  rateIds?: number[]
}

/**
 * Used:<br>POST /availabilityRateGrid
 * @example {"categories":[{"billingCategoryId":0,"categoryId":4,"name":"Deluxe 004","rates":[{"dayBreakdown":[{"availableAreas":5,"closedOnArrival":false,"closedOnDeparture":false,"dailyRate":5418,"maxStay":"0,","minStay":0,"minStayOnArrival":"0,","theDate":"2023-08-15 00:00:00","stopSell":false}],"name":"Testing Rate","personBase":0,"rateId":1416}]}]}
 */
export interface RMSCloudAvailabilityRateGridResponse {
  categories?: RMSCloudAvailabilityRateCategory[]
}

/** Not Used. */
export interface RMSCloudAvailabilityRateRate {
  dayBreakdown?: RMSCloudDayBreakdown[]
  name?: string
  /** @format int32 */
  personBase?: number
  /** @format int32 */
  rateId?: number
}

/**
 * Used:<br>POST /availableAreas<br>
 * @example {"categoryIds":[4,3],"dateFrom":"2023-11-17 00:00:00","dateTo":"2023-11-29 00:00:00","dwelling":{"lengthId":1,"slideId":2,"typeId":2},"propertyId":0,"useDefaultTimes":true}
 */
export interface RMSCloudAvailableAreaRequest {
  categoryIds?: number[]
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-time
   */
  dateFrom?: string
  /**
   * A maximum of 14 days worth of data can be returned
   * @format date-string
   */
  dateTo?: string
  dwelling?: RMSCloudAvailableAreaRequestDwelling
  /** @format int32 */
  propertyId?: number
  /** If passed in as True, the default category times will be used as the time portion of the dateFrom and dateTo values. */
  useDefaultTimes?: boolean
}

export interface RMSCloudAvailableAreaRequestDwelling {
  /** @format int32 */
  lengthId?: number
  /** @format int32 */
  slideId?: number
  /** @format int32 */
  typeId?: number
}

/**
 * Used:<br>POST /availableAreas
 * @example {"categoryId":2,"cleanStatus":"Clean","description":"Spacious, bright and outward facing rooms measuring 300 m2 and totally refurbished. The room comes with a modern, fully equipped bathroom finished in top quality bronze coloured ceramics and an independent entrance.","extension":"101","guestDescription":"","id":7,"inactive":true,"interconnecting":true,"keyNo1":null,"keyNo2":null,"maxOccupants":4,"name":"Room 3","propertyId":1}
 */
export interface RMSCloudAvailableAreaResponse {
  keyNo1?: string
  keyNo2?: string
  /** @format int32 */
  categoryId?: number
  /** @format enum - Vacant Dirty - Vacant Clean - Occupied - Vacant Inspect - Maintenance */
  cleanStatus?: string
  description?: string
  extension?: string
  guestDescription?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  interconnecting?: boolean
  /** @format int32 */
  maxOccupants?: number
  name?: string
  /** @format int32 */
  propertyId?: number
}

/**
 * Used:<br>GET /reservations/{id}/bedConfiguration
 * @example {"id":1,"name":"King","quantity":2}
 */
export interface RMSCloudBedConfiguration {
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  quantity?: number
}

/**
 * Used:<br>GET /bookingSources<br>GET /properties/{id}/ibe/bookingSources
 * @example {"code":"4 goh","id":1,"inactive":true,"name":"Return Guest"}
 */
export interface RMSCloudBookingSourceBasic {
  code?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
}

/** @example {"accessNumber":"632283","theDate":"2024-07-23 16:00:33","boomgateId":1,"comment":"Gate","valid":true} */
export interface RMSCloudBoomgatesHistory {
  accessNumber: string
  boomgateId: number
  comment: string
  /** @format date-time */
  theDate: string
  valid: boolean
}

/**
 * Used:<br> GET /cancellationPoliciesRules
 * @example [{"propertyId":1,"description":"Cancellation property1","mandatoryCancellationNote":true,"voidRateCharges":true,"periodMethod":"DaysFromArrival","rule1":{"feeType":"Sundry","period":15,"sundryId":1431,"firstXNights":0,"amount":0,"percentage":0},"rule2":{"feeType":"FirstXNights","period":10,"sundryId":0,"firstXNights":1,"amount":0,"percentage":0},"rule3":{"feeType":"AmountOrPercentage","period":5,"sundryId":1357,"firstXNights":0,"amount":25,"percentage":0},"rule4":{"feeType":"AmountOrPercentage","period":0,"sundryId":0,"firstXNights":0,"amount":0,"percentage":100}},{"propertyId":0,"description":"You can cancel half a day before. Cause so.","mandatoryCancellationNote":false,"voidRateCharges":true,"periodMethod":"HoursFromArrival","rule1":{"feeType":"FirstXNights","period":3,"sundryId":0,"firstXNights":1,"amount":0,"percentage":0},"rule2":{"feeType":"FirstXNights","period":6,"sundryId":0,"firstXNights":3,"amount":0,"percentage":0},"rule3":{"feeType":"AmountOrPercentage","period":9,"sundryId":0,"firstXNights":0,"amount":50,"percentage":0},"rule4":{"feeType":"AmountOrPercentage","period":12,"sundryId":0,"firstXNights":0,"amount":0,"percentage":20}}]
 */
export interface RMSCloudCancellationPoliciesRules {
  rule1?: RMSCloudCancellationPoliciesRulesRule1
  rule2?: RMSCloudCancellationPoliciesRulesRule1
  rule3?: RMSCloudCancellationPoliciesRulesRule1
  rule4?: RMSCloudCancellationPoliciesRulesRule1
  description?: string
  mandatoryCancellationNote?: boolean
  periodMethod?: string
  propertyId?: number
  voidRateCharges?: boolean
}

export interface RMSCloudCancellationPoliciesRulesRule1 {
  amount?: number
  feeType?: string
  firstXNights?: number
  percentage?: number
  period?: number
  sundryId?: number
}

/**
 * Used:<br>POST /cancellationPolicies
 * @example {"code":"c21","description":"Coolangatta 21","id":1,"makeCancellationNoteMandatory":true,"nonCancellationPeriodInHours":48,"shortDescription":"Coolangatta the bestest place evs"}
 */
export interface RMSCloudCancellationPolicy {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  makeCancellationNoteMandatory?: boolean
  /** @format int32 */
  nonCancellationPeriodInHours?: number
  shortDescription?: string
}

/**
 * Used:<br>GET /categories<br>GET /categories/{id}<br>GET /properties/{id}/categories
 * @example {"allowBookingByCategory":true,"availableToIbe":true,"categoryClass":"Accommodation","categoryTypeGroupingId":4,"defaultArrivalTime":"14:00:00","defaultDepartureTime":"10:00:00","glCodeId":9,"id":1,"inactive":false,"interconnecting":false,"longDescription":"LUXURY WATER FRONT LIVING! With the finest of fixtures and fittings .....","name":"Queen Bedroom","numberOfAreas":35,"maxOccupantsPerCategory":6,"maxOccupantsPerCategoryType":32,"propertyId":1}
 */
export interface RMSCloudCategoryBasic {
  allowBookingByCategory?: boolean
  availableToIbe?: boolean
  categoryClass?: string
  /** @format int32 */
  categoryTypeGroupingId?: number
  /** @format time */
  defaultArrivalTime?: string
  /** @format time */
  defaultDepartureTime?: string
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  interconnecting?: boolean
  longDescription?: string
  /** @format int32 */
  maxOccupantsPerCategory?: number
  /** @format int32 */
  maxOccupantsPerCategoryType?: number
  name?: string
  /** @format int32 */
  numberOfAreas?: number
  /** @format int32 */
  propertyId?: number
}

/**
 * Used:<br>GET /categories<br>GET /categories/{id}<br>GET /properties/{id}/categories
 * @example {"allowBookingByCategory":true,"allowMultipleReservationsOverTheSameTime":true,"allowOverbooking":true,"availableToKiosk":true,"availableToIbe":true,"billingCategoryId":0,"categoryClass":"Accommodation","categoryManagerId":6,"categoryTypeGroupingId":4,"code":"2dr","code2":"99brd","code3":"tw25","dynamicPricingGroupingId":9,"glCodeId":9,"guestDescription":"Waterfront Room","headline":"Cheap room","id":1,"inactive":false,"includeOnHouseKeepersReport":false,"interconnecting":false,"inventoryGrouping":false,"longDescription":"LUXURY WATER FRONT LIVING! With the finest of fixtures and fittings .....","maxOccupantsPerCategory":6,"maxOccupantsPerCategoryType":32,"minimumOccupantsPerRoom":2,"minNightlyRate":35.26,"modifiedDate":"10:00:00","name":"Queen Bedroom","numberOfAreas":35,"numberOfBedrooms":1,"numberOfFullBaths":1,"numberOfHalfBaths":0,"numberOfOverbookingsAllowed":4,"numberOfRoomsToHoldFromIBE":1,"numberOfShowers":1,"propertyId":1,"rentalPerSqrMtr":354,"userDefined1":"String 500","userDefined2":"String 500","userDefined3":"String 500","userDefined4":"String 500","userDefined5":"String 500","userDefined6":"String 500","userDefined7":"String 500","userDefined8":"String Max","userDefined9":"String Max"}
 */
export interface RMSCloudCategoryFull {
  code2?: string
  code3?: string
  /** @maxLength 500 */
  userDefined1?: string
  /** @maxLength 500 */
  userDefined2?: string
  /** @maxLength 500 */
  userDefined3?: string
  /** @maxLength 500 */
  userDefined4?: string
  /** @maxLength 500 */
  userDefined5?: string
  /** @maxLength 500 */
  userDefined6?: string
  /** @maxLength 500 */
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
  allowBookingByCategory?: boolean
  allowMultipleReservationsOverTheSameTime?: boolean
  allowOverbooking?: boolean
  /** This setting determines the number of Rooms held back from availability to any connected Online Travel Agents within this Category. Holding back Rooms provides a contingency for avoiding multiple bookings being made online simultaneously for your last available Room. RMS recommends setting this to a minimum of 1. Where only one Room exists within the Category this figure will be ignored. */
  availableToIbe?: boolean
  availableToKiosk?: boolean
  /** @format int32 */
  billingCategoryId?: number
  categoryClass?: string
  /** @format int32 */
  categoryManagerId?: number
  /** @format int32 */
  categoryTypeGroupingId?: number
  code?: string
  /** @format int32 */
  dynamicPricingGroupingId?: number
  /** @format int32 */
  glCodeId?: number
  guestDescription?: string
  headline?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  includeOnHouseKeepersReport?: boolean
  interconnecting?: boolean
  interconnectingAreaId?: number[]
  inventoryGrouping?: boolean
  longDescription?: string
  /** @format int32 */
  maxOccupantsPerCategory?: number
  /** @format int32 */
  maxOccupantsPerCategoryType?: number
  /** @format currency */
  minNightlyRate?: number
  /** @format int32 */
  minimumOccupantsPerRoom?: number
  /** @format time */
  modifiedDate?: string
  name?: string
  /** @format int32 */
  numberOfAreas?: number
  /** @format int32 */
  numberOfBedrooms?: number
  /** @format int32 */
  numberOfFullBaths?: number
  /** @format int32 */
  numberOfHalfBaths?: number
  /** @format int32 */
  numberOfOverbookingsAllowed?: number
  /** @format int32 */
  numberOfRoomsToHoldFromIBE?: number
  /** @format int32 */
  numberOfShowers?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  rentalPerSqrMtr?: number
}

/** @example [{"categoryId":10,"housekeepingTasks":[{"taskId":1,"name":"Pre Arrival Check"},{"taskId":2,"name":"Departure"},{"taskId":3,"name":"Supervisor Inspection"}],"bedConfiguration":[{"bedConfigurationId":3,"name":"King","quantity":1}],"customAreaCleanStatuses":[{"id":1,"name":"Status 1","minutes":0},{"id":2,"name":"Status 2","minutes":30},{"id":3,"name":"Status 3","minutes":60}]}] */
export interface RMSCloudCategoryHousekeeping {
  bedConfiguration?: RMSCloudCategoryHousekeepingBedConfiguration[]
  /** @format int32 */
  categoryId?: number
  customAreaCleanStatus?: RMSCloudCategoryHousekeepingCustomAreaCleanStatus[]
  housekeepingTasks?: RMSCloudCategoryHousekeepingHousekeepingTasks[]
}

export interface RMSCloudCategoryHousekeepingBedConfiguration {
  /** @format int32 */
  bedConfigurationId?: number
  name?: string
  quantity?: string
}

export interface RMSCloudCategoryHousekeepingCustomAreaCleanStatus {
  /** @format int32 */
  id?: number
  minutes?: string
  name?: string
}

export interface RMSCloudCategoryHousekeepingHousekeepingTasks {
  name?: string
  /** @format int32 */
  taskId?: number
}

/**
 * Used:<br>GET /categories<br>GET /categories/{id}<br>GET /properties/{id}/categories
 * @example {"id":1,"name":"Queen Bedroom","propertyId":1}
 */
export interface RMSCloudCategoryLite {
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  propertyId?: number
}

/**
 * Used:<br>GET /categories/{id}/onlineOptions
 * @example {"availableToIBE":true,"headline":"Cheap room","id":5,"minimumOccupantsPerRoom":2,"numberOfBedrooms":1,"numberOfFullBaths":1,"numberOfHalfBaths":0,"numberOfRoomsToHoldFromIBE":1,"numberOfShowers":1}
 */
export interface RMSCloudCategoryOnlineOptions {
  /** This setting determines the number of Rooms held back from availability to any connected Online Travel Agents within this Category. Holding back Rooms provides a contingency for avoiding multiple bookings being made online simultaneously for your last available Room. RMS recommends setting this to a minimum of 1. Where only one Room exists within the Category this figure will be ignored. */
  availableToIBE?: boolean
  headline?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  minimumOccupantsPerRoom?: number
  /** @format int32 */
  numberOfBedrooms?: number
  /** @format int32 */
  numberOfFullBaths?: number
  /** @format int32 */
  numberOfHalfBaths?: number
  /** @format int32 */
  numberOfRoomsToHoldFromIBE?: number
  /** @format int32 */
  numberOfShowers?: number
}

/**
 * Used:<br>GET /companies/{id}/rates<br>
 * @example {"fromDate":"2023-05-31 00:00:00","id":1416,"name":"Testing Rate","propertyId":1,"toDate":"2023-08-31 00:00:00"}
 */
export interface RMSCloudChargeTypeLite {
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  toDate?: string
}

/** @example {"id":7,"companyId":1,"fromDate":"2024-08-02 00:00:00","toDate":"2024-12-02 00:00:00","rateId":1,"rateName":"BAR","propertyId":1,"propertyName":"Test Property 1"} */
export interface RMSCloudCompaniesRatesAssignmentsFull {
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  /** @format int32 */
  rateId?: number
  rateName?: string
  /** @format date-time */
  toDate?: string
}

/**
 * Used:<br>GET /companies<br>GET /companies/{id}<br>
 * @example {"id":78,"name":"Mians","abn":"123A 2596 5E89","acn":"5986 9856 569 6","address1":"25","address2":"fake street","address3":"north","address4":"ftizfield","averageIncome":"52000","bookingSourceId":986,"cityMasterId":235,"code":"12A","competitorMasterId":3,"contact":"Wayne","countryid":2,"creditHold":true,"creditLimit":"986","email":"fake@email.com.au","fax":"03 4569 4569","given":"bob","inactive":false,"inactiveReason":"Old Account","notes":"This is a note","parentId":784,"phone":"03 5986 4875","postcode":"0425","reservationTypeId":45,"sendArToHeadOffice":true,"state":"Victoria","surname":"hobbs","title":"Mr","totalIncome":23.56,"tradingAs":"Melb Corp","userDefined1":"String 20","userDefined2":"String 50","userDefined3":"String 50","userDefined4":"String 50","userDefined5":"String 50","webAddress":"www.melbcorp.com"}
 */
export interface RMSCloudCompanyBasic {
  address1?: string
  address2?: string
  address3?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined2?: string
  /** @maxLength 50 */
  userDefined3?: string
  /** @maxLength 50 */
  userDefined4?: string
  /** @maxLength 50 */
  userDefined5?: string
  /** Australian Business Number */
  abn?: string
  /** Australian Company Number */
  acn?: string
  /**
   * This field is informational, any changes made will not be honoured
   * @format currency
   */
  averageIncome?: number
  /** @format int32 */
  bookingSourceId?: number
  city?: string
  cityMaster?: string
  /** @format int32 */
  cityMasterId?: number
  code?: string
  /** @format int32 */
  competitorMasterId?: number
  contact?: string
  contactPosition?: string
  /** @format int32 */
  countryid?: number
  creditHold?: boolean
  /** @format decimal */
  creditLimit?: number
  email?: string
  fax?: string
  given?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  inactiveReason?: string
  name?: string
  notes?: string
  /** @format int32 */
  parentId?: number
  phone?: string
  postcode?: string
  /** @format int32 */
  reservationTypeId?: number
  sendArToHeadOffice?: string
  state?: string
  surname?: string
  /**
   * This field is informational, any changes made will not be honoured
   * @format currency
   */
  totalIncome?: number
  tradingAs?: string
  webAddress?: string
}

/** @example {"id":78,"name":"Mians","abn":"123A 2596 5E89","acn":"5986 9856 569 6","accountId":18001,"address1":"25","address2":"fake street","address3":"north","averageIncome":"52000","bookingSource":"AusCorp","bookingSourceId":986,"branch":" dellas","city":"ftizfield","cityMaster":"NSW","cityMasterId":235,"code":"12A","competitorMaster":"Rex Group","competitorMasterId":3,"contact":"Wayne","contactPosition":"Lodge Manager","country":"ukraine","createdById":5,"createdDate":"2018-09-27 16:00:00","creditHold":true,"creditLimit":"986","email":"fake@email.com.au","fax":"03 4569 4569","hideRateFromCorrespondence":false,"inactive":false,"inactiveReason":"Old Account","industryMasterId":25,"lastVisit":"2018-09-25 17:25:00","modifiedById":85,"modifiedDate":"2019-09-25 17:25:00","notes":"This is a note","numberOfVisits":56,"parentId":784,"phone":"03 5986 4875","postcode":"0425","resType":"Staff","resTypeId":45,"sendArToHeadOffice":true,"state":"Victoria","totalIncome":23.56,"tradingAs":"Melb Corp","userDefined1":"String 20","userDefined2":"String 50","userDefined3":"String 50","userDefined4":"String 50","userDefined5":"String 50","webAddress":"www.melbcorp.com"} */
export interface RMSCloudCompanyFull {
  address1?: string
  address2?: string
  address3?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined2?: string
  /** @maxLength 50 */
  userDefined3?: string
  /** @maxLength 50 */
  userDefined4?: string
  /** @maxLength 50 */
  userDefined5?: string
  /** Australian Business Number */
  abn?: string
  /** @format int32 */
  accountId?: number
  /** Australian Company Number */
  acn?: string
  /** @format currency */
  averageIncome?: number
  bookingSource?: string
  /** @format int32 */
  bookingSourceId?: number
  branch?: string
  city?: string
  cityMaster?: string
  /** @format int32 */
  cityMasterId?: number
  code?: string
  competitorMaster?: string
  /** @format int32 */
  competitorMasterId?: number
  contact?: string
  contactPosition?: string
  country?: string
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  creditHold?: boolean
  /** @format decimal */
  creditLimit?: number
  email?: string
  fax?: string
  hideRateFromCorrespondence?: boolean
  /** @format int32 */
  id?: number
  inactive?: boolean
  inactiveReason?: string
  /** @format int32 */
  industryMasterId?: number
  /** @format date-time */
  lastVisit?: string
  /** @format int32 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  name?: string
  notes?: string
  /** @format int32 */
  numberOfVisits?: number
  /** @format int32 */
  parentId?: number
  phone?: string
  postcode?: string
  resType?: string
  /** @format int32 */
  resTypeId?: number
  sendARToHeadOffice?: string
  state?: string
  /** @format currency */
  totalIncome?: number
  tradingAs?: string
  webAddress?: string
}

/** @example {"companyIds":[4,12,15]} */
export interface RMSCloudCompanyIds {
  companyIds?: number[]
}

/**
 * Used:<br>GET /companies<br>GET /companies/{id}<br>
 * @example {"id":78,"name":"Mians"}
 */
export interface RMSCloudCompanyLite {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"address1":"123 Main St","address2":"Apt 4B","address3":"","city":"Springfield","postcode":"12345","countryid":1,"state":"IL","abn":"123456789","accounttypeid":2,"acn":"987654321","averageincome":55000,"billingnote":"Billing cycle is monthly","bookingsourceid":3,"citymasterid":4,"code":"SPR001","contact":"John Doe","contactposition":"Manager","credithold":false,"competitormasterid":5,"creditlimit":10000,"email":"john.doe@example.com","fax":"123-456-7890","given":"John","hideratefromcorrespondence":true,"inactive":false,"industrymasterid":6,"markettypeid":7,"name":"Doe Enterprises","notes":"Preferred customer","phone":"123-456-7890","reservationTypeId":8,"sendartoheadoffice":true,"surname":"Doe","totalincome":120000,"tradingas":"Doe & Co.","userdefined1":"Custom Field 1","userdefined2":"Custom Field 2","userdefined3":"Custom Field 3","userdefined4":"Custom Field 4","userdefined5":"Custom Field 5","userrepid":9} */
export interface RMSCloudCompanyPatch {
  address1?: string
  address2?: string
  address3?: string
  userdefined1?: string
  userdefined2?: string
  userdefined3?: string
  userdefined4?: string
  userdefined5?: string
  abn?: string
  /** @format integer */
  accounttypeid?: number
  acn?: string
  averageincome?: number
  billingnote?: string
  /** @format integer */
  bookingsourceid?: number
  city?: string
  /** @format integer */
  citymasterid?: number
  code?: string
  /** @format integer */
  competitormasterid?: number
  contact?: string
  contactposition?: string
  /** @format integer */
  countryid?: number
  credithold?: boolean
  creditlimit?: number
  email?: string
  fax?: string
  given?: string
  hideratefromcorrespondence?: boolean
  inactive?: boolean
  /** @format integer */
  industrymasterid?: number
  /** @format integer */
  markettypeid?: number
  name?: string
  notes?: string
  phone?: string
  postcode?: string
  /** @format integer */
  reservationTypeId?: number
  sendartoheadoffice?: boolean
  state?: string
  surname?: string
  totalincome?: number
  tradingas?: string
  /** @format integer */
  userrepid?: number
}

/** @example {"id":16,"address1":"51 fake st","address2":"West town","address3":"South Side","city":"Melbourne","contactType":"Company","countryId":2,"createdById":2,"createdDate":"2020-08-04 00:00:00","email":"test@fake.com.au","fax":"03 9865 8954","given":"Tom","groupingId":4,"mobile":"0411235985","modifiedById":5,"modifiedDate":"2020-08-05 00:00:00","pager":"265954895","phoneAh":"03 9856 9856","phoneBh":"02 5969 5698","position":"Receptionist","postcode":"3042","referenceId":"20A","relationshipId":7,"state":"Victoria","surname":"Newman","title":"Mr"} */
export interface RMSCloudContact {
  address1?: string
  address2?: string
  address3?: string
  city?: string
  contactType?: string
  /** @format int32 */
  countryId?: number
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  email?: string
  fax?: string
  given?: string
  /** @format int32 */
  groupingId?: number
  mobile?: string
  /** @format int32 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  pager?: string
  phoneAh?: string
  phoneBh?: string
  position?: string
  postcode?: string
  referenceId?: string
  /** @format int32 */
  relationship?: number
  state?: string
  surname?: string
  title?: string
}

/** @example {"id":2564,"attachment":"consent form.pdf","code":"15a","correspondenceType":"Email","description":"CC Registration","guestId":103,"readDate":"2018-09-25 17:25:00","reservationId":3503,"sentDate":"2018-09-25 17:25:00","userId":7,"userName":"*hp"} */
export interface RMSCloudCorrespondence {
  attachment?: string
  code?: string
  correspondenceType?: string
  description?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  /** @format date-time */
  readDate?: string
  /** @format int32 */
  reservationId?: number
  /** @format date-time */
  sentDate?: string
  /** @format int32 */
  userId?: number
  userName?: string
}

/** @example {"caption":"Signature","id":5,"url":"https://images.rmscloud.com/rmsoimages/6880/rmswin/rmsonlineimages/00000090.jpg"} */
export interface RMSCloudCorrespondenceSignature {
  'url:'?: string
  caption?: string
  /** @format int32 */
  id?: number
}

/** @example {"id":1,"name":"Australia"} */
export interface RMSCloudCountry {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"acknowledgementQuestion1":"Do you declare you have not been overseas in the past 14 days?","acknowledgementQuestion2":"Do you declare you have not been interstate in the past 14 days?","acknowledgementQuestion3":"Do you declare you are not required to be in self-isolation/self-quarantine?","acknowledgementQuestion4":"Do you declare you have not previously been diagnosed with COVID-19?","acknowledgementQuestion5":"Do you declare to the best of you knowledge, you have not been in close contact with a person who has a reported or suspected case of coronavirus (COVID-19) in the past 14 days?","acknowledgementQuestion6":"Do you declare you have not been in a COVID-19 hotspot (as defined by the Chief Health Officer) in the past 14 days?","acknowledgementQuestion7":"Do you declare you have not had a fever, cough, sore throat, shortness of breath or other cold/flu-like symptoms in the last 72 hours and are otherwise well?","acknowledgementQuestion8":"Do yu declare you are healthy?","acknowledgementQuestion9":"Do you declare you have not been in contact with anyone unhealthy?","acknowledgementQuestion10":"Do you declare you have no symptons of sickness?"} */
export interface RMSCloudCovidAckowledgement {
  acknowledgementQuestion1?: string
  acknowledgementQuestion10?: string
  acknowledgementQuestion2?: string
  acknowledgementQuestion3?: string
  acknowledgementQuestion4?: string
  acknowledgementQuestion5?: string
  acknowledgementQuestion6?: string
  acknowledgementQuestion7?: string
  acknowledgementQuestion8?: string
  acknowledgementQuestion9?: string
}

/** @example {"id":5,"name":"Visa"} */
export interface RMSCloudCreditCard {
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>GET /properties/{id}/creditCards/fees<br>POST /properties/creditCards/fees/search
 * @example {"cardId":3,"cardName":"Amex","gatewayTransactionFee":10,"glCodeId":37,"merchantFeeNoGreaterThan":0,"merchantFeePercentage":0,"propertyId":1}
 */
export interface RMSCloudCreditCardFee {
  /** @format int32 */
  cardId?: number
  cardName?: string
  /** @format currency */
  gatewayTransactionFee?: number
  /** @format int32 */
  glCodeId?: number
  /** @format currency */
  merchantFeeNoGreaterThan?: number
  /** @format currency */
  merchantFeePercentage?: number
  /** @format int32 */
  propertyid?: number
}

/**
 * Used:<br>POST /properties/creditCards/fees/search
 * @example {"cardIds":[3],"propertyIds":[0,1]}
 */
export interface RMSCloudCreditCardFeeSearch {
  cardIds?: number[]
  propertyIds?: number[]
}

/** Used:<br>GET /companies/{id}/accountsReceivable<br>POST /companies/{id}/accountsReceivable<br>PUT /companies/{id}/accountsReceivable/{arId}<br>GET /travelAgents/{id}/accountsReceivable<br>POST /travelAgents/{id}/accountsReceivable<br>PUT /travelAgents/{id}/accountsReceivable/{arId} */
export interface RMSCloudCreditHoldBasic {
  creditHold?: boolean
  /** @format currency */
  creditLimit?: number
  /** @format int32 */
  creditTerms?: number
  /** @format int32 */
  groupingId?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
}

/** @example {"id":3,"name":"Coke Can","assigned":true,"costPrice":1,"currencyView":"Local Currency","gLCodeName":"Accommodation Revenue","gLCodeId":0,"grouping":"Group 1","groupingId":1,"hasTaxes":true,"inactive":false,"secondCurrency":0,"unitPrice":2.5} */
export interface RMSCloudCreditNote {
  assigned?: boolean
  /** @format currency */
  costPrice?: number
  currencyView?: string
  /** @format int32 */
  gLCodeId?: number
  gLCodeName?: string
  grouping?: string
  /** @format int32 */
  groupingId?: number
  hasTaxes?: boolean
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
  /** @format currency */
  secondCurrency?: number
  /** @format currency */
  unitPrice?: number
}

export interface RMSCloudCurrency {
  PrimaryCurrencyDescription?: string
  /** @format int32 */
  primaryCurrencyId?: number
  primaryCurrencyName?: string
  primaryCurrencySymbol?: string
  secondaryCurrencyDescription?: string
  /** @format int32 */
  secondaryCurrencyId?: number
  secondaryCurrencyName?: string
  secondaryCurrencySymbol?: string
}

/** @example {"reservationId":3678,"additionalsAmount":0,"currency":"AUD","discountAmount":29.25,"dynamicAmount":0,"exclusiveTax":0,"linkedRateAdjustmentAmount":0,"packageAmount":0,"rateAmount":292.5,"rateId":12,"ratePeriod":7,"rateTable":15,"rateTypeId":15,"stayDate":"28-04-2019 12:00:00","totalRateAmount":800.25,"xNightsDiscount":0,"packageAmountIncludedInRateAmount":20} */
export interface RMSCloudDailyRate {
  /** @format currency */
  additionalsAmount?: number
  currency?: string
  /** @format currency */
  discountAmount?: number
  /** @format currency */
  dynamicAmount?: number
  /** @format currency */
  exclusiveTax?: number
  /** @format currency */
  linkedRateAdjustmentAmount?: number
  /** @format currency */
  packageAmount?: number
  /** @format currency */
  packageAmountIncludedInRateAmount?: number
  /** @format currency */
  rateAmount?: number
  /** @format int32 */
  rateId?: number
  /** @format int32 */
  ratePeriod?: number
  /** @format int32 */
  rateTable?: number
  /** @format int32 */
  rateTypeId?: number
  /** @format int32 */
  reservationId?: number
  /** @format date-time */
  stayDate?: string
  /** @format currency */
  totalRateAmount?: number
  /** @format currency */
  xNightsDiscount?: number
}

/**
 * Used:<br>POST /reservations/dailyRates/search
 * @example [{"additionalsAmount":0,"currency":"AUD","discountAmount":29.25,"dynamicAmount":800,"exclusiveTax":0,"linkedRateAdjustmentAmount":0,"packageAmount":0,"rateAmount":800,"rateElement":"","ratePeriod":"","rateTable":"CD PH Winter hols","rateTypeId":1416,"reservationId":215470,"stayDate":"2023-06-01 00:00:00","totalRateAmount":844,"xNightsDiscount":0,"packageAmountIncludedInRateAmount":20},{"additionalsAmount":0,"currency":"AUD","discountAmount":0,"dynamicAmount":800,"exclusiveTax":0,"linkedRateAdjustmentAmount":0,"packageAmount":44,"rateAmount":800,"rateElement":"","ratePeriod":"","rateTable":"CD PH Winter hols","rateTypeId":1416,"reservationId":215471,"stayDate":"2023-06-01 00:00:00","totalRateAmount":844,"xNightsDiscount":0,"packageAmountIncludedInRateAmount":20}]
 */
export interface RMSCloudDailyRateBasicArray {
  /** @format currency */
  additionalsAmount?: number
  currency?: string
  /** @format currency */
  discountAmount?: number
  /** @format currency */
  dynamicAmount?: number
  /** @format currency */
  exclusiveTax?: number
  /** @format currency */
  linkedRateAdjustmentAmount?: number
  /** @format currency */
  packageAmount?: number
  /** @format currency */
  packageAmountIncludedInRateAmount?: number
  /** @format currency */
  rateAmount?: number
  rateElement?: string
  ratePeriod?: string
  rateTable?: string
  /** @format int32 */
  rateTypeId?: number
  /** @format int32 */
  reservationId?: number
  /** @format date-time */
  stayDate?: string
  /** @format currency */
  totalRateAmount?: number
  /** @format currency */
  xNightsDiscount?: number
}

/** @example {"accommodation":20,"accommodationGst":2,"accommodationTax":0,"foodAndBeverage":10,"foodAndBeverageGst":1,"foodAndBeverageTax":0,"other":15,"otherGst":1.5,"otherTax":0,"theDate":"2019-09-12"} */
export interface RMSCloudDailyRevenue {
  /**
   * This value is tax inclusive for tax inclusive properties
   * @format currency
   */
  accommodation?: number
  /** @format currency */
  accommodationGst?: number
  /** @format currency */
  accommodationTax?: number
  /**
   * This value is tax inclusive for tax inclusive properties
   * @format currency
   */
  foodAndBeverage?: number
  /** @format currency */
  foodAndBeverageGst?: number
  /** @format currency */
  foodAndBeverageTax?: number
  /**
   * This value is tax inclusive for tax inclusive properties
   * @format currency
   */
  other?: number
  /** @format currency */
  otherGst?: number
  /** @format currency */
  otherTax?: number
  /** @format date-time */
  theDate?: string
}

/** @example {"reservationId":163577,"dailyRevenue":[{"theDate":"2020-12-10 00:00:00","accommodation":360,"accommodationTax":0,"accommodationGST":32.72,"foodAndBeverage":0,"foodAndBeverageTax":0,"foodAndBeverageGST":0,"other":50,"otherTax":0,"otherGST":4.55},{"theDate":"2020-12-11 00:00:00","accommodation":0,"accommodationTax":0,"accommodationGST":0,"foodAndBeverage":0,"foodAndBeverageTax":0,"foodAndBeverageGST":0,"other":0,"otherTax":0,"otherGST":0}]} */
export interface RMSCloudDailyRevenueArray {
  dailyRevenue?: RMSCloudDailyRevenue
  /** @format int32 */
  reservationId?: number
}

/**
 * Used:<br>POST /availabilityRateGrid
 * @example {"availableAreas":5,"closedOnArrival":false,"closedOnDeparture":false,"dailyRate":5418,"estimatedRate":false,"maxStay":0,"minStay":0,"minStayOnArrival":0,"stopSell":false,"theDate":"2023-08-15 00:00:00"}
 */
export interface RMSCloudDayBreakdown {
  /** @format int32 */
  availableAreas?: number
  closedOnArrival?: boolean
  closedOnDeparture?: boolean
  /** @format currency */
  dailyRate?: number
  estimatedRate?: boolean
  /** @format int32 */
  maxStay?: number
  /** @format int32 */
  minStay?: number
  /** @format int32 */
  minStayOnArrival?: number
  stopSell?: boolean
  /** @format date */
  theDate?: string
}

export interface RMSCloudDaysOfMonth {
  daysOfMonth?: number[]
}

export interface RMSCloudDaysOfWeek {
  daysOfWeek?: RMSCloudDaysOfWeekEnum[]
}

export enum RMSCloudDaysOfWeekEnum {
  Monday = 'Monday',
  Tuesday = 'Tuesday',
  Wednesday = 'Wednesday',
  Thursday = 'Thursday',
  Friday = 'Friday',
  Saturday = 'Saturday',
  Sunday = 'Sunday',
}

/** @example {"id":1,"name":"accommodation"} */
export interface RMSCloudDepartments {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":1,"name":"10% Discount","availableToIbe":true,"description":"Customers will recieve 10% off total booking","maximumNightStay":0,"minimumNightStay":3} */
export interface RMSCloudDiscountBasic {
  availableToIbe?: boolean
  description?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  maximumNightStay?: number
  /** @format int32 */
  minimumNightStay?: number
  name?: string
}

export type RMSCloudDiscountFull = RMSCloudDiscountFullInner[]

export interface RMSCloudDiscountFullInner {
  amount?: {
    amount?: number
  }
  availableToIbe?: boolean
  availableToMembers?: boolean
  bogo?: {
    buyXNights?: number
    getXNights?: number
    getXNightsCycles?: number
    includeAdditionals?: boolean
  }
  description?: string
  discountType?: RMSCloudDiscountFullInnerDiscountTypeEnum
  glCodeId?: number
  glCodeType?: string
  id?: number
  maximumNightStay?: number
  minimumNightStay?: number
  name?: string
  nightlyRateOverride?: {
    firstXNights?: number
    includeAdditionals?: boolean
    totalCharge?: number
  }
  percentage?: {
    appliesToTotalRate?: boolean
    includeAdditionals?: boolean
    includePackage?: boolean
    noGreaterThan?: number
    percentage?: number
  }
  totalOverride?: {
    firstXNights?: number
    includeAdditionals?: boolean
    maxAdults?: number
    maxChildren?: number
    totalCharge?: number
  }
}

export enum RMSCloudDiscountFullInnerDiscountTypeEnum {
  Percentage = 'Percentage',
  Amount = 'Amount',
  BOGO = 'BOGO',
  TotalRateOverride = 'TotalRateOverride',
  KidsAndInfantsStayFree = 'KidsAndInfantsStayFree',
  NightlyRateOverride = 'NightlyRateOverride',
}

/** @example {"id":1,"name":"10% Discount"} */
export interface RMSCloudDiscountLite {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"discountId":63,"name":"Validation Options Test","propertyIds":[1,3],"categoryIds":[1,29,52],"validationDates":[{"propertyIds":[1,3],"rateIds":[1119,1421,1425],"reservationMadeFromDate":"2022-07-21 23:59:00","reservationMadeToDate":"2022-09-05 23:59:59","reservationMadePermanentFlag":false,"reservationStayingFromDate":"2022-07-21 23:59:00","reservationStayingToDate":"2022-10-31 23:59:59","reservationStayingPermanentFlag":false,"arrivingOnMonday":true,"arrivingOnTuesday":true,"arrivingOnWednesday":true,"arrivingOnThursday":true,"arrivingOnFriday":true,"arrivingOnSaturday":true,"arrivingOnSunday":true,"applyingOnMonday":true,"applyingOnTuesday":true,"applyingOnWednesday":true,"applyingOnThursday":true,"applyingOnFriday":true,"applyingOnSaturday":true,"applyingOnSunday":true},{"propertyIds":[1,3],"rateIds":[1417],"reservationMadeFromDate":"2048-09-14 00:00:00","reservationMadeToDate":"2048-09-15 23:59:59","reservationMadePermanentFlag":true,"reservationStayingFromDate":"2048-09-14 00:00:00","reservationStayingToDate":"2048-09-14 23:59:59","reservationStayingPermanentFlag":false,"arrivingOnMonday":true,"arrivingOnTuesday":true,"arrivingOnWednesday":true,"arrivingOnThursday":true,"arrivingOnFriday":true,"arrivingOnSaturday":true,"arrivingOnSunday":true,"applyingOnMonday":true,"applyingOnTuesday":true,"applyingOnWednesday":true,"applyingOnThursday":true,"applyingOnFriday":true,"applyingOnSaturday":true,"applyingOnSunday":true}]} */
export interface RMSCloudDiscountValidation {
  /** These are the Category ID's these validation options apply to */
  categoryIds?: number[]
  /** @format int32 */
  discountid?: number
  name?: string
  validationDates?: RMSCloudDiscountValidationSearchDates
}

export interface RMSCloudDiscountValidationSearch {
  ids?: number[]
}

export interface RMSCloudDiscountValidationSearchDates {
  applyingOnFriday?: boolean
  applyingOnMonday?: boolean
  applyingOnSaturday?: boolean
  applyingOnSunday?: boolean
  applyingOnThursday?: boolean
  applyingOnTuesday?: boolean
  applyingOnWednesday?: boolean
  arrivingOnFriday?: boolean
  arrivingOnMonday?: boolean
  arrivingOnSaturday?: boolean
  arrivingOnSunday?: boolean
  arrivingOnThursday?: boolean
  arrivingOnTuesday?: boolean
  arrivingOnWednesday?: boolean
  /** These are the property ID's these validation options apply to */
  propertyIds?: number[]
  rateIds?: number[]
  /** @format date-time */
  reservationMadeFromDate?: string
  reservationMadePermanentFlag?: boolean
  /** @format date-time */
  reservationMadeToDate?: string
  /** @format date-time */
  reservationStayingFromDate?: string
  reservationStayingPermanentFlag?: boolean
  /** @format date-time */
  reservationStayingToDate?: string
}

/** @example {"id":3,"name":"6 ft"} */
export interface RMSCloudDwellingLength {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":1,"name":"Passenger"} */
export interface RMSCloudDwellingSlide {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":7,"name":"Double decker"} */
export interface RMSCloudDwellingType {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"reservationId":198654,"existingToken":true} */
export interface RMSCloudExistingToken {
  existingToken?: boolean
  /** @format int32 */
  reservationId?: number
}

export interface RMSCloudFinancialInterfaceAdditional {
  interface1?: RMSCloudFinancialInterfaceCodeDesc[]
  interface2?: RMSCloudFinancialInterfaceCodeDesc[]
  interface3?: RMSCloudFinancialInterfaceCodeDesc[]
  interface4?: RMSCloudFinancialInterfaceCodeDesc[]
}

export interface RMSCloudFinancialInterfaceAdvancesLedger {
  lessCreditsRefunded?: RMSCloudFinancialInterfaceCodeDesc[]
  lessCreditsUsed?: RMSCloudFinancialInterfaceCodeDesc[]
  plusNewCredits?: RMSCloudFinancialInterfaceCodeDesc[]
}

export interface RMSCloudFinancialInterfaceCardDetail {
  card?: RMSCloudFinancialInterfaceCodeDesc[]
  /** @format int32 */
  cardId?: number
  eftPos?: RMSCloudFinancialInterfaceCodeDesc[]
  name?: string
}

export interface RMSCloudFinancialInterfaceCityLedger {
  lessCreditsUsed?: RMSCloudFinancialInterfaceCodeDesc[]
  lessPaidBalances?: RMSCloudFinancialInterfaceCodeDesc[]
  plusNewBalances?: RMSCloudFinancialInterfaceCodeDesc[]
  plusNewCredits?: RMSCloudFinancialInterfaceCodeDesc[]
}

export interface RMSCloudFinancialInterfaceCodeDesc {
  code?: string
  description?: string
}

export interface RMSCloudFinancialInterfaceGuestLedger {
  lessPaidBalances?: RMSCloudFinancialInterfaceCodeDesc[]
  plusNewReservationCharges?: RMSCloudFinancialInterfaceCodeDesc[]
}

export interface RMSCloudFinancialInterfaceOptionsTaxes {
  amortiseTaxes?: boolean
  serviceChargeNonTaxable?: boolean
}

export interface RMSCloudFinancialInterfacePeriods {
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  period?: number
  /** @format date-time */
  postingDate?: string
  /** @format date-time */
  toDate?: string
  /** @format int32 */
  year?: number
}

export interface RMSCloudFinancialInterfaceReceipts {
  directCredit2?: RMSCloudFinancialInterfaceCodeDesc[]
  cash?: RMSCloudFinancialInterfaceCodeDesc[]
  cheque?: RMSCloudFinancialInterfaceCodeDesc[]
  directCredit?: RMSCloudFinancialInterfaceCodeDesc[]
  otherCash?: RMSCloudFinancialInterfaceCodeDesc[]
}

/** @example {"propertyId":3} */
export interface RMSCloudFinancialInterfaceSetup {
  /** @format int32 */
  propertyId?: number
}

export interface RMSCloudFinancialInterfaceSetupResponse {
  additionalInterface?: RMSCloudFinancialInterfaceAdditional[]
  advancesLedger?: RMSCloudFinancialInterfaceAdvancesLedger[]
  cards?: RMSCloudFinancialInterfaceCardDetail[]
  cityLedger?: RMSCloudFinancialInterfaceCityLedger[]
  guestLedger?: RMSCloudFinancialInterfaceGuestLedger[]
  options?: RMSCloudFinancialInterfaceOptionsTaxes[]
  periods?: RMSCloudFinancialInterfacePeriods[]
  /** @format int32 */
  propertyId?: number
  receipts?: RMSCloudFinancialInterfaceReceipts[]
  stats?: RMSCloudFinancialInterfaceStats[]
}

export interface RMSCloudFinancialInterfaceStats {
  availableRooms?: RMSCloudFinancialInterfaceCodeDesc[]
  noShowRooms?: RMSCloudFinancialInterfaceCodeDesc[]
  occupiedRooms?: RMSCloudFinancialInterfaceCodeDesc[]
  outOfOrderRooms?: RMSCloudFinancialInterfaceCodeDesc[]
  totalRoomsInProperty?: RMSCloudFinancialInterfaceCodeDesc[]
}

/** @example {"propertyId":3,"entityType":"eftpos"} */
export interface RMSCloudFinancialInterfaceTcodes {
  entityType?: RMSCloudFinancialInterfaceTcodesEntityTypeEnum
  /** @format int32 */
  propertyId?: number
}

export enum RMSCloudFinancialInterfaceTcodesEntityTypeEnum {
  NotSet = 'notSet',
  GlCode = 'glCode',
  MarketSegment = 'marketSegment',
  Mappings = 'mappings',
  Receipts = 'receipts',
  CreditCards = 'creditCards',
  Eftpos = 'eftpos',
  Statistics = 'statistics',
}

/** @example {"entityTypeId":6,"entityType":"EFTPos","entityId":3,"entity":"Amex","propertyId":3,"t0":"AmexEFTT0","t1":"AmexEFTT1","t2":"AmexEFTT2","t3":"AmexEFTT3","t4":"AmexEFTT4","t5":"AmexEFTT5","t6":"AmexEFTT6","t7":"AmexEFTT7","t8":"AmexEFTT8","t9":"AmexEFTT9"} */
export interface RMSCloudFinancialInterfaceTcodesResponse {
  t0?: string
  t1?: string
  t2?: string
  t3?: string
  t4?: string
  t5?: string
  t6?: string
  t7?: string
  t8?: string
  t9?: string
  entity?: string
  /** @format int32 */
  entityId?: number
  entityType?: RMSCloudFinancialInterfaceTcodesResponseEntityTypeEnum
  /** @format int32 */
  entityTypeId?: number
  /** @format int32 */
  propertyId?: number
}

export enum RMSCloudFinancialInterfaceTcodesResponseEntityTypeEnum {
  NotSet = 'notSet',
  GlCode = 'glCode',
  MarketSegment = 'marketSegment',
  Mappings = 'mappings',
  Receipts = 'receipts',
  CreditCards = 'creditCards',
  Eftpos = 'eftpos',
  Statistics = 'statistics',
}

/** @example {"id":1,"code":"USD","description":"US Dollars","exchangeRate":1.5,"propertyId":1,"Symbol":"$"} */
export interface RMSCloudForeignExchangeRates {
  Symbol?: string
  code?: string
  description?: string
  /** @format decimal */
  exchangeRate?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
}

/** @example {"id":1,"name":"Jim's Accommodation"} */
export interface RMSCloudFranchises {
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetAreasByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetAreasParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/** Only these asscociations will be accepted */
export enum RMSCloudGetAttributesParamsAssociatedToEnum {
  All = 'all',
  Area = 'area',
  Property = 'property',
  Category = 'category',
  Dwelling = 'dwelling',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetCategoriesByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetCategoriesParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetCompaniesParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetDiscountsParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetGroupAllotmentsByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetGroupAllotmentsParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetGuestsByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetOnlineAgentsParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetPropertiesByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetPropertiesParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetPropertiescategoriesParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetRateTypesByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetRateTypesParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/** Only these statuses will be accepted */
export enum RMSCloudGetReasonsParamsReasonTypeEnum {
  AssetAssociatedToChanged = 'AssetAssociatedToChanged',
  CancelInvoice = 'CancelInvoice',
  ChangeOfArrivedRoom = 'ChangeOfArrivedRoom',
  ChangeOfChargeType = 'ChangeOfChargeType',
  ClosedOpportunityStage = 'ClosedOpportunityStage',
  Discount = 'Discount',
  ExtraDoorKeyCut = 'ExtraDoorKeyCut',
  FixReservation = 'FixReservation',
  Housekeeping = 'Housekeeping',
  InActive = 'InActive',
  MaintenanceBooking = 'MaintenanceBooking',
  ManualOverride = 'ManualOverride',
  PencilBooking = 'PencilBooking',
  ReinstateRes = 'ReinstateRes',
  RejectImageUpload = 'RejectImageUpload',
  ReservationCancelled = 'ReservationCancelled',
  ReservationUpgrade = 'ReservationUpgrade',
  ResNoShow = 'ResNoShow',
  ReverseExpensePayment = 'ReverseExpensePayment',
  ReverseReceipt = 'ReverseReceipt',
  ReverseRefund = 'ReverseRefund',
  RevertRes = 'RevertRes',
  TransferToAccount = 'TransferToAccount',
  VoidingTransaction = 'VoidingTransaction',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetReservationArrivingParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetReservationByIdParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetReservationDepartingParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetReservationInHouseParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetTravelAgentsParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudGetWholesalersParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/** @example {"id":36,"name":"Tips/Restaurant","glCode":"2-1210","groupingId":12,"includeInAccommodationRevenue\"":false} */
export interface RMSCloudGlCodeBasic {
  glCode?: string
  groupingId?: number
  /** @format int64 */
  id?: number
  includeInAccommodationRevenue?: boolean
  name?: string
}

/** @example {"id":0,"name":"Tips/Restaurant","glCode":"2-1210","groupingId":12,"includeInAccommodationRevenue\"":false} */
export interface RMSCloudGlCodeCreation {
  glCode?: string
  groupingId?: number
  /** @format int64 */
  id?: number
  includeInAccommodationRevenue?: boolean
  name?: string
}

export interface RMSCloudGroupAllotmentAgentRequest {
  agentIds?: number[]
}

/**
 * Used:<br>POST /groupAllotments/{id}/allotments
 * @example {"allotment":2,"allotmentId":7564,"categoryId":4,"categoryName":"Test","fromDate":"20-07-2020","propertyId":1,"toDate":"20-08-2020"}
 */
export interface RMSCloudGroupAllotmentCategory {
  /** @format int32 */
  allotment?: number
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  toDate?: string
}

export interface RMSCloudGroupAllotmentCategoryAllotment {
  /** @format int32 */
  allotment?: number
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  toDate?: string
}

/** @example {"allotment":0,"categoryId":4,"fromDate":"20-07-2020","toDate":"20-08-2020"} */
export interface RMSCloudGroupAllotmentCategoryAllotmentCreation {
  /** @format int32 */
  allotment?: number
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  fromDate?: string
  /** @format date-time */
  toDate?: string
}

/** @example {"allotment":2,"allotmentId":7564,"categoryId":4,"fromDate":"20-07-2020","toDate":"20-08-2020","propertyId":1} */
export interface RMSCloudGroupAllotmentCategoryAllotmentUpdates {
  /** @format int32 */
  allotment?: number
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  toDate?: string
}

/** @example {"id":22,"name":"APT Group G1 11th & 12th Oct","companyId":44,"companyName":"Mians"} */
export interface RMSCloudGroupAllotmentCompanies {
  /** @format int32 */
  companyId?: number
  companyName?: string
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:<br>POST /groupAllotments/{id}/allotments
 * @example {"availableFor":["tuesday","wednesday","friday"],"categoryAllotment":[{"allotment":10,"categoryId":1,"categoryName":"Cat A","fromDate":"2020-04-07 00:00:00","propertyId":1,"toDate":"2020-04-07 00:00:00"},{"allotment":5,"categoryId":3,"categoryName":"Cat C","fromDate":"2020-04-07 00:00:00","propertyId":1,"toDate":"2020-04-07 00:00:00"},{"allotment":9,"categoryId":1,"categoryName":"Cat A","fromDate":"2020-04-07 00:00:00","propertyId":1,"toDate":"2020-04-07 00:00:00"},{"allotment":5,"categoryId":2,"categoryName":"Cat B","fromDate":"2020-04-07 00:00:00","propertyId":1,"toDate":"2020-04-07 00:00:00"}],"daysBeforeRelease":40,"discountId":3,"discountReasonId":2,"doNotSellAboveAllotment":true,"fromDate":"2019-07-01 00:00:00","groupAllotmentId":0,"groupStatus":"proposal","guaranteed":true,"name":"Cheers","toDate":"2019-07-03 00:00:00","rateId":1,"releaseDate":"2019-07-03 00:00:00","releaseMethod":"specificDate","setPermanently":false}
 */
export interface RMSCloudGroupAllotmentDetails {
  availableFor?: RMSCloudGroupAllotmentDetailsAvailableForEnum[]
  categoryAllotment?: RMSCloudGroupAllotmentCategory[]
  /** @format int32 */
  daysBeforeRelease?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  discountReasonId?: number
  doNotSellAboveAllotment?: boolean
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  groupAllotmentId?: number
  groupStatus?: RMSCloudGroupAllotmentDetailsGroupStatusEnum
  /** If true this will detuct fron inventory */
  guaranteed?: boolean
  name: string
  /** @format int32 */
  rateId: number
  /** @format date-time */
  releaseDate?: string
  releaseMethod?: RMSCloudGroupAllotmentDetailsReleaseMethodEnum
  /** If this is set to true the date from and to values will be ignored and this allotment will exist forever */
  setPermanently?: boolean
  /** @format date-time */
  toDate?: string
}

export enum RMSCloudGroupAllotmentDetailsAvailableForEnum {
  Monday = 'monday',
  Tuesday = 'tuesday',
  Wednesday = 'wednesday',
  Thursday = 'thursday',
  Friday = 'friday',
  Saturday = 'saturday',
  Sunday = 'sunday',
}

export enum RMSCloudGroupAllotmentDetailsGroupStatusEnum {
  Proposal = 'proposal',
  Provisional = 'provisional',
  Definite = 'definite',
}

export enum RMSCloudGroupAllotmentDetailsReleaseMethodEnum {
  DaysBefore = 'daysBefore',
  SpecificDate = 'specificDate',
}

/** @example {"availableFor":["Friday","Tuesday"],"daysBeforeRelease":40,"discountId":3,"discountReasonId":2,"doNotSellAboveAllotment":false,"fromDate":"2019-07-01 00:00:00","groupStatus":"Proposal","guaranteed":false,"name":"Special 2","rateId":1,"releaseDate":"2019-07-03 00:00:00","releaseMethod":"specificDate","setPermanently":false,"toDate":"2019-07-04 00:00:00","reportingADR":[{"categoryId":"4,","reportingADR":200},{"categoryId":"2,","reportingADR":200}]} */
export interface RMSCloudGroupAllotmentOptionPatch {
  availableFor?: RMSCloudGroupAllotmentOptionPatchAvailableForEnum[]
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  daysBeforeRelease?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  discountReasonId?: number
  doNotSellAboveAllotment?: boolean
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  groupAllotmentId?: number
  /** @format int32 */
  groupOptionId?: number
  groupStatus?: RMSCloudGroupAllotmentOptionPatchGroupStatusEnum
  guaranteed?: boolean
  name?: string
  /** @format int32 */
  rateId?: number
  /** @format date-time */
  releaseDate?: string
  releaseMethod?: RMSCloudGroupAllotmentOptionPatchReleaseMethodEnum
  reportingADR?: number[]
  setPermanently?: boolean
  /** @format date-time */
  toDate?: string
}

export enum RMSCloudGroupAllotmentOptionPatchAvailableForEnum {
  Monday = 'monday',
  Tuesday = 'tuesday',
  Wednesday = 'wednesday',
  Thursday = 'thursday',
  Friday = 'friday',
  Saturday = 'saturday',
  Sunday = 'sunday',
}

export enum RMSCloudGroupAllotmentOptionPatchGroupStatusEnum {
  NotSet = 'NotSet',
  Proposal = 'Proposal',
  Provisional = 'Provisional',
  Definite = 'Definite',
}

export enum RMSCloudGroupAllotmentOptionPatchReleaseMethodEnum {
  DaysBefore = 'daysBefore',
  SpecificDate = 'specificDate',
}

/** @example {"amount":15,"id":66326,"masterRequirementId":6119,"name":"Much Cheddar","quantity":1,"requiredDaily":false} */
export interface RMSCloudGroupAllotmentRequirement {
  /** @format currency */
  amount?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  masterRequirementId?: number
  name?: string
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
}

/** @example {"amount":15,"id":66326,"masterRequirementId":6119,"name":"Much Cheddar","quantity":1,"requiredDaily":false} */
export interface RMSCloudGroupAllotmentRequirementArray {
  /** @format currency */
  amount?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  masterRequirementId?: number
  name?: string
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
}

/** @example {"amount":0,"masterRequirementId":51339,"name":"Super Soft Body Pillow","quantity":1} */
export interface RMSCloudGroupAllotmentRequirementCreation {
  /** @format currency */
  amount?: number
  /** @format int32 */
  masterRequirementId?: number
  name?: string
  /** @format int32 */
  quantity?: number
}

export interface RMSCloudGroupAllotmentTravelAgents {
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  travelAgentId?: number
  travelAgentName?: string
}

export interface RMSCloudGroupAllotmentWholesalers {
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  wholesalerId?: number
  wholesalerName?: string
}

/** @example [{"name":"Cheers","availableFor":["tuesday","wednesday","friday"],"categoryAllotment":[{"propertyId":1,"allotment":10,"allotmentId":1242,"categoryId":1,"categoryName":"Deluxe 001","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"},{"propertyId":1,"allotment":5,"allotmentId":1243,"categoryId":3,"categoryName":"Deluxe 003","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"},{"propertyId":1,"allotment":9,"allotmentId":1244,"categoryId":1,"categoryName":"Deluxe 001","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"},{"propertyId":1,"allotment":5,"allotmentId":1245,"categoryId":2,"categoryName":"Deluxe 002","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"}]},{"reportingADR":[{"categoryId":"4,","reportingADR":200},{"categoryId":"2,","reportingADR":200}],"daysBeforeRelease":40,"discountId":3,"discountReasonId":2,"doNotSellAboveAllotment":true,"fromDate":"2019-07-01 00:00:00","groupOptionId":82,"groupStatus":"proposal","guaranteed":true,"rateId":1,"setPermanently":false,"toDate":"2019-07-03 00:00:00"},{"reportingADR":[{"categoryId":"6,","reportingADR":100},{"categoryId":"1,","reportingADR":100}]},{"name":"Special 2","availableFor":["wednesday","friday"],"categoryAllotment":[{"allotment":6,"categoryId":1,"categoryName":"Deluxe 001","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"},{"allotment":2,"categoryId":3,"categoryName":"Deluxe 003","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"},{"allotment":3,"categoryId":4,"categoryName":"Deluxe 004","fromDate":"2020-04-07 00:00:00","toDate":"2020-04-07 00:00:00"}],"daysBeforeRelease":0,"discountId":0,"discountReasonId":0,"doNotSellAboveAllotment":true,"fromDate":"2019-07-03 00:00:00","groupStatus":"provisional","guaranteed":false,"rateId":3,"releaseDate":"2019-07-03 00:00:00","releaseOptions":"releaseDate","setPermanently":false,"toDate":"2019-07-04 00:00:00"}] */
export interface RMSCloudGroupAllotmentsAllotments {
  availableFor?: RMSCloudGroupAllotmentsAllotmentsAvailableForEnum[]
  categoryAllotment?: RMSCloudGroupAllotmentCategoryAllotment[]
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  daysBeforeRelease?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  discountReasonId?: number
  doNotSellAboveAllotment?: boolean
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  groupOptionId?: number
  groupStatus?: RMSCloudGroupAllotmentsAllotmentsGroupStatusEnum
  /** If true this will detuct fron inventory */
  guaranteed?: boolean
  name?: string
  /** @format int32 */
  rateId?: number
  /** @format date-time */
  releaseDate?: string
  releaseOptions?: RMSCloudGroupAllotmentsAllotmentsReleaseOptionsEnum
  reportingADR?: number[]
  /** If this to true the date from and to values will be ignored and this allotment will exist forever */
  setPermanently?: boolean
  /** @format date-time */
  toDate?: string
}

export enum RMSCloudGroupAllotmentsAllotmentsAvailableForEnum {
  Monday = 'monday',
  Tuesday = 'tuesday',
  Wednesday = 'wednesday',
  Thursday = 'thursday',
  Friday = 'friday',
  Saturday = 'saturday',
  Sunday = 'sunday',
}

export enum RMSCloudGroupAllotmentsAllotmentsGroupStatusEnum {
  Proposal = 'proposal',
  Provisional = 'provisional',
  Definite = 'definite',
}

export enum RMSCloudGroupAllotmentsAllotmentsReleaseOptionsEnum {
  DaysBeforeRelease = 'daysBeforeRelease',
  ReleaseDate = 'releaseDate',
}

/** @example {"id":1,"name":"Wedding","address1":"35 fake street","address2":"West chester","address3":"North","bookingSourceId":5,"city":"Melbourne","cityMasterId":68,"competitorMasterId":32,"countryId":2,"email":"test@rscom.au","externalRefId":"b985698","fax":"03 9882 5998","inactive":true,"inactiveReason":"Out of business","industryMasterId":4,"marketSegmentId":3,"modifiedDate":"2018-09-05 13:25:00","phone":"+614 555 986 98","postcode":"9568","propertyId":1,"salesSourceId":1,"state":"Vic","subMarketSegmentId":5,"tradingAs":"Webster enco"} */
export interface RMSCloudGroupAllotmentsBasic {
  address1?: string
  address2?: string
  address3?: string
  /** @format int32 */
  bookingSourceId?: number
  city?: string
  /** @format int32 */
  cityMasterId?: number
  /** @format int32 */
  competitorMasterId?: number
  /** @format int32 */
  countryId?: number
  email?: string
  externalRefId?: string
  fax?: string
  id?: string
  inactive?: boolean
  inactiveReason?: string
  /** @format int32 */
  industryMasterId?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format date-time */
  modifiedDate?: string
  name?: string
  phone?: string
  postcode?: string
  /** @format int32 */
  propertyId?: number
  salesSource?: string
  state?: string
  /** @format int32 */
  subMarketSegmentId?: number
  tradingAs?: string
}

/** @example {"rateIds":[1416,1633]} */
export interface RMSCloudGroupAllotmentsGroupOptionsRates {
  rateIds?: number[]
}

/** @example {"id":1,"name":"Wedding"} */
export interface RMSCloudGroupAllotmentsLite {
  /** @format int32 */
  id?: number
  name?: string
}

export interface RMSCloudGrouping {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"ids":[6548,2243,9879]} */
export interface RMSCloudGuestArraySearch {
  /** This call is limitied to only allow you to pass 50 guest ID's per call */
  ids?: number[]
}

/** @example {"id":0,"addressLine1":"1540 Amsterdam Avenue","addressLine2":"south","addressLine3":"Westingham","birthday":"1999-07-24 00:00:00","companyId":1,"countryId":1,"edmFilter1OptOut":true,"edmFilter2OptOut":true,"edmFilter3OptOut":true,"email":"test@rms.com.au","email2":"test@rms.com.au","emailOptOut":true,"guestAccountId":1234,"guestGiven":"Smithers","guestSurname":"Westingham","languageSpoken":"French Canadian","marketingOptOut":true,"mobile":"+614 586 659 77","nationalityId":7,"notes":"This is a nice guest","passportId":"E1234569","phoneAH":"03 1245 6564","phoneOptOut":true,"postcode":"1234E","privacyOptIn":true,"propertyId":"1","smsOptOut":true,"state":"Victoria","title":"Dr.","town":"Diggers","userDefined1":"Computer IP","userDefined2":"Mums address","userDefined3":"Phone","userDefined4":"Spare keys","userDefined5":"Calanders","userDefined6":"Tissues","userDefined7":"Bottles","userDefined8":"Headsets","userDefined9":"Pancakes","userDefined10":"Lip balm","userDefined11":"breakfast","userDefined12":"stationary kit","userDefined13":true,"userDefined14":false,"userDefined15":"2018-08-25 17:25:00","userDefined16":"2018-09-25 13:25:00"} */
export interface RMSCloudGuestBasic {
  addressLine1?: string
  addressLine2?: string
  addressLine3?: string
  edmFilter1OptOut?: boolean
  edmFilter2OptOut?: boolean
  edmFilter3OptOut?: boolean
  email2?: string
  userDefined1?: string
  userDefined10?: string
  userDefined11?: string
  userDefined12?: string
  userDefined13?: boolean
  userDefined14?: boolean
  /** @format date-time */
  userDefined15?: string
  /** @format date-time */
  userDefined16?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
  /** @format date-time */
  birthday?: string
  /** @format int32 */
  companyId?: number
  /** @format int32 */
  countryId?: number
  email?: string
  emailOptOut?: boolean
  /** @format int32 */
  guestAccountId?: number
  guestGiven?: string
  guestSurname?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  languageSpokenId?: number
  marketingOptOut?: boolean
  mobile?: string
  /** @format int32 */
  nationalityId?: number
  notes?: string
  passportId?: string
  phoneAH?: string
  phoneOptOut?: boolean
  postcode?: string
  privacyOptIn?: boolean
  /** @format int32 */
  propertyId?: number
  smsOptOut?: boolean
  state?: string
  title?: string
  town?: string
}

/** @example {"accountId":64984,"areaId":4,"categoryId":4,"contractNumber":265,"contractType":"Standard","dwellingSalesNumber":15,"ownedFromDate":"2018-09-26 10:25:00","ownedToDate":"2020-09-26 10:25:00","percentageShare":100,"propertyId":1} */
export interface RMSCloudGuestContract {
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  areaId?: number
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  contractId?: number
  contractType?: string
  /** @format int32 */
  dwellingSalesNumber?: number
  /** @format date-time */
  ownedFromDate?: string
  /** @format date-time */
  ownedToDate?: string
  /** @format int32 */
  percentageShare?: number
  /** @format int32 */
  propertyId?: number
}

/** @example {"guestId":564566,"contracts":[{"accountId":64984,"areaId":4,"categoryId":4,"contractNumber":265,"contractType":"Standard","dwellingSalesNumber":15,"ownedFromDate":"2018-09-26 10:25:00","ownedToDate":"2020-09-26 10:25:00","percentageShare":100,"propertyId":1}]} */
export interface RMSCloudGuestContracts {
  contracts?: RMSCloudGuestContract[]
  /** @format int32 */
  guestId?: number
}

/** @example {"accountId":346613,"amount":-50,"description":"Credit Note 2022","guestId":150595,"propertId":1,"remainingAmount":-50,"transactionId":223} */
export interface RMSCloudGuestCredit {
  /** @format int32 */
  accountId?: number
  /** @format number */
  amount?: number
  description?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  propertyId?: number
  /** @format number */
  remainingAmount?: number
  /** @format int32 */
  transactionId?: number
}

/** @example {"ids":[141029,149503,150595],"propertId":1} */
export interface RMSCloudGuestCreditSearch {
  ids?: number[]
  /** @format int32 */
  propertyId?: number
}

/** @example {"propertyId":1,"guestId":141029,"amount":7,"remainingAmount":7,"description":"Receipt #283826","accountId":386,"transactionId":11} */
export interface RMSCloudGuestCreditSearchResponse {
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  amount?: number
  description?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  remainingAmount?: number
  /** @format int32 */
  transactionId?: number
}

/** @example {"lengthId":8,"slideId":7,"typeId":2,"year":"1989","towingId":5} */
export interface RMSCloudGuestDwelling {
  /** @format int32 */
  lengthId?: number
  /** @format int32 */
  slideId?: number
  /** @format int32 */
  towingId?: number
  /** @format int32 */
  typeId?: number
  /** @format int32 */
  year?: number
}

/** @example {"id":78,"abn":"012 659 65689","addressLine1":"1540 Amsterdam Avenue","addressLine2":"south","addressLine3":"Westingham","agreementDate":"2018-09-25 17:25:00","arrivedFrom":"San Fran","auxDocumentDate":"2018-09-26 10:25:00","birthday":"1991-08-22 00:00:00","bookingSourceId":8,"blackList":true,"businessSegmentId":9,"ccConsent":true,"cityMasterId":87,"companyId":4,"countryArrivalDate":"2018-09-26 10:25:00","countryOfBirthId":8,"countryOfIdId":8,"countryId":8,"createdById":5,"createdDate":"2016-03-02 09:00:56","discountId":53,"edmFilter1OptOut":true,"edmFilter2OptOut":true,"edmFilter3OptOut":true,"email":"test@rms.com.au","email2":"test@rms.com.au","emailOptOut":true,"employedInCountry":false,"externalRefId":"v1234568","fax":"03 9568 69568","frequentFlyerMembershipTypeId":0,"gender":"X","groupName":"Westinghouse","gstFree":true,"guestAccountId":8,"guestGiven":"Smithers","guestSurname":"Westingham","guestStatusId":null,"guestTypeId":1,"identificationTypeId":74,"idIssueDate":"2018-09-25 17:25:00","landingPortId":11,"languageSpoken":"French Canadian","languageSpokenId":2,"lastAreaId":15,"lastRateTypeId":12,"lastVisit":"26-06-2016 00:12:00","licenceExpiryDate":"2018-09-25 17:25:00","licenceIssuedDate":"2018-09-25 17:25:00","licenceNumber":"98685p","longTerm":false,"loyaltyLevel":"Preetty Loyal","loyaltyMembershipType":"Platinum","loyaltyNumber":"55d","marketingOptOut":true,"membershipNumber":"br12345","mobile":"+614 586 659 77","modifiedById":50,"modifiedDate":"2017-07-12 15:12:00","nationalityId":8,"notes":"This is a nice guest","numberOfVisits":12,"otherName":"Smith","passportExpiry":"2018-09-25 17:25:00","passportId":"PT123698","phoneAH":"03 5698 5698","PhoneBH":"03 8986 5458","phoneOptOut":true,"placeOfIssue":"Ueganda","position":"CEO","postcode":"1234E","preference":"Clean room","preferredAreaGroupid":null,"preferredAreaId":14,"preferredPrintingLanguageId":7,"privacyOptIn":false,"proceedingTo":"New York","propertyId":7,"propertyName":"test property","registeredInCountry":false,"registrationAddress":"15, urik st","registrationDate":"2017-07-12 15:12:00","registrationNumber":"rrg4e8y7ye","registrationOffice":"Head Office","resTypeId":8,"retailer":false,"rvLengthId":9,"rvSlideId":3,"rvTypeId":2,"rvYear":8,"salesPrioritiesId":5,"smsOptOut":true,"state":"Victoria","studentId":246,"subResTypeId":6,"subTitleId":4,"tagId":11,"title":"Dr.","totalIncome":45000,"towingId":2,"town":"Bigennsville","turnAwayId":3,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 20","userDefined11":"String 20","userDefined12":"String 50","userDefined13":true,"userDefined14":false,"userDefined15":"28-02-2019 00:00:00","userDefined16":"28-02-2019 00:00:00","vipCodesId":14,"visaExpiry":"28-02-2019 00:00:00","visaIssued":"28-02-2019 00:00:00","visaNumber":"Jw123456","visaIssuedPlace":"Paris","visitPurposeId":1,"webAddress":"www.cbf.com.au"} */
export interface RMSCloudGuestFull {
  addressLine1?: string
  addressLine2?: string
  addressLine3?: string
  edmFilter1OptOut?: boolean
  edmFilter2OptOut?: boolean
  edmFilter3OptOut?: boolean
  email2?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 20 */
  userDefined10?: string
  /** @maxLength 20 */
  userDefined11?: string
  /** @maxLength 50 */
  userDefined12?: string
  userDefined13?: boolean
  userDefined14?: boolean
  /** @format date-time */
  userDefined15?: string
  /** @format date-time */
  userDefined16?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  PhoneBH?: string
  /** Australian Business Number */
  abn?: string
  /** @format date-time */
  agreementDate?: string
  arrivedFrom?: string
  /** @format date-time */
  auxDocumentDate?: string
  /** @format date-time */
  birthday?: string
  blackList?: boolean
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  businessSegmentId?: number
  ccConsent?: boolean
  /** @format int32 */
  cityMasterId?: number
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  countryArrivalDate?: string
  /** @format int32 */
  countryId?: number
  /** @format int32 */
  countryOfBirthId?: number
  /** @format int32 */
  countryOfIdId?: number
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format int32 */
  discountId?: number
  email?: string
  emailOptOut?: boolean
  employedInCountry?: boolean
  externalRefId?: string
  fax?: string
  /** @format int32 */
  frequentFlyerMembershipTypeId?: number
  gender?: string
  groupName?: string
  gstFree?: boolean
  /** @format int32 */
  guestAccountId?: number
  guestGiven?: string
  /** @format int32 */
  guestStatusId?: number
  guestSurname?: string
  /** @format int32 */
  guestTypeId?: number
  /** @format in32 */
  id?: number
  /** @format date-time */
  idIssueDate?: string
  /** @format int32 */
  identificationTypeId?: number
  /** @format int32 */
  landingPortId?: number
  languageSpoken?: string
  /** @format int32 */
  languageSpokenId?: number
  /** @format int32 */
  lastAreaId?: number
  /** @format int32 */
  lastRateTypeId?: number
  /** @format date-time */
  lastVisitDate?: string
  /** @format date-time */
  licenceExpiryDate?: string
  /** @format date-time */
  licenceIssuedDate?: string
  licenceNumber?: string
  longTerm?: boolean
  loyaltyLevel?: string
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  loyaltyNumber?: string
  marketingOptOut?: boolean
  membershipNumber?: string
  mobile?: string
  /** @format int32 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  /** @format int32 */
  nationalityId?: number
  notes?: string
  /** @format int32 */
  numberOfVisits?: number
  /** @format int32 */
  otaLoyaltyNumber?: number
  otherName?: string
  /** @format date-time */
  passportExpiry?: string
  passportId?: string
  phoneAH?: string
  phoneOptOut?: boolean
  placeOfIssue?: string
  position?: string
  postcode?: string
  preference?: string
  /** @format int32 */
  preferredAreaGroupid?: number
  /** @format int32 */
  preferredAreaId?: number
  /** @format int32 */
  preferredPrintingLanguageId?: number
  privacyOptIn?: boolean
  proceedingTo?: string
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  registeredInCountry?: boolean
  registrationAddress?: string
  /** @format date-time */
  registrationDate?: string
  registrationNumber?: string
  registrationOffice?: string
  /** @format int32 */
  resTypeId?: number
  retailer?: boolean
  /** @format int32 */
  rvLengthId?: number
  /** @format int32 */
  rvSlideId?: number
  /** @format int32 */
  rvTypeId?: number
  /** @format int32 */
  rvYear?: number
  /** @format int32 */
  salesPrioritiesId?: number
  smsOptOut?: boolean
  state?: string
  /** @format int32 */
  studentId?: number
  /** @format int32 */
  subResTypeId?: number
  /** @format int32 */
  subTitleId?: number
  /** @format int32 */
  tagId?: number
  title?: string
  /** @format decimal */
  totalIncome?: number
  /** @format int32 */
  towingId?: number
  town?: string
  /** @format int32 */
  turnAwayId?: number
  /** @format int32 */
  vipCodesId?: number
  /** @format date-time */
  visaExpiry?: string
  /** @format date-time */
  visaIssued?: string
  visaIssuedPlace?: string
  visaNumber?: string
  /** @format int32 */
  visitPurposeId?: number
  webAddress?: string
}

/** @example {"amount":10,"giftCardId":2,"guestId":150595,"propertId":1,"remainingAmount":5} */
export interface RMSCloudGuestGiftCard {
  /** @format number */
  amount?: number
  /** @format int32 */
  giftCardId?: number
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  propertId?: number
  /** @format number */
  remainingAmount?: number
}

/** @example {"guestIds":[6548,2243,9879],"dateFrom":"2019-01-01","dateTo":"2021-08-01"} */
export interface RMSCloudGuestIdArraySearch {
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  guestIds?: number[]
}

/** @example {"id":968,"guestGiven":"Smithers","guestSurname":"Westingham"} */
export interface RMSCloudGuestLite {
  guestGiven?: string
  guestSurname?: string
  /** @format int32 */
  id?: number
}

/** @example {"guestId":31,"points":"500","enrolled":true} */
export interface RMSCloudGuestLoyaltyPoints {
  enrolled?: boolean
  /** @format int32 */
  guestId?: number
  points?: string
}

/** @example {"activity":"sign up credit","amount":-25,"date":"2018-09-27","description":"Credit note 2","totalSpendForCalanderYear":12632,"username":"*hp"} */
export interface RMSCloudGuestLoyaltySpend {
  activity?: string
  amount?: number
  /** @format date-time */
  date?: string
  description?: string
  totalSpendForCalanderYear?: number
  username?: string
}

/** @example {"guestId":150595,"loyaltyNumber":150595,"currentCredit":0,"currentSpend":0,"remainingSpend":1818.5} */
export interface RMSCloudGuestLoyaltySpendBalance {
  /** @format currency */
  currentCredit?: number
  /** @format currency */
  currentSpend?: number
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  loyaltyNumber?: number
  /** @format currency */
  remainingSpend?: number
}

/** @example {"guestId":155,"address1":"15","address2":"somthing rd","given":"Steven","surname":"Peters","postCode":"3045","town":"keilor","state":"Vic","mobile":"+61458596548","birthday":"2018-09-27 00:00:00","email":"apisupport@rmscloud.com","loyaltyNumber":"4569"} */
export interface RMSCloudGuestLoyaltySpendEnrolment {
  address1?: string
  address2?: string
  /** @format date-time */
  birthday?: string
  email?: string
  given?: string
  /** @format int32 */
  guestId?: number
  loyaltyNumber?: string
  mobile?: string
  postCode?: string
  state?: string
  surname?: string
  town?: string
}

/**
 * Used:<br>GET /guests/{id}/memberships<br>POST /guests/{id}/memberships<br>
 * @example {"guestId":1384706,"id":38824,"inactive":false,"level":1,"membershipTypeId":2,"membershipTypeName":"","number":"ABC123"}
 */
export interface RMSCloudGuestMembershipBasic {
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  /** @format int32 */
  level?: number
  /** @format int32 */
  membershipTypeId?: number
  membershipTypeName?: string
  number?: string
}

/** @example [{"id":194076,"guestId":58202,"primaryGuest":true,"arrive":"2023-05-27 14:00:00","depart":"2023-05-30 10:30:00","adults":2,"children":0,"reservationId":214327,"doNotSendCorrespondence":false,"roleId":1,"role":"Capitain","guestGiven":"Eric","guestSurname":"Cartman"},{"id":194129,"guestId":153307,"primaryGuest":false,"arrive":"2023-05-27 14:00:00","depart":"2023-05-30 10:30:00","adults":2,"children":0,"reservationId":214327,"doNotSendCorrespondence":false,"roleId":2,"role":"Crew","guestGiven":"Lando","guestSurname":"Norris"}] */
export interface RMSCloudGuestMovement {
  /** @format int32 */
  adults?: number
  /** @format date-time */
  arrive?: string
  /** @format int32 */
  children?: number
  /** @format date-time */
  depart?: string
  doNotSendCorrespondace?: boolean
  guestGiven?: string
  /** @format int32 */
  guestId?: number
  guestSurname?: string
  /** @format int32 */
  id?: number
  primaryGuest?: boolean
  /** @format int32 */
  reservationId?: number
  role?: string
  /** @format int32 */
  roleId?: number
}

/** @example {"guestIds":194076,"reservationIds":[]} */
export interface RMSCloudGuestMovementsSearch {
  guestIds?: number[]
  reservationIds?: number[]
}

/** @example {"id":78,"abn":"012 659 65689","addressLine1":"1540 Amsterdam Avenue","addressLine2":"south","addressLine3":"Westingham","agreementDate":"2018-09-25 17:25:00","arrivedFrom":"San Fran","auxDocumentDate":"2018-09-26 10:25:00","birthday":"1991-08-22 00:00:00","bookingSourceId":8,"blackList":true,"businessSegmentId":9,"ccConsent":true,"cityMasterId":87,"companyId":4,"countryArrivalDate":"2018-09-26 10:25:00","countryOfBirthId":8,"countryOfIdId":8,"countryId":8,"createdById":5,"createdDate":"2016-03-02 09:00:56","discountId":53,"edmFilter1OptOut":true,"edmFilter2OptOut":true,"edmFilter3OptOut":true,"email":"test@rms.com.au","email2":"test@rms.com.au","emailOptOut":true,"employedInCountry":false,"externalRefId":"v1234568","fax":"03 9568 69568","frequentFlyerMembershipTypeId":0,"gender":"X","groupName":"Westinghouse","gstFree":true,"guestAccountId":8,"guestGiven":"Smithers","guestSurname":"Westingham","guestStatusId":null,"guestTypeId":1,"identificationTypeId":74,"idIssueDate":"2018-09-25 17:25:00","landingPortId":11,"languageSpoken":"French Canadian","languageSpokenId":2,"lastAreaId":15,"lastRateTypeId":12,"lastVisit":"26-06-2016 00:12:00","licenceExpiryDate":"2018-09-25 17:25:00","licenceIssuedDate":"2018-09-25 17:25:00","licenceNumber":"98685p","longTerm":false,"loyaltyLevel":"Preetty Loyal","loyaltyMembershipType":"Platinum","loyaltyNumber":"55d","marketingOptOut":true,"membershipNumber":"br12345","mobile":"+614 586 659 77","modifiedById":50,"modifiedDate":"2017-07-12 15:12:00","nationalityId":8,"notes":"This is a nice guest","numberOfVisits":12,"otherName":"Smith","otaLoyaltyNumber":"98413","passportExpiry":"2018-09-25 17:25:00","passportId":"PT123698","phoneAH":"03 5698 5698","PhoneBH":"03 8986 5458","phoneOptOut":true,"placeOfIssue":"Ueganda","position":"CEO","postcode":"1234E","preference":"Clean room","preferredAreaGroupid":null,"preferredAreaId":14,"preferredPrintingLanguageId":7,"privacyOptIn":false,"proceedingTo":"New York","propertyId":7,"propertyName":"test property","registeredInCountry":false,"registrationAddress":"15, urik st","registrationDate":"2017-07-12 15:12:00","registrationNumber":"rrg4e8y7ye","registrationOffice":"Head Office","resTypeId":8,"retailer":false,"salesPrioritiesId":5,"smsOptOut":true,"state":"Victoria","studentId":246,"subResTypeId":6,"subTitleId":4,"tagId":11,"title":"Dr.","totalIncome":45000,"towingId":2,"town":"Bigennsville","turnAwayId":3,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 20","userDefined11":"String 20","userDefined12":"String 50","userDefined13":true,"userDefined14":false,"userDefined15":"28-02-2019 00:00:00","userDefined16":"28-02-2019 00:00:00","vipCodesId":14,"visaExpiry":"28-02-2019 00:00:00","visaIssued":"28-02-2019 00:00:00","visaNumber":"Jw123456","visaIssuedPlace":"Paris","visitPurposeId":1,"webAddress":"www.cbf.com.au"} */
export interface RMSCloudGuestPatch {
  addressLine1?: string
  addressLine2?: string
  addressLine3?: string
  edmFilter1OptOut?: boolean
  edmFilter2OptOut?: boolean
  edmFilter3OptOut?: boolean
  email2?: string
  /** @maxLength 20 */
  userDefined1?: string
  /** @maxLength 20 */
  userDefined10?: string
  /** @maxLength 20 */
  userDefined11?: string
  /** @maxLength 50 */
  userDefined12?: string
  userDefined13?: boolean
  userDefined14?: boolean
  /** @format date-time */
  userDefined15?: string
  /** @format date-time */
  userDefined16?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  PhoneBH?: string
  /** Australian Business Number */
  abn?: string
  /** @format date-time */
  agreementDate?: string
  arrivedFrom?: string
  /** @format date-time */
  auxDocumentDate?: string
  /** @format date-time */
  birthday?: string
  blackList?: boolean
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  businessSegmentId?: number
  ccConsent?: boolean
  /** @format int32 */
  cityMasterId?: number
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  countryArrivalDate?: string
  /** @format int32 */
  countryId?: number
  /** @format int32 */
  countryOfBirthId?: number
  /** @format int32 */
  countryOfIdId?: number
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format int32 */
  discountId?: number
  email?: string
  emailOptOut?: boolean
  employedInCountry?: boolean
  externalRefId?: string
  fax?: string
  /** @format int32 */
  frequentFlyerMembershipTypeId?: number
  gender?: string
  groupName?: string
  gstFree?: boolean
  /** @format int32 */
  guestAccountId?: number
  guestGiven?: string
  /** @format int32 */
  guestStatusId?: number
  guestSurname?: string
  /** @format int32 */
  guestTypeId?: number
  /** @format in32 */
  id?: number
  /** @format date-time */
  idIssueDate?: string
  /** @format int32 */
  identificationTypeId?: number
  /** @format int32 */
  landingPortId?: number
  languageSpoken?: string
  /** @format int32 */
  languageSpokenId?: number
  /** @format int32 */
  lastAreaId?: number
  /** @format int32 */
  lastRateTypeId?: number
  /** @format date-time */
  lastVisitDate?: string
  /** @format date-time */
  licenceExpiryDate?: string
  /** @format date-time */
  licenceIssuedDate?: string
  licenceNumber?: string
  longTerm?: boolean
  loyaltyLevel?: string
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  loyaltyNumber?: string
  marketingOptOut?: boolean
  membershipNumber?: string
  mobile?: string
  /** @format int32 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  /** @format int32 */
  nationalityId?: number
  notes?: string
  /** @format int32 */
  numberOfVisits?: number
  /** @format int32 */
  otaLoyaltyNumber?: number
  otherName?: string
  /** @format date-time */
  passportExpiry?: string
  passportId?: string
  phoneAH?: string
  phoneOptOut?: boolean
  placeOfIssue?: string
  position?: string
  postcode?: string
  preference?: string
  /** @format int32 */
  preferredAreaGroupid?: number
  /** @format int32 */
  preferredAreaId?: number
  /** @format int32 */
  preferredPrintingLanguageId?: number
  privacyOptIn?: boolean
  proceedingTo?: string
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  registeredInCountry?: boolean
  registrationAddress?: string
  /** @format date-time */
  registrationDate?: string
  registrationNumber?: string
  registrationOffice?: string
  /** @format int32 */
  resTypeId?: number
  retailer?: boolean
  /** @format int32 */
  salesPrioritiesId?: number
  smsOptOut?: boolean
  state?: string
  /** @format int32 */
  studentId?: number
  /** @format int32 */
  subResTypeId?: number
  /** @format int32 */
  subTitleId?: number
  /** @format int32 */
  tagId?: number
  title?: string
  /** @format decimal */
  totalIncome?: number
  /** @format int32 */
  towingId?: number
  town?: string
  /** @format int32 */
  turnAwayId?: number
  /** @format int32 */
  vipCodesId?: number
  /** @format date-time */
  visaExpiry?: string
  /** @format date-time */
  visaIssued?: string
  visaIssuedPlace?: string
  visaNumber?: string
  /** @format int32 */
  visitPurposeId?: number
  webAddress?: string
}

/**
 * Used:<br>POST guests/{id}/rmsPayToken/search
 * @example {"cardHolderName":"","cardId":1,"cardType":"Visa","description":"Wifes Card","expiryDate":"03/30","lastFourDigitsOfCard":"1000","propertyId":1,"token":"948534hkfdhklfhkwefuhkl"}
 */
export interface RMSCloudGuestRMSPayToken {
  cardHolderName?: string
  /** @format int32 */
  cardId?: number
  cardType?: string
  description?: string
  expiryDate?: string
  lastFourDigitsOfCard?: string
  /** @format int32 */
  propertyId?: number
  token?: string
}

/** @example {"ids":[12,5,702],"idFrom":6,"idTo":12,"accountIds":[1242,5985,702],"clientType":"Not Set","createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","email":"john@gmail.com","email2":"apisupport@rmscloud.com","guestPropertyIds":"[1]","given":"steve","includeReservationIds":true,"includeSecondaryGuests":false,"loyaltyNumber":3732,"membershipNumber":"04903a","mobile":"0412345678","modifiedFrom":"2018-09-25 00:00:00","modifiedTo":"2018-09-27 00:00:00","propertyIds":[1,5,2],"reservationIds":[9454,123,1425],"surname":"smith","surnameStartsWith":"S","userDefinedFieldNumber":1,"userDefinedFieldValue":"married"} */
export interface RMSCloudGuestSearch {
  email2?: string
  accountIds?: number[]
  /** @default "notSet" */
  clientType?: RMSCloudGuestSearchClientTypeEnum
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  email?: string
  given?: string
  guestPropertyIds?: number[]
  /** @format int32 */
  idFrom?: number
  /** @format int32 */
  idTo?: number
  ids?: number[]
  includeReservationIds?: boolean
  includeSecondaryGuests?: boolean
  /** @format int32 */
  loyaltyNumber?: number
  membershipNumber?: string
  mobile?: string
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  propertyIds?: number[]
  reservationIds?: number[]
  surname?: string
  surnameStartsWith?: string
  /** @format int32 */
  userDefinedFieldNumber?: number
  userDefinedFieldValue?: string
}

/** @default "notSet" */
export enum RMSCloudGuestSearchClientTypeEnum {
  NotSet = 'notSet',
  Client = 'client',
  Owner = 'owner',
}

/** @example {"id":1,"name":"Citizen"} */
export interface RMSCloudGuestStatus {
  /** @format int32 */
  id?: number
  name?: string
}

/**
 * Used:
 * @example {"cardHolderName":"John Johnson","cardType":"VISA","description":"Customers Wifes card","expiryDate":"08/20","lastFourDigitsOfCard":4589,"propertyId":1,"token":"erer78er9+er3er6r3fedfr"}
 */
export interface RMSCloudGuestToken {
  cardHolderName?: string
  cardType?: string
  description?: string
  /** You must pass the date in the fromat MM/YY for it to work */
  expiryDate?: string
  /**
   * Some gateways only require last 2 digits. in these cases append with ..
   * @maxLength 4
   */
  lastFourDigitsOfCard?: string
  /**
   * The property ID the reservation is associated to
   * @format int32
   */
  propertyId?: number
  token?: string
}

/** @example {"cardHolderName":"John Johnson","cardType":"VISA","description":"Customers Wifes card","expiryDate":"08/20","lastFourDigitsOfCard":4589,"relatedSecurityKey":"XXXXXXXXX","relatedTxAuthno":"5555555555","relatedVendorTxCode":"XXXPAYMENT-1556613026-815551635","relatedVPSTxId":"9C7AC5AB-XXXX-XXXX-35B6-DECB9E946D59","token":"erer78er9+er3er6r3fedfr"} */
export interface RMSCloudGuestTokenSagePay {
  cardHolderName?: string
  cardType?: string
  description?: string
  /** You must pass the date in the fromat MM/YY for it to work */
  expiryDate?: string
  /**
   * Day value will be ignored
   * @maxLength 4
   */
  lastFourDigitsOfCard?: number
  relatedSecurityKey?: string
  relatedTxAuthno?: string
  relatedVPSTxId?: string
  relatedVendorTxCode?: string
  token?: string
}

/** @example {"id":1,"name":"Staff"} */
export interface RMSCloudGuestTypes {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"guestId":155,"loyaltyNumber":"4569"} */
export interface RMSCloudGuestsLoyaltyNightsEnrollment {
  /** @format int32 */
  guestId?: number
  loyaltyNumber?: string
}

/** @example {"departureClean":true,"housekeeperId":8,"housekeeperName":"Jan","id":8,"linenChange":true,"note":"dont tuck bed to tight","taskDate":"2020-05-26 00:00:00","taskName":"Departure","taskMinutes":5,"reservationId":213296} */
export interface RMSCloudHousekeeping {
  departureClean?: boolean
  /** @format int32 */
  housekeeperId?: number
  housekeeperName?: string
  /** @format int32 */
  id?: number
  linenChange?: boolean
  note?: string
  /** @format int32 */
  reservationId?: number
  /** @format date-time */
  taskDate?: string
  /** @format int32 */
  taskMinutes?: number
  taskName?: string
}

/**
 * Used: GET /properties/{id}/ibe/additionals
 * @example {"maxChildAge":11,"maxInfantAge":5,"showAdditionalCharge1":true,"showAdditionalCharge2":true,"showAdditionalCharge3":false,"showAdditionalCharge4":false,"showAdditionalCharge5":false,"showAdditionalCharge6":false,"showAdditionalCharge7":false,"showChildren":true,"showInfants":false}
 */
export interface RMSCloudIbeAdditional {
  showAdditionalCharge1?: boolean
  showAdditionalCharge2?: boolean
  showAdditionalCharge3?: boolean
  showAdditionalCharge4?: boolean
  showAdditionalCharge5?: boolean
  showAdditionalCharge6?: boolean
  showAdditionalCharge7?: boolean
  /** @format int32 */
  maxChildAge?: number
  /** @format int32 */
  maxInfantAge?: number
  showChildren?: boolean
  showInfants?: boolean
}

/** @example {"id":7,"name":"Chapagne & Chochlates","displayOrder":2,"excludeFromDeposit":false,"longDescription":"Chapagne & Chochlates on arrival in your room"} */
export interface RMSCloudIbeRequirement {
  /** @format int32 */
  displayOrder?: number
  excludeFromDeposit?: boolean
  /** @format int32 */
  id?: number
  longDescription?: string
  name?: string
}

/** @example {"creditCardCommission":2.66,"onlineReservationFee":1.5,"sundryId":2} */
export interface RMSCloudIbeReservationFees {
  /**
   * This value represents a percentage of the total rate.
   * @format decimal
   */
  creditCardCommission?: number
  /** @format decimal */
  onlineReservationFee?: number
  /** @format int32 */
  sundryId?: number
}

export interface RMSCloudIbeSetting {
  /** @format int32 */
  MaxGroupBookings?: number
  allowGroupBookings?: boolean
  childrenAllowed?: boolean
  currency?: string
  currencySymbol?: string
  /** @format date-time */
  defaultArrivalTime?: string
  /** @format date-time */
  defaultDepartTime?: string
  /** @format int32 */
  gatewayID?: number
  googleAnalyticsCode?: string
  latitude?: string
  longitude?: string
  maxChildAge?: string
  maxInfantAge?: string
  /** @format int32 */
  minAgeRequiredToBook?: number
  petsAllowed?: boolean
  redirectionURL?: string
  smokingAllowed?: boolean
}

/**
 * Used:<br>POST /areas/requirements/search<br>POST /areas/attributes/search<br>POST /areas/configuration/search<br>POST /categories/requirements/search<br>
 * @example {"ids":[10]}
 */
export interface RMSCloudIds {
  ids?: number[]
}

/** @example {"caption":"Bathroom","displayOrder":5,"url":"https://images.rmscloud.com/rmsoimages/6880/rmswin/rmsonlineimages/00000090.jpg"} */
export interface RMSCloudImage {
  'url:'?: string
  caption?: string
  /** @format int32 */
  displayOrder?: number
}

export type RMSCloudInlineResponse200 =
  | RMSCloudAreaLite[]
  | RMSCloudAreaBasic[]
  | RMSCloudAreaFull[]

export type RMSCloudInlineResponse2001 =
  | RMSCloudCategoryLite[]
  | RMSCloudCategoryBasic[]
  | RMSCloudCategoryFull[]

export type RMSCloudInlineResponse20010 =
  | RMSCloudReservationLite[]
  | RMSCloudReservationBasic[]
  | RMSCloudReservationFull[]

export interface RMSCloudInlineResponse20011 {
  /** @example true */
  Success?: boolean
}

export type RMSCloudInlineResponse2002 =
  | RMSCloudCompanyLite[]
  | RMSCloudCompanyBasic[]
  | RMSCloudCompanyFull[]

export type RMSCloudInlineResponse2003 =
  | RMSCloudDiscountLite[]
  | RMSCloudDiscountBasic[]
  | RMSCloudDiscountFull[]

export type RMSCloudInlineResponse2004 =
  | RMSCloudGuestLite[]
  | RMSCloudGuestBasic[]
  | RMSCloudGuestFull[]

export type RMSCloudInlineResponse2005 =
  | RMSCloudGroupAllotmentsLite[]
  | RMSCloudGroupAllotmentsBasic[]

/** @example [{"agentLite":{"$ref":"https://api.swaggerhub.com/domains/RMSHospitality/schema_domain1/1.4.26.1#/components/schemas/agentLite/example"}},{"agentBasic":{"$ref":"https://api.swaggerhub.com/domains/RMSHospitality/schema_domain1/1.4.26.1#/components/schemas/agentBasic/example"}},{"agentFull":{"$ref":"https://api.swaggerhub.com/domains/RMSHospitality/schema_domain1/1.4.26.1#/components/schemas/agentFull/example"}}] */
export type RMSCloudInlineResponse2006 =
  | RMSCloudAgentLite[]
  | RMSCloudAgentBasic[]
  | RMSCloudAgentFull[]

export type RMSCloudInlineResponse2007 =
  | RMSCloudPropertiesLite[]
  | RMSCloudPropertiesBasic[]
  | RMSCloudPropertiesFull[]

export type RMSCloudInlineResponse2008 = RMSCloudRateTypeLite[] | RMSCloudRateTypeFull[]

export type RMSCloudInlineResponse2009 = RMSCloudRateElements[]

/** @example {"id":1,"billingCategoryId":29,"categories":[{"categoryId":28,"order":1},{"categoryId":29,"order":2}],"description":"Kings & Queens","categoryId":58,"propertyId":3} */
export interface RMSCloudInventoryGroupings {
  /** @format int32 */
  billingCategoryId?: number
  categories?: RMSCloudInventoryGroupingsCategories[]
  /** @format int32 */
  categoryId?: number
  description?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
}

/** @example [{"categoryId":28,"order":1},{"categoryId":29,"order":2}] */
export interface RMSCloudInventoryGroupingsCategories {
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  order?: number
}

/** @example {"propertyId":3} */
export interface RMSCloudInventoryGroupingsSearch {
  /** @format int32 */
  propertyId?: number
}

/** @example {"id":1269,"accountId":12990785,"accountType":"Accomm","cancelledDate":"1900-00-00 00:00:00","guestId":9984588,"companyId":0,"createdDate":"2018-09-27 00:00:00","invoiceAmount":100,"propertyId":2,"reservationId":35421} */
export interface RMSCloudInvoice {
  /** @format int32 */
  accountId?: number
  accountType?: string
  /**
   * if this field is populated with a real date then this invoice has been cancelled
   * @format date-time
   */
  cancelledDate?: string
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  createdDate?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  /** @format decimal */
  invoiceAmount?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  reservationId?: number
}

/** @example {"accountId":361450,"invoiceId":123,"propertyId":1,"reasonId":3} */
export interface RMSCloudInvoiceCancel {
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  invoiceId: number
  /** @format int32 */
  propertyId: number
  /** @format int32 */
  reasonId?: number
}

/** @example {"accountId":5,"accountType":"Accomm"} */
export interface RMSCloudInvoiceCreate {
  /** @format int32 */
  accountId?: number
  /** @default "standard" */
  accountType?: RMSCloudInvoiceCreateAccountTypeEnum
}

/** @default "standard" */
export enum RMSCloudInvoiceCreateAccountTypeEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Standard = 'standard',
  Water = 'water',
}

/** @example {"ids":[545456,45748],"accountId":6456545,"fromEmail":"test@test.com","email":["apisupport@rms.com.au","apisupport@rmscloud.com"]} */
export interface RMSCloudInvoiceEmail {
  /** @format int32 */
  accountId?: number
  email?: string[]
  /**
   * This field is optional, if this field is left empty we will send the email from the email configured under propertie options
   * @format email
   */
  fromEmail?: string
  ids?: number[]
}

/** @example {"ids":[12,5,702],"accountIds":[1242,5985,702],"cancelledFrom":"2018-09-25 00:00:00","cancelledTo":"2018-09-27 00:00:00","createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","propertyId":1,"reservationIds":[12426,454566,646646]} */
export interface RMSCloudInvoiceSearch {
  accountIds?: number[]
  /** @format date-time */
  cancelledFrom?: string
  /** @format date-time */
  cancelledTo?: string
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  ids?: number[]
  /** @format int32 */
  propertyId?: number
  reservationIds?: number[]
}

/**
 * Used:GET /properties/{id}/ibe/bookingSources
 * @example {"id":1,"name":"Return Guest"}
 */
export interface RMSCloudItemLite {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":1,"name":"Manager"} */
export interface RMSCloudItemLiteUser {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"account1":"Accomm","account2":"Extras","gas":"Gas","electricity":"Elec","water":"Water","eftposManual":"EFTPOS","eftposPaymentGateway":"EFTPOS Machine","cash2":"Other Cash","cash3":"Cash 3","cash4":"Cash 4","cash5":"Cash 5","cheque2":"Other Cheque","cheque3":"Cheque 3","cheque4":"Cheque 4","cheque5":"Cheque 5","directCredit":"direct credit","directCredit2":"direct credit 2","directCredit3":"direct credit 3","directCredit4":"direct credit 4","directCredit5":"direct credit 5","tax":"GST"} */
export interface RMSCloudLabelAccounting {
  account1?: string
  account2?: string
  cash2?: string
  cash3?: string
  cash4?: string
  cash5?: string
  cheque2?: string
  cheque3?: string
  cheque4?: string
  cheque5?: string
  directCredit2?: string
  directCredit3?: string
  directCredit4?: string
  directCredit5?: string
  directCredit?: string
  eftposManual?: string
  eftposPaymentGateway?: string
  electricity?: string
  gas?: string
  tax?: string
  water?: string
}

/** @example {"userDefined1":"Fancy Charge 1","userDefined2":"Fancy Charge 2","userDefined3":"Fancy Charge 3","userDefined4":"Fancy Charge 4","userDefined5":"Fancy Charge 5","userDefined6":"Fancy Charge 6","userDefined7":"Fancy Charge 7"} */
export interface RMSCloudLabelAdditional {
  userDefined1?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
}

/** @example {"userDefined1":"Bill ID","userDefined2":"Grandmas Name","userDefined3":"Birth country","userDefined4":"Spare key No","userDefined5":"File No","userDefined6":"Refrigerator id","userDefined7":"Owner name","userDefined8":"Ghost name","userDefined9":"Pancake","userDefined10":"Spoons"} */
export interface RMSCloudLabelArea {
  userDefined1?: string
  userDefined10?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
}

/** @example {"userDefined1":"Computer","userDefined2":"Gum","userDefined3":"Phone","userDefined4":"Spare keys","userDefined5":"Calanders","userDefined6":"Tissues","userDefined7":"Bottles","userDefined8":"Headsets","userDefined9":"Pancake","userDefined10":"Lip balm"} */
export interface RMSCloudLabelAsset {
  userDefined1?: string
  userDefined10?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
}

/** @example {"userDefined1":"Bill ID","userDefined2":"Grandmas Name","userDefined3":"Birth country","userDefined4":"Spare key No","userDefined5":"File No","userDefined6":"Refrigerator id","userDefined7":"Owner name","userDefined8":"Ghost name","userDefined9":"Pancake"} */
export interface RMSCloudLabelCategory {
  userDefined1?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
}

/** @example {"userDefined1":"Computer IP","userDefined2":"Mums address","userDefined3":"Phone","userDefined4":"Spare keys","userDefined5":"Calanders","userDefined6":"Tissues","userDefined7":"Bottles","userDefined8":"Headsets","userDefined9":"Pancakes","userDefined10":"Lip balm","userDefined11":"breakfast","userDefined12":"stationary kit","userDefined13":false,"userDefined14":true,"userDefined15":"2018-08-25 17:25:00","userDefined16":"2018-09-25 13:25:00"} */
export interface RMSCloudLabelGuest {
  userDefined1?: string
  userDefined10?: string
  userDefined11?: string
  userDefined12?: string
  userDefined13?: boolean
  userDefined14?: boolean
  /** @format date-time */
  userDefined15?: string
  /** @format date-time */
  userDefined16?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
}

/** @example {"accommodation":"Cabin","dock":"Jetty","site":"Site"} */
export interface RMSCloudLabelIbe {
  accommodation?: string
  dock?: string
  site?: string
}

/** @example {"userDefined1":"Computer","userDefined2":"Gum","userDefined3":"Phone","userDefined4":"Spare keys","userDefined5":"Calanders"} */
export interface RMSCloudLabelProperty {
  userDefined1?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
}

/** @example {"userDefined1":"Computer IP","userDefined2":"Mums address","userDefined3":"Phone","userDefined4":"Spare keys","userDefined5":"Calanders","userDefined6":"Tissues","userDefined7":"Bottles","userDefined8":"Headsets","userDefined9":"Pancakes","userDefined10":"Lip balm","userDefined11":false,"userDefined12":true,"userDefined13":true,"userDefined14":"2018-08-25 17:25:00","userDefined15":"2018-08-25 17:25:00","userDefined16":"Blank"} */
export interface RMSCloudLabelReservation {
  userDefined1?: string
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  userDefined16?: RMSCloudLabelReservationUserDefined16Enum
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
}

export enum RMSCloudLabelReservationUserDefined16Enum {
  Blank = 'Blank',
  True = 'true',
  False = 'false',
}

/** @example {"abn":"ABN","activity":"Exercise","addOn":"Add Ons","adult":"Adults","area":"Room","arrive":"Arrival","bannedList":"Black List","boat":"Jet Ski","bookingSource":"bkg source","businessSegment":"Business Segment","category":"Room Type","child":"Kids","clientStatus":"Guest Status","client":"Guest","company":"Company","companyUnknown":"Unknown","coordinator1":"Coordinator 1","coordinator2":"Coordinator 2","depart":"Departing","dwelling":"RV","edmFilter1OptOut":"EDM Filter 1 Opt Out","edmFilter2OptOut":"EDM Filter 2 Opt Out","edmFilter3OptOut":"EDM Filter 3 Opt Out","eventName":"Event Name","given":"First","groupName":"Group","hold":"Reserve","housekeeperNote":"Cleaning Note","housekeepingUnitOfTime":"Min","infant":"Infants","loyalty":"Loyalty","maintenance":"Out Of Order","mealPlan":"Meal Plan","occupant":"Occupant","otaRef1":"Online Number","otaRef2":"Customer number","otaRef3":"Channel manager number","postcode":"Zip Code","postalCode":"Postal Sort","privacyOptIn":"Privacy Opt In","rate":"Rate","resNote":"Reservation Notes","resType":"Reservation Type","reservation":"Reservation","state":"State","sundry":"Charges","surname":"Last Name","town":"City","travelAgent":"Agent","voucherNo.":"Voucher Number","wholesaler":"Wholesaler"} */
export interface RMSCloudLabelSystem {
  coordinator1?: string
  coordinator2?: string
  edmFilter1OptOut?: string
  edmFilter2OptOut?: string
  edmFilter3OptOut?: string
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  'voucherNo.'?: string
  abn?: string
  activity?: string
  addOn?: string
  adult?: string
  area?: string
  arrive?: string
  bannedList?: string
  boat?: string
  bookingSource?: string
  businessSegment?: string
  category?: string
  child?: string
  client?: string
  clientStatus?: string
  company?: string
  companyUnknown?: string
  depart?: string
  dwelling?: string
  eventName?: string
  given?: string
  groupName?: string
  hold?: string
  housekeeperNote?: string
  housekeepingUnitOfTime?: string
  infant?: string
  loyalty?: string
  maintenance?: string
  mealPlan?: string
  occupant?: string
  postalCode?: string
  postcode?: string
  privacyOptIn?: string
  rate?: string
  resNote?: string
  resType?: string
  reservation?: string
  state?: string
  sundry?: string
  surname?: string
  town?: string
  travelAgent?: string
  wholesaler?: string
}

/** @example {"id":1,"level":"Bronze","minimumRequiredPoints":200,"multiplier":"1.00"} */
export interface RMSCloudLoyaltyLevel {
  /** @format int32 */
  id?: number
  level?: string
  /** @format number */
  minimumRequiredPoints?: number
  /** @format decimal */
  multiplier?: number
}

/** @example {"id":0,"areaId":13,"dateFrom":"2023-03-20 10:00:00","dateTo":"2023-03-21 17:30:00","cancelledDate":"1900-01-01","categoryId":4,"notes":"aircon is broken","reasonId":36} */
export interface RMSCloudMaintenance {
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  cancelledDate?: string
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format int32 */
  id?: number
  note?: string
  /** @format int32 */
  reasonId?: number
}

/** @example [{"entity":"Guest","name":"Given","onCheckin":false,"onSave":true},{"entity":"Reservation","name":"Company","onCheckin":true,"onSave":true}] */
export interface RMSCloudMandatoryField {
  entity?: RMSCloudMandatoryFieldEntityEnum
  name?: string
  onCheckin?: boolean
  onSave?: boolean
}

export enum RMSCloudMandatoryFieldEntityEnum {
  Guest = 'Guest',
  Reservation = 'Reservation',
}

/** @example {"id":1,"name":"Test"} */
export interface RMSCloudMarketTypes {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":1,"code":"OOL","description":"Coolangatta","shortDescription":"Coolangatta"} */
export interface RMSCloudMaster {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  shortDescription?: string
}

/** @example {"id":72,"cardId":"99986a","companyId":8,"expiryDate":"2018-09-25 17:25:00","guestId":11457,"mealsAllowed":"Both","mealsCustom":"Breakfast","propertyId":1,"startingDate":"2018-08-25 17:25:00"} */
export interface RMSCloudMealCard {
  cardId?: string
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  expiryDate?: string
  guestId?: number
  /** @format int32 */
  id?: number
  mealsAllowed?: string
  mealsCustom?: string
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  startingDate?: string
}

/** @example {"id":2,"description":"Breakfast","code":"BFST","breakfast":true,"lunch":false,"dinner":false} */
export interface RMSCloudMealPlan {
  breakfast?: boolean
  code?: string
  description?: string
  dinner?: boolean
  /** @format int32 */
  id?: number
  lunch?: boolean
}

/** @example {"reservationIds":[17117,17118],"dateFor":"2022-09-04","dateFrom":"2022-09-01","dateTo":"2022-09-05"} */
export interface RMSCloudMealPlanSchedulesSearch {
  /** @format date-time */
  dateFor?: string
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  reservationIds?: number[]
}

/** @example {"reservationId":1234,"mealPlanId":12,"dates":[{"theDate":"2023-02-20","mealPlanUpgradeId":14,"startingMeal":"Dinner"},{"theDate":"2023-02-21","mealPlanUpgradeId":14,"startingMeal":""}]} */
export interface RMSCloudMealPlanSchedulesSearchResponse {
  dates?: RMSCloudMealPlanSearchResponseDates[]
  mealPlanId?: number
  reservationId?: number
}

export interface RMSCloudMealPlanSchedulesUpgrade {
  dates?: RMSCloudMealPlanSearchResponseDates[]
}

export interface RMSCloudMealPlanSearchResponseDates {
  mealPlanUpgradeId?: number
  startingMeal?: RMSCloudMealPlanSearchResponseDatesStartingMealEnum
  /** @format date */
  theDate?: string
}

export enum RMSCloudMealPlanSearchResponseDatesStartingMealEnum {
  Breakfast = 'Breakfast',
  Lunch = 'Lunch',
  Dinner = 'Dinner',
}

/** @example {"code":"FF1","membershipType":"FrequentFlyer","level1Code":"Bronze","level2Code":"Silver","level3Code":"Gold","level4Code":"Platinum","level5Code":"Diamond","level6Code":"BETTER THA","level7Code":"","level8Code":"","level9Code":"","level10Code":"","id":1,"name":"Frequent Flyer"} */
export interface RMSCloudMembershipType {
  level10Code?: string
  level1Code?: string
  level2Code?: string
  level3Code?: string
  level4Code?: string
  level5Code?: string
  level6Code?: string
  level7Code?: string
  level8Code?: string
  level9Code?: string
  code?: string
  /** @format int32 */
  id?: number
  membershipType?: string
  name?: string
}

/** @example {"Body":"An additonal Guest was added to this reservation","guestId":138500,"header1":"COVID-19 Declaration","propertyId":1,"reservationId":163706,"subject":"COVID-19 Warning"} */
export interface RMSCloudMessageCentreGuestPortalNotification {
  header1?: string
  Body?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  reservationId?: number
  subject?: string
}

/** @example {"id":15,"message":"<p class=\"bold rmsRow\">COVID-19 Declaration</p><br/>An additonal Guest was added to this reservation<br/>","propertyId":1,"subject":"COVID-19 Warning"} */
export interface RMSCloudMessageCentreGuestPortalNotificationResponse {
  /** @format int32 */
  id?: number
  message?: string
  /** @format int32 */
  propertyId?: number
  subject?: string
}

/** @example {"propertyId":1,"note":"Do not give suites to employees"} */
export interface RMSCloudNotes {
  note?: string
  /** @format int32 */
  propertyId?: number
}

/** @example {"id":12,"propertyId":1,"note":"Do not give suites to employees","billingNote":"500 DLLS MAX. Maybe?"} */
export interface RMSCloudNotesResponse {
  billingNote?: string
  /** @format int32 */
  id?: number
  note?: string
  /** @format int32 */
  propertyId?: number
}

/** @example {"id":1,"code":"AMO","description":"Austrian Main Office on level 3","shortDescription":"Coolangatta the bestest place evs"} */
export interface RMSCloudOrigin {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  shortDescription?: string
}

/** Used in Rate Breakdown */
export interface RMSCloudPackageBreakdown {
  /** @format currency */
  perExtra4Fee?: number
  /** @format currency */
  perExtra5Fee?: number
  /** @format currency */
  perExtra6Fee?: number
  /** @format currency */
  perExtra7Fee?: number
  /** @format currency */
  perExtra8Fee?: number
  /** @format currency */
  amount?: number
  /** @format int32 */
  auantity?: number
  baseIncludesPackageAmount?: boolean
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  packageFeeType?: number
  /** @format int32 */
  packageId?: number
  /** @format currency */
  perAdultFee?: number
  /** @format currency */
  perChildFee?: number
  /** @format currency */
  perInfantFee?: number
  /** @format int32 */
  sundryId?: number
  sundryName?: string
  taxBreakdown?: RMSCloudTaxBreakdown[]
  /** @format date-time */
  theDate?: string
  /** @format currency */
  totalTax?: number
}

/** @example {"billTo":{"account1":"company","account2":"client","phone":"company","electricty":"company","gas":"company","water":"company"},"kiosk":{"payAtArrival":"LocalTaxesOnly","payAtDeparture":"NoCharge"},"inactive":false,"id":7,"code":"Accom To Company Pay Own Extras","description":"GREAT PAYMENT MODE"} */
export interface RMSCloudPaymentModes {
  billTo?: RMSCloudPaymentModesBillTo[]
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  kiosk?: RMSCloudPaymentModesKiosk[]
}

export interface RMSCloudPaymentModesBillTo {
  account1?: string
  account2?: string
  electricty?: string
  gas?: string
  phone?: string
  water?: string
}

export interface RMSCloudPaymentModesKiosk {
  payAtArrival?: RMSCloudPaymentModesKioskPayAtArrivalEnum
  payAtDeparture?: RMSCloudPaymentModesKioskPayAtDepartureEnum
}

export enum RMSCloudPaymentModesKioskPayAtArrivalEnum {
  NoCharge = 'NoCharge',
  LocalTaxesOnly = 'LocalTaxesOnly',
  FullRateIncAllTaxes = 'FullRateIncAllTaxes',
}

export enum RMSCloudPaymentModesKioskPayAtDepartureEnum {
  NoCharge = 'NoCharge',
  AllBalances = 'AllBalances',
  UseBillTo = 'UseBillTo',
}

/** @example {"businessFacilities":"This section will outline Business Facilities.","carParking":"There is a charge for extra vehicles, daily parking and other space consuming devices which accompany travelers, except for those which are exempt from extra charges.","cancellationPolicy":"CANCELLATION POLICY - cancellation is free of charge up to 48 hours prior to 2pm on your arrival date. Any booking modifications, including date changes and/or a full cancellation of your booking made within 48 hours of 2pm on your arrival date will incur a charge of the first night booked. Any booking modifications requested after check in must occur at least 48 hours prior to the change taking place to avoid any charges. NO SHOW POLICY - Failure to arrive at the property, on the booked check-in date, will be treated as a no-show and will incur the first night charge. Please note the remainder of the booking will be cancelled.","description":"Rachel's Ritzy Resort is a class above the rest!!!","directions":"Travel Directions for guests. For easiest access to the property the best route to follow to arrive safely is the most direct route which comes in from the south, as this is the only route which provides road access, although many of you may wish to take the scenic alternative","features":"This section will outline Property Features.","petPolicy":"Those pets which have returned from the taxidermist and now exhibit none of their former feral aromas or lifestyle are most welcome.  These beasts must be restrained at all times and are not allowed outside at any time without close attentive supervision.","terms":"AFTER-HOURS ARRIVALS - reception hours are from 8am to 6pm daily. If you are arriving outside of these hours, please contact the lodge at least 24 hours prior to 2pm on your arrival date to arrange an after-hours key collection. CHECK-IN POLICY - The person who's name the room was booked under must be present and part of the travelling party staying at the lodge. THIRD PARTY PAYMENT POLICY - If any room nights or additional charges are to be paid for by a third party, or anyone else other than the person who's name the booking was made under, the lodge must be notified more than 48 hours prior to 2pm on your arrival date.","thingsToDo":"Outlines things to do at the property."} */
export interface RMSCloudPolicy {
  /** @format string */
  businessFacilities?: any
  /** @format string */
  cancellationPolicy?: any
  /** @format string */
  carParking?: any
  /** @format string */
  description?: any
  /** @format string */
  directions?: any
  /** @format string */
  features?: any
  /** @format string */
  petPolicy?: any
  /** @format string */
  terms?: any
  /** @format string */
  thingsToDo?: any
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudPostAgentSearchParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudPostAreaSearchParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudPostCompanySearchParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudPostGuestSearchParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/**
 * Only these fields will be returned
 * @default "basic"
 */
export enum RMSCloudPostReservationSearchParamsModelTypeEnum {
  Basic = 'basic',
  Lite = 'lite',
  Full = 'full',
}

/** @example {"id":72,"tax":null,"total":null,"totalTaxExcludingGST":null} */
export interface RMSCloudProjectedAccount {
  /** @format int32 */
  id?: number
  /** @format currency */
  tax?: number
  /** @format currency */
  total?: number
  /** @format currency */
  totalTaxExcludingGST?: number
}

/** @example {"TaxOption":"TaxInclusive","allowPOSChargeToRoom":true,"maxPOSAmountForStay":0,"posAccountId":131353,"cashAccountId":124752,"allowSplitAccounts":true,"allowedAccountTypes":{"accommodation":true,"extras":true,"gas":true,"electricity":true,"water":true,"pabx":true},"postToAccommodationAccount":{"accommodation":true,"extras":false,"gas":false,"electricity":false,"water":false,"pabx":true}} */
export interface RMSCloudPropertiesAccounting {
  /** @format currency */
  MaxPOSAmountForStay?: number
  allowPOSChargeToRoom?: boolean
  allowSplitAccounts?: boolean
  allowedAccountTypes?: RMSCloudPropertiesAccountingAllowedAccountTypes
  /** @format int32 */
  cashAccountId?: number
  /** @format int32 */
  posAccountId?: number
  taxOption?: RMSCloudPropertiesAccountingTaxOptionEnum
}

export interface RMSCloudPropertiesAccountingAllowedAccountTypes {
  accommodation?: boolean
  electricity?: boolean
  extras?: boolean
  gas?: boolean
  pabx?: boolean
  water?: boolean
}

export enum RMSCloudPropertiesAccountingTaxOptionEnum {
  TaxInclusive = 'TaxInclusive',
  TaxExclusive = 'TaxExclusive',
}

/** @example {"id":1,"name":"Mexican Shores","accountingDate":"2019-09-25 17:25:00","inactive":true,"code":"2598r","rmsClientId":"11281","timeZoneId":"AUS Eastern Standard Time","useSecondaryCurrency":"useDefault"} */
export interface RMSCloudPropertiesBasic {
  /** @format date-time */
  accountingDate?: string
  code?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
  rmsClientId?: number
  timeZoneId?: string
  /** useDefault */
  useSecondaryCurrency?: RMSCloudPropertiesBasicUseSecondaryCurrencyEnum
}

/** useDefault */
export enum RMSCloudPropertiesBasicUseSecondaryCurrencyEnum {
  UseDefault = 'useDefault',
  True = 'true',
  False = 'false',
}

/** @example {"eBanquetEndOfDay":"2021-06-18 00:00:00","propertyId":1} */
export interface RMSCloudPropertiesEBanquetEndOfDay {
  /** @format date-time */
  eBanquetEndOfDay?: string
  /** @format int32 */
  propertyId?: number
}

/** @example {"eBanquetEndOfDay":"2021-06-18 00:00:00","propertyId":1} */
export interface RMSCloudPropertiesEBanquetEndOfDayUpdate {
  /** @format date-time */
  eBanquetEndOfDay: string
  /**
   * This field is informational only and not required in the request body
   * @format int32
   */
  propertyId?: number
}

/** @example {"id":1,"name":"Mexican Shores","abn":"123 123 15","accountingDate":"2019-09-25 17:25:00","inactive":true,"addressLine1":"116","addressLine2":"Harrick Road","addressLine3":"","addressLine4":"","city":"Keilor Park","code":"2598r","country":"Australia","email":"apisupport@rms.com.au","groupingId":2,"latitude":"-37.723050","longitude":"144.845970","mobile":"+61412345123","phone":"03 1245 4589","postcode":"32A45","pricingOption":"Use Property","rmsClientId":"11281","state":"Vic","timeZoneId":"AUS Eastern Standard Time","useSecondaryCurrency":"useDefault"} */
export interface RMSCloudPropertiesFull {
  addressLine1?: string
  addressLine2?: string
  addressLine3?: string
  addressLine4?: string
  /** Australian Business Number */
  abn?: string
  /** @format date-time */
  accountingDate?: string
  city?: string
  clientId?: number
  code?: string
  /** @format int32 */
  countryId?: number
  email?: string
  /** @format int32 */
  groupId?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  latitude?: string
  longitude?: string
  mobile?: string
  name?: string
  phone?: string
  postcode?: string
  pricingOption?: string
  state?: string
  timeZone?: string
  /** useDefault */
  useSecondaryCurrency?: RMSCloudPropertiesFullUseSecondaryCurrencyEnum
}

/** useDefault */
export enum RMSCloudPropertiesFullUseSecondaryCurrencyEnum {
  UseDefault = 'useDefault',
  True = 'true',
  False = 'false',
}

/** @example {"id":1,"name":"Mexican Shores","inactive":true} */
export interface RMSCloudPropertiesLite {
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
}

/** @example {"posEndOfDay":"2021-06-18 00:00:00","propertyId":1} */
export interface RMSCloudPropertiesPosEndOfDay {
  /** @format date-time */
  posEndOfDay?: string
  /** @format int32 */
  propertyId?: number
}

/** @example {"posEndOfDay":"2021-06-18 00:00:00","propertyId":1} */
export interface RMSCloudPropertiesPosEndOfDayUpdate {
  /** @format date-time */
  posEndOfDay: string
  /**
   * This field is informational only and not required in the request body
   * @format int32
   */
  propertyId?: number
}

/** @example {"cancellationPolicyId":0,"bookingSourceId":180,"discountId":97,"glCodeId":39,"longDescription":"This is the Long Description","marketSegmentId":55,"mealPlanId":0,"rateChargeDescription":"Test Property1 BAR","advancePurchaseNights":0,"lastMinuteNights":0} */
export interface RMSCloudPropertyRules {
  /** @format int32 */
  advancePurchaseNights?: number
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  cancellationPolicyId?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  lastMinuteNights?: number
  longDescription?: string
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  rateChargeDescription?: string
}

/** @example {"propertyIds":[1,4],"rateIds":[1276,1281]} */
export interface RMSCloudPropertyRulesSearch {
  propertyIds?: number[]
  rateIds?: number[]
}

/** only these statuses will be excepted */
export enum RMSCloudPutBoomgatesReservationStatusParamsStatusEnum {
  In = 'in',
  Out = 'out',
}

/** Only these statuses will be accepted */
export enum RMSCloudPutUpdateAreaCleanStatusParamsStatusEnum {
  Maintenance = 'maintenance',
  VacantClean = 'vacantClean',
  VacantDirty = 'vacantDirty',
  VacantInspect = 'vacantInspect',
}

/**
 * Used:<br>POST /rates/rateQuote<br>
 * @example {"additional1":1,"additional2":2,"additional3":1,"additional4":0,"additional5":0,"additional6":2,"additional7":2,"adults":2,"agentId":1,"areaId":1,"arrivalDate":"2018-11-01 10:00:00","categoryId":4,"children":1,"departureDate":"2018-11-05 13:25:00","discountId":2,"ignoreRateRestrictions":false,"includeTaxBreakdown":true,"infants":1,"propertyId":1,"rateTypeId":2,"secondDiscountId":2,"useIbeDepositRules":true,"allotmentAssociationId":"travelAgent","includeAvailableAreas":true}
 */
export interface RMSCloudQuoteRequest {
  /** @format int32 */
  additional1?: number
  /** @format int32 */
  additional2?: number
  /** @format int32 */
  additional3?: number
  /** @format int32 */
  additional4?: number
  /** @format int32 */
  additional5?: number
  /** @format int32 */
  additional6?: number
  /** @format int32 */
  additional7?: number
  /** @format int32 */
  adults: number
  /** @format int32 */
  agentId: number
  allotmentAssociationId?: RMSCloudQuoteRequestAllotmentAssociationIdEnum
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /** @format int32 */
  categoryId: number
  /** @format int32 */
  children?: number
  /** @format date-time */
  departureDate?: string
  /** @format int32 */
  discountId?: number
  ignoreRateRestrictions?: boolean
  includeAvailableAreas?: boolean
  includeTaxBreakdown?: boolean
  /** @format int32 */
  infants?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  rateTypeId: number
  /** @format int32 */
  secondDiscountId?: number
  useIbeDepositRules?: boolean
}

export enum RMSCloudQuoteRequestAllotmentAssociationIdEnum {
  TravelAgent = 'TravelAgent',
}

/**
 * Used:<br>POST /rates/rateQuote<br>
 * @example {"baseRate":1150,"baseRateDiscountAmount":0,"baseRateRentalReductionAmount":0,"baseRateTax":115,"categoryId":4,"deposit1Amount":376.25,"deposit1RequiredBy":"2023-06-13 10:10:34","deposit2Amount":0,"deposit2RequiredBy":"0001-01-01 00:00:00","discountAmount":0,"firstNightRate":1505,"package":240,"packageTax":0,"rateBreakdown":[{"baseRateAmount":1150,"baseRateRaw":800,"currencyCode":"AUD","currencySymbol":"$","displayBaseRate":800,"displayTotalPackage":240,"displayTotalRate":1505,"displayTotalTax":50,"packageAmount":240,"packageBreakdown":[{"amount":240,"baseIncludesPackageAmount":false,"glCodeId":24,"packageFeeType":1,"packageId":23910,"perAdultFee":20,"perChildFee":0,"perExtra4Fee":20,"perExtra5Fee":40,"perExtra6Fee":0,"perExtra7Fee":0,"perExtra8Fee":0,"perInfantFee":0,"auantity":0,"sundryId":3,"sundryName":"B1 B/Fast food","taxBreakdown":[{"amount":1,"description":"B1 B/Fast food Taxes","packageId":1,"perAdultFee":10,"perInfantFee":10,"perPersonAdditionalTax":true,"perPersonPercentage":0,"perPersonPercentageAdditionalPercentage":0,"perPersonPercentageCapped":false,"perPersonPercentageCappedAmount":0,"serviceCharge":false,"taxExemptionApplied":false,"taxId":3,"taxMethod":0,"theDate":"2018-09-03 00:00:00"}],"totalTax":30,"theDate":"2023-06-15 00:00:00"}],"packageHiddenAmount":0,"packageShownAmount":240,"rateType":"Rate 1","rateTypeId":3,"theDate":"2023-06-15 00:00:00","totalExtras":350,"totalPackage":240,"totalPackageIncludedInBase":0,"totalPackageNotIncludedInBase":240,"totalRate":1390,"taxBreakdown":[{"amount":10,"description":"10% State Tax"},{"amount":9,"description":"SGST 9"}]}],"secondDiscountAmount":0,"useResDiscountNightly":false,"cancellationPolicyId":1}
 */
export interface RMSCloudQuoteResponse {
  /** @format currency */
  deposit1Amount?: number
  /** @format date-time */
  deposit1RequiredBy?: string
  /** @format currency */
  deposit2Amount?: number
  /** @format date-time */
  deposit2RequiredBy?: string
  /** @format currency */
  baseRate?: number
  /** @format currency */
  baseRateDiscountAmount?: number
  /** @format currency */
  baseRateRentalReductionAmount?: number
  /** @format currency */
  baseRateTax?: number
  /** @format in32 */
  cancellationPolicyId?: number
  /** @format in32 */
  categoryId?: number
  /** @format currency */
  discountAmount?: number
  /** @format currency */
  firstNightRate?: number
  /** @format currency */
  package?: number
  /** @format currency */
  packageTax?: number
  rateBreakdown?: RMSCloudRateBreakdown[]
  /** @format currency */
  secondDiscountAmount?: number
  taxBreakdown?: RMSCloudQuoteResponseTaxBreakdown[]
  useResDiscountNightly?: boolean
}

export interface RMSCloudQuoteResponseTaxBreakdown {
  amount?: number
  description?: string
}

/** @example {"id":1377,"categoryInfo":[{"basePeople":2,"categoryId":4,"dailyRate":140,"dateFrom":"2020-02-10 00:00:00","dateTo":"2020-02-15 00:00:00","minimumStay":2},{"basePeople":2,"categoryId":6,"dailyRate":240,"dateFrom":"2020-02-10 00:00:00","dateTo":"2020-02-15 00:00:00","minimumStay":2}]} */
export interface RMSCloudRateAdjustmentRequest {
  categoryInfo?: RMSCloudRateAdjustmentRequestVariable[]
  /** @format int32 */
  id?: number
}

export interface RMSCloudRateAdjustmentRequestVariable {
  /** @format int32 */
  basePeople?: number
  /** @format int32 */
  categoryId?: number
  /** @format currency */
  dailyRate?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format int32 */
  minimumStay?: number
}

/** Used in Quote Response */
export interface RMSCloudRateBreakdown {
  /** @format currency */
  baseRateAmount?: number
  /** @format currency */
  baseRateRaw?: number
  currencyCode?: string
  currencySymbol?: string
  /** @format currency */
  displayBaseRate?: number
  /** @format currency */
  displayTotalPackage?: number
  /** @format currency */
  displayTotalRate?: number
  /** @format currency */
  displayTotalTax?: number
  /** @format currency */
  packageAmount?: number
  packageBreakdown?: RMSCloudPackageBreakdown[]
  /** @format currency */
  packageHiddenAmount?: number
  /** @format currency */
  packageShownAmount?: number
  rateType?: string
  /** @format int32 */
  rateTypeId?: number
  /** @format date-time */
  theDate?: string
  /** @format currency */
  totalExtras?: number
  /** @format currency */
  totalPackage?: number
  /** @format currency */
  totalPackageIncludedInBase?: number
  /** @format currency */
  totalPackageNotIncludedInBase?: number
  /** @format currency */
  totalRate?: number
}

/** @example {"id":1,"code":"RE1","description":"Rate Element 1"} */
export interface RMSCloudRateElements {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
}

/** @example {"areaId":null,"clientId":11282,"categories":[{"categoryId":1,"rates":[{"rateId":1159,"personBase":2,"dayBreakdown":[{"availableAreas":0,"closedOnArrival":false,"closedOnDeparture":false,"dailyRate":395,"dateFrom":"2024-06-29","dateTo":"2024-06-29","minStay":0,"minStayOnArrival":0,"maxStay":0,"stopSell":false}],"additionals":{"adults":[{"additionalCount":1,"amount":60},{"additionalCount":2,"amount":60}],"children":[{"additionalCount":1,"amount":60},{"additionalCount":2,"amount":60}],"infants":[{"additionalCount":1,"amount":60},{"additionalCount":2,"amount":60}],"adultsBase":{"includeInBase":true,"personBase":2},"childrenBase":{"includeInBase":false,"personBase":0},"infantsBase":{"includeInBase":false,"personBase":0}}}]}]} */
export interface RMSCloudRateGridARIPushResponse {
  areaId?: string | null
  categories?: RMSCloudRateGridARIPushResponseCategories[]
  clientId?: number
}

export interface RMSCloudRateGridARIPushResponseAdditionals {
  adults?: RMSCloudRateGridARIPushResponseAdditionalsAdults[] | null
  adultsBase?: RMSCloudRateGridARIPushResponseAdditionalsAdultsBase
  children?: RMSCloudRateGridARIPushResponseAdditionalsAdults[] | null
  childrenBase?: RMSCloudRateGridARIPushResponseAdditionalsAdultsBase
  infants?: RMSCloudRateGridARIPushResponseAdditionalsAdults[] | null
  infantsBase?: RMSCloudRateGridARIPushResponseAdditionalsAdultsBase
}

export interface RMSCloudRateGridARIPushResponseAdditionalsAdults {
  additionalCount?: number
  /** @format float */
  amount?: number
}

export type RMSCloudRateGridARIPushResponseAdditionalsAdultsBase = {
  includeInBase?: boolean
  personBase?: number
} | null

export interface RMSCloudRateGridARIPushResponseCategories {
  categoryId?: number
  rates?: RMSCloudRateGridARIPushResponseRates[]
}

export interface RMSCloudRateGridARIPushResponseDayBreakdown {
  availableAreas?: number
  closedOnArrival?: boolean
  closedOnDeparture?: boolean
  /** @format float */
  dailyRate?: number
  /** @format date */
  dateFrom?: string
  /** @format date */
  dateTo?: string
  maxStay?: number
  minStay?: number
  minStayOnArrival?: number
  stopSell?: boolean
}

export interface RMSCloudRateGridARIPushResponseRates {
  additionals?: RMSCloudRateGridARIPushResponseAdditionals
  dayBreakdown?: RMSCloudRateGridARIPushResponseDayBreakdown[]
  personBase?: number
  rateId?: number
}

/** @example {"timeIncrement":15,"facilities":[{"rateId":1159,"rateName":"OTA Rate [Main]","categoryId":9,"categoryName":"Deluxe 009","areas":[{"areaId":36,"areaName":"01 036","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":37,"areaName":"01 037","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":107,"areaName":"01 107","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":109,"areaName":"01 109","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":110,"areaName":"01 110","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":111,"areaName":"01 111","availability":[{"available":true,"rate":400,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":400,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]}]},{"rateId":1420,"rateName":"Facility hourly","categoryId":9,"categoryName":"Deluxe 009","areas":[{"areaId":36,"areaName":"01 036","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":37,"areaName":"01 037","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":107,"areaName":"01 107","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":109,"areaName":"01 109","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":110,"areaName":"01 110","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]},{"areaId":111,"areaName":"01 111","availability":[{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:15:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:15:00","dateTo":"2023-02-10 06:30:00"},{"available":true,"rate":2.5,"dateFrom":"2023-02-10 06:30:00","dateTo":"2023-02-10 06:45:00"}]}]}]} */
export interface RMSCloudRateGridFacility {
  facilities?: RMSCloudRateGridRateFacility[]
  /** @format int32 */
  timeIncrement?: number
}

export interface RMSCloudRateGridItemFacility {
  available?: boolean
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format currency */
  rate?: number
}

export interface RMSCloudRateGridItemFacilityArea {
  /** @format int32 */
  areaId?: number
  areaName?: string
  availability?: RMSCloudRateGridItemFacility[]
}

export interface RMSCloudRateGridRateFacility {
  areas?: RMSCloudRateGridItemFacilityArea[]
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format int32 */
  rateId?: number
  rateName?: string
}

/**
 * Used:<br>POST /rates/grid
 * @example {"adults":2,"agentId":0,"allotmentAssociationId":"GroupAllotment","arrival":"2023-08-15","categoryIds":[4],"children":0,"departure":"2023-08-16","groupAllotmentId":2625,"includeEstimatedRates":false,"includeHouseUseForAllotments":true,"includeZeroRates":true,"infants":0,"rateIds":[1416]}
 */
export interface RMSCloudRateGridRequest {
  adults?: number
  /** @format int32 */
  agentId?: number
  allotmentAssociationId?: RMSCloudRateGridRequestAllotmentAssociationIdEnum
  /** @format date-time */
  arrival: string
  categoryIds: number[]
  /** @format int32 */
  children?: number
  /** @format date-string */
  departure: string
  /** @format int32 */
  groupAllotmentId?: number
  includeEstimatedRates?: boolean
  includeHouseUseForAllotments?: boolean
  includeZeroRates?: boolean
  /** @format int32 */
  infants?: number
  rateIds: number[]
}

export enum RMSCloudRateGridRequestAllotmentAssociationIdEnum {
  NotSet = 'NotSet',
  TravelAgent = 'TravelAgent',
  Wholesaler = 'Wholesaler',
  GroupAllotment = 'GroupAllotment',
}

/** @example {"adults":2,"agentId":1,"categoryIds":[9],"children":0,"dateFrom":"2023-02-10 06:00:00","dateTo":"2023-02-10 06:30:00","infants":0,"propertyId":1} */
export interface RMSCloudRateGridRequestFacility {
  /** @format int32 */
  adults?: number
  /** @format int32 */
  agentId?: number
  categoryIds?: number[]
  /** @format int32 */
  children?: number
  /**
   * A maximum of 1 days worth of data can be returned
   * @format date-time
   */
  dateFrom?: string
  /**
   * A maximum of 1 days worth of data can be returned
   * @format date-string
   */
  dateTo?: string
  /** @format int32 */
  infants?: number
  /** @format int32 */
  propertyId?: number
}

/** @example {"areaId":1,"categoryId":1,"rateId":1282,"rateName":"Staff, family & friends","periodId":372,"propertyId":1,"periodFrom":"2017-05-01 00:00:00","periodTo":"2021-01-16 23:59:59","periodDescription":"Low Season","tableId":5} */
export interface RMSCloudRateLookups {
  /** @format int32 */
  areaId?: number
  /** @format int32 */
  categoryId?: number
  periodDescription?: string
  /** @format date-time */
  periodFrom?: string
  /** @format int32 */
  periodId?: number
  /** @format date-time */
  periodTo?: string
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  rateId?: number
  rateName?: string
  /** @format int32 */
  tableId?: number
}

/** @example {"areaIds":[12,13],"categoryIds":[4,3],"rateIds":[1380,1159],"dateFrom":"2019-01-16 00:00:00","dateTo":"2021-01-16 23:59:59","excludeAllYearPeriods":true} */
export interface RMSCloudRateLookupsRequest {
  areaIds?: number[]
  categoryIds?: number[]
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  excludeAllYearPeriods?: boolean
  rateIds?: number[]
}

/** @example {"tableIds":[1,15,2],"rateIds":[1254,546],"propertyIds":[4]} */
export interface RMSCloudRatePackagesSearch {
  /** Pass in the propertyids to search for packages beloning to property rate rules */
  propertyIds?: number[]
  rateIds?: number[]
  tableIds?: number[]
}

/** @example {"id":123,"cancellationPolicyId":2,"dateFrom":"2019-01-16 00:00:00","dateTo":"2021-01-16 23:59:59","descirption":"Extended","minimumReservationPeriod":0,"noDiscountAllowed":false} */
export interface RMSCloudRatePeriod {
  /** @format int32 */
  cancellationPolicyId?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  descirption?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  minimumReservationPeriod?: number
  noDiscountAllowed?: boolean
}

/** @example {"id":21,"basedOn":"Night Of Week","cancellationPolicyId":3,"description":"10 Degrees Warmer LS","format":"Nightly","inactive":false,"minimumChargePerPeriod":0,"personBase":2,"mondayRate":375,"tuesdayRate":375,"wednesdayRate":375,"thursdayRate":375,"fridayRate":475,"saturdayRate":475,"sundayRate":375} */
export interface RMSCloudRateTable {
  basedOn?: string
  /** @format int32 */
  cancellationPolicyId?: number
  description?: string
  format?: string
  /** @format currency */
  fridayRate?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  /** @format currency */
  minimumChargePerPeriod?: number
  /** @format currency */
  mondayRate?: number
  /** @format int32 */
  personBase?: number
  /** @format currency */
  saturdayRate?: number
  /** @format currency */
  sundayRate?: number
  /** @format currency */
  thursdayRate?: number
  /** @format currency */
  tuesdayRate?: number
  /** @format currency */
  wednesdayRate?: number
}

/** @example {"id":124,"applyCharge":"every","applyChargeOnTheDate":1,"applyChargeOnTheDay":"Monday","makePackageInclusive":false,"percentageOfRate":[{"percentageOfRate":10,"rateFrom":100,"rateTo":250,"useIfRateFallsBetween":true}],"perPeriodFee":[{"amount":10,"quantity":1,"unitPrice":5,"useAmountFromSundry":false}],"perPersonFee":[{"additionalRateCharge1":5,"additionalRateCharge2":5,"additionalRateCharge3":5,"additionalRateCharge4":5,"additionalRateCharge5":5,"adults":5,"children":5,"infants":5,"minimumChargePerPeriod":10}],"postOnNextDay":false,"postToExtrasAccount":false,"propertyId":0,"showOnAccount":true,"showOnHousekeepersReport":false,"showOnToDoChart":true,"sundryId":7,"startingPeriod":"include","endingPeriod":"exclude"} */
export interface RMSCloudRateTablePackage {
  applyCharge?: RMSCloudRateTablePackageApplyChargeEnum
  /** @format int32 */
  applyChargeOnTheDate?: number
  applyChargeOnTheDay?: RMSCloudRateTablePackageApplyChargeOnTheDayEnum
  endingPeriod?: RMSCloudRateTablePackageEndingPeriodEnum
  /** @format int32 */
  id?: number
  /** This will include the packaged amount as part of the rate without increasing the overall price */
  makePackageInclusive?: boolean
  perPeriodFee?: RMSCloudRateTablePackagePerPeriodFee[]
  perPersonFee?: RMSCloudRateTablePackagePerPersonFee[]
  percentageOfRate?: RMSCloudRateTablePackagePercentageOfRate[]
  postOnNextDay?: boolean
  postToExtrasAccount?: boolean
  /**
   * This value will be returned if the package belongs to a property rate rule
   * @format int32
   */
  propertyId?: number
  showOnAccount?: boolean
  showOnHousekeepersReport?: boolean
  showOnToDoChart?: boolean
  startingPeriod?: RMSCloudRateTablePackageStartingPeriodEnum
  /** @format int32 */
  sundryId?: number
}

export enum RMSCloudRateTablePackageApplyChargeEnum {
  Every = 'every',
  OnThe = 'on the',
}

export enum RMSCloudRateTablePackageApplyChargeOnTheDayEnum {
  Monday = 'Monday',
  Tuesday = 'Tuesday',
  Wednesday = 'Wednesday',
  Thursday = 'Thursday',
  Friday = 'Friday',
  Saturday = 'Saturday',
  Sunday = 'Sunday',
}

export enum RMSCloudRateTablePackageEndingPeriodEnum {
  Include = 'include',
  Exclude = 'exclude',
}

export interface RMSCloudRateTablePackagePerPeriodFee {
  /** @format currency */
  amount?: number
  /** @format int32 */
  quantity?: number
  /** @format currency */
  unitPrice?: number
  useAmountFromSundry?: boolean
}

export interface RMSCloudRateTablePackagePerPersonFee {
  /** @format currency */
  additionalRateCharge1?: number
  /** @format currency */
  additionalRateCharge2?: number
  /** @format currency */
  additionalRateCharge3?: number
  /** @format currency */
  additionalRateCharge4?: number
  /** @format currency */
  additionalRateCharge5?: number
  /** @format currency */
  adults?: number
  /** @format currency */
  children?: number
  /** @format currency */
  infants?: number
  /** @format currency */
  minimumChargePerPeriod?: number
}

export interface RMSCloudRateTablePackagePercentageOfRate {
  /**
   * Calculate a Percentage of the Nightly Rate Less any Discount
   * @format decimal
   */
  percentageOfRate?: number
  /** @format currency */
  rateFrom?: number
  /** @format currency */
  rateTo?: number
  useIfRateFallsBetween?: boolean
}

export enum RMSCloudRateTablePackageStartingPeriodEnum {
  Include = 'include',
  Exclude = 'exclude',
}

/** @example {"tableIds":[1,15,2]} */
export interface RMSCloudRateTablesAdditionalsSearch {
  tableIds?: number[]
}

/** @example {"ids":[1,15,2],"inactive":false} */
export interface RMSCloudRateTablesSearch {
  ids?: number[]
  inactive?: boolean
}

/** @example {"id":112,"name":"Bed & Breakfast.","arrivingOnSunday":true,"arrivingOnMonday":true,"arrivingOnTuesday":true,"arrivingOnWednesday":true,"arrivingOnThursday":true,"arrivingOnFriday":true,"arrivingOnSaturday":true,"bestAvailableRate":true,"bookingSourceId":3,"cancellationPolicyId":1,"code":"B2","contractedRate":false,"discountId":7,"doNotAllowBaseRateToBeOverridden":false,"doNotUseAsPromoCode":false,"gLAccountCodeId":32,"groupingId":3,"inactive":false,"linkedRateTypeId":4,"long Description":"Includes continental buffet breakfast for 2","marketSegmentId":6,"mealPlanId":2,"noDiscountAllowed":true,"AdvancePurchaseNights":30,"LastMinuteNights":0,"onlyAvailableToMembers":true,"showAvailabilityAsTicksForIbe":false,"startEachRatePeriodFromNightOneOnRateTable":true,"subMarketSegmentId":4,"rateChargeDescription":"Bed & Breakfast.","rateStructure":"directRate"} */
export interface RMSCloudRateTypeFull {
  'long Description'?: string
  /** @format int32 */
  AdvancePurchaseNights?: number
  /** @format int32 */
  LastMinuteNights?: number
  arrivingOnFriday?: boolean
  arrivingOnMonday?: boolean
  arrivingOnSaturday?: boolean
  arrivingOnSunday?: boolean
  arrivingOnThursday?: boolean
  arrivingOnTuesday?: boolean
  arrivingOnWednesday?: boolean
  /** BAR */
  bestAvailableRate?: boolean
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  cancellationPolicyId?: number
  code?: string
  contractedRate?: boolean
  /** @format int32 */
  discountId?: number
  doNotAllowBaseRateToBeOverridden?: boolean
  doNotUseAsPromoCode?: boolean
  /** @format int32 */
  gLAccountCodeId?: number
  /** @format int32 */
  groupingId?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  /** @format int32 */
  linkedRateTypeId?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  name?: string
  noDiscountAllowed?: boolean
  onlyAvailableToMembers?: boolean
  rateChargeDescription?: string
  rateStructure?: RMSCloudRateTypeFullRateStructureEnum
  showAvailabilityAsTicksForIbe?: boolean
  startEachRatePeriodFromNightOneOnRateTable?: boolean
  /** @format int32 */
  subMarketSegmentId?: number
}

export enum RMSCloudRateTypeFullRateStructureEnum {
  OtaRate = 'otaRate',
  DirectRate = 'directRate',
}

/** @example {"id":1,"name":"BAR"} */
export interface RMSCloudRateTypeLite {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":7,"fromDate":"2024-08-02 00:00:00","propertyId":1,"rateId":1,"toDate":"2024-12-02 00:00:00"} */
export interface RMSCloudRatesAssignmentsBasic {
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  rateId?: number
  /** @format date-time */
  toDate?: string
}

/** @example {"id":2,"reasonType":"Reservation Cancelled","code":"4","description":"Cancelled by Customer","reason":"Cancelled by Customer"} */
export interface RMSCloudReason {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  reason?: string
  reasonType?: string
}

/** @example {"id":383,"accessNumber":"5265","accessZone":"All","areaId":95,"zoneId":0,"createdDate":"2018-08-02 04:22:00","expiryDate":"2018-09-25 17:25:00","modifiedDate":"2018-09-05 13:25:00","note":"Car is Nice","regoNumber":"698-IOU","reservationId":211897,"status":"In"} */
export interface RMSCloudRegoAccess {
  accessNumber?: string
  accessZone?: string
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  expiryDate?: string
  /** @format int32 */
  id?: number
  /** @format date-time */
  modifiedDate?: string
  note?: string
  regoNumber?: string
  /** @format int32 */
  reservationId?: number
  /** @default "notSet" */
  status?: RMSCloudRegoAccessStatusEnum
  /** @format int32 */
  zoneId?: number
}

/** @example {"reservationId":163577,"regoAccess":null,"id":383,"accessNumber":"5265","accessZone":"All","area_id":34,"arrivalDate":"2018-09-22 14:00:00","zoneId":0,"createdDate":"2018-08-02 04:22:00","expiryDate":"2018-09-25 17:25:00","modifiedDate":"2018-09-05 13:25:00","note":"Car is Nice","regoNumber":"698-IOU","status":"In"} */
export interface RMSCloudRegoAccessArrayResponse {
  accessNumber?: string
  accessZone?: string
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  expiryDate?: string
  id?: number
  /** @format date-time */
  modifiedDate?: string
  note?: string
  regoNumber?: string
  /** @format int32 */
  reservationId?: number
  /** @default "notSet" */
  status?: RMSCloudRegoAccessArrayResponseStatusEnum
  /** @format int32 */
  zoneId?: number
}

/** @default "notSet" */
export enum RMSCloudRegoAccessArrayResponseStatusEnum {
  NotSet = 'notSet',
  In = 'in',
  Out = 'out',
}

/** @example {"expirationDateFrom":"2019-01-16 00:00:00","userType":"AlternateUser"} */
export interface RMSCloudRegoAccessSearchRequest {
  /** @format date-time */
  expirationDateFrom?: string
  /** @default "Reservation" */
  userType?: RMSCloudRegoAccessSearchRequestUserTypeEnum
}

/** @default "Reservation" */
export enum RMSCloudRegoAccessSearchRequestUserTypeEnum {
  Reservation = 'Reservation',
  AlternateUser = 'AlternateUser',
  PassUser = 'PassUser',
}

/** @default "notSet" */
export enum RMSCloudRegoAccessStatusEnum {
  NotSet = 'notSet',
  In = 'in',
  Out = 'out',
}

/** @example {"id":1,"name":"Sister"} */
export interface RMSCloudRelationships {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"dateFrom":"2020-05-01 00:00:00","dateTo":"2020-05-31 00:00:00","areaIds":[1,2],"reservationStatusIds":[0,1,2,3]} */
export interface RMSCloudReportAreaIncomeSummaryBuild {
  areaIds?: number[]
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  reservationStatusIds?: number[]
}

/** @example {"category":"UPC/3 Bedroom","areaId":38,"area":"BUB/UPC/3207/3BR","numberOfReservations":16,"numberOfAdults":59,"numberOfChildren":4,"nights":203,"actualNights":196,"grossRevenue":"126,658.20","nettRevenue":"115,164.11","grossOther":"10,907.90","nettOther":"10,895.42","totalGrossRevenue":"137,566.10","totalNettRevenue":"126,059.53","averageGrossRevenue":"7,916.14","averageNettRevenue":"7,197.76","averageDiscount":"0.00","averageGrossOther":"681.74","averageNettOther":"680.96","averageDailyGrossRevenue":"646.22","averageDailyNettRevenue":"587.57","occupancy":"0.64"} */
export interface RMSCloudReportAreaIncomeSummaryResponse {
  /** @format int32 */
  actualNights?: number
  area?: string
  /** @format int32 */
  areaId?: number
  averageDailyGrossRevenue?: string
  averageDailyNettRevenue?: string
  averageDiscount?: string
  averageGrossOther?: string
  averageGrossRevenue?: string
  averageNettOther?: string
  averageNettRevenue?: string
  category?: string
  grossOther?: string
  grossRevenue?: string
  nettOther?: string
  nettRevenue?: string
  /** @format int32 */
  nights?: number
  /** @format int32 */
  numberOfAdults?: number
  /** @format int32 */
  numberOfChildren?: number
  /** @format int32 */
  numberOfReservations?: number
  occupancy?: string
  totalGrossRevenue?: string
  totalNettRevenue?: string
}

/** @example {"dateFrom":"2021-11-01 00:00:00","dateTo":"2021-12-01 00:00:00","categoryIds":[12,13]} */
export interface RMSCloudReportExpensesAreaSummaryBuild {
  categoryIds?: number[]
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
}

/** @example {"reportData":[{"area":"Amazing Grace","ownerName":"Cannon Graham","description":"Income","amount":"422.00"},{"area":"Amazing Grace","ownerName":"Cannon Graham","description":"Management Fee","amount":"-84.36"}]} */
export interface RMSCloudReportExpensesAreaSummaryResponse {
  reportData?: RMSCloudReportExpensesAreaSummaryResponseReportData[]
}

/** @example {"area":"Amazing Grace","ownerName":"Cannon Graham","description":"Income","amount":"-84.36"} */
export interface RMSCloudReportExpensesAreaSummaryResponseReportData {
  /** @format number */
  amount?: string
  area?: string
  description?: string
  ownerName?: string
}

/** @example {"accommodationRevenue":925.88,"arrivingRooms":5,"averageRate":370.24,"complementaryRooms":0,"dayUseRooms":0,"departingRooms":6,"foodBeverageRevenue":0,"houseUse":0,"noShow":0,"occupancyPercentage":16.67,"otherRevenue":668.48,"outOfOrderRooms":1,"theDate":"2020-02-25 00:00:00","totalOccupancy":25} */
export interface RMSCloudReportHistoryForecast {
  /** @format decimal */
  accommodationRevenue?: number
  /** @format int32 */
  arrivingRooms?: number
  /** @format decimal */
  averageRate?: number
  /** @format int32 */
  complementaryRooms?: number
  /** @format int32 */
  dayUseRooms?: number
  /** @format int32 */
  departingRooms?: number
  /** @format decimal */
  foodBeverageRevenue?: number
  /** @format int32 */
  houseUse?: number
  /** @format int32 */
  noShow?: number
  /** @format decimal */
  occupancyPercentage?: number
  /** @format decimal */
  otherRevenue?: number
  /** @format int32 */
  outOfOrderRooms?: number
  /** @format date-time */
  theDate?: string
  /** @format int32 */
  totalOccupancy?: number
}

/** @example {"categoryIds":[8,9],"dateFrom":"2020-02-25 00:00:00","dateTo":"2020-02-26 00:00:00","operationalRevenue":"gross","propertyIds":[1,2],"roomStatistics":"ignore"} */
export interface RMSCloudReportHistoryForecastBuild {
  categoryIds?: number[]
  /** @format date-time */
  dateFrom: string
  /** @format date-time */
  dateTo: string
  operationalRevenue?: RMSCloudReportHistoryForecastBuildOperationalRevenueEnum
  propertyIds?: number[]
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportHistoryForecastBuildRoomStatisticsEnum
}

export enum RMSCloudReportHistoryForecastBuildOperationalRevenueEnum {
  Gross = 'gross',
  Nett = 'nett',
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportHistoryForecastBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

/** @example {"propertyId":1,"rundate":"2023-01-01"} */
export interface RMSCloudReportNightAudit {
  /** @format int32 */
  propertyId?: number
  /** @format date-time */
  rundate?: string
}

export interface RMSCloudReportNightAuditAdvancesLedger {
  /** @format decimal */
  closingBalance?: number
  /** @format decimal */
  lessCreditsRefunded?: number
  /** @format decimal */
  lessCreditsUsed?: number
  /** @format decimal */
  openingBalance?: number
  /** @format decimal */
  plusNewCredits?: number
}

export interface RMSCloudReportNightAuditCityLedger {
  /** @format decimal */
  closingBalance?: number
  /** @format decimal */
  lessCreditsRefunded?: number
  /** @format decimal */
  lessCreditsUsed?: number
  /** @format decimal */
  lessPaidBalances?: number
  /** @format decimal */
  openingBalance?: number
  /** @format decimal */
  plusNewCredits?: number
  /** @format decimal */
  plusNewTransfers?: number
}

export interface RMSCloudReportNightAuditDebtorAnalysis {
  advancesLedger?: RMSCloudReportNightAuditAdvancesLedger[]
  cityLedger?: RMSCloudReportNightAuditCityLedger[]
  guestLedger?: RMSCloudReportNightAuditGuestLedger[]
}

export interface RMSCloudReportNightAuditGuestLedger {
  /** @format decimal */
  closingBalance?: number
  /** @format decimal */
  lessPaidBalances?: number
  /** @format decimal */
  openingBalance?: number
  /** @format decimal */
  plusNewReservationCharges?: number
}

export interface RMSCloudReportNightAuditReport {
  /** @format decimal */
  outstandingGuestBalance?: number
  summary?: RMSCloudReportNightAuditReportSummary[]
}

export interface RMSCloudReportNightAuditReportSummary {
  debtorsAnalysis?: RMSCloudReportNightAuditDebtorAnalysis[]
  transactions?: RMSCloudReportNightAuditTransactions[]
}

export interface RMSCloudReportNightAuditTransactions {
  /** @format decimal */
  cash?: number
  /** @format decimal */
  cashExpense?: number
  /** @format decimal */
  cheque?: number
  /** @format decimal */
  creditCard?: number
  /** @format decimal */
  directCredit?: number
  /** @format decimal */
  directDebit?: number
  /** @format decimal */
  eftPos?: number
  /** @format decimal */
  journal?: number
  /** @format decimal */
  refund?: number
}

/** @example {"propertyId":1,"totalResponses":3,"responsesRate":9.68,"netPromoterStore":66.76,"service":9.33,"standardOfFacilities":7.67,"site":9.33,"valueForMoney":8.33,"surveyDeatils":[{"arrivalDate":"2020-06-28 16:37:00","departureDate":"2020-07-01 08:52:50","npsRating":7,"serviceRating":8,"facilityRating":3,"siteRating":8,"valueRating":8,"categoryId":5,"reservationId":4585654,"comments":"Not being allowed to have access to a toilet and shower was very disappointing. Although we are self contained a good size shower would have been wonderful at least once"},{"arrivalDate":"2020-07-01 15:28:00","departureDate":"2020-07-03 10:34:43","npsRating":10,"serviceRating":10,"facilityRating":10,"siteRating":10,"valueRating":7,"categoryId":4,"reservationId":4215468,"comments":"Very comfortable accommodation. Just loved it. Will be back again. Just a bit expensive."}]} */
export interface RMSCloudReportNpnResults {
  /** @format decimal */
  netPromoterStore?: number
  /** @format int32 */
  propertyId?: number
  /**
   * This value represents a percentage of the response rate.
   * @format int32
   */
  responsesRate?: number
  /** @format decimal */
  service?: number
  /** @format decimal */
  site?: number
  /** @format decimal */
  standardOfFacilities?: number
  surveyDeatils?: RMSCloudReportNpnResultsSurveyDeatils[]
  /** @format int32 */
  totalResponses?: number
  /** @format decimal */
  valueForMoney?: number
}

/** @example {"categoryIds":[4,6],"dateFrom":"2020-02-25 00:00:00","dateTo":"2020-02-26 00:00:00","npsRating":[0,1,2,3,4,5,6,7,8,9,10],"propertyIds":[1,2],"reportBy":"surveyDate"} */
export interface RMSCloudReportNpnResultsBuild {
  categoryIds?: number[]
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** Pass ratings between the range of 0 to 10 */
  npsRating?: number[]
  propertyIds: number[]
  reportBy?: RMSCloudReportNpnResultsBuildReportByEnum
}

export enum RMSCloudReportNpnResultsBuildReportByEnum {
  SurveyDate = 'surveyDate',
  DepartDate = 'departDate',
}

export interface RMSCloudReportNpnResultsSurveyDeatils {
  /** @format date-time */
  arrivalDate?: string
  /** @format int32 */
  categoryId?: number
  comments?: string
  /** @format date-time */
  departureDate?: string
  /** @format int32 */
  facilityRating?: number
  /** @format int32 */
  npsRating?: number
  /** @format int32 */
  reservationId?: number
  /** @format int32 */
  serviceRating?: number
  /** @format int32 */
  siteRating?: number
  /** @format int32 */
  valueRating?: number
}

/** @example {"averageLengthOfStay":1,"confirmedPercent":100,"categroyId":4,"description":"Deluxe 004","discount":32.9,"grossAverageRevPOR":275.6,"netAverageRevPOR":250.64,"numberOfAreasAvailable":14,"numberOfAreasInMaintenance":0,"numberOfAreasUnused":3,"numberOfAreasUsed":11,"numberOfAreasTotal":14,"occupancyPercentage":21.43,"occupants":8,"period":"Days","propertyId":1,"reservationIds":[165763,165993,165994,166002],"revPar":53.71,"theDate":"2020-02-25 00:00:00","totalGrossRevenue":826.8,"totalNetRevenue":751.93} */
export interface RMSCloudReportOccupancy {
  /** @format decimal */
  averageLengthOfStay?: number
  /**
   * This value is returned based on your grouping options
   * @format int32
   */
  categoryId?: number
  /** @format decimal */
  confirmedPercent?: number
  /** This value is dependant on the values passed in grouping1 and grouping2 */
  description?: string
  /** @format decimal */
  discount?: number
  /** @format decimal */
  grossAverageRevPOR?: number
  /** @format decimal */
  netAverageRevPOR?: number
  /** @format int32 */
  numberOfAreasAvailable?: number
  /** @format int32 */
  numberOfAreasInMaintenance?: number
  /** @format int32 */
  numberOfAreasTotal?: number
  /** @format int32 */
  numberOfAreasUnused?: number
  /** @format int32 */
  numberOfAreasUsed?: number
  /** @format decimal */
  occupancyPercentage?: number
  /** @format int32 */
  occupants?: number
  period?: string
  /**
   * This value is returned based on your grouping options
   * @format int32
   */
  propertyId?: number
  /** @format int32 */
  reservationIds?: number
  /** @format decimal */
  revPar?: number
  /** @format date-time */
  theDate?: string
  /** @format decimal */
  totalGrossRevenue?: number
  /** @format decimal */
  totalNetRevenue?: number
}

/** @example {"breakdownAdultChildInfants":true,"categoryIds":[4,6],"dailyBreakdown":false,"dateFrom":"2020-02-25 00:00:00","dateTo":"2020-02-26 00:00:00","dayOfTheWeek":["all"],"groupBy1":"Category","groupBy2":"Property","includeInfantsInOccupantsTotal":true,"includeReservationIds":true,"includeUniqueGuestCount":false,"propertyIds":[1,2],"replaceOccupantsWithGuestNights":true,"roomStatistics":"ignore"} */
export interface RMSCloudReportOccupancyBuild {
  groupBy1?: RMSCloudReportOccupancyBuildGroupBy1Enum
  groupBy2?: RMSCloudReportOccupancyBuildGroupBy2Enum
  breakdownAdultChildInfants?: boolean
  categoryIds?: number[]
  dailyBreakdown?: boolean
  /** @format date-time */
  dateFrom: string
  /** @format date-time */
  dateTo: string
  dayOfTheWeek?: RMSCloudReportOccupancyBuildDayOfTheWeekEnum[]
  includeInfantsInOccupantsTotal?: boolean
  /** This will NOT work if DailyBreakdown is true. */
  includeReservationIds?: boolean
  includeUniqueGuestCount?: boolean
  propertyIds?: number[]
  replaceOccupantsWithGuestNights?: boolean
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportOccupancyBuildRoomStatisticsEnum
}

export enum RMSCloudReportOccupancyBuildDayOfTheWeekEnum {
  All = 'all',
  Sunday = 'sunday',
  Monday = 'monday',
  Tuesday = 'tuesday',
  Wednesday = 'wednesday',
  Thursday = 'thursday',
  Friday = 'friday',
  Saturday = 'saturday',
}

export enum RMSCloudReportOccupancyBuildGroupBy1Enum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
  DayOfWeek = 'dayOfWeek',
  Property = 'property',
  PropertyState = 'propertyState',
}

export enum RMSCloudReportOccupancyBuildGroupBy2Enum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
  DayOfWeek = 'dayOfWeek',
  Property = 'property',
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportOccupancyBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

/** @example {"areaId":1,"categroyId":4,"numberOfAreasAvailable":14,"numberOfAreasUnused":3,"numberOfAreasUsed":11,"occupancyPercentage":21.43,"period":"Days","propertyId":1,"totalGrossRevenue":826.8,"totalNetRevenue":751.93} */
export interface RMSCloudReportOccupancyByArea {
  /** @format decimal */
  areaId?: number
  /**
   * This value is returned based on your grouping options
   * @format int32
   */
  categoryId?: number
  /** @format int32 */
  numberOfAreasAvailable?: number
  /** @format int32 */
  numberOfAreasUnused?: number
  /** @format int32 */
  numberOfAreasUsed?: number
  /** @format decimal */
  occupancyPercentage?: number
  period?: string
  /**
   * This value is returned based on your grouping options
   * @format int32
   */
  propertyId?: number
  /** @format decimal */
  totalGrossRevenue?: number
  /** @format decimal */
  totalNetRevenue?: number
}

/** @example {"breakdownAdultChildInfants":true,"categoryIds":[4,6],"dailyBreakdown":false,"dateFrom":"2020-02-25 00:00:00","dateTo":"2020-02-26 00:00:00","groupBy1":"Category","groupBy2":"Property","includeInfantsInOccupantsTotal":true,"includeUniqueGuestCount":false,"propertyIds":[1,2],"replaceOccupantsWithGuestNights":true,"roomStatistics":"ignore","excludeOwnerStays":false} */
export interface RMSCloudReportOccupancyByAreaBuild {
  groupBy1?: RMSCloudReportOccupancyByAreaBuildGroupBy1Enum
  groupBy2?: RMSCloudReportOccupancyByAreaBuildGroupBy2Enum
  breakdownAdultChildInfants?: boolean
  categoryIds?: number[]
  dailyBreakdown?: boolean
  /** @format date-time */
  dateFrom: string
  /** @format date-time */
  dateTo: string
  excludeOwnerStays?: boolean
  includeInfantsInOccupantsTotal?: boolean
  includeUniqueGuestCount?: boolean
  propertyIds?: number[]
  replaceOccupantsWithGuestNights?: boolean
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportOccupancyByAreaBuildRoomStatisticsEnum
}

export enum RMSCloudReportOccupancyByAreaBuildGroupBy1Enum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
  DayOfWeek = 'dayOfWeek',
  Property = 'property',
  PropertyState = 'propertyState',
}

export enum RMSCloudReportOccupancyByAreaBuildGroupBy2Enum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
  DayOfWeek = 'dayOfWeek',
  Property = 'property',
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportOccupancyByAreaBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

export interface RMSCloudReportOccupancyRevenueComparison {
  title?: string
}

/** @example {"allReservationsBetween":[{"reservationsBetweenStart":"1900-00-00 00:00:00","reservationsBetweenEnd":"1900-00-00 00:00:00","comparedToReservationsBetweenStart":"1900-00-00 00:00:00","comparedToReservationsBetweenEnd":"1900-00-00 00:00:00"}],"allReservationsPriorTo":[{"reservationsMadePriorToDate":"1900-00-00 00:00:00","reservationsBetweenStart":"1900-00-00 00:00:00","reservationsBetweenEnd":"1900-00-00 00:00:00","comparedToReservationsMadePriorToDate":"1900-00-00 00:00:00","comparedToReservationsBetweenStart":"1900-00-00 00:00:00","comparedToReservationsBetweenEnd":"1900-00-00 00:00:00"}],"categoryIds":[4,5],"categoryGroupingIds":[1],"excludeReservationWithStatusOfOwnerOccupied":false,"groupByProperty":false,"groupByTravelAgent":true,"includeLongTermReservation":true,"propertyIds":[1],"replaceTotalArrivalsAndAvailsNightsWithNettRevPARAndNetRevPOR":false,"roomStatistics":"ignore","travelAgentIds":[45,12]} */
export interface RMSCloudReportOccupancyRevenueComparisonBuild {
  allReservationsBetween?: RMSCloudReportOccupancyRevenueComparisonBuildAllReservationsBetween[]
  allReservationsPriorTo?: RMSCloudReportOccupancyRevenueComparisonBuildAllReservationsPriorTo[]
  categoryGroupingIds?: number[]
  categoryIds?: number[]
  excludeReservationWithStatusOfOwnerOccupied?: boolean
  groupByProperty?: boolean
  groupByTravelAgent?: boolean
  includeLongTermReservation?: boolean
  propertyIds?: number[]
  replaceTotalArrivalsAndAvailsNightsWithNettRevPARAndNetRevPOR?: boolean
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportOccupancyRevenueComparisonBuildRoomStatisticsEnum
  travelAgentIds?: number[]
}

export interface RMSCloudReportOccupancyRevenueComparisonBuildAllReservationsBetween {
  /** @format date-time */
  comparedToReservationsBetweenEnd?: string
  /** @format date-time */
  comparedToReservationsBetweenStart?: string
  /** @format date-time */
  reservationsBetweenEnd?: string
  /** @format date-time */
  reservationsBetweenStart?: string
}

export interface RMSCloudReportOccupancyRevenueComparisonBuildAllReservationsPriorTo {
  /** @format date-time */
  comparedToReservationsBetweenEnd?: string
  /** @format date-time */
  comparedToReservationsBetweenStart?: string
  /** @format date-time */
  comparedToReservationsMadePriorToDate?: string
  /** @format date-time */
  reservationsBetweenEnd?: string
  /** @format date-time */
  reservationsBetweenStart?: string
  /** @format date-time */
  reservationsMadePriorToDate?: string
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportOccupancyRevenueComparisonBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

/** @example {"title":"Pace Report","report":[{"propertyId":1,"propertyName":"Test property 1","categoryName":"Deluxe 004","categoryId":4,"categoryGroupType":"","categoryGroupTypeId":0,"current":[{"reservation":3,"nights":5,"grossRevenue":1048,"nettRevenue":953.33,"averageDailyRateGross":209.6,"averageDailyRateNett":190.67,"occupancyPercent":17.86}],"previous":[{"reservation":19,"nights":27,"grossRevenue":9704,"nettRevenue":8821.81,"averageDailyRateGross":359.41,"averageDailyRateNett":326.73,"occupancyPercent":96.43}],"variance":[{"reservation":-16,"reservationPercent":-84.2105263157895,"nights":22,"nightsPercent":-81.4814814814815,"grossRevenue":-8656,"grossRevenuePercent":-89.20032976092332,"nettRevenue":-7868.48,"nettRevenuePercent":-89.193487504265,"averageDailyRateGross":-149.81,"averageDailyRateGrossPercent":-41.68220138560419,"averageDailyRateNett":-136.06,"averageDailyRateNettPercent":-41.642946775625134,"occupancyPercent":-78.57}]}]} */
export interface RMSCloudReportPace {
  categoryGroupType?: string
  /** @format int32 */
  categoryGroupTypeId?: number
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  current?: RMSCloudReportPaceCurrentPrevious[]
  previous?: RMSCloudReportPaceCurrentPrevious[]
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  title?: string
  variance?: RMSCloudReportPaceVariance[]
}

/** @example {"categoryIds":[4,6],"compareTo":"lastYear","dateFrom":"2020-02-25 00:00:00","dateTo":"2020-02-26 00:00:00","groupBy":"Category","propertyIds":[1,2],"roomStatistics":"ignore","reservationDatePriorTo":"2020-02-27 00:00:00"} */
export interface RMSCloudReportPaceBuild {
  categoryIds?: number[]
  compareTo?: RMSCloudReportPaceBuildCompareToEnum
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  deductProjectedCancellationNoShowPercentageFromCurrentValues?: boolean
  groupBy?: RMSCloudReportPaceBuildGroupByEnum
  propertyIds?: number[]
  /** @format date-time */
  reservationDatePriorTo?: string
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportPaceBuildRoomStatisticsEnum
}

export enum RMSCloudReportPaceBuildCompareToEnum {
  LastYear = 'lastYear',
  YearBeforeLast = 'yearBeforeLast',
  NoComparison = 'noComparison',
  LastYearAndYearBeforeLast = 'lastYearAndYearBeforeLast',
}

export enum RMSCloudReportPaceBuildGroupByEnum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportPaceBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

export interface RMSCloudReportPaceCurrentPrevious {
  /** @format decimal */
  averageDailyRateGross?: number
  /** @format decimal */
  averageDailyRateNett?: number
  /** @format int32 */
  grossRevenue?: number
  /** @format decimal */
  nettRevenue?: number
  /** @format int32 */
  nights?: number
  /** @format decimal */
  occupancyPercent?: number
  /** @format int32 */
  reservation?: number
}

export interface RMSCloudReportPaceVariance {
  /** @format decimal */
  averageDailyRateGross?: number
  /** @format decimal */
  averageDailyRateGrossPercent?: number
  /** @format decimal */
  averageDailyRateNett?: number
  /** @format decimal */
  averageDailyRateNettPercent?: number
  /** @format int32 */
  grossRevenue?: number
  /** @format decimal */
  grossRevenuePercent?: number
  /** @format decimal */
  nettRevenue?: number
  /** @format decimal */
  nettRevenuePercent?: number
  /** @format int32 */
  nights?: number
  /** @format decimal */
  nightsPercent?: number
  /** @format decimal */
  occupancyPercent?: number
  /** @format int32 */
  reservation?: number
  /** @format decimal */
  reservationPercent?: number
}

/** @example {"propertyId":2,"reportDate":"2022-01-11"} */
export interface RMSCloudReportParthfinderBuild {
  /** @format int32 */
  propertyId?: number
  /** @format date */
  reportDate?: string
}

/** @example {"title":"Pace Report","report":[{"propertyId":1,"propertyName":"Test property 1","categoryName":"","categoryId":0,"categoryGroupType":"B1 Rooms","categoryGroupTypeId":22,"reportTypeEntity":"company","current":[{"reservation":7,"cancellationPercent":0,"noShowPercent":0,"averageLeadTime":-0.43,"averageLengthOfStay":1,"nights":7,"grossRevenue":0,"nettRevenue":0,"averageDailyRateGross":0,"averageDailyRateNett":0}],"previous":[{"reservation":0,"cancellationPercent":0,"noShowPercent":0,"averageLeadTime":0,"averageLengthOfStay":0,"nights":0,"grossRevenue":0,"nettRevenue":0,"averageDailyRateGross":0,"averageDailyRateNett":0}],"variance":[{"reservation":7,"reservationPercent":0,"cancellationPercent":0,"noShowPercent":0,"averageLeadTime":-0.43,"averageLeadTimePercent":0,"averageLengthOfStay":1,"averageLengthOfStayPercent":0,"nights":7,"nightsPercent":0,"grossRevenue":0,"grossRevenuePercent":0,"nettRevenue":0,"nettRevenuePercent":0,"averageDailyRateGross":0,"averageDailyRateGrossPercent":0,"averageDailyRateNett":0,"averageDailyRateNettPercent":0}]}]} */
export interface RMSCloudReportPerformanceII {
  categoryGroupType?: string
  /** @format int32 */
  categoryGroupTypeId?: number
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  current?: RMSCloudReportPerformanceIICurrentPrevious[]
  previous?: RMSCloudReportPerformanceIICurrentPrevious[]
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  reportTypeEntity?: string
  title?: string
  variance?: RMSCloudReportPerformanceIIVariance[]
}

/** @example {"categoryIds":[],"comparisonAgainstSameTimeLastYear":true,"dateFrom":"2020-05-01 00:00:00","dateTo":"2020-05-31 00:00:00","groupBy":"Category","monthlyBreakdownBy":"grossRevenue","performanceBasedOn":"revenue","propertyIds":[1,3,4],"replaceCancellationAndNoShowPercentageWithNettRevPercentage":false,"reportType":"company","reportTypeOptionIds":[],"roomStatistics":"ignore","reservationDatePriorTo":"2020-06-12 00:00:00","showOnlyTop":10} */
export interface RMSCloudReportPerformanceIIBuild {
  groupBy2?: RMSCloudReportPerformanceIiBuildGroupBy2Enum
  'reportType:'?: RMSCloudReportPerformanceIiBuildReportTypeEnum
  categoryIds?: number[]
  comparisonAgainstSameTimeLastYear?: boolean
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  monthlyBreakdownBy?: RMSCloudReportPerformanceIiBuildMonthlyBreakdownByEnum
  performanceBasedOn?: RMSCloudReportPerformanceIiBuildPerformanceBasedOnEnum
  propertyIds?: number[]
  replaceCancellationAndNoShowPercentageWithNettRevPercentage?: boolean
  /** This option will allow you to pass the ID that corrosponds with the Report Type you have chosen to filter your reult on. e.g. If your Report Type is Rate Type you could pass your Rate Id's as the reportTypeOptionIds */
  reportTypeOptionIds?: number[]
  /** @format date-time */
  reservationDatePriorTo?: string
  /** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
  roomStatistics?: RMSCloudReportPerformanceIiBuildRoomStatisticsEnum
  /** @format int32 */
  showOnlyTop?: number
}

export interface RMSCloudReportPerformanceIICurrentPrevious {
  /** @format decimal */
  averageDailyRateGross?: number
  /** @format decimal */
  averageDailyRateNett?: number
  /** @format decimal */
  averageLeadTime?: number
  /** @format int32 */
  averageLengthOfStay?: number
  /** @format int32 */
  cancellationPercent?: number
  /** @format int32 */
  grossRevenue?: number
  /** @format decimal */
  nettRevenue?: number
  /** @format int32 */
  nights?: number
  /** @format int32 */
  noShowPercent?: number
  /** @format int32 */
  reservation?: number
}

export interface RMSCloudReportPerformanceIIVariance {
  /** @format decimal */
  averageDailyRateGross?: number
  /** @format decimal */
  averageDailyRateGrossPercent?: number
  /** @format decimal */
  averageDailyRateNett?: number
  /** @format decimal */
  averageDailyRateNettPercent?: number
  /** @format decimal */
  averageLeadTime?: number
  /** @format decimal */
  averageLeadTimePercent?: number
  /** @format decimal */
  averageLengthOfStay?: number
  /** @format decimal */
  averageLengthOfStayPercent?: number
  /** @format decimal */
  cancellationPercent?: number
  /** @format int32 */
  grossRevenue?: number
  /** @format decimal */
  grossRevenuePercent?: number
  /** @format decimal */
  nettRevenue?: number
  /** @format decimal */
  nettRevenuePercent?: number
  /** @format int32 */
  nights?: number
  /** @format decimal */
  nightsPercent?: number
  /** @format decimal */
  noShowPercent?: number
  /** @format int32 */
  reservation?: number
  /** @format decimal */
  reservationPercent?: number
}

export enum RMSCloudReportPerformanceIiBuildGroupBy2Enum {
  None = 'none',
  Category = 'category',
  CategoryGrouping = 'categoryGrouping',
}

export enum RMSCloudReportPerformanceIiBuildMonthlyBreakdownByEnum {
  GrossRevenue = 'grossRevenue',
  NettRevenue = 'nettRevenue',
  Nights = 'nights',
}

export enum RMSCloudReportPerformanceIiBuildPerformanceBasedOnEnum {
  Revenue = 'revenue',
  Nights = 'nights',
  Reservations = 'reservations',
}

export enum RMSCloudReportPerformanceIiBuildReportTypeEnum {
  Company = 'company',
  TravelAgent = 'travelAgent',
  RateType = 'rateType',
  BookingSoruce = 'bookingSoruce',
  ReservationType = 'reservationType',
  SubReservationType = 'subReservationType',
  MarketSegment = 'marketSegment',
  SubMarketSegment = 'subMarketSegment',
  GroupReservation = 'groupReservation',
  GroupAllotment = 'groupAllotment',
}

/** On = Only Look for Stats On, Off = Only Look for Stats Off, Ignore = We don't Filter on Stats */
export enum RMSCloudReportPerformanceIiBuildRoomStatisticsEnum {
  On = 'on',
  Off = 'off',
  Ignore = 'ignore',
}

/** @example {"dateFrom":"2020-05-01 00:00:00","dateTo":"2020-05-31 00:00:00","propertyIds":[1,2]} */
export interface RMSCloudReportRevenueAndExpenseBuild {
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  propertyIds?: number[]
}

/**
 * Used:<br>POST /reports/auditTrail<br>
 * @example {"propertyIds":[1],"glCodeIds":[],"byPostingDate":true,"groupBy":"NoGrouping","transactionOption":"ByDate","fromDate":"2023-10-05 00:00:00","toDate":"2023-10-05 23:23:59","transactionIdFrom":0,"transactionIdTo":0,"sortBy":"reservationId"}
 */
export interface RMSCloudReportsAuditTrail {
  byPostingDate?: boolean
  /** @format date-time */
  fromDate?: string
  glCodeIds?: number[]
  groupBy?: RMSCloudReportsAuditTrailGroupByEnum
  propertyIds?: number[]
  sortBy?: RMSCloudReportsAuditTrailSortByEnum
  /** @format date-time */
  toDate?: string
  transactionOption?: RMSCloudReportsAuditTrailTransactionOptionEnum
  /** @format int32 */
  traqnsactionIdFrom?: number
  /** @format int32 */
  traqnsactionIdTo?: number
}

export enum RMSCloudReportsAuditTrailGroupByEnum {
  NoGrouping = 'noGrouping',
  GlCode = 'glCode',
  Category = 'category',
  User = 'user',
  Area = 'area',
  Company = 'company',
  TravelAgent = 'travelAgent',
  BookingSource = 'bookingSource',
}

/** @example {"Data":[{"propertyId":1,"propertyName":"Test property 1","glCodeId":40,"glCod":"Toni1","postingDate":"2023-10-05 00:00:00","createdDate":"2023-10-05 18:26:08","transactionId":2492469,"reservationId":216865,"accountId":362486,"areaId":287,"guestSurname":"","guestGiven":"","transactionDescription":"Currency Adjustment","taxInvoiceId":0,"userId":186,"debit":0,"credit":0,"loyaltyMembershipType":"","group":""}]} */
export interface RMSCloudReportsAuditTrailResponse {
  data?: RMSCloudReportsAuditTrailResponseData[]
}

export interface RMSCloudReportsAuditTrailResponseData {
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  createDate?: string
  /** @format decimal */
  credits?: number
  /** @format decimal */
  debits?: number
  /** @format int32 */
  glCodeId?: number
  group?: string
  guestGiven?: string
  guestSurname?: string
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  /** @format date-time */
  postingDate?: string
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  /** @format int32 */
  reservationId?: number
  /** @format int32 */
  taxInvoiceId?: number
  transactionDescription?: string
  /** @format int32 */
  transactionId?: number
  /** @format int32 */
  userId?: number
}

export enum RMSCloudReportsAuditTrailSortByEnum {
  TransactionId = 'transactionId',
  ReservationId = 'reservationId',
  Surname = 'surname',
  GlCode = 'glCode',
  TransactionDate = 'transactionDate',
  Area = 'area',
  StudentId = 'studentId',
  LoyaltyMembershipType = 'loyaltyMembershipType',
}

export enum RMSCloudReportsAuditTrailTransactionOptionEnum {
  ByDate = 'byDate',
  ById = 'byId',
}

/** @example {"dateFrom":"2022-06-01","dateTo":"2022-06-21","groupBy":"Category","propertyIds":[1,3,4],"categoryIds":[0],"groupByProperty":true,"excludeOwnerAccountingCharges":true} */
export interface RMSCloudReportsCashChargeBuild {
  categoryIds?: number[]
  /** @format date-time */
  dateFrom: string
  /** @format date-time */
  dateTo: string
  excludeOwnerAccountingCharges?: boolean
  groupBy?: RMSCloudReportsCashChargeBuildGroupByEnum
  groupByProperty?: boolean
  propertyIds?: number[]
}

export enum RMSCloudReportsCashChargeBuildGroupByEnum {
  BookingSource = 'bookingSource',
  Category = 'category',
  GlCode = 'glCode',
}

/** @example {"propertyId":1,"glCode":"4-1000","glCodeId":33,"description":"Accommodation","totalCharge":53.1,"totalGST":4.82,"gstExclusive":48.28,"gstFreeCharge":0,"fullGSTGST":4.82,"fullGSTCharge":53.1,"concessionalGSTCharge":0,"concessionalGSTGST":0} */
export interface RMSCloudReportsCashChargeResponse {
  /** @format decimal */
  concessionalGSTCharge?: number
  /** @format decimal */
  concessionalGSTGST?: number
  description?: string
  /** @format decimal */
  fullGSTCharge?: number
  /** @format decimal */
  fullGSTGST?: number
  glCode?: string
  /** @format int32 */
  glCodeId?: number
  /** @format decimal */
  gstExclusive?: number
  /** @format decimal */
  gstFreeCharge?: number
  /** @format int32 */
  propertyId?: number
  /** @format decimal */
  totalCharge?: number
  /** @format decimal */
  totalGST?: number
}

/** @example {"asOfDate":"2022-06-21","groupByProperty":false,"groupBy":"Category","propertyIds":[1],"categoryIds":[],"balance":"AgedYDays","balanceAgeX":12,"balanceAgeY":15,"balanceAgeZ":33,"accountClassIds":null,"accountTypes":[],"includeLongTerm":true,"includeNonLongTerm":true,"onlyCompanies":false,"onlyTravelAgents":false,"onlyWholesalers":false,"creditDebit":"Both","accountIds":[],"excludeFutureReservations":false,"clientClassId":0,"excludeTrustChargesForReservationAccounts":false,"invoicedTransactionsOnly":false,"clientStatusIds":[],"onlyNonARDebtors":false,"includeTrustBreakdown":false,"compareOldAndNew":false,"excludeNonInvoicedRepeatCharges":false,"includeManagementExpensesBreakdown":true} */
export interface RMSCloudReportsDebtorsLedgerBuild {
  accountClassIds?: number[]
  accountIds?: number[]
  accountTypes?: RMSCloudReportsDebtorsLedgerBuildAccountTypesEnum
  /** @format date-time */
  asOfDate?: string
  balance?: RMSCloudReportsDebtorsLedgerBuildBalanceEnum
  /** @format int32 */
  balanceAgeX?: number
  /** @format int32 */
  balanceAgeY?: number
  /** @format int32 */
  balanceAgeZ?: number
  categoryIds?: number[]
  /** @format int32 */
  clientClassId?: number
  clientStatusIds?: number[]
  compareOldAndNew?: boolean
  creditDebit?: RMSCloudReportsDebtorsLedgerBuildCreditDebitEnum
  excludeFutureReservations?: boolean
  excludeNonInvoicedRepeatCharges?: boolean
  excludeTrustChargesForReservationAccounts?: boolean
  groupBy?: RMSCloudReportsDebtorsLedgerBuildGroupByEnum
  groupByProperty?: boolean
  includeLongTerm?: boolean
  includeManagementExpensesBreakdown?: boolean
  includeNonLongTerm?: boolean
  includeTrustBreakdown?: boolean
  invoicedTransactionsOnly?: boolean
  onlyCompanies?: boolean
  onlyNonARDebtors?: boolean
  onlyTravelAgents?: boolean
  onlyWholesalers?: boolean
  propertyIds?: number[]
}

export enum RMSCloudReportsDebtorsLedgerBuildAccountTypesEnum {
  None = 'none',
  All = 'all',
  Reservations = 'reservations',
  Guest = 'guest',
  TravelAgent = 'travelAgent',
  Owners = 'owners',
}

export enum RMSCloudReportsDebtorsLedgerBuildBalanceEnum {
  All = 'all',
  Current = 'current',
  AgedYDays = 'AgedYDays',
}

export enum RMSCloudReportsDebtorsLedgerBuildCreditDebitEnum {
  All = 'all',
  Credit = 'credit',
  Debit = 'debit',
}

export enum RMSCloudReportsDebtorsLedgerBuildGroupByEnum {
  None = 'none',
  Category = 'category',
  Company = 'company',
  AccountClass = 'accountClass',
  TravelAgent = 'travelAgent',
  CompanyOverTravelAgentPreference = 'companyOverTravelAgentPreference',
  TravelAgentOverCompanyPrefrence = 'travelAgentOverCompanyPrefrence',
  AR = 'AR',
  AccountsReceivableSummary = 'accountsReceivableSummary',
}

/** @example {"reportData":[{"accountId":1,"propertyId":1,"reservationId":0,"guestId":0,"credits":0,"current":0,"debits":8883.18,"ageZ":8751.74,"ageY":0,"ageX":0,"total":8751.74,"trustTotal":0,"nonTrustTotal":0,"accountHasIssues":false,"group":"","invoiceId":0,"recordType":"NonAR","arCompanyId":0,"arTravelAgentId":0,"managementExpenses":0,"notionalExpenses":0,"sundryExpenses":8797.89,"ownerIncome":-46.15,"managementExpensesBreakdown":[{"breakdownType":"Sundry","reservationId":0,"accountId":1,"amount":148.5,"gst":13.5},{"breakdownType":"Sundry","reservationId":0,"accountId":1,"amount":148.5,"gst":13.5}]}]} */
export interface RMSCloudReportsDebtorsLedgerResponse {
  reportData?: RMSCloudReportsDebtorsLedgerResponseData[]
}

export interface RMSCloudReportsDebtorsLedgerResponseDailyBreakdown {
  /** @format int32 */
  accountId?: number
  /** @format decimal */
  amount?: number
  breakdownType?: string
  /** @format decimal */
  gst?: number
  /** @format int32 */
  reservationId?: number
}

export interface RMSCloudReportsDebtorsLedgerResponseData {
  accountHasIssues?: boolean
  /** @format int32 */
  accountId?: number
  /** @format decimal */
  ageX?: number
  /** @format decimal */
  ageY?: number
  /** @format decimal */
  ageZ?: number
  /** @format int32 */
  arCompanyId?: number
  /** @format int32 */
  arTravelAgentId?: number
  /** @format decimal */
  credits?: number
  /** @format decimal */
  current?: number
  /** @format decimal */
  debits?: number
  group?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  invoiceId?: number
  /** @format decimal */
  managementExpenses?: number
  managementExpensesBreakdown?: RMSCloudReportsDebtorsLedgerResponseDailyBreakdown[]
  /** @format decimal */
  nonTrustTotal?: number
  /** @format decimal */
  notionalExpenses?: number
  /** @format decimal */
  ownerIncome?: number
  /** @format int32 */
  propertyId?: number
  recordType?: string
  /** @format int32 */
  reservationId?: number
  /** @format decimal */
  sundryExpenses?: number
  /** @format decimal */
  total?: number
  /** @format decimal */
  trustTotal?: number
}

/** @example {"id":7,"name":"Chapagne & Chochlates","amount":30,"chargeDailyIncludeToDate":false,"ChargeRequiredDaily":false,"Code":"A129e","groupingId":2,"inactive":false,"monitorRequirement":false,"note":"Make sure you check inventory for stock","quantity":2,"requiredDaily":false,"showInHouseKeepersReport":true,"sundryId":8,"secondUnitPrice":30,"secondAdultAmount":0,"secondChildAmount":0,"secondInfantAmount":0,"unitPrice":15,"useSundryAmount":true} */
export interface RMSCloudRequirement {
  /** @format decimal */
  adultAmount?: number
  /** @format decimal */
  amount?: number
  chargeDailyIncludeToDate?: boolean
  chargeRequiredDaily?: boolean
  /** @format decimal */
  childAmount?: number
  code?: string
  feeType?: string
  /** @format int32 */
  groupingId?: number
  /** @format int32 */
  id?: number
  inactive?: boolean
  /** @format decimal */
  infantAmount?: number
  monitorRequirement?: boolean
  name?: string
  note?: string
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
  /** @format decimal */
  secondAdultAmount?: number
  /** @format decimal */
  secondChildAmount?: number
  /** @format decimal */
  secondInfantAmount?: number
  /** @format decimal */
  secondUnitPrice?: number
  showInHousekeepersReport?: boolean
  /** @format int32 */
  sundryId?: number
  /** @format decimal */
  unitPrice?: number
  useSundryAmount?: boolean
}

/**
 * Used:<br>GET /areas/{id}/requirements<br>GET /areas/requirements/search
 * @example {"amount":30,"adultAmount":0,"chargeDailyIncludeToDate":false,"chargeRequiredDaily":false,"childAmount":0,"code":"A129e","feeType":"PerPeriodFee","groupingId":2,"id":7,"infantAmount":0,"secondUnitPrice\"":0,"secondAdultAmount\"":16,"secondChildAmount\"":12,"secondInfantAmount\"":5,"masterRequirementId":7,"monitorRequirement":false,"name":"Chapagne & Chochlates","note":"Make sure you check inventory for stock","quantity":2,"requiredDaily":false,"showInHouseKeepersReport":true,"sundryId":8,"unitPrice":15,"useSundryAmount":true}
 */
export interface RMSCloudRequirementBasic {
  /** @format decimal */
  adultAmount?: number
  /** @format decimal */
  amount?: number
  chargeDailyIncludeToDate?: boolean
  chargeRequiredDaily?: boolean
  /** @format decimal */
  childAmount?: number
  code?: string
  /** @default "PerPeriodFee" */
  feeType?: RMSCloudRequirementBasicFeeTypeEnum
  /** @format int32 */
  groupingId?: number
  /** @format int32 */
  id?: number
  /** @format decimal */
  infantAmount?: number
  /** @format int32 */
  masterRequirementId?: number
  monitorRequirement?: boolean
  name?: string
  note?: string
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
  /** @format decimal */
  secondAdultAmount?: number
  /** @format decimal */
  secondChildAmount?: number
  /** @format decimal */
  secondInfantAmount?: number
  /** @format decimal */
  secondUnitPrice?: number
  showInHousekeepersReport?: boolean
  /** @format int32 */
  sundryId?: number
  /** @format decimal */
  unitPrice?: number
  useSundryAmount?: boolean
}

/** @default "PerPeriodFee" */
export enum RMSCloudRequirementBasicFeeTypeEnum {
  PerPeriodFee = 'PerPeriodFee',
  PerPersonFee = 'PerPersonFee',
}

/** @example {"url":"https://images.rmscloud.com/rmsoimages/6880/rmswin/rmsonlineimages/00000090.jpg"} */
export interface RMSCloudRequirementImage {
  'url:'?: string
}

/** @example {"amount":30,"id":7,"masterRequirementId":7,"name":"Chapagne & Chochlates","quantity":2,"requiredDaily":false} */
export interface RMSCloudRequirementLite {
  /** @format decimal */
  amount?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  masterRequirementId?: number
  name?: string
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
}

/** @example {"id":35212,"name":"11am Check-out","chargeDailyIncludeToDate":false,"chargeRequiredDaily":false,"code":"","description":"","feeType":"PerPeriod","groupingId\"":0,"guestFacingRequirement":false,"inactive":false,"monitorRequirement":false,"note":"","quantity":1,"requiredDaily":false,"showInHousekeepersReport":false,"sameDayRequirement":false,"sundryId":0,"unitPrice":0,"useSundryAmount":false,"perAdult":0,"perChild":0,"perInfant":0,"secondPerAdult":16,"secondPerChild":12,"secondPerInfant":5,"secondUnitPrice":0} */
export interface RMSCloudRequirementMasterCreation {
  /** @format decimal */
  adultAmount?: number
  /** @format decimal */
  amount?: number
  chargeDailyIncludeToDate?: boolean
  chargeRequiredDaily?: boolean
  /** @format decimal */
  childAmount?: number
  code?: string
  /** @default "PerPeriod" */
  feeType?: RMSCloudRequirementMasterCreationFeeTypeEnum
  /** @format int32 */
  groupingId?: number
  guestFacingRequirement?: boolean
  /** @format int32 */
  id?: number
  inactive?: boolean
  /** @format decimal */
  infantAmount?: number
  monitorRequirement?: boolean
  name?: string
  note?: string
  /** @format decimal */
  perAdult?: number
  /** @format decimal */
  perChild?: number
  /** @format decimal */
  perInfant?: number
  /** @format int32 */
  quantity?: number
  requiredDaily?: boolean
  sameDayRequirement?: boolean
  /** @format decimal */
  secondPerAdult?: number
  /** @format decimal */
  secondPerChild?: number
  /** @format decimal */
  secondPerInfant?: number
  showInHousekeepersReport?: boolean
  /** @format int32 */
  sundryId?: number
  /** @format decimal */
  unitPrice?: number
  useSundryAmount?: boolean
}

/** @default "PerPeriod" */
export enum RMSCloudRequirementMasterCreationFeeTypeEnum {
  PerPeriod = 'PerPeriod',
  PerPerson = 'PerPerson',
}

/** @example {"arrivingOnMonday":true,"arrivingOnTuesday":true,"arrivingOnWednesday":true,"arrivingOnThursday":false,"arrivingOnFriday":false,"arrivingOnSaturday":false,"arrivingOnSunday":false,"reservationMadeFromDate":"2020-02-16 00:00:00","reservationMadeToDate":"2020-03-19 00:00:00","reservationsMadePermanentFlag":false,"reservationsStayingFromDate":"1900-00-00 00:00:00","reservationsStayingToDate":"1900-00-00 00:00:00","reservationsStayingPermanentFlag":true} */
export interface RMSCloudRequirementValidationDates {
  arrivingOnFriday?: boolean
  arrivingOnMonday?: boolean
  arrivingOnSaturday?: boolean
  arrivingOnSunday?: boolean
  arrivingOnThursday?: boolean
  arrivingOnTuesday?: boolean
  arrivingOnWednesday?: boolean
  /** @format date-time */
  reservationMadeFromDate?: string
  /** If this is set to true then the default date value will be returned for reservationMadeFromDate and reservationMadeToDate */
  reservationMadePermanentFlag?: boolean
  /** @format date-time */
  reservationMadeToDate?: string
  /** @format date-time */
  reservationStayingFromDate?: string
  /** If this is set to true then the default date value will be returned for reservationsStayingFromDate and reservationsStayingToDate */
  reservationStayingPermanentlyFlag?: boolean
  /** @format date-time */
  reservationStayingToDate?: string
}

/**
 * Used:<br>POST /categories/requirements/search
 * @example {"categoryId":5,"requirements":[{"amount":30,"id":7,"masterRequirementId":7,"name":"Chapagne & Chochlates","quantity":2,"requiredDaily":false}]}
 */
export interface RMSCloudRequirementsByCategory {
  /** @format int32 */
  categoryId?: number
  requirements?: RMSCloudRequirementLite[]
}

/** @example {"linenId":4,"linen":"Bath towel","quantity":1} */
export interface RMSCloudResLinen {
  linen?: string
  /** @format int32 */
  linenId?: number
  /** @format int32 */
  quantity?: number
}

/** @example {"id":4,"name":"Business","inactive":false} */
export interface RMSCloudResType {
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
}

/** @example {"id":2,"name":"Local","inactive":false} */
export interface RMSCloudResTypeSub {
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
}

/** @example {"id":55,"addOn":"PK1","addOnId":1,"addOnType":"Car Park","addOnTypeId":3,"amount":36.23,"aqppearOnHousekeepersReport":true,"chargesRequiredDaily":false,"fromDate":"2018-06-12 02:11:00","includeToDate":false,"sundryId":2,"useAmountFromSundry":true,"toDate":"2018-09-25 17:25:00"} */
export interface RMSCloudReservationAddOn {
  /** @format int32 */
  addOnId?: number
  /** This field is informational, any changes made will not be honoured */
  addOnName?: string
  /** @format int32 */
  addOnTypeId?: number
  /** This field is informational, any changes made will not be honoured */
  addOnTypeName?: string
  /** @format currency */
  amount?: number
  appearOnHousekeepersReport?: boolean
  chargesRequiredDaily?: boolean
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  includeToDate?: boolean
  /** @format int32 */
  sundryId?: number
  /** @format date-time */
  toDate?: string
  useAmountFromSundry?: boolean
}

/** @example {"ids":[215469]} */
export interface RMSCloudReservationArraySearch {
  /** This call is limitied to only allow you to pass 50 reservations ID's per call */
  ids?: number[]
}

/** @example {"amount":986,"date":"2018-09-25 17:25:00","fieldModified":"Category","newValue":"Deluxe Queen","oldValue":"Single","reason":"Incorrect Entry","username":"Manager","view":"reservation"} */
export interface RMSCloudReservationAuditTrail {
  /** @format currency */
  amount?: number
  /** @format date-time */
  date?: string
  fieldModified?: string
  newValue?: string
  oldValue?: string
  reason?: string
  username?: string
  view?: string
}

/** @example {"id":0,"accountId":0,"adults":2,"allotmentAssociationID":"TravelAgent","allotmentId":12457,"areaId":3,"arrivalDate":"2017-11-17 14:00:00","baseRateOverride":0,"totalRateOverride":0,"billingCategoryId":0,"bookingSourceId":2,"categoryId":1,"children":1,"companyId":5,"departureDate":"2017-11-22 11:00:00","discountId":22,"groupAllotmentId":0,"groupOptionId":1314,"groupReservationId":0,"guestId":134541,"infants":1,"notes":"This is a note about my reservation","onlineConfirmationId":12986985,"otaNotes":"This is a note from an OTA or Website","otaRef1":"V5986985s9","otaRef2":"BCOM-8976958","otaRef3":"89869858896","rateTypeId":1,"resTypeId":0,"status":"Confirmed","marketSegmentId":5,"mealPlanId":5,"subMarketSegmentId":5,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","travelAgentId":1,"voucherId":"B4569856985"} */
export interface RMSCloudReservationBasic {
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  /** @maxLength 50 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  adults?: number
  /** Required when using combinations of Travel Agent, Group Allotments and Wholesalers */
  allotmentAssociationID?: string
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /**
   * if you pass null or 0 RMS will calculate the rate breakdown for you, if you pass a value here the base rate will appear overridden and RMS will pro rata the nightly rate minus any Packages or Taxes
   * @format int32
   */
  baseRateOverride?: number
  /** @format int32 */
  billingCategoryId?: number
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  children?: number
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  departureDate?: string
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  groupAllotmentId?: number
  /** @format int32 */
  groupOptionId?: number
  /**
   * This field will only be honoured on the response of a POST
   * @format int32
   */
  groupReservationId?: number
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  infants?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  notes?: string
  /** @format int32 */
  onlineConfirmationId?: number
  otaNotes?: string
  /** @format int32 */
  rateTypeId?: number
  /** @format int32 */
  resTypeId?: number
  /** This field is informational, any changes made will not be honoured */
  status?: RMSCloudReservationStatus
  /** @format int32 */
  subMarketSegmentId?: number
  /**
   * if you pass null or 0 RMS will calculate the rate breakdown for you, if you pass a value here the total rate will appear overridden and RMS will pro rata the nightly rate to include Base plus Packages. Taxes will be caculted ontop of the total rate override amount. If both baseRateOverride & totalRateOverride are passed in with a value then the totalRateOverride is used
   * @format int32
   */
  totalRateOverride?: number
  /** @format int32 */
  travelAgentId?: number
  voucherId?: string
  /** @format int32 */
  wholesaleId?: number
}

/** @example [{"id":0,"accountId":0,"adults":2,"allotmentAssociationId":"travelAgent","allotmentId":12457,"areaId":22,"arrivalDate":"2020-10-02 14:00:00","baseRateOverride":0,"totalRateOverride":0,"bookingSourceId":2,"categoryId":4,"children":1,"companyId":5,"departureDate":"2020-10-04 14:00:00","discountId":0,"groupAllotmentId":0,"groupReservationId":0,"guestId":138220,"infants":1,"notes":"This is a note about my reservation","onlineConfirmationId":0,"otaRef1":"0","otaRef2":"0","otaRef3":"0","rateTypeId":1355,"resTypeId":0,"status":"Confirmed","subMarketSegmentId":0,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","travelAgentId":1,"voucherId":"0"},{"id":0,"accountId":0,"adults":2,"areaId":21,"arrivalDate":"2020-10-02 14:00:00","allotmentAssociationId":"travelAgent","allotmentId":12457,"baseRateOverride":0,"totalRateOverride":0,"bookingSourceId":2,"categoryId":4,"children":1,"companyId":5,"departureDate":"2020-10-04 14:00:00","discountId":0,"groupAllotmentId":0,"groupReservationId":0,"guestId":138220,"infants":1,"notes":"This is a note about my reservation","onlineConfirmationId":0,"otaRef1":"0","otaRef2":"0","otaRef3":"0","rateTypeId":1355,"resTypeId":0,"status":"Confirmed","subMarketSegmentId":0,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","travelAgentId":1,"voucherId":"0"}] */
export interface RMSCloudReservationBasicGroup {
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  /** @maxLength 50 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  adults?: number
  /** Required when using combinations of Travel Agent, Group Allotments and Wholesalers */
  allotmentAssociationID?: string
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /**
   * if you pass null or 0 RMS will calculate the rate breakdown for you, if you pass a value here the base rate will appear overridden and RMS will pro rata the nightly rate minus any Inclusive Packages or Inclusive Taxes
   * @format int32
   */
  baseRateOverride?: number
  /** @format int32 */
  bookingSourceId?: number
  /** @format int32 */
  categoryId?: number
  /** @format int32 */
  children?: number
  /** @format int32 */
  companyId?: number
  /** @format date-time */
  departureDate?: string
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  groupAllotmentId?: number
  /**
   * This field will only be honoured on the response of a POST
   * @format int32
   */
  groupReservationId?: number
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  infants?: number
  /** @format int32 */
  marketSegmentId?: number
  notes?: string
  /** @format int32 */
  onlineConfirmationId?: number
  /** @format int32 */
  rateTypeId?: number
  /** @format int32 */
  resTypeId?: number
  /** This field is informational, any changes made will not be honoured */
  status?: RMSCloudReservationStatus
  /** @format int32 */
  subMarketSegmentId?: number
  /**
   * if you pass null or 0 RMS will calculate the rate breakdown for you, if you pass a value here the total rate will appear overridden and RMS will pro rata the nightly rate minus any Packages or Exclusive Taxes. If both baseRateOverride & totalRateOverride are passed in with a value then the totalRateOverride is used
   * @format int32
   */
  totalRateOverride?: number
  /** @format int32 */
  travelAgentId?: number
  voucherId?: string
  /** @format int32 */
  wholesaleId?: number
}

export interface RMSCloudReservationBillTo {
  accountType?: string
  billToEntity?: string
  /** @format int32 */
  billToEntityId?: number
  /** system label */
  description?: string
  invoiced?: string
}

/** @example {"reservationId":163577,"billToInformation":[{"billToEntityId":138452,"billToEntity":"Guest","accountType":"Account1","description":"Accommodation","invoiced":false},{"billToEntityId":138452,"billToEntity":"Guest","accountType":"Account1","description":"Extras","invoiced":false},{"billToEntityId":138452,"billToEntity":"Guest","accountType":"Pabx","description":"Pabx","invoiced":false},{"billToEntityId":138452,"billToEntity":"Guest","accountType":"Electricity","description":"Electricity","invoiced":false}]} */
export interface RMSCloudReservationBillToArray {
  billToInformation?: RMSCloudReservationBillTo
  /** @format int32 */
  reservationId?: number
}

/** @example {"documentName":"Picture.png","documentContent":"iVBORw0KGgoAAAANSUhEUgAAAIwAAAD3CAYAAADPJbw8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAP+lSURBVHhezH0FeFTX2vXE3d3d3d0VSHBICMQ9uNW999ZbihPcKRWg0JbS4u7u7p6EKBHC+tc+k1Da2957237P9/1pX/bMmTNnZs5ee71r7b3PPrI2APXtzXjwuAZ1nbWobX+I+o5HaEUzOtDO/x6jpbMZzZ0N0uMOvtLI1+VR+5uQb3/CPZ9wz78S8v/a0cb462UHS/mR/krZyv9apH9/v/xl/06Wnb8pxec3sqxjWf8XynqW4v2Nf6kU0dBxX4r69nuob2PJaGivYdShsb0BTR1NaH7SzHptkcrGNkZ7I5o7HqOV257wO7Ty/U+eNqK1rQltbfy9rU/xqK4ZBEwHdh3bhe92rMH24z9i27H1+H77Kvy89wds2v8jftrzPX7ctY7lOmw5+CO2H92AXSc2dsVPvxtbDnzPWP+HsZXH+eP4AVsOfcfg5/3lEO//67H54Lp/G5sOrO2K734nvsWmQysZy/9GfMEQx/hrsfPEd4wfsOP499jB+tzJehX1sufUZuw9vQW7jm/G7hNbsOfkdil2n9iGvad24sDZPTh0fje2HViDvcfXY8/Rn7Fp1w84f+Ucjp48geVffgXZkXOHEd0jBLq2CjB2lUHbQQYTD2WYe2vA1FMFhq4KMHSTwdRLGSaeCjDgPvouDFH+Xoh9Pf99mHn9m/D+/z+MPf6L4O/8y/F7x/svw5Ch6yyDlqMM6nYyKFvJoGAug8yEYcQw7CqNnwu+pmAqg4qlDBo2fK7F0OZjPpepy6BmrAQnPxdYOdtB9qjzIXoMiUVmURQmfpyDt6oLUP5uD4z4IFOKqvd6YNTHvfDC1H6YOKUvRn6UhglTMhg9GemYMJXPp6Z0RRImTEvAuEkxjKg/jPGfR/9xTObrkyMYYX8vpoT8tZIx5rPQfxu/fL/fK0X8h9/4HyP2L8fYzxMZPTHq056ofD8NhW/GIfuFUPQZ6YP0MnckFzkjrdQD6aVeSCvxRGqxF1KKvFn6oGdZEDKrgtF7eADihjliwOg4RPT3gk2AKUa+MYIZZjtktR134BpmhOQcD5S+mYiyf0Qi62UXFP7TC2Uf+aP4Ay+UfuSFEZMDpCj7xA1Vn3ugajLLyc6omuLIsO8KOykqP7f5m2HFsPh7Mdnsr5WMUdPtGY5d5b/GL9/v90p+/0mOqPzM+W+Ey1+Ois88UDEpGGUEdvHHQcj9pw8Gve6CjAnWSB5hjPgKQ8SW6SOmxABRRQYIzdVF0BBtBGZrIThHD2G5hlLp3U8LPv2MYRenKzGSdaAV3q/+ELJm3IdbhB6GjItg60lH+YdBqPjcBxMXBuOVZREYO88XldMJjBlOqODJKvrcFGXTzFE23YRhhLIZegxdhnZX6GJ4tRHD5A+japbxfxUjZv6V0pCl4d8qK6YYomzqb8pp+s/K4TOMUDnTgKXB75T87dMJvukWLAmiv1JOs2Rp+dfKabaonOWOympvjJjti+FzfPidPFE81QX5n9oj5yNrZL9niUH/sES/N8zQ82UjpIzVQ8JoHSSN1kfyWGN4ZMmQNsEJkcU2yBwfidjcYCmVBaQGQVaPG/BPNYNPmjri8o3Qd6I5Br5phNxPzfghNsifZIahHxugYLIxymZaoGK2GcqrjVE+24Chh9JqDRTPVGUoo2y2GirnyUFTNp2vzzCUooInUUQlK1VEKU/6b6Nkqt6zKJ/B44uYRkASlKIsnSavvP++1Jcq9/fK0u7PmqKLYoZ4LraXS9/ZGCWTDbmdx5hixP34Habyt0vfw0R6vWK6+H78Xd2/bwbfO5OAkko9/lYdlM/SYqn1F0u+n/HXSn1UzbNGPr/z8Pl2KOD3Lp1lhtLZ5igU53MOQTnXBoXTTVE0zYz7mSHnYxNkM/q9o4fY0YqIGK4O58Ey9H4tAJ4DzJA+Ih5pZWmSrpE9wlUE9TCHX4YmovJ0kTJCD4EFMkSPlCF5oiJSX1REz1dVMPA9HeROMkQ+T2L+FD0U8eSUCdDMZTlHC6VzNFAyWx0lBJAAUlk1K2YWK2UmK2WGDoqma/MLa6Fgqqa0vTvEfr+KWQZSJYoomWogVawAgVThgtFYqcVT9Lv2+aOSMVX7P0bRFK1fhbSd730GWIb4PPHZzwA9TV4pAhjykFeWqGh5yd9frcpQ/hsh3v/XorRaHRXz+D1n66KoWhOVCw0wdIoCRi41ksry+Toonq2BvOmqKJqlzf0MUCjqkkAqrSbzfGyEAR/Ywqa/DEkTXBBd4QHbJDMUvV0EVQemp7qnVxDa2xoBfXUQNkwbkUUa8B1K+imUIaRUAWHlCogaoYTE8epIfUkDKS+qovfbWhj0gQFyJ5ugZJYlgWMlIbikmqxESi+pJoBmExhdIQD1fBTOUJWiYLqKFPnTlKXIm6okRe7nKsibrEpgahBg6hLQimeI0CEAyWASuMhif1iKff44KuYQFLN1pMelrOiSmZq/Cvkx5Mfpfr14plpXyCulVKocxmzlrlB8rlT4myGO8dejaqE2hk6VYexKQ2RNkmH4Ek3kzZShdL4Siufy+CwLq2UomauGEjb0/BksZ7OBzzFE9iR9DKE2dR5CwpjgDu9sKwRl+8ArIwA+6RGCYS4jrI8NAvroISRHB6EF2ogq10d4mTZCijUQXKyGkBJVhJaqIKhYBr98GWlLleyjjsw39ck8Jsj5xIKVa80KtSd4rPmlSfNz1FA2V12K8nkaqJhPtC/QkkI8FiG2i/2Kq1WIdmUUzlRCwQxFlM/ha4yKuazcuXzPPB1UsWUMX6DHYEUKELKV/HHJz56j8odlxVx+n3l8zOeikktmqRDoilJa7Q6xraRaSXpdeu8cJbKpPErn8OT/NyEq/8+WvwoBgD9XlsyRR8VCNeQTJCOWaWLAJzKM+1obQwiisoUyVCzmPvP4eD5/9xxlDJuqKIGmkAw56BMdxL+kg8ByHQQUmCOcLiqpPAFevYKhbGsEWQNTUkimDXwy9BEy1BCRpSYILzUmw+jAN08T/gWaCCrRQmCxOvwKlOFDwIRWqCF8uCqiRqkhdqw6kl/SRubbRsj62AZ506xZ+aTD2QQBo5AUWzCLQGDkz+QXY3S/9vw+z0cxK6qYJ+CPyiJWbhFbyB+W/yGKZ8vLwlkyFPCk/ja69xFRMpcVyZMromy+PMTJfhbi+fMhtvE9JXMUuirvz5bPhQDzny0ZojEOmyLDhC+NMeAjMsxisjV/V8VCBZ5f/oZ5PIeinMs0xkZbPIuNc54BG6Up8qaYwr9EBrchykge7wefbCckl6chpH88ZHoaAjDXENjDCp49dMkwJoirtEFYiRGBok020SCrkHXK+VqZFoGjjqBSVYRVqhM0ZJwyBQSWyhBcLkPUaCWkvKyDjLd10P99FQz4UMZ8qIjsz1QwdLI6cqld8qljCphWhjHVdD8vFBqHqUTQYfk8Csr5FMWzmVuphbqjeJb6syhiWign8/xhzKOW4EkoJ4P8p1LOgPKTVjFfXWK/qoVMo2SUUsEkDFER3QCTogtEz+J58DwPlq7K+2uh+rdCnKPK+Wy0s1Sl3zXwYzLMSj0yifhuAjBMSWwsYl9xzkRGqJhLsU+XOeA9PXhQkiSMc0DPF8JgmWAI1zRvKNpSH778okhJ1xCQbg2PNAOEDLFAbIU1oiqMEFxKsEjg0JQAElSqKIEjpEIBoZWKLGUIIlAEGv2YqgLLZAgbTuCMYcoao4D4cUpImqiKtJc1kfGGHvq+QzH1T1MMet8cWR9aIvsjK6YyGwppe+RPdkThVGcUT3dFCe17yQwblM6gCGOUzaRG+k3kf07h/W9Dn8fU/cOyYDJdH4V7IZ1Q0TQKa9FFMMsEFdV0EHPMUUp73R0lM/Seifai6ZoMoV+YSqXo0jKs5F9Ft775yyGO+1eDKZn6q3CaBsYtM0c205G0nd+rfC4ZfAYZh41CnnbZYLhv0TQ96ZwM/Kc6okfI4E3ADPsoDlbJmnDqaQtNTyME9U7BhsPH5C5JAMazhz6Ch5giusxS0i5+FL0igsuUpPArIjgIDAGYAIJEYpYu0ATwsQCOKMVzsY94T2jXe0MINgG44BIyUokSwspUEVKuivByNSm9RVSoI7xKA5GVjCpVxI4i4EbLpEggAJPGKZIelaRImaCM1Ikq/yGUGAp/WKa9oIz0F5XQ4yVV9HqFIv51LfR7SxsD3zXAoH/oE0wWUhROtWSYS/azeIYZgUV7OsO0C0xyF1g6S0eqpF8AJOL3QPDfRvcxRHQf88+UZOQZctBUzeNvmaqKoRS+Ixfp09lSAjBE14cwG4UzKPJpUsRvE7+3z1s61KsypJBdrNM1YNfDAjI7GTJHFmHBz1uw8/xd0XF3HWG97eGZToeUZ46IYgNJ6IqKDSpVZoWrSCEei22BrHRR+SIdyYMg+U0El/N1hgBLULkADd9f3nWcMjWWavJSsFgZhfWzUlN6LaJCkSH7wwjjZ/xPRTgBLuLZ8StlSJxAYL2kQlGvTUY0xrBJBNBUivrplmQcC1K3yPWaknurIvVXztNkBVD/MCrmCVtM4f678bx1/nfRZZPJAH+lFGK+aIaSZBhyJysgdwp1Da12wXQKW4KkbA7ZlQI3byqZc4Y5hn5mTrZ1QdxoLaRNsINhtAwGkbpwyQzEgJfGYNZPO7H+VB2+2XUHsse4ici+jvDuqYuYQgsyjDEdESuPlStYQDBAaIWG9FhUZjd45CFnjn8BThdgBFjkIQeMAIk85AAJKqOgfj5KtSXwhFMfyUHz+/F7Ff+r4Hf6byOcoBYRUa4sRTiPH1pFEJGaY8aS1V7SQO+39CTgiBObz5Yo+qJEvhedl8Jyi8oppiYQTqWMGqac5e/G74Lo9+I50PzpEK6OGoWpp5z6LHeyrAswBsifpi4BpmCGNkYvs8bgT7WoJ5mCq73YQEzgX6iK+FEu0ItQg8xahuy3x2PHgxqsOHADM9afx8+nIQBzG5F9nOHdQ4+AsZIAE16uJYnasEqmjSo6IqYL8VgOHgGYLqB0xzO26YpnQPkNYP4L4EiAKRfBz/2DEBb/D4OV/2cjjED5JZSk1NudYkXajWGKFP1PGW8wdf1DB4M/EP1B5mQWUjlZJm+KotSqKykwS6r/C2D8Hpi6Q9rnt4zzJ6NLqwjA5AvLPE3OMPnTRP+XOgGjiXFf2NFCa2PYZGrJT10RVqEDrxxNmKeqQuYuwz+/nY0Vxw9g/r6jWHW6Dl8cfIQvdtWIlHQb4ZmO8EzTQ2SuBSKKjFgpBEhVF2BonwVoxGM5aERqkWuTZyHSz3PxdwAjnoexDCtT/8NSMGBoqQDOH5V/DTgiBGgESwqNJgGHEczH4UxVMUJXjZMh/WUlinbRi20uaQDRmy06+UTfkei/kVfcb0DyfPweUJ4Pab/fgOBPhABu0UwFKVUK9hNuqXKBDoGiLDnNkjnaBJAZhkyiQaDZCK/SQlSVJRz7aEPmSfc0eQLW3zqPr89dxMIDF7Dw4D3M2HgNXx9sEIC5S8A4dwHGSgKMqBS5G1KWHJG8VOY2CljGM3DwBP9e/PeA+S1w5CEHBqNU63fL0BKGAMcflb9lnT8RQqCLBhLKBtP9m0W3gYgwoZ8YUSMpxF+QkWn0WMFWFJeWrBjhTLTkwOlKDf8afwQYkca6oxswfzWUn7mgqvn8PqKzcq46hi/SkTpGy+YSRNWi38UMWZ+aYOD7tnDLYmMptoeiDzVcaSK+PEtmOXwUU3ccw7obbVh8tB6fbbiI9ReklHSXKcmVKckAMQW2iC41lXp2xQkSoHk+xDaRcrqBE8LW+Hvx5wHTHXLAiLT0bwHxn8pulvkvI6SE37srhDYLqRSAIaNVCvfGNCgYlgCKqKTeIdMIxgnhuRDjbLmThGuyRN5kuWWvmG1E8anBivtXbfHHoHkeMH8fNCMW6jwDjNSrPV+TgNEiw/DY8zQwdIoSRiyyQeY7uogbqwu/XEM4ZppAZi7D/L3foXrfPvxU+wTTdl/ChxsvYNmZdiw51owVh+ue1zC/BYzoa+kGiwCPvJUJupZvex4wcpvcHf8RMH8UXcCRi2u5i/pL5Z8I0dckIrBE5ZcQ28Tr5epSCNHfrd8E6wRT3wjQRAynBX1RGQP+oYthn5lI9ru82rRrEJKO5fn4FXC6KvffAeavBo87fAFt8zQlyT6Xz1GXAFO5QAN500TvrjqGTVWmdtFD6itaCCjib8+3hlmCEUxjHPHTjQv47mYDZh2+i8m7b2P20SbM2N+AaTvvY9nhWrmtDhe2+jkNI1ppN4vIU5K8o64bNM+A9CvAMI11hRwAfwEwXSGc2N+LfwXGH8XvA0ZdioASNWoYVflJ5Xaxnzh+aBnTFt2UAE0gwZMwVgE5HxMosxwlthF9NNLo9bMg40jRDZzfguZ/FjCCWfLEyDQ1lRhb6+7ZFsMFone3uFoHCRPJkK9oS0M/7gPNYJlkhYEvl2Paxo345lIjPt5GZ3SoCfNPPcX0g82Yf+Qxlhx5KCaB30RYph3cU7Tg1VsbcRWWCMhXQUCxIqJH6UitKmKEoGQluA+VIXKkPF1J8Uy3dFWSaOGMwDLlZyEHAfepYMvsil+D6V9DrpG6PuNPh9BWvwXQnwl5agyg8A+gXhLRLca7GUx0aPoUECxFZBlacDEVJGG8Iu23DtOSOarmWqCy2lCaF1Q6XUeaWFYhtA1BUzZTjWlLhBDHiiilHS9mqhAhHlfMEaHI15X+q3gGPEbZLNr6Wdw+V4spSQ2F00Wvs3zIQ7CMGOTNn66EUUstkfSiqEvRjWCM4Hw3KHqqYcKsj7Dq1Hl8uuU85p3swJc3gH9ufoAZB9sx71grVpysh6z2yQWE9rJHTI4zEktdEDTUEKnjbWHbRwbvXAXmOEP4ipPD1hQzRktill8q5rdgkdtiQel/HjDd7qoLLILN/kr8y3f7c6X4vgG07hJgukDT7eC6ASNSlNhfWPCIKgVJ14hIGK+MzDc0pOEJMYencpYpqqpNmKL0UTJNzL9RR/E0FRTShhdPJ1hmipADpaxaDpaqX3X8dT/+dVk5h65nDq0yQScHjhx88tcZklvjZ80UnXhCwxCwDCF4xdSTkmojpL/alTlKjOHHutcPN8Wwt8bhiyOnsehErcQu1ceBz/Y0Yel5oPoQWebAXcEw96lh3KHvLYNXhgnSRvnAZ4gmkifYImaUCULLtck0epIAFIJXPtgoKvXvAEaA4zfByn5WimAF/KXofr903F8D8b8rlQiUbtA8BxyGXJSrUbtoPxPC4qSL1BRAtgmhvosh2/R5k/T/EXXMdHOMmGOFipnUN5Npaz/XQOFkNZRMVyfTUFuQaUQFC9CUPBfPKv5Z+vp1WUldIkDTzVTdx5G/LgeJPB3JQwzmls3RYalLIOkjd4o++v9TT6rP8HIzeAy0hVMvd0Tm98aKI8cImIeYfoi6ZX8LoxVLzgEz9jzCvL0EzK36Swjr6Qv3RBskFoYgIMsWJvEyxI2yhVeOBpwHivkvxpI2EVMbxPS9Zx10UscdASB0gBjJLuEJZfmnANNdwb+N3wPDfxPPH6P7+H+mZARQu0khAecX8PwiykUvOLWbpPPIuARMUJcQDudxxBhY5itKGPqBAUqmmOP5OdDds/VEiqqgvRUVLJimRKQkCSwitajIg2nl98qKagJCgKNLEz3/eqk0qEgAETDlc+STv0TvbtEM4Zz0UDTdkILYFNkfWVB2yOvZrb8lfAb7wirBE1+eOILPt57E/JMtmHO0FVP3NmDGgceYtqsWy4/QJbXgMaIzo+CT4oMeZWkIGOSBXhND4TVEH57ZOoistJCmOXgNU5BaltA2v+7p/S1g/gTDiEr6/zACGP5kDn8CQkQ3cOS/RQV+xWRaCl8BmGfaie8JIWDDRJBpYqlt0icoYODb2sj/hGlJTO6utibjWFDX6MonzLMyS2fIK1kwxYj5GhizmJpHAEAKwUT/viydQcCJY7AsmS5ChYBQoHYhoAgYMVOxkDpKDGWIub3FZL2i6bbSzAFBAEnjHOHa3wReg9yg7qePObs2YOqOI1h+rgXT9z/EzAMNmLm/GTP31GHFIWqYps4ncA7yhsxYDWqOetIlBe59reAx2AhpE30QXWUHt8GiQ4tpqUIAhkDoGoSUh3hMZyEGLIvJLiL+LWC66P+5Cvr/KQJY4SL8n4VgHDnrPEtZpWQVPpfSURdYxPiTCNE/E8KWG8aI4uOUsTL0f4Ou5WNjiWkqZ5lj+GzGHGMKYz2yBFmAlVwyQwhYoU2EDReO6o9DDphfQg4YkerkgMkTbkgwDtORmJZRPNOA+siax7eWRqXFDMmkCSSBXMGGtnAfZAyPAQ5Q89PEyJnvYsnxswRMLd7/6QwWn3yMZaeBOXvrsWjPA6akhy1IHzwEny5agAUb1iDrxQIoecqg7M8Tl2cF5/60XVkaSBxnSxGsKIngXwAjyj8ATBdofg0YUf4XgJEY6JcK+nPx98D4r4Dhcwkwv4T4DNETHFKliECCQkzpEHOBBGCCmJbCGBFMUSIEaBKoa3q+qIiB76hj6Id0SzNMpasnqmZTGBM0otKLpymjiMwgQg6M5235r0Oezrqd1y/bBWOJY4lhAdH/IgAjJt3nTzGQ+oiGfmqM3m+K+Uk6Uvr0K1RE1HAz+OdaIjDXDSaxhvDOisb0HTuw8ux9fPjzSSw91YIFtNSzdtRg6V7JVgN+0SmoePVNfLljK74+8DMmfz8ZMnsZLBI1kTLaD+HFVtJYgyv1TGi5lhwgz4OlO6RpESwlduHJZMgrny1RgKWSLZPxexX1q/g/BIyIbsBI4BHPpfgFMIGit5tgEb/FnydeGAExui1AIypCTJOIoraJJFhCyTRBtOEiTSWSbTJeU0W/t9WQ9YGWNGlJmrg1W4QRWcBQHrPICP8mqrhvd5TTvneHuOJChDjGiPnyTsTcz/SR85Ehsj80QsbrmogkqBPHqsGH7CIGmSPLTRFZSpdc6QuXDBvIPDQwfu4MrLl4B/P2X8HiIw/xyY8XMGPTTaw62gxZx1MgOrU/Pp2/DD8eOoy9N85j5vrFGDV5PAzDdOGYboLUUX5w6adKNa2IyAp9aUwnRIhbAqTbZorOOyGifHlyRKvrju5KCObJ747nK+cPowto/yfBzxcg+Zfv9F+ESFGiY+/ZFAoC5VfB1+NGKzBYcePEZTzKUkUO+Icehnxkwgo2R8lkS5R+bokypo/yqZaomGaFyunWqJphJYXQQ5Uzua3ajinMnmBzIFDsmH6sadmtkfepDfI+tEX2u+bIfFVcpMb0SbbzGyaD9xD+NoIlMF+ROssEYYXULwMNEVvug+AcN2nCVELpUHx/9jK+OHwBs7adwoLdtyT9smDrDcguXa1DeGIGlq3fgI0nDuGj5bMw9KUyhGXHQGYqg1svKyRWeSNtrAfih1vRcosToSPNygsoEmlIDhrhHARgxMy8/xHA/J2QKv732Oe/CTlg/k786yg4U5gU4jUyUNeYVHdEkpliRikhfqwyksarImmUIpJHUf8QWKljKJ4JrB7jldBzgjJ6vqCEZG4TbJU4XvT9yDsN4ybII2GcCnWnGhlDE9EVakyJKoggI4aS+UJE3RTIkDrOiMyijcgSQwTnGcN7kBHCC5wRWegJpzQHmIV5Yu7mrfj50j3M3XYS1dsu4Cs6pOV77kPW+oQMk9YDmYXZSByaDi0PPTgmOMA4TAcyB6r9Eg8iUJ8HJgorzfglDLoAI8YhukEjd0gCPJIo/hcNo9KlYf6XRG83U/zV+L1j/on4Y8DIQRNZpSwBJZQNqtuSd4eYIhnObVHcL5qvx/B4sdw3jqkknsCKZeqL5uMoPhbpRfQ0C8BFUCeJifgxY9h4xbEE04sptmzE0qxC8Xk8ruidDqHLE/N2/XLUEVFqzs9wQlSpK2LKvJFQHgtFJ3O8UD0Pm67VYcGu81i45ya+PNaAFfuoYdqpYYLiw2DsSWpKdYFvH2f0n5AIr76WUPEifWUL2jJDcL4eQgq1GZr8QfqkOG1+OKNYUyrFpSjB0ow5bhOXpXTFs271ck2GOgFDC/4/1JL/MH4LgD8bv3fMPxH/HjBM6wRMN8uI6RICON1TJ4T+EUwgIowV3v24OwQAJLYgoEIE2FiKkNxal0aMGiWfzyS2ifG/8OGKiBgh7wIQGSBmhKgnTaYo1kuBEcHpgMBh1mQaKwTnBkHd2xF9J76OL45cxrzdF/H1qXqpD2bu1uuQXb1zBQHxHojN8seYz3JQ8UlvvDAnG7n/jIXPIG0qZ4F0ARgdhBXpI7xEj4AxRBjL4BJ96TKUoGLxWJcng/qm3IhA0XsWQaW6DH5BCqxu0HQ7p3852TyBzx7/XkX+t/H8Mf8P4j8BRhrt7gpR8d2AEQASQAqlAw0t4b5FNAiCKZhG/BniIkLfPD5mKcazRJ+YmBnoz319CQRv7uPJ10MqhelQgB9fCxDHH65EQS5vqKIPyTdfmBXWW5EhwstskDzWF3HDveE7xAGufahjHC2QWDEec3adwowd57HydCMWH6rBzM1XIHvYfBPRmR7IrAjAmMk9Mfh1b+S/F4Kxc3qg3yteVM0yuPYjhWWpkxotCR5zIp1pqcSICDeQQoBGAEbqq/kzgPl3lftbEPyZ+L3j/S/GnwGMBJrnGENEdJU6XZYGdYaYZSi/6lS4T5Hu/YrIHKViNoEWWUSH7KErleLcitF1vyKe10oN+JUrw1cAiZ/f3VvtS8ngVaCKXm96MnU5wHOIAax6qMOhj6hPH2qjKMSP6AGZBcX3+9Ox/MRtzNh5EYuP1eHLM61YtJ8apgV3ENXHFinFNhg1JRKjZ4VjxPQIFH8WgvgqUwkwdj2YJ0us+dwRngO1qbIplgoM+GOpbQgU+ZWRTD0sQ8qIXJGKunp9u8eXQpia5NMf5FMEpHEoVq48eOKei98FwZ+J36nE/834T4ARg5bPh3y7AAtTCgEkLkkWWiOwkCxBJvEtYIOlq/EmM3jkkVXE9e/iUqASTdp6eeoP4PkXmtKvkGl/OJlfRBUbbZUBwWIA/zJDvseILGQCn0ILullbJIwNQY+XEhFRHgrvHG+Yp1iSXdRgmZSCST8dwBenySq7r2LB0Uf4+nwHFh2khml8ehmRfUzRb4w9Rk4lu3xki1eXJbH0R5+XXeAzWBOGUTLYpzMv5jsgodKT1GUsgSaITCM0ixC+/oVEcZF8bok8KHgZcnCIsRcxZ0Y+f0Y+aPkH8XsA+LPxO5X4vxlyAPwxYAQwfm9bN+PIt3WfE6FFqBNF/1e5uOZZDwHUkP5kbxESkxfLmT6UoAirMCWL6MOn2IQgMSdYrJiWbPk+J54bNzKTD5wG28IoxRCO/VzgMSQAJsn2ME1xgX3vABjG+mDAW+9h9cVGzNh1BZO2UscceYRFxxsxdfNlwTCXEZiujkEv2KBysgNKp9ig36smKJ8SjvLPE+CfbQhFsozMVQb33jZIHRmOoGH2iCixo3iyhkcO82wJ09UYA3jS50eN1CTdCZHLFkJ6DauST7YS/TNiDokAhJhMLk6GmMUWNVJbGqMSlOtPOhUWXZ6u/mr8/wKY34tfQCTmDj8fYpuYgB5OJxk3WkPqWEuaaCiN9zhnMU2NNWPF6xIAZIlCgqbEhOfVgszN7fnGCMwjaAqNqUmsyESW8Mq3IbDcEFrpC/9iL7gNcYd3rj81UgJsM71g3sMLxonuUAmxg8zTHHqxvsh4ZSTe++5bfH+1nuzyCLP23cHn229g8o7bmLnvPhYdroGsCecR2EMFg1+ylJYbq5hui9dWxGLcvATkvR8B517akNmysvt7QCdABxaxJgjMcUdksRuiKu2p+E2l0ezwSh3pmlwX/jgP0UFEcIjLZ4VKF8AR6lwM1ok5NVIHnxBxhUxH0rQIYclJpUxfEVVMcc80zl+N/1vQ/D5YRPwHwFCviGuyBMt48xy6Z4s+FmNWOtN8hT7TERtWuQXCR9DVlNjAN9cMvkPNEZxnjfBCO4TnWyMo1wbRlYF8vyfs+zjAIt0WhvFWUA0xgcxNBzJ71qefHXSi/BFcmIMRs2di1u6dWHbqFJaePE29cg4rTjzEYrLK3EO1mH2wDtWHGjD3cD0WHLwnAHNWAszAF8zJMHLAjKr2wbAPPND/VR+EDLWHU7odpnxXDftET6i40UIPCUZkkT/Fr4M0gVhMgwhjnkwab0PEa8FPKHVSrGgt4kSJS2RFBBUpIoBAiRmhS/uoTTEnn7gtLStSJEoKuQqenP8JwPyd+B0Q/Jn4V6B0RxdgfjPxXITYJq7WENddxQxXR/wo6kCeL9EQXbMV4JSlgrRX/SX9EVjqxPPrhogyH2k5jtBcVwQMtodff2t49bWBcaQB9MJNoRpgBGU/Y5gn+iJ9XAne+moplh89glXnL2GZGGA8fgnfXnmI9XeaseZqLZacvIH5h29i/oH7mH/wEeYdapSmZs4/3oYFx5qw8JAkeskw6WroN84CZZ/ZomyqNcbM9ULO+46IpyvyoL4JHRKOYw1X8OLMj5D1YgVRqg7zWAskj45EDDWNS38dAoe6Jt8ULgNVEZDHH1uowefUNnlsNaTS+FGmFFd68GSriRluhMgKqvtSHQkwok9HgEaESG8ib/8+EP434v8CMMIJqUmAiSjTgHNfGXq9aM7HWvAaKmboJcBhgCZcsk2Q/EIE3Ic4wn2wC9ypQRzZmC2ijWEQoAldT2VouKnAJdULA14owAdfVmPRrvVYtn8HluzfhwW7D2H2tqNYeugKFh24hvn7b2D23uuYvPU8Pt50GtN2X6NWoV4ho8w/0IQ5+5swm6WYbbfgSCOWHauFrJUaJrinNvqPs0HZJy6onOGACYs8SVU+iKs0gl2KJsJyIrHt2klsOHMKK3btwDtLZkHLlw7KSga9CLJDvgfSx0dRDDshqtwbjhk6iCp1QY/xAdLAlnMfTdj3UoJXFu11AXPwEHWGKumU4CKoBGgE44gL6LonWstZ5v8i/j5ouocA/jNgaASkkF+cJ665EiBx7cf30u1ElhnAO5ssXGyLqOFkE6Yat8HuMIq3gFqQPlOMJjS9jeGR6o9Bo4bijanvYPrXs/Hlru+w5shWrDu2B6sP7+Pj4/jh9DV8d+Y+vjn2AF8cqcXiQ3VYzDSz8kwHvroALD/bgTl0QzP3PaQbeoyFB1oJmFZU73ssgWb+4SamqkcCMFcR2ssQA8Y5o3KSN0bNdkPuJ9qorHZAHPWEfZo6PDN98P7y+fj57EXsvHYHa48fw6wNqzBu1puwTLSXBqzs0u3h3tcLngO8kDI8ESHD/OGaaQ+fgS5IHhGOfq/EI2W0P/yHmsIvxxD+w3SeMZE4UVFVAjBqkp3824Dpmhn3l0I6xv8hYOg6U0ZbIEas0TNEC0mj3KBHlxpR6g/nfq5Q9NeGepA5AoekYsRnb6F6/TdYd3Av9lw4hyt1tah9Khag78RdtOHY/dv47tAxLNy4B4s2H8XKvTex6hgF7eFGLNhXj9m76jB7XyNZpQNLzjzFojOdWHCiA3P3PubrHVhw6CmZBbTVfHykGcuPUPS24hpCehqi/xhXVHzqT8B4IO8zMVfUDHHDNWCboghlNzXE5WXj7fnLsWr/aXxz4ATWnzmNVcd3Y925nXh10QewjHeDzFkHSh7GkrDS8bWAdawL6dKWbKQDdR9FspUxIgvdEVvugtgKe0SVmSKsmC6JNCw6q8RF8aInUziofwHBnwmp8slWfykEaP6PAFOqRWBQ3xXoYcDL3rBPV0TGhFAMfC0dxnGGdDNqyHwxH3O3r8Pq4wew49o17Ll6EzvOXMXuM9dw/nYDHrYB15oe4T5a8QggcICDtxux7vANfLGLsbcW83fUYMnBVjIGsJQx53AbZh5swczDZJMjbQRMGxbtf4qlBMuSY8DCo08lhllyUAw+ilU00/XRl8q75H0vDJ/uguyPFaX5FLkf2yJ9rCMrWwaLSDu4pURh0ITRmDh1Mg48uI2vD+3E2tP78f25I5i3/Wc+Po1X5i1A+Ycfoe+4sYjMHQLffj3hlBYBowhnaPkZQdNfC1FFQXRZHgjNp4DLpZYp1EJslRaiK5iOyDDihEr9D11a5tkc2+74FTC6J2uLoDWny+ieUvnL9u747YTuX6LbrUmfS8A860T8HUD8S0j7/xL/CpTnQw4ayRkVU+wWU78wwko0EC5cIgHjTYGbPMoZKSN9YZWkC5mjDBr+Jlh1chcW7d6Crw8fxZKte7Hk5134+ch5MssTNBEYLYz7zR2obW/F3ccNuN/eTrbhtqfAsbvt+OlkDVYffIilux9g2YEGLDlEJulOPQfbqFWeUOh2cnsnVpBdlh8mYA6TXahlFu2rwQrhkhpwEtF9DZBWZICqjzwkaz1ygSVKqw2kBXWKJrlj8Fu+iKRlMw5TgMxGBm0vLfQeNRgrD/yELdcvYOZPmwmW21i27wa+OfoQS/Zdxcoj17Hm1F38eKkOa07fwJQNWzH9541U8emQOehCJ8QISVVRiC/zgO9ApiaKu/4v0x7SRUUUsdUVKEs9nmJ0O2SUEgJHKsCN9tyBdjN0lAZcWYqLzCJGGcK7WAXutOg+lWpwY8v2YiXGvW4IDz524vF8hyvDi8ALHK6JoBE68C1VZ0XTpQm7yjQgLL0Q3KLSRCV2DwSKEPN0fxXc1g0meRAkXawhD2qyLsBLzyWAyMHSPUdGjBWJ0psGIJL7hYtuf/6eWNE1MUiGxBft4F1oBId+RnSiYtkwb4yfPo1p5SC2nHuE1Xuu4Ntdl7Dz1D3cqH+Khk6g5nEraloa0fq0HS3tbWh/2omWJ09Q28LtrU9xvxU4c+8xNp28jS92XsSirZewZNd9fElGWUEGmbe7HXN2EywHmYJ2NGLprkdYvqcBK/bUYsXeB/hyzy2s3nddLB1/BHH9DdG30hTjJ/thXLWrtJxXnrTUqRkqZ7tgzOxgVHwehuzX/ZA+0h3BWXbQC1JDzxH9sGTPz1i+7wjWnb6P5Tzw0v11WEkLNnvXLSzYexfV269j/p4bWH2OOXPrCWy59QiZE8ZCydMcKp4EyhBP9BkfiugCc7hmEAzDVBBXqk/RrCe5Bl+CxIsV7yNms41TQeRLOtLEbK9CsRKWOsKos/zJDL488f5VqvCuVIALgebJivWrVISX6DwcqwV3MpdnsSLcmPICK0V/hug5lY9vSSzDY8lTg6hkfg+CQZp+8G+jm1G6ASPA8sv8oF8Dht+jK8T0BTFHRUxkimUqjuHvDCtQRPJIA/jnKsKfrjJ4pD08hjnALMUeJlH++P70FazYdh4bDtVi9ZZr2Ha0BudutuNOfSdB0SbdwqapoxFNbQ1oJ8OArPKU0dLegWYCSjDQ7Ubqmhs1+OnYFXy95yKWbr+MJTvvYOGOB6jeVIM5W5vY6Dvw5f5Gyo46rDpQg2/23sZXu67iy+3n8c32U5A9bDuM+IEmGDDCChOnhGDCbC9Jv1QtZMyzRcl0O5RPcUU5wZT3ng/6veSGnqM9ETLUURK7Xv3CsfrkIcz4eSfBc0VS4B//eA7rrgFfnG7HPH7opI2XMHPnNXx7oQkfrtuBn2/eR977b8Kjb5R80nlvGwRmWyGpwhGpTI2RxWbUNsYQI6q+zPGeJTK4MQQQ3MTYSolYYUGLmocsUSSWOhPLVWhKHYNiWD9suBrc2WIjRhKQTE2RI3X5mgaiRhlIEUrAiON6FykjoFIdgVUCcNRPjGBWYPewxi8hn5bZHZLGeS7kXfhd3fhdIVKptE28LgUB2A1EAWI+DuFvEYCJ4neJ4HcRgBG/x2GQImz6aaDXK8kSo5d99Aa2XGaj23sZKzedxbdkh5M32lFHXDxo6sS9+kaySSvaqVsammvR3NyMJ+2d6HwCtLU/RUsHg4B51EF90/gYu85dx1pq0SWbKYi3nMTSHQTj/vtYe7INW64CxAgO3GHceoJ911ux5/Ij7LpwD3vO3SLDtB9HTD9jpiQTVLzviYrPHFA6wxwjF9ti1CJxrbAtSqc5YlS1L/WNH/I/8ETJZ5EUX35w6mkAVT81hOdnYN7Obdhw6R4+//EYvjrXjuoDj7CGoHnl62NYex2Yd7gO7393AsuO38Py41ew9sIlvPPlIhhGOlIoK8M22QTpo0IIIgO2Nlv45ZrAm/pGjJtEjTNB7IumCB9DZ0UtIq7IjB9lLLGQSGWxZTpIEC6LLCIoPoI23XMwK4XaSMzfcaNNFdogTAyQFqox1WhLg3ke+TIJMEEjNZjGFOBJdgrgY8FY0lweMagqHkvXWndfCSFA0mW9n4W8D0cu1rujC0zPMVI3a4lJUkH8rmHFCogqp4bJV2AokWkI+nwt6RIfJ6aj3i/1hMxMhmW7fsJ8pv0fD13GonX7sOP4HdysAx4TBHUtT1DTyFTUKW7x1Yam5kdoamhGeysBQ4C0txEsBA+fopn71z7pxMnbd7Hj7CV8R/Oy9tBZ/HT6JnZdb8JRHvNSO3CD+95mEDO4TdDd5rbbFNN32jrFoohnEUaXFNpXjU7JHP1fMsCgf+qgQKyrX22NomniOhobjF7ggZFzPVE82RllU32R8743WSdNughKLBOx8dYJzN2xHfP2nMEWyvNRS/djxUVgyp46fLb9PmYfbsEaonfegYeYtOkkvrtaw3S1E9XbfiS7JEDDWxuOKTbw7e+I5OHBiC5zQ2C+JXxyDeBTSOCQpkMr9BBeQc0yRJWW35Li2QhB2ZpIKDFESrlYfUIVCXRdUbn6iCu2QmyBKVKr7OGaLkPqcBtE5FFQDhSz2PSk9BNA7RA8gmlplCa8qhThTsD4jhCi2IDAMKYINiIIDBjy6QO/ngD2CyhEyK8m6Bbm4jnByHheHHeDJrycTEVtJYFbAHEoQZRL7ZRPET+M4K/0RI+xMdAP5vftHYKFP6/Fwh+pF09cxE/7z+DKg8d4SMpoYmU2Udg2MR21dbSgo7MVbW2P0fa4HU/5Wnda6njyFB18QvwQZE/x6Ek7rjfU4dSdOzhx5zbO1jzCxaYWXCUgbnLfe3zPA+5b0xUPCUVh1x+Rw2SNuIyQNCN4JVNsEd0J5WKVSiVkvqUmLWMx4J/ayHpfh1bbGLmfGmHwe7oom+6AsQvDUTIlEtHljvDPIXgmTaDdW48NNx9II5xfkl2m0esvPQd8uPk+plFAzTnYjNe+Po4fCd3ZFF7zdx/H9lt3MPPHb5ne9GDob47gfoEIHCAu2/RCYoUPoosd4TfEAO79VVnqkEXM2QrN2Bppy4vsJDGeUGSDpCJrxOcZI4GvReXYImM4j9PPFIkFzvDqoYH0Ukf0HkHnUWqJ2EID6RYwsVVMUSP0JdAIwexeqUTtowZ/MaeHgJHHHwHmF6A8795+C5jnQdPNNHGjyFhiiKRSE+Gid3uoEiKLmF5zyTBDDZFcHgDPTCepIU7+uhoHb1zAuj27cZgW+gEFrBC5dW10QI+b8fiJHCjtBIyIToKhk69R9RI0nVJ0dHSg/UmbxEKPGYKLGp9SDLc34j41zwMeo4bP73c+xj3pcQvB0SrdUFCUjzqbUPekEfWdjcIlXUFID3N4pSgjZpguoguVJVEmruATKy0lv6iAfu9qYthnBhTBJtLVc6+tCkDeJGsM+8QDpZMTMfjNNCnXLtr9PWbv2IX1zIH//PkKJu96iA2E6Ls/XMOikyCQHuBbssyyYy34bP0prDp+F4u2HcaRh48QOagvFMx1oWylBl1XZThF6iJqgBPSC9naSj2RVkrtVOmDjDFB/I5eFMuu0iBocI4XfHrbwYO/wTPdGK7JhrCPN4N/Xw8YB2nCI9USQZk2sA1hi+5vjqAMLfj2UEbUED0klhBcYopGoRDBekxPuvAp1YZfuT6FZ1eUa3dZcbku+S2rdAPFXwIa05koKbafXdPE+DVgFKVbzfhT8MZUkDULCMSh6ogrM0EYz3/4UAsE9HaEjrsGyt+sxLlHV9HAVr7//Dncbmpi9Qn73C6/Z+MTClxW5pNOahaC5UlHG57SIT1pffxLcJsIASZx/8aWVuqdjufu98j3NhEgzTwy4dcV8mdt0h0uua+0RXx2M2R1T64ivJcNAnpps3WaILpIXKuiLk0J9JE60dgixsiQ9rIMfd5RwOAP1aXbp4xiihoxLxhj5vVEzrsEjDNdSGYE3l/1DWbtuYC1N4F3vjtDVmnCkpOd1DBtUifRQvr9T9dfwXfnn+LLg3cxZ/1B/HzqOuauWQ+ZoSFMXCxh5qwJS2cFOHjQKodqISLFBDGZtghj+KTbIGxIMBxSXWCX5g27nn7QDrSAoqs2lJw1ILNWgo6/JexSfGEebo+Q/sHIHtNbut+PhYcMSgYy2PkyBaRpITHbjEA1RMhgPbZwC0RX2FC3GMGP2shXDKLSPfnRwfhL2oVphBUuQlS8BAKRgp6BRZNAI9gqNCUX98tFcGI/OcC67Xf8SH34CEtdoo+QYUyJOTpIKrdB+DBTRA6xhX24MUJ6hbKKREtvwenrl/GwVVQeRev9W9KNPpmIBE+QXR6RQerxlCxDZKDjMXPVUwKng77oiVA5Yta2SEYdEvsIB9UhQMQUI5iptZ1QaGtEc3sT2YpAedqE5o4aPH5aK/GLxDFPG6SgYRcMcxvBPa3hnqyGyBwDROTLb04hrSlXpgpxNxNxNZ+YzyKu8IsZK8Pgj7SR86kpiqZ6YugHIRg3Ow/+A30hs6Vbyc+ll7+M6duvYOGhh/jox/NYR1ap3tuAxYc7MGPbQ2qdWmygvpm38QK+P3IXs1dvx7YTVxDXexAiEuMQEe6MYB99uFjLoKXCnB+sB20dGbRNxD0JFaHsrEdG06cg1IdVj1SElpSgbNJkzNy0Gd+cOoUNN67g59tXsOHKSWlM5esdq2HpqQ+PQCOERpvD2VUGc1sZ1PXpUnqZomeuK3xTdJBc6IaIAhv45BMkFMOiE9CbzkzMi40erSpdrObD8yD6ZyTQ0D0JHeRHPSSssH+FARmFIBhJVqpSggcbnT/Pn3BtQjBLiy0VqSK4QIOplQxaSJ2UrY+IIRT0BK9rigZc4vTgn+iOKzWXcav+Dh60PMKNh/ewec9OqY9F2Gap8p7WoeNpDdmlDk/INE/JIE9poQXDgOkDgpe43zPgPGUe63iC1ha5xunk09ZWASahc55S+7ShtvYhjydUTiNu3Dktlc1t99Eq3SmYxxcaph63ENKTlJ6iiShxc4p8trZSE4QW84eLziyxajdPmJjDIk5S1ChqnYlkHQKnz5tWSJvggMFvJCIoKwC+faJhGOiHt5f/gBlbaf/Ot0j9MV+cfExb/QALD7RgLrXMkv3NtHEst93Amn13sPiHw9h85Ape/3A6QiOj0Dc5FKlkjXyyR5KvERIDzBDsaQAjAqZ0fAlmr19LN/Yj5hw4hcm7T2LlxXpM3XEeay8/xpJDN7DgyAXMPXgUC/bswRd7d+H1KR9D35rpxt8GaUmeCA8wRlKMFUID9WApboypR9bxUkJcH3eEDbQlCxjDYQhtvOgnmajPtKyPQP5+L2HVCRYxRUPcHkiatiF6m5laAinGA6h5BGg8CsSF/BTUYrhjBBmnWBkeOWQ1nk9x8Vh4oSHiqKWc0xWRWOSArAmRcIrVgHkQG+QAb+w5uZUtux01LfW4U/OAuqMT9c1MPcIHkQU6njaSIR6hkyzQyVICiAAFAYEOguCp6N+l5WH5tIPA6QYM/yf50EWJ50B9HTmsqQ0P7j2Unjc2PEJNzS0KaCF1+X6qmPrG23wb01FbPRqb6gRgyDC9HKQVqKKGmUjOI6LEhHldH0EFXdMPxI8XVMyTFVLFklQrZqfHjtSR+ktiS72ZJkLRb0weZJrqeGH2cul6lnUXxPjDXczddx/z9tVKQ+YCNCuOdWDW5ltYua9O6hj6ZgdT2M6zWLf1KMws7RDn54hh8V7oF2CNivQg9A60QaCNNhys9DDu1RewcONWrD53CzP2X8FKWvaPd9yWlqYQLDZnXw3mUxvN2ncG8/bS0h87jfScHBhZmCAy1AeDe0ZjYFIAhvYKRlZ6AOJCrBHoawJDYxlUyGKR/dwQVWaLqLEWiBxtJJ9YLVIzbXB0JXUemSOS6SWSjBFOhyPGgMREdzFd0o9uza+ULEN29mdD6x52kK7dKlDneaWgHWkHlx4K6FHpjpihfByvhZRhTJ9+StKdew9f3kawNDFapc64uw8foKmVKYbVV/uoDo9bG6QKJIS4jSFYhBrkKcWslHmYliR2kfwNmeHJI3m6ktDC/8XLfHiH5qThEY02tz1upkppapDYpbWdn9F+D3cfnMX9GqYBflbHE6YpMp1IZbTVcsB4pGojJo/ug2AJJwiCCvRoa+XXG0mdZCPUJKAEEDiRZBmxfq00JYGuJaHMHyEDAxE+KIlpwkhaavzLozewaP9VLDhwG7P33MXK052Ye6AZ8w62YNHhVszZVYeVBxuwYu89rDt0F8s3nsDPh65BpqCBlCAPVPUKQ4q9LkrifDA0zAPJHrYIdHPAoKFD8d2Rs/jm7D3MPl6Dj/c8wPSj7fhsZyO+OAMpFhyvw6LjN/DNSTLYoVNw8A2Gk5MTesZFISc9FpkhHugX6Yl+sT7oFUU3xggOdIK1vQHUyDiWSRSv1DSRVWKNHFruLEW6QV3EV+oggMyTNFwLceL+COKqz0JV+BfS9RAwwRWmTD80EASHTwGF9UhjxI22oGahM6u0QGi+EWKLbZj6rZBa7IEIinq3WEPp1r+5o3qjpuMatcp1AqUG9+vusi7pclhlzDRS+fgxQSFqW1IzoiuuewRJPO/aSXpdAEYwRCPBxH0ErYjX+JK4Yfn5M9RED8TQJIFz5xbuP7hFMN6S9m/rfEghfRe37tOlEJBPyFLnL5zAwxoxjInnAJOuQ/1B10DAiOuPggq0pAXzxMx/MW0ychQtX5UivEvILOMFiNSkCVDiaoI+E+KZf52gYk/GGdgX3564hJXHb2PyzyekWVqi0+4LglUsTjPn6BNM2dMoCeE5e2oxb9ddrD5ahxW7rmDtwRswd/ZHbIAHevnaoiwxEBluZujrbY/C5Gh421ohOiEZ3x+9gK9O38O0g3fw0e77mE+QfLrtEdNdO+bz2FO3XsLiQ5ex5thVfLzoa+iaWCHY1xeDkuIwIDIIA8Np1+2ZlrxtkZsZDw8HU9jZGWHEhEpUvTUcKmzpCn4y2PYyJiMEIJFs4JbJtJIhQwKFakSuihSheSoIKWDKLhYrpxuwUfH8jbZkurZmutJHZKU5/ChqvQZpICTXGBHDzMnCwfDLMEVghjU0qKNUTGWY++XnBMtN7D2xndXexLoVd6dvZWWLzpQu0hAVLgFC/IkNQn8IoIgQjwVQxF+ndEd7UflyQHWBiX9treSlhha0tPDY3O/U2WMsxefV4f6j0+ibFQ57D00Ys9GMe6UIN+6exNWbp1BDMIlOwdt3b8kBEyhSUhrFrgBMqRHTjHwGnHz5DjWEVmrKu9mrlCURGDWaQCIdiysgg/NMMWBiIsxCDKDhqIM3587EykPnsPTwTUzddgFLTzVi3vEmaZG9j3bVYzaB+wkrVVSy6NCbuuOOdFXdmlOPsOroPZS+9B501RTgY6qKstQwZAe7YnCgKzL83ODnYAsjcyvM+WELVp9/gA+3nce8822YebgZX5wjs+xqwerjT6hdruGb4zfxw9ErGFI+Bja2TkgICUFWfCT6BLghwEAVr+UNQM8gF5irU8iSvV56YwIOnD2Cn47vwkffVMNrQITUD6IfqoO0igj0Hh2K2FxLhA5mY8miQRimStGqSb0npiTIr/gUl3h456khZYITPIcwFeXqw3OgOoKZ6hPLneGbSQvfzwIeScZQJ1j6FMTj0oPjeNRxH/fqb7Ja29Hw+BFbuGCIVvmYEP+Ejn3cQrTw/+YmuVD9BTQixONuwPAZU0g38wihKoDXyfe2tnXgUT1Zh/sePX2QoKzH8YvbsPzbSTB2oAOM10P6IA9Yu6kgMtkDsxd/jGv3TqL+8T20tD3CXTo0AuYW0W5HwNBO5xlLVi+MeVtMZhKCTszmF+MxYcOZj7sAEz5CHa5ZMiSPJWUP1EVKRSD0fNSQPXYoVh3ciYV7T2LJMWqXw/ew4GQTZh5rwdRjrfhwXzOmnwImHyNYDrVhKlPTlP11mCGlrGYsPniLNnsXAoN8EOxojDQfewzvFYvytGgkudshOSIImvr6GPPxFLLTSay43IB3N57BotMt+HzjNXx1sBnLd97Fj2fr8f3x6/h2xzE4eQYiJiwKaSFklohAZIV5o5+fEwaEusJExpPkao5ly6qx69gu/LB/C9PdXqw6fAALdmzByM/ehX2Ct3SjBosQbSTleWDweDKO6CAs0Ed8iQ6iRcoWnW90P2K4wXOYkpTGHHsrIGmkExJHOCOpyg0JpQRnmAxmFLamPkoY/W4BLj88jrqOO7jx4LKUgm7eu4UmCt2mZqE/BFi6QMDKlrAjngqWESEV8v5befzyUqew1WSEToJFdNh1dD7p2k4YdTzG3ZrbqKdOuVN/Git/nAxt/j4Hfq8+RY4YXOGNxH7u0CbLuAWY4mHLZQFjRhPqm2q6ANOLuTSFlnqoLSIKzaWUJObfigURxbVGAaVK8ssvKxUkwESO0YVdPxkGvBkIj0x9RGV7w9RTD2u3fos9585h1YFz+PZMLZYde4iZe+9ixsFHmHm8HZOPdmDScaaiy8Db2x9iobDbJ1qlNWGr9z/AJLHq9O5zmDpvLlyZMjzNtZHu44j+gW4oTApHgp8LvFztEZSQgBnf/4iVp6iRjtzAzN3XsfxYE5bva8TyHQ/w/YkaLN90BLOXr4VMpox+SfFI9XXGQDJVWXwQhgS5wppgyUmOwKbvvsL+o7uxYd8WrCFgVh/ahXk//4x9d6itjh5ERsUwqNhqQN9NE54JZtQcmkjLJXiHmiFuCNPOEKblYXqS9osfbo2U0U5IG+2BlEoPZL8WDbceOlKnpoaLDE4x+qh6Mxt7zv7IhHEXj5kKHncK8dpBm0sp2yRYQfyxojuaqVmaaXfJHl1I4NNfUCEVQuN0xy8vCaCIFNL2tJW2uBWtT5imuF1EB/+rab5LrcRzt/oj2PrL0KvQHgWv+uKFKTGoeicYFa8mI6cyHgp0j/vPbML9xutSirxz76YAzA0kDwmHQ5QpPFPt4dPPCdGlXkgY5SVfUrw/nVG5KnWLBrwIluCRiggfoweXIapsPd5kJisMqegHDV01jB0xDrvYqr/bcgwLvtuHRT/T8u6/J80fnXOogemoDbNOd2AabfaUE40EUB1mn2qWFuCbtvsBZu16iPXnW7Hkp63oNbAPHK1oqX1dUJwQglQ7fZTGU4dEesDWUBnDx1Ti6207seNmI6ZvPIe5ux9JczoW7n6MdccasXj9QfQdUgALY31khLmSpfyR6aSDHrZa6ONmgyQHO3w9azZuX72J23W1OHzjMo7WXsfum2exhXS9asdP2HR8H7JGFsA2yBF2gdbQtVWAKt2UW6AafMPUMSDXA6kD7ZA2hAwyhI+LQ5BcGATPZBM4R2tLzkfZSgbfRBt8tXEuHrRdpVW+IXWMCYpvedzAVEMX8rgVnY8JmpZOqRQDQSKNiP4ReXCTCDKMKP/dnwDPY6nnVjgtsgu3dScvMT+mvqMRtxqu4cSN3dAjiKOzjJH/picmzArF8Ml0p29aIGusG1KyHWDlrYhxbxZLDPiYdl18tGSrvePdoGytDF1PY5iGWSMgyx9egx2Yf+mW8g3R6xVrxI7VhN0gUjhttU+xEnzzdRFEW5heFAX/KE/YWlrATM0Qlto2yB5cjA8nz8fGfeex8dhtLN56HvN3XceS47WYeegePth2EbNPs4LPNWLm0RqmrRYsO/2UaaYJ0zZexfqzd/Da5GkICguHv4sDsiP9kR/ugfxgJ+SEOCLIWhPh/k7YsH0L5n37EwHygECpwdydj7HqOLB08zV8ueEgTC1s4WZjhNwkb+RFWGOYvxGKQmwRZ6aDvNg43DlxEfUPmvGgSfRnAmea77H51ONmy31qi8ts/01YtXkdKZsOKMEPPmF2CAy1gqMjU4sJz4W/htSPEyuuHHRQgExLBkVudwk1JLhkUOVjLb6+8vt5uHT7BC7dOMWT3oq2djJHawvamviY0dHEKhWTVoROeUweYO74BSz/Gv/uTwIMv7cAzGMJMhS7DJHRxHqGj8ScGf6yjIIYaBMwoz9NQsWnvsj5hylGzbbD6JnOGPVJKFnHAf7JRojq6UXAteAhLf3NW/chu9N2A/4pgRg0MhfD338VSUUDoOtvAtMoQyRXhqDHGB/456jCJ4fapUJRunrRYYAMqeMdEVfsgtC+TpBpyDC4fxoyomPgZmYJGxMjKCsrwsXLCy+8/T6+3roP609cwTfHrknu5esLNZi5/xI+2Xoas4TtPliH9364jE830DGdB769QFG89SByhk+Evh51lasLBoX5oZ+PHfoHOSDSxRAW+gpISI7B4Qs85oYD+OFYHeZuoJXeXYcf993CS29OgoqSMuICnFHcwx+pTkrIDTZFSaQjfPh957/zpnQm2x8/lSYgia6uK221uNX5SDrR9a2iW7yDOZx5W00GP2qe+EQfJMY6wd9NFb4UiVPfL8Q/X83CGy8Nhp+vHsytFeDopY+AaFvYeGrD3scAfhH2rKi7pHQhNltw7z7F7ZPHFLKP0dHC1NPMT2FIzCLmIAg6+JuAEWM+rcIi8992fnI3wzSLCeKdjTh57RDUqVu8U3Qx5vMUjJkVjpLP7SDusTl6rhtK3/NC8WvhSCRpKBjIeJRa1DbWoO5RA2SXH11FQFoUpn2zEtsvX8GUNasQ1C9FmofRa3gy+o+PhlUcaXWwDJkvWErTCQNpJyOKaDnL3eAQoQFd7htK2s6MDUOPUH/0TgxGUrQ3giguLaz0+bohojN64P0Fi7D+5Fks3X0E35xiRR+4hGlbz9F612IVgbL0yBNMF9rmSA2+OvUA1d/tgSVttquVAxJ93JETG4ScOF/k9QiFnaEifD3tMGrcWGw/chbzVm3HjpMNWLjqADbvOgsLc3sEe7igv9g/3hnJZIBhIabo72NEl6SMq3t3SpXTyTPZ2PEUV2pqKO06cbX+Dje38+TclwRoS1sDRbgXLMw00TstBDEBFojz1sXgOBug4RBab27B2MI4WOnzHPibIrNXIHpkBiOtTxi0mb4+nf4WK7Ee9c13cOcuRZuoQjGW084U1NYugUYOGIFegqFb2P7FP6GHxJiPEKliQpV4JrSLSChipLqRDuzrn5dCjYDJqPBF0T/CUPihB8Ys8EHZLCsM+8QYxe+5Y9xnSYjsbwpVCxm2HlqHuseiX6hdXPnYCa/4BLwydTZZ4Bo2nr+FRZu2QmahD/cELwT2ZsvKdUHmKA8E006mjbRE4BBNJJTZ0ym4QKYtg5WLEvx8zNE/OQzpoe4YnOqDcIrgMC8DJEe7wNPdCBrcT99cC55hvnjl04/xza59BOh9fHPoOhbvInj2PsQ8gmXSTzcxacddLKbGWX3sPjILxkJHyxRhHnQocWHoHeyCPuGuGJDoCy87A5jqqaGkqBgXr9zFvoOXcOjgRbw24U1oUtRmUSgPCHdC/wBDFMRSa4WaIspKkYwTifZ710n/FIRMAaIFPmgWKxaTtpn/BZKePG7C07YWNNbex8LqqdBXpUjuGYUewXYoz/BDjJ0Mn43ogekT+iHdSwtp/gZIC7Xmd1LDwP4xMDVTgZ+/vQSWCxeOoIOpoKH+IQ/NqhM+WerGp90laJ60ykeYQXEqgeVvAEZ8d5GUxLRwMf4jBLBgHTGs0ColqzpUr5wEBXOZNPVjxOQk9BxvhILP7TF6mQeGfGyI15fEo/SfgXSFVghIN0TeqB5sTLd4DGl6A+Ael4ZXpi/Hiu2X8NW+G1h7+CI+W/EVZPqqsAqyQsmbg2EbpYTsl8LgkaGO8FxL9BodSGdlBFWKOicfQ3h7mSElyg+9Y3kyfYwxrJcPSgeGI53aITrABIMzAtC3VwhcnA0hU5TBxtUJ2aXDMXPlemw8fg8/nqjFmkM1+P5cB+YcqMP8I3XSpPJpKzfC0MQW0YEBSAvyRLyrCe0xHU+0M1nHErY6MtgbaTE1vIyN637AJ2/9Az4W5khwtUNWpCcy+V0yPDQwto83Mry04cb9v188Ga21t1gxnWho5ElseyLleTG/RJzc9maeFTEm08mUdP0aaq5fhYMhQcH01i/UAT3ctJHhoorerkrIdFFEqJEM/QJNKMjtUNgnAuF+9tDXVsBXK+bjzo3z6GwVva0daHj4EI11j+TzVbrBISwvAdRJcIIWWE4xf+dPvF8oFv4WMWQg/TK59RbM00zAjHy9CA7h2vDppYeM8WTfcfoEijVK59mjZLY9Js4PxbA33DBmUhKiBplCRqasfXqe738A2dX6VtiFpuLj5duwbNttzPz+HL4/dg9LthzAO3PnQMXOEK7xTkjKD0NgHzuEDHLCgJdSaKcdoOKkgNemvoxX3n8Bzp72UFWSwdZEFwPTQpEWZo8Ugq1XpC16hFvKI8IOCYFWSGVF+nvYQUdbEzr6JkjsOQhvflyNBWu24ottZ7DubCMW7b2FVfuvYvfpW+jRsw8i/bzQO9wL/Vlh4/pHYGi0PQayRRelB8CdedZYQYaKQb3hrKMCHx1FjEwPxyA/cwxhRWYH6qIo3gbRYg6yqQyPbp1gi66hle2QxmlqGxol2hZjNR3tVAAPa0Qvl8QAtTdvSH62ZEAGXPUUMCDYHkOCLTEqiefBTVmK3GBjZIeYYWCIBQZFuyM13AfOVqboaKQOqq+VwPHgFgH6mFVGHfCkhRXaIQAjDzEOJOazyMd8JBHD+Kt/XYB5Sg/eSRCKYQFWtQiRph6jBoPL05CU4w3f3nS7vWVInmCAvu+Zou9HBiicZY/cD2xQ9rE3PvwqC3G5JpDx/M7+5k1cqzsobDXgGt0Pb1Svx5wfr+LbY6344VQ9U8VFbLl4HcH9e0LbwwQBvf2paVIRPDgAiaXJcO3hBW1vM3x7YDNO3L6KtZs3442334O/bwD01BVhpqOAGH875PeNQFaqJ5IDjEjnZshK8JCYIT3EDf2TopGZGA87CwsoMIX06dsfu46expdbjuKzZeuxdvsRbN9zCGMqSmGmQk3lb4W8aAfqEH0URVkiJ4hMFmGF7HA7xDrK2SPVg5/hy9e8aRcJlspYa1QQLBmeaoh0UEScnynP523+6ibcY7oR1dPQIob0xR/ZpYUnul3OAE9baXebxUhwO9YumQsrfoesKFcMpVMqibBAYZABRibYYnSaM/p6a6Msmdbayxym3G/B1KkECFMDwfjw2i10NvEzmnncNrb15u70IypXLkk7O+WMIK/cvwsYHuMpQfOExxOgkY7ZykbRwH8fYuJ7JfBJM0PEEHNp5FwsuxI8QobeHxog8309FE6mU5oRhJfmJiLvTV+E9NVippFh1ZYpkD1g0/KIG4gPlmzDrB+vYMW+Wkz/+bh0LdGyvYcxZ/OPUHIyhndGCAIGRCI4OxYmPGma/g6o/OQ9fLF3D5Zs3Ia1O49i4/4z2HnwDGbOXoSkpCQoEQRWRqoIdjdE7xgnVAwIR7KnAfqHOKE4LQJxzhboF+GHlABXhLtbcT9zqJEpBmUNxsw583Hx7BmcO7oHr1blwIe0n+6igQm9vNCPzFZC61oaZoKCECOUxLDVh1mjX5AFShLdMJSidEyUBSrDjDHYXRkjUxzR108X3qTW914sYKXdQ9uTejx++pgkzXTEtPDkCU+EAEpbmxw0RFCHSB2s1Ls3rqKj/i5CnEwQ72ZA8OmiMtEBPclYJRGm6OOhgjIyTm8/I4Ta0GprKKLxzj2JRW5fuCLHBKOT9l0ABu38LAGYJ2JSE4UpbXY7NY4YA6I07ap0+d+/c0Ziu5h+KX33rj8hqJnj+ECwmACmOF4raupu8tiNqHl8BS99WArnOG0E9NNH4FBtxIzWh80gGaJfVkbaO9oomuqK3I+cUPKZN16cn4LBL7rDyJfnn1pWdpfH90rsj7fmfocVu+7gu3MtWLD/PGbt2o/V585g+eFdzGejYBLuKM1ks4z3gm1aGCJLcjBp/Q/YfvcBvjp4Ct8fuYitp2/io7lfYsOe4zh56TpWrv4KWUMyYKxLwatMhgizRVHPQGT42SCMrkN0+ffxY+sMckJRWiB1iT2i3HQR5mIGJ0N1mFDruBvKEMA0EkGRluWnhbwATeR5KqE8UBMVgdooDdJlpZlhWLgpssPMURBtiXxfVYwO18OoCANkuSmgnNt6e+vDl8f5edUcSgUxKahBErhNYtaZlBJ4IlrZGhnicRs1jOhSb2lpQlNjHdoa7qMqNxP+VqroRbtcEm8vpbqCSFPk8vPz4x0QRlst+og2rFhC69WM+lv30FpDw06wtNTw88QIsUQq1C1MhyIVdQqLTbC0E8BiZPgpVYYcYfK//wYwope4+0/6He1ktiZ+rjSXQYCnWQJj65Mainuags8qYBOugtQyF4Tk6UuDy35ltNkVMgSSaeInqGPgu1YEjQtGTA/B2OmxiC8whmWgDLL7RHz84EKM+LAaa4/fwbydp7Dy3AXM3L8Nay4fw5oLe/HDxR3o88JQ6LMVi6mO0eUDsezYTiw4uAszt20hG53Dgq27sHzHPmy7eAPrj5xA9Tdf4x/TP8bydYuwZMVnyBoQCkdWmDndRmaQM0pSozE4xBd9fZ1ZMkJtkO6pjqExVhgcbIU+3qZIddZAXx89ZLIF93GXoSxCDyVB6gSKKsp8FFHpp4bKIB0UBGkjP8wIudEWyAnTQ4G/DMNDlTEuxgC5XqooDjdHLw+6Pn73RzdPor31IZo76p/NZ5Vm3LfLwSLvf++krqlntT1FTUMt/+1Ac8M9rF+1ADZMez38jDEk0gr5MZYYFKSPvDh79A0xh4OGTLLxnbTkgj0e19SSVcge9U14ePuuHCyi7p8DjJiDIsDS/oT6iY6q8znAdIPlt6ARABHPRfkvgKFdb2uWi+xOpsS7N69xq0hJLbjz4DyP/BAvflgMLVcZelZ5wTdLC775qoh7wQDuhdR4pQRNOS33m6bo9aoJMl82w6jp4XihOgVZ43wgu8ODJgweggmTp2PtiYuYv2cfVl09ifc2LkXOR2OQMrYvwgtiEF8Wh4L3CvHR2s+x8MBqrLm0G1+c2YH1t09j/Y3TeHvlfPQeVwaPnnFQcDCGzFQZBl76MPPWgr2/Bl7/Zx4WLngLqdFO0GOqCrGxQN/gILZMHtveCCkuushPsEO6swyV0XaoiqLjCKUOIRAGeiqit4sMxcGqyPOSYVSIOso9WfqrYXSIDnK9KTyDtFAYb0Z9oYEi5ttSgmZMtA5KQ/RQFmmDNGd9SbSyqaOjtQ4tHWQOgkVMem5nKxeiE3QqT9vkTqm2SQy4kcTpcARgGhvvofHhRZgTFL2Y+gaGWWBYlDX6U0cNDLVEvLsuXCkOF0x6Cw+unmetstJZaR3Nzai9exfN9WQX1rk0q58hsQt1hpjA/Qtg6KB+AxgBhm6AdP+JFPTvACO5MLGJIf9cpll+xu3753Cn/qwEGH02wLg8R/hl6cIrWwlx44wgJq8HDleUppXGjNNE7Fh1pL6gj8KPPaQFM4d/FAvZxQe34RIZgi92b8aUdV9j7u4fEVLeE8pRRpC5yeA31BO2yQawiteEjJUmLgwX693JLGRQDdWFbqw5ZN5q8te4v3mCGbz7uSLnjb5IKPGFWagMrnEq8IhWQf/cIOzYvRJjqvIQ4eUFV0Mr2KrpoCyzB91OFCJsVDC+bzAKA01R5KePLA81DA3QwmA/ZWQFKGNUohEqI7QwPFAFFQTO+GAtjOV3GMofP8RXCQWxBsiLVCcTyZiWCLAgRT42REmkAxJsdJDoZstUQcYgKARIxLRq0asrOrgkwdnBymIIgIg01fqU2oZnvaGpDq3NdDtMGT62wl7TDRGEWeFkmURn9PQ1Rai9BjIi3HH/4hE8fczKb21Efe09YobHJXAEQETvbjs/W+gWAZZuwAg91dbZDRgxj4X7PweW7ugGTTdIRAjwiFL8idfbhbvj05q7D+WAaWzCrZtXcf3Wef6Wetx/fAlj38mDR4IBQgdZILHcAaGFemQZZUSM1oFfuaI0LVWkKM98mXRfyMxXTNB7ojkGTKCGqWUuD8uMxwfLpuIfy6bAuU8QVMJ1oBSpBJsME/gPs4F5jAwu6cqIyrNEXIkDooqdEZDvAF8i1KIX81+hI6JHesGpvzYSRrtJy7OG5ZtiwCteyH3XH+mVlvDuqQwrPxkcKD73HdyGpQuWIco/HtFeUTCQqaJfbCRtsyfp3ROD3XRQ6M0IMkRFgiUtqxYyCYphQQSQN9nDTwnDfZTlgAnSRD7ZZogPQRKhicJYsk+sDIXBMgzltopoE+SH2CDCRA1vFOXREjVIOb6js51QaSNgRG+ocEkESyepnK5C9GgKoIgBN1E+fHgfne2syM5GZFG/hTloYmC4PS22OQqThDMyRYClOt6fWM60xoqiAxPHE/NjGxrFJWFkFbZyoYXEY5GGOglQEUJbCLC0ddbyezCFSUMIZKA/AIyIbobpftwNGPFYzMpre8zXqYPv3XmI+/eZHsUvbK/Ho8d3sGH310gc4IeAdNZJL330GuMprb/sOICMM85EumY9bDQNgrg8OY+6hqARS9BHl1IWjLETt/C7BS+xOsCkF2Cb4CSxh3e+G9JejUC/N6LQ52U/DHrRE8M/iULua97SVYZheXoIzNVBb1quPgRExChTDP7QBy992QsTlyVi+MwQDHvPHiWfuqD8c3dMnB2J0VNiadENYeiuAHUTLVy+/gDVM7/Bx+/OgYmmFbxs3RDl7YEYV3NMTA9CIXVCLztFDAkxQH6cOYZFG6EiyYKuiKDwVsTIQHWMZkoa7quI8gCyS6AChgUroJhsVhzNtBZPhglXwku93ZEfao8AbSVsXUox2kBQPG4lw4iRFsEwYrxFeCUBFsaTRokBRPMUM+lFKSZHC5v6pO62BApfEwUCxhH9Aiwp2qmP/G0QTAY7uf0H6pc7TAs1UsUL3VDf9AC1dXcosnlsAQRGB92Z6IUVISZ0/x5gukEiQNANim7QdANE/D2/XTCPmCLxqI7gJxk1i0HVRw24ePE8vv3uKwymaHcLsoIBs0SwuLSotylSKpyla9nd6ZISxpkRMEpwHkotI+Y9jVZD+Egx0CyDrxhLHMpMIgapvOOdoSAGo/q4wCeb7FBpj6GTopHxmisqpkeifJIfRk71R88xTAeTvTF8egDeXtOTIHFEzqfOeGVVIopnumPwB2YY8gFdwwcmeGWxH15d6ouh7+pjdLUXXl2ShJ6jnJGQ5wsZhWPP7KFY+tUm3LzdiQ0/HICpvi0MtPTQK5K6JsoL2aT5Ad7UH8kOKIq3RH8K3IJQWr4gDRR4KVDHaKLSSxElHjKMCNdAWagqcgJoc2MUkRsiwwu91DAuzRCfFEWjOMYVHtQedw7vB+rqJDEoXdhFNmkjE8hn4dNVMDWAjCv0jDRAyFJ+NaGwpi20yhewYsZ7CDBXRk6sO7WLLaJt6CgiCXRPa763Hi21N7hvPeoahNgUIKFWaqIraxPDm/J5LnKG+SUl/eKSBFhEZQuNI9IYU0+X5hGdjCKk2XMSYOQhbWMIShEpr6mBQCVYbt+8h9raR9i7dzfUNJVgaq0LPSsVyOhYVSxlSMrzQnKxGzOGnbRGj0+uBuLGmsOnSBWRY43gU6oMH7KMmMctLu+NqVRDmljo+9HTW/BPtYe2WCK+hwHCiiyRRZFTtTAAo5YGI2+qnXQNUuU8B4xd5oYRCx0IJmqFKcYommFOoFigeLolCqaYIW+SIQo+IRNMskbZxxYofM8QQ97SwphZrsh73wEDXnZFQrErIgYGSGNQi9Z8jxVrtmDLrlNYtuIHZGcXwc3BgVrAkxXiSgdlKFlXoUNyvZVQQjZ5IYaahPpFpKVSXxUUUrsUBSqjPEIdpWEqZBq6KQLmpTQVzKwIxDvZ/ujnYwRnAubx7Ys8x0w5EiCangFFjPeIa3jkISpYDLRRELfWyOezMhU9baeGeXwb1R9NhBMBX9U3DD18TFCQ6gcrOr/P3hgtgU0ApK3lFjXPdT4WICGDNNAhCX0k0qCwu6LCRVppF1cqsrLFVLguAEjpg5pJ6kchwKSeWjFCyu0iutnvUd2Drsdycd0mhjO4/4M7N6Xjrlu9Cgnx0dDWVUJEvC8c/UzgEWkKY547cSlN8GALBA01QWiRCSIqzBBeZYSAMm14FRAoxSrSpTHi4j1xtYi02kSBIkJyqGMbuyaBuybrIm24F/I+jEDBZFeChWlqpR/KCZS86aYomGmC3On6GPiJCqoWWEgxfL4VquZZo3I2Q9zwicAZPs0W42e54dPVcaiaZINXFvninS/DkUp6y/2nj3Q9tFeGA6zDHRDeuxe2n7iA1Zv249uf9mHz7hPQN+APs6Odi3LD4Ch7WmoNjIwxw2sp1iilVpGCOqbMXxnF/ioUt0oUybTZYRooD2NJh/RysiI+yTLBnBGheIkCvKeXnjQl4skjcTJpl5+IVMCWLmkNpiBxjU8b3ROZ4HHjXcmxiNfEBWNtfF2AqrH+Oiv+Kqb9cwyC7FSRQf3Sm/Y/zsMQbsZKOLXvZ1YcQUb7XV8nRqVrWPG3cO/WOSnNiV7Xxw0EggCLmEUn6l/gg1gRBCEGQZubH0siVQCAX4igeyTF84B53EL3RuEsHjeLYQeC5M7NK1LJH0d8NeLujSsw0FaFj5cdklJDEBZPsaouQ0CqFTyS9RBTYE/na4GQfDqjAm34FsjvQxBQoYng4TrwLVSR7mkgbtPYvRCSWOQpPFdPjFbfgm+KBSKy7ZD9OrVGdRqy/+GIgs8cUDbDFeWznFBW7YiKOY4om20rMUr+ZGPkfW4kXaBfIK6A/NQCJWSVis/tmbKcUfKBNQr/aSGtNdPnRQrV980x9AMnRFcYIWiYJQIGe8I62gUO0WFYvfsglv+0C3vO3cH6PScxrHQEzI0N4OtoipyUQAyJsKcD0saYODNUUvQWUvyW+imgLEAFJQGqKKCDKiRwykLVMZypaTh1yz/76GFmiRNmVoagKsUK0Q5MVz0i8LT5IU8400bHY6kPppGapUVoCJEOpKsHGyQ2EX00De10RlQ48ukBTEeNd1jpDzH9vfEIc9KUrHVhmi8SvIzhbqKM+5eP8nUer/EhAVeLRrJRSytZQEpLciZobW3BzZs3pWmXglQEr4g+WjGroamV1v1xO4OfypQpJliJcS2pE5GPRQfiE6YmgbLGRrqd+3fRUF+HulqKWgLsUc1d4qoZi+fNhA4ZLy87A8FBDnB01oW5nQzpWb7oke+L2Bw7xBZZU8SaIaLMQJroL4StV5G4tJfgGC0HkJjQLuZzh1LshpfR8JSoI6rAUIxWX4NnghFSSz2Q+0409UkSxsyMZOX7IP9DJwx53woD3zFB3zf10Pt1LZZa6P+2DkMPA98ywJB3zVD4vj0qPnHHiM99MXpqAAr+YY8Rkz2R/541+r2ij0HvWElLgSWMskFQvj3iK+NgEkWn1S8DK3bux/fHLmHRz/vxzc6TWPnzHvQZmANbC1OEezogJykA6S5qyKZ1n5hsgTwyTFmgEpmEDBPElESwCNCUBaljRIQ2xsZo4dMcK8wd4Y1JZf4oSbJEkJUCXhmRL1nj1icUhk87UctW+4DO50FrHWpbH0kXqMunAlB6Pm7A7foHqCcrtAn6b65jJdawYurx1pgCBND+ZwRbItFdDxlBNvA0U0fL3UusS1YwQVPXfAdX7p8n6Gp4xMe4XXOb20RHoJwnGimmxQh5c3unFNJjCtZmfi8hs2/fuUepVYf2doKVqauBzu7evXsUsI8kDSMuKGvt6mC8fvkCWpnm7t++gQBvd5gaasBUl07H3xYlRb3g5WuA5Aw39MzxgRsdZEaVJ8KGGiBcmretI03uD6xUop2WwYfhywgo1mboQqzMLi02XapKZ6xJwOjLV28I6mWFQRNDUfpxIqomx6PqszDkvuWK3uNNkTpKF3HlqtLNnkIZkcxnQbRbgcMoiBhhRGdcsQZSyvWRXmHCMEJknjJCcuVWLG28IdImmMEkkRppsDaSJ0QSPNGQOelhxNTP8M3x81iy5wy+OHAFq47dwpoDl7H0u50YkFUEY322AGcLZAZZY2iYCcaSUgeJDrwg6plgZYYqigPVUETAlPirY2S4LiYmGGBqoTPmjwnER6UBKEt3hIeZDFM+ehO3mN8b2bSFuRXm9y5P/h2e/HttrdLF7rWtj1HHx/VMG/fYykVZ3/EEN+7R5ZDqn9Iy908Jgb+lijTtc3CkM3KTfWEqk+HJA4pcAk2khmZp1l4zbtXfwB0ykzDuYobtZX7+PaYlaaokP6empRl1/EzxXPJMZJAGfg/BOpKq6WKh7j8hboWwfVQnwEuWElMimIZmT58MRxsLqPJ76GsoIMjTAomRTogMtcLgrDD4hekitrcNBo0MgldPNWoRHQTmiUWTVKTJ/aGjlBA0koCpkEm9vcFlegSLMUKkZePEDdXUESlW+spnSnqESwjrY4OMEV4Y8mYwxP2S4oi+6DxNRORSMZOaYko0pMoXq1yKpVgTR+mw1EZMqTZiS/SQWGqC5BILJBVayNdnIXW5ZMiQ8YIj7ZgKUsbYo/drAfDIMkNkRRhk3ppw7Z+AJUcPYeGBk/j0xwPYePsppm0+gyW7r2Pb+VZ8sf4w4pP7wtRAFz1CXTAsxhZZtNGFIUxDFLZFtNGlIUxLBI0ATJGPCkaG6uHFJGN8MtQe1QTMu/k+FKVOsNCUYeHcqdh9+ChO3r6Ps7Sd51vacZW1IVZZEuARF3bcZ03dpZYQyuAhX6tj3GequFXHls3W3Fp/B2Geloh1M6GtdkJFRiiGxntJgBEO6drp47hx+Twe1FO7NBEcTbfxsOUB7tNaX3tA8Dx6QOh0Pos2VnYH4SGmcAlmE3a7kZrlMcHUSHtcU1OD+3fJNrUPJRZpbXyEhpp7aBdaiOxXQ+0yvGgoNPj5aoyirAFIjQ6Es7UGQnyNkZrogsBQE7j5qRMwdkjOdUb/cQGIKjSXbpjmk6copSKJVYYzJTHE45ByQ+mmFwIw0nKwBJbQMGKhBtnDp2fJMGYI7K+HpEprxBJZUXlEZKEBYor1iSzSUpG6dK2SWFtWrH8fN4p0VqaFoFw1BOVoIXyIIaJyzBCdbYWILAvEFzsgc5wPAnOMYZ2iAP9sCzj2NoBzXxvI3BVgmuyJ2Xs3Ydq2nZh78DyWn67BJ5suSJeazNp5D6uPtuHnE82YsewnBIdEwsfBBP3CrJHiLMOYdDMM9ZdJoBGAEdpFAKbASwnDg3TxUhIFcm8jzCBgXs/1RVa8LbR4Mr/7fg3WbtmF7/afwoYz17Hpyj3sut+A402dOM88cZUC9AbLG8wJ1yk5xDJdd/hYDM7WtIpK5fbLp+BkQhsd44VAUwXE22sh05eazEwTbbcuYvHUz/H2S+ORkkS2LhuM7Tt/4LuaUE8hfefeZcmZidFo0WHX0lJL3cFU9fAGxettdDwmbIUTY3p80iqsNb+Q6CEWLCKei7kyBEnnIzqu+vs4un0D7AzU+X00ycJWcDWnsPdwwKiCQdJsw7KCdAQFmCMl3QtmDmT3MB0kDvNGSJYV69gR4SVm1Cma8KT78Swmu4gFFwiYoBFkm1JxDyzqzRJx92BViLvDiTX4Igu0ILv/5LQEGJcURQLEHJHFxgilLxcL7UQU6yGALOPD1CNuTSOWrBC3gIsYIW6ipQGfHDXpfkqhQ0ykcYmkAnckF3oxT4bCo4cZksuC4EuQuGdYQz9EA5r+TF2j+mLl8a1YcfwAlh47jbkHLuDbG08xZecdTN1Th/mHn+CLY8DUdRex5+Jj5JWPgZmuGvpEOaGnpzIqEk2Q7SvDsAA5YMrpjkr86JY8FTEiUEcCzMQ0bcyZEIG3i4IxKN4BGooyHDx6BGt3Hsby7Uexgp+57MglrDxxTbqof8OVh9h+uwkHHrTjWE0HzlOnXqSxucgMc5P1daepHbfvP8D2n7+HDisjLyUA/QNtkB/tinF9oiSG6RnoDid9TVjrqKJ/ajhcbDShoyzDwF6ROLx7Ayu/Hp3N99Hw8CpuXDiKc8d24+jOH7F/8xoc37ket07tRtvds8TXHTxtrKG7b8Djh3f5lKmOQlow2KOLJ7Dr2+Wo6J8CA35mjyAXRLmYwUFLhkRvO/SJYANJiZAaSGSII/z9rCDjd5ix8H1p8Un7SCM2bk/WsReFrAuZxFZaQMCrSA2eRQrwFWvgVGlI+iWAWUa6w0yxEsSd/iNZRhfpyDVMcIYlK5ipp9hSmh8RRIYR4wvSDSZ4MHFLOLEgYfg4XWlpU7H+ibjZU3ilGXpM9ETmhCBYRhPFiXqwpfB0jDZhaQrrMGNpdNss0AD+mX5YsGkJvjm8AXvvX8TsbZvx0/X7mLn9FD4juyw42oolp4HZB4FlJ4C522qwZON5fLf1MNSVZBiUJJ9HOyLNCrnUMMPIMvl+MhQGKKHUX5VBlxSgjeGhmhgZq4opo4Lxdkk4MiKsYKyriE279mDTiatYvuc8lh66hnkHr2L2/ssE7CUsOXwNyw7zNeqn5btp8/n46z1nsWrvGWwksI5cvImfNm9DSW4WbLVl0qy/Hi46yAo0R5oDQcIKSnCxwJsVBXhzeBHLwVj0wTiUZUagN1NXHDVFkr8dxuT2hreFJm24ijRD0Ijvs1WTwZKluArTj5U6JNYHn70yFru++xpHNq3D2Z0bsPWLuZiQ0wspHlZw5v5utMjDyHKDQp2lCWMWfG8Zgdk/1F2alSjmHxvoKOPtt1+UugVaqZD2XjoImbkCrOPonDJcKQ/cWbde1CtuCCi1gT9dU1ClCcJHWcJLLHJEByXd1J4pSwAmoUoT8dwma8ZNAsYadrGknTxzJIygkynQkS7EF/dp9CIVeZUqIGCUGjwoisTiyq7CgpXTfjEPuvXXhFksvyArL6iPHXzT7OEYail1zPnEe2LJD4uxdte32HdxH96b8xF6FvaDd2oUXpwxGR99tRZfHrmGtRfaMHdfAz7ccB8fbajBnH2d+PJoJ9Yff4QNu0/DSE8bA+L9kO6hjVzqlDw6ogIxHOCvKPXFCIYRgCkng1XQeldEyvBBoTveq4xBUqApDHWVsH7rLvx45Armbz+LJcfuYR5j7tG7mHPkFlntFhYeuomF+69j8d4rWLb3IuZtPIrd1xqw/tB5rNu6D0u/+Aoe9hZI9rVHcZIvhtEllcc6EryWiLNQxoBgR7ySPxAv5/dHZY9g5JMRXxoUx8eB6CHu2KsnQyadS7qPJSJs6TTDnFGSEoS8OC/khDkhO8QOmW6GCDch0zMFu+srw51uR4AxyEgZqS5M++bKGBrqhFE9g1EU644hfE+kmRL6+lkjO8INA4PJGjYGsDHWo/VuxMZNW1DfLiADXKYGusp06Nk7HjIPE6gGm8O6lxszRRjCyoPgMdQWLtmm8MmnRhvpQjAZwI/2WtwwJEIs18YsE5ClLDruCJhednBJ1iJgrBBXaYOAQh145SojfLQBvEqUpDVy/UerwraAgBG5bqQWIseaIn6sPVJHeyBkMOn51Z5YtnEKfty3EuPeHA4jW32o6qvgyJmD2H98Dz6f9SlcfOyZT00RkBAKJVN9KFlZoXfVRPx4vhHTf76KL8ksiw49xcsrzqJ66z18s/cWvvxhJ8yN9JEc4IicKDvkBOqhMFgHJUGadEgazwAjgcaXJZlnVIwS3sqyw+djU5AWZC5ZzQ207z8cuYGFu65g4ZEHmEMwSnGiFnOP3Mf8Q/ew8OA9LD14Gz9dbsGCLSexfMcprNt3Bt9v34958xfCgK27F4GRG2GHoX6GyPXTxSB3DcSb0hGaKyLBwRCxdjqIJqsGqcjwblYs5k0chreHJiNYX4ZkZz309rVAEdmyIMEbuZGuGBTIymZ6ywt3QFG4I4YylYiKHxjmgeG9ojEsyh2D/G0wkO/LcNLBxF5B6O+uj0wXbfRx1YcH2XdggC0SHfSRE+lFQW6HtIQkHDhyVrLod5lefzx4hu7zJH6+eAubbt7D6OpZcBuYCZmtLsFjAKf+/kxRcYgsj0YkZYTrAHNEVTkjaZwztSszTb4q4isMkVhOIrjecAbeiVbwy7RAaI41fLL04J+vS8QpInq8CfwqmN+onIPHa8KRlst3hBqVtDpcchSl1QkSy1yh7UY7R7vrFKAPR28jWBIsjk5WEPN0N/zwLU4cPYC0pEiEBbmjsjwHBSWDMIj0HNUrAZq2dnhr9kos3HIBC7fdx9J9zdLa9l8fb5GWM/t+ywH4ubnAz0ILeZGOGOKrS1uth4pgPZQHaaPYTw3FvrTVYqjATwGFPjJMTFLHm/0t8GlVPPryPYa6Kti05yjWHrqOJfvvYNa+e5hxuA4zjzegmqCZfaQW8w7X0rXVU189otV/iKV7qK2YmtYdOINN+48jNj4Gwe7WGBzlivxwKxSHGKHQTxtDPVTR14H53ZjnhloiSFeGMA0ZUpheetko4fV+4XhtYBT8ybg9PAzJksbI8DFHqpsRMrwp4Hm80ngfgtAJQwNtJcCkuhhjSIQn+npboyTOGyNSA1BIMA1P8MAwP3MUBFmjItYVMfxMTwKzt481RmTEYHC4D8z5/LVX38X3mw9h6bfbsZHpd8Pxu1i+6zw2XGrEEqbilSdv4vMt+zB81hyEFOVC5kmtw++rEUBnlBeN3i9nwGeIM1z6iZvbO9DlOiBoCDNKf7qk2s7bCO/tiZD+zojMdUHSCHfpjrE+dECxY02krmKhWwJHEyQEjFivP36iBXyHUp1nGSA2xx4m4n6Qgfrw9beEo50udHjCsvqmkxp10D8tAcMy06HHnJ2VFo53JhZhwsgBeO8fw/HqW1UYkD8AOnZO+GTRWqaMWkz65gh+vg58yRa/du8l7DxwSpoo7qGniAJSd2moNVnFAJVBIvRQ4it3SSUBihK7FBAwLyap4dUMY7yZ44+hSR7QovBbu3EXvtx5Qbojx4y9DzD9UANmHGuUYtZhMs2hR1h0pB7Lj9VjyYGbmLP1BHbe5An+eQ+Wrv0eMn7/Aamh6Bdig6FB+qiKMMCIEF1UBetKc4eH+uphgJehxBRDfYyooxyRbC7DqwMi8ElFX2Rze5KbAXISvNCPIBkU50nn54oUb+ogT3MMoB4ZFuWJbG4bGuWNivQI9Pe1RR++1tvdBH353sIwVp6VCno5aGFiRjgy3U3JLExVNvxcNshwBytY6+ri/Y9nYuuR69h2giwtbvT5zT6sOcHGwAYxa8cNfPzjKSxmOl5/qxnrrtzF5xt+xqDXXoZpVBBkZEKZszbse7ghvDAEwcRE0FBrafWJuEJnyOj8EdnHH/bRRnBJM0avcUEQd8IPKxF3KtWT1vIPqqSWKaZnZ4jl1lMm2lExUyANNINdgAL0SMlxcW5Ijw2Et50p7I2of1xtYKWphAhXOzhpq8JZWxGJ7mZI8KJSd1fD6NJEZPb0QvawFNjRDpaMfRHbjt/Gd0wJa47XYPqPB/EVW8neA8cxNKMHAo01UBrpgXHxHihmxVQGGkugKfaRd9yJnl8xjiQBJkEJL6fr4vXBXqjsFwZ9DSXMXPQVVu64SAdWj7mHGzHz2GMpZhxtxsxDjRTb9Zi3vx4LD9Rg+eE7kgD+9thVzFm3CT2ysmFnZ4bEQEdkRdhIl5aUBahheKAaKpkSxTTRkiBDFPG1kSle6OOkjjQrpiBrRbw1LBEfjRiIYmoZ4WwGJfujX6If+pBVesf6og+jZxjdpZ8tUv0ckBnkigQnczpCG4zuHSeN3A8kg1Ql+6GYKawkyg19PEwRY64qiV1P6rO+Yf4o7dsLbiZGsDezxpoNe7F2z0Us/PE41h59iHmbr2A5f59YwEloRXFrvsUnmuhSa7H44HXpDvgrD5/GzJ824o2FC+DZJx2G4R7QZjp3TBfs4oqQbEdE5LhA9qDtPlwibGESoAFtnmwHWtKIPAvEVVAtD1ZlXjNERJUeXIeI1SNJS8OUEZCjheihJuhf7gf/KDogXxP0iA9AtIcLTNkSx+QNRGqwKxy1FTA4Nhg9fZ2Q5GTMHK6DBGdluJC2U4LVMbo4Cm+8PAQBwQ4IjQ7Hln0nMJ80+vP5Wnx98AJ2nrqC3XsOoDdfi7bUR0moGypD7FHA3F3hZ4yKAMNngKkMU0VFmAxFZJmRLMfHq+HjwjCMy47jSTTEqBfellqbSHULj7Wh+kQHAdMmgab6WAtmH26GWINv/r6HmL7lLL479xBf0CWNev8zqBgYIJC2OYqtfXiGH9OCOkbQjY0L16QzU0KJjzJKyTql4RbIp+CvTHBDvJUC+vgY462SDLxQ0AN9YtxgxpQ1KDMSATyOnYUGzAyUYGOiDhsjNZgzZYk+lUgp7QUinL83w9sBfXztkBXkhOGpwRJw0hz1kepoiCADFQSaaiHZyxVpwf5IDQ2FqaY2CnLLsPvEDen6rq92X8MX++5i2b4arOTvFbe6WXoSqN7fjOm7azFt+01U77qKLw7fwLenbmHN0Qt0kUepKW/gnWUrmILSIbNUhCZZPCYvAEnFwdQwtTfhFeuJ+JwYuKe5wDBIFWHZdkiqcIFTL7G2mzniRpjBfbAMSWNpvZiqwkXXcqamtNSFE7WLHwVYpJsFouysEGplLI3/5LBFmLEF9PJxwcT+GUh3NENZvBfKk5wwuo8rAs1o1bwU8f5LWUiOcIGVGfVATjZWr/8JK3/ahm+27MCeQ4fwzfKF8DXXQaylJsoj3ahbbDDMmWzDFFAhLlDzUSFgFFEVrsY0oYDiABlyPWQoDZZhSkU8xg2OJetZILPfMKzafgFfSVpF3EiKDEOQzDrSgnkn2rDoBG39EbGI40N8deQOFm87gSlffgcFPUP4BnhKVzOW9wlDD1dVWnotHl9LGooQ7izXQ5kC3ABFQSbo7aKBwmhHJDpqoU+ILT6aWIBReb3hbKMDA6ZVZVpeS36f1Ix0VI0fhYmvvoxX3ngdL776CgYOHgAPF0c4UOTbaavDWUcNmYFeSHKxhCfTfBzPQaDQSQSXN621v6E6MkL8EOTkhF6JKTA1ssRHUxbg8M02LNx8Ft+eqMPi3beltXOmbbuLaTtqKPDbMWVXAwFTT3fYgi9Pt1G3NWDR7htYxAb1hbgX5LZTWH+B6ezEaZRPeg9WiT5Q89KDcyoZphWdCEqOxvSvFmD66sVwSfCEvp+qREExJS5IHeMuddA59yfFjjGTllxPKGQ66qOFxAwzmFF4OZvIEGmnCV8dGXOwM3oE6CE9gLbMUBl9vD2R4xeK/q5umJAagRRz+WUfPR1lpFUZpk3IxetF/eBppCJNDtdm6FC4iXXn4v0d4Ew76sHjZgVZoDTaFsWhJigM0EERGVGMVpcEsHVTv5QyNZaKCVSBMhSKoYMIFfwjLwz/KOsNTzN9hAaE4/C5Gsxed4yWvQmLyCxTdtdQv5BVjjZiwaFa6cQt3H4Zm04/xDebDkLXyAxujtZICXRAmrcBqtLckOGsIF0iWxBmJmeTOFcMppgd6KqLMUyXJeF2kjh353eeWNAHcz97GzmDM2FhZY5+w/Lw/qyFWLFpP/XUCTqXixTil7H24CV8y8c/HLqEzUcv4+CJS/Bw94ULtZ3otXXW04QnU3ofdwu83jcGL6QFId1KHelORshPjkBSeDCsrO3hGhiLhev34evDdHsH7kvgX0xduJACf/aBh6g+UCvdUrj6UBMWnnzCtPSU21sgbtm35MhTLD0MzNtTj69P1WPq5iOYt/csfrhVQybajqiKQqYpL8juNzXCJSQYnzB3rdu7D6/N+BTWkfawjWWaGUVnk29PWyVfVTO2kip6GNmlLy3ti5HwDVWBJivXjogXVx5mBdJuhtmhMN0eLjxhqa4WyAuLRG8nH7w9cChSTHUxPJo2kVY0hWDJcNTEx6X9URDti0ADnhCyR6K7AfqE2mNQtCvykn2Q4WuMTKK7MMYGBeEmKAjVRz7tdFEXWITYlYPlF8CMSNBEfpgy7WwwXstNkDqzLPUNsGTFOlbIbcz56TSWHX7IFncN1XtvY+nRB5i9/SKW772GLWdrUfnCezA0tISThRnKB6ZSU2hgVE939KF2KY5h2om2R1VGsNSvkuJOwRrkjNxwd8QYKiCEAHfTZGPwtMBb48qRGBUCZXUNRKT2xuw1m/EtndqKfdepGe7hS2qIlUfrJOcmtXCRQnZfxrw12zBr0RooKOkhq3820sPDEWVriiRrHUTw2MV+ZuhBhu5Lp5XNcxcfEgAbR1f0KRqD1Uwvi/fdp165TyA8kK5RX3D0Eebxc+YeeyQtITf9QJ3EqgtPiI7STszZDywU93Y8AIpiwbQN+OpcPb44W4eFPF9zD13Ee99vQtqYcZCJ0VvfmHi8O2Mu1h8+SbQfQNjgZKi4qyOpMh72Pc0RQnWcONobkSWO8BlIcZzIdJTjARnpNTXBCf3j3aUex2Q7/sBgW+Qm2aKK3l50mffx9keipQvizWwwLi0Wmc4ETbIT0uxlKIt1waflA9HHywZePBGlKczF7voYGueB3oGW0rXTYqK1uG45L8wUgzzVMJT6oTCQzug5wJQEKjwLcYlJWYQiBosJ4AmmeCM3GlX9YmBIYA8aNAhbDp7ExtM38M1hcW+nq1jBcuHOk9hy8SE2HL2KvKoXkBCXDGNVJWoDV/T0s0RFqicG+jP9JDigl4cOsmJcEe6kDzczTXiY68JRXxWu+ipSb60VNZwxXVlUINmmcBh8AgLhExaPN6cswubzddhy7Qnm77qJBfvZ+g/XS7HgYA210z0s2n8fX+y/jW/3XMHRS49g4xSEAN8wxPj5YWh8GOIt1CUmK/Y3whA3bWmtm2yxbGxwAMwsHfD6Z/Pl18XvYQPY/YCA4XGPECR0R/NYziODLjhFZt37UErJ808QLIc7Me+gHDBzCZzpO2gEtt+jAXjA7QTeobtYcaYW31x4gBmb9wqXBET26It3py/A6l3HseHUOfQfWwkDVnxsaTq8BjFHUvCEFPrCe7AzPPs6YPykMsjYkqIo7lLjPalfTDG8dyzZxQ1J9pro4aeLWDd1eOqoIMGR+7j4IsSQFR7khqEU2Cmk9UgLGf5RkIoX+8cjwUYPiba0p6n+ZBN9qYNOzJLr729MAJqiMNICZVHmyA0QOobOiO6kNFCFoSSPILJMVxRTuwjAlEaqMG1oYM5L/ZnyUpAcaEuKN8D7n/wTi9euxtKNG7GeOXrj2Qv4cvtu/HTwKKbMWQx1VTUEO1iiIIVi3dMEVaneKIiyRbwNAU3gCB0TTlaJCHCFs4M1evZIwbRJnyAzJRHhXi6oyM2SLhF2cHKEkZUtItP6Yt66bdh2qVG6veGnP5xmpdzBjN2stAONbL3NrMwmiPtCLznWjK+ON2LtgXtYTeH9yjszIZNpIT06FkU949HL1Ui6ZmsEz4dwZSOS3HiuPJAcFgB1dX1MX7peunvaFwcIwgPi3tMECI87/3ADZh2qk2I20/G0/Y9QTf0y52g7t9EAHCCID0Fimpm72qh5nmIuU5NwjUtPtmIRwTaT+mb5wSuQ3WtqQXBiJt6fvZIp6RJ+OnkDC7ZtR0xRDvRIsw6ZoQjhCQ/Mj4VDT0+osIWJTh5bPxvoUqMkRPkhzkusoxuK3p6WKCI7DI6xxZBkD/Tw98DGxcuwaupsWPEkulCwOTNVudPrxzhRv7wwDGk8CV5qMgwNdcZQisTBAcbS8mKDAw0xLNwcQwJ0MYwh5vUWUGCWhWhKYJEmUUnxC1i6wVMWpiCBpiBYCZOHx+Lt/AiMywmHC2k82N8Mr/9zDDbs/g7rtq3Fx9WfoLAyDy6u9jAz1EW4qzUGBlihOIxWNsYepfwufT00MTozEOl+FvAisAUgEtNTsfib1bha04jNew7CxMYemX16U1z3h527H7YcOouvNh3Awp8OYPPFJszddpkt9xYdSgNmH2plxT15FtWHW6WbiYsbeSxiZS/dfherd9zEyvXHYGpB9o6JRQSFb0miBwa4q6I0hCznRjaljhoY4oCMmHAoyNSxfN1ufLXzOoV9CxYdbCFziRuUk0n4fOaBR5ixvw4zD9VjxuFGSezPOkQ2OUDxv79NSk2Caebuf0L268RC6Xm7pHHmENgLD9Zh6b6bkN2ub4ZfXAY+nLMaa3Zewcod57H1+gOMmTUTmkE+0AzxgjY9ubK/HaxTQmAV44f3Fs7E2TvXpXVeLAy1kdczAfmJwUh10sOwSP6AQDN4UAiX9emBTnFRen0TVs+dAT87daRFmGJUfjhBpo6CVB8EGilIDFOW4IdYUxmFpDlyKJiz/bV5QsgwXqoUlYpMNRoY5kUxS0dUHqTMUHoWZQSGFKIvhmU+09FgNx6LmmZ0kjHeLwzGR1UJGJpsBU9ruhR+jjUZQ4GpQ4PuIyrIHhlxvhiSFIrKnuGYmOyKcgrrUREWyLCTYVQPX/QLo67TVYCjnTmmL1iIXacvYd2+k2Sng5i/9mfoOrghq7QCMT37wjsuU3IqK3ddwPxN57D+cieWH2/G8jOskGOdmH2cWqErZh6jzT3SSfHdjuqDrNwD3G9vM3468QRrtl5DQfkrMNYzIpAtkRfnhGxa3PJwbWTTCYqFCAYG22FwcjzUVHWxasMRrGOqWynAsp/HYiwgGOcdfoxZBxul/qbqI81SN4IAzEwCdAY/byb3qz7YQWDJ71M9Y1sLqne2YebudjLhYwk4y/l9RMefTNysKTihH/45fRW+2nwZi346i02Xa7Cnlh+wZQuGT5+Kfq++iNDCHLy2ZCFz7D7qnEP4dusOLFv5JSwMdBFkZ4we3pYoS/ZCuqsWhiV7SpeNTnrtBbTduSOtiHD91EF4OdOCDvLH+28MgrslK44VFmSuhpwIT4zNiKRz0sCYFBcUhhgi118DlRFGUmuqCKMDidFHRbAKRoVr0E4roSJIQYpyRjdgxCy8btAIey0ej08yQnVVNOaMT8Sk0fEYneWG/N5kjmxvvDg8BS9VpiOLFSFmz1WlBCGZLJTvrIgJEQZIIRO+lOGHItpKXbKKn7cbvv15E1v/Qaw9fB7rTlzHj2dvofjNj6Dr5o2iiS9D09YFI96fja8P3iJTX8Kygw8wZ/c9TN3xAJN3N2DyvlZMY8VMPdQpxbTDZBgCRjDNPHFDcQJn9pZGrNjdjO+ZUpau2QstTT0MSAlHupcOcoI0MTKG5yRcEyPiraRrowYkRkFP2wyrvj+CHw7WU1S3YP5eAoWfNZ8pZz6ttGCwWYzZx8hmR+VdCiIEu0mMd6idlpvsQsB8cZoCmGwjUtQcpioBms833sP8neI2xASMb1QG3vr8S/xAMfTTsXrM2XgAq9mClhw4hA/XfodNd27ji+PHsO7cRczbvAM7L9zA3jOXEZ+QghAvD/QMYxriCRfidEi4BW21GXyttLFo0sfSdUDtdQ/wzqvD2TppNcf3xJCBnvBzUYANU1SkvQESHc1QGu+P3BBrWnAdWmc9DHGnG6AbGh6ug9GRugSKJgo8ZaiisO2OX0DzC2BElAeqYkwUj+Esw9uZtvgk2x0fD/XEP4e5Y/qEOPyjMhhvlIfgjbJIvFUSg8JYW2Q6aRKgTngxwQNFrooYQzc2jiI3igAKtTeEr6sTVv+wEau2H8KPp25RJ1zG4l1nsfb0TWQOnwhdT7qVQYOp7Yyx4WwN5m65hEV772HVuSf49Kdr0lL58+lKqskoglWms2KmkfansaKEjhDpYQ4ZRtxDeuE+4Eta3BUE2TebzsDYjBoq2B2Do2yo5/TYiJQxIloLoxKt6ER1kBriC30dc6xcs18CzMoDbdQwTzCXpZhfNO9Qh3Qjc5F+Zh1pJVB+6YOac7yNYpj7ElTihucCNNV7RTzFtN0dmEzXNHUXrTffu5xaSNYkABPZE5PmrceqzVexkdZrBkXamhNnsOLQUXx/6RKmUSCuOn0ay/cdwrrjZyQK3n7kFHr37gtrAy3qlSBkBpogP8YcebHmSPU3h72+Ajav/hJtD+7iaXMtPnxvPJKT7VFSGoH588ZCh7plz49LkOLnCA8tBcRaaiMnxEoajc7zVUV5sAYZgvTLyh9J8VpJN1REwFT6yTCc7DGcbqgyWBFVIWQbwSwETBH1jJgfU+itjDwPBeS7K2Akj/NWmiU+zXLHp3me+DDPA69nO6EgTht9fWX8TC1puZDiAFMUexmj0scEWbZklhRXjGLKFIB2tbbEwmVfYSUb0s6rzZj242Es3H0B+2qZYjbvh8zKAbkvvoS+JUWQUdx/e+yuRN/LxPiUEKDUEnMPiRRAdiEgumMGtYPYJgGF6UH0NM8jOywmmObt7MCX+5qx4ufT6DswFz5OZjzHxhTgeigJ5e8NV0VhGI1BkBnSw/yhrWmCdZvOYs3eWiwTqYiAmceYc0AsAddBJhEsI9isAzMIjhlHWyXwiBACWIS4L6ecbbjfgadMY/IQ6UrcVGTpwUdylxQY1RNTF6zHt0xJG48+wPQ1P+Pboyew+thxbL15E0v37sX6CxdIk/vw1Z4DWLf7IM5cvYW+fTJ5Mo3QN0rcC8AABTEmKEu1w5AUb2nWF5p4Rp+0oKP5Hj76YCwimGJeeLEXsrO84EQN0fnoCs7s+AnOGop0JHYojHPFsFBDlDAFjWRLqgymyGX6GR6iJjGKAMvYMBU5YCTQ/AIYwTLCYhf7K+EFtrwxkcbyCVVicjhBNyqYIBSdejzGqCR9FPCkD/GnMCZgykNNUBFghBG+ZhgdZEXxTABFOCDEXB2WWqoYN+4V7Dx5E6sP3MD0n05J/Sef/XAE1RuPYMWuo5AZW6BXYT48IoMRntkXq4/cloOFQnEhW7wAzHwyiKgMiU0OsGSIu9HP5TYhSheKzjTqDNF9X72XgGGs5OMvt19G+aiX4GxtgF4ETD7ZtpgMUxomB8wANrKeUcHQI8N8t/W8BJilBIwASzdgRIULsMzqSn8zyCICNEI3yQEjB40YHpGDhtsPPqHmkYf4zvOYzsQC3TJxmYNfWCJmLmbq2XcNBy4+wuWGDmlS9I3OJ9LdRU83P4K4pPtqZ4c0afrC/Ro0PulAz9QkhHraIiPUDn38DZAVqE4RpoO+sa4wUCdgxAVcnU1oa7iO3CGxyOzliBGV0Rg2xB/Bvrp8vQ5orMOJn36Al54yEl11kU2hmx+kjRERukw3aijxJ1CCVMgwMlSQEUYTIL8ARrAMt5NphJYRDkne86spjWKXUjCXk23EhfujAlQwIlCZx1KW1o8p4jGLQ7Wl9CfGgSr9jTDK3wIjg2zQy1YNQ6M9JXsd4O2POSvWY/nWc0xDD9jK6qSbaQjHMGvDQXy0bA1kmkyj48fA2Mkao955V9IvSw4QLAdqCYBHBANFqCQ+2+S0T5CIx0JbiO2LWWmLWVkixK2BJlF0zj0AMkUL1uy/hU9nLIC5gQZ6BpLBw8UQhJr0/YeF6KJ/sCV6RAdDX98Sa7fRme29j6V0NkKoPgMMy2rqpVmHOzHzyFO6pF9A8wvTkGWEICZgBIAESGaKVMYQ6VIM2C4+VAOZWBDQJyASi1b+gGOXanC7SX6Bp7hg4lbbYwKlAxeaHxJAT3EP7ahjKaYyi1UNAn3ckBDkin7hYnKTNQb5qSOFdjna2wgJkZ6ou3MRFDB4XHcRafFOyBvih+J8f4ygbuhJodkm1q2te4TWG9dxdMO3sFal4Ey0xyAv2uYQbVSGakkXrFWFqklCt5Tup4qV3Q2YKjKGiG7xK1hGWGuRyiqCtLivupxhfFUYSnLQBKkiX1w5GUZmidSXJmOJeS0Sw/ibotTXgiznhN6hnrA2NMCwguHULeexaPsNLNlfjyU8sTM2X8OPl1rx3dFb6FU8Gjr2znjx/fegZmqAaSu+wpcH70ipaCEttOgP6WYYARIJLKyEbsAsPNImAWYRdYUAzELu9zl1gxCb83fV0mDcwZqfdkoj7uIaqJxQpiUK34IANTpJHfTyM0NyZAC0DcywZvtpfCWW6md6E4CZy5DYhSHA8ivAPAeaX5hGnpoEYGYSMNMPd0ghNI/oL5IY5lFDPYLCIrFm/SbcqmuFSFEkGHn5tB3i8i5xDWADgXP/aSPutdbjUZu4pVsTrI20kc4T25u2VCxWWB5nTeFrAk9LJbw2sZQHeUj9chtttWeRPzAYg+lOXhmdgPIhwYjw0Efn/Zt4fF24KDLXaSr8FZ8jwUcT/b3VUE66raRTETPrxDxdkZaGkx1GhRJAXUD5V8AwSNfCHZXTUVUxDQ33J8N4UyTTklf5kK3EDL0AVVRE6KE4XFfqOR7mq8n3Ub8EmyDXh7Y/MxqhZAtTAxOpi37V7utYfeIxGYNaZA9NwY47+PIQBeneSzBwC0bCwBwMKq+ETF0N6w+fxpdHHhIA8tFvcVMxKQiUORShwsIKjSBofw4rQwBHAg+BsoA6QeiZaoJF7DNz8y2sIpPtOHQOuqpKyAxiwwwxZ0oyQGGQHrID9NHDzxwJ4QHQ0DfFml2nseroQwKmgYBplT5TpL1fA0YuuKeL1NQFml+nJrILnwtmeQYYPhapahHTrOxxayPiExOwdfdu1LaKJTBYzx3ibuodeNTSJK1NX9tRT9A04GFbHR48rkF9C50PAWOqpYLeRHeqhwV6expjdJI7ypPdYUS7vGf7ajxpIhieMrk1XUTvBDsM6+OI10cnoio7GEEOWgQKP62hjR9I5d3yCLcu7Ya/vQwZ7sooIt2KGMaUIqZhivQkQDMukswhuSSmI7KMCKFNJMfE1FTJlDWMTCS0SpnERAoYTdCMDVTDeLLWmAh9CYRFfCxWrcqmwM6l1ikLN0VluBnTobnUe+qgr4G+vQfgwOm7WErHs4IaY97eRixli1xOrbF8z218+sUmgsQU+eNfg1dsMmz8g7Ht0j2sOPpIAoBwFvKOL1FpQrswBeyX6wORIiQR2gUe8fpsCmGxz0La2hkUv9O33pAAs+vIBeiokGECXTAszIb6hUzIyAuzlBprYkQg1A0otveexben6qSKFSJVCG3RtyPpJolV6NCeAYafwecCNELbSP1AXSGeT+f3EpZfhHgs9NeiQ3RJLdQniUmx2H1gD+rFTRPIKMw4UohFAcXtacX1x2INabGeirSqSkcT2pvroa8kw4DoUPT0dkCSrTYp3gn9fU3hbq2KlsaraKy5xAM9BJovIMxDFaUD3TGxKAz9YizxclFfoKYOHbfr0HKLoBIrEXTcgp+jDFGWYoEgdRQE6rLFM18H0C0Fk3XogIQG6bbVkq5hipIDhgwSwu1hBEkMxXA0y3AZRoZS5FIMj/TlNjJMsbeSZNfzgzUxNJgOj2VuKDWI6POJIN1HWKJfsKME+s8+mYxtBy9jzQHa45MdpGRS9fYaLGOaWXOkls7oMyhaeKDghXehae+F0tffx6pDV6QKkyqKolW4oFnPt3DhPMggvwqxXTAK9cZ0AmbJOeDznQ/JZvew9vBt/LzrGLSVlKVbAeVHOCPf3xglIRZ0TA7SrD0xwKmka4ivdh3HNyfuk93qJJH6nwAjB83vAaaTIKGt5v4ipvM7CmCL3mNZbc0DRMeEY/feHRD3Lxb3MxZLmYtbsjwR1woTIOJuFmLJ8YZORutD6SKsmttXpWt0BkSGYGhMEHq5mUlTKIOMWIHDUlH/SNxgsh6dLbfRWXsOg5NcMCTRAv8YnojhA8hK/lZ4+pCWu6GFKYvCqbMdD2+dwOfvlMNXT4b+HmKGnRkqo00wJs4Uo6P1UEZXU8jUIvRMOUEggCJY5HnADCdASvi4mNuKCab/R9tbx1d5bVvDQUKIu7u7uwsJ7poQdw9OS90FJ0aI4A7F6qW4JriVttSACqVQoNRtfGOuTdqe3vbcc27f74/52zs7W55nrbHGHGOp/F/YSByVWHOZ+yuAUTogyogAMUM+haRajUB3JvvWJXjZwkJPX02kXr/zODYd/wKL91EbsCCXkyE2dH2DjUc+Q0DaBAT2G4mi+5+Elo4Z5m7YifY9l1Qqku725k6NdVaMQu2w5F6FdVechLwmoBEgLT5G4BA0K98G5u69hlUnb6uzn7a92QXdXtpIo8EoSPDCBB8DtTtXUbyT2ho/NS6MwtsAa/YcJ/td/RvAiNv5/ff/J2B4jQIYAuPfAubb735CYlIKDh8+qHYLUFtLSPwqp3p9Q5n7FdnlDp/Jkdt31J4q+OU77Nm+BVYyYz0+CsOCPTE20l1Ncg627YHjh7fh8+vvKmD9/A2dEB/z0sNRkuqJxsnDMX1CJJz06KJ+pJj+8hq+/5H8Jfvw36HeuXKabsmE4llHtfa6NEeM89BSO2KKJilmupGhAc2UTI1WEd0iqagqUgs1EcI+sgqyt8Y98bVyAREfZWBSRrQLAnuiOtoEE31kMb8xqqm9sqkJsgigickesNE1wMTsWnS9dx3Ldp9Gw573sIn4F+fSsu87rD94F9uYkrStXTGiuAgD8guhZemCTSdvoP7NT7HuHLD8NN9/nGlHnAorpu0MdQlfk8r4LVRF/KLGcSTk/fI4d69MR/gJa+ha1h/5GC8ePE8XZIbUYFc1eJsfbqT6qvLo7oZTqI8ZlIgevObnl2/DhuPXlDtrp/AV7SSaSFJeK39P/T5Dk4o0obmWP6RGAU23vlFg+ZWhSUnSRaD19Xc/3wPMYc3i7l+oKSTUtlqyhPwrBRQBzPfdgGGaemnNSrj07YvRUXJMsDdGR3oi3lUPhSOi8c1XHyovJUciqE2S797GhIRwNeNuUdUQTB0TAeu+Wvjp5+v44pvraq9c2ZEA1Ea4/THmTyuAt64WSumsJgToKsCI8BWGkZQknXmyploFRbCARsDRDZjqkD6oCdVV/TOlAhamqUKZvsn/y/SHikiZYmmCAj9xUxZMX/bIiyLTJFpjTLw77M2d8NizK/DSyQ+xZM9ZitIbaipA8xFW/IFfsfHQ19h24LLqpBtXUYTokcNgG5vOtEVW2X8Xy1nQS8kYbWJnGQoQJ5mKWAmqX0NVkmgYTQhQJDrIMPIoPavSQysOa83hT/Dy0XdgZeeoJpSNi7JFEdlQdqwooMMbFWyOsf1j0auvPp7p2ErrT4dG6686CxVgGKKhCAS5BmG6fwXLn7SUep8GRBrAaPpiNIChS5J9SZIImCNkGNldUh2QIAzDR0lHPxAu3+IuASMr6DTbbYFiuGPePPiammJoSCDGRAVhZLgn/E20sKn1GZWKZKPBr8lYd+9+w7TzFUbHh6MiIxRzygbh/uxE2BloKf8lolp2TPhFrPodahla+CvHdsKFGkIYSWbmqZ5fgkTYpUoY5Q+AkU6sbsBIn4wGMHRGFLky9lQaxTT0J8DUxOqpqZV5FNcV4ebUSibIiSCAkmyQ6G2CiKA4vPD6OazcdRZL9jMtXfoRjUwz9Qd+Ut32W+l0XqYY1bV3Rt6UajhEhmFY7f3Y/g7BQPZZcoSOqFN6WDVgaemi02CqaaaW+U8AI58R6y2Ttlcf+hivHHsPbl6+BAw1Yrg1SphCC0LJjtIPQz0zMi0SOvpGeGrJRlr6a9Ramr4fEb7dgJG0JL8lv/uPAPPtdz8gOTEJnYcOahZ9C2B+0uybJnpGhK5sTyqHw8iecD/LduRkjcfq6hBqa4sMXy9kUfgOCnSFO1nh6vl9tNyaHQtu8bsFkLIJYVb/ZJT0C8FTRf0xKy8FDkZauPvdNfLX9/j0aznbh2bqxnW+V1LYNTKSN4YGmGNMgL7SMdK3UhTEtEL3I9MbZG8YBRiGpKZuwEhn3v8GmLoEfRRQCxXIWu0oc2SSxbIjTZCfbAtParDsrDK8eewalr55Hh2dV7Di4g9oILU3HPoRq5lGdpz6DrvPXkcAG1rh9MlqQd5D7euw4xIBceA2mg9+g9ajP7LSyTIMYRlxRwKY7krSVNRfA6aDKawbMGuOfoqXu96Hb1Ao4gNdMDqCtjrWFHnUYsIwY0ItMTQpFAYm5ni8eR1eOPUFtc8d1a+jnBqB0w2Y7t7bfwQY2e0oOSmBgNlPm8t0I4D5WTbb45+//Kr2qpUdS76hppG9a3+l3pDR5/xhwxDj4oR+3h7ISY5FsrsNwm318PON94m3W7jJipe+HAn5vrr8TIyP88TjBMz0ewzz3kdnCZif8ck3coIYv1Z2sP6ZafG769je/jwCTemWomxQFmdJrUGXRGYpJMt0A0YmUnUDRvpg/lPATEmWBXAUxGF6BI81soP11NTLkv5ucOR1PTe3BZv3fYDVR69g9blbaJC5sOdJ5az0Nad/wTaK0Zc638OEskpMKC9BD3s7tO8+ihffY8EevovFTCnCMEtZ4O0MYQxhGKmcP+qYvwOMgEwAIwv6pL9nx5F3ERgWRafphHG01UUxZsgJ1ABmHBlnSHwQzC2s1Ky+7advYM2J/18B8w0BE4fOw/s0gCEofvnpZ+oLAYtsDUg18usvanekH+UwBXWuz49IC/ZHqo87+vt7qOmDYTb6yB8YR71ylXgiYL69o8By64ef1Pali556SE13nF09HA8V9oO3tRad2U71HtmNXB7lnGYRyb/euYavr55DAFu7bIw4UVYYBlCjRLNiWdGq+19AI4AhcLoB092R9y+AYcoqIWiKqWWU6CVgauP4urgrWvWqeFO1eXRFuguqhvnDRdLqjv1of/kcNp65jVUXvsWcIzfQSucihbnmzPd4gTphzoqtqH34YcQPGQjn2DhsPvkutryrmX/S1ind8r/8BhjFMgIO6of/BDCa+FG5khdO38YLB99CUFQswrzs1L5/AhgpD9Eycr7CoFg/2Nra48G57dhOhpFBwv/fUtIfASMb6ok7kr3UhF00YGGqYKjttOQ0MQWYbxFgZ4LBcgB5mCcyk4LVTLrFT03jGz/BnTuf4frtG/iKgPv09h21t9trW1YiwU0X8+pG4JnygYh07YMXt61Q/T7Xv6WsJkh/+Ol7XLv6PlMir+PrTzE+NQjJrjoYH2KAXDJMVayRmkClmcvb+zfAyHCADAtI34x01FXxf7If3t8BppyPFWSbMtnXlwwlc0wmDfPB1AmxCHKzwJtH30b7znex7uzXdDhfo+HMjypkPsnqU3fw4qlPMKZ8KipnzYKtrw9GVNRgyyky0umbWHlWuvsJFopeqXhhFwFMt+DsriRNRf01YARo0oknDCOA2bz/IsLjUhDobosxsQRMnBWyg3hvsWSaeAd1Cp490+KMpxsJZs041v9volcAk8SUdOTwfmpd2ciGYGGoNMRWz6rTgOYXqVABDF/98Q5cqEFGxflgJNPM6EQf2NH17NnWQZa6hm/vXlf7wkma+fyujEr9hPPH3kSQhRaeKk7BY/kJiHDQwvIlz1O7fE+98w2ZSLO/3JXL0n/zPW59+j6enFaMSPueyIlluogzQ2UcdUaAhmEkZCK4YhgKQOmb+WvAaEDzR8BU8PnkpF6ojJFZaz2RF2uI+ydE4NGygUiN9sfukx9g7ZFrqmezsfMulvGSZh+9o2bbrzz5Od68eA0ByRnIr61FL3NzTJvbgPXH38Pig5ehti05Cyyj1mkVsUu2+aNL+qOO+TvAiCVvOfqtGobYePJLbDxwEdEpGfB3tcaoaCeUMn1KA5JdzvMSnTAgyguODnaY+tg8bDryIVZ23fxtWEIAI2zVeoqaiNpIGO4fAeab775FWno/7DuwX6UEscJf/fStGkeSqhbA3BXAMEUJA8i2pTcvn4MzATM0xhmDIu0wRJalkMo/PL+bgJHx7K/VAZsyon3jm68IBMLi1gcqxTySE436usEYGmqOp+6vULsxCXt9duc2f/knfPHlZ7j79S38+N1t7N6xGn5WWhjoS0udZIecYG0Ny4QRLBL3ACPaRux2LYFRRytdy1RTwf+rnTb5t0QhgSJTNgsZso+vnEVQGUsAxcrpbQ54rmogqsfEYkZdCfaeuYzGV95Rg4LLZaXgW8CcwzJxmq7l1BVs6TwLQ2dXRGdkwMzVA1sOn1VLe+Vw0wZZjqpGijWVr8DC6E4Hf4y/A4wATTSMjF3JQrQdxy5j6IRcOJjrqaMLxwTqojrJEsPpICsG+GBgtDfMTA1RM+sJvHDkA6yjhmkjwJcc/QrLyYwrZTooU1JTJ5nmnzLMbaaDhNR0vLFnP7767kdVeSJEb7PaJWS/t1s/awYkRcPIdIUPzx2AEwEzMNoWA6KtMCDWAdZMSZ9dPsZ09QVZ6ht898PX+Irv/+wuUxLd1bd3PoCXsRYezo5UgBlDMftAVTa/ncAkc12nVZdjf+98T0DyM8I2H717Eh6iYyJtUETASKuSXTO7U5F6ZGgAo01LLaHptJN5NGplQaTOPTel6cCridfC1BQNaGoTKYAHGeGhiQF4pmYQysfEY3H9XOw99zGW7fsYq07/qMTqknPAgqN3sZSAWNn5NhZueAFmbq5IHjIElh7+avfP1Uc/YuXcYeHe/ceAkZB+mJUUrauOfIYXj1/BqOwSBZhxiZ7ICjdGebwFRvv0REWGNwZHe8HMWA+19z2GFw6/h9VdX6Kji9dBwC07/QOWMUUKYLqF9z8CjIjS+P6D1f4p9CgqbrC6PuejcMUnNE2fULZ88Q31DC2ypK09r6yBIyu/P8EyKI6gSXKGNR3N13c/4Cfu4ofvZf986fbj5wiGr375hnb8c7jLHNnMMDRMGobsRFcUjc6gff8B1766q4SvAFWY7RptNn9W7ZtrRyCOkd7NRDs1spxPQStnJv0xBDDCKNLDqxlj6klR25NimA4qqq8GXOE9FVjuH9AbT4zUwf0DtTBzcC88nmWPOdUJeLQ8AxMygtX2JHvOXqY7uamORZYpiq3Sjd71LVafvYFVR8+gYNZMuIUGID5jAPyi0pgy3sGOi7KC8o6aV9JON/JPACN2XAGGDLf62A3sOH4VE0pqYG9hgLFJ3siPt1UOSSaEl6Z5YFgMGcaQrDP9QWw+9A6WM52K6F1BwHfQLalBzf9Xovcm2SMiYxg2vnkYH331s9oM8CoF72Xa6o9IKB8SLB8xL318B7h5h7rm66/QNP8ROLPl96e2GJbmhkHpXnB11SVIbuC7X+7i85sUvExht1jpskPlDVb/j7gDPwdqjFEhmFs9FHlpAUgI9sL1G1/gxHuXce7aTVy4/gXeu32LcQdf/sg09tPXsCaTySbKeQSMnJtUEm1IttAApTRClwKWcQ8wAhQ1ev0HwMh71F6+IRrd8tgIA8zPNcGCAhM8M9EYs0vcMX9yEqbnxiMxwA779+3Cmyfep4ilQzom52jTHsuee4fvYN35z7Hh+GkEpyciYVAK3PwCkVU6DZsOfIgXLwrlf4mmU5rpC/8UMJKSVp76AWuO38S2rsvIr5kBG1N9jE7wJts6ICuwj3J3RcnOGBHnDWsTPZTWTMe2w5fQcZDCl8yy5vyvSsMsPiITwH9QGkZ+9x8B5nOCwithEOaveRGvn/4Ab5y/jM1dZ7H5+EVslZHarqvYcegqXtr/PnbuPc8CPYLKoonwdtDDgEQ3DM3wQf/0QIRHeeLz29fw7sdXcf7DT3Dpxrc4feN7nP/qR5y6cR2X73yKyFAbTOjvg8fLh6JgSAzszIxx8sIlbD90Gq+dZ6GfvYg3Ll7Cwfev4PgHH+GdD96GD11LaqAFCvu5YrC7FkpjqGEoaBWz3AOM2qbsHmAqZIZehACmB1OSjgKMbC+fG6iFSYk98dQYI9QXmmHFFGc0VTlgfqUnZtfEYFJmFHxtdbFv7268Spe0sfMa9cOPWNYJFjxQv+8LbL7wGdYeOgJ9BzOMyx+PXvpGmL9kE7YxbWwgsyw6chNNFL3/FDAS4mxk9p0ARnRJ+fSHYW7Ul+DwVGdwjw/ojYkheshPcMDoeF84WxljQk4RXjn2AZYf/FQBZrWsbCRgmg9/rQDTTsH7jzXMNQpa1/jBeKJjC9Yfuoj1R97BxmPvYvOJj7D15HXS4S282Hkbrx66jt0HPsKhA2eQFheDUG97DE72R/8UH9ryAAwdPRDH37qA146cxIFzH2Hf29fYGj/E1otXsenkWbxx7gT6D4mmC3HCY3WZqMsbBX1dA+zqvIC1+85i0+krWHfqHaw/cQFbjp3Di4e7sPvIQaQkhCDBzwyF6R4Y7EGxGqZZKivaRc2si9RDFRlHNIz0vwho5Pg+tXSWolh2WRCGEXclDPPsOBM0FZlizQxXLJnkiIXVnni6PBy1WXLafg/e30G8fEi2K7uKVQdZ6LJJo6SkvV9gy4WP8dy6lehhShFdXYAefQyw/c3Taqb+CmqcBuqG1gt0Iv8QMGpIgWlEOt/WnvgSmw9/iEkPPQ0TfR0Mj/VSrjE7VFfNTMyNI/Mm+sPH2QbJ6ZQWJy9T93yuPiuz+QQw4rhkmoU4tX/skkSruCWPwpMrX8HGrg/p+z/G2q6PsI5+fuOxL/ECC2LbwW/xyv6vsOfANRw5dAkuti6IDfGldglGEm8gNjYQddMnKx20/o2jePPMx6qvomnPRV70ZXTQVazcv4e0mo0AP0s8OrUQ99WWoI+uCbbuP4fVR94n3X+BdW99Siv7LjZ0nseWA0fx2v59GDo4CeHuBsiMt8dE5u3ckD7UMX2UQ+oGTHWkrhrJrpHpnNQxtTEUuUxNaqOhSAOykR6KyTzTUvtgdqYp2ios0VFrg/oKCyyo9cTDRYGoHBem9NKJY8fx0sFz2HDwCtYc+h4rZUL2IaCdLmnb+SvImj4Jll5WqJxSAnevQLy+7228cfZ7LDv0FeqPfasclQDknwCmg68JYETDrGdqFKs886l5MDbQUYd2yAn/JXEWGOXdQwOYJF+EeDvBy58aTNaMH/9S2eq2LlprahkR4Zp5OT+rUfN/BBg5wdk5YTgeXPqSUvrrTl2j0JIQgfcVC+1rbDjwLbYfuItdZJkuvse4twFSwoIxMC4Y8aGeiImNwLOLGrBt/2ms2X0er7x1C5vO3UT9QV78e3ew9u2raDtwAJOfeQCOHhaYUpePaZPLodVLF6teOYQVB9/F6tOfY83bN5lvL2Hr+Y/VJn5vdHVhwMAUeNn2wWDa8KoBrmqWfx7ttbCGpBwZeRbAyFxdmeQtorc2VpdgEevci85IXy36Ko/sifvStbEg2wQrJ9ujqcwIz+UbEjBemJkfiPzhITDVJWBOX2AKPo8NRz/BOtrQZQd/QvNulsOx23jx3AeIHNofoYnBbCBVGDh4PHa8fgE7z1LnHLyDRcfuovn87yD4I1j+DJju1+T/fwZMO9OGpCRJK7I1iQDmwecbfwOMrP+qSXPACE8t5N0DTKS/G6ztnPHGiQ9UZ18Hs0LrkXsz/2TurixpOfYj2sVi/wtIfo/u1zQrMf8GMGKb3VNG46FlL7MlfYg1/LE1Z4jKThYS0dh26Du2sh/wypmfsWXnJby0/SBs+upjQIgfxiaEYWh8OGKj4zC/fR3W7LuIxp3vqv1Ill/8llb0Kpa9cxMrmJaWHDmCafWzYepljekPVqOsKgdWDjZ4trkNr1+4io7D76Lj1HXUH6I9PfExtl/4hHa1C0HREfByNmbudkZRqpOaHVcYoac0jHJBMvD4W6edDA30oK4hoAgeCXUugQwZxGjhkUG9UJ9riKXVZqgv1kdjtT0apjMdZQYiI94NfbS1sP/U29h8jOVw/AvGd7yur5gW2GhOfIZ1B47A0scN4/PGoLyyDA8+PBc7D16l0LyFpQdu4YWrwEKCRubAyrxcNTeXhS7R/bda5yOvM9VJyBybf4l7gGnp/FoxzNrjt7GZjXTOkrUwNdDF0CgfjAkyRyVNQHG0hTqze0ycF5LD/GBmbo0Nr3fi1Qt3KNi/xJJDN9DaSXtNwAhrCGAEOMr2k3FkSYuEWkPN31XXJ6FArQGMZoIVgd0NGHEy7ikjMauDgDlMGj5DKjt6B4splCSXthz9HkvILhu77mDDaxdQv3Ap7HV1keHnjpERvhgaG662x1i+bY/am66t8wssPkUndeYu5hz9GK0Xb2DJ2fexhFR/X3sTejuZomJGCRV9DhzcbHDfk0/ixWMXsKbrfay+QB1wlJbw1OfYdP5TbDx0EgExUfD2sMSQWFd1RHFOlGy7yhSjBh0ZEb3uAUbrt5UE0lGXTyAJYORMAundrYnVwuNDeqApzwDLq8wwL68PFlXY4vnqQJSPC0RMuDNMLS2w88Q7WHOUwvE4dQCB0nrwhlqUtv0sU/T+g2qLk8KKAlTX1KGpZRP2k4k3H7hJJrqNdZcIGOoZzdIMTeHLjLo/A+ZvwXIPMDKvV018IkOsku3GDr2PRcs2o2/Pnhgc4YWxwZZ0i1bIC5EZg7LFmQ9Swv1hZGiGhUs3sXHzmk9olrnImicBjJomyug4TSYTsBz/VnUMLmcaXSbMI7/L6/s9Vf0NYGTdkQDmvrYXsYwVLIvGl7DFyATmJaTkFTJTjPl5Y9dtbN/3LirLpyPAzgbDwnwJGB8MiQlFv9R0bJbltbzQZlq6tjPfYEHXDcY1tF2QHSvf5fdcwHOb1kHLkoK1Lg9VTEu+Ae4oqKrEZtnSnep+3dvfKsCsPEM9QxEsgPGNDEegn73qTR4XbfkfA6aALCNrd7oBUxevhSeH9cLiAiOsqLPEnOw+1DAOeLzYUwEmwNscweFheJUiXADTTueznPe87PBN1T2/jgw4d/VaaOlooXJyBQpKSrH9lS4cOHEba3d9xvT9NZad+x6LTnz1jwHTdPQ7rKAzWyTTQrsIGKb2lVv3qF0j5CBVAUxeqAky/foiL5ICmKZjYFwoTI3NMO3ROWoe8AbVj/SVYinRJk2dmrnFy5iSZDVBN2DkUQAkKek/Asy1HwGP5JGYsXgblT7ztgy4HfkSq84Ku3yLje8AS6lltpAad3ZdRv+MYYjzdsfYuECMivTGoOhAxMfGYeue41jf9QkW7fmIKegnLDz6BVrO3ELHhS/R1EUhe+EDLNn5BrSM+6BkUr4CTHRsEEZkTsBW2upVrJCVbMnNRz+nHbyp9iLZdPgUPEKCEBHkwtTnihGhxmrurQYwf5eStFQaklNPiggm2b5MADMlSQvPjtLB4mITrJ5shzm5Omiqc8XjJT4omxACZwddjMnKwja6wHXHrrKRfEJLfQvrT36DdQT+0p0nMLSwCN68XwFM/6FDsefwO9jJ+1zx+ie01aT907TW/xAwkhoaj3yLde8C83drVlBuPnIFrx48rwAzLi0CYwiY7CBDdUxzbgSZJi0QI5Mj4WjvgLzq6djaSS1KhpRFd8tk1wbZBJGAkZQkY0pqbRSBIgOU/zVgPvkO8EodjamNL2Bl56cKMHKiiIy6LpIZ8ueZc2VROHP6G0fehS+dgazZEbCMjPRAf7JMeHg4Xjp8li3xmjqRZPXbv2DRkS+w/K3vKbIImKPvY9OFy1h78DC0TPVRXJ2D0ooJSE+PQb9BA7CTumHl/ovUTddJodROBIykqK1HzsDe0wPRoe4YleiBEUH6v2mYvweM2OmeKInUUbPxugEzLUULs8fro7XMHCvrbDAvXw9NkzzwZGUQCscEwdxMC9MfeRQb9pzAyiOX2fqYZjrvKLEr82q3dL0NEw83jCwYh8ppVfAJCcN+usoXD5CJdl5jCiUgTpFZ+f5/Cph6Gg0BzIK9rHSyxMajV3Dg3BX07tkLEwfEqv3+ckOMkRNkgNxQC+Qk+mBEYii83ZwxZGwutnV+qEC+ovMGy/Q2UxzdmxKvFPC/aZj/CRh1fRL/DjAffwP4pY/DlEUbWUmfUfR+RbF0XSl06awSSms/cB3bT97A1p3HYGdpi0RfJ5U3x8R4YgCBExjor7YnX3f8U7VF1srzP2DhwS+w6iJb3XE6n8MfUQdcZks5CQMHUmjhGOQXjMTwEakIiw7H/vMfYM3Bd9S2GGvPyZyTL7G28z282HUWJnIyW6grxqWyUP4AmN9F7+/DAmqk+h5gSqP6qvm+BQSRAGZmv56Yl2WC9kobtFVaYF4BHVK1K56uCceY/u7Q6auFxmUrsG7fabTve4/lcJeMewfL9n3GCvsYu2iptYz0ML4sCzUza2Hu6Iw9xy5jx8HrWL33FjaQ6oVh5h/98h8DZhEBs4wNteHgTTV7bvXB93H4rU+go90H4/pFIocGoDBCppYaITvEBBOiXdQOGr6uTgiOSlIbYstUTXG6S7vI8icp3s/yd0/T9dB9SYrqZhkJef4fA+bq178iuH8mpizYQB1xDWt5gbI32hpaxZYjdxRgVh69gVcpaFdsehWm+voYQpAIDcoMuowID/j4eOGNk+9gOR3OYjJLG2m5nqy0TiYdkdY7uj7H+uN0PscvwDU4GOMyh6G4aCRyJg6Bo5sDdp+6qISd6IU1p2Ua5BcKMK+cuABtI31EBTsju78/xoQaIT9Shgb+PWCkz0WOJZboBsz9Gb2xMMccHVW2WFxqgoXFZni21BHPTiHLxdmiBx3S1t0HeI0f8jquqv16l1LMrjrwOTaywtq2voHelobIq8lF+bRK9DAwwutkou0yjZIVvLSThX+ODUXt8vTPACPpQ1YgSkXLHngde97FvrNXoEuzMSw+EPmJbgowsoX+xEADTIxxVuNJgSxLO0c3bD14Qa3vXi87aLKSW49RvDMVCWDk2v4eMATH/waYT+7+irABEzF13npFY5L32o7Idp1kFlpr2VFgDZ3Pa2c/R0P7Guj11MKwKC/kJjMlRTghhZXp5eWB3Wc+VLa8kSzRwkJroLvYSNfQ2vUVVp+kLSXiXzv1PsJSUjFm3GBUMyWVlY6BsZk+XqNWkUpZfugOC/5rrDz2OTZ0XcLrJ87TlfREZIA98gcTaOEmfwMYDWhkk2UBjnTalUfr/AaYUqal+/vroD7PkpbaDk2lpqgvt8FTxQ54fnoi4iIslPvZf+5d7HrnSzXTrv7NK2jf8zm2E/zrd7+FkvsegamrNaY8Uou8qgJo9dbB9v3vYevR21h9+Fs07bvNFCwrBTW2+p8Apk267098S4YGVpPp2na9jV2nP4Q+QTog2o+A8UB+mKnafjY72EABaByFb6SPi7LWG3cdx+auK9hMpl5Gp9REE9PQSR1zUrb60PS1CAAEKN0de78B5h5A/p5h7vyMkIxMzFi4CRuPXWfOJmAO3dSMdhLhQmniErYceR+zHnsO5nq91F75I8NsMCHeXTGMra013jj9vjrYYbEMwBFwq8/zB498hbaub2lNv8RLF75V4xyDxmYiKSUSNZXjMbl2otr2bGfnWQq1j7GRN9O45wZTwWfqzKKVr+yCtr4OBiYHYTRdkpz7KDs7lETKxsr3Bh4jdNRkKTW9QUAjdlqmcYp7itFRgCkM0sKDg/TQUmKPxWXWWFRkgsV1Tniy1BkzSoIQHmIKFz9XvMzr2CYO44zGTi/b+wUOfgAs33EU1l7+iB8Qj9LJ+fCPDUD0oCFYz4pcSxZaz4Jt3H9XMUwbnZIUdjdgFGj+FAIWWWwve8p1h4ClretXtcJg2QU6pCN3VSWtPM0GdOgyXqKGMre2QVyAM/KTvRSz5AfrqjXWhUk0BeGOGM5y1dbWxpyODXiBOmbTyetYcVwO3vgWCw+zLqizGmSt9T8BzCd3fkFovwm4b9FmbCZg1tMNLWWrkemBsq/ZUubktZ2fU0i9j+KKOrhaG2F4pDPGRdlhYoIbBkZ6wcLKElsOnFf7+DcevaU2/hPR3HjwK7SzANr4uI35/aWjH2FcQRkCgz3IMONw3/RC9NHVwsbX92L17nfoTn7C8qPSu3oZL9BZLdm8A9p6vTEwIUABRu1cEGH4J8DI4KOuAk11mLYCTAW1i4ClKk5XddpJSnp0mBGaCZimEmumIxM8XWCC+hmhyB5iA1eX3sgYORBbDp7Bpq5PyTB0FNRvqw7ewmvUdG2bd8PI1h7DswahdlYxnFhpY8ur1Y6Vqw/cUuNNjQfpLs989/8EMB335t/INhsrznxDy34VLx9/D05unmrlQE6CO3LDjNUmkXmhesiPt8fQEDsMTwiCpakRZj27UA0cb2RaWnLwYyyhEBfAtJyR1Yy8NoYaArgHGjUk8C+A0bznLwHz+V0gNG08Zi16AZsJjA388tUyDnH4Dja9BaUrVh/6lAj/EEmpAxHu5YShoQ7IjXdBFq2uHKxgbGKmdqAWoVh/iIA7RWZiSqvf/5Xq7u449D3Z62tsO/wBKmY8DA8ve1RXjsWM6fkwseiD5jWbsez181h15DsFmOWHrijAzF+2FvqGfTFADmig0MuMMNMwTISBGlQsD2f8CTAy806zs6bM2dWkJ5mK+cxYS7RXuaO53BbNNXZ4Mt8UcycHY1Q/Mzi6aGNcSb46gW2t9EWd/h7Ne76gO7qLLbTX89s2o6+pCUprJmLaw6XQszPEIw0t2EbNt+oQxbFUNK9bdhVvO/etpsAJiP8rYGRbs27ArDz7LVbTvb508n0EhkUi2p+NVVYORFugKExPrT2XPYxlBeTgaC/4uDtibGGl2mV8Y9dlNO66pCRCPeWF7Ngg8UfAaOK/AMyNb4HglLEsgG144cg1opI5W/YMOcBcTmpcxvy3nnb3pc4PYO/kruawiHYpTPZAJsWWqHNjEwt0vNilCno+W9zy8xRWBEg9aXqpFMjhH7H2yNdkoY/w+PzF8PR2QHXVONTUjIWVgxGeaGjFWjqT5Ye/Q8veu2S0z6gdLuEpVoqpuREGJfhjAvP0hHBTDcP8ETAMAYyEOl2EqUkmhMshFRKSnqpitfDsBGssqXTFwgILrJjpjYU1LpiR44CckS7wDbTA0JwsvHLmClarDjumpAN3sJGi/yWWydQHZ8PCzgaTpheganoOtIx7Yvlrb6oF+SuOfKvuUbRHM8tuCdPZPwWMLGddwGuQfVlWEIDLZbnsiQ+Q1G8Agt2tlRwoibWCbBiplsxGmWu2Lgt3QWyYD/wi45ni31aDyS173lNdFUvoetVODKe6QfBH0GgGHQU0/ytgbn8PBCaMwuPNL2Lz4c+oru9iA8XRkv231Qa/y4/cxvZTZJtd56CrZ4xEAiY7wZt5kxVIO9c/3JPC1Rqr3zyP1ad+wDyKvxUXZNyCbHPwG1UYS4+ALfEbbNp/GUvWbYOtgymqqkajsnIEPAMcUPPIE9hIel95hPmbsfrIJ+qGpz7+DKyszTA4zg85qV7IotBTO0YRMN1g+SvATIrXV2uthWWEYWrieyjANBY74ZlMfSyb6YV5Nc6YVeiKCUOd4OpljKyaKrx89mMl8FvJkss7v1P6ZM+p2xg8Oh9hEcGorMvEmNx06NsbYXvXKTXJakXnj5BNkWWuSaMMC5wi9f8/AMzCY98o4bv8LNn60MfY0vkuho6dQElgqNhEGKY8SnMyXX6EKbKi7TGAzJ8WFwxd1seWQ+fwwvHLqjNWNmdexmzRfFqze+e/B8zv8ZeAufsT4B83Ak+2vIzNBz/FCye+JgV+y4r7HiuoKVaSyl4+9w3qV7+mABMf6IaifkGYyAucGOeOlABXGJnaYNvRKxRY32GBWMxz0kH0FeNntElhHCZgDn6HzQeuYvMbh6Ddly6mchSqakcjKpn6pLQSaw7Irp2/4gVJg/s/woYDZ5FfMxXWNuZ0Bt7ITfNWG+iUxpj+r4CpjqR7Eu3CKIvQwtRUHSzId0ZHjTcWFFqhqcYRD000wYIH4pEUpQM9Yy081thA/fKBZp/+w3exkhW3hqJ31/Ev4OodjnHjR6KobARiU30Rlh6FHXRwG+hAlvMeuwHTTIfUTBusCpyv/V8AI/NuZZeoRbS7jaykpQRM+yGW25F3kVtaAVtjbbWlvtrsWnbpiqG1plMqSNYI3wGJ4dDS7sv0fw5bTlxW+/FJWhPAtFL0LiQoJC0pt/QnwPwRLBJ/CZhvfgH8Yofj6dZXsenAJ9giOydRe6xnAQhoZJ+1l87cxdQnF8PK0h5Jge7qTIBRAUwPKb5I8HGEvpE1Xj9zU636a2IByj72zWQYmRK4RPZ6PQQ1e00A+eoRWmVtLVRUj0R51TAkD4xE2rgsrKMlX8kC28w0uOrwxxSU5zGuqAL2DtboTxufn+qtls3KJkP/EzAa0HQDpoSuSFZIKnsdqYXp/XRRX+SGFZP90VTuoAAza4Ih5s+KI4X3hrahFuatWE4r/z711jW1rYe6dwJm0xvvoGcfU9TVlaGoZCi85JymB2rwwtFTio06yDDSKJYwpONOtmb/p4CRKQX11C8CGBmf6mB5vND1Hmpm3g8rg56qLGSTAtm2pCrWBGN9eqGsnyfGxLphUHI478eYmvOiGnXffP5L1TcmO0y1vU33xXv7I2C6d536jwHz7a+Ab8wwPNP2GjYe1ABmya6b2HoRKj+vZ8W/ePIGcmoegquzC1JDPVCcEYhBXnoo7R+qtlrX0bXErguk43130C4gUbstMbef5XPZvvPQz1jV+T1T3ufYdeJ96JvooapmAnILMpAyMBzJo0ZRs1zFUmqY9sPfY8vpL/ib72BscQWcXR3QjzppYpofhvjpI0uOviFoNDrmd+AIaCpZgEr8RsqapN4qLVVE9cDkZG08n2WLhjI3PJNjgSXTA/FoiSumFQUgI9UBlo5GeGhRI7af/hit+64osb/0gCwg+wwd6/ZCS0sbDzwwlQwzDrZeFpizsh1rDp0m3X+O9qPfqO3WZf1R+xk6wrMytUEzVeCvgNId/y4lNRz7kQzzvQKM6EEZCN167CPMfPxpWBpR1A8Ow2g/HTWRTAAjy00qMzyRleSOYSkhsLKxxq6TbxHU76jzK+ftuowFnXfQ9i4ZRtLSaQFMN1hk98xv1XO1ddn/BhhZpOYbNxxPtL6CNQevKtG7tutHVjC/cPd16pe7ePXEx4hMHoiIUD8MivFCZqILxkfbKURH+TjDzSMEr8qO19J5xYJoO/yDWi4qP9JGIdxBm7qSdL3x6HW8eOgSgkJjMDAjAVVy9E3hCHiEB+GV0x/SHd3ChtM/qakEba/uRP606dCzNEZMTAAGJvqqzrusOHsUJtoiJ8wAEwP7oJDWsojCL0e2ivfriSrmdOnIk61BimTzQ+qYh4aYoKHUGw1VfniywAXzpsVgVnkkMkf6wyfAEpaujqhfuxXr9r2Nbed4nWco0o+KfvkUmdklCPH3QXlJLvLKi6BtZ4/6HbuwhhW4ousa1lOUynKQRop9scNNrPQ/g6M7BBT/W4h4bmDjaifTzt57A+vfI6C6vqBU+BizW1bAzLivSj2VGe6oTDBXk8lE1+XFWGBUmKWaEB7HenphxyuqM1UOzFr91nd4/siXqOd3LuA11p8hGFgvS1i3rawX2SFTAxoNYP7tBCoBjE/cSDze9pICzIZ7gFl2gP7/MAXvyS/xGnO7Z3AookO8MDzJG6NiCJYoG4yJ80CUryv8g+Px+smb/IzsASfO6hcsZUuRTqHW01+h9YxY7ZtY13UdOw5/iOjY/hg6IB21ZeNRWDAUjj4ueO30u1h9lAV06lu8+Nbn6HhzH0offhwm7q4IVZO0/DAyIxxjkr1p6y0wNtwCE8PNkBtmgrwwY+Qyp2cH6iPTWw5vMEVFjBlKowzUqHVNP2M8ke2B2ZXheKo6ElMLwzH3qXzUTpoAe0879Layw4INr6lRYelzat13Te3L8trBs+jfvz8yEiIJmGyMzs1HT0cfNL5xSq2AVIA5c0dtr9FCsMtO3w1Mwf8pOP4qBDALDlASvC+7Un2PJjJD076P8eo7X6Nj607Y2FjRaLhheIAJqlLsMCnNFmO8mOJTHFCc4oKRUc4YFB+C6dOn48CZ97CJwF7JRvD0getYTPDNo5GpZ4NolvRJM9MuQ0H/FDDr+IbmN2/SBXyv9nfbceACjK1t1ZEv4/r5Y0iIGUZG0t5R9Ib70solD1GAWX7wazorprKjpHQCRna3lhNb1TQHAk/2uX3p6GX0yxitADO5cgKKCofByNaULPY21nV+iTXHqaEIqm1vXcXy3Z1InZgPOz8/1SNsb2OM9PgAdcCmTEuUwhkWbI3MODdUDAxFRUYwxbgrKvoHql09ZWcDmXQ1PTMcT9ekY2ZxPLKH+SAhygpmFlpkLx30z5qAx9rWYu9H36itNV5lRS3ZKz3NX+DlfSfg4+2JnHFDUFddhP6jxsA5LgMdB97GytPXeY+fESw31Rarkpo6mIIbVaX/NRj+oxB7TtMho9Uy2UlGrGUw+JV3vsEL+88hITUDfnSZ0lE3PtgEUzJcMDFIV3XkVaS7sTFZYWRKOAL8fbHupV1K+C49fhPP7GND4L3NI4P/BhgCpePEHYYcw8O/We8qnf63gNlIwVv/2mdMDT/hBQquta8cUqeKJUZ4YnyarwLMaKakIVGuCHC1x8DhOXjl2HXFMAKYlZ1kGZmtJ3MxTtxivrypALPh+A283HkFI8bkIzUhFlOrs1BaNAJ9THSw7cgprO+SKQV3sfTYNbR3foTVFKEr9p3GyyfewQNz6hGWkKiOA+5L0eznaoP+sSHoHxOIOF9nRHrYIdHfFRnhvojwsEa/cA8MjPdDQrAD/Bz1YG+uBStTLTWNYUL2MCzdsAq7zpxVc27ad53G65fpTqjhGvdehex+8CJF/Ct7u6Dbl+ktfxymT6mAb3QMhlXOwKrjV7DqtKxfvoalFL4yb2Y5dVs7773pv0g/fxkEzFqmDjWkIgvQOr/GOuqYtV036EQ/wqwn50FPuwfyBsYhzUVHHSX4wIgADHLSQmminWokw+J8YWrQF+VT78erZ6+i9cinWNh1G03ikk7/rNlYQBbcKcDcVdMc1BQH/rbSWzJF9L8FTONr17D11Dd0Tu9jYft66OhoU3wyHSV6KHaRbScGhFG/2FpgQl6dWpsjQnEVf2QVaVmm/Qlgmk58iSaK5na2RLGhr3R9gvyiKQjy88X02mxUlo2BtnEfrH5tH9aJiDxyB+vf/QXLz32FFadvsDKuUFd8jrX7zmPla4ewdOvruP/J59F/2Bg16dnQyByOTu7w9gmEm7sPbGyd4ODiDnNbWxjLsbxeHhg8cjgeefYZrN2xA68d7sSOQ8d5X6fU/nWbTn2C9edlOOM6Ht7+FgtNk2KkX2jN1tfUYe1lBWMxaVIpeptbYcqCVqw9LdNIZbztBtp4zTJ8soquo4333vIPASO7d2+QPhM50PPYd1h55hc1ia1t/+fYduoG1r1xTI1Ip0YEYWCQI0YHWeDR8VEY5dlTs38vNd7wGHcEuNvBIyAIu9V86StqnEs2FFhEwDSd1ghe2ThRwKKZpimHWRAsvPb/DjCkKNmrvn3/LWzqZFo6+B6mPPAkLM0MVQfasBhHgsUJWckeSA1yhp2ZCSqmPKYA08HPLKcrEnv8R8AIw7SfYko6/iVe6vwYMx+aDXtrK9w/hTqiejz0LfWwcPUmtT2XjFZ3nPlBdYI1svU27r+q+iHWdn6CN969g86Pf8Cb5zT7vm3bdw6bd51C28ZdeLx+NWY+24ZZczvwaNMqdLy8j87tMg69d10dzbf18Nt4ifS8++1bFN8fEbyfUmtRXLPCWygqm8kq8yl0ZXuPpXRzq3dfwBNkNRtL0n5lHqqrC6HVpy/mbn6d+uUztDK9rjrzFVPRF2rsba3MxpcCvyd4/wyE/zQEMFIGwrRqc0Wmh6UnNJsLbb/wA1488SnGFtRBR7svhiWEYUiwHfKiHFARZ4sCpiaZ9pCZwEadHoXeutpsoBew6ugVLDvzNeYcvIWGezpFAKABiwSf/wEwmp0m/gvAqHEU2q71h6/h5SPvY9T4HHg4WmJkEgETbqNcUg5TU0KAIyxNTTDr6SZWxg01PaHj6E9Y0fmLAoycXtp88hYR/aUCjKzi29H1KRpb18NITxcPzSjG5LosWDmZ4qEFTVi1/0OsliWdckrZ2V+w4m2mt7d+oW39kt97XY1iLz9wmanrUzVIuO3kdTVD/s2L3+ANxs63v8ebl76nDvkaWy6S0ehy1hIYMm1jXecN0roMpN7C3BffVaPRMoVDRnKbur5Cy1m6hgs/4rndV1TP6qaDb2PYuEzERQbjoemVKCnJgY6tI9Z3vs1K/QRNR65h7flv0UHdJYCRym0+ytz/Nw7pPw0BzBKyy1pqinUsAwFLA1O9bCEiQy9yjHL92t0ws/NEiI+XmhQ+1McE0zI8kOvdAxP9eiM3yRVjM8Kgq9cbLRu2q3Vm9Qc+VpZfjtuRHl0ZdJTZdiuY+mQrWTmF7f8EGNkqYu6rV7CdlbX+0CfYefwDJCalqc1sZCH48HArTEx0RjbFrwy1W5pb4On6VXjtnGb1X8eRHwgYtpIuGUb/GotP3UYzRW/rqVtq6oQctrB+2y70YR5+ZFYppk7Ogr27BSY9/jRW7qWqZyE1UUAuYDTyZoRtRDyvOfsDL/gO6t/4AIv3UEOQ/eT72vd/hpbdpF26AImG3ZcVKzVRewkLLD/5ldrJQLr7W2VE+cj3WM2Uu5KxitQvJ6TNP/QlGpjL111lhZ39Wp3wKluSyUaEg2j/H5lZicysUXAIjsRrl75Ey5FPsIhCdO1bvM9jX5ERNGwg5wspSv8DAP7bUAv5mZZXHyPLdH3DlEQ9uf8rNXm7mQ1yDVn7FZb1qKLp6KtjiOGJkZgY54kp6Z7quJ9sby21uC2NotjO2ggPz12E9UffxzMvnsfmy2RBxS4EzPEfFbOsoE76M2D+bUqSTYP8EkbjyQ5NP4xsFbFw56d46RKwpZMt+bWjarOagTG+SPczxbgoa2QlOGF0rDvig91hRffUsWUvth6/Tlb6Hm2HmBeP8GJ4EXKcioZhbhPdmrUyGw58gJ0HTkOnT0/UVozFrPvyEBTpibHFZVi1+x28cO5HJfhkLbBcpJzi3kzL2nSI6eLoLTIXK6jrzu8hIpnRQcqWkPMJG5laGikS1WAg83TbSVI67f4KAQoroPHAD4oNFhPYjUe/Uztkykll7Rd/IIjkCL2r2Lr3NExMzVGcMxo5YwcgPSMRGXRsOy5ex4L9l9Ek5yCxxcsyDvn9ZZ0Uvd0FLiHi8f8QApjlnXSKR5nujvD6ZZlrp2bbEdkoupVgeuHMN2h/6Tgc3IIQFeCHMVEeGOujr07onxRngpwYC0S59IW3qyUmPfAQtnR9iBU0HMtkyObe3BdZi/RnwLTeu37pqOsGzP8cGvgLwDTs/lwxjMz3WLnlDboLfQyMcsNgev+JsTZqr1ix1PGh3rBxcFZCbMsJtjgySvuRr9UUhRWydz5VeCOZpfEMWzdDlkys2/8+9h27qDbAyc1Mx6MPFiE00gsj8/LUeZOSMtTELaZEmSKh2bOflU4wqJxLqv6XQx8oDCVkpaDamuv4d7xJ/i5DnTrGnC1WUWa9tUuFMBoOsgXRyclrMpNeTiuTcxBleYyI2S0nP0H9yq0wNjbE5IpcTKvOQ2CINybUTcfOy99i0eFP1XcL+6lpjopZeQ0U+/K9/wQwUplSkaJjxKq3dn6nen8VYFixshOD9FW1vX4BwyZWwdneAYleVmq5ifR0y07nE4L1MTzKDoGeNhgwajS20m3KkT1qJwfe7x8Bo4LfK9NQhOHUcMZ/C5jmAzeYGn7A2r0X0dixFka0sdK7OCbMXO1NMjLUAnKoViwL0c7NEy8evaQmHUt/hJpiyRtcyVypjry9B5glZ2VSFnXEvg9w9MxHcHV1xtAB4Xj84RLEJgYgZcRQvHySope2VvVryE7WDAGHZna7BjSykq97Hmr35B9NaKhWjY+c/k4BQMa01N98XaZGLpEWxGg6LNuhAkvJOHJus9pe/eTXfI/s3PQZttE2T330OdjbWWFqVS4evb8CVrZmeKipHS9/IAeF36TmuTcUwM/KYKUMabQd/X8AGFpb0S1ywKcc5yfWWk4jkdcFNEsIIDkmZ9neDzFn6VYyvD28zLVR0c8H1dHG6tjCUX69UDIkEBGBjrB2dVEj3espC1o6ZUBYmFsDGFn1KIDRLGSTPpj/I2BkIdsaapm1ey7g0WfmwqS3FkZGOKgpkoXx1hgebKYAEx7gAVe/YLx+6mNa4s8IiJsEyvdYxYtZxTQgLbbh9C1aOV7saQHTDazZ+z6Onr+CkJAgpCf748H7cjB4RDy8woKwX85K3PUBb4IiufO2CtEIwjhynK4ApvnIbQpVsokKFqRMbpZKp5vQhLz23b0g4/wGGBYIHZyEpCIZGBXAqN5N2ko5YVVcnQBGjrXJKqlCdEQgKgtG0f7nwtBEFyve2IeVxz9mId7B4rMEqIhzpkwBjGi3DhloZfwTwAgbqp03eU8axtTcp4Q6xkbG6NiI1nZdx8a9FxARmwwH/R4oS/dFZYwJsry0MC5IG0WD/BAf5got3b5qTGnNyRsst+/UBHMBjGgYtVRWGFItMxH3JFMf/g+AkaWyKygq5YJKKmvhaMiLIMUVxlqhIIZuSTGMD3w9nBAUk0pmkIlHnyhAyJyY/wkYOq8zdFD8/6q9H+Dg6Q/URozpyb6YUjsa+UUjoGtpisMUlCv3faTAKguwJOTcIZnuufIcb5JpStKHgESAIQBZfJpBkdYdCjQnWQDUFnKTEgo094DTDR6ZQS+TrWXZRSM1QzMLTT4np9S/ePIykgYMxfDBqQTMCBRlD4KljbHa227J4fdVumukWJZClcV+AhiZ5rCCQJGBRKUDWPn/12gTIMu98FqlIjWNQ6PpZGJaGxl4EzWh9E3VzHhITXmYSCstY0qyAUF+jDFTkgWSozzRy0BfMczyzs+whiL/XwDDspSQXl65dxnB7h7J/q8AIwiWvojNBy4gNaM/ghwNMV52oCZY5EAEeT48wQeuTrboPzILW49+oGbJdQNmJStBmEZSkgCm/sxXbJEiVm9h9b4Pse/EJYwePRJpid6orRyKmkkT1az9N059hHWHP2FKk2ug6KNolc4laRkCFmEMOSlMwKKAIqOup39V0XhG8yivSStUB1UxNIDhtfCzKsgK8h0yv1XeW89WtlCEL1uvAE5c1evnPoaDlzeyJwzFfdXZGDM4FuFRgdh85DRWnbpGwPC+zvL3WLAiRNtlaSs1wEpW9j8FjFSSnDrbTNBoVh/IAVxympvcE1MyRX0ry2cjndKynafRsmYTbIz7YESkgzr3SRb4lSZZItW7D9JjfGBoZUlneklNkVCAEda6B0Slv9SpJ5oTZqVDr4nl818DZtkpGc/5XG0o7OLqjkQ/WupQcxRGm2pGiWMcVPez5HjZSmvjoXex6fRNlUpkM2JR+TKZSkZDFcMQLM3nCJjjt7H6wEfYe/ISKirKEBvhhKm1I1E7OZvU2QtrXutUx8q0H7nOXH1HTSaXiViy9alYbBnubyRYpBXIEL0mKGIZ9fce5X+Kxv8FMPf0jJzXLJ2C/FtSymJWegMrZRG1QQMrS456EZe1bu959NI3RGVRJmbV5ShqL63IV2u9N1ykY6M+aqSN1oCTBU/QCGCWUx+13tMwfwWG/ySkkhppoeV+xNKqnaPIAGq8hw1IwCL9UpJi1h5iqnlpJ4z7apFRnJTYlQ2XihPM0T9AH/3j/BRgXjz+EZYdvaYRvbxfYVspFwUWsqWYk5bT3xAs36thg38LGNlW1S9h5D3AXFar5VafZZ489DG27j8DPV0dDAp2wthAExRGmiA7xBAT450xJN4fNnbWqHtsNtYdeAfbzlPsnritrK6sGJT1TAowp+5gEVNTk0wE4k2vPHQVe858iBmzHlCL7KdPzUVlbR606ZoWrnlF7cuy/OgNFg5tMsEntriJ2kUAo+ZwyFKJe2CpZ1r4l7gHGElZonPkJjWA0YRMqpZ5sk0ioPl+mY6gtvAiuzSzwtXUhEM3MH/1dmj10sK0ScWoKRsPR3sjzG6Yj63H3sL6s1+gneUjW8lLB6PoDBGoMjtxKbXR4kP8XWEZVv7/JRRgBPzUWIr1mCqlooUFNOxCDScbN8tA6TkajS2voI+cWxXvrgCTFdATudEmGB1tq1Zb6Bob49WTTPOdn6N+D0Ejuk+ZBDENko7kJNm/YxjRNAIYMhIbmQLMrV8Ar/iheGb5q0wHV7BKKuz453j54m2154upbh91wuoEfxPmRyPkR1ggJ8UPaTEB0NLpi4XrXsaqQx8oBG+68BNWERSyCY7smC2Tf2Ru6mwqfaFw6VGVRWqvnbqM5xtbYWFliuq6UmQW5sGYTPbokvV4gZS/qlOY6jvqINpz3sSy07Ix4c9YeuFXdMg4C91Js1Q2n7deZMu8wNekp5XRIq+flvTzu/DVAIdagJUrIXu+Sf+GdN5t5HesYEtu2EN3uPe2Wpv14PPPw8pOF9NnVqCirgi6Fkbo2LodGw/LyoYPCYzPCWiZ+6NZn9xOBpSQjjb5LhlA/GNn3H8TCjgEjWIcqSyCRrkkXr8wQxvvSZYTN715Ca+f/RSFVZNgrqul1ogVRBhDjnAeQ+Bk9/NGfLDMVXLHjoNn1Xb3rXuZ7lke4pBEw3Q/dn+3SrH3wKIA84e/fwPM7V81gHl6+csKMGuOfozVxz/F1tNXcd9jz8JCpweyotxRStE7wYvgCbNAtuyAGeUHLSNTNG7brbY3k1HbdaR72SKjZc9HFILXFEDq+YMLSbGLpNUwVS168z28dOoK2jbsgJW9EyZNm4qyyVPhGhaLWU0ryECX1JH97WqYga7lyNdYzMdm2nVhhiaCSKYvLjr1PRnlByzijc4/9h3mkYHkUebCNjGlyvqgZedZeQKuzm/RQGEqe91I17v09G6SVYUnCeLdN9Cy+yY2UdO89A7w0tkbmFiai7gkb8x6bDLGFoynvuqtlu2+/tanqnHIZkOy5lnsreg9sfqyifJSGZchu3UDRjry/i+Paot3NWtPAMMKU5ZX09JF/ApQm994F3svfq4OrYjyccQgf3M1+CgHq8qS4olpPkggYNzdXbFj7wls7byCZfs+xRoCRmy0lIOE2GnVHSHpTxhFAUQc0x8BRFAJYE58qQGMd8IwPLXsJQWYdV2fYu3Jz7Cp6z2MlN2njXUwIcIFk1LcMM6jlwJMTj96/CA36NnYo+21w2oaoPSxyPG3suOB7Diw+V3qg6NMJQIUMsBCUuyaS1DvW73nPDa9vh+mVrbILy7BmNx8WHgGoPjBZ7Hm0HvKoYnlWyqCjzlXUSgrovUc0wAZQUAiUc/XFpFiRYfIEgoRi7IpoeiU5hMEGFOZpKHlZB0ZBljFxxW8jiWHWOD7pe/kW17rz3R1BNIR6Xb/DjvfuYvAmDBWhBPG543ChJJcGLi4YnvnBbS9QQ1zUrOjgoxDyfUpxqKGkSP7lPtgiuueJiCV/396/A0wAhYKX2GZe5Wq3NKR21hx8GO8fPwD9NTRx5DEMAz205w0W5dkhbEhRshK9UZiiAu8PHnte7oUYFayIa4VxmbZdrPLHxmmm1n+LWDkjGoBzJNLX8S6Ix9h04lr2HjyY7zQeRH+IeEIdbdDTowbahKdkUshlRNuieyMIPh62sLayxcrdh/H1vNfUvB9Qcq6o851lscX3gfm7LuF+bSbzx/9BY/uuo2VbNXtBz+D7J0vy2PNrO2QW1iAgooqeIRGY0L1TOw4eVWNEcmWo9LLK+JV5oQ0sAXLLpWy8aBomcVMU91OR4ScEnPULzI21EEb3sbrUDmfDNDdIyxs1XLwDraQSVr23cSiNz5Vy2hWHL2Fxjc+RPObl/n7H8PUwQrjMgegvLYYacMHwy+xHw59eAMbOj/i+/kZ6rPf9lRhCxX9I9F9AKhU+j8JDWC6uwD+AjCHb2KLTEp76TB69NFDv0g/5CZ6IC/EADUJFgowmUnuSI/wQFCgL17ae1zt9buGZmI1y/XvAKN+738DjJwn4J04BE907FCA2XrmOvP4B1jx+gGYW1pgQKQvChLckBtshPIoS2SFmSMzPQCuzubwionDqgOnsfm8dNgxqLY3XGAK2vkJ1hMc9bSbrWzZIkYf3/kFtcgPKve+SPbaSccha4VzcibivgcfQGLGQAwan4cdnZoT6EULyfdJX4yMITUfvoHGw1+gnoUlHWwi1NQsMQJCdploOig91Dex+OBNNB2g0xImO635jo4jN8kmX6oBvRfojlZ10q3xtWX7r2H5/k+wnYJ93xWmowtfY8XO43DycEF1TR4qqkvgGx6GsaW1aoqE7IggpqDtMNMu05sc6tnMCm4ma0k08rlM0fyj6/m/RDdgVKqg4/sNMKw4AYxseCjnS85f9QoMTC0Q4+eIkgxfFIcbqhN4J4QaIjPRDYNifREVGYpXDhzHi8euqklYGrD/3lPe3Vv+HwNGXJIA5rG2LQowL53/gi3pbTw4vxHGRroYHh+AwgRXjPfsjfJogiXUDGNTfODgYIK44SOw9uh5rD/9OXP6l6pyNl2k6zhwQwFGelOXiSilhpG1vRsu/Ih1nR/j1a53sPvQMYSGBmP4kP6oKClEdHSkOvPgyAW24jfPY+m+D1VnoNqC5MQNjY2UecGnxVJ+yUcKVIrrzffihVNfq/XbO87JnOCv1OZGqw5Jq7qKLfy8rFLccJjssOsStnR+hlfOfIlXz9yA7IG7bi/dz74LWMGU07r5FZiZ0wmOH4zMCaPhGxyMuUtWYi2BJMMa8lsyMCjbuS0mOAQwi9kgmhj1fL7o3mt/BYT/NBRgpJKkIgUwTH2qQhnSJ7PsmKSkjzBn+XboGpqoo/3EuZZHm2Kirxayw00wMcEFwxMDkRgXiZf3H8N2tZXuF8rF/k/A/A6abrD8LWDkPACfpKF4tPUFBZhX3voC20+8jYxx4+BkZ4ohEW4ojnNCXpAe8qm+M+mShsV7wsHJHCNKylkx71FIfYZVp2Wa4i3IAVRq9Ja0JwNli5gC6g99xRb5perO3nT4Eg6dew+dJ04iZ8IYDE6JRnnuWAxKiUVSbCSOHj+FTTuPYtP+89h+9F3sOP4+dhz7UA2gyWKujUfewY4TV7Dt2EdqR4kXDryLLXvewda97+LlQx/idebq5S8exMJV2/FYw0o8tGApnmhYg0cWrEDdo4uQN+lxFEx+DBPKZ2LQhBKEpw6FW3A0bL0C4OgfBL+QIGVTH51RiZmTKtU5RPVLVmHnsUs4cIn2ec9VtbJhJZ2MiFSZNLVY+ivYOJr42EAdolhHXvs/hAYw0u/RDZjf+5MkBDBtTC3S8J5p34g+evoYHOevVj7KWmvZirYwylytfR+R4I+E6FBse+MANtNMCGBk7x9NZ52mh1exNMEg363pfvivAPMBXrv4BXaevwQXP1+EUH0PDLRBaawD6hJsMd6nN3Ji7TEw2h0OzlbInnYftp67yryoAYx0/cv0AxFW0oG37vyvamOiTRd/xovv/oT1h+kwdnZi/7HTePWVHcgeNRBJbB2P1BVicsEYhLjZ4tnHHkABgZhTXq1ifGEphozPQfzA4QihlvCLTkRQfD+migQ4egXDxNoVffWs0UfbHLo6ltDTs4KFtQO8AgIQnZCMmMQUhITHIDQiFmkZg6lNcjFu/ETU1E7CrFmz8Pjjj2L1qqXYu/c1dHQ0oDB3FNyt+mDhY9NQmTMWxrq6eOSRZ9CyYge27buEDQfIkDKSf54CmuBo6aJ7EeCwosUO/xUI/pv4HTAagPxPwHyLlgOf4pW37+LBRcugb2yCYYlBKErxQKaPFmakWasjD/PIOGrJSXggNrz4pmJQ2fdOJnz9JWAYv/VX/TvAyOEU7rH98cyKl9Talx2nLrOFvg5bF1ukx/hhcJANyuOI3hBDZPnrIjvGASmhTrC0M8es+sW8iA+w9uxNrD57F3Ig1XJaaZktJkPwslyj+U3mfqaPmrlroOcaCm0Le/TQ7g17ayPosyX3C3HGM1PyMLFfKKKcjZEW4oZRAxIxuaYYD90/SS3vkHj+mYexrL0JrYsXYnlbEzqaF2Lj8qXo3P0mrp47j0/fuojLJ0/j/ZPH8PHFk3jn1AGc79qLd08fxrVL53Dzo7fx6Ttn8N4p+fssPnnnBD46ewjvn96LKxcO8vU3sWt7G9rnzlCny4XaGSCKADbntUZRkAcEJyEsaTweWrSNwvgbdOy9jqdeuIT1BM4aui9xYrKWXEaUpdL/Cgzd0X3Iefeh4xKa86Ep4pV2kdQjQwKaYQHpe1EVKp1sNBTrz32D1UylzyxZBz0jQ4xOC0Nhiity/HuiOKgnsgK0UZTogoGhzkiNCcXshlbF0jL7UHSdpndX02H3r6EBjRpUpQNVQy/3ACPXIAeoa90SW504mIDZoWZmyUDV042LYW1jolS22LWyGGuUyu5PoSaK6sSumdlYUCivpY74hMi7Trsqg4sUk4JEOo/2/Z+r6Z5i/0QsTpm7DFoWjug3fKRa2G5vqYtxA6MR52OB4ZGuGBBgDUsC6NdPzuDCga24cHAHPjy9C9cvHWWF7sfZQztwav92vHN8J87s244PT+7GjXeO4fa7J3DrfCdunTuKO+eP4+7FYzi8vR1vbqzHjuWzsWnJk1hX/yiWPj8TjY/WYM7MYswsHI5HKsfiobIRqBgdhzGJnsgIsUSMex8EW2vBx0ALHn214G2sDWNek4mOAeztfODunwbPqLFY/tp7eONdYBstvFjy51++Apn0Jc5J0rD0HmsGQwUU//5R05uqGQbQAEbTjSAtXzOG9N1vLKAmgx2T/qnraN99EffPWQId3b4YnxGJ8ZEWUHvmhPdGtr+2OiR+WIQLkiKD8OTcBmw5dFEBZsUp1s2/BQx/65RsXfKj2rFKQo3f8bd/c0n+zONPLduGVQfepk54G0V1ddQvxhgS5YnhfmZ0R1aoirRESaQ1suM9kBjqCRM7Wyzc/BpeuPAlWg5/prr9Ww5RjJ75STGMTJd8ndZajsWV+SVzqSn84tNw4uJb6DpxGC2NzyGDKt6IFWLdQ0ulvqrhsdja8DBWPD+JFZuNWSWDcF/RADxUMQwzCvsjb3AoBkbYY0Ssqxo7SXQzhJeeFpz4He49GXy0ZcQ690ailw7SA+RcSiu+10GdZCbTSvMHBGPqxDRMyUrFtOxUPFk9AqvnTsb+TXPRuaMe+9bPxuddr+DKoVdx99IZ4MsbePfUBbx1/gpWbdqLwIQsbD1Md7X7YzS/TlF9nAXZRXfFFCwTqrd+IKlJKF1apqaz7c+PaiT6lDz/19eFXbpnGkqXvczmkxQkz7sHHtuO3cLqU7fYuD9E3WNzYWhsgImDojHMTw+VMYYoC+mB3IDeajvWcUxJCWG+uP/Rp7F21wkC5hMskxUcJ+/w9wU0mhAAdYNIACMsIyCR+b8SMpLfIn1sx29qNIwA5rG2zWrr0x3HLyF92FAEedljXLxmE+GKSBtURzE3UlhNiHZTM+2s3TzQ/nonNr9Fy3uQ7uP098rWrj7F1nHkK2VjN8tmOHQpHW+exmMtq+EeFYdzVz7EvqN7cfb8EXzy4RlcvnAIDU9MhrepFlK8zZHqbYK8/n54oDgds6cyBZQPxvT8NDwxaRRanqrE6oUzsHrBdGxsegCvdjyDrm1LWMEv49cPu/DrB524c24nLh1cg/ePbsDl4y/g6sntjBfx6enX8MWF3WSkA/jy7X24dekAbl7ci6unXsGHXVvx0fHtuHJiGz7q2oFbZ/fj0p6XcPr1F3Hz/fdx8uAJXDj/MZau3QV9hzjsufgTtp/6BisP3UTzrk9p229hq3RKUr/N2/WJZl/cY9/9bXRrhL8KqazusSM1Us/4I2A0I9V3lZvNqr5PjedlZkRgZJA+KmP11UYERUE6anfN3CQ/JIX6onLyTKx6o0uzy+mJL8ggfw+Y7rQk1yLs0g2Y3xhGAOObPBgPt2xQDPPa2cvwCfBX83Wzkqi+Q21QGW6NyjBSXrQjRoc7IzrIGwEUn6v3nVP72i2RXaqYw+WQb+l2lpliajHWkRtYd/Im1hx9D/c3LkdfZ0/kTJ6Evae6cP6DC9h/6A18/tm7uHH1PIanhmJr+xxW2hu4fOpVvHN0C94+wgo/9zq+/OAgbl0+jJsfHlLxKSv68tmduHpmJz67sAefnd6Ny12v4crRVwmMnbj90WF88dF+XHt/H7XKHlx5azc+Or8bH57dgw/O7MWx3Vtw6sCLuNj1Bt47s4fa5ijffxI3PjyO6+924esPqHneOo3z+/fi8w+u4OSxt7Dv4EXMbt4Gr7hs7CE4Wt74CKu67mIbn2+8CDxPtnlix9vY9B7/x8qVeTt/F1Ihfx+aaQxq8JWsLSG7kkqIfmk9RmNx9FPsOPsZUkbn0K3aqgMrsmOtUB2jj4oQLZTTLWUHGSOf9ZcW4Y8JOQVY8yYBQ4267OR1AuYWASOg4fcxNMtlu5fMEpw0LaJh/ix6lYbR9MMMxCOt6xXDvHTsHRibmqBfuBfGxXghK9gaFaT1siAZq3DEqDAXBHm4qU62jZ0fqA47uTk5hKrtCAvjyPdYRvCseQdYsPcaC/Nb7P6YaerIWxhePQXDyiugpaMNt8hQLF7dgXVb1mLdug6MHZ6Glc2zWan78dG5vazsIyrePv06Th3ZhrPHX8I753bhHVb8Zx+dwNtnduNs16uqwi+fP6jE6+UzBMmlLpwmSxw6sBE7X1+JF6lnNm9oxtpV9VjaOh9LmmajfsEzePShaaiuyEdZ8UQlqrMzRyAxLhQejuYIcrZDsKM9zHV0YWpgDmMjJxhZBcLIORH67hmY98J5tSXrm58Biyh+JWSL2VUXf+W93+tlpkhUYvUvHqW1ypHGv2mGe4/yf/lsN2BkOoNEN1hkrzrpkJQ13a9evIGBE0vg4uqAQXStcsRhZZQOymXHrXA559tIrSaQLeXTBgzB5gNnsPb41f8BGIm/AoyaN/Qn0buS+kdLDgIVhnlq+RYs3X0OK147jF69emBIbCDGRLghJ5jaIsIOxf4mKIogw4S5w8nKAhUzHsGO09fU2NCKM5qDKJfLGErnj6inzZx79EfMk17XI3wPL3T7W59i2b4uNL30Kun8FHJmzoCuowM1QSyS0lNga2eBxoXPYvZT92PTmsVY3jEXzz41DZPqcjBtegmeeHo6pt9XhrGZAxBF9xYe6U3x7I3oaH9ERfjAy80aRjpa6EU9ZMj0ZmChBSPr3rBwNICTly28gz0QGBGI0OhwxKQmqbQ7NicPeWUVKKmpQ82M6Zj15BOYPX8edmzYiJc3bsHuV/fglZcPQE6i2/DqWbRvO4PV+z/lvRAoRMs66cU+dFudCyDDEc/v/Qz1R78kIL5WIRX/vz1KBamUQ6CIXlETpZh6usHyG2godiUdyeEfso/xG+/eQun9j6r9c4bGean9/wQwZUxJCjB+BhgV6oChSZEIjohWRLCq8yMK82sKMDJldslpAofxZ8CI6O1mmG7R+xvDfPkLEJg6WInSpa8fR+PaHehFATm2XziVtxsKwh1QF+WIIhncIruMCveBuZ4+HniuiSi/rRS79LXIEo+1x39Syy1k+uOiYz9gG1ugAGbm6jex4I1j2Hz+I7z2/qdYdfg41hzpxJJXX8ecVaswvqoCerYW0KIzCQj3R2C4Lzz9XREeG4xRmSORXTQRw8cNx9AxQ5HJ5/c/8gBmL5yP+pZmzF24SMWq1Wuxe88+HDt1Grs7D2Fn1yG8fvQAXjm0Fy8d2M3Yy+f78fqRI3i98yh27N+PDTt3qnhh335sP3wELx/rxM4TJ7C/6zg2bt2B1/cexfqX9mLP6SvYc+EGXj79BV59+ztsOf89nnvxLdWzXb/3Y6yjpllz8Xva6k9Y6LdUpWpCc7rLnx9lItlSOQSLj8tO3GLcwfKTt9VsP3nsOH5daQ2JZcc1sfTYdZbx50xHH2PJnrew9fi7uO+Z52FsrINRCd40J3qoizdR50YJYCb66tLhWmJkcjQ8fPzx+qn3WO7vQRbhtZ+6wTqi+OWjhKx77+B1q0lavCcBsABaWFDmOku0neD1Hf9cM+POOyYZzy1ZpY6uk3XLRkY9MSDGFYWpfiiM1AAm280IFWzZI0L8odOzL9a9ekSNO3UcvYYN57/D4l0yYHkH2+THDl1ThdckXfF0SZvf/RpbLskI7xW0HDiPbe/KjuNvYfO5t/HqB+9TGB/AtjNHyXAvYuOhN7Hr7AkcoZs6ePYcXmNFvrr/MPZ1ncGhkxf5eA6Hj7+NPYf4v90n8fIbJ/Dqm6fw2p4zrOBzeHXPWbxy4C0C5C28eOAc4zRePnAcrx4+RqB04o2uI3iFgHrp2AFs4m+9euEYdr53Dmu79qL94E6sOroXL5w4im0nj1MnnMGOM+ex8dhZrNh3HE2vHMKCbQewdN8FbJTtwE5SExx4B0t2ncPyw+9gA+9Puhk2nvqccZ1x4y8fZZfQNV2fYMPJL9Tf62WJDi2vbN2/WsarTn1I+/senRfj2CXIpgTrTnyEzWfI1NSYW09cxP6L7+LR556EpXEPtaIjP8ae2sUExb69MDXeQh1ckRfviVHJkTA1s8bKHfvUptXLDhE0XZeZ2i4TPFcI1o8J/M8pLW5p+tGY+lZQd7Z3formQ1fRLDMg5WSUMzIc8ykZ5uef4RMVi4Udq7C36zwKyyphbtoTqWH2tNBuyA60JM1ZY6KrIUWvD9I8HWGob4DlL76BDScu8aY+xIvvfaXQ+5LaHv4yXrl0E+vPyfbr76D10AW0Hj5HEJ3Fol1HMfvVXVh//iIv7BjWnDqGTaywVcd3Y+vbh7Ht4kGq/0N49UQX3ug8jp2M3Z2nsOvwCbyxjxW7pwtv7j2Gl145gFd3HsGuPSex98BZFW/uP4vX95zCq7tP480j7+CNI2/jjcNv8VH+PoFdBMuersPYc/wAXju6C29S7+yiQ3uF0bFnKx5ZtxiPbGjB8y+vxuSO5zB12WzMXDUfD6ypx4NMkQ+uasEDyxbj/o4mPLi0BfO3b8LyA7uw4fhhAusEXnmH4Dx/ggJ/PxvSWWw5c45x4S8ft59/G1vPEognzrDc2FD2HWIcoOvqpE1nuZzuxMrTh7Hq5BGmH81rG8h8m0+ewrbTJ7B6zxvYe74TC5qehY+rEYZFOGGUrwnyfQ1RHmCAumgTlESZoTDZC6k0L/r6+li9YycOfvAF1h27iA1nLvG7L2A5G8LKE+ex7syHNC+f8rc+x/Kuq1h3lnHuI6w5dwWrzl4heGUhnJyHfRFa1777CpH9+mF+ewd28uL7Dx0MT1dL9I90R0GKPwFjhZIAS16MKYpj3RFhp4uYWH+s372DreEglrCANrx1Ch2HdmEjW+eqfa+jbe/rWPj6djxNQfvI+qV4aG2rKvQH1jTi/lULMGJWMUbcl49h07MwsGYk+lcOQWpJOgZVDUH0qBh4h/nB09cPvoFB/K14xMcnIiwkFMH+fogMDYKvhys83RzhZGsJcxNd6Pftgb5MZ8bG2rC0MoI2/+4peqaPFnpq8/Fe9JbX+D4D8x5q0rmWLl+z04aupzEMA21gEGiHnr4G0Ark/ygeteg4ejB6hmpBm6ET1hu64drQ8uLn/LXQJ7CHCv0QbRiE66CnNz9jzXC4F/Z/82jJkPdJyGuuWtAN0oZVnAUcMhxhnuoAs1Q+pjjDItkVVkkesE7UhF2iJxzi3DC4cAAGjo4lw2hhVLw7siOdUBfngQdSPVASrKNm3uXEOSEt1BE2NkZYvH4lXjl3ElvOHcf2S6ew4QIBeWo3Vp/eh40XjmPzW+ex9tQFLD1yDB1k/FUE7UY2gvXvXMDqs6eYHZimz5yE1nf4BfEDU5FZmofZTQsQGhWMmFBvDIsLQHn/SORROJWH2qIk1Ap50XbwMWchsrCTM2PgMtQXOrRzerxRLRZWT09NAWj76KC3b18GH/16MXqoAu7py88yLOP7wjndFP7D7OE9wApRY9wRPMQesWO8YOnVGz5+jnC0IRj0+8JEpydMWNkmvbRgxcp2Mu0BL9u+CGUlJ4XZYUCCCzISHJEUaYGIID0E+2ojPcUR6cnOSE9yQr9ER/RLcEZaPAuPkcrnuVlJmDgxBVPvz8PMJytR9UAByh4uRuXjlaiZW4zShiEobE5CYUMSCuoTUbgwWUXRolSULkrDpLahqFk8EMXzUpH7XCyK5qagsjEDVQ0ZKJ6bhKqF/VDF9/3d47QlQzGZn69elI7i2fGY+Fg4Rs/yw9Cpnug/2QOpkwOQPDUE/aaEo9/kSKRPikZabTT6VTMqY+A7mPeUE4bEQe6wIfgy032RRQc70ZupyLkPigK11YkvuQm2GJ4oY20stxA7aDkS7FasI497QeBrBfaEQYwFLFPcYJMWAOtUf1j184DbqGAEF6QgrnoYUqaMxZBZ+ch5qkYA8yMc/Z1gSOZIH5FMS90LCWE+GBrlj4r0KLokB1RFOaEs0hpjQ/Xha6OFiARdjJkcg/hKf0RUe2PAQxEY9XgkyhemonI+C3X2AJTPGYaqBUNRvXAwKheko2xeEguHhftcJCrnxqBmXgJmNg1C+RPxmPwMC/q+GEysCUNItCHS4rwxKoV/D0xCzkBW2JBEFA+NQ25GIEaz1YyMscLgcD2kkQlSArTYirQwOE4LI9O0MSajLzKitZARxYjQRHqYRG/0C+lDitZFUpAhHOik7Fl4zi49EBFri7H5ySidNhoPNuQjf3YQcha6IneRG/IbPFDc5IWSZm+UtfiiosUPBQvdUFLvibJGH4Y3Kpr9UNUSgOpmllmDN0oXOKN8gSPjrx+LZtuhZK6d+ruq3gXVDe6oXOSM0nmOKJjjjKL6IBQ0RKCkIZIRzd+KQdGCOBTOjUP+84koejYVBY+koP8EV7pLLYzv74mCRG/UJAYyHdGo+PVGFstmaIA2BsVawtunD8aWpaD06fF4YFU1yhpG8jcGImdOIkY/FonBM0KQWh2AhJIQxBQHIbLYE6FFrvDPdYHrWFtYDzYl4xnCMsFQAPMtEgZFI2VoBMomj4OLmwGSQ70wMjIAZWlRmBBgiynMhWVx1hhGyxbLeOCZdDzcMZoF2A+FrQko7YhDaWsYpiwLR21zECY3xWBSQzxq6yNRUx/MluSHinoPFoorweOEynnOKH7KHvc3hGHSM0F4gOB5tpGt7sFYjBvnjrKxCXi4eDxm1xVgdm025tVloX7aBMyvHY7HC+PwfEU85lTHYMHUGDTeH42GByMxZ5ovHiqzw+SJRni6zg1P17rjuVofPFfjj+eqQ/FsZSSeKY/FE+UJWDhzFJ6fMRrzHs5GztgQBPj0ghUbgg9b5tSnBqJktifyF1mRXazJMjYoarRGcbM1ipqsVJQ2W6FiiS2q2uxRuZiVX2+JwnmmKJjLmGdE4Jijpsn0b6OqwRgViwxVVNYbqdfqFpurqFqs+d2CBgcUNTipKCaoCha6IG++K/LmeOGhNYNw/5KByJ4cCFeyxIBYCwz0McbEAEfk+lhRPuigKp7XkmyFYfHm8CL7Dy8IQN5DCRj7cDDZkmBsDEJZkz8B6cvrZiOYE4oSNurK+n4obyIoG2KQtzAa2QRq7iIy7KIMlC0YAq33Pn+b1BaKrPL+qGYhWrPg+kd6YnxMEEqSQjHS0wyT03zU0XnJTDlD+vXGzGdjUT0/AjkLfJDX4oPsZidMXGiB4kYLFM4xxqQmDwLFk/RLcNTboYYFXNtijtolZnxuhJlL7VD0lC4eXOyDKc+6o+YhDzxGtA8Yroc4MsJT1DXPV4zD00XD8eCEZMwcFYWHxkXguQJWdlUiHs/xwaPZrngoyxYPT7TCYwXWeKbMFs/X2mHuZEc8X2WH2ZVy6r0bFlT6YEFFIOaWh2FuWTRml8ajbqgXpk0IweypQzGrKhWTimMxbJAD4mJ18cT8oZjRFIK6JbyuVhcCwp4MwpRMEBQ3mTFMUNpkxAI3RHGDAYpZ6RLl9caoa7HB9GUOqOT/K5v0/jYqGnVRVk+dsVBbPVY166Ou1RiT2wmcDnNUd1gxbFCz1FpFXYct/7ZDdTvZntdUVs9rWxiEvBme8CG7jki3xmi10NAHhQEOmBRjh0nJtsilVOgfrgtXaqThBW6Y0difYA1HaaMbQW9LwPCe6k1QNN+cjGeL8vkezBKs07nOyJnPFDffGVkLXDBxARvQ/CDWbTRd0o+fInFwEIZmRmBiMXWJE0ER5YrsOH9aNW9k2GujnLl/KLVHAEXa4AE9MWsOqfI5D2TPc0D+Eidks2XkNOqjkjdc1WKK8kXmKONFlC5gS2LBVrT0RfniXiis10LuHC22wL4YfZ8W7m9yxoy5Hqie5YrnFmYgOkELYdQ6Dj21kGTXE3WDgtE6bTxWP5iNpqoBeDY7As9kB+H5/EAsKAtCY00wmuoCUV/tpU5XW1DtjEW1/K4iW8wucsDcYlfML/XGwuIAzC8KxbzCCMwpiMLyWaMxtyod9+dEYFCEDuJ4b47UZjaMJ57vhxkLg1HDQq2sd6BmsUHJIjO2RGOUNRujtIX31GKE8hZ9VCw2VPdbvdiEGuYPrMH/V7YQHC0Gf/lY3ar5f3kzwbNYV70ujyUNOshf2IutmzpERe97Ia/1Juv0IfvoE8hsiAvcMLbWDE4+rJMUQ4yNs0VFYgByfG1QSb2Z5d0HowP6YmySJYKYtofk2GBaYyImtQTx845kSAMCvwdTqhbTaB9UNZIZF1nz+q3JcvyONhtULeP7ljFVtrmidLEXs0QItN7//Byi05irq9KQUxIJH3eq7lhHjAu1Ry7t2jh/M+RQUGbGGsLdTAvTpvmj7glfTGr0Z6Hxcy2k6w5Lfqkp6bovC9WAlMbCa2YhLjEmbeujvL0PStp6oHiJFqldi3aVLXVOHyLeGQ83h+L5lgzUTAtGJHVHIrXG4EB9ZLhQS1HQJVJnjPPri5mDvVnhcVhMRlhcnYSG8hjMKwrG0zleeCLLFU/muGJ2CYFDXTW7wAuN5SFoqYrC6pkZaK9OwcLCaDSVJuPJ8cHIjzTGcJ8eCKGOief9Do7qQQGtBS82lgceiUDds76Y2RqECjaISc2uqGlxYEs0wtSVdmRRHZQu0eW967KSBTT6ZAhDVPOeaxpNUEUGEkCVtrJCCIy/eixZYsjQ/8vH0haCsJXfw7KT7y5frMNgo13SB+VtBFgbGa7RDPcvo2Z62gOWLtRx1GxjmJYmUtgWBdqjyMcMRQEmmBBiSgdlAV+mpNAUlv3j3mQSNgKCX8BSsViLgJcGzMfG3gQMv7/egA3ASAMoueY2vrfVgr/vhOpGP2hd//o9xKd7YkJeJEaMdoc/1bOgNTPcRu05MjbQiArcFGNjDeDBdDVjFoXVkz5MOz4sGCcULLZESTvZRAFGTwGmmAUoN17aqkd905fBVrK0J4ratFDIC6xbxgJh+ip+2hJT5wTi4TlJyMxzgQcrLzFUFxOTbFGUZKc2Kx7m2RMpBE6CiRZSyQAZvIaRLKRCvu/+Ia6YR8ZoZpqqL48jUELwVFYAnskKxuOjCOok6o1wIwyjc0ugU0gn4KNprSf490ZpEnXGYDs8XUX9c18C6vj7yUyH02cQLHMCUDnbGVMbPVA61xKTlohWMWUh6qGouRfvi59v7clC7M0yYOtc3JeFrkstogFPKdmnuFWX8d8/CnAql5jy91hG/K4qMo8wtPxOBYFa2UpwEbwz2r0JGDdYOGsAMz7RAtmhZMMQe5T7WaIqzBb5UXYYz3IMoQCOzeiFOuqUagr5igYjlN0DiwIMn9c2aaFGmIYsV92ig4pWHZS1MWW2kwTaDFG2hGmyyVO2LPsUqQN9MSYzBGn9rBFGNE6IM1NHquRGWBAwBpgQbYqRcfrw4cXNejQStU97Y3KzOAYn2k8zhcCyVqK6iYgkZRexZRSxcAvbdAmUviha1gf5S7VRQOAUtPZFzXLm5xZnlDzrjIrH/PDwbKajpL7w9+2JgfE2yE22R3EixWYcrXwUryXcBDkhhhjj2QtD6AoGMjX2J4j6EQCJxmQJw3uA4msCqGQ+l0jUJxXz71FkjrJQU8zLisCighgsLIlGy+RkzKuKoN4JxeNkpepMKzozNoip7niUYrzoCXPc1+qFoucNlP6q6zCmENZCSasWGwejXYstnnTOv6vInNWLe1Kf9WYFk01b+6CwvTfjv38sZvlUtJCdCdAqpkDRN7+BhmUq7FW0gGy32JP14A4r1kkqAZOTaoVcpqKqcAplD0PUhNigIMKWzGOl0nx0ak/MmB9H5+rJ9EnwE4DVvO4aXn+tPBI0Nc0ETJMGMJVLtHlvbBztvRRoykV/NrpC65tfP0faID/k5schKcEckcyJWTHGKBHQsKLGhhhQAJthSKw+/Ammh59LQI0CjDfRaY9CUrGApXQJxZMCjCFBxALgBRW29UVhB/PyUh3kLeNjhx4KSHHVy8lMFFnTmujMHg7EtEdTYc9KlX3/R/dzQ3aitTo9NjNUj61GH6Wk25okB7XMJcePuT6U4Aw2QZ6/ATK9dTDWXRujGWM9dTDBxwj5wWxdwfbI9mXqC7FEcZAxavkd88k8C3ODMC/PDw2VwRTBPniqyB1PlXtiVgHt7nB+d64xnmmKwpT5bphS78xWR0dEfVa33BC5DQQMgVLSwVj6F6Bp6cEy6UmW6KHYtKj1rx+L23qiuJ0p+i8eBWwCCknpvwGGIRqnnJqpgpqpmI6srsENk571hiXLrR8BU5hup44kro10Qp6TNqoCTZHHv0dFmCGcgAmJ08J9C5NRPpdmpJEaRWkpgoXXI1EjoCFQhC0F9BUtZE9eTxmjlExTTlFeQ82pdeeHj5Ga4YeqysFIiDFHOBV1dpQBqkhxueGGGB9mhHGxZhgQ1RfBpLbH5yah9lkvTF5Mm9xiRXAw7aj8LKmI6p9pqIg/VrikJ8HRS7GKACZ/qS4BY0QQURC3UIE/ZYMpCyIx5Zl49B9pARuyxvD+bhiZ6IjxEUYojiUQ48yRH6avdobM8dNhxRuQKYyR6d4Leb78LbJGTbQ1qmNsURljo2YGSn9RTgCtJUGTF0ABTv1Vxu+oI0POy/TAArqredkOaCxxQ0OFuxLMS2bSQdUxzY42QQq1zIPPBeGJpdEoe8YaD67wpmVma2zn/bGAiwiSYoKleNnvoPkjYIRpyvhcmKjkbx5LCRzFUn/1yFRXxkrTiGrRSd0heoZlQmdTMs8SdQs8MGN2MKwc2NCo/cr6OyM70ByTIsnc7jqYzEZVGG7Gxm6BhIg+CGC6fYguqXpBIBmGollSHsFZQ22pgmlWmKWa2kxAI4Ap5/UowAjLUNNUNTtC69Z3V5Cc6otaWtmwAAOEOmphYrgeJqWQ4giYzAgTJahSw/sgJISAmZ9MwLD1LXZhazIlw/QmSJjvGKVklnKyiipYFkAxC7Owo4cmFZHWCttJp0usaUl5wQu9UPaYL+5/LhV2pFXJswOkryfKAllRBEwM82ysCcr4vCJaGMIMtUyN1dQktZEmqIlg6wujXghm2gsiM4SwgOW1GGsUkVVKwqxRGEw3EklHE94LU5O00ZTvjPYyF6ye7ImltS5YLNa7xAYNtR54rtgRM8eYIoQtNrfMHA82R6P0KUc8tCIYBbMp5FmBVcv1kM/7KiRQJAQ4wjjlvN8Ksko1W6aEsIz8XcFG898/EjAtrKAWjdBV2kXSEQEjLq280RLlCxxQO98LD8yNgg31WXpED+tpiiAAADqBSURBVFQOcEOmjykmMyVV+fTBZJZNERv7xERLpFN/uvmxITQMQs2CUGoYF36fJdMOwdHGNMqoaGUK4t8Czkq6WPldAYwm/fKaSASVTXZMST9fJ2D8UVYyBJ5OPRHr2ZtqWw9TUyl6+aMTqSEEMAnBPRHC1vfo/ETUPk/AMB1VUaAVUmFLyyhjwZVSQFWSWuV5mdA2H4v5WMDHAtJaIQVbMVmprMEJ93dEofhBd4wvtocV2WVQP3P0izDESGqnErKbHASaL1tvBbESCJpJMaYoC+iNCQR0EVNjeUBPyPlIk6L0CSTde0fe8KbDyWSBZDlqnnz/Xgos5QT6NFr21iJLrKiywbwJPTA3syeaiozRWGqJlhpa8hJnLKjwRv9gLYTHU0ROcsBUMmDVPDLMXBvVx1S9koxHBpBGUMj7kjRSwhZYriqU18D0XN1E/dBEAczGU0PX+N8+VrFlSzkKEwkQpdIUaPj9ApiyeuqUehfUzffHIwuTYEdNl8F7rB7gjfHuJpgU6oA6P23UBpGFA8nMlBkD4gxhyXKbPqcfKih8yxso5lXnI+08G7qARTX4e+6vnIBRzuweYEoENNSj0h+l9TO+QmpaGAqyB8CZorE/tUFWgD5mpjozB5ogm5Q/Jt4acWQAAcxD8xM0gKHNqqINVIBRX8gCJOVWEhxVjEoWqABHfqyI4qlAHMZi6fyiNZ3nilktcah8yB9e/F5/Ly2MTrfE4DDqJbKEzHovDyH6ww1QSQYpD9RGdUhfthp9TBH2C+2LulBt1AQTDAH8DYkgtnI57DyKvxMgx9/QsYX0JtAoRknH9yURMIVmWFZuhrV11lhWaYqlVVbUNAaYnWWIp8cbYfV9Eagcog8bVkLkoJ54snUwsu93QOV8D1aULWo7JAWLqO2tgCJuSQMWfY2tbhBhaIJaOsUaVrBELdP0n6OOwPhzTGrUhAjnUpaplKViLv6OVKhUpOowrLdEreiXef54YlGKAkz/0J6oImBGuxmhOtQek3nvNWzgOYG9kJ9shSFJZjC10sLUZ9NQOTdMdfwJYAQgygkxRDvJ3yWLWW4MAYyk1u66FfapbiJgvv/hLtKSozBxbH9Y0lUMjaBLCbJARYg1isMdkBfrhFGx1kiJ7AsfVsz9c+JQTnUunVoiwIoWU1ssIYUy7UghFjYyl/MHJBTbqIvRpKLSFjfSXSCqF4ZiMr9n8DhT+FJkJ7GyR0cbYBwBUxBGhxCoi6lkiOlhxupxcpA+JpE1pvJxMgE0hQUymaAR4NSG0dKSaeSMpHI5JymULYWAq2KaqgvXQW14D75HCzPJGrNH6KK92AptRabYNNVVsU1jvjHaKxzQUmKL58Yb49EcOyTHasGdQB44zhiz5sVgxgI/ZM7qjSfXe6JsQS9MbieYm3uwpWqcxVQ6w6l0i5MX0qovMFSULilFpRVpqYzKZk1USTT2Rm0jWYAxqbGPiskN2ipqG3qS+jUprqqdjNmhzQpjGROYRbTZZU1MSfPtMX2hH55clAAvT4reUC2MoXwoiHJkGrZAkQ9TSCAFNLNDLg3EkARLuFGbzqQbLZ8dQsBQ57SaorSDIFlKsS2Cm3UoYClZTFDKI/VMGTWZgFb0mYB/Uj1T0vfff4vUpFiMH94P1rSnApiSCEdUhtqhkJEb44jRcTYKMF4KMAkofJQ/KINnCqUmvClDVK+iXlhGR0PKLqL9LK5nyI23GaFmhSNql/tSJAehfGEYCzYRGVlmCGHLD/fVIrP0QQFvrDiSgjiEGoXAmEp3NC3USIFDwCJAmRFqgBkUxNKCJoUQDMGk8GBWTLAAhY/UWeUEUEUQQURGEsDUsfXVsECnxmjh2eH6BIs9WgossbLKEe0l1lhcZIHlTEntFY5YmGeJ+ZWeyBpsjujoHsgYrIcRE42os4Ixa6EPCh/SwUPtjqhZqGGF6nqCYX4P1DXqYlaHJaa3sLJma3pl85vYuhkFjZqQ3tpiRmk9gUDQiNYRsE1qZlqVuAecWr5XgCj9JGJry2i1xaWI3ZaOvQqydMkcC0yjBnx0XiSCmULjWS9jY+gaYx1QSgNQ4EvXFcDfpEPKjbfB0BhLuFInTnsiGVUU9GUNDuq7SpcSJKLFCIpi6q4yptKyZgEMBf4SDWAqCJZqpshJZMbJApiffvweqQkxGJERDzsjOhW6jDxR2AGGyA6iNYu3x4RkW6TSJXlRON33PDXM7EAWlCsKF5gjc24fZM3rjTy2DnFJJWwJYkEnLacK75C+GTNkzTHDhKfJXE+T2p8NQdVjkfBmqw8nswxPMEIWBW0lbbPY5XK6oOIAflcg8yc1SAktYYkvn/O3q1gI1SHUNHJ0HdNRRTDpO5g6gs9LCIySCKaICLIN7Xg1AVcTzkoN5U2zUOvoJJ4caoAlFLctRXaozzPHc2N18XymARqooxYV2qKe/2udHo5HK0Mwqr8JQvnbsQTapJm+eLYhGfnTLCiGA5Xdnt7qgkmtlmwcOsiZK42jJ++bKXMN72UpG9FSsvRSea4JKQuJmg7pqe2rQsaUVDTp0LnwuhuoVViOJWxskpaUhqDgFOYubmOjaKPwbpVxHzPMbPDGQ3NCqD+1EEj2GJfIVB5LfZPogCLpmGTZiY7LiWFKoknwoJivvT+ChiWAhsNedbBqLLMGnOXSuOX3G/UVw/wtYH798QekxUWrs4dcTLUwMtoGE9nC8wIoHsNNUJLigKw0W6SwMlzd2FIfjcZjram4vy2cBealBueEaWT0tradgqvDHjnzdZE9Tw+5801QxNRVs9gfM9pi8EBLGh5pHITIFC04UN2nUaSOizXFONnML4j2nTdVHEj7GEX0E6AS5RS0lVHUMWQhEbU18jpBIkf0lVGzqAjvrcBSEsWCihThy+8IZh4mC1USSDIxupps9uQQI7SWeKC11BVPjGRqS2arS9PCrMF9cN9gHTyZaYHmuhA8VuiHhbP6YWyqLiJI+QHUWFOmhmBR22iUzfLGJDYY0TUyQDljnQcmr7GkqO+BLBZ6Dgs3t0EHufUGfGQZMPLqJXRV5NczvTTra7og7ukFsdESpWSaMmqYYqZ1AYyy5zKkQuCIDpSe83KmksoGa9zf4osH5wZh9AQdONM0jEk2xJhIiuIkO5QG6VD36TA9Gaje8iFMVzLsUVzrgylkmOr5dkx7tMlkFUk3lfytKoK0emFvSg25ln8DGPz8E9JiohAf6AFPil7ZTK9QrKiciUxnUpRsDel2TmbBu7rwgw9EovrxYFQ+40sH4Umh54XaJk/+oJua31E8zxFTlgeROj3ZUjwxqSWM4EpGzXMRGJZnjdA4LThSqMWz1U9MtVULsGQNTXmENXI9qDti+fvRZLdottwoHRTFsnBjWdgERi4rvkDOcuRnhVHKI3mD0QRSDAuIjwKY4nDmfDJMMXWQzDwrZ6oq5fsrCZjHB5uhrdSX9toVM/sJI7FSqFdKGQXRLJh+ffDQWFu0TIpFQ10s6obZYep4b0SzobiwbMaNccPT88fhoYVD6FJiUTzXCwUUw6VLzVG+lte8nA2OBV+53BRVS20YbPEqLH+PZeaseGndTN/tBEsH7fJSClo1hKJJP6XS4llJwjCqi4KVVsDKK6SukJ70mmYbzFzshfsofPMrLGFlznrrZ4ARMUwlKTa8Z32aBT3VrSAbcQ+J0Icf625ioSNmPB+CurkOqG6gVCA4VQ8vAVq7kCy8gH8vYlpv/reA+Rlp0ZEIdbGBn01PjJcKo72tiNRDfhiZgs/HkwWGxRkjhGlhxqwEPLFgEC82HpP449XP+aPyOT+GP2rnBpOuowmeMNQtjmVOT8IUCrPSh0MxosABcWk6CGGlJ9K9lI30RT6d2AgfXRTJykqK67IQaqJoK2TFGGIEreKosN7IjNFFFllmHCt9LFOETAwqIAgEGGVkm4qYvqgkoMoJsGICqJgCuJRapzBAQEPAUNMIG5UzBT7S3xxLigIwZ6wDagmSknC2rARWCtNVFq13XqQWCumqquJ10FYdh9WzhmLyEFdkxllhXKoTAgiclCRLFFZHY9rs/pjenIzc5xwx5lldFCyl2N1Icb+yj2KRwoW8BolFrLhFwiwadpHU3d0TXkT3ozo3VfSgZRdgEMT3+mAkRIzmL+6JfFZuIZ1S8WLp/bVDLRvnDAKmYroLzC0I1AFGGJVsisJUG7IsG2CoIXJDjFGQZM+UZAA/d6Z/mowZz4dh0lwn1NabKsdW09yTQptgWdQDkxdQhPNa/z1gfvmF+iQCvjYmCLbTRmasHfIDmQpI57n+1CcUnHkJtpiY5oAgCqeJ470wh63sgaf7oWZWOIqm+yFnihdyp/iidFYE6p5MQtkTMah+Xjr4UtQkn7RhpghlpUSE9EAy08WYZAcUZHhjkDefB5kjJ8IOI/lcxkIGebLw0lkJCSZMj0bITDRDHispO8ZI7XBdnmhOgBmofhqJ4ggqemqV30OPKYnMyNRWylRXRZGsRDGB9kCKGRpzAvH0MAdUycn51DfVsX1RGE4LGkaHx9SXKyksglqJAHxmnB8eGR2IeZVsIBMTEOeti1CvPnD30MKgMU6Y/EwSZjE91zSxpS8gQy40RFGjIVutBUWxJmrpnmoXm6KGjlJGoGXwUE1VEDHMVCAAyWOl5DIkneXxtVJWTmmTdNQRcKy8fIrRPArRIn5PaYs1altpi593xH00ELUP+cPCVgvDBrK80i0wQTpcI03Z2E3VwfC5KU7oz3L0ZmpNHUpn+WwoauczM0g3Ab+vlt9fxxQ6icwyeSEZnqn0fwVMv8gIeJjrI8xBR23aLCO8U6LNVDd8fgiFaIo7chJdYNlDC34OpGeGPTWI9NA6Mb/bswAtHLVgYqMFY/5Pn8+1eRM69P5WzJ3+rKw4Vm4SXU+inx5yMrwwIsIWya46mDI6CpWDgzDQny10aBBGkWFGJdqgHyk12bc3BrDSh4eRcZi6xrHVyPb1JVT9RVEsFP6dQ6eUR1eULz2+tOUlBEhFFEHF1iXXX83Ckz6dEr+etNbmWDjOH88OdaMYZmuliC6V0XH/Higg0KqT2ToJysmJJhjO+5N+jMfHheDh8ZEoSnXDM7UjkD8iCFG07C68d3+mtInVnqh+KhxZ9zli4sO2mEFRXDfHEZPm2KFuno2KmvlWqF5gSbFpjopFBA6NgHTNy/SPcgJIk57YANp4nUvYCOpNULyIjquBbNZojvxGMzIM77vFjs7JFdOWBaH4eTfc38S0+XiYKvv+ZJghGZYYGmeGcdHmGB9hiuGM8elOSIozhIs3G+zAXqh6JgxVC3wosl1UaqtZLH1HhmQZA4KFDpWhZhz8HWB+uHsXKWGhsO1LBPpbYZg/1bZvX0yNtkahL7VMpBNK4jwwOtgevrTdUW46SI+0QBIrLC3ZCv3SrJAQZ45E2uKMDHf0y3BBfJoNkjJskZRqhcR4CwxIdcSEoQHIGRJIaidY4pyp6t2R2c+H4YXhic5IZgUHk/I9CTpXMy0EsRCi3LURzooLo6hLcu6FYX4UxiGWmBBEF8c0VkYbWRxlzRRljgK2qKIIc7KFqbLnhfy+kjDm+xhWEt1CMcE3OcIEzw70xNP93TEzjp8nCKv53kl0FvL5HOb8mhRHairZxYngizNBYRxpPok6ZLA7pmeG4v6ieFRlhqA//+fCRmFO/eDhS03WTw8DR9lg4FgzDJzQB0Oye2JUiR6yakyQWWuEsTV8Po0p6xFe7+NWKHjaAgXPUSzPYcwnOBYSEE3UH4ud6VTcUbbIkzrQm67Kj67FFRPmWjFs6MY8ULU4COMfcUTJ00HImeqNgHg6zrjeGDnCGYm87hGsixHxTKMD3DB6mDsi4vvCjtY7cGAPjL2P5f6EC7Ket0UegZy3gA1vLsG6wIB61AJT22z/PWDw44/IiIuBnW4PpAXaUDewNcQ5qMX3Y5x1MN7LDCWxsjFiALz1tBDCtDU03hUZ0Xboz4LuT8pLjrNDSrwjUvl6DJkjLc0FAwa4Y0C6K1+zRxrT3KB4J2RE2iPe3xQjU7zQL9wWwa694cACtyJAnAgMP78+iGarSOd7k0OtkRpsjbQgK4QQRHZaWvAiqAd4GqiDMSdG2qEgxkmtZMgheHIJHAk5yzqHYJZpEbITU3WiLarISBVhJpgWY4MnyG7PDg7ErCQXWnYj5PmwcGRFRLA5snht+VE2qMxwJaPYYAKpfAT11nBqpvFx+shKMsb4JBOUj/ZE4XAPjOvvzHKwQIinNlzlGk3ItAxPHwKe7JM0oC+GybSJHBv0H2+MlFFkzbE6GFpsjsFlZhhcYYYBVSYYWG2MgQTV4KlmGDbDEhOf9ETW0x7In+NLlxnASmUje5LlMUMXcbW9kVKnj/gSgrKWjTLTCBZkDztGfJox4pnKh/V3wCA22lSm4LA4HThS/5mR5R3pCMNyeyO2UhtxddSSU+lUZ7JM76cGelQL+c8zDTbSGf+7fphu0WveUwsJfhbqeGGZklnOCimNJhKDHJEV7kXh6a8qLcrVCH52PeDFCo7w10Nagh0yUtwwKN0bGak+BIw9IkLNkBBrgxQCKpngk2Ueg9I8MYipLYWsEOyjD3+vvvCkXvHy1kZAmBEFsSMGjArA2IkxGDs8AiMzgpE5KAK5Q2OQEe4IH4IqzLYXxsV7YEw0GSraEaPkyF2mTImR4eYYEWaGoSH6yKFTGEunNZLaZQIdU1GMGSqY6mSaQ7ZHH8xMoh1OdKNFd+B9snHEulEg2mKomwH606n5mvI+mWYHUvhLP9GoRH2MTtLFmCRZlqqDwRE9MYR6ZzjZazjF+rAYTwyM8GWD80GCvzsFpi6cmZotKEZN+F3mdFg2TGEeTIGBcQYISjJESJoRU4Q5okZYIX6sHVJzXTCo3BfDav0Ql2+GqAIDROT1RUSxDhKqDZE02RDR1ToIzGejZcSSvQbUksnzzOBGhrElIFxpKFwIVicytRM1ix3DkkCyJXg9B2shOLsPQot7wztPC76FTKkl/K4KfletFjIImgnPUIxTqP9bwEg/THJkOEwImORgG0zs54Hh1BMy066iny/GhztjaIAjhoV7wJSASfC3RgLdjK97LzjRHluzMIyNeVGkZw/PPipcXHvAmarcnoVkxffY8H92BJglNY0+32tMVnH27IHYVAcMzwzHhOJEjMyPQfqYACQO8EBCggsqi4cga1QcLHT5Gf5uGoVxztBw9AuzwYgkApRMEO/TF/78Xm+mLAk3VpADvz+W9Dso3oD52wpj4o0xLLAPxtBmFzHN1hK0Yzz6qnkzmX5myAqwxChvU0SzYgPIYKH8nmDPnnBlSrTlvbmx4hPosMYMNMOEIaYYlUbXNtACY9MsMJJmYHSCB4VmGDJTEjAmLhFDomMwOCUK6UlBSIrxIWO6IoTp3NvXHE4eerBlSjd36QlT2lwD/kZvMpMWr1uLDUI98m89Vr4ef1OfRsEkkdcwkgAu1ye7GCG8XBux1XpIrTNHv2pL9CuzQlqBDWJHmyAghQ0whkCgAwwkiPySeU8D+dksgq7cUH0upJzlPo3fMa0n4mewzu+j/nmADPNkT+TN0wxw/nuG+elHpCfEwooVk8xWNirJCSOiLTGEAjVLmIMpZnCMG1t7mJooPZjupl8/ZwwY5Ipx2YHIKgzBoNHuiO5nCZ9wXVgT3W5BfeDI1uTg3xPutOZh/ZimxvhiQGYQMsYHILe2PzIrUjGCIBlEXZAxJljFgHGhGDo+HE7ULn14PX368KZ99TFkgB/TmyfCAg3hwYK2ZOXaCDgIRBlLiaL1HjjYHsNHu2DwKEf4sqXZsqKNDfjI98ok79HxZCEyWRpBXJLsgSJqqHxhFuqzoQHWCOH3xTjpIGtQMCKoa/oP98TICYGITTaGnbAF792PrbV/si6iCMjkCB0MoTgfnswyivFCWpgnUoJ9WIb+iAnzoq7zR//0SAwdFo9hIxMxgEwZl+aP4FhXsowL/JhO3SJtYUvWM/bWgS4bWF+WnbYsMONzfQLGKoVMQWYIyOqDmEoTRFcZIqhIC5Hl/LtcB8ETyRCZWgo0gyvIdBWuyJ4agILpAXz0QNYMV+Q+4q562Mc95YBhj5tj4ONGGEndNGouQT/fHBMWmCBnEc1EE00HRbj0RP/bnt5ffv4R/ZLi1AEH/tQsvjL6Gc28GsuIt0EkXU2gly5iI6xgzdY3dJQvhk/wQ/+xzN8TqFvG2SBqiAniR1piUJ4XBhcGYlBhKFKzAxA/zgtx4z2RnO2HtPxgpOax1U30U6scw4e5IHa4O+KGeiCSAPSj5nD07g0LuioHr96IS3dD2lBfePjrQlufjouC24EF6RvSRwnqVAKk3whHdR2Ds1npBZ5Iz3JC3EgzhFM7ZEyQxWlMFcOs1cQvX7bmRH9tTEh2pEOTZRl2GBVJ+07QZARYwZ/3FuLUB0MzfDEqNxYDskIVyNPHemPweC9k0IoHhmrSi1hUX7rDYL/eBIcJ06wjGcUL6Yl+SE3wRUK8FyKjXeHtbwZrx14wIbMakTlMBcS8v778LV1ej6FbD5j6asOKadQ+2hRuSTbwTLdB2DhnROY4IrrAAREFlogoNEF4CV1saV8EF/dQaSmyvDeiS3shqlAb8YV6SCo0xKAKO+Q/FEDXFoLKJ31Q8Zw3HZGXGp0uWORAe26P4g43ZDVaIZsOSSbwF7VaQmZMyphfNd2ahAzv/C1gvvvuG6SnJsDBQpdUbAAHUqMbbyoshMj26wEXtmgL3qwtW6YBbzR1lBtGFvtjQL4rBpWQaUodmUctkZxng/Riup18F1KgK6JzCJZCP4qzAMQW+SEix5utwR0hE9zgN9QWrklGMGNLFQtuRJDas3UFBJsgMt4W5nxuwMI15HU4B2kjop8Nkke4IWGoI6L6k4bHuaJfpgtSs5yRkGmPxGx7XoM9YrLJFOOMMajWG0OqvDGCmmBongcS+5siwF8LPq5MOQRdBrXOSOq0McleGJPqi7HpZIM4N8QGWyEigr81NhBx43jdo32QONoX/ck0w7NDMITsmEGQR5GtxBnJlAF9ilx5NCfbGbDsetMYSPeCNctNNIQtgeXoRyaMZjpIpUDub40ouY9RBDcbU8JELyTl+CApn2ArCkRaaTAGT45Ev0o2uBIXRBZaISzfCEH5fRBC/RFV1QcRlUwrNdroN80QGdNMkFhGrZNNhszpjX4EVuljrrT1Hpi0yB0lc6yQ85whcuYxFhljwkJ95DabM+j+mmloWkwICgOyi6yPIkCaycAtMgPhbwBz95uvMXhIBkLDXDBkiC9bRl848yb9IqWlsyVFs7UPtkW/CR6IGMKWWRfBG3RA2HgjhE7QQ+hEfQRmUkzl6CE8zwj+43ThN4HqvMAZseVebBnucB5hCn3mVi1WmqzB7kFhpsMCN2SYMSxIw+YEjikBqccW7BShTQtojgSCK368M2IoChMynZBOFulfwtZe7I7UQidEZVsiaDwF5EQjxJZSZE9yRtoUgpUU7T1KG97DeiMp1xbDy3yQMdYRobF94M3fjmdrFneXSE0TEWhKhnXFsEFBfN2JYrEPHGi//Qe7IiUnHOn5EUjOorYa64WUMUw7Y/nbYwjYce4KuEmjHRE3whoxjOTxTuhPgPbLJOvle2BgAT+T6YDYMVZIGE9HM9GR4Hak5nBBWpErwUETUOxKkeuAyImWCJtggeDx5ip8RhnCbyyFb4EpospMEFpEwUuhGloq7oblTsEqz2OrevB+CRY+T6nqi7RqbQyiAyqZbY66Fgc1YbxgoS5qllujZqUNcpr6oqjNhIAwRnGLCFzN3BcBSrmMYcm8ZWEYxh8BI73CGsB8/xMiE8MQnc50ku2JYUXOBIY2+hfYImyIDtOIPfqXMXXwpoZMDSYwLBGYbYbIMmskTnFG6n0stOkOiJlkgXDm2LBKqv8qPq+wQhDto/dEY9gP6wNjirfeZC21aJ8g0eajDsOYILIJ6wXvRCNEDhLxZk+GskZ4Lqk4zwqR+dYMS/5tjpAcYyp9AyRV0Z5X2SKu0gYxVZakZxZoGVthsS4Ci/ryuQFi6ywQX8vPFxkjMs8ECRSGiRPtEDXcAkZkMGMypg2B6hdhjMR0Vhy1WSidoRM1k0WAHjzSWNHUXMn5IYid6InI8Y5kMLKZDHHk2zIN8FqLrBDDiC7k9eWTPXJMEZxlivBsCzIqryvXGtH5fB/fG19M0Jfakg3sEJyppyIkS4/XZoyEMgukVlsjrcYOKdW2iC2zRFQxU2sBy7NYDxGljDIdOpyeCCJogkXHVFKbERjxk3rwPvnISJ7SE+kUsSWLLQgIQ2iWr0jIEhaZOnsvlnRPmOqjJmdVtvZCFcEhUc5QGqZFj4DpRcDwdYJGzYdpsIXWF3e/QWCsP4L60QJnsZXmGyNmAq1jNVGf2RcJhbR++abwGq2NyBIrOI/upcAQWGICz/y+cM3tBc+CnvCnCAurM0D0NFOEVJJtCJ7IanNaQVZqhQMLwIkV74KwbKaRQn/EFzBd5dGG5pKOmb7S8r2RXkhrXuqBuBI7xRKRLLhIFmZEqbmKsDJTFf4FfRFQSHAU6yO4TB+hFYbq9yQiaEE9Sc8BRT1ZsNrwz+mB4BwdxJVaIrGUlU3GiRpni+ixtPcDLGEprMe0IuFIJxU12FuJT33fXrBP4L1QSMeR2WLJmAq8hbweaoqwIgNWoAGCSxjFBGuJEYJL+f4SWuJyaj82qIhSphNWfBjfH0KbHJrHa83TRdpk2uEaM8SV0SqX6BLU2ny9B8Ut0+Y4AqGSr1cYKGcUzbKMq9FHQp0+EidL6LJMKfSrtOiYqLvILOG0xsnTtTDqGRPkN1ujoM0QeR19VBSoJSyaKG7rrUJWNWjWVclsvl4ETM/fAbNYM5GqGzAyAKoAwzRVK4C5+e03CIr3RXA6KTPLAom5fRGbrY0htbTPBbpILjdlK2KqyaS4YisILCQo+L9QqvYA3qxfKdV6hS5CmFuDKnryNbbaAtq6Ym3eDCuggp8nE8RXMgVUuCOx3BvRuS6IySMVM+L5PC6XtD7RFjGZBEiWOSuXYCkxR3iRKUILjBFSaMzKoaUsNWFLox4p0NcApkiPrMKUyAgoJogkKAKjeE2JLOj4Mrbggj5s5bwPgi+13A5JJfYYWO2NhHxnAscOsRNckZxLZzPWAy4JBtBlGnagRjGmdjIMooZLM0ZYJjVHrgNTnxn8J/Ql/ZNhS/l6iaECTEgJn/O6wivJDFXUKOWWiC5nY1FByy5RYcwULWHIe+rN6Elt0pPg66nEa1xFH8SLZaaYjSztyTSkiUgCQiKK4IglSBLusUnK1B7of782Bj+sg+GP62Hcc8bIW2RDBrEjYPR/A8t/ChjFJP8JYO78+A1Ck30QPsgOaXnmSC7QZgXSqhEEMaz4pHJdxJWTMYr6IGWKJeJqWYl8LbSClVFL6p9ihPhpRoia1BdBvDHpFBLrF0zqDCnqxcqmvinUJ70aK8UvrTQkk61uogU1CCmdtB2bb0XwWCA2jwVLio4pNkUEW2x4MStCWjI/L61ZKkgiutKMwo8VVMGWzgqQShOw+ObrICC3J1NFb2oDbTIZRSKtZ2RWD0TlEEg5vO5M2vxMshHTRmyBI5IrvJBa6c+04Q6/0VZwTDeEFXWcHoWqFtNWLwLINqWHut4EppN4Ml8EG01oERsJ7y2QlR9IQdrNehIhxWRbXk94SV8yjR4bDcuySp9pVA8JNbq8L7ICI4IRyQYWJYBgRPO5hLweTdaIryFAmHYkEicJSLSYcnpg6KO6BAhFa6M9KjtcVZQusUd+gyWyFxoowHSD5c+AUfOR/wlgbv94B+Fpnogf7YDhZJDBdXoYNLkPMiYTOLyJOEE2Lz6MIIgoZw7lYyBvqjv8+XcAwREkBcD3xfAmIynColSw9ZT14ecNkECmSay0QHKlNVIqmaur6Eb4PJmtMrnSnJVmyjBBcpUJc7i++kxchRHZSRPRTDuRfD2cFRDKiggje8nzMNJ2ON8XzvfLYwz/FpAk5ZCmCd5EWtAktuYUVmIiHUQsK1QYM77Ckr9hQ/dhAtexOnAZq8t7E+HsD7+R1GnDreGUpg2jMIryBII/S5/XRh1EsEYLc5X3VUCIIpNJhFfS9rIRhUr/CMsi5A8RKmJVgmUlIeUZR7aIZ2qRSGSZSSSJDiE40mdoYfCD2hjzlBEyZ5sie54FchdYqG1AiptsULrYjhVpfy9s1Qh2yWIrFcVLTNSK026QaICiCQWWfwqYOz/fQOwgTwwu8lKLtQuftUPRPDuMZz4c/rAuhj7cF0Me1kP6LB2kTGerndqT0UtF3GSN+FIFxIIQ6pQCCGfhRPDvCD5G8jGKEU3BFsNKk5C+g0i2zIiCHhSLfL+EvI/fIy1NPi8tMLKUzKCouReZhVqErweR9fzJgP78TCA/HywsRrsZXKqtIoLvS+D/+jHS+Z0ZpPeMit5IJ+WnVOiQMRnVBFcpUygZKLSCLX+aDeJm2COQoPXI0qH49MCIqUHoX+OOIILJbSh/j9oimCD0Ha+pfLk+aRTRVb2UxY2pZdToILqGKYVlIiE6QxpQN0MksbySpzD42I+aY9ADvTHiMaaTpw2RPccchYtY+U32akCwsNEUZUtsUNluq6KizQblbZYqiheboqjZBAWNRmQVfYYh/zYiy/AzbXQ/FLn/vwHmq1+vI2GYO0Yzr09ZFIQpLbIviqNah1PSpEF0UbMN8hpt1B4w0vkzjjc3YZ4lMudbIXOOhWoJw5hLB07vgXQpDBZQP7aWND6mSr4liJJYgAlkqziyUlJ1byTSDiZIYUrr4nukUJNYqFKYMcJUfwrJ4cJcIvSEySQi5ZHfK6IvjK+H8v8RBFwyfyOVYJFIZsUmsIJjCbRIRjhDtXS+N6ySqaaaWoIVHsIKD67rgwgKzNDcPojJN6BINmTKEnakaCa7CjPI9Sr25PMYAiKW1x3Pa04gEJLYiJKm9cCgR/pi2GM6GPGEPkY/baD0ReYcsz8wBSud5Vq22FaFlLNEZcu9bTY6LFRHWtkSzQx+mc4pO2PIdh95i3ojd6E2H5luGuh4+D+18QFDpn4WNt9zQvdAogGKJjSbCPQmEAgMguXPgJEQkPxbwNz84TKiBthheIUzJi30xuQWRzUzvbDBABXtFsyPlvwRCxQuMUP+YjNUrXREWQeDdFi6REON1e3Omj1LmuxQtoA3TzCVzmeBLGBhLLBXjFUwh6B7zgY5z1kjZ44tsmdbIWu2BSY8b4LRz+hhxJPaGPpYDwx+RAvDH+uFoY/w+UM9MPABLQYr4cGeiqYHP9wH/WYSDIx+95M5Zmkj44G+SL8XIgSH87XhpPUh00jtzPsD+dhfYkYPDLi/FwbM6qM+l3Z/H6Q+QEYhk2Y8aoSMx40x4FETjHzUFgOmGGLYfWzJ89xQ1uSJrOesME5cCIWlLPUtXezAlm6rGpM8Fkt6aHNmeTmrsimTaQL3orSVaYQhOyBIlLcSHB3WatOgqnZLfp85Sppl3xlTtdWHbOshu0TkLtJSUdjUUy00q2jXVStLq5YaqvcULyaDNPXme2mTWaFqnRHZpeQeYLqB8v8UMLd/uYq4oQRMpQNq5rugpslczYfo/pCa0ENPL2uLuqNIdmhglLSYqZtVyy6bLdUWHtUNVqhl66lrtsckFmrdYkcVVfy7opEFSKaSeR8Ssg2YyrstZLMl5ihqNeX3k46bDNTCfpm9JsAtqDdUtJu3yOhemCC3nrHI7F6YI7v+9yhZzO+XUDtH/WtI5XY/Fi+2/z2ayaqMEkZpkzPKGyUcUU5GLSUo1MKvxRYMTe+oJqQMNCEdYfKaaIjSNrN7IffDv+U1hnovy1IWtsvWKDXtfA8Zom4pG2S99IcYqv10apbqoHqptoqqjt5MSb3UgrbuSpZtRv41NNM5JaRvRUIB5A9/S/z+/j9+1+9gkZD//1vA3Pn1CuKH2WNElb2aJyr7rMkUPUGsCqJVhcwGuxdFS/g3gST7oMhOA5q9TIzV3m0SZQtYKAuNULHIGJWs2Ip6M7WlV/FCFhRVfFkTC7JZ4l6BdwOyjUBlSCuRKOXvSKvpjt9uhHlahSzGYqX8XkFmbFlmKGAlFbTKo5liRoligrs7BOhS8RoAWPB+/yp4zRK8N5l4raF93rNch0R3uajW2/1cyoXX2sryU/cij9LoNJ+R3lMJDYNoo6aD39ncB3XLjAmYnkxHZI92DViqOrQYfK2dFdkmE8I1qwgk/lzhvwOhO/4nWP6fAeYrXEXCcAeMrCYbLHTBJLZ0WVvbPRG5m8ZELKkZ7WolozzXUZX62wJu2b+NAqyiXg/li/gaH+XvqkZZ9U/gkDHKyBiljbwQxWAaFhPgdReyCgKyknRaSQuoCXneBxUdpOR7IbSsNrr5Lfi5e1HcoY+8dn3ktpOR7oV0ZKl13QJMhlS+2jpD0oAAnaFZFy3P+b97wNCEgPZeod8rC03IUlkJjYDsDllD9Mc0IL2qv8Xi3ioEGCVMOTVL+Tv8e9IyfRTVEyB8f3U7wdLWi9GDjCMrIDWhVhEw1AK3P1SwJqTSNdENmL+OvwaMgOK3+N8B84liGAFMN8NoNrBhJckK/ns/8HuBsIBkNT9vSq34l5D3NjEoysqFWht1UEWRVsMfriEgalsN1KNmnzdeiFqHQ8DJWhxVIf9fd9f6XVVxxSOgKK8ooVYSEkCwRbCCCtSitUJrP1RxLZdYXbUlgbyAe29eBgS/VavyDIGbhFfCQ7HtcnW1/4sf+sWuKssq1IJQhYQkJru/356z7517cs7lQnXFy4ff2mfmnHvunjm/2bPnnJk9AIjiLIv76GXLLAhdXwzQNDcC9PINXLPjgzPw+dLqd323Q8JRZNQIPCBCVw8Cuh4aYDkJFz3KgfH3WOZ4coSA1p8D5Pn6cIkIwchbGw8hjQfOBlDXg4fA5SVIN5+E1U6DMGggJIxPBp8oBv+8Q5YwCn1uUbg2YVjevIS59PW/Ah+mHD5MFXyPmWhpU7XiMoFlghtbBWl0BkD7Vf4RHnBDD0iUxjUH8SAPUOLPurieeLKuKeYHLi7Squ9GPo+59pjx22iigYy1ImF4L1QM70vY/9NBU+B/uWrPB0msqwRhxjW6Ao41UA+grZ7X4KG7SmKoMRctirAwHQSjJ7iyjoX7bQhBRRscYUoURhaSxActZx1kCr4KyxkmzGYQKwx+HDToArR8QDmswefClduIFVWGAgkzR53exL65kuoqg9M6Q5cfGGlYiWSyrsRDRWhQHBDHhaPItgAut2RURn7xpGzsggeOcT3H9iQBA/HVMT9YoJ5Zf8MWT7IYggIybFYOgq4qkjQgMIP7KILWntHPw5hWSeJ4sIrMEiVrabItNIzcymfgIJ80tWpdPMLQSkKmjt8WQxjUGxpZDiwP0ukaQRQDn1kkab4Bwvx35Kw89sxcOL2VOkriWprmIGQFP2lnWh1JgR8SGg0zOFYnzCOMIrAKfMisBIJfRNUS8bqARCSNK8jtuBa+S9BlsftyAGkPI5/nFIy9xi4LBMS9/K5JozsF+rCAjN/Gz/IG5hHmE5A0WknQ07ciYZLkOI2BNTRooB9F9qGQQGZlrHFZfTHui4uhk4cw8A1JDMaa03hzaLQKPIeMVODaMZigMMKE8Y0Q5svRc/L42nnwYaok2blQmjHUTXUbYfDA+Gf4E5pFIw0LS7DwzHOg2YQiBK8HQXyyUEFWji4yH0MYWhOPGAFxSBY+EBd6lF0VKhjdmvlO9KPCoOUhQZIefNLkkEUryJHEuqwoojjkkiWXMEYa5PNavY/rnozERIYwqBP6MJkuyXd64cu5qJyE86nGAM8kjjQZSwl9HEmyMpYwBOsDUgmDcrj5MAFh8GyTIFEqXQ7CDH8mq9bOledS82RLJ+O+3AkfZjoUc8pakDwzg/Zn9ueOvVkHkqAVYPfDimAX1HJymtSyBXHkgLR1MZkCKFyhjESseJO5CHcHYXg6RiCnkhTud6yo3PuEEaWLD7sGZQGZeW9aQTq1JIUCjYkNhWV3BIET3jUB9YQRXPoWnR65BSNFNhT6g6zXJIjK403dk/SY3byr8xgE9al6hGR+uLpwhOGMO7oMjkS8JyO4pw5WjSXMpnQ2Pqwjgk+YABkF7Tyu1WiP+B0jPuqDn6jmlTLJoW9geUgkdWqDyovEmMIUF6wxsCxWVgfmsbFMDggzBYThsLpUY8ckMJp0hIHlUcLcdt2EcQ0vV5/rgSMMXwNAdyMM7pvsQa9zcN6NEMYxLkucgDBGGkhWCq0JK4mkoWTayEIrQzBteTcVYYIu2Hy2sIWhZXEW5Y7AwpSCQKwjdMXokouUMGGykCg+YkgTEIZWhd1Q03FGL4AvEaRZYT5hrBJZSOuqogpSTLg2YW4LEWZ6sROGliKOMM4JyiGOKmvXo1AgDC0LzW6q7w6p6YTTGaRZYWHLYmRhRRJRBSkmcNhPZ9F3dBUkDesOQ2eGc+NnAEpGrtqAxqQRLfHAi5gwUELJYoQxsuQjjVOYBKAV4TEtCyXTJIgPu/bmIQweLkZchRAm0QerGxCmBo2JhKHjrK8O/g/CROtVGG6IMNzWJTtUdF62G2XYSy8OTYngBZhdo9e7F260Hswzq2LdkVmVKNh9ogpSPDDCgBxhwgDMS/ShS1LCOJklDEcmHEVN1q6KdWkjKTrMPOabcqvnOETrVRhunDDwRXJIo4QhfNLYsSOHKUwrQWvCbmh9hxtOV+93w2l2RSQHiROGdVVRBSkeFEYYvocJE4a/L0rCNPZMg5MGU6iAecQNWBDegAXWlzw+cFMH96ckhlqKPMQwx9dgPg3hF6D4AP17UW6QRr9xoX7sBZ5+LAVpfoPGU40y7/grN7G6Q16Gj/f8ThDnnVJF6sQ0WY88ftVmN7Wx6xY95nPYwklUOe9/ohClV2EgYfiikjMSlPzwx+hTMVpVU3r+WMI0pGdKYzf30+FXZWIsabRSrkGYKNL4XY8d+3n2O78AxQh9cwyChL8hMU0kTnJax0RZj2563a4SaftjmRJly/Gpwhl2DFvLrXZIDiMMJadCjBdhaGHyEKYUD9iFrooiTZYguUQxhdkF+YTxSWHEsGM/j79jN+YXoBjhCOOmMjC0PsHAyXwYjIzOOTEv7imR7X+ZLS2n79LjF0Ccbe/PRncwWVpAHnZRib4pGcKwXjmHxhzj/IjWqxCECUMYYSK7JBKGM+J0I4QY0rib+0QhsgqbpTAyhMliBApbHRKGyL1v8YGTvDRkPqwI58AoWVgvIEAC3Q2/SyVOzFByrENX1P5nhmjlzH83R7f13Tt1mE3CsCsywjB4tF/P8YjWqxD4PowRJq8P05CeBcJwUjIRTKO02XFwgllI/RgXMDELNxGKCvtE8QlhRPLz/XO0LjeDhSFhOCOR32O4dxShu4EcnyZbTs6AjzNNXthdIlvfL5fm07PkpX0l8uJepueoP9P87kypBmFIMM4urAFhWMecDJ5b59GI0qlQ+ITxnV7ORsxDmO9JHWGk0Q0LsqRx5PCVtLyANIccKcx3MUtixDBCWdq6Ir7k45vhqIIUC7TbQbfBmX0bMWLZgLogGD6DU1A1/PuJUg0vX9MNC4OuiERJnipD1zVFydP0zl2yHl0SCcN7GWG4koDp3Lofiyi9CgX116mkAWEII0zywNwYwnS5dTJZ0tDKkDRGGJvrarD5r0E+hn42RDb4pDHL4pPopiEMHphOYOeHRdSHTfwm3Pxlt3botwduldf+tgAW5h6MmibqKCl16h6MnmD+T5aq88tlJUYYSj5I5oUJEkaUXoXCCLMR3agRhvNzMoS5NHJGVj07W55rqgJh5ithSJTawLow8jTJwgk1Ok8CD5dK6URwmi9KTWcVru1Cfgj13XyZh8LADwrnM4/vfPgtRbctDu4z7hI6Xb/EULhvujT0seuBDwjJXVm5ikC3OTwyXdr+VCE1sCbVXbfLSx0TpPW9OZJ6dzbIUCbPvoHRESzQyyCMTm5HV8ZdUXhMK9XYB9Lx3UwMso24UH3Hyg0gDrdg5GxB+mH0Xbm9cuIgCHNZPpTla6fKuq1zpHZXuSSPlAuXVdiWuG7iNEhwjJOM4MD14iYAd1qLkrxGHWQ6yzHgjH1KRruu60KlQDKPi7i4Voer/NgK46TNCPv2JR5whOSaoo2HYD16UD9BvqV1D8xjpbpKYePhaVJ9eKrKjVzJ2HunNJyYhS5qutQcQSM8UqrBfbh2aQPXKh2eoec2nygDMbh8hnnTkOfuEV4fFgcGCsqnP1dU6n4HEZLLYrgT8Ibjt0p1L4b+IAzrnHtlb6aF+UI+kFXPl8qv2+foFrXcCV4Xa+mSDJLG1uDAIgSk0XmzIEgGTGcwERYK13eBEGn4PRGS65h0w0suO+meru99uPVuglvdcnEXKpn/HSe5YaUr4LclWYF4wNeQXJDG9VEmLZ8PmBZkPSyI7mwC8Jgh4JnP80YCH5bvE4YksfNGGP83UaAOUfqa5GbpjSBvlKRFrD+F/zg5XWoxoqujhTzKyOUVkkwvQpckf5cVT0+VZxrvltb0cmk5tFiSR+HPHKsEKmRL72zg+8L1vm7PH9yc3YaCXjwRpNGquHovO8UyWtqSE06F0L0SeQ4PqhkmnPtD16GbooPH9w7jIvX/MSzOI7lMlYvQOGqkybY0z7ecLpPm98qk6fRMdDV3KZLvoEGcKlWwe7HuxoflcyS1+QQaErqf8Hnm5cOmXhAROsTpfU1JKw4XpOZwGaxmGawmB0D3SEPnPNm0d7GUDMhH8uDqKfJMLQjy9gpJ7Fsq9XsWSu2+uVK/r1JqOyogyyFheTrultr9ZVIPOAkfpxMtwdIds/SYKx8bOlH4GNTvRwUAdR2wRACPmd94AIWGFUqiS+R+kuMH/n9+JNCNEMljIANgaZ6rPYjuE/DlhgPc4YTf1EC2IF2D4/Udk6SawDE36+L1XOxXm0YX5/2O0s7X8RwQJYmwrmFs5mrVGHBdfX13JUbKC2Qzw9T3cIujRZLsfFASe1dwk1CMkn4FYmx7QprffEpadq+W9gM/k7b049J+cBXko9KeXiltXY9Ie9dD0ta9VHYcWS6vHn1YdgAqNb0ccqXLO7IEWBSLHccWR+K13iWyve9+aeqqlFQeNHVXjSvi9LD85p65irbD86XtyL3yCmCyFXntRxdomudbDs3TLZ2Zz/Ov4Nz24z+UV4m+H8g2ovc+2QpYeuuxhdIOxMmwXmGYnpFI34vBD/flfERSnculuXOFNO1fKc17V0nTztVSMirnZc3aJfJiw0+lbtsvZfuedZL4/c+BJyXx+hPA48AqSbzxE+DHwApJvrk8F39YGeBRlYwTm3gTjLwGkm8tHYMtlLuXSXIPzsfIpr0PS9M+bhQ1PpJ6cG+o1J6HMvmWpn4J7nq28wFJ7kLe7gcBXLNnKSqdexUtgyX/EbBENr/1ALA4I+Pyr1deS3/qafqOkXtAkJ0wHjt/Ic271kjrzjXS8vZqaX3rKWl9/Wkp+fiTD+SxJ++XioWM4j1Jyu+bKAuWTpYFyyYFmCALHirJ4mHGzo0BN0CgXFYiVXkwB9cYuHECYekK3INx82fjOE5W4PoK3Ge8JPUo53Eov5w6AloWXFPxAPKWOMk066YK185DPRLzUZc+LJ/XGvgbg+WxfuNQhd/H6e3rSf2jJOu/kv8DnSug+5zFWVQuKpESkcty/ouP5crg5zIqX0n/8FkZln8DlMSnwCfAGeBj4J8RYD5xRgZx7YCcA/6TF1dh2YhBuZA5Zv4V/Hf42u8ifP3DZRhG+mvN/xzpc9I/elYl00M4b+mrKCvzCB7btf55u8aO/fwoDCiidS4E7r+o66cyMPqR9I/8A/hQ5cDIGSkZGbkiQ4OX5eKlz+X8hbPy1eUvZHjkS+BSgIsyPHoBQEWMgkjA0Mi5EFARivMy9PVFGRzul4HhoRvG5asD8tXglVhcGR74zqIfGBy+mhdXhwbyIuo31wPqEKVbIegfviL9AxdlYOCCDAyCREMg7xDIA/QPfib/Axzzyry/uhNHAAAAAElFTkSuQmCC","note":"Logo"} */
export interface RMSCloudReservationDocumentation {
  /** @format base64 */
  documentContent?: string
  documentName?: string
  note?: string
}

/** @example {"id":3681,"activeMealPlanId":3,"activityId":25,"accountId":1259,"adults":2,"additional1":1,"additional2":2,"additional3":1,"additional4":0,"additional5":0,"additional6":2,"additional7":2,"allotmentAssociationID":"TravelAgent","allotmetnId":12457,"areaId":5,"areaName":"Room 7","areaNameLike":"01","arrivalDate":"2016-28-08 13:26:00","attendees":"30","billing":"Personal Account","boatId":6,"bookerContactId":4,"bookingSourceId":2,"bookingSourceName":"Online","businessLostId":12,"businessSegmentId":9,"cancellationPolicyId":1,"cancelledDate":"2016-08-26 12:26:00","cancelledById":6,"cardId":"A698659","categoryId":19,"categoryName":"Super Delux Queen","chargeToRoomLimit":300,"children":1,"companyId":5,"confirmedDate":"2016-08-22 19:25:00","confirmedById":5,"contactId":9,"coordinator1Id":8,"coordinator2Id":7,"createdDate":"2016-08-22 19:25:00","createdById":35,"departureDate":"2019-09-29 09:25:00","deposit":20,"depositDate":"2019-09-29 09:25:00","destinationCodeId":6,"discountId":0,"discountReasonId":0,"eta":"Wednesday Midnight","eventFinish":"2016-08-29 09:25:00","eventName":"Concert","eventStart":"2019-08-29 09:25:00","externalCancelId":"bcom39658965","externalReservationId":"uy96598568","fixedRes":true,"fixedResReason":1,"groupAllotmentId":7,"groupOptionId":1314,"groupReservationId":96598,"groupHeader":true,"guestGiven":"Smithers","guestId":65,"guestSurname":"Westingham","housekeepingNote":"housekeeping note","infants":1,"longTerm":true,"loyaltyMembershipTypeId":12,"marketSegmentId":12,"mealPlanId":16,"ModifiedDate":"2016-08-22 19:25:00","modifiedById":50,"notes":"This is a note about my reservation","occupantId":4,"onlineConfirmationId":12986985,"originId":9,"otaNotes":"Booking.com - breakdown of pricing, etc","otaRef1":"V5986985s9","otaRef2":"BCOM-8976958","otaRef3":"89869858896","paymentModeId":45,"posOnGroupMaster":false,"preAuthAmount":23.56,"preAuthCode":"2A","preAuthExpDate":"2016-08-29 09:25:00","propertyId":1,"rateElementId":1,"rateOnGroup":false,"rateTypeId":3,"rateTypeName":"Daily","resTypeId":8,"reservationType":"Event","secondDeposit":15,"secondDepositDate":"2016-08-29 09:25:00","secondDiscountReasonId":0,"splitReservationId":12358,"status":"Confirmed","subMarketSegmentId":9,"subResTypeId":5,"travelAgentId":7,"travelAgentName":"Bopoking.com","upgradeReasonId":33,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","voucherId":"B4569856985","wholesalerId":58} */
export interface RMSCloudReservationFull {
  /** @format int32 */
  additional1?: number
  /** @format int32 */
  additional2?: number
  /** @format int32 */
  additional3?: number
  /** @format int32 */
  additional4?: number
  /** @format int32 */
  additional5?: number
  /** @format int32 */
  additional6?: number
  /** @format int32 */
  additional7?: number
  /** @format int32 */
  coordinator1Id?: number
  /** @format int32 */
  coordinator2Id?: number
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  /** @maxLength 50 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  activeMealPlanId?: number
  /** @format int32 */
  activityId?: number
  /** @format int32 */
  adults?: number
  /** Required when using combinations of Travel Agent, Group Allotments and Wholesalers */
  allotmentAssociationID?: string
  /** @format int32 */
  allotmentId?: number
  /** @format int32 */
  areaId?: number
  areaName?: string
  areaNameLike?: string
  /** @format date-time */
  arrivalDate?: string
  attendees?: string
  billing?: string
  /** @format int32 */
  boatId?: number
  /** @format int32 */
  bookerContactId?: number
  /** @format int32 */
  bookingSourceId?: number
  bookingSourceName?: string
  /** @format int32 */
  businessLostId?: number
  /** @format int32 */
  businessSegmentId?: number
  /** @format int32 */
  cancellationPolicyId?: number
  /** @format int32 */
  cancelledById?: number
  /** @format date-time */
  cancelledDate?: string
  cardId?: string
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format currency */
  chargeToRoomLimit?: number
  /** @format int32 */
  children?: number
  /** @format int32 */
  companyId?: number
  /** @format int32 */
  confirmedById?: number
  /** @format date-time */
  confirmedDate?: string
  /** @format int32 */
  contactId?: number
  /** @format int64 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  departureDate?: string
  /** @format currency */
  deposit?: number
  /** @format date-time */
  depositDate?: string
  /** @format int32 */
  destinationCodeId?: number
  /** @format int32 */
  discountId?: number
  /** @format int32 */
  discountReasonId?: number
  eta?: string
  /** @format date-time */
  eventFinish?: string
  eventName?: string
  /** @format date-time */
  eventStart?: string
  externalCancelId?: string
  externalReservationId?: string
  fixedRes?: boolean
  /** @format int32 */
  fixedResReasonId?: number
  /** @format int32 */
  groupAllotmentId?: number
  groupHeader?: boolean
  /** @format int32 */
  groupOptionId?: number
  /** @format int32 */
  groupReservationId?: number
  guestGiven?: string
  /** @format int32 */
  guestId?: number
  guestSurname?: string
  housekeepingNote?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  infants?: number
  longTerm?: boolean
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  /** @format int64 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  notes?: string
  /** @format int32 */
  occupantId?: number
  /** @format int32 */
  onlineConfirmationId?: number
  /** @format int32 */
  originId?: number
  otaNotes?: string
  /** @format int32 */
  paymentModeId?: number
  posOnGroupMaster?: boolean
  preArrivalCheckComplete?: boolean
  /** @format currency */
  preAuthAmount?: number
  preAuthCode?: string
  /** @format date-time */
  preAuthExpDate?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  rateElementId?: number
  rateOnGroup?: boolean
  /** @format int32 */
  rateTypeId?: number
  rateTypeName?: string
  resType?: string
  /** @format int32 */
  resTypeId?: number
  reservationType?: string
  /** @format currency */
  secondDeposit?: number
  /** @format date-time */
  secondDepositDate?: string
  /** @format int32 */
  secondDiscountReasonId?: number
  /** @format int32 */
  splitReservationId?: number
  status?: string
  /** @format int32 */
  subMarketSegmentId?: number
  /** @format int32 */
  subResTypeId?: number
  /** @format int32 */
  travelAgentId?: number
  travelAgentName?: string
  /** @format int32 */
  upgradeReasonId?: number
  voucherId?: string
  /** @format int32 */
  wholesalerId?: number
}

/** @example {"id":0,"expiryDate":"2024-09-18 00:00:00","guestId":1235678,"guestEmail":"vic@rms.com.au","guestGiven":"Smithers","guestMobile":"04123456987","guestSurname":"French","note":"This is a note about my reservation","status":"Pencil","pencils":[{"id":0,"areaId":20,"arrivalDate":"2024-10-21 14:00:00","categoryId":4,"departureDate":"2024-10-22 11:00:00"},{"id":0,"areaId":21,"arrivalDate":"2024-10-21 14:00:00","categoryId":4,"departureDate":"2024-10-22 11:00:00"}]} */
export interface RMSCloudReservationGroupPencil {
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  departureDate?: string
  /** @format date-time */
  expiryDate?: string
  guestEmail?: string
  guestGiven?: string
  /**
   * If you wish to create a pencil reservation with an existing guest, populate the guestId field and leave the other guest fields blank (If the other guest fields are populated they will be ignored). Alternatively, if you do not have an existing guestId populate the guest values i.e. guestName etc and we will create a guest for you and return the guestId in the response
   * @format int32
   */
  guestId?: number
  guestMobile?: string
  guestSurname?: string
  /** @format int32 */
  id?: number
  note?: string
  pencils?: number[]
  /** This field is informational, any changes made will not be honoured */
  status?: RMSCloudReservationStatus
}

/** @example {"id":216814,"expiryDate":"2024-09-18 00:00:00","guestId":1235678,"guestEmail":"vic@rms.com.au","guestGiven":"Smithers","guestMobile":"04123456987","guestSurname":"French","note":"This is a note about my reservation","status":"Pencil","pencils":[{"id":216815},{"areaId":20},{"arrivalDate":"2024-10-21 14:00:00"},{"categoryId":4},{"departureDate":"2024-10-22 11:00:00"},{"id":216816},{"areaId":21},{"arrivalDate":"2024-10-21 14:00:00"},{"categoryId":4},{"departureDate":"2024-10-22 11:00:00"}]} */
export interface RMSCloudReservationGroupPencilResponse {
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  departureDate?: string
  /** @format date-time */
  expiryDate?: string
  guestEmail?: string
  guestGiven?: string
  /** @format int32 */
  guestId?: number
  guestMobile?: string
  guestSurname?: string
  /** @format int32 */
  id?: number
  note?: string
  pencils?: number[]
  /** This field is informational, any changes made will not be honoured */
  status?: RMSCloudReservationStatus
}

/** @example {"id":5,"holdExpired":true,"dateFrom":"2020-10-23 00:00:00","rateId":1277,"dateTo":"2020-10-27 00:00:00"} */
export interface RMSCloudReservationHold {
  /** @format date */
  dateFrom?: string
  /** @format date */
  dateTo?: string
  holdExpired?: boolean
  /** @format int32 */
  id?: number
  /** @format int32 */
  rateId?: number
}

/** @example {"reservationId":124356,"holds":[{"id":5,"holdExpired":true,"dateFrom":"2020-10-23 00:00:00","rateId":1277,"dateTo":"2020-10-27 00:00:00"}]} */
export interface RMSCloudReservationHoldArray {
  holds?: RMSCloudReservationHold
  /** @format int32 */
  reservationId?: number
}

/** @example {"departureClean":false,"housekeeperId":45,"housekeeperName":"Hayden Paterson","id":7,"linenChange":true,"note":"","taskDate":"2023-04-20 00:00:00","taskName":"Linen Change","taskMinutes":30,"reservationId":213691} */
export interface RMSCloudReservationHousekeepingArray {
  departureClean?: boolean
  /** @format int32 */
  housekeeperId?: number
  housekeeperName?: string
  /** @format int32 */
  id?: number
  linenChange?: boolean
  note?: string
  /** @format int32 */
  reservationId?: number
  /** @format date-time */
  taskDate?: string
  /** @format date-time */
  taskMinutes?: any
  taskName?: string
}

/** @example {"fromDate":"2023-04-20","reservationIds":[213691,213296],"toDate":"2023-04-20"} */
export interface RMSCloudReservationHousekeepingSearch {
  /** @format date */
  fromDate?: string
  reservationIds?: number[]
  /** @format date */
  toDate?: string
}

/** @example {"id":3681,"accountId":1259,"areaId":5,"arrivalDate":"2017-11-12 02:03:44","cancelledDate":"2017-11-25 17:25:00","categoryId":19,"departureDate":"2017-11-13 14:00:00","guestId":65,"rateTypeId":3,"rateTypeName":"Daily","status":"Confirmed"} */
export interface RMSCloudReservationLite {
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  areaId?: number
  /** @format date-time */
  arrivalDate?: string
  /** @format date-time */
  cancelledDate?: string
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  departureDate?: string
  /** @format int32 */
  guestId?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  rateTypeId?: number
  rateTypeName?: string
  status?: string
}

/** @example {"id":43196,"sundryId":313,"sundryDescription":"Fancy Pants Package","quantity":2,"perAdult":5,"perChild":5,"perInfant":0,"perAdditional1":0,"perAdditional2":0,"perAdditional3":0,"perAdditional4":0,"perAdditional5":0,"showOnccount":false,"applyChargeDescription":"On The 1st Period (Determined by Tariff Table - Hourly, Nightly or Daily)"} */
export interface RMSCloudReservationPackageArray {
  /** @format decimal */
  perAdditional1?: number
  /** @format decimal */
  perAdditional2?: number
  /** @format decimal */
  perAdditional3?: number
  /** @format decimal */
  perAdditional4?: number
  /** @format decimal */
  perAdditional5?: number
  applyChargeDescription?: string
  /** @format int32 */
  id?: number
  /** @format decimal */
  perAdult?: number
  /** @format decimal */
  perChild?: number
  /** @format decimal */
  perInfant?: number
  /** @format int32 */
  quantity?: number
  showOnccount?: boolean
  sundryDescription?: string
  /** @format int32 */
  sundryId?: number
}

/** @example {"activityId":25,"accountId":1259,"adults":2,"additional1":1,"additional2":2,"additional3":1,"additional4":0,"additional5":0,"additional6":2,"additional7":2,"allotmentAssociationID":"TravelAgent","areaId":5,"areaName":"Room 7","arrivalDate":"2016-28-08 13:26:00","attendees":"30","baseRateOverride":0,"totalRateOverride":0,"billing":"Personal Account","billingCategoryId":0,"boatId":6,"bookerContactId":4,"bookingSourceId":2,"bookingSourceName":"Online","businessLostId":12,"businessSegmentId":9,"cancellationPolicyId":1,"cancelledDate":"2016-08-26 12:26:00","cancelledById":6,"cardId":"A698659","categoryId":19,"categoryName":"Super Delux Queen","children":1,"companyId":5,"confirmedDate":"2016-08-22 19:25:00","confirmedById":5,"contactId":9,"coordinator1Id":8,"coordinator2Id":7,"createdDate":"2016-08-22 19:25:00","createdById":35,"departureDate":"2019-09-29 09:25:00","deposit":20,"depositDate":"2019-09-29 09:25:00","destinationCodeId":6,"discountReasonId":0,"eta":"Wednesday Midnight","eventFinish":"2016-08-29 09:25:00","eventName":"Concert","eventStart":"2019-08-29 09:25:00","externalCancelId":"bcom39658965","externalReservationId":"uy96598568","fixedRes":true,"fixedResReason":1,"groupAllotmentId":7,"groupOptionId":1314,"groupReservationId":96598,"groupHeader":true,"guestGiven":"Smithers","guestId":65,"guestSurname":"Westingham","housekeepingNote":"housekeeping note","infants":1,"longTerm":true,"loyaltyMembershipTypeId":12,"marketSegmentId":12,"mealPlanId":16,"ModifiedDate":"2016-08-22 19:25:00","modifiedById":50,"notes":"This is a note about my reservation","occupantId":4,"onHold":false,"onlineConfirmationId":12986985,"originId":9,"otaNotes":"Booking.com - breakdown of pricing, etc","otaRef1":"V5986985s9","otaRef2":"BCOM-8976958","otaRef3":"89869858896","paymentModeId":45,"posOnGroupMaster":false,"preArrivalCheckComplete":"false,","preAuthAmount":23.56,"preAuthCode":"2A","preAuthExpDate":"2016-08-29 09:25:00","propertyId":1,"rateOnGroup":false,"rateTypeId":3,"rateTypeName":"Daily","resTypeId":8,"reservationType":"Event","secondDeposit":15,"secondDepositDate":"2016-08-29 09:25:00","secondDiscountReasonId":0,"splitReservationId":12358,"status":"Confirmed","subMarketSegmentId":9,"subResTypeId":5,"travelAgentId":7,"travelAgentName":"Bopoking.com","upgradeReasonId":33,"userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","voucherId":"B4569856985","wholesalerId":58} */
export interface RMSCloudReservationPatch {
  /** @format int32 */
  additional1?: number
  /** @format int32 */
  additional2?: number
  /** @format int32 */
  additional3?: number
  /** @format int32 */
  additional4?: number
  /** @format int32 */
  additional5?: number
  /** @format int32 */
  additional6?: number
  /** @format int32 */
  additional7?: number
  /** @format int32 */
  coordinator1Id?: number
  /** @format int32 */
  coordinator2Id?: number
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  /** @maxLength 50 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  activityId?: number
  /** @format int32 */
  adults?: number
  /** Required when using combinations of Travel Agent, Group Allotments and Wholesalers */
  allotmentAssociationID?: string
  /** @format int32 */
  areaId?: number
  areaName?: string
  /** @format date-time */
  arrivalDate?: string
  attendees?: string
  /**
   * If you pass a value here the base rate will appear overridden and RMS will pro rata the nightly rate minus any Inclusive Packages or Inclusive Taxes
   * @format int32
   */
  baseRateOverride?: number
  billing?: string
  /** @format int32 */
  billingCategoryId?: number
  /** @format int32 */
  boatId?: number
  /** @format int32 */
  bookerContactId?: number
  /** @format int32 */
  bookingSourceId?: number
  bookingSourceName?: string
  /** @format int32 */
  businessLostId?: number
  /** @format int32 */
  businessSegmentId?: number
  /** @format int32 */
  cancellationPolicyId?: number
  /** @format int32 */
  cancelledById?: number
  /** @format date-time */
  cancelledDate?: string
  cardId?: string
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format int32 */
  children?: number
  /** @format int32 */
  companyId?: number
  /** @format int32 */
  confirmedById?: number
  /** @format date-time */
  confirmedDate?: string
  /** @format int32 */
  contactId?: number
  /** @format int64 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  departureDate?: string
  /** @format currency */
  deposit?: number
  /** @format date-time */
  depositDate?: string
  /** @format int32 */
  destinationCodeId?: number
  /** @format int32 */
  discountReasonId?: number
  eta?: string
  /** @format date-time */
  eventFinish?: string
  eventName?: string
  /** @format date-time */
  eventStart?: string
  externalCancelId?: string
  externalReservationId?: string
  fixedRes?: boolean
  /** @format int32 */
  fixedResReasonId?: number
  /** @format int32 */
  groupAllotmentId?: number
  groupHeader?: boolean
  /** @format int32 */
  groupOptionId?: number
  /** @format int32 */
  groupReservationId?: number
  guestGiven?: string
  /** @format int32 */
  guestId?: number
  guestSurname?: string
  housekeepingNote?: string
  /** @format int32 */
  infants?: number
  longTerm?: boolean
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  /** @format int64 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  notes?: string
  /** @format int32 */
  occupantId?: number
  onHold?: boolean
  /** @format int32 */
  onlineConfirmationId?: number
  /** @format int32 */
  originId?: number
  otaNotes?: string
  /** @format int32 */
  paymentModeId?: number
  posOnGroupMaster?: boolean
  preArrivalCheckComplete?: boolean
  /** @format currency */
  preAuthAmount?: number
  preAuthCode?: string
  /** @format date-time */
  preAuthExpDate?: number
  /** @format int32 */
  propertyId?: number
  rateOnGroup?: boolean
  /** @format int32 */
  rateTypeId?: number
  rateTypeName?: string
  resType?: string
  /** @format int32 */
  resTypeId?: number
  reservationType?: string
  /** @format currency */
  secondDeposit?: number
  /** @format date-time */
  secondDepositDate?: string
  /** @format int32 */
  secondDiscountReasonId?: number
  /** @format int32 */
  splitReservationId?: number
  status?: string
  /** @format int32 */
  subMarketSegmentId?: number
  /** @format int32 */
  subResTypeId?: number
  /**
   * If you pass a value here the total rate will appear overridden and RMS will pro rata the nightly rate minus any Packages or Exclusive Taxes. If both baseRateOverride & totalRateOverride are passed in with a value then the totalRateOverride is used
   * @format int32
   */
  totalRateOverride?: number
  /** @format int32 */
  travelAgentId?: number
  travelAgentName?: string
  /** @format int32 */
  upgradeReasonId?: number
  voucherId?: string
  /** @format int32 */
  wholesalerId?: number
}

/** @example {"id":0,"areaId":16,"arrivalDate":"2019-10-22 14:00:00","categoryId":4,"departureDate":"2019-10-23 11:00:00","expiryDate":"2019-10-18 00:00:00","guestId":1235678,"guestEmail":"vic@rms.com.au","guestGiven":"Smithers","guestMobile":"04123456987","guestSurname":"French","note":"This is a note about my reservation","status":"Pencil"} */
export interface RMSCloudReservationPencil {
  /** @format int32 */
  areaId: number
  /** @format date-time */
  arrivalDate: string
  /** @format int32 */
  categoryId: number
  /** @format date-time */
  departureDate: string
  /** @format date-time */
  expiryDate: string
  guestEmail?: string
  guestGiven?: string
  /**
   * If you wish to create a pencil reservation with an existing guest, populate the guestId field and leave the other guest fields blank (If the other guest fields are populated they will be ignored). Alternatively, if you do not have an existing guestId populate the guest values i.e. guestName etc and we will create a guest for you and return the guestId in the response
   * @format int32
   */
  guestId?: number
  guestMobile?: string
  guestSurname: string
  /** @format int32 */
  id?: number
  note?: string
  /** This field is informational, any changes made will not be honoured */
  status?: RMSCloudReservationStatus
}

/** @example {"amount":26.9,"dateFrom":"2019-10-23 00:00:00","dateTo":"2019-10-21 00:00:00","quantity":2,"requirementId":2,"secondCurrency":0,"masterRequirementId":518,"name":"Custom Description","amountOverride":{"feeType":"PerPeriod","perAdult":0,"perChild":0,"perInfant":0,"unitPrice":12}} */
export interface RMSCloudReservationRequirement {
  /** @format decimal */
  amount?: number
  amountOverride?: RMSCloudReservationRequirementOverride[]
  /** @format date-time */
  dateFrom: string
  /** @format date-time */
  dateTo: string
  /** @format int32 */
  masterRequirementId?: number
  name?: string
  /** @format int32 */
  quantity: number
  /** @format int32 */
  requirementId: number
  /** @format decimal */
  secondaryCurrency?: number
}

/** @example {"amount":26.9,"dateFrom":"2019-10-23 00:00:00","dateTo":"2019-10-21 00:00:00","id":2,"quantity":2,"name":"Early check in online. 12 noon check in.","reservationId":21548} */
export interface RMSCloudReservationRequirementArray {
  /** @format decimal */
  amount?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format int32 */
  id?: number
  name?: string
  /** @format int32 */
  quantity?: number
  /** @format int32 */
  reservationId?: number
}

export interface RMSCloudReservationRequirementOverride {
  feeType?: RMSCloudReservationRequirementOverrideFeeTypeEnum
  /** @format decimal */
  perAdult?: number
  /** @format decimal */
  perChild?: number
  /** @format decimal */
  perInfant?: number
  /** @format decimal */
  unitPrice?: number
}

export enum RMSCloudReservationRequirementOverrideFeeTypeEnum {
  PerPerson = 'PerPerson',
  PerPeriod = 'PerPeriod',
}

/** @example {"accountIds":[12,5,702],"areaIds":[1,5,4],"areaNames":["207,208,209"],"areaNameLike":"01","arriveFrom":"2018-09-25 00:00:00","arriveTo":"2018-09-27 00:00:00","categoryIds":[2,5,9],"createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","departFrom":"2018-09-25 00:00:00","departTo":"2018-09-27 00:00:00","groupReservationIds":[1059,1045],"guestSurname":["Smith","anderson"],"guestIds":[42,459,8],"includeGroupMasterReservations":"ExcludeGroupMasters","includeInterconnecterSiblings":false,"includeRoomMoveHeaders":false,"limitProjectedRevenueToDateRange":false,"otaReferences":["gh1232","g5444"],"propertyCodes":["WCF","TCG"],"propertyIds":[1,3,17],"reservationIds":[124,8699,2547],"roomMoveReservationIds":[7589,12],"listOfStatus":["confirmed","departed"],"modifiedFrom":"2018-09-25 00:00:00","modifiedTo":"2018-09-27 00:00:00","projectedRevenueFromDate":"2018-09-25 00:00:00","projectedRevenueToDate":"2018-09-27 00:00:00","rmsOnlineConfirmationIds":[1023456,10245985],"regoNumbers":["A7T778,ARE895"],"reservationIdFrom":122,"reservationIdTo":125,"voucherIds":["A984646,B.com98464564"],"userDefined1\"":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50"} */
export interface RMSCloudReservationSearch {
  userDefined1?: string
  userDefined10?: string
  userDefined2?: string
  userDefined3?: string
  userDefined4?: string
  userDefined5?: string
  userDefined6?: string
  userDefined7?: string
  userDefined8?: string
  userDefined9?: string
  accountIds?: number[]
  areaIds?: number[]
  areaNameLike?: string
  areaNames?: string[]
  /** @format date-time */
  arriveFrom?: string
  /** @format date-time */
  arriveTo?: string
  categoryIds?: number[]
  /** @format date-time */
  checkOutFrom?: string
  /** @format date-time */
  checkOutTo?: string
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  /** @format date-time */
  departFrom?: string
  /** @format date-time */
  departTo?: string
  groupReservationIds?: number[]
  guestIds?: number[]
  guestSurname?: string[]
  /** @default "excludeGroupMasters" */
  includeGroupMasterReservations?: RMSCloudReservationSearchIncludeGroupMasterReservationsEnum
  includeInterconnecterSiblings?: boolean
  includeRoomMoveHeaders?: boolean
  limitProjectedRevenueToDateRange?: boolean
  /** Valid Reservation Status */
  listOfStatus?: RMSCloudReservationSearchListOfStatusEnum[]
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  otaReferences?: string[]
  /** @format date-time */
  projectedRevenueFromDate?: string
  /** @format date-time */
  projectedRevenueToDate?: string
  propertyCodes?: string[]
  propertyIds?: number[]
  regoNumbers?: string[]
  /** @format int32 */
  reservationIdFrom?: number
  /** @format int32 */
  reservationIdTo?: number
  reservationIds?: number[]
  rmsOnlineConfirmationIds?: number[]
  roomMoveReservationIds?: number[]
  voucherIds?: string[]
}

/** @default "excludeGroupMasters" */
export enum RMSCloudReservationSearchIncludeGroupMasterReservationsEnum {
  ExcludeGroupMasters = 'excludeGroupMasters',
  IncludeGroupMasters = 'includeGroupMasters',
  OnlyGroupMasters = 'onlyGroupMasters',
}

export enum RMSCloudReservationSearchListOfStatusEnum {
  Unconfirmed = 'unconfirmed',
  Confirmed = 'confirmed',
  Arrived = 'arrived',
  Departed = 'departed',
  Cancelled = 'cancelled',
  Maintenance = 'maintenance',
  Quote = 'quote',
  StopSell = 'stopSell',
  OwnerOccupied = 'ownerOccupied',
  NoShow = 'noShow',
  Pencil = 'pencil',
}

/** @example {"status":"cancelled","reasonid":1,"cancellationNote":"Change Plans"} */
export interface RMSCloudReservationStatus {
  /** Free type note field used to add optional cancellation note */
  cancellationNote?: string
  /**
   * reasonId is an optional field that can be passed with the staus 'cancelled'. You can retrieve a list of cancellation related reasonIds via the call GET/reasons
   * @format int32
   */
  reasonId?: number
  /** Valid Reservation Status */
  status?: RMSCloudReservationStatusStatusEnum
}

/** Valid Reservation Status */
export enum RMSCloudReservationStatusStatusEnum {
  Unconfirmed = 'unconfirmed',
  Confirmed = 'confirmed',
  Arrived = 'arrived',
  Departed = 'departed',
  Cancelled = 'cancelled',
  Maintenance = 'maintenance',
  Quote = 'quote',
  StopSell = 'stopSell',
  OwnerOccupied = 'ownerOccupied',
  NoShow = 'noShow',
  Pencil = 'pencil',
}

/** @example {"percentage":{"percentage":3,"noGreaterThan":12,"includePackage":true,"includeAdditionals":true,"appliestoTotalRate":false},"amount":{"amount":15}} */
export interface RMSCloudReservationsDiscountOverride {
  amount?: RMSCloudReservationsDiscountOverrideAmount
  percentage?: RMSCloudReservationsDiscountOverridePercentage
}

export interface RMSCloudReservationsDiscountOverrideAmount {
  /** @format int32 */
  amount?: number
}

export interface RMSCloudReservationsDiscountOverridePercentage {
  appliesToTotalRate?: boolean
  includeAdditionals?: boolean
  includePackage?: boolean
  /** @format int32 */
  noGreaterThan?: number
  /** @format int32 */
  percentage?: number
}

/** @example {"reservationIds":[219970,219971,219972],"patch":{"activityId":25,"accountId":1259,"adults":2,"additional1":1,"additional2":2,"additional3":1,"additional4":0,"additional5":0,"additional6":2,"additional7":2,"allotmentAssociationID":"TravelAgent","areaId":5,"areaName":"Room 7","arrivalDate":"2016-28-08 13:26:00","attendees":"30","baseRateOverride":0,"totalRateOverride":0,"billing":"Personal Account","billingCategoryId":0,"boatId":6,"bookerContactId":4,"bookingSourceId":2,"bookingSourceName":"Online","businessLostId":12,"businessSegmentId":9,"cancellationPolicyId":1,"cancelledDate":"2016-08-26 12:26:00","cancelledById":6,"cardId":"A698659","categoryId":19,"categoryName":"Super Delux Queen","children":1,"companyId":5,"confirmedDate":"2016-08-22 19:25:00","confirmedById":5,"contactId":9,"coordinator1Id":8,"coordinator2Id":7,"createdDate":"2016-08-22 19:25:00","createdById":35,"departureDate":"2019-09-29 09:25:00","deposit":20,"depositDate":"2019-09-29 09:25:00","destinationCodeId":6,"discountReasonId":0,"eta":"Wednesday Midnight","eventFinish":"2016-08-29 09:25:00","eventName":"Concert","eventStart":"2019-08-29 09:25:00","externalCancelId":"bcom39658965","externalReservationId":"uy96598568","fixedRes":true,"fixedResReason":1,"groupAllotmentId":7,"groupOptionId":1314,"groupReservationId":96598,"groupHeader":true,"guestGiven":"Smithers","guestId":65,"guestSurname":"Westingham","housekeepingNote":"housekeeping note","infants":1,"longTerm":true,"loyaltyMembershipTypeId":12,"marketSegmentId":12,"mealPlanId":16,"ModifiedDate":"2016-08-22 19:25:00","modifiedById":50,"notes":"This is a note about my reservation","occupantId":4,"onHold":false,"onlineConfirmationId":12986985,"originId":9,"otaNotes":"Booking.com - breakdown of pricing, etc","otaRef1":"V5986985s9","otaRef2":"BCOM-8976958","otaRef3":"89869858896","paymentModeId":45,"posOnGroupMaster":false,"preArrivalCheckComplete":false,"preAuthAmount":23.56,"preAuthCode":"2A","preAuthExpDate":"2016-08-29 09:25:00","propertyId":1,"rateOnGroup":false,"rateTypeId":3,"rateTypeName":"Daily","resTypeId":8,"reservationType":"Event","secondDeposit":15,"secondDepositDate":"2016-08-29 09:25:00","secondDiscountReasonId":0,"splitReservationId":12358,"status":"Confirmed","subMarketSegmentId":9,"subResTypeId":5,"travelAgentId":7,"travelAgentName":"Booking.com","userDefined1":"String 50","userDefined2":"String 20","userDefined3":"String 20","userDefined4":"String 20","userDefined5":"String 20","userDefined6":"String 20","userDefined7":"String 20","userDefined8":"String 20","userDefined9":"String 20","userDefined10":"String 50","userDefined11":true,"userDefined12":true,"userDefined13":true,"userDefined14":"2016-08-29 09:25:00","userDefined15":"2016-08-29 09:25:00","voucherId":"B4569856985","wholesalerId":58}} */
export interface RMSCloudReservationsPatch {
  patch?: RMSCloudReservationsPatchPatch
  reservationIds?: number[]
}

export interface RMSCloudReservationsPatchPatch {
  /** @format int32 */
  additional1?: number
  /** @format int32 */
  additional2?: number
  /** @format int32 */
  additional3?: number
  /** @format int32 */
  additional4?: number
  /** @format int32 */
  additional5?: number
  /** @format int32 */
  additional6?: number
  /** @format int32 */
  additional7?: number
  /** @format int32 */
  coordinator1Id?: number
  /** @format int32 */
  coordinator2Id?: number
  otaRef1?: string
  otaRef2?: string
  otaRef3?: string
  /** @maxLength 50 */
  userDefined1?: string
  /** @maxLength 50 */
  userDefined10?: string
  userDefined11?: boolean
  userDefined12?: boolean
  userDefined13?: boolean
  /** @format date-time */
  userDefined14?: string
  /** @format date-time */
  userDefined15?: string
  /** @maxLength 20 */
  userDefined2?: string
  /** @maxLength 20 */
  userDefined3?: string
  /** @maxLength 20 */
  userDefined4?: string
  /** @maxLength 20 */
  userDefined5?: string
  /** @maxLength 20 */
  userDefined6?: string
  /** @maxLength 20 */
  userDefined7?: string
  /** @maxLength 20 */
  userDefined8?: string
  /** @maxLength 20 */
  userDefined9?: string
  /** @format int32 */
  accountId?: number
  /** @format int32 */
  activityId?: number
  /** @format int32 */
  adults?: number
  /** Required when using combinations of Travel Agent, Group Allotments and Wholesalers */
  allotmentAssociationID?: string
  /** @format int32 */
  areaId?: number
  areaName?: string
  /** @format date-time */
  arrivalDate?: string
  attendees?: string
  /**
   * If you pass a value here the base rate will appear overridden and RMS will pro rata the nightly rate minus any Inclusive Packages or Inclusive Taxes
   * @format int32
   */
  baseRateOverride?: number
  billing?: string
  /** @format int32 */
  billingCategoryId?: number
  /** @format int32 */
  boatId?: number
  /** @format int32 */
  bookerContactId?: number
  /** @format int32 */
  bookingSourceId?: number
  bookingSourceName?: string
  /** @format int32 */
  businessLostId?: number
  /** @format int32 */
  businessSegmentId?: number
  /** @format int32 */
  cancellationPolicyId?: number
  /** @format int32 */
  cancelledById?: number
  /** @format date-time */
  cancelledDate?: string
  cardId?: string
  /** @format int32 */
  categoryId?: number
  categoryName?: string
  /** @format int32 */
  children?: number
  /** @format int32 */
  companyId?: number
  /** @format int32 */
  confirmedById?: number
  /** @format date-time */
  confirmedDate?: string
  /** @format int32 */
  contactId?: number
  /** @format int64 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  departureDate?: string
  /** @format currency */
  deposit?: number
  /** @format date-time */
  depositDate?: string
  /** @format int32 */
  destinationCodeId?: number
  /** @format int32 */
  discountReasonId?: number
  eta?: string
  /** @format date-time */
  eventFinish?: string
  eventName?: string
  /** @format date-time */
  eventStart?: string
  externalCancelId?: string
  externalReservationId?: string
  fixedRes?: boolean
  /** @format int32 */
  fixedResReasonId?: number
  /** @format int32 */
  groupAllotmentId?: number
  groupHeader?: boolean
  /** @format int32 */
  groupOptionId?: number
  /** @format int32 */
  groupReservationId?: number
  guestGiven?: string
  /** @format int32 */
  guestId?: number
  guestSurname?: string
  housekeepingNote?: string
  /** @format int32 */
  infants?: number
  longTerm?: boolean
  /** @format int32 */
  loyaltyMembershipTypeId?: number
  /** @format int32 */
  marketSegmentId?: number
  /** @format int32 */
  mealPlanId?: number
  /** @format int64 */
  modifiedById?: number
  /** @format date-time */
  modifiedDate?: string
  notes?: string
  /** @format int32 */
  occupantId?: number
  onHold?: boolean
  /** @format int32 */
  onlineConfirmationId?: number
  /** @format int32 */
  originId?: number
  otaNotes?: string
  /** @format int32 */
  paymentModeId?: number
  posOnGroupMaster?: boolean
  preArrivalCheckComplete?: boolean
  /** @format currency */
  preAuthAmount?: number
  preAuthCode?: string
  /** @format date-time */
  preAuthExpDate?: number
  /** @format int32 */
  propertyId?: number
  rateOnGroup?: boolean
  /** @format int32 */
  rateTypeId?: number
  rateTypeName?: string
  resType?: string
  /** @format int32 */
  resTypeId?: number
  reservationType?: string
  /** @format currency */
  secondDeposit?: number
  /** @format date-time */
  secondDepositDate?: string
  /** @format int32 */
  secondDiscountReasonId?: number
  /** @format int32 */
  splitReservationId?: number
  status?: string
  /** @format int32 */
  subMarketSegmentId?: number
  /** @format int32 */
  subResTypeId?: number
  /**
   * If you pass a value here the total rate will appear overridden and RMS will pro rata the nightly rate minus any Packages or Exclusive Taxes. If both baseRateOverride & totalRateOverride are passed in with a value then the totalRateOverride is used
   * @format int32
   */
  totalRateOverride?: number
  /** @format int32 */
  travelAgentId?: number
  travelAgentName?: string
  voucherId?: string
  /** @format int32 */
  wholesalerId?: number
}

/** @example {"rateOnGroup":true} */
export interface RMSCloudReservationsRateOnGroup {
  rateOnGroup?: boolean
}

/**
 * Used:<br>POST /reservations/{id}/housekeeping/resetSchedule
 * @example {"reservationId":0,"resetBedConfig":true}
 */
export interface RMSCloudResetHousekeepingRequest {
  /** @format int32 */
  reservationId?: number
  resetBedConfig?: boolean
}

/** @example {"id":16,"availableFor":["Monday","Tuesday"],"categoryid":3,"createdDate":"2020-09-25 00:00:00","createdById":4,"dateFrom":"2020-09-25 00:00:00","dateTo":"2020-09-28 00:00:00","minimumOccupancyLevelInPercentage":0,"rateId":1377,"setPermanently":false} */
export interface RMSCloudRestriction {
  availableFor?: string[]
  /** @format int32 */
  categoryid?: number
  /** @format int32 */
  createdById?: number
  /** @format date-time */
  createdDate?: string
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  minimumOccupancyLevelInPercentage?: number
  /** @format int32 */
  rateId?: number
  setPermanently?: boolean
}

/** @example {"agentIds":[4,5],"categoryIds":[5,4],"fromDate":"2020-11-01 00:00:00","inactive":false,"rateIds":[134,1546],"toDate":"2020-11-28 00:00:00","type":["stopSell","RateAdjustment"]} */
export interface RMSCloudRestrictionSearch {
  agentIds?: number[]
  categoryIds?: number[]
  /** @format date-time */
  fromDate?: string
  inactive?: boolean
  rateIds?: number[]
  /** @format date-time */
  toDate?: string
  /** Valid Reservation Status */
  type?: RMSCloudRestrictionSearchTypeEnum[]
}

export enum RMSCloudRestrictionSearchTypeEnum {
  AddtionalAdults = 'addtionalAdults',
  AddtionalChildren = 'addtionalChildren',
  Allotment = 'allotment',
  Bar = 'bar',
  ClearCloseRate = 'clearCloseRate',
  ClearCloseToArrival = 'clearCloseToArrival',
  ClearCloseToDeparture = 'clearCloseToDeparture',
  ClearLastRoomValue = 'clearLastRoomValue',
  ClearMinNightsOnArrival = 'clearMinNightsOnArrival',
  ClearMinNightsStayThruRes = 'clearMinNightsStayThruRes',
  ClearStopSell = 'clearStopSell',
  ClearRateOveride = 'clearRateOveride',
  CloseRate = 'closeRate',
  CloseToArrival = 'closeToArrival',
  CloseToDeparture = 'closeToDeparture',
  HotSale = 'hotSale',
  LastRoomValue = 'lastRoomValue',
  LastRoomValueCeiling = 'lastRoomValueCeiling',
  LastRoomValueDelta = 'lastRoomValueDelta',
  LastRoomValueMaxSold = 'lastRoomValueMaxSold',
  LastRoomValueYieldAdjustment = 'lastRoomValueYieldAdjustment',
  MaxPropertyOversell = 'maxPropertyOversell',
  MinNightsStayOnArrival = 'minNightsStayOnArrival',
  MinNightsStayThruRes = 'minNightsStayThruRes',
  OldRecords = 'oldRecords',
  OversellAllotment = 'oversellAllotment',
  StopSell = 'stopSell',
  RateAdjustment = 'RateAdjustment',
  RateOverride = 'RateOverride',
}

/** @example [{"categoryId":1,"rateId":1159,"dateFrom":"2023-10-01","dateTo":"2023-10-02","restrictionType":"minNightsStayOnArrival","minStay":4},{"categoryId":1,"rateId":1159,"dateFrom":"2023-10-30","dateTo":"2023-10-31","restrictionType":"stopSell"}] */
export interface RMSCloudRestrictionsPost {
  /** @format int32 */
  categoryId?: number
  /** @format date-time */
  dateFrom?: string
  /** @format date-time */
  dateTo?: string
  /** @format int32 */
  minStay?: number
  /** @format int32 */
  rateId?: number
  restrictionType?: RMSCloudRestrictionsPostRestrictionTypeEnum
}

export enum RMSCloudRestrictionsPostRestrictionTypeEnum {
  ClearCloseToArrival = 'clearCloseToArrival',
  ClearCloseToDeparture = 'clearCloseToDeparture',
  ClearMinNightsOnArrival = 'clearMinNightsOnArrival',
  ClearMinNightsStayThroughRes = 'clearMinNightsStayThroughRes',
  ClearStopSell = 'clearStopSell',
  CloseToArrival = 'closeToArrival',
  CloseToDeparture = 'closeToDeparture',
  MinNightsStayOnArrival = 'minNightsStayOnArrival',
  MinNightsStayThroughRes = 'minNightsStayThroughRes',
  StopSell = 'stopSell',
}

/** @example {"netDueToOwner":"0.00","totalPaymentsOnBehalfOfOwner":"0.00","paymentsOnBehalfOfOwner":[],"totalPayouts":"0.00","ownerShare":"0.00","netRevenue":"0.00","totalOperationalExpenses":"0.00","operationalExpenses":[],"grossRevenue":"0.00","averageRate":"0.00","occupancyPercent":"0.00","occupancyOwnerStay":0,"occupancyUsed":0,"occupancyAvailable":0,"occupancyMaintenance":0,"occupancyTotalAvailable":0,"ownerId":22,"propertyId":1,"area":"BUB/MAJ/1106/STU","areaId":34,"accountId":59,"holdAmount":"0.00","paidToOwner":"0.00"} */
export interface RMSCloudRevenueAndExpenseResponse {
  reportData?: RMSCloudRevenueAndExpenseResponseBody[]
}

export interface RMSCloudRevenueAndExpenseResponseBody {
  /** @format int32 */
  accountId?: number
  area?: string
  /** @format int32 */
  areaId?: number
  /** @format number */
  averageRate?: string
  /** @format number */
  grossRevenue?: string
  /** @format number */
  holdAmount?: string
  /** @format number */
  netDueToOwner?: string
  /** @format number */
  netRevenue?: string
  /** @format int32 */
  occupancyAvailable?: number
  /** @format int32 */
  occupancyMaintenance?: number
  /** @format int32 */
  occupancyOwnerStay?: number
  /** @format number */
  occupancyPercent?: string
  /** @format int32 */
  occupancyTotalAvailable?: number
  /** @format int32 */
  occupancyUsed?: number
  /** @format array */
  operationalExpenses?: string
  /** @format int32 */
  ownerId?: number
  /** @format number */
  ownerShare?: string
  /** @format number */
  paidToOwner?: string
  /** @format array */
  paymentsOnBehalfOfOwner?: string
  /** @format int32 */
  propertyId?: number
  /** @format number */
  totalOperationalExpenses?: string
  /** @format number */
  totalPaymentsOnBehalfOfOwner?: string
  /** @format number */
  totalPayouts?: string
}

/** @example {"id":23,"propertyId":"4","propertyName":"(RMSPAY)- Internal DB","stationNumber":"V400m-347312406","description":"RMSPay Termin"} */
export interface RMSCloudRmsPayTerminals {
  description: string
  /** @example 23 */
  id: number
  propertyId: string
  propertyName: string
  stationNumber: string
}

/** @example {"propertyId":4,"accountId":5127,"terminalId":20,"amount":"1","stationNumber":"V400m-347312398","merchantReference":"testMerchantRef","notifyURL":"https://testapp8.rmscloud.com","reservationId":100} */
export interface RMSCloudRmsPayTerminalsSale {
  accountId: number
  amount: string
  merchantReference?: string
  notifyURL?: string
  propertyId: number
  reservationId?: number
  stationNumber: string
  terminalId: number
}

/** @example {"success":true,"token":"RMS_464444459|FNFP6VRCMWPPZQT5","transactionReference":"PYgD001717632730005.ZWSFJ5XP6N2HLXT5","merchantReference":"testMerchantRef","cardType":"MasterCard","cardExpiry":"02/28"} */
export interface RMSCloudRmsPayTerminalsSaleResponse {
  cardExpiry?: string
  cardType?: string
  merchantReference?: string
  success?: boolean
  token?: string
  transactionReference?: string
}

/** @example {"success":true,"token":"RMS_122264948|SLXC55WJRLDN2S65","transactionReference":"PYgD001717721634000.SNS7HB9FBVS49W65","cardType":"MasterCard","cardExpiry":"02/28"} */
export interface RMSCloudRmsPayTerminalsStatus {
  cardExpiry?: string
  cardType?: string
  success?: boolean
  token?: string
  transactionReference?: string
}

/** @example {"propertyId":4,"accountId":5127,"terminalId":20,"merchantReference":"testMerchantRef","notifyURL":"https://testapp8.rmscloud.com","stationNumber":"V400m-347312398","guestId":444,"reservationId":100} */
export interface RMSCloudRmsPayTerminalsToken {
  accountId: number
  guestId: number
  merchantReference: string
  notifyURL?: string
  propertyId: number
  reservationId?: number
  stationNumber: string
  terminalId: number
}

/**
 * Used:<br>POST /guests/{id}/rmsPayPayment<br>POST /guests/{id}/rmsPayToken<br>POST /guests/{id}/rmsPayToken/search
 * @example {"allowPaymentMethods":["visa","mc","amex"],"amount":1,"currencyCode":"AUD","locale":"en_US","merchantReference":"REST88569","notifyURL":"https://testapp8.rmscloud.com","propertyId":4,"redirectURL":"https://testapp8.rmscloud.com","skip3DS":false}
 */
export interface RMSCloudRmsPayTokenRequest {
  skip3DS?: boolean
  /** allowPaymentMethods is an optional field */
  allowPaymentMethods?: RMSCloudRmsPayTokenRequestAllowPaymentMethodsEnum[]
  /** @format currency */
  amount: number
  currencyCode?: string
  /** locale is an optional field */
  locale?: string
  merchantReference: string
  notifyURL?: string
  /** @format int32 */
  propertyId: number
  redirectURL: string
}

export enum RMSCloudRmsPayTokenRequestAllowPaymentMethodsEnum {
  Visa = 'visa',
  Mc = 'mc',
  Amex = 'amex',
}

/**
 * Used:<br>POST /guests/{id}/rmsPayPayment<br>POST /guests/{id}/rmsPayToken
 * @example {"success":true,"redirectURL":"https://testapp8.rmscloud.com/RMSPay/?sessionId=54f654tyt98yyt8888","message":"Success"}
 */
export interface RMSCloudRmsPayTokenResponse {
  message?: string
  redirectURL?: string
  success?: boolean
}

export interface RMSCloudRmsPayTokenSearchRequest {
  merchantReference: string
  /** @format int32 */
  propertyId: number
}

/** @example [{"id":1,"description":"Capitain"},{"id":2,"description":"Crew"},{"id":3,"description":"Cleaners"}] */
export interface RMSCloudRoles {
  description?: string
  /** @format int32 */
  id?: number
}

/** @example {"id":1,"name":"Manager"} */
export interface RMSCloudSecurityProfile {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":5,"name":"Airlines","code":"AL","inactive":false,"shortDescription":"Airlines"} */
export interface RMSCloudSegment {
  code?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
  shortDescription?: string
}

/** @example {"success":true} */
export interface RMSCloudSuccessResult {
  success?: boolean
}

/** @example {"id":3,"name":"Coke Can","costPrice":1,"gLCodeId":0,"groupingId":1,"gstDivisorOverride":5.25,"inactive":false,"secondCurrency":0,"unitPrice":2.5,"unassigned":false,"thirdPartyClientId":151,"gstType":"Full","creditNote":true,"addOn":true,"posLite":false,"refundable":false,"expenseCharge":false,"transfers":false,"meal":true,"externalRefId":"123456789"} */
export interface RMSCloudSundry {
  addOn?: boolean
  /** @format currency */
  costPrice?: number
  creditNote?: boolean
  expenseCharge?: boolean
  externalRefId?: string
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  groupingId?: number
  /** @format decimal */
  gstDivisorOverride?: number
  /** @default "Full" */
  gstType?: RMSCloudSundryGstTypeEnum
  /** @format int32 */
  id?: number
  inactive?: boolean
  meal?: boolean
  name?: string
  posLite?: boolean
  refundable?: boolean
  /** @format int32 */
  secondCurrency?: number
  /** @format int32 */
  thirdPartyClientId?: number
  transfers?: boolean
  unassigned?: boolean
  /** @format currency */
  unitPrice?: number
}

/** @example {"id":3,"name":"Coke Can","costPrice":1,"gLCodeId":0,"groupingId":1,"gstDivisorOverride":5.25,"inactive":false,"secondCurrency":0,"unitPrice":2.5,"unassigned":false,"thirdPartyClientId":151,"gstType":"Full","creditNote":true} */
export interface RMSCloudSundryCreation {
  /** @format currency */
  costPrice?: number
  creditNote?: boolean
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  groupingId?: number
  /** @format decimal */
  gstDivisorOverride?: number
  /** @default "Full" */
  gstType?: RMSCloudSundryCreationGstTypeEnum
  /** @format int32 */
  id?: number
  inactive?: boolean
  name?: string
  /** @format int32 */
  secondCurrency?: number
  /** @format int32 */
  thirdPartyClientId?: number
  unassigned?: boolean
  /** @format currency */
  unitPrice?: number
}

/** @default "Full" */
export enum RMSCloudSundryCreationGstTypeEnum {
  NotSet = 'NotSet',
  Rent = 'Rent',
  Free = 'Free',
  Full = 'Full',
  Override = 'Override',
}

/** @default "Full" */
export enum RMSCloudSundryGstTypeEnum {
  NotSet = 'NotSet',
  Rent = 'Rent',
  Free = 'Free',
  Full = 'Full',
  Override = 'Override',
}

/** Used in Package Breakdown */
export interface RMSCloudTaxBreakdown {
  /** @format currency */
  amount?: number
  description?: string
  /** @format int32 */
  packageId?: number
  /** @format currency */
  perAdultFee?: number
  /** @format currency */
  perInfantFee?: number
  /** 'true When A Per Person Percentage Tax Has 'Add Additional %' Ticked */
  perPersonAdditionalTax?: boolean
  /** @format int32 */
  perPersonPercentage?: number
  /** @format int32 */
  perPersonPercentageAdditionalPercentage?: number
  perPersonPercentageCapped?: boolean
  /** @format currency */
  perPersonPercentageCappedAmount?: number
  serviceCharge?: boolean
  taxExemptionApplied?: boolean
  /** @format int32 */
  taxId?: number
  /** @format int32 */
  taxMethod?: number
  /** @format time-date */
  theDate?: string
}

/** @example {"id":3,"name":"Exclusive 10% Tax"} */
export interface RMSCloudTaxes {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":1,"name":"Mr"} */
export interface RMSCloudTitle {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":7,"name":"Sedan"} */
export interface RMSCloudTowing {
  /** @format int32 */
  id?: number
  name?: string
}

/** @example {"id":3,"tracesTemplateId":3,"description":"An almost identical trace","longDescription":"For reasons. That are long","entityType":"Reservation","entityId":214653,"departmentId":1,"fromDate":"2023-03-24 00:00:00","toDate":"2023-03-24 00:00:00","dateType":"DateRange","completed":false,"completedId":0,"createdId":189,"dueDate":"2023-03-24 00:00:00","modifiedId":189,"modifiedDate":"2023-03-25 08:45:20","userId":0,"repeatFrequency":"Week","repeatEvery":{"daysOfWeek":["monday","wednesday"]}} */
export interface RMSCloudTraces {
  /** @format int32 */
  completeId?: number
  completed?: boolean
  /** @format int32 */
  createdID?: number
  dateType?: RMSCloudTracesDateTypeEnum
  /** @format int32 */
  departmentID?: number
  description?: string
  /** @format date-time */
  dueDate?: string
  /** @format int32 */
  entityId?: number
  entityType?: RMSCloudTracesEntityTypeEnum
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  longDescription?: string
  /** @format date-time */
  modifiedDate?: string
  /** @format int32 */
  modifiedId?: number
  repeatEvery?: (RMSCloudDaysOfWeek | RMSCloudDaysOfMonth)[]
  repeatFrequency?: RMSCloudTracesRepeatFrequencyEnum
  /** @format date-time */
  toDate?: string
  /** @format int32 */
  tracesTemplateId?: number
  /** @format int32 */
  userId?: number
}

export enum RMSCloudTracesDateTypeEnum {
  Duedate = 'duedate',
  DateRange = 'dateRange',
}

export enum RMSCloudTracesEntityTypeEnum {
  Guest = 'guest',
  Company = 'company',
  Groups = 'groups',
  Reservation = 'reservation',
  ToDo = 'toDo',
  TravelAgent = 'travelAgent',
}

export enum RMSCloudTracesRepeatFrequencyEnum {
  Day = 'day',
  Week = 'week',
  Month = 'month',
}

/** @example {"tracesTemplateId":3,"description":"An almost identical trace","longDescription":"For reasons. That are long","entityType":"Reservation","entityId":214653,"departmentId":1,"fromDate":"2023-03-24 00:00:00","toDate":"2023-03-24 00:00:00","dateType":"DateRange","completed":false,"completedId":0,"createdId":189,"dueDate":"2023-03-24 00:00:00","modifiedId":189,"modifiedDate":"2023-03-25 08:45:20","userId":0,"repeatFrequency":"Week","repeatEvery":{"daysOfWeek":["monday","wednesday"]}} */
export interface RMSCloudTracesRequest {
  /** @format int32 */
  completeId?: number
  completed?: boolean
  /** @format int32 */
  createdID?: number
  dateType?: RMSCloudTracesRequestDateTypeEnum
  /** @format int32 */
  departmentID?: number
  description?: string
  /** @format date-time */
  dueDate?: string
  /** @format int32 */
  entityId?: number
  entityType?: RMSCloudTracesRequestEntityTypeEnum
  /** @format date-time */
  fromDate?: string
  longDescription?: string
  /** @format date-time */
  modifiedDate?: string
  /** @format int32 */
  modifiedId?: number
  repeatEvery?: (RMSCloudDaysOfWeek | RMSCloudDaysOfMonth)[]
  repeatFrequency?: RMSCloudTracesRequestRepeatFrequencyEnum
  /** @format date-time */
  toDate?: string
  /** @format int32 */
  tracesTemplateId?: number
  /** @format int32 */
  userId?: number
}

export enum RMSCloudTracesRequestDateTypeEnum {
  Duedate = 'duedate',
  DateRange = 'dateRange',
}

export enum RMSCloudTracesRequestEntityTypeEnum {
  Guest = 'guest',
  Company = 'company',
  Groups = 'groups',
  Reservation = 'reservation',
  ToDo = 'toDo',
  TravelAgent = 'travelAgent',
}

export enum RMSCloudTracesRequestRepeatFrequencyEnum {
  Day = 'day',
  Week = 'week',
  Month = 'month',
}

/** @example {"id":1,"tracesType":"company","description":"Company Trace","inactive":false,"departmentIds":[1],"propertyIds":[3]} */
export interface RMSCloudTracesTemplates {
  departmentIds?: number[]
  description?: string
  /** @format int32 */
  id?: number
  inactive?: boolean
  propertyIds?: number[]
  tracesType?: RMSCloudTracesTemplatesTracesTypeEnum
}

/** @example {"tracesType":"company","description":"Company Trace","inactive":false,"departmentIds":[1],"propertyIds":[3]} */
export interface RMSCloudTracesTemplatesRequest {
  departmentIds?: number[]
  description?: string
  inactive?: boolean
  propertyIds?: number[]
  tracesType?: RMSCloudTracesTemplatesRequestTracesTypeEnum
}

export enum RMSCloudTracesTemplatesRequestTracesTypeEnum {
  Guest = 'guest',
  Company = 'company',
  Groups = 'groups',
  Reservation = 'reservation',
  ToDo = 'toDo',
  TravelAgent = 'travelAgent',
}

export enum RMSCloudTracesTemplatesTracesTypeEnum {
  Guest = 'guest',
  Company = 'company',
  Groups = 'groups',
  Reservation = 'reservation',
  ToDo = 'toDo',
  TravelAgent = 'travelAgent',
}

/** @example {"accountId":7,"accountTypeOverride":"notSet","amount":26.02,"comment":"Extra Sheets","dateOfTransaction":"2016-11-28 00:00:00","description":"Cost of the Extra Sheets","overrideExchangeRate":22.2,"source":"Standard","sundryId":7,"thirdPartyClientId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default"} */
export interface RMSCloudTransactionCharge {
  /** @format int32 */
  accountId: number
  /**
   * This is used to override the source and specifiy the accountType for the posted transaction
   * @default "notSet"
   */
  accountTypeOverride?: RMSCloudTransactionChargeAccountTypeOverrideEnum
  /** @format currency */
  amount: number
  /** This information is only stored in the backend and is not shown in the UI or on the invoice */
  comment?: string
  /** @format date-time */
  dateOfTransaction?: number
  /** This will appear against the transaction on the account in the description colum in the UI and on the invoice */
  description?: string
  /** @format decimal */
  overrideExchangeRate?: number
  /** @default "standard" */
  source: RMSCloudTransactionChargeSourceEnum
  /** @format int32 */
  sundryId: number
  /** @format int32 */
  thirdPartyClientId?: number
  useRmsAccountingDateForPostingDate?: boolean
  /** default */
  useSecondaryCurrency?: RMSCloudTransactionChargeUseSecondaryCurrencyEnum
}

/**
 * This is used to override the source and specifiy the accountType for the posted transaction
 * @default "notSet"
 */
export enum RMSCloudTransactionChargeAccountTypeOverrideEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  NotSet = 'notSet',
  Pabx = 'pabx',
  Water = 'water',
}

/** @default "standard" */
export enum RMSCloudTransactionChargeSourceEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Standard = 'standard',
  Water = 'water',
}

/** default */
export enum RMSCloudTransactionChargeUseSecondaryCurrencyEnum {
  Default = 'default',
  Local = 'local',
  UsCurrency = 'usCurrency',
  GbCurrency = 'gbCurrency',
  Euro = 'euro',
  HongKongDollar = 'hongKongDollar',
  JapaneseYen = 'japaneseYen',
  ChineseYuan = 'chineseYuan',
}

/** @example [{"accountId":7,"accountTypeOverride":"notSet","amount":5.7,"comment":"Beer","dateOfTransaction":"2019-11-28 00:00:00","description":"Scooner","overrideExchangeRate":22.2,"source":"Standard","sundryId":7,"thirdPartyClientId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default"},{"accountId":7,"accountTypeOverride":"notSet","amount":25.2,"comment":"Pie","dateOfTransaction":"2019-11-28 00:00:00","description":"Shepards - family size","overrideExchangeRate":22.2,"source":"Standard","sundryId":7,"thirdPartyClientId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default"}] */
export interface RMSCloudTransactionCharges {
  /** @format int32 */
  accountId: number
  /**
   * This is used to override the source and specifiy the accountType for the posted transaction
   * @default "notSet"
   */
  accountTypeOverride?: RMSCloudTransactionChargesAccountTypeOverrideEnum
  /** @format currency */
  amount: number
  /** This information is only stored in the backend and is not shown in the UI or on the invoice */
  comment?: string
  /** @format date-time */
  dateOfTransaction?: number
  /** This will appear against the transaction on the account in the description colum in the UI and on the invoice */
  description?: string
  /** @format decimal */
  overrideExchangeRate?: number
  /** @default "standard" */
  source?: RMSCloudTransactionChargesSourceEnum
  /** @format int32 */
  sundryId: number
  /** @format int32 */
  thirdPartyClientId?: number
  useRmsAccountingDateForPostingDate?: boolean
  /** useDefault */
  useSecondaryCurrency?: RMSCloudTransactionChargesUseSecondaryCurrencyEnum
}

/**
 * This is used to override the source and specifiy the accountType for the posted transaction
 * @default "notSet"
 */
export enum RMSCloudTransactionChargesAccountTypeOverrideEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  NotSet = 'notSet',
  Pabx = 'pabx',
  Water = 'water',
}

/** @default "standard" */
export enum RMSCloudTransactionChargesSourceEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Standard = 'standard',
  Water = 'water',
}

/** useDefault */
export enum RMSCloudTransactionChargesUseSecondaryCurrencyEnum {
  Default = 'default',
  Local = 'local',
  UsCurrency = 'usCurrency',
  GbCurrency = 'gbCurrency',
  Euro = 'euro',
  HongKongDollar = 'hongKongDollar',
  JapaneseYen = 'japaneseYen',
  ChineseYuan = 'chineseYuan',
}

/** @example {"accountId":7,"amount":26.02,"assignedTransactionId":7,"comment":"Extra Sheets","dateOfTransaction":"2016-11-28 00:00:00","description":"Cost of the Extra Sheets","overrideExchangeRate":2.22,"sundryId":7,"source":"Standard","uniqueId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default"} */
export interface RMSCloudTransactionCreditNote {
  /** @format int32 */
  accountId: number
  /** @format currency */
  amount?: number
  /** @format int32 */
  assignedTransactionId?: number
  /** This information is presented on the line below the transaction in the UI and on the invoice */
  comment?: string
  /** @format date-time */
  dateOfTransaction?: number
  /** This will appear against the transaction on the account in the description colum in the UI and on the invoice */
  description?: string
  /** @format decimal */
  overrideExchangeRate?: number
  /** @default "accom" */
  source?: RMSCloudTransactionCreditNoteSourceEnum
  /** @format int32 */
  sundryId: number
  /** @format int32 */
  uniqueId?: number
  useRmsAccountingDateForPostingDate?: boolean
  /** useDefault */
  useSecondaryCurrency?: RMSCloudTransactionCreditNoteUseSecondaryCurrencyEnum
}

/** @default "accom" */
export enum RMSCloudTransactionCreditNoteSourceEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Accom = 'accom',
  Water = 'water',
}

/** useDefault */
export enum RMSCloudTransactionCreditNoteUseSecondaryCurrencyEnum {
  Default = 'default',
  Local = 'local',
  UsCurrency = 'usCurrency',
  GbCurrency = 'gbCurrency',
  Euro = 'euro',
  HongKongDollar = 'hongKongDollar',
  JapaneseYen = 'japaneseYen',
  ChineseYuan = 'chineseYuan',
}

/** @example {"id":9,"accountId":328,"accountingDate":"2019-02-16 00:00:00","accountType":"Accommodation","amount":53.26,"comment":"Cleaning","createdDate":"2016-11-28 00:00:00","creditCardMasked":"XXXX-XXXX-XXXX-5322","creditCardType":"Visa","currencyCode":"AUD","dateOfTransaction":"2016-11-28 00:00:00","dollarAction":0,"description":"Direct Credit Receipt #1, RMSOnline Booking #6920394","exchangeRate":12.2,"fullGst":86.25,"glCodeDescription":"On going","gLCodeGrouping":"Full time stays","glCodeId":986,"invoiceId":154546,"isHiddenPackage":false,"linkPointer":7,"linkPointerType":"Ppppp","modifiedDate":"2016-11-28 00:00:00","originalReceiptId":0,"propertyId":1,"quantity":1,"rateTransactionReservationId":122354,"receiptCurrencyCode":"AUD","receiptType":"CreditCard","sundryId":9,"taxAmount":0,"transactionType":"Receipt","userId":5,"voidTransaction":true} */
export interface RMSCloudTransactionFull {
  /** @format int32 */
  accountId?: number
  accountType?: string
  /**
   * This refers to the accounting day that is set in RMS
   * @format date-time
   */
  accountingDate?: string
  /** @format currency */
  amount?: number
  comment?: string
  /** @format date-time */
  createdDate?: string
  creditCardMasked?: string
  creditCardType?: string
  currencyCode?: string
  /** @format date-time */
  dateOfTransaction?: string
  description?: string
  /** @format currecny */
  dollarAction?: number
  /** @format decimal */
  exchangeRate?: number
  /** @format currency */
  fullGst?: number
  glCodeDescription?: string
  glCodeGrouping?: string
  /** @format int32 */
  glCodeId?: number
  /** @format int32 */
  id?: number
  /** @format int32 */
  invoiceId?: number
  isHiddenPackage?: boolean
  /** @format int32 */
  linkPointer?: number
  linkPointerType?: string
  /** @format date-time */
  modifiedDate?: string
  /**
   * The original receipt ID for a refund
   * @format int32
   */
  originalReceiptId?: number
  /** @format int32 */
  propertyId?: number
  /** @format int32 */
  quantity?: number
  /**
   * For a reservation transaction that has been moved to another account (Group Master, Company etc) this represents the Reservation Id the transaction was created for
   * @format int32
   */
  rateTransactionReservationId?: number
  receiptCurrencyCode?: string
  receiptType?: string
  /** @format int32 */
  sundryId?: number
  /** @format currency */
  taxAmount?: number
  transactionType?: string
  /** @format int32 */
  userId?: number
  voidTransaction?: boolean
}

/** @example {"accountId":31477,"accountType":"accomm","amount":5,"transactionId":2519489,"guestAccountId":30247,"reservationId":23508} */
export interface RMSCloudTransactionGuestCredit {
  /** @format int32 */
  accountId: number
  accountType: string
  /** @format number */
  amount: number
  /** @format int32 */
  guestAccountId: number
  /** @format int32 */
  reservationId: number
  /** @format int32 */
  transactionId: number
}

/** @example {"accountId":31477,"accountType":"accomm","amount":5,"giftCardId":89,"guestAccountId":30247,"reservationId":23508} */
export interface RMSCloudTransactionGuestCreditAndGiftCard {
  /** @format int32 */
  accountId: number
  accountType: string
  /** @format number */
  amount: number
  /** @format int32 */
  giftCardId: number
  /** @format int32 */
  guestAccountId: number
  /** @format int32 */
  reservationId: number
}

/**
 * array of guestCredits
 * @example {"accountId":378082,"accountType":"accomm","reservationId":221517,"creditTransactions":[{"amount":10,"transactionId":2520399,"guestAccountId":378301},{"amount":27,"transactionId":2520400,"guestAccountId":378301}]}
 */
export interface RMSCloudTransactionGuestCredits {
  /** @format number */
  accountId: number
  /** @format string */
  accountType: string
  creditTransactions: RMSCloudTransactionGuestCreditsCreditTransactions[]
  /** @format number */
  reservationId: number
}

export interface RMSCloudTransactionGuestCreditsCreditTransactions {
  /** @format number */
  amount?: number
  /** @format number */
  guestAccountId?: number
  /** @format number */
  transactionId?: number
}

/** @example [{"accountingDate":"2024-07-18 00:00:00","creditCardType":"","creditCardMasked":"","currencyCode":"AUD","createdDate":"2024-07-18 05:33:35","fullGst":0,"glCodeGrouping":"Suspense","glCodeDescription":"Suspense Charge","glCodeId":2,"originalReceiptId":0,"propertyId":1,"rateTransactionReservationId":0,"taxAmount":0,"transactionType":"CreditNote","voidTransaction":false,"linkPointer":2520402,"linkPointerType":"CreditTransfer","unpaidBalance":-10,"isHiddenPackage":false,"userId":186,"secondaryCurrency":-10,"exchangeRate":0,"modifiedDate":"1900-01-01 00:00:00","id":2520401,"accountId":378082,"accountType":"Accommodation","amount":-10,"comment":"","dateOfTransaction":"2024-07-18 00:00:00","sundryId":0,"description":"Transfer Credit from Acc No: 378301","quantity":0,"invoiceId":0},{"accountingDate":"2024-07-18 00:00:00","creditCardType":"","creditCardMasked":"","currencyCode":"AUD","createdDate":"2024-07-18 05:33:35","fullGst":0,"glCodeGrouping":"Suspense","glCodeDescription":"Suspense Charge","glCodeId":2,"originalReceiptId":0,"propertyId":1,"rateTransactionReservationId":0,"taxAmount":0,"transactionType":"Charge","voidTransaction":false,"linkPointer":2520401,"linkPointerType":"CreditTransfer","unpaidBalance":0,"isHiddenPackage":false,"userId":186,"secondaryCurrency":10,"exchangeRate":0,"modifiedDate":"1900-01-01 00:00:00","id":2520402,"accountId":378301,"accountType":"Accommodation","amount":10,"comment":"","dateOfTransaction":"2024-07-18 00:00:00","sundryId":0,"description":"Transfer Credit to Res No: 221517 - (Account1)","quantity":0,"invoiceId":0},{"accountingDate":"2024-07-18 00:00:00","creditCardType":"","creditCardMasked":"","currencyCode":"AUD","createdDate":"2024-07-18 05:33:35","fullGst":0,"glCodeGrouping":"Suspense","glCodeDescription":"Suspense Charge","glCodeId":2,"originalReceiptId":0,"propertyId":1,"rateTransactionReservationId":0,"taxAmount":0,"transactionType":"CreditNote","voidTransaction":false,"linkPointer":2520404,"linkPointerType":"CreditTransfer","unpaidBalance":-27,"isHiddenPackage":false,"userId":186,"secondaryCurrency":-27,"exchangeRate":0,"modifiedDate":"1900-01-01 00:00:00","id":2520403,"accountId":378082,"accountType":"Accommodation","amount":-27,"comment":"","dateOfTransaction":"2024-07-18 00:00:00","sundryId":0,"description":"Transfer Credit from Acc No: 378301","quantity":0,"invoiceId":0},{"accountingDate":"2024-07-18 00:00:00","creditCardType":"","creditCardMasked":"","currencyCode":"AUD","createdDate":"2024-07-18 05:33:35","fullGst":0,"glCodeGrouping":"Suspense","glCodeDescription":"Suspense Charge","glCodeId":2,"originalReceiptId":0,"propertyId":1,"rateTransactionReservationId":0,"taxAmount":0,"transactionType":"Charge","voidTransaction":false,"linkPointer":2520403,"linkPointerType":"CreditTransfer","unpaidBalance":0,"isHiddenPackage":false,"userId":186,"secondaryCurrency":27,"exchangeRate":0,"modifiedDate":"1900-01-01 00:00:00","id":2520404,"accountId":378301,"accountType":"Accommodation","amount":27,"comment":"","dateOfTransaction":"2024-07-18 00:00:00","sundryId":0,"description":"Transfer Credit to Res No: 221517 - (Account1)","quantity":0,"invoiceId":0}] */
export type RMSCloudTransactionGuestCreditsResponse = RMSCloudTransactionGuestCreditsResponseInner[]

export interface RMSCloudTransactionGuestCreditsResponseInner {
  /** @format number */
  accountId?: number
  /** @format string */
  accountType?: string
  /** @format date-time */
  accountingDate?: string
  /** @format number */
  amount?: number
  /** @format string */
  comment?: string
  /** @format date-time */
  createdDate?: string
  /** @format string */
  creditCardMasked?: string
  /** @format string */
  creditCardType?: string
  /** @format string */
  currencyCode?: string
  /** @format date-time */
  dateOfTransaction?: string
  /** @format string */
  description?: string
  /** @format number */
  exchangeRate?: number
  /** @format number */
  fullGst?: number
  /** @format string */
  glCodeDescription?: string
  /** @format string */
  glCodeGrouping?: string
  /** @format number */
  glCodeId?: number
  /** @format number */
  id?: number
  /** @format number */
  invoiceId?: number
  /** @format boolean */
  isHiddenPackage?: boolean
  /** @format number */
  linkPointer?: number
  /** @format string */
  linkPointerType?: string
  /** @format date-time */
  modifiedDate?: string
  /** @format number */
  originalReceiptId?: number
  /** @format number */
  propertyId?: number
  /** @format number */
  quantity?: number
  /** @format number */
  rateTransactionReservationId?: number
  /** @format number */
  secondaryCurrency?: number
  /** @format number */
  sundryId?: number
  /** @format number */
  taxAmount?: number
  /** @format string */
  transactionType?: string
  /** @format number */
  unpaidBalance?: number
  /** @format number */
  userId?: number
  /** @format boolean */
  voidTransaction?: boolean
}

/** @example {"accountId":7,"accountTypeOverride":"notSet","allowOnlinePayment":false,"amount":26.02,"cardId":2,"creditCardAuthorization":"yes","creditCardExpiry":"22/25","creditCardName":"Peter Branden","creditCardNumber":4569,"chequeNo":"G88392","comment":"Extra Sheets","dateOfTransaction":"2016-11-28 00:00:00","description":"Cost of the Extra Sheets","exchangeRateId":0,"invoiceId":23673,"journalId":"u7838yt","overrideExchangeRate":2.22,"receiptType":"CreditCard","source":"Standard","uniqueId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default","token":"erer78er9+er3er6r3fedfr","transactionReference":"Tr6464g65"} */
export interface RMSCloudTransactionReceipt {
  /** @format int32 */
  accountId: number
  /**
   * This is used to override the source and specifiy the accountType for the posted transaction
   * @default "notSet"
   */
  accountTypeOverride?: RMSCloudTransactionReceiptAccountTypeOverrideEnum
  /** For RMSPay Customers Only - Will proccess the payment via the gateway if to true and a valid RMSPay token is attached to the request */
  allowOnlinePayment?: boolean
  /** @format currency */
  amount: number
  /**
   * The cardId refers to the 'id' returned in both the calls 'get/properties/{id}/ibe/creditCard' and '/properties/{id}/creditCards'
   * @format int32
   */
  cardId?: number
  chequeNo?: string
  /** This information is presented on the line below the transaction in the UI and on the invoice */
  comment?: string
  /** This is only required when usuing the receiptType 'creditCard' or 'eftpos') */
  creditCardAuthorization?: string
  /** Format must be month/year e.g. 22/28 (This is only required when usuing the receiptType 'creditCard' or 'eftpos) */
  creditCardExpiry?: string
  /** This is only required when usuing the receiptType 'creditCard' or 'eftpos') */
  creditCardName?: string
  /**
   * Only pass the last 4 digits of the credit card (This is only required when usuing the receiptType 'creditCard' or 'eftpos)
   * @maxLength 4
   */
  creditCardNumber?: number
  /** @format date-time */
  dateOfTransaction?: number
  /** This will appear against the transaction on the account in the description colum in the UI and on the invoice */
  description?: string
  /** @format int32 */
  exchangeRateId?: number
  /** @format int32 */
  invoiceId?: number
  journalId?: string
  /** @format decimal */
  overrideExchangeRate?: number
  receiptType: RMSCloudTransactionReceiptReceiptTypeEnum
  /** @default "standard" */
  source: RMSCloudTransactionReceiptSourceEnum
  /** This field refers to the ‘token’ you would pass in the call guest/id/token <br/><br/> If a token is in the request, the receiptType must be CreditCard and a CardId must be provided. <br/><br/>  The token must also meet the atleast 1 of following criteria: <br/><br/> 1) The accountId is associated with the primary guestId where this token was already associated <br/><br/> 2) The accountId is for the reservation where the primary GuestId already had this token associated. <br/><br/> If none of the above criteria is met, the receipt post will be rejected.  */
  token?: string
  /** This field is so you can provide the paymnet gateway reference number */
  transactionReference?: string
  /** @format int32 */
  uniqueId?: number
  useRmsAccountingDateForPostingDate?: boolean
  /** useDefault */
  useSecondaryCurrency?: RMSCloudTransactionReceiptUseSecondaryCurrencyEnum
}

/**
 * This is used to override the source and specifiy the accountType for the posted transaction
 * @default "notSet"
 */
export enum RMSCloudTransactionReceiptAccountTypeOverrideEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  NotSet = 'notSet',
  Pabx = 'pabx',
  Water = 'water',
}

export enum RMSCloudTransactionReceiptReceiptTypeEnum {
  Cash = 'cash',
  Cash3 = 'cash3',
  Cash4 = 'cash4',
  Cash5 = 'cash5',
  CashExpense = 'cashExpense',
  CreditTransfer = 'creditTransfer',
  Cheque3 = 'cheque3',
  Cheque4 = 'cheque4',
  Cheque5 = 'cheque5',
  Cheque = 'cheque',
  CreditCard = 'creditCard',
  DirectCredit = 'directCredit',
  DirectCredit2 = 'directCredit2',
  DirectCredit3 = 'directCredit3',
  DirectCredit4 = 'directCredit4',
  DirectCredit5 = 'directCredit5',
  Eftpos = 'eftpos',
  EftposMachine = 'eftposMachine',
  ExistingToken = 'existingToken',
  ForexCash = 'forexCash',
  GiftCard = 'giftCard',
  GuestCredit = 'guestCredit',
  Journal = 'journal',
  OtherCash = 'otherCash',
  OtherCheque = 'otherCheque',
  Voucher = 'voucher',
}

/** @default "standard" */
export enum RMSCloudTransactionReceiptSourceEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Standard = 'standard',
  Water = 'water',
}

/** useDefault */
export enum RMSCloudTransactionReceiptUseSecondaryCurrencyEnum {
  Default = 'default',
  Local = 'local',
  UsCurrency = 'usCurrency',
  GbCurrency = 'gbCurrency',
  Euro = 'euro',
  HongKongDollar = 'hongKongDollar',
  JapaneseYen = 'japaneseYen',
  ChineseYuan = 'chineseYuan',
}

/**
 * Used:<br>POST /transactions/refund
 * @example {"accountId":544545,"amount":26.02,"allowOnlinePayment":true,"assignedTransactionId":2481628,"cardId":2,"chequeNo":"G88392","comment":"Extra Sheets","dateOfTransaction":"2016-11-28 00:00:00","description":"Cost of the Extra Sheets","journalId":"u7838yt","overrideExchangeRate":22.2,"receiptType":"CreditCard","source":"Standard","transactionReference":"SSVPQR52TGNG5S82","uniqueId":0,"useRmsAccountingDateForPostingDate":true,"useSecondaryCurrency":"default"}
 */
export interface RMSCloudTransactionRefund {
  /** @format int32 */
  accountId: number
  allowOnlinePayment?: boolean
  /** @format currency */
  amount: number
  /**
   * This field is required with RMSPay - The assigned transaction ID needs to be captured from the response body of the RMSPay receipt. In the RMSPay recceipt response body, it is referred to as 'id'
   * @format int32
   */
  assignedTransactionId?: number
  /**
   * This is the credit card type ID from RMS
   * @format int32
   */
  cardId?: number
  chequeNo?: string
  /** This information is presented on the line below the transaction in the UI and on the invoice */
  comment?: string
  /** @format date-time */
  dateOfTransaction?: number
  /** This will appear against the transaction on the account in the description colum in the UI and on the invoice */
  description?: string
  journalId?: string
  /** @format decimal */
  overrideExchangeRate?: number
  receiptType: RMSCloudTransactionRefundReceiptTypeEnum
  /** @default "standard" */
  source?: RMSCloudTransactionRefundSourceEnum
  /** @format int32 */
  sundryId?: number
  transactionReference?: string
  /** @format int32 */
  uniqueId?: number
  useRmsAccountingDateForPostingDate?: boolean
  /** useDefault */
  useSecondaryCurrency?: RMSCloudTransactionRefundUseSecondaryCurrencyEnum
}

export enum RMSCloudTransactionRefundReceiptTypeEnum {
  Cash = 'cash',
  Cash3 = 'cash3',
  Cash4 = 'cash4',
  Cash5 = 'cash5',
  CashExpense = 'cashExpense',
  CreditTransfer = 'creditTransfer',
  Cheque3 = 'cheque3',
  Cheque4 = 'cheque4',
  Cheque5 = 'cheque5',
  Cheque = 'cheque',
  CreditCard = 'creditCard',
  DirectCredit = 'directCredit',
  DirectCredit2 = 'directCredit2',
  DirectCredit3 = 'directCredit3',
  DirectCredit4 = 'directCredit4',
  DirectCredit5 = 'directCredit5',
  Eftpos = 'eftpos',
  EftposMachine = 'eftposMachine',
  ExistingToken = 'existingToken',
  Journal = 'journal',
  OtherCash = 'otherCash',
  OtherCheque = 'otherCheque',
  Voucher = 'voucher',
}

/** @default "standard" */
export enum RMSCloudTransactionRefundSourceEnum {
  Electric = 'electric',
  Extras = 'extras',
  Gas = 'gas',
  Kiosk = 'kiosk',
  Membership = 'membership',
  Pos = 'pos',
  Pabx = 'pabx',
  Standard = 'standard',
  Water = 'water',
}

/** useDefault */
export enum RMSCloudTransactionRefundUseSecondaryCurrencyEnum {
  Default = 'default',
  Local = 'local',
  UsCurrency = 'usCurrency',
  GbCurrency = 'gbCurrency',
  Euro = 'euro',
  HongKongDollar = 'hongKongDollar',
  JapaneseYen = 'japaneseYen',
  ChineseYuan = 'chineseYuan',
}

/** @example {"idFrom":6,"idTo":12,"accountType":"extras","accountIds":[1242,5985,702],"alwaysReturnReservationId":true,"createdFrom":"2018-09-25 00:00:00","createdTo":"2018-09-27 00:00:00","guestIds":[78945,61478],"invoiceIds":[89984,987978],"modifiedFrom":"2018-09-25 00:00:00","modifiedTo":"2018-09-27 00:00:00","propertyId":1,"receiptIds":[222586,222587],"reservationIds":[9454,123,1425],"transactionIds":[1886832,1886833,1886834],"transDateFrom":"2018-10-25 00:00:00","TransDateTo":"2018-10-27 00:00:00","transactionType":"charge","voidTransaction":true} */
export interface RMSCloudTransactionSearch {
  accountIds?: number[]
  accountType?: RMSCloudAccountTypeEnum
  alwaysReturnReservationId?: boolean
  /** @format date-time */
  createdFrom?: string
  /** @format date-time */
  createdTo?: string
  guestIds?: number[]
  /** @format int32 */
  idFrom?: number
  /** @format int32 */
  idTo?: number
  invoiceIds?: number[]
  /** @format date-time */
  modifiedFrom?: string
  /** @format date-time */
  modifiedTo?: string
  /** @format int32 */
  propertyId?: number
  receiptIds?: number[]
  reservationIds?: number[]
  /** @format date-time */
  transDateFrom?: string
  /** @format date-time */
  transDateTo?: string
  transactionIds?: number[]
  transactionType?: RMSCloudTransactionSearchTransactionTypeEnum
  voidTransaction?: boolean
}

export enum RMSCloudTransactionSearchTransactionTypeEnum {
  Charge = 'charge',
  Reciept = 'reciept',
  Voucher = 'voucher',
  Refund = 'refund',
  CreditNote = 'creditNote',
}

/** @example {"id":12345,"comment":"Accidental charge","reasonId":5} */
export interface RMSCloudTransactionVoid {
  /** This information is presented on the line below the transaction in the UI and on the invoice */
  comment?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  reasonId?: number
}

/** @example {"id":12345,"accountId":254696,"reasonId":5} */
export interface RMSCloudTransactionreverseReceipt {
  /** @format int32 */
  accountId: number
  /**
   * The transactionId for the receipt you wish to reverse
   * @format int32
   */
  id: number
  /** @format int32 */
  reasonId?: number
}

/** @example [{"receiptTransactionId":2474927,"destinationTransactionId":2474921,"allocatedDate":"2022-12-15 00:00:00","amount":1000,"glCodeId":154,"allocationType":"NotSet"},{"receiptTransactionId":2474927,"destinationTransactionId":2474921,"allocatedDate":"2022-12-15 00:00:00","amount":-1000,"glCodeId":154,"allocationType":"DeAllocateCharge"}] */
export interface RMSCloudTransactionsAllocation {
  /** @format date-time */
  allocatedDate?: string
  allocationType?: RMSCloudTransactionsAllocationAllocationTypeEnum
  /** @format int32 */
  destinationTransactionId?: number
  /** @format int32 */
  glCode?: number
  /** @format int32 */
  receiptTransactionId?: number
}

export enum RMSCloudTransactionsAllocationAllocationTypeEnum {
  NotSet = 'NotSet',
  AllocInternal = 'Alloc_Internal',
  Refund = 'Refund',
  Expense = 'Expense',
  DeAllocateCharge = 'DeAllocateCharge',
  DeAllocateReverseReceipt = 'DeAllocateReverseReceipt',
  DeAllocateOther = 'DeAllocateOther',
  ThirdParty = 'ThirdParty',
}

/** @example {"transactionIds":[2474929,2474927]} */
export interface RMSCloudTransactionsAllocationSearch {
  transactionIds?: number[]
}

/** @example {"ids":[2491311,2491312],"comment":"Accidental charge","reasonId":5} */
export interface RMSCloudTransactionsVoids {
  /** This information is presented on the line below the transaction in the UI and on the invoice */
  comment?: string
  ids?: number[]
  /** @format int32 */
  reasonId?: number
}

/** @example {"id":2654698,"amount":10,"carrier":"Big Rigs","confirmationNumber":"ty45986","dropOffLocationId":1,"note":"This is for notes","pax":10,"pickupLocationId":1,"shipFlightNumber":"JQ1234","sundryId":6,"reservationId":1,"theDate":"2020-09-25 17:25:00","transportTypeId":1,"type":"dropOff","useAmountFromSundry":false} */
export interface RMSCloudTransfer {
  /** @format currency */
  amount?: number
  carrier?: string
  confirmationNumber?: string
  /** @format int32 */
  dropOffLocationId?: number
  /** @format int32 */
  id?: number
  note?: string
  /** @format int32 */
  pax?: number
  /** @format int32 */
  pickupLocationId?: number
  /** @format int32 */
  reservationId?: number
  shipFlightNumber?: string
  /** @format int32 */
  sundryId?: number
  /** @format date-time */
  theDate?: string
  /** @format int32 */
  transportTypeId?: number
  type?: RMSCloudTransferTypeEnum
  useAmountFromSundry?: boolean
}

/** @example {"reservationAccountId":355494,"transferType":"toGuestAccount"} */
export interface RMSCloudTransferBalance {
  /** @format int32 */
  reservationAccountId?: number
  transferType?: RMSCloudTransferBalanceTransferTypeEnum
}

export enum RMSCloudTransferBalanceTransferTypeEnum {
  ToGuestAccount = 'toGuestAccount',
}

/** @example {"id":5,"description":"horse back","propertyIds":[1,3,4]} */
export interface RMSCloudTransferType {
  description?: string
  /** @format int32 */
  id?: number
  propertyIds?: number[]
}

export enum RMSCloudTransferTypeEnum {
  PickUp = 'pickUp',
  DropOff = 'dropOff',
}

/**
 * Used:<br>GET /agents/{id}/rates<br>
 * @example {"countryId":7,"fromDate":"2018-08-02 00:00:00","propertyId":1,"propertyName":"Property 1","rateId":1,"rateName":"BAR","toDate":"2019-12-02 00:00:00","town":"Melbourne"}
 */
export interface RMSCloudTravelAgentRateBasic {
  /** @format int32 */
  countryId?: number
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  /** @format int32 */
  rateId?: number
  rateName?: string
  /** @format date-time */
  toDate?: string
  town?: string
}

/** @example {"id":7,"travelAgentId":1,"fromDate":"2024-08-02 00:00:00","toDate":"2024-12-02 00:00:00","rateId":1,"rateName":"BAR","propertyId":1,"propertyName":"Test Property 1"} */
export interface RMSCloudTravelAgentsRatesAssignmentsFull {
  /** @format date-time */
  fromDate?: string
  /** @format int32 */
  id?: number
  /** @format int32 */
  propertyId?: number
  propertyName?: string
  /** @format int32 */
  rateId?: number
  rateName?: string
  /** @format date-time */
  toDate?: string
  /** @format int32 */
  travelAgentsId?: number
}

/** @example {"date":"2018-09-25 17:25:00","fieldModified":"Category","newValue":"Deluxe Queen","oldValue":"Single","userId":"Manager"} */
export interface RMSCloudUserAuditTrail {
  /** @format date-time */
  createdDate?: string
  fieldModified?: string
  newValue?: string
  oldValue?: string
  userId?: string
}

/** @example {"departmentId":8,"docuSignUsername":"Harry","email":"harry@rms.com","given":"Harry","inactive":false,"limitedUser":false,"mobile":72612358,"perferredLanguage":"french","phoneAh":"03 9856 9568","phoneBh":"03 4548 4598","positionId":9,"printProfileId":6,"ssoFederationId":"8g954g4","startupLandingPage":"Availability Chart","surname":"Farfield","title":"Mr","userName":" HarryFarfield","useSmartPrinting":true} */
export interface RMSCloudUserProfile {
  /** @format int32 */
  departmentId?: number
  docuSignUsername?: string
  email?: string
  given?: string
  inactive?: boolean
  limitedUser?: boolean
  mobile?: string
  perferredLanguage?: string
  phoneAh?: string
  phoneBh?: string
  /** @format int32 */
  positionId?: number
  /** @format int32 */
  printProfileId?: number
  ssoFederationId?: string
  startupLandingPage?: string
  surname?: string
  title?: string
  useSmartPrinting?: boolean
  userName?: string
}

/** @example {"ids":[1,595,4],"idFrom":6,"idTo":7,"departmentIds":[4,5,9],"emails":["apisupport@rms.com.au","apisupport@rmscloud.com"],"given":["john","james"],"mobile":["+6141245125","04 268 895 14"],"phoneAh":["03 456 9854","0245694569"],"phoneBh":["03 456 9854","0245694569"],"surname":["jeeves","gordans"],"userName":["jacobJ","PeterF"]} */
export interface RMSCloudUserSearch {
  departmentId?: number[]
  email?: string[]
  given?: string[]
  /** @format int32 */
  idFrom?: number
  /** @format int32 */
  idTo?: number
  ids?: number[]
  mobile?: string[]
  phoneAh?: string[]
  phoneBh?: string[]
  surname?: string[]
  userName?: string[]
}

/** @example {"id":1,"categroyIds":[4,5,9,10,11],"name":"Manager","propertyIds":[1,2],"userId":7} */
export interface RMSCloudUserSecurityProfile {
  categoryIds?: number[]
  /** @format int32 */
  id?: number
  name?: string
  propertyIds?: number[]
  /** @format int32 */
  userId?: number
}

/** @example {"id":[1,2,3],"propertyIds":[1,2]} */
export interface RMSCloudUserSecurityProfileSearch {
  ids?: number[]
  propertyIds?: number[]
}

/** @example {"id":1,"code":"KC","description":"KC VIP1","shortDescription":"KC VIP"} */
export interface RMSCloudVIPcodes {
  code?: string
  description?: string
  /** @format int32 */
  id?: number
  shortDescription?: string
}

/**
 * Used monitor area clean status changes - Only available with RMS v11.23.51.6 or higher
 * @example {"endpoint":"https://endpoint/webhooks","entityType":"area","action":"statusModification","subAction":"areaVacantDirty","propertyId":0,"modelType":""}
 */
export interface RMSCloudWebhookAreaSubscription {
  action?: RMSCloudWebhookAreaSubscriptionActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookAreaSubscriptionEntityTypeEnum
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: RMSCloudWebhookAreaSubscriptionSubActionEnum
}

export enum RMSCloudWebhookAreaSubscriptionActionEnum {
  StatusModification = 'statusModification',
}

export enum RMSCloudWebhookAreaSubscriptionEntityTypeEnum {
  Area = 'area',
}

export enum RMSCloudWebhookAreaSubscriptionSubActionEnum {
  AreaVacantClean = 'areaVacantClean',
  AreaVacantDirty = 'areaVacantDirty',
  AreaOccupied = 'areaOccupied',
  AreaVacantInspect = 'areaVacantInspect',
  AreaMaintenance = 'areaMaintenance',
}

/**
 * Used monitor group allotment changes - Only available with RMS v11.22.329.2 or higher
 * @example {"endpoint":"https://endpoint/webhooks","entityType":"groupAllotment","action":"creation","subAction":"","propertyId":0,"modelType":""}
 */
export interface RMSCloudWebhookGroupAllotmentSubscription {
  action?: RMSCloudWebhookGroupAllotmentSubscriptionActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookGroupAllotmentSubscriptionEntityTypeEnum
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: string
}

export enum RMSCloudWebhookGroupAllotmentSubscriptionActionEnum {
  Creation = 'creation',
  Modification = 'modification',
  Delete = 'delete',
}

export enum RMSCloudWebhookGroupAllotmentSubscriptionEntityTypeEnum {
  GroupAllotment = 'groupAllotment',
}

/**
 * Used monitor guest changes
 * @example {"endpoint":"https://endpoint/webhooks","entityType":"guest","action":"creation","subAction":"","propertyId":0,"modelType":"full"}
 */
export interface RMSCloudWebhookGuestSubscription {
  action?: RMSCloudWebhookGuestSubscriptionActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookGuestSubscriptionEntityTypeEnum
  /** To specify the basic, lite or full guest response (default is basic) */
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: string
}

export enum RMSCloudWebhookGuestSubscriptionActionEnum {
  Creation = 'creation',
  Modification = 'modification',
  Delete = 'delete',
  IdScan = 'idScan',
}

export enum RMSCloudWebhookGuestSubscriptionEntityTypeEnum {
  Guest = 'guest',
}

/**
 * Used monitor meal plan changes
 * @example {"endpoint":"https://endpoint/webhooks","entityType":"mealPlan","action":"creation","subAction":"","propertyId":0,"modelType":""}
 */
export interface RMSCloudWebhookMealPlanSubscription {
  action?: RMSCloudWebhookMealPlanSubscriptionActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookMealPlanSubscriptionEntityTypeEnum
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: string
}

export enum RMSCloudWebhookMealPlanSubscriptionActionEnum {
  Creation = 'creation',
  Modification = 'modification',
  Delete = 'delete',
}

export enum RMSCloudWebhookMealPlanSubscriptionEntityTypeEnum {
  MealPlan = 'mealPlan',
}

/**
 * Used monitor reservation changes
 * @example {"endpoint":"https://endpoint/webhooks","entityType":"reservation","action":"creation","subAction":"","propertyId":0,"modelType":"lite"}
 */
export interface RMSCloudWebhookReservationSubscription {
  /** regoAccessModified will only work with RMS v11.23.027.1 or Higher */
  action?: RMSCloudWebhookReservationSubscriptionActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookReservationSubscriptionEntityTypeEnum
  /** To specify the basic, lite or full reservation response (default is basic) */
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: RMSCloudWebhookReservationSubscriptionSubActionEnum
}

/** regoAccessModified will only work with RMS v11.23.027.1 or Higher */
export enum RMSCloudWebhookReservationSubscriptionActionEnum {
  Creation = 'creation',
  Modification = 'modification',
  StatusModification = 'statusModification',
  RegoAccessModified = 'regoAccessModified',
  AccountBalanceModification = 'accountBalanceModification',
}

export enum RMSCloudWebhookReservationSubscriptionEntityTypeEnum {
  Reservation = 'reservation',
}

export enum RMSCloudWebhookReservationSubscriptionSubActionEnum {
  Unconfirmed = 'unconfirmed',
  Confirmed = 'confirmed',
  Arrived = 'arrived',
  Departed = 'departed',
  Cancelled = 'cancelled',
  PreCheckIn = 'preCheckIn',
  NoShow = 'noShow',
}

/** @example {"endpoint":"https://endpoint/webhooks","entityType":"reservation","action":"creation","subAction":"","propertyId":0,"modelType":"lite"} */
export interface RMSCloudWebhookSubscription {
  /** regoAccessModified will only work with RMS v11.23.027.1 or Higher */
  action?: RMSCloudWebhookSubscriptionActionEnum
  endpoint?: string
  /** Group Allotment will only work with RMS v10.22.329.2 or Higher */
  entityType?: RMSCloudWebhookSubscriptionEntityTypeEnum
  /** To specify the basic, lite or full reservation response (default is basic) */
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: RMSCloudWebhookSubscriptionSubActionEnum
}

/** regoAccessModified will only work with RMS v11.23.027.1 or Higher */
export enum RMSCloudWebhookSubscriptionActionEnum {
  Creation = 'creation',
  Modification = 'modification',
  StatusModification = 'statusModification',
  Deletion = 'deletion',
  RegoAccessModified = 'regoAccessModified',
  AccountBalanceModification = 'accountBalanceModification',
}

/** Group Allotment will only work with RMS v10.22.329.2 or Higher */
export enum RMSCloudWebhookSubscriptionEntityTypeEnum {
  Reservation = 'reservation',
  Guest = 'guest',
  MealPlan = 'mealPlan',
  GroupAllotment = 'groupAllotment',
}

/** @example {"id":1,"endpoint":"https://endpoint/webhooks","entityType":"reservation","action":"creation","subAction":"","propertyId":0,"modelType":"lite"} */
export interface RMSCloudWebhookSubscriptionResponse {
  action?: RMSCloudWebhookSubscriptionResponseActionEnum
  endpoint?: string
  entityType?: RMSCloudWebhookSubscriptionResponseEntityTypeEnum
  /** @format int32 */
  id?: number
  /** The basic, lite or full reservation response (default is basic) */
  modelType?: string
  /**
   * If you pass the value '0' as the property ID in a central database it will act against every property ID wthin the database
   * @format int32
   */
  propertyId?: number
  subAction?: string
}

export enum RMSCloudWebhookSubscriptionResponseActionEnum {
  Creation = 'creation',
  Delete = 'delete',
  Modification = 'modification',
  StatusModification = 'statusModification',
}

export enum RMSCloudWebhookSubscriptionResponseEntityTypeEnum {
  Reservation = 'reservation',
  Guest = 'guest',
}

export enum RMSCloudWebhookSubscriptionResponseSubActionEnum {
  Unconfirmed = 'unconfirmed',
  Confirmed = 'confirmed',
  Arrived = 'arrived',
  Departed = 'departed',
  Cancelled = 'cancelled',
  PreCheckIn = 'preCheckIn',
  AreaVacantClean = 'areaVacantClean',
}

export enum RMSCloudWebhookSubscriptionSubActionEnum {
  Unconfirmed = 'unconfirmed',
  Confirmed = 'confirmed',
  Arrived = 'arrived',
  Departed = 'departed',
  Cancelled = 'cancelled',
  PreCheckIn = 'preCheckIn',
  AreaVacantClean = 'areaVacantClean',
}

export type RMSCloudWebhooksBody =
  | RMSCloudWebhookReservationSubscription
  | RMSCloudWebhookGuestSubscription
  | RMSCloudWebhookMealPlanSubscription
  | RMSCloudWebhookGroupAllotmentSubscription
  | RMSCloudWebhookAreaSubscription

/** @example {"id":1,"name":"North Park"} */
export interface RMSCloudZones {
  /** @format int32 */
  id?: number
  name?: string
}
