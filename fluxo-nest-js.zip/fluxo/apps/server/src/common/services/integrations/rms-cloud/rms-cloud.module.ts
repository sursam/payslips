import { HttpModule } from '@nestjs/axios'
import { forwardRef, Module } from '@nestjs/common'

import { RmsCloudListener } from '@/common/services/integrations/rms-cloud/rms-cloud.listener'
import { RmsCloudService } from '@/common/services/integrations/rms-cloud/rms-cloud.service'
import { PropertiesModule } from '@/resources/properties/properties.module'

@Module({
  imports: [HttpModule, forwardRef(() => PropertiesModule)],
  providers: [RmsCloudListener, RmsCloudService],
  exports: [RmsCloudService],
})
export class RmsCloudModule {}
