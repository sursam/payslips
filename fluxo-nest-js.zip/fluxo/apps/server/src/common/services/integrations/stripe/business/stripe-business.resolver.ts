import { UseGuards } from '@nestjs/common'
import { Args, Query, Resolver } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { CurrentUserDetails } from '@/common/decorators/current-user-details.decorator'
import { ErrorGraphqlHandlingDecorator } from '@/common/decorators/error-graphql-handling.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard'
import { RolesGuard } from '@/common/guards/roles.guard'
import { MessageInterfaceEntity } from '@/common/interfaces/message.interface'
import { GetAccountLinkInput } from '@/common/services/integrations/stripe/business/dto/get-account-link.input'
import { StripeAccountEntity } from '@/common/services/integrations/stripe/business/entities/stripe-account.entity'
import { StripePublicAccountEntity } from '@/common/services/integrations/stripe/business/entities/stripe-business-account.entity'
import { StripeSessionEntity } from '@/common/services/integrations/stripe/business/entities/stripe-session.entity'
import { StripeBusinessService } from '@/common/services/integrations/stripe/business/stripe-business.service'
import { DashboardMetricsEntity } from '@/common/services/integrations/stripe/customers/entities/metrics.entity'
import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'
import {
  StripeBusinessStatisticsEntity,
  StripeBusinessUpcomingBookingsStatisticEntity,
} from '@/common/services/integrations/stripe/business/entities/stripe-business-statistics.entity'

@Resolver(() => MessageInterfaceEntity)
export class StripeBusinessResolver {
  constructor(private readonly stripeBusinessService: StripeBusinessService) {}

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripeAccountEntity)
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  businessAccountLink(
    @CurrentUserDetails() userDetails: JwtTokenPayload,
    @Args('input') input: GetAccountLinkInput,
  ) {
    return this.stripeBusinessService.createBusinessAccountLink(userDetails, input)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripeSessionEntity)
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  businessAccountSession(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeBusinessService.createBusinessAccountSession(userDetails)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => StripePublicAccountEntity)
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  businessAccountVerificationStatus(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeBusinessService.checkKYCVerified(userDetails.id)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => DashboardMetricsEntity)
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  hostDashboard(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeBusinessService.calculateDashboardMetrics(userDetails)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => [StripeBusinessStatisticsEntity])
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  async historicalRevenue(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeBusinessService.historicalRevenue(userDetails)
  }

  @Roles(UserRole.HOST)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Query(() => [StripeBusinessUpcomingBookingsStatisticEntity])
  @ErrorGraphqlHandlingDecorator(StripeBusinessResolver.name)
  async upcomingBookingsStatistics(@CurrentUserDetails() userDetails: JwtTokenPayload) {
    return this.stripeBusinessService.upcomingBookingsStatistics(userDetails)
  }
}
