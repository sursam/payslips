import { Injectable } from '@nestjs/common'

@Injectable()
export class MessageGraphqlService {
  public error(input: string, message: string): string {
    return JSON.stringify({ input, message })
  }
}
