import { join } from 'node:path'

import { ApolloServerPluginLandingPageDisabled } from '@apollo/server/plugin/disabled'
import { ApolloServerPluginLandingPageLocalDefault } from '@apollo/server/plugin/landingPage/default'
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo'
import { Module } from '@nestjs/common'
import { GraphQLModule as GraphQLModuleClass } from '@nestjs/graphql'
import { FastifyReply, FastifyRequest } from 'fastify'

import { JwtTokenPayload } from '@/common/services/jwt-token/jwt-token.service'

interface Context {
  request: FastifyRequest & { extra?: { request: { rawHeaders: string[] } } }
  reply: FastifyReply
}

export interface ContextServer {
  req: FastifyRequest & {
    userDetails?: JwtTokenPayload
  }
  res: FastifyReply
  locale?: string
  socketToken?: string
}

@Module({
  imports: [
    GraphQLModuleClass.forRoot<ApolloDriverConfig>({
      // resolvers: { JSON: GraphQLJSON },
      driver: ApolloDriver,
      playground: false,
      introspection: process.env.NODE_ENV !== 'production',
      plugins: [
        process.env.NODE_ENV === 'production'
          ? ApolloServerPluginLandingPageDisabled()
          : ApolloServerPluginLandingPageLocalDefault(),
      ],
      autoSchemaFile: join(process.cwd(), 'src/schema.graphql'),
      // subscriptions: { 'graphql-ws': true },
      path: '/graphql',
      context: async (
        request: Context['request'],
        replay: Context['reply'],
      ): Promise<ContextServer> => {
        const cookies = request.extra?.request.rawHeaders
          .find((el) => el.includes('token='))
          ?.replaceAll(' ', '')
          .split(';')
        const cookieSocketToken: string | undefined = cookies
          ?.find((el) => el.includes('token='))
          ?.replace('token=', '')
        const headerSocketToken: string | undefined = Array.isArray(request.headers.authorization)
          ? undefined
          : request.headers.authorization?.replace('Bearer', '').trim()
        const locale =
          request.cookies.NEXT_LOCALE ?? request.headers['accept-language']?.split(',').at(0)

        return {
          req: request,
          res: replay,
          locale,
          socketToken: headerSocketToken ?? cookieSocketToken,
        }
      },
    }),
  ],
})
export class GraphqlModule {}
