export interface AppConfig {
  app: {
    port: number
    url: string
    tokenExpirationTime: {
      short: string
      normal: string
      extended: string
    }
    corsConfig: {
      origin: string[]
      credentials: boolean
    }
    nodeEnv: string
  }
  database: {
    url: string
  }
  secrets: {
    token: string
    cookie: string
  }
  rmsCloud: {
    authCredentials: {
      agentId: string
      agentPassword: string
      clientId: string
      clientPassword: string
      useTrainingDatabase: boolean
      moduleType: string[]
    }
    defaultServerUrl: string
    defaultRateTypeId: string
  }
  resend: {
    apiKey: string
  }
  hubspot: {
    apiKey: string
  }
  aws: {
    region: string
    accessKeyId: string
    secretAccessKey: string
    s3StaticBucketName: string
    s3DynamicBucketName: string
    s3FileUrl: string
  }
  google: {
    clientId: string
    clientSecret: string
  }
  apple: {
    bundleId: string
  }
  stripe: {
    apiKey: string
    publicApiKey: string
    whBusinessSecret: string
    whCustomersSecret: string
  }
  yotpo: {
    apiKey: string
    apiSecret: string
  }
  expoPush: {
    accessToken: string
  }
}
export default (): AppConfig => ({
  app: {
    tokenExpirationTime: {
      short: '1h',
      normal: '24h',
      extended: '7d',
    },
    corsConfig: {
      origin: [process.env.NEXT_PUBLIC_WEB_APP_URL ?? '', 'http://127.0.0.1:3000', 'http://localhost:3000'],
      credentials: process.env.CORS_CREDENTIALS === 'true', // Updated to use environment variable
    },
    port: 4000,
    url: process.env.NEXT_PUBLIC_WEB_APP_URL ?? '',
    nodeEnv: process.env.NODE_ENV ?? '',
  },
  database: {
    url: process.env.DATABASE_URL ?? '',
  },
  secrets: {
    token: process.env.TOKEN_SECRET ?? '',
    cookie: process.env.COOKIE_SECRET ?? '',
  },
  rmsCloud: {
    authCredentials: {
      agentId: process.env.RMS_CLOUD_AGENT_ID ?? '',
      agentPassword: process.env.RMS_CLOUD_AGENT_PASSWORD ?? '',
      clientId: process.env.RMS_CLOUD_CLIENT_ID ?? '',
      clientPassword: process.env.RMS_CLOUD_CLIENT_PASSWORD ?? '',
      useTrainingDatabase: false,
      moduleType: ['datawarehouse'],
    },
    defaultServerUrl: process.env.RMS_CLOUD_DEFAULT_URL ?? '',
    defaultRateTypeId: process.env.RMS_CLOUD_DEFAULT_RATE_TYPE_ID ?? '33',
  },
  resend: {
    apiKey: process.env.RESEND_API_KEY ?? '',
  },
  hubspot: {
    apiKey: process.env.HUBSPOT_API_KEY ?? '',
  },
  aws: {
    region: process.env.AWS_REGION ?? '',
    accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? '',
    s3StaticBucketName: process.env.S3_STATIC_BUCKET_NAME ?? '',
    s3DynamicBucketName: process.env.S3_DYNAMIC_BUCKET_NAME ?? '',
    s3FileUrl: process.env.S3_FILE_URL ?? '',
  },
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID ?? '',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? '',
  },
  apple: {
    bundleId: process.env.APPLE_BUNDLE_ID ?? '',
  },
  stripe: {
    apiKey: process.env.STRIPE_API_KEY ?? '',
    publicApiKey: process.env.STRIPE_PUBLIC_API_KEY ?? '',
    whBusinessSecret: process.env.STRIPE_BUSINESS_WEBHOOK_SECRET ?? '',
    whCustomersSecret: process.env.STRIPE_CUSTOMERS_WEBHOOK_SECRET ?? '',
  },
  yotpo: {
    apiKey: process.env.YOTPO_API_KEY ?? '',
    apiSecret: process.env.YOTPO_SECRET_KEY ?? '',
  },
  expoPush: {
    accessToken: process.env.EXPO_ACCESS_TOKEN ?? '',
  },
})
