import { Field, ObjectType } from '@nestjs/graphql'

@ObjectType()
export class AuthTokenInterface {
  @Field()
  authToken: string
}
