import { createParamDecorator, type ExecutionContext } from '@nestjs/common'
import { GqlExecutionContext } from '@nestjs/graphql'
import { type FieldNode, type GraphQLResolveInfo, type SelectionNode } from 'graphql'

export interface RequestedFieldsInfo {
  [fieldName: string]: boolean | RequestedFieldsInfo
}

export const RequestedFieldsDecorator = createParamDecorator(
  (data: unknown, context: ExecutionContext) => {
    const ctx = GqlExecutionContext.create(context)
    const info: GraphQLResolveInfo = ctx.getInfo()
    const selections: readonly SelectionNode[] | undefined =
      info.fieldNodes[0]?.selectionSet?.selections

    const getRequestedFields = (selectionNodes: readonly SelectionNode[]): RequestedFieldsInfo => {
      const requestedFields: RequestedFieldsInfo = {}

      // @ts-expect-error -- to be fixed later
      selectionNodes.forEach((field: FieldNode) => {
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- to be fixed later
        if (!field.name) return
        if (field.name.value === '__typename') return

        if (field.selectionSet) {
          requestedFields[field.name.value] = {
            select: getRequestedFields(field.selectionSet.selections),
          }
        } else {
          requestedFields[field.name.value] = true
        }
      })

      return requestedFields
    }

    return getRequestedFields(selections ?? [])
  },
)
