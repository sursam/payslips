import { createParamDecorator, type ExecutionContext } from '@nestjs/common'
import { GqlExecutionContext } from '@nestjs/graphql'

import { type ContextServer } from '@/common/services/graphql/graphql.module'

export const CurrentUserDetails = createParamDecorator(
  (data: unknown, context: ExecutionContext) => {
    const ctx = GqlExecutionContext.create(context)
    return ctx.getContext<ContextServer>().req.userDetails
  },
)
