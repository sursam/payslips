import {
  BadRequestException,
  ForbiddenException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common'

export const ErrorGraphqlHandlingDecorator = (name?: string) => {
  const logger = new Logger()

  return (_target: unknown, _key: string, descriptor: PropertyDescriptor) => {
    const originalMethod = descriptor.value as (...args: unknown[]) => unknown

    descriptor.value = async function op(...args: unknown[]) {
      try {
        logger.log(`Operation: ${_key}`, name)

        return await originalMethod.apply(this, args)
      } catch (error) {
        const graphqlError = error as Error & {
          response: { statusCode: number | undefined } | undefined
        }

        logger.error(`Operation: ${_key}. Error: ${graphqlError.message}`, name)
        const statusCode = graphqlError.response?.statusCode?.toString()

        if (statusCode?.includes('50')) {
          throw new InternalServerErrorException('Internal Server Error')
        } else if (statusCode?.includes('403')) {
          throw new ForbiddenException(graphqlError.message)
        } else if (graphqlError.message.length > 70) {
          throw new BadRequestException(graphqlError.message)
        } else {
          throw new BadRequestException(graphqlError.message)
        }
      }
    }

    return descriptor
  }
}
