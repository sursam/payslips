import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { GqlExecutionContext } from '@nestjs/graphql'
import { UserRole } from '@prisma/client'

import { ContextServer } from '@/common/services/graphql/graphql.module'

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<UserRole[]>('roles', [
      context.getHandler(),
      context.getClass(),
    ])

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- type quirks
    if (!requiredRoles) return true

    const ctx = GqlExecutionContext.create(context)
    const { req }: ContextServer = ctx.getContext()

    if (!requiredRoles.some((role) => role === req.userDetails?.role)) {
      throw new ForbiddenException("Current user doesn't have an appropriate role")
    }

    return true
  }
}
