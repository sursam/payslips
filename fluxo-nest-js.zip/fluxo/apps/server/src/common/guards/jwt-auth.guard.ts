import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { GqlExecutionContext } from '@nestjs/graphql'

import { AppConfig } from '@/common/config/configuration'
import { ContextServer } from '@/common/services/graphql/graphql.module'
import { JwtTokenService } from '@/common/services/jwt-token/jwt-token.service'
import { PrismaService } from '@/common/services/prisma/prisma.service'

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwtTokenService: JwtTokenService,
    private readonly configService: ConfigService<AppConfig>,
    private readonly prismaService: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const ctx = GqlExecutionContext.create(context)
    const { req, res, socketToken }: ContextServer = ctx.getContext()

    const token = socketToken ?? req.cookies.token ?? null

    if (!token) {
      throw new UnauthorizedException('You are not authorized')
    }

    try {
      const { iat = 0, exp, ...user } = await this.jwtTokenService.verifyToken(token)
      const tokenExpirationTime = this.configService.get('app.tokenExpirationTime', { infer: true })
      const userData = await this.prismaService.user.findUnique({
        where: { email: user.email },
        select: {
          tokenExpiryThreshold: true,
        },
      })
      const isTokenExpiredByThreshold = userData?.tokenExpiryThreshold
        ? userData.tokenExpiryThreshold.getTime() > iat
        : false

      if (isTokenExpiredByThreshold) throw new UnauthorizedException('Token expired')

      if (!socketToken) {
        const refreshToken = await this.jwtTokenService.createToken(
          { ...user, iat: new Date().getTime() },
          user.remember ? tokenExpirationTime?.extended : tokenExpirationTime?.normal,
        )

        this.jwtTokenService.setTokenToCookie(res, refreshToken)
      }

      req.userDetails = user
    } catch {
      this.jwtTokenService.clearTokenFromCookie(res)

      throw new UnauthorizedException('You are not authorized')
    }

    return true
  }
}
