/*
  Warnings:

  - You are about to drop the column `dayPassId` on the `availabilities` table. All the data in the column will be lost.
  - You are about to drop the column `propertyId` on the `availabilities` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `guests` table. All the data in the column will be lost.
  - You are about to drop the column `businessLocation` on the `hosts` table. All the data in the column will be lost.
  - You are about to drop the column `businessName` on the `hosts` table. All the data in the column will be lost.
  - You are about to drop the column `businessPhoneNumber` on the `hosts` table. All the data in the column will be lost.
  - You are about to drop the column `businessTaxId` on the `hosts` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `hosts` table. All the data in the column will be lost.
  - You are about to drop the column `hostId` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `unlistedDays` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the `DayPass` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[user_id]` on the table `guests` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[user_id]` on the table `hosts` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[host_id]` on the table `properties` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `user_id` to the `guests` table without a default value. This is not possible if the table is not empty.
  - Added the required column `business_location` to the `hosts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `business_name` to the `hosts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `business_phone_number` to the `hosts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `business_tax_id` to the `hosts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `user_id` to the `hosts` table without a default value. This is not possible if the table is not empty.
  - Added the required column `host_id` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "DayPass" DROP CONSTRAINT "DayPass_propertyId_fkey";

-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_dayPassId_fkey";

-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_propertyId_fkey";

-- DropForeignKey
ALTER TABLE "guests" DROP CONSTRAINT "guests_userId_fkey";

-- DropForeignKey
ALTER TABLE "hosts" DROP CONSTRAINT "hosts_userId_fkey";

-- DropForeignKey
ALTER TABLE "properties" DROP CONSTRAINT "properties_hostId_fkey";

-- DropIndex
DROP INDEX "guests_userId_key";

-- DropIndex
DROP INDEX "hosts_userId_key";

-- DropIndex
DROP INDEX "properties_hostId_key";

-- AlterTable
ALTER TABLE "availabilities" DROP COLUMN "dayPassId",
DROP COLUMN "propertyId",
ADD COLUMN     "day_pass_id" TEXT,
ADD COLUMN     "property_id" TEXT;

-- AlterTable
ALTER TABLE "guests" DROP COLUMN "userId",
ADD COLUMN     "user_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "hosts" DROP COLUMN "businessLocation",
DROP COLUMN "businessName",
DROP COLUMN "businessPhoneNumber",
DROP COLUMN "businessTaxId",
DROP COLUMN "userId",
ADD COLUMN     "business_location" TEXT NOT NULL,
ADD COLUMN     "business_name" TEXT NOT NULL,
ADD COLUMN     "business_phone_number" TEXT NOT NULL,
ADD COLUMN     "business_tax_id" TEXT NOT NULL,
ADD COLUMN     "user_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "properties" DROP COLUMN "hostId",
DROP COLUMN "unlistedDays",
ADD COLUMN     "host_id" TEXT NOT NULL,
ADD COLUMN     "unlisted_days" TIMESTAMP(3)[];

-- DropTable
DROP TABLE "DayPass";

-- CreateTable
CREATE TABLE "day_passes" (
    "id" TEXT NOT NULL,
    "description" VARCHAR(3000) NOT NULL DEFAULT '',
    "quantity" INTEGER NOT NULL,
    "daily_cost" INTEGER NOT NULL,
    "property_id" TEXT,

    CONSTRAINT "day_passes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "day_passes_property_id_key" ON "day_passes"("property_id");

-- CreateIndex
CREATE UNIQUE INDEX "guests_user_id_key" ON "guests"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "hosts_user_id_key" ON "hosts"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "properties_host_id_key" ON "properties"("host_id");

-- AddForeignKey
ALTER TABLE "guests" ADD CONSTRAINT "guests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hosts" ADD CONSTRAINT "hosts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_host_id_fkey" FOREIGN KEY ("host_id") REFERENCES "hosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_property_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_day_pass_id_fkey" FOREIGN KEY ("day_pass_id") REFERENCES "day_passes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "day_passes" ADD CONSTRAINT "day_passes_property_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;
