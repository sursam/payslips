-- AlterTable
ALTER TABLE "BookingPassGroup" ADD COLUMN     "seats" INTEGER;
