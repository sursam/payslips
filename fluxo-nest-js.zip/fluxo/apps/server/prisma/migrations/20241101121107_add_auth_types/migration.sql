-- CreateEnum
CREATE TYPE "AuthType" AS ENUM ('FLUXO', 'GOOGLE', 'APPLE');

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "auth_type" "AuthType" NOT NULL DEFAULT 'FLUXO';
