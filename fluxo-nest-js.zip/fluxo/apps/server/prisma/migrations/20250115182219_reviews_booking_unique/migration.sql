/*
  Warnings:

  - A unique constraint covering the columns `[property_id,guest_id]` on the table `BookingReview` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "BookingReview_guest_id_key";

-- DropIndex
DROP INDEX "BookingReview_property_id_key";

-- CreateIndex
CREATE UNIQUE INDEX "BookingReview_property_id_guest_id_key" ON "BookingReview"("property_id", "guest_id");
