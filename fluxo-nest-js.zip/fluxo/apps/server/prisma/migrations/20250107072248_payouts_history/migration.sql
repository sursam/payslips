-- AlterTable
ALTER TABLE "payouts_history" ALTER COLUMN "balance_transaction_id" DROP NOT NULL,
ALTER COLUMN "statement_descriptor" DROP NOT NULL;
