-- AlterTable
ALTER TABLE "hosts" ADD COLUMN     "commission_rate" DOUBLE PRECISION NOT NULL DEFAULT 0.2;
