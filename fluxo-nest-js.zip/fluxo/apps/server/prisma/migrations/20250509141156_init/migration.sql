/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `stripe_coupons` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "stripe_coupons_name_key" ON "stripe_coupons"("name");
