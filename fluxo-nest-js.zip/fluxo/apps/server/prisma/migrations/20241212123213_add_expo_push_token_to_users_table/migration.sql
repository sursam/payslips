-- AlterTable
ALTER TABLE "users" ADD COLUMN     "expo_push_token" TEXT;
