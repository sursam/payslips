/*
  Warnings:

  - You are about to drop the column `expected_arrival_time` on the `BookingPass` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BookingPass" DROP COLUMN "expected_arrival_time";
