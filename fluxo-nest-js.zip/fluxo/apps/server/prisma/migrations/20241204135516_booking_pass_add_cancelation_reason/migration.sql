-- AlterTable
ALTER TABLE "BookingPass" ADD COLUMN     "cancelationReason" TEXT;
