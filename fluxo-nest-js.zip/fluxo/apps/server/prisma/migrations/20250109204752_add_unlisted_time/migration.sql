-- CreateTable
CREATE TABLE "unlisted_time" (
    "id" TEXT NOT NULL,
    "from" TEXT,
    "to" TEXT,
    "date" TIMESTAMP(3) NOT NULL,
    "space_id" TEXT,

    CONSTRAINT "unlisted_time_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "unlisted_time" ADD CONSTRAINT "unlisted_time_space_id_fkey" FOREIGN KEY ("space_id") REFERENCES "spaces"("id") ON DELETE CASCADE ON UPDATE CASCADE;
