-- CreateTable
CREATE TABLE "transactions_history" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "stripe_customer_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "transactions_history_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_user_id_key" ON "transactions_history"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_stripe_customer_id_key" ON "transactions_history"("stripe_customer_id");

-- AddForeignKey
ALTER TABLE "transactions_history" ADD CONSTRAINT "transactions_history_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transactions_history" ADD CONSTRAINT "transactions_history_stripe_customer_id_fkey" FOREIGN KEY ("stripe_customer_id") REFERENCES "stripe_customers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
