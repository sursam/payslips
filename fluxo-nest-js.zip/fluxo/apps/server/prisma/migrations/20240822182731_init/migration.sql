-- AlterTable
ALTER TABLE "users" ADD COLUMN     "emailVerificationCode" VARCHAR(6),
ADD COLUMN     "email_verified" BOOLEAN NOT NULL DEFAULT false;
