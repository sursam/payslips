/*
  Warnings:

  - A unique constraint covering the columns `[rmsId,rmsCategoryId]` on the table `rms_mapping` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "rms_mapping_rmsId_rmsCategoryId_key" ON "rms_mapping"("rmsId", "rmsCategoryId");
