-- AlterTable
ALTER TABLE "attributes" ADD COLUMN     "order" INTEGER;
