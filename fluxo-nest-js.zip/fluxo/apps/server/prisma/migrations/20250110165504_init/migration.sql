/*
  Warnings:

  - You are about to drop the column `reviewScore` on the `BookingPassGroup` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BookingPassGroup" DROP COLUMN "reviewScore";

-- CreateTable
CREATE TABLE "BookingReview" (
    "id" TEXT NOT NULL,
    "property_id" TEXT NOT NULL,
    "guest_id" TEXT NOT NULL,
    "reviewScore" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "BookingReview_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BookingReview_property_id_key" ON "BookingReview"("property_id");

-- CreateIndex
CREATE UNIQUE INDEX "BookingReview_guest_id_key" ON "BookingReview"("guest_id");

-- AddForeignKey
ALTER TABLE "BookingReview" ADD CONSTRAINT "BookingReview_property_id_fkey" FOREIGN KEY ("property_id") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BookingReview" ADD CONSTRAINT "BookingReview_guest_id_fkey" FOREIGN KEY ("guest_id") REFERENCES "guests"("id") ON DELETE CASCADE ON UPDATE CASCADE;
