-- CreateTable
CREATE TABLE "rms_configuration" (
    "id" TEXT NOT NULL,
    "auth_token" TEXT,
    "server_url" TEXT,

    CONSTRAINT "rms_configuration_pkey" PRIMARY KEY ("id")
);
