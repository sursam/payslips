-- AlterEnum
ALTER TYPE "AttributeType" ADD VALUE 'SPACE_CATEGORY';
