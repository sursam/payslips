-- CreateEnum
CREATE TYPE "HostStatus" AS ENUM ('ACTIVE', 'PAUSED');

-- AlterTable
ALTER TABLE "hosts" ADD COLUMN     "status" "HostStatus" NOT NULL DEFAULT 'ACTIVE';
