/*
  Warnings:

  - You are about to drop the column `rms_mapping_id` on the `day_passes` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "day_passes" DROP CONSTRAINT "day_passes_rms_mapping_id_fkey";

-- DropIndex
DROP INDEX "day_passes_rms_mapping_id_key";

-- AlterTable
ALTER TABLE "day_passes" DROP COLUMN "rms_mapping_id";

-- AlterTable
ALTER TABLE "rms_mapping" ADD COLUMN     "dayPassId" TEXT;

-- AddForeignKey
ALTER TABLE "rms_mapping" ADD CONSTRAINT "rms_mapping_dayPassId_fkey" FOREIGN KEY ("dayPassId") REFERENCES "day_passes"("id") ON DELETE SET NULL ON UPDATE CASCADE;
