/*
  Warnings:

  - You are about to drop the column `dayPassId` on the `properties` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[propertyId]` on the table `DayPass` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_dayPassId_fkey";

-- DropForeignKey
ALTER TABLE "availabilities" DROP CONSTRAINT "availabilities_propertyId_fkey";

-- DropForeignKey
ALTER TABLE "properties" DROP CONSTRAINT "properties_dayPassId_fkey";

-- AlterTable
ALTER TABLE "DayPass" ADD COLUMN     "propertyId" TEXT;

-- AlterTable
ALTER TABLE "properties" DROP COLUMN "dayPassId";

-- CreateIndex
CREATE UNIQUE INDEX "DayPass_propertyId_key" ON "DayPass"("propertyId");

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "availabilities" ADD CONSTRAINT "availabilities_dayPassId_fkey" FOREIGN KEY ("dayPassId") REFERENCES "DayPass"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DayPass" ADD CONSTRAINT "DayPass_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;
