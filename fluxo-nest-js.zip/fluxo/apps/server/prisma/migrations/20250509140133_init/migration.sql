-- CreateTable
CREATE TABLE "stripe_coupons_usage" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "couponCode" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "stripe_coupons_usage_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "stripe_coupons_usage" ADD CONSTRAINT "stripe_coupons_usage_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
