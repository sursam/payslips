-- AlterTable
ALTER TABLE "BookingPass" ADD COLUMN     "groupId" TEXT;

-- CreateTable
CREATE TABLE "BookingPassGroup" (
    "id" TEXT NOT NULL,

    CONSTRAINT "BookingPassGroup_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BookingPass" ADD CONSTRAINT "BookingPass_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "BookingPassGroup"("id") ON DELETE SET NULL ON UPDATE CASCADE;
