-- CreateTable
CREATE TABLE "stripe_customer_payment_methods" (
    "id" TEXT NOT NULL,
    "customer_id" TEXT,
    "payment_method_id" TEXT NOT NULL,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "isRemoved" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "stripe_customer_payment_methods_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "stripe_customer_payment_methods_customer_id_key" ON "stripe_customer_payment_methods"("customer_id");

-- CreateIndex
CREATE UNIQUE INDEX "stripe_customer_payment_methods_payment_method_id_key" ON "stripe_customer_payment_methods"("payment_method_id");

-- AddForeignKey
ALTER TABLE "stripe_customer_payment_methods" ADD CONSTRAINT "stripe_customer_payment_methods_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "stripe_customers"("id") ON DELETE SET NULL ON UPDATE CASCADE;
