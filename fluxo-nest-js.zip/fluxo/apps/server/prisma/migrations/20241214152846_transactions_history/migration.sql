/*
  Warnings:

  - You are about to drop the column `stripe_customer_id` on the `transactions_history` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[charge_id]` on the table `transactions_history` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[balance_transaction_id]` on the table `transactions_history` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[payment_intent_id]` on the table `transactions_history` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[transfer_id]` on the table `transactions_history` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `amount` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `balance_transaction_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `business_stripe_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `captured` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `charge_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `customer_stripe_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `payment_intent_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `transfer_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "transactions_history" DROP CONSTRAINT "transactions_history_stripe_customer_id_fkey";

-- DropForeignKey
ALTER TABLE "transactions_history" DROP CONSTRAINT "transactions_history_user_id_fkey";

-- DropIndex
DROP INDEX "transactions_history_stripe_customer_id_key";

-- DropIndex
DROP INDEX "transactions_history_user_id_key";

-- AlterTable
ALTER TABLE "transactions_history" DROP COLUMN "stripe_customer_id",
ADD COLUMN     "amount" INTEGER NOT NULL,
ADD COLUMN     "balance_transaction_id" TEXT NOT NULL,
ADD COLUMN     "business_stripe_id" TEXT NOT NULL,
ADD COLUMN     "captured" BOOLEAN NOT NULL,
ADD COLUMN     "charge_id" TEXT NOT NULL,
ADD COLUMN     "customer_stripe_id" TEXT NOT NULL,
ADD COLUMN     "payment_intent_id" TEXT NOT NULL,
ADD COLUMN     "transfer_id" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_charge_id_key" ON "transactions_history"("charge_id");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_balance_transaction_id_key" ON "transactions_history"("balance_transaction_id");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_payment_intent_id_key" ON "transactions_history"("payment_intent_id");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_transfer_id_key" ON "transactions_history"("transfer_id");
