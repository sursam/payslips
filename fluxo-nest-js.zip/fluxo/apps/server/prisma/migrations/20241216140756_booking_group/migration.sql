/*
  Warnings:

  - You are about to drop the column `amount` on the `transactions_history` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[group_id]` on the table `transactions_history` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `base_price` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fees` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `group_id` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `status` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `taxes` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `total` to the `transactions_history` table without a default value. This is not possible if the table is not empty.
  - Added the required column `transfer_amount` to the `transactions_history` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "BookingPassGroup" ADD COLUMN     "base_total_price" DOUBLE PRECISION,
ADD COLUMN     "confirmation_numbers" TEXT,
ADD COLUMN     "fees" DOUBLE PRECISION,
ADD COLUMN     "payment_intent_id" TEXT,
ADD COLUMN     "taxes" DOUBLE PRECISION,
ADD COLUMN     "total_price" DOUBLE PRECISION,
ADD COLUMN     "transfer_amount" DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "transactions_history" DROP COLUMN "amount",
ADD COLUMN     "base_price" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "fees" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "group_id" TEXT NOT NULL,
ADD COLUMN     "status" TEXT NOT NULL,
ADD COLUMN     "taxes" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "total" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "transfer_amount" DOUBLE PRECISION NOT NULL,
ALTER COLUMN "balance_transaction_id" DROP NOT NULL,
ALTER COLUMN "transfer_id" DROP NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "transactions_history_group_id_key" ON "transactions_history"("group_id");
