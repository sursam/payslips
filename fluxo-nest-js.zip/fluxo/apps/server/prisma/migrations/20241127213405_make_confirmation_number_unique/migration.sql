/*
  Warnings:

  - A unique constraint covering the columns `[confirmation_number]` on the table `BookingPass` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "BookingPass_confirmation_number_key" ON "BookingPass"("confirmation_number");
