-- AlterTable
ALTER TABLE "hosts" ADD COLUMN     "business_phone_number_country" TEXT DEFAULT 'USA';
