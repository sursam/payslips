/*
  Warnings:

  - You are about to drop the column `email_verification_code` on the `users` table. All the data in the column will be lost.
  - Added the required column `user_type` to the `users` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "UserType" AS ENUM ('HOST', 'GUEST');

-- AlterTable
ALTER TABLE "users" DROP COLUMN "email_verification_code",
ADD COLUMN     "user_type" "UserType" NOT NULL,
ADD COLUMN     "verification_code" TEXT;

-- CreateTable
CREATE TABLE "guests" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "bio" TEXT,
    "location" TEXT NOT NULL,
    "phone_number" TEXT NOT NULL,
    "job_title" TEXT NOT NULL,
    "date_of_birth" TIMESTAMP(3) NOT NULL,
    "speaks" TEXT,
    "pronouns" TEXT,

    CONSTRAINT "guests_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hosts" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "businessName" TEXT NOT NULL,
    "businessLocation" TEXT NOT NULL,
    "businessPhoneNumber" TEXT NOT NULL,
    "businessTaxId" TEXT NOT NULL,

    CONSTRAINT "hosts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "guests_userId_key" ON "guests"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "hosts_userId_key" ON "hosts"("userId");

-- AddForeignKey
ALTER TABLE "guests" ADD CONSTRAINT "guests_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hosts" ADD CONSTRAINT "hosts_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
