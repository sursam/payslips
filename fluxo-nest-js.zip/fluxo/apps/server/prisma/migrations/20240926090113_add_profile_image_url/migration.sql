-- AlterTable
ALTER TABLE "guests" ADD COLUMN     "profileImageUrl" TEXT;
