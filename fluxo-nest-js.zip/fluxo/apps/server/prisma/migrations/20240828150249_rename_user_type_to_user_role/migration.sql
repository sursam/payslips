/*
  Warnings:

  - You are about to drop the column `user_type` on the `users` table. All the data in the column will be lost.
  - Added the required column `user_role` to the `users` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('HOST', 'GUEST');

-- AlterTable
ALTER TABLE "users" DROP COLUMN "user_type",
ADD COLUMN     "user_role" "UserRole" NOT NULL;

-- DropEnum
DROP TYPE "UserType";
