/*
  Warnings:

  - You are about to drop the column `location` on the `guests` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[guest_id]` on the table `Location` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `guest_id` to the `Location` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Location" ADD COLUMN     "guest_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "availabilities" ALTER COLUMN "from" DROP NOT NULL,
ALTER COLUMN "to" DROP NOT NULL;

-- AlterTable
ALTER TABLE "guests" DROP COLUMN "location";

-- CreateIndex
CREATE UNIQUE INDEX "Location_guest_id_key" ON "Location"("guest_id");

-- AddForeignKey
ALTER TABLE "Location" ADD CONSTRAINT "Location_guest_id_fkey" FOREIGN KEY ("guest_id") REFERENCES "guests"("id") ON DELETE CASCADE ON UPDATE CASCADE;
