-- DropIndex
DROP INDEX "stripe_coupons_name_key";
