/*
  Warnings:

  - You are about to drop the column `userId` on the `properties` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[hostId]` on the table `properties` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `hostId` to the `properties` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "properties" DROP CONSTRAINT "properties_userId_fkey";

-- DropIndex
DROP INDEX "properties_userId_key";

-- AlterTable
ALTER TABLE "properties" DROP COLUMN "userId",
ADD COLUMN     "hostId" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "properties_hostId_key" ON "properties"("hostId");

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_hostId_fkey" FOREIGN KEY ("hostId") REFERENCES "hosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
