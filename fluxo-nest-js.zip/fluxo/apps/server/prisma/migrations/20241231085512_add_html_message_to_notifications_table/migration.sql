-- AlterTable
ALTER TABLE "notifications" ADD COLUMN     "html_message" TEXT NOT NULL DEFAULT '';
