-- AlterTable
ALTER TABLE "spaces" ALTER COLUMN "description" SET DATA TYPE VARCHAR(3000);
