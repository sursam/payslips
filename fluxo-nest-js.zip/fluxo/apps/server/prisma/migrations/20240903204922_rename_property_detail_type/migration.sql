/*
  Warnings:

  - The values [FEATURES,VIBES] on the enum `PropertyDetailType` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "PropertyDetailType_new" AS ENUM ('CATEGORY', 'FEATURE', 'VIBE');
ALTER TABLE "property_details" ALTER COLUMN "type" TYPE "PropertyDetailType_new" USING ("type"::text::"PropertyDetailType_new");
ALTER TYPE "PropertyDetailType" RENAME TO "PropertyDetailType_old";
ALTER TYPE "PropertyDetailType_new" RENAME TO "PropertyDetailType";
DROP TYPE "PropertyDetailType_old";
COMMIT;
