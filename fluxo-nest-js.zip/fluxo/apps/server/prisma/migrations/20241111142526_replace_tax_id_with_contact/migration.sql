/*
  Warnings:

  - You are about to drop the column `business_tax_id` on the `hosts` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "hosts" DROP COLUMN "business_tax_id",
ADD COLUMN     "business_contact" TEXT NOT NULL DEFAULT '';
