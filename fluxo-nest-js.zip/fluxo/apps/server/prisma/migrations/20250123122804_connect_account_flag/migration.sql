-- AlterTable
ALTER TABLE "stripe_business_accounts" ADD COLUMN     "been_already_verified" BOOLEAN NOT NULL DEFAULT false;
