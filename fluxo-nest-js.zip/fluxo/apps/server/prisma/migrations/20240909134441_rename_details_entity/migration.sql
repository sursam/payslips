/*
  Warnings:

  - You are about to drop the `_PropertyToPropertyDetail` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `property_details` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "AttributeType" AS ENUM ('PROPERTY_CATEGORY', 'PROPERTY_FEATURE', 'PROPERTY_VIBE', 'SPACE_FEATURE');

-- DropForeignKey
ALTER TABLE "_PropertyToPropertyDetail" DROP CONSTRAINT "_PropertyToPropertyDetail_A_fkey";

-- DropForeignKey
ALTER TABLE "_PropertyToPropertyDetail" DROP CONSTRAINT "_PropertyToPropertyDetail_B_fkey";

-- DropTable
DROP TABLE "_PropertyToPropertyDetail";

-- DropTable
DROP TABLE "property_details";

-- DropEnum
DROP TYPE "PropertyDetailType";

-- CreateTable
CREATE TABLE "attributes" (
    "id" TEXT NOT NULL,
    "name" VARCHAR(80) NOT NULL,
    "type" "AttributeType" NOT NULL,
    "icon_url" TEXT,
    "standard" BOOLEAN DEFAULT false,

    CONSTRAINT "attributes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_AttributeToProperty" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "_AttributeToProperty_AB_unique" ON "_AttributeToProperty"("A", "B");

-- CreateIndex
CREATE INDEX "_AttributeToProperty_B_index" ON "_AttributeToProperty"("B");

-- AddForeignKey
ALTER TABLE "_AttributeToProperty" ADD CONSTRAINT "_AttributeToProperty_A_fkey" FOREIGN KEY ("A") REFERENCES "attributes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_AttributeToProperty" ADD CONSTRAINT "_AttributeToProperty_B_fkey" FOREIGN KEY ("B") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;
