-- CreateEnum
CREATE TYPE "HostPauseSource" AS ENUM ('FLUXO', 'RMS');

-- AlterTable
ALTER TABLE "hosts" ADD COLUMN     "pauseSource" "HostPauseSource";
