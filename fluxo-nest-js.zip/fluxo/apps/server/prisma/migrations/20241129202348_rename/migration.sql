/*
  Warnings:

  - You are about to drop the column `arrival_time` on the `BookingPass` table. All the data in the column will be lost.
  - You are about to drop the column `departure_time` on the `BookingPass` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "BookingPass" DROP COLUMN "arrival_time",
DROP COLUMN "departure_time",
ADD COLUMN     "arrival_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "departure_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
