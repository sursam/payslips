-- AlterTable
ALTER TABLE "guests" ALTER COLUMN "phone_number" DROP NOT NULL;

-- AlterTable
ALTER TABLE "hosts" ALTER COLUMN "business_phone_number" DROP NOT NULL;
