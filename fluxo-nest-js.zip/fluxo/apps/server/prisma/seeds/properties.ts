import { AttributeType, DayOfWeek, Prisma, PrismaClient } from '@prisma/client'
import { hashSync } from 'bcryptjs'
import { formatISO } from 'date-fns'

const imagesList = [
  'https://plus.unsplash.com/premium_photo-1675805015392-28fd80c551ec?q=80&w=3732&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?q=80&w=3552&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://plus.unsplash.com/premium_photo-1673697239981-389164b7b87f?q=80&w=3488&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=3506&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://plus.unsplash.com/premium_photo-1675826774815-35b8a48ddc2c?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?q=80&w=3674&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1490682143684-14369e18dce8?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
] as string[]

const prisma = new PrismaClient()

const data = [
  {
    firstName: 'John',
    lastName: 'Morgan',
    email: 'host@gmail.com',
    businessName: 'Starbucks',
    businessLocation: {
      address: '1500 Broadway, New York, NY 10036, United States',
      coordinates: 'POINT (40.76043072581273 -73.97607952695631)',
    },
    businessContact: 'email@gmail.com',
    businessPhoneNumber: '+12324252522',
    neighborhood: 'Oakland',
    heroImage: imagesList[0],
    availability: [
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.MONDAY },
      { from: '10:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY },
      { from: '09:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.FRIDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.SATURDAY },
    ],
    spaces: {
      name: 'Test Space',
      cost: 121,
      capacity: 5,
      imagesList: [imagesList[1], imagesList[3]],
      manualBookingApproval: false,
      availability: [{ from: '10:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY }],
    },
    dayPass: {
      cost: 121,
      quantity: 4,
      availability: [{ from: '10:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY }],
    },
    locations: {
      address: 'UNIQLO 5th Avenue',
      coordinates: 'POINT (40.76043072581273 -73.97607952695631)',
    },
  },
  {
    firstName: 'Jeremy',
    lastName: 'Ferguson',
    email: 'host1@gmail.com',
    businessName: 'Book Store',
    businessLocation: {
      address: '1073 6th Ave, New York, NY 10018, United States',
      coordinates: 'POINT (40.76043072581273 -73.97607952695631)',
    },
    coordinates: '40.75519763557978 -73.98507098489823',
    businessContact: 'email@gmail.com',
    businessPhoneNumber: '+12324252522',
    neighborhood: 'Springs',
    heroImage: imagesList[4],
    availability: [
      { from: '09:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.MONDAY },
      { from: '09:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.TUESDAY },
      { from: '10:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY },
      { from: '09:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.FRIDAY },
      { from: '09:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.SATURDAY },
    ],
    spaces: {
      name: 'Another Space',
      cost: 213,
      capacity: 3,
      imagesList: [imagesList[2], imagesList[0]],
      manualBookingApproval: true,
      availability: [{ from: '09:00 AM', to: '07:00 PM', dayOfWeek: DayOfWeek.FRIDAY }],
    },
    dayPass: {
      cost: 233,
      quantity: 3,
      availability: [{ from: '08:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.FRIDAY }],
    },
    locations: {
      address: 'Plecosystems Inc',
      coordinates: 'POINT (40.75755436455296 -73.97814789069454)',
    },
  },
  {
    firstName: 'Michaella',
    lastName: 'Peterson',
    email: 'host2@gmail.com',
    businessName: 'Green Gourmet',
    businessLocation: {
      address: '7 Park Ave #1, New York, NY 10016, United States',
      coordinates: 'POINT (40.76043072581273 -73.97607952695631)',
    },
    coordinates: '40.747141172825465 -73.98097357008601',
    businessContact: 'email@gmail.com',
    businessPhoneNumber: '+12324252522',
    neighborhood: 'Manhattan',
    heroImage: imagesList[3],
    availability: [
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.MONDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.TUESDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.THURSDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.FRIDAY },
      { from: '08:00 AM', to: '09:00 PM', dayOfWeek: DayOfWeek.SATURDAY },
    ],
    spaces: {
      name: 'Another Space',
      cost: 315,
      capacity: 20,
      imagesList: [imagesList[4], imagesList[5], imagesList[6], imagesList[7]],
      manualBookingApproval: false,
      availability: [
        { from: '09:00 AM', to: '07:00 PM', dayOfWeek: DayOfWeek.MONDAY },
        { from: '09:00 AM', to: '07:00 PM', dayOfWeek: DayOfWeek.WEDNESDAY },
        { from: '09:00 AM', to: '07:00 PM', dayOfWeek: DayOfWeek.FRIDAY },
      ],
    },
    dayPass: {
      cost: 100,
      quantity: 5,
      availability: [
        { from: '08:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.THURSDAY },
        { from: '08:00 AM', to: '08:00 PM', dayOfWeek: DayOfWeek.FRIDAY },
      ],
    },
    locations: {
      address: 'Radio City Music Hall',
      coordinates: 'POINT (40.760006487030644 -73.97997081413871)',
    },
  },
]

export const runPropertySeed = async (): Promise<void> => {
  await prisma.$transaction([prisma.property.deleteMany()])

  for (const item of data) {
    const { id: userId } = await prisma.user.upsert({
      where: { email: item.email },
      update: {},
      create: {
        email: item.email,
        firstName: item.firstName,
        lastName: item.lastName,
        role: 'HOST',
        password: hashSync('12345678', 12),
      },
    })

    await prisma.user.update({
      where: { id: userId },
      data: { emailVerified: true, verificationCode: null },
    })

    const { id: hostId } = await prisma.host.upsert({
      where: { userId },
      update: {
        user: {
          connect: { id: userId },
        },
        businessName: item.businessName,
        businessContact: item.businessContact,
        businessPhoneNumber: item.businessPhoneNumber,
      },
      create: {
        user: {
          connect: { id: userId },
        },
        businessName: item.businessName,
        businessContact: item.businessContact,
        businessPhoneNumber: item.businessPhoneNumber,
      },
    })

    const propCategories = await prisma.attribute.findMany({
      where: { type: AttributeType.PROPERTY_CATEGORY },
      take: 4,
      skip: Math.floor(
        Math.random() *
          (await prisma.attribute.count({ where: { type: AttributeType.PROPERTY_CATEGORY } })),
      ),
      select: { id: true },
    })
    const propVibes = await prisma.attribute.findMany({
      where: { type: AttributeType.PROPERTY_VIBE },
      take: 5,
      select: { id: true },
    })
    const propFeatures = await prisma.attribute.findMany({
      where: { type: AttributeType.PROPERTY_FEATURE },
      take: 10,
      skip: Math.floor(
        Math.random() *
          (await prisma.attribute.count({ where: { type: AttributeType.PROPERTY_FEATURE } })),
      ),
      select: { id: true },
    })
    const spaceCategories = await prisma.attribute.findMany({
      where: { type: AttributeType.SPACE_CATEGORY },
      take: 3,
      skip: Math.floor(
        Math.random() *
          (await prisma.attribute.count({ where: { type: AttributeType.SPACE_CATEGORY } })),
      ),
      select: { id: true },
    })
    const spaceFeatures = await prisma.attribute.findMany({
      where: { type: AttributeType.SPACE_FEATURE },
      take: 12,
      skip: Math.floor(
        Math.random() *
          (await prisma.attribute.count({ where: { type: AttributeType.SPACE_FEATURE } })),
      ),
      select: { id: true },
    })

    await prisma.property
      .create({
        data: {
          logoUrl:
            'https://www.adaptivewfs.com/wp-content/uploads/2020/07/logo-placeholder-image.png',
          neighborhood: item.neighborhood,
          hostId,
          unlistedDays: Array.from({ length: 12 }).map((_, idx) => {
            const now = new Date()
            return formatISO(now.setDate(now.getDate() + idx))
          }),
          wifiPassword: '12345',
          wifiName: 'Public WiFi',
          description:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
          name: item.businessName,
          images: imagesList,
          heroImage: item.heroImage,
          spaces: {
            create: {
              name: item.spaces.name,
              description:
                'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
              images: item.spaces.imagesList,
              capacity: item.spaces.capacity,
              hourlyCost: item.spaces.cost,
              manualBookingApproval: item.spaces.manualBookingApproval,
              attributes: {
                connect: [
                  ...propCategories,
                  ...propVibes,
                  ...propFeatures,
                  ...spaceCategories,
                  ...spaceFeatures,
                ],
              },
              availability: {
                createMany: {
                  data: item.spaces.availability,
                },
              },
            },
          },
          dayPass: {
            create: {
              dailyCost: item.dayPass.cost,
              description:
                'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
              quantity: item.dayPass.quantity,
              availability: {
                createMany: {
                  data: item.dayPass.availability,
                },
              },
            },
          },
          availability: {
            createMany: {
              data: item.availability,
            },
          },
          attributes: {
            connect: [
              ...propCategories,
              ...propVibes,
              ...propFeatures,
              ...spaceCategories,
              ...spaceFeatures,
            ],
          },
        },
      })
      .then(async (res) => {
        await prisma.$queryRaw(Prisma.sql`
              INSERT INTO "locations" ("id", "address", "coordinates", "property_id", "host_id")
              VALUES (uuid_generate_v4(), ${item.locations.address}, ST_GeomFromText(${item.locations.coordinates}, 4326), ${res.id}, null);
          `)

        await prisma.location.deleteMany({ where: { hostId: res.hostId } })
        await prisma.$queryRaw(Prisma.sql`
              INSERT INTO "locations" ("id", "address", "coordinates", "property_id", "host_id")
              VALUES (uuid_generate_v4(), ${item.businessLocation.address}, ST_GeomFromText(${item.businessLocation.coordinates}, 4326), null, ${res.hostId});
          `)
      })
  }
}
