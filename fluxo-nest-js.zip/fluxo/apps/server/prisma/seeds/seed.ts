import { PrismaClient } from '@prisma/client'

// import { hashSync } from 'bcryptjs'
// import { formatISO } from 'date-fns'
// import attributesList, { mapToAttributes } from './attributes'
// import { runPropertySeed } from './properties'

const prisma = new PrismaClient()

// const runAttributesSeed = async (): Promise<void> => {
//   const mergedAttributes = mapToAttributes(attributesList)
//
//   await prisma.$transaction([prisma.attribute.deleteMany()])
//
//   await prisma.attribute.createMany({ data: mergedAttributes })
// }

const runRmsConfigurationSeed = async (): Promise<void> => {
  await prisma.$transaction([prisma.rmsConfiguration.deleteMany()])

  await prisma.rmsConfiguration.create({
    data: {
      authToken: '',
      serverUrl: process.env.RMS_CLOUD_DEFAULT_URL ?? 'https://restapi13.rmscloud.com',
    },
  })
}

// const runGuestSeed = async (): Promise<void> => {
//   const { id: userId } = await prisma.user.upsert({
//     where: { email: 'guest@gmail.com' },
//     update: {},
//     create: {
//       email: 'guest@gmail.com',
//       firstName: 'Mary',
//       lastName: 'Johnson',
//       role: 'GUEST',
//       password: hashSync('12345678', 12),
//     },
//   })
//
//   await prisma.user.update({
//     where: { id: userId },
//     data: { emailVerified: true, verificationCode: null },
//   })
//
//   const { id: guestId } = await prisma.guest.upsert({
//     where: { userId },
//     create: {
//       user: { connect: { id: userId } },
//       bio: 'Bio',
//       jobTitle: 'Assistant',
//       phoneNumber: '+12324252522',
//       dateOfBirth: formatISO(new Date()),
//       pronouns: 'She/Her',
//     },
//     update: {
//       user: {
//         connect: { id: userId },
//       },
//       bio: 'Bio',
//       jobTitle: 'Assistant',
//       phoneNumber: '+12324252522',
//       dateOfBirth: formatISO(new Date()),
//       pronouns: 'She/Her',
//     },
//     include: {
//       user: {
//         include: {
//           guest: { include: { location: true } },
//         },
//       },
//     },
//   })
//
//   await prisma.location.deleteMany({ where: { guestId } })
//   await prisma.$queryRaw(Prisma.sql`
//       INSERT INTO "locations" ("id", "address", "coordinates", "property_id", "guest_id")
//       VALUES (uuid_generate_v4(), '45 Rockefeller Plaza, New York, NY 10111, United States',
//               ST_GeomFromText('POINT(40.75901654425811 -73.97859023039268)', 4326), NULL, ${guestId});
//   `)
// }

async function run(): Promise<void> {
  await runRmsConfigurationSeed()
  // await runAttributesSeed()
  //  await runGuestSeed()
  //  await runPropertySeed()
}

void run()
