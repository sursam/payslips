import type { AttributeType, Prisma } from '@prisma/client'

const attributesList = {
  PROPERTY_CATEGORY: [
    {
      name: 'Bar',
      iconUrl: 'https://static.stage.fluxo.work/property_category/bar.png',
    },
    {
      name: 'Restaurant',
      iconUrl: 'https://static.stage.fluxo.work/property_category/restaurant.png',
    },
    {
      name: 'Brewery',
      iconUrl: 'https://static.stage.fluxo.work/property_category/brewery.png',
    },
    {
      name: 'Coffee Shop',
      iconUrl: 'https://static.stage.fluxo.work/property_category/coffee_shop.png',
    },
    {
      name: 'Office',
      iconUrl: 'https://static.stage.fluxo.work/property_category/office.png',
    },
    {
      name: 'Hotel',
      iconUrl: 'https://static.stage.fluxo.work/property_category/hotel.png',
    },
    {
      name: 'Coworking',
      iconUrl: 'https://static.stage.fluxo.work/property_category/coworking.png',
    },
    {
      name: 'Office b&b',
      iconUrl: 'https://static.stage.fluxo.work/property_category/officebnb.png',
    },
    {
      name: 'Storefront',
      iconUrl: 'https://static.stage.fluxo.work/property_category/storefront.png',
    },
    {
      name: 'Event Space',
      iconUrl: 'https://static.stage.fluxo.work/property_category/event.png',
    },
    {
      name: 'Pop-up',
      iconUrl: 'https://static.stage.fluxo.work/property_category/popup.png',
    },
    {
      name: 'Studio',
      iconUrl: 'https://static.stage.fluxo.work/property_category/studio.png',
    },
    {
      name: 'Theatre',
      iconUrl: 'https://static.stage.fluxo.work/property_category/theatre.png',
    },
    {
      name: 'Gallery',
      iconUrl: 'https://static.stage.fluxo.work/property_category/gallery.png',
    },
    {
      name: 'Library',
      iconUrl: 'https://static.stage.fluxo.work/property_category/library.png',
    },
    {
      name: 'Community Space',
      iconUrl: 'https://static.stage.fluxo.work/property_category/community.png',
    },
    {
      name: 'Gym',
      iconUrl: 'https://static.stage.fluxo.work/property_category/gym.png',
    },
    {
      name: '??',
      iconUrl: 'https://static.stage.fluxo.work/property_category/___.png',
    },
  ],
  PROPERTY_FEATURE: [
    {
      name: 'Great Wi-Fi',
      standard: true,
      iconUrl: 'https://static.stage.fluxo.work/property_features/fast_wifi.png',
    },
    {
      name: 'Power Access',
      standard: true,
      iconUrl: 'https://static.stage.fluxo.work/property_features/power.png',
    },
    {
      name: 'Coffee & Water',
      standard: true,
      iconUrl: 'https://static.stage.fluxo.work/property_features/specialty_coffee.png',
    },
    {
      name: 'Guaranteed Spot',
      standard: true,
      iconUrl: 'https://static.stage.fluxo.work/property_features/table.png',
    },
    {
      name: '150MB+ Wi-Fi',
      iconUrl: 'https://static.stage.fluxo.work/property_features/fast_wifi.png',
    },
    {
      name: 'ADA Compliant',
      iconUrl: 'https://static.stage.fluxo.work/property_features/wheelchair.png',
    },
    {
      name: 'Alt-Milks',
      iconUrl: 'https://static.stage.fluxo.work/property_features/milk.png',
    },
    {
      name: 'Backyard',
      iconUrl: 'https://static.stage.fluxo.work/property_features/outdoors.png',
    },
    {
      name: 'Bar Games',
      iconUrl: 'https://static.stage.fluxo.work/property_features/dart.png',
    },
    {
      name: 'Bike Storage',
      iconUrl: 'https://static.stage.fluxo.work/property_features/bike.png',
    },
    {
      name: 'Board Games',
      iconUrl: 'https://static.stage.fluxo.work/property_features/boardgames.png',
    },
    {
      name: 'Booths',
      iconUrl: 'https://static.stage.fluxo.work/property_features/booth.png',
    },
    {
      name: 'BYOFood',
      iconUrl: 'https://static.stage.fluxo.work/property_features/byofood.png',
    },
    {
      name: 'Coat Check',
      iconUrl: 'https://static.stage.fluxo.work/property_features/hanger.png',
    },
    {
      name: 'Cozy Couches',
      iconUrl: 'https://static.stage.fluxo.work/property_features/couch.png',
    },
    {
      name: 'Filming Allowed',
      iconUrl: 'https://static.stage.fluxo.work/property_features/film.png',
    },
    {
      name: 'Food Menu',
      iconUrl: 'https://static.stage.fluxo.work/property_features/food.png',
    },
    {
      name: 'Front Yard',
      iconUrl: 'https://static.stage.fluxo.work/property_features/yard.png',
    },
    {
      name: 'Happy Hour Specials',
      iconUrl: 'https://static.stage.fluxo.work/property_features/happy_hour.png',
    },
    {
      name: 'Healthy Food Options',
      iconUrl: 'https://static.stage.fluxo.work/property_features/apple.png',
    },
    {
      name: 'Heavy Wooden Tables',
      iconUrl: 'https://static.stage.fluxo.work/property_features/wooden_table.png',
    },
    {
      name: 'High Tops',
      iconUrl: 'https://static.stage.fluxo.work/property_features/hightop.png',
    },
    {
      name: 'Killer Views',
      iconUrl: 'https://static.stage.fluxo.work/property_features/view.png',
    },
    {
      name: 'Lockers',
      iconUrl: 'https://static.stage.fluxo.work/property_features/locker.png',
    },
    {
      name: 'Long Tables',
      iconUrl: 'https://static.stage.fluxo.work/property_features/table.png',
    },
    {
      name: 'Lunch Special',
      iconUrl: 'https://static.stage.fluxo.work/property_features/lunch.png',
    },
    {
      name: 'Microwave',
      iconUrl: 'https://static.stage.fluxo.work/property_features/microwave.png',
    },
    {
      name: 'Natural Light',
      iconUrl: 'https://static.stage.fluxo.work/property_features/sun.png',
    },
    {
      name: 'Paper Shredding',
      iconUrl: 'https://static.stage.fluxo.work/property_features/paper_shred.png',
    },
    {
      name: 'Pet Friendly',
      iconUrl: 'https://static.stage.fluxo.work/property_features/pet.png',
    },
    {
      name: 'Place to Pace',
      iconUrl: 'https://static.stage.fluxo.work/property_features/walk.png',
    },
    {
      name: 'Print/Copy/Scan',
      iconUrl: 'https://static.stage.fluxo.work/property_features/printer.png',
    },
    {
      name: 'Private Meeting Room',
      iconUrl: 'https://static.stage.fluxo.work/property_features/meeting_room.png',
    },
    {
      name: 'Private Space for Calls',
      iconUrl: 'https://static.stage.fluxo.work/property_features/call.png',
    },
    {
      name: 'Quiet Corners',
      iconUrl: 'https://static.stage.fluxo.work/property_features/quiet.png',
    },
    {
      name: 'Real Plants',
      iconUrl: 'https://static.stage.fluxo.work/property_features/plant.png',
    },
    {
      name: 'Rooftop',
      iconUrl: 'https://static.stage.fluxo.work/property_features/rooftop.png',
    },
    {
      name: 'Security/Door Attendant',
      iconUrl: 'https://static.stage.fluxo.work/property_features/security.png',
    },
    {
      name: 'Shower',
      iconUrl: 'https://static.stage.fluxo.work/property_features/shower.png',
    },
    {
      name: 'Specialty Coffee',
      iconUrl: 'https://static.stage.fluxo.work/property_features/specialty_coffee.png',
    },
    {
      name: 'Standing Desks',
      iconUrl: 'https://static.stage.fluxo.work/property_features/standing_desk.png',
    },
    {
      name: 'Street Presence',
      iconUrl: 'https://static.stage.fluxo.work/property_features/street_presence.png',
    },
    {
      name: 'Windows That Open',
      iconUrl: 'https://static.stage.fluxo.work/property_features/window.png',
    },
  ],
  PROPERTY_VIBE: [
    {
      name: 'Quiet',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/shhh.png',
    },
    {
      name: 'Social',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/social.png',
    },
    {
      name: 'Fancy',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/fancy.png',
    },
    {
      name: 'Creative',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/artsy.png',
    },
    {
      name: 'Classic',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/profesh.png',
    },
    {
      name: 'Boozy',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/drafty.png',
    },
    {
      name: 'Leafy',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/leafy.png',
    },
    {
      name: 'Focused',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/grindy.png',
    },
    {
      name: 'Inspiring',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/hmm.png',
    },
    {
      name: 'Modern',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/y2k5.png',
    },
    {
      name: '??',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/---.png',
    },
    {
      name: 'Comfy',
      iconUrl: 'https://static.stage.fluxo.work/property_vibes/comfy.png',
    },
  ],
  SPACE_FEATURE: [
    {
      name: 'Power outlets',
      iconUrl: 'https://static.stage.fluxo.work/space_features/power+outlets.png',
    },
    {
      name: 'Projector/screen',
      iconUrl: 'https://static.stage.fluxo.work/space_features/projector.png',
    },
    {
      name: 'Sound system',
      iconUrl: 'https://static.stage.fluxo.work/space_features/sound+system.png',
    },
    {
      name: 'Comfortable seating',
      iconUrl: 'https://static.stage.fluxo.work/space_features/comfortable+seating.png',
    },
    {
      name: 'Climate control',
      iconUrl: 'https://static.stage.fluxo.work/space_features/climate+control.png',
    },
    {
      name: 'Adjustable lighting',
      iconUrl: 'https://static.stage.fluxo.work/space_features/adjustable+lighting.png',
    },
    {
      name: 'Flexible furniture/layout',
      iconUrl: 'https://static.stage.fluxo.work/space_features/flexible+furniture.png',
    },
    {
      name: 'Specialized equipment (e.g. kitchen, studio, workshop tools)',
      iconUrl: 'https://static.stage.fluxo.work/space_features/specialized+equipment.png',
    },
    {
      name: 'Security systems',
      iconUrl: 'https://static.stage.fluxo.work/space_features/security+system.png',
    },
    {
      name: 'Storage space',
      iconUrl: 'https://static.stage.fluxo.work/space_features/storage+space.png',
    },
    {
      name: 'Locker rooms and showers',
      iconUrl: 'https://static.stage.fluxo.work/space_features/locker+rooms+and+shower.png',
    },
    {
      name: 'Outdoor seating',
      iconUrl: 'https://static.stage.fluxo.work/space_features/outdoor+seating.png',
    },
    {
      name: 'Whiteboards/flipcharts',
      iconUrl: 'https://static.stage.fluxo.work/space_features/whiteboard.png',
    },
    {
      name: 'Acoustic enhancements',
      iconUrl: 'https://static.stage.fluxo.work/space_features/acoustic+enhancements.png',
    },
    {
      name: 'Stage/screen setup',
      iconUrl: 'https://static.stage.fluxo.work/space_features/stage.png',
    },
    {
      name: 'Privacy dividers',
      iconUrl: 'https://static.stage.fluxo.work/space_features/privacy+dividers.png',
    },
    {
      name: 'Catering options',
      iconUrl: 'https://static.stage.fluxo.work/space_features/catering+options.png',
    },
    {
      name: 'Privacy',
      iconUrl: 'https://static.stage.fluxo.work/space_features/privacy.png',
    },
    {
      name: 'Inside only',
      iconUrl: 'https://static.stage.fluxo.work/space_features/inside+only.png',
    },
    {
      name: 'Outside only',
      iconUrl: 'https://static.stage.fluxo.work/space_features/outside+only.png',
    },
    {
      name: 'Inside & Outside',
      iconUrl: 'https://static.stage.fluxo.work/space_features/Inside+and+outside.png',
    },
  ],
  SPACE_CATEGORY: [
    {
      name: 'Meeting Room',
      iconUrl: 'https://static.stage.fluxo.work/space_category/meeting+room.png',
    },
    {
      name: 'Shared Table',
      iconUrl: 'https://static.stage.fluxo.work/space_category/shared+table.png',
    },
    {
      name: 'Roof Terrace',
      iconUrl: 'https://static.stage.fluxo.work/space_category/roof+terrace.png',
    },
    {
      name: 'Makerspace/Workshop',
      iconUrl: 'https://static.stage.fluxo.work/space_category/makerspace.png',
    },
    {
      name: 'Sporting Facility',
      iconUrl: 'https://static.stage.fluxo.work/space_category/sporting+facility.png',
    },
    {
      name: 'Podcast Studio',
      iconUrl: 'https://static.stage.fluxo.work/space_category/podcast+studio.png',
    },
    {
      name: 'Classroom',
      iconUrl: 'https://static.stage.fluxo.work/space_category/classroom.png',
    },
    {
      name: 'Shared Booth',
      iconUrl: 'https://static.stage.fluxo.work/space_category/shared+booth.png',
    },
    {
      name: 'Gallery',
      iconUrl: 'https://static.stage.fluxo.work/space_category/gallery.png',
    },
    {
      name: 'Fitness/Yoga Studio',
      iconUrl: 'https://static.stage.fluxo.work/space_category/fitness.png',
    },
    {
      name: 'Stage/Screen/Auditorium',
      iconUrl: 'https://static.stage.fluxo.work/space_features/stage.png',
    },
    {
      name: 'Boutique',
      iconUrl: 'https://static.stage.fluxo.work/space_category/popup.png',
    },
    {
      name: 'Entire Venue',
      iconUrl: 'https://static.stage.fluxo.work/space_category/entire+venue.png',
    },
    {
      name: 'Private Office',
      iconUrl: 'https://static.stage.fluxo.work/space_category/private+office.png',
    },
    {
      name: 'Test Kitchen',
      iconUrl: 'https://static.stage.fluxo.work/space_category/test+kitchen.png',
    },
    {
      name: 'Outside Area',
      iconUrl: 'https://static.stage.fluxo.work/space_category/outside+area.png',
    },
    {
      name: 'Film/Photography Studio',
      iconUrl: 'https://static.stage.fluxo.work/space_category/film.png',
    },
    {
      name: 'Game Room',
      iconUrl: 'https://static.stage.fluxo.work/space_category/game+room.png',
    },
  ],
}

export function mapToAttributes(
  attributes: typeof attributesList,
): Pick<Prisma.AttributeCreateManyInput, 'name' | 'iconUrl' | 'standard' | 'type'>[] {
  const attributesEntries = Object.entries(attributes)

  return attributesEntries.flatMap(([key, value]) =>
    value.map((el) => ({
      ...el,
      type: key as AttributeType,
    })),
  )
}

export default attributesList
