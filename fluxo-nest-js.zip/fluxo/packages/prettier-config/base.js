module.exports = {
  singleQuote: true,
  trailingComma: "all",
  tabWidth: 2,
  semi: false,
  printWidth: 100,
};
