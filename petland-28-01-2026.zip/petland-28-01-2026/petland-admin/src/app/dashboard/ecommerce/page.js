// import { Row, Col } from "react-bootstrap";
// import Welcome from '@/components/dashboard/Welcome';
// import TotalSales from '@/components/dashboard/TotalSales';
// import TotalOrders from '@/components/dashboard/TotalOrders';
// import TotalCustomers from '@/components/dashboard/TotalCustomers';
// import TotalRevenue from '@/components/dashboard/TotalRevenue';
// import SalesByLocations from '@/components/dashboard/SalesByLocations';
// import TopSellingProducts from '@/components/dashboard/TopSellingProducts';
// import RecentOrders from '@/components/dashboard/RecentOrders';
// import OrderSummary from '@/components/dashboard/OrderSummary';
// import RecentTransactions from '@/components/dashboard/RecentTransactions';
// import ReturningCustomerRate from '@/components/dashboard/ReturningCustomerRate';

// export default function Page() {
//   return (
//     <> 
//       <Row>
//         <Col xs={12} lg={8}>
//           <Welcome />

//           <TotalSales />
//         </Col>

//         <Col xs={12} lg={4}>
//           <TotalOrders />

//           <TotalCustomers />

//           <TotalRevenue />
//         </Col>
//       </Row> 

//       <Row>
//         <Col xs={12} lg={12} xl={5}>
//           <SalesByLocations />
//         </Col>

//         <Col xs={12} lg={12} xl={7}>
//           <TopSellingProducts />
//         </Col>
//       </Row> 

//       <Row>
//         <Col xs={12} lg={12} xl={8}>
//           <RecentOrders />
//         </Col>

//         <Col xs={12} lg={12} xl={4}>
//           <OrderSummary />
//         </Col>
//       </Row>
      
//       <Row>
//         <Col xs={12} lg={4}>
//           <RecentTransactions />
//         </Col>

//         <Col xs={12} lg={8}>
//           <ReturningCustomerRate />
//         </Col>
//       </Row> 
//     </>
//   );
// }

export default function Page() {
  return (
    <> 
    </>
  );
}