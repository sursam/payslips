import ResetPasswordForm from "@/components/Authentication/ResetPasswordForm";

export default function Page() {
  return (
    <>
    
      <ResetPasswordForm />
    </>
  );
}
