// auth.js
import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import type { NextAuthOptions } from "next-auth";

export const authOptions: NextAuthOptions = {
  providers: [
    Credentials({
      name: 'Credentials',
      credentials: {
        email: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
        device_type: { label: 'Device Type', type: 'number' },
      },
      async authorize(credentials) {        
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}email-login`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email_id: credentials?.email,
            password: credentials?.password,
            device_type: credentials?.device_type,
          }),
        });
        const response = await res.json();

        if (!res.ok) {
          throw new Error(response?.message)
        }
        if (res.ok && response?.data && response?.data?.user) {
            const user = response.data.user;
            return user;
        }
        return null;
      },
    }),
  ],
  pages: {
    signIn: '/sign-in', // Custom sign-in page path
  },
  callbacks: {
    async jwt({ token, user } : any) {
      console.log('token', token);
      /*if(token){
        if(!token.needToLogout){
          const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}fetch-user-details/${token?.uuid}`, {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
              'Authorization': `Bearer ${token?.accessToken}`,
            },
          });
          const response = await res.json();
          token.needToLogout = response?.data?.user?.needToLogout;
        }else{

        }        
      }*/
      if (user) {
        token.accessToken = user.accessToken;
        token.uuid = user.uuid;
        token.isVerified = user.isVerified;
        token.needToLogout = user.needToLogout;
      }
      return token
    },
    async session({ session, token, user } : any) {
      // console.log('session, token, user', session, token, user);
      session.accessToken = token.accessToken;
      session.user.uuid = token.uuid;
      session.user.isVerified = token.isVerified;
      session.user.needToLogout = token.needToLogout;
      return session
    }
  },
  session: {
    strategy: 'jwt',
  },
};
const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }