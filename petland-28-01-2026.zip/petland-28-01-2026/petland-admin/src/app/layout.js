'use client';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'remixicon/fonts/remixicon.css'; 
import 'react-calendar/dist/Calendar.css';
import "swiper/css";
import "swiper/css/bundle";
import 'react-datetime-picker/dist/DateTimePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-clock/dist/Clock.css';
import 'react-tabs/style/react-tabs.css';
 
// Styles
import "../../styles/style.css";

import LayoutProvider from '@/providers/LayoutProvider';
import SessionSync from '@/providers/SessionSync';
import { Inter } from "next/font/google";

import { store } from '@/redux/store';
import { Provider } from 'react-redux';
import { SessionProvider } from 'next-auth/react';

const inter = Inter({ subsets: ["latin"] });
// export const metadata = {
//   title: "Pet Land",
//   description: "Pet Land",
// };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SessionProvider>
          <Provider store={store}>
            <LayoutProvider>
              <SessionSync />
              {children}
            </LayoutProvider>
          </Provider>
        </SessionProvider>
      </body>
    </html>
  );
}
