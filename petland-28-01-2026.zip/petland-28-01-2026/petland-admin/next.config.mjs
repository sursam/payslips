import path from 'path';

/** @type {import('next').NextConfig} */
const nextConfig = {
  // async headers() {
  //     return [
  //         {
  //             source: '/:path*', // Match all routes
  //             headers: [
  //                 { key: 'Cache-Control', value: 'no-store, no-cache, must-revalidate, proxy-revalidate' },
  //                 { key: 'Pragma', value: 'no-cache' },
  //                 { key: 'Expires', value: '0' },
  //             ],
  //         },
  //     ];
  // },
  // experimental: {
  //     disableRouterCache: true,
  // },

  images: {
    domains: ["127.0.0.1", "localhost", "3.108.121.124", "alsahraa.shyamfuture.in"],
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  assetPrefix: "",
  env: {
    // serverUrl: "http://3.108.121.124:7002/",
    // serverUrl: "https://alsahraa.shyamfuture.in/",
    // serverUrl: "http://127.0.0.1:7002/",
  },

  webpack: (config) => {
    config.resolve.alias['@'] = path.resolve(new URL('.', import.meta.url).pathname, 'src'); // Change 'src' if your folder is different
    return config;
  },
  turbopack: {}
};

export default nextConfig;