import React, { createContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { toast } from 'react-toastify';

export interface Batch {
    filename: string;
    path: string;
    size: number;
}

export interface Winner {
    position: any; // Change to number
    dog_object_id: { _id: string } | string | null;
    box_number: any; // Change to number
    race_completion_time: any | null;
    mgn: any | null; // Change to number
    split: any | null;
    in_run: any | null;
    weight: any | null;
    dog_price: any | null;
    name?: string;
    trainer?: string;
    batch?: Batch;
}

export interface Round {
    time: string;
    race_round_no: any;
    winners: Winner[];
}

export interface Race {
    race_date: string;
    race_object_id: any;
    dogs?: any; // unspecified type for now
    _id: string;
    race_id?: string;
    race_name?: string;
    date?: string;
    time?: string;
    location?: string;
    distance?: string;
    grade?: string;
    status?: string;
    details?: string;
    title: string;
    raceDate: string;
    round: Round[];
}

export interface EditableRace extends NewRace {
    _id: string; // Include the _id property for editing
}

export type NewRace = {
    race_object_id: string;
    race_date: string;
    grade: string;
    round: Round[];
    dogs?: any;
};

interface RaceContextType {
    races: Race[];
    fetchRaces: () => Promise<Race[]>;
    fetchRaceById: (id: string) => Promise<Race | null>;
    addRace: (race: NewRace) => Promise<any>;
    updateRace: (id: string, race: NewRace) => Promise<any>;
    deleteRace: (id: string) => Promise<Race | null>;
}


const RaceContext = createContext<RaceContextType | undefined>(undefined);

export const RaceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [races, setRaces] = useState<Race[]>([]);

    const fetchRaces = useCallback(async (): Promise<Race[]> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/list`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });
            const data = await response.json();
            if (response.ok) {
                setRaces(data.result);
                console.log('races', data.result);
                return data.result;
            } else {
                toast.error(data.message || 'Failed to fetch race list');
                return [];
            }
        } catch (error) {
            console.error("Error fetching race list:", error);
            return [];
        }
    }, []);

    const fetchRaceById = useCallback(async (id: string): Promise<Race | null> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/edit/${id}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch race by ID');
            }

            const data = await response.json();

            return data.result || null; // ✅ Ensure it extracts the race data correctly
        } catch (error) {
            console.error('Error fetching race by ID:', error);
            return null;
        }
    }, []);


    const addRace = useCallback(async (race: NewRace): Promise<any> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify(race),
            });

            const responseData = await response.json();

            if (!response.ok) {
                throw new Error(responseData.message || 'Error adding race');
            }

            const newRace = responseData.data || responseData;

            setRaces((prevRaces) => [...prevRaces, newRace]);
            return responseData;
        } catch (error: any) {
            console.error('Error adding race:', error);
            return { message: error?.message || 'Error adding race' };
        }
    }, []);

    const updateRace = useCallback(async (id: string, race: NewRace): Promise<any> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/update/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify(race),
            });

            const responseData = await response.json();

            if (!response.ok) {
                throw new Error(responseData.message || 'Failed to update race');
            }

            const updatedRace = responseData.data || null;
            if (updatedRace) {
                setRaces((prevRaces) =>
                    prevRaces.map((r) => (r._id === id ? updatedRace : r))
                );
            }

            return responseData;
        } catch (error) {
            console.error('Error updating race:', error);
            return { message: 'Failed to update race' };
        }
    }, []);

    const deleteRace = useCallback(async (id: string): Promise<Race | null> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/delete/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to delete race');
            }

            const deletedRace = await response.json();
            setRaces((prevRaces) => prevRaces.filter((race) => race._id !== id));
            return deletedRace;
        } catch (error) {
            console.error('Error deleting race:', error);
            return null;
        }
    }, []);

    return (
        <RaceContext.Provider value={{ races, fetchRaces, fetchRaceById, addRace, updateRace, deleteRace }}>
            {children}
        </RaceContext.Provider>
    );
};

export const useRace = (): RaceContextType => {
    const context = React.useContext(RaceContext);
    if (context === undefined) {
        throw new Error('useRace must be used within a RaceProvider');
    }
    return context;
};

