import React, { ReactNode } from 'react';
import { AuthProvider } from './AuthContext';
import { UsersProvider } from './Users';
import { HelmetProvider } from 'react-helmet-async';

const Providers: React.FC<{ children: ReactNode }> = ({ children }) => {
    return (
        <HelmetProvider>
            <AuthProvider>
                <UsersProvider>
                    {children}
                </UsersProvider>
            </AuthProvider>
        </HelmetProvider>
    );
};

export default Providers;