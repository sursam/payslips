import React, { createContext, useState, useCallback, ReactNode } from 'react';

interface Announcement {
	_id?: string;
	subject: string;
	description: string;
	link?: string;
	imageUrl?: string; // URL for the uploaded image if provided by API
	createdAt?: string;
}

interface AnnouncementCreatePayload {
	subject: string;
	description: string;
	link?: string;
	image?: File; // image file for add (optional)
}

interface AnnouncementUpdatePayload {
	subject: string;
	description: string;
	link?: string;
}
interface Notification {
	_id?: string;
	title: string;
	message: string;
	created_at: string;
	status: string; // URL for the uploaded image if provided by API
	member_id?: string;
	__v: number
}
interface AnnouncementContextType {
	notifications: Notification[];
	announcements: Announcement[];
	fetchAnnouncements: () => Promise<void>;
	addAnnouncement: (payload: AnnouncementCreatePayload) => Promise<void>;
	editAnnouncement: (id: string, payload: AnnouncementUpdatePayload) => Promise<void>;
	deleteAnnouncement: (id: string) => Promise<void>;
	fetchNotifications: (id: string) => Promise<void>;
}
const AnnouncementContext = createContext<AnnouncementContextType | undefined>(undefined);

export const AnnouncementProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
	const [announcements, setAnnouncements] = useState<Announcement[]>([]);
	const [notifications, setNotifications] = useState<Notification[]>([]);

	const fetchAnnouncements = useCallback(async () => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}announcement_v2/list`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to fetch announcement list');
			}

			const data = await response.json();
			setAnnouncements(data.result);
		} catch (error) {
			console.error('Error fetching announcements:', error);
		}
	}, []);

	const addAnnouncement = useCallback(async (payload: AnnouncementCreatePayload): Promise<void> => {
		const formData = new FormData();
		formData.append('subject', payload.subject);
		formData.append('description', payload.description);
		if (payload.link) formData.append('link', payload.link);
		if (payload.image) formData.append('image', payload.image);

		const response = await fetch(`${process.env.REACT_APP_API_URL}announcement_v2/add`, {
			method: 'POST',
			headers: {
				'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
			},
			body: formData,
		});

		if (!response.ok) {
			const errorData = await response.json(); // Get the error response
			throw { response: errorData }; // Throw an error with the response data
		}

		await fetchAnnouncements();
	}, [fetchAnnouncements]);

	const editAnnouncement = useCallback(async (id: string, payload: AnnouncementUpdatePayload): Promise<void> => {
		try {
			const body = JSON.stringify({
				subject: payload.subject,
				description: payload.description,
				link: payload.link,
			});

			const response = await fetch(`${process.env.REACT_APP_API_URL}announcement_v2/update/${id}`, {
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
				body,
			});

			if (!response.ok) {
				const errorData = await response.json(); // Get the error response
				throw { response: errorData }; // Throw an error with the response data
			}

			await fetchAnnouncements();
		} catch (error) {
			console.error('Error updating announcement:', error);
			throw error; // Rethrow the error to be handled in the component
		}
	}, [fetchAnnouncements]);



	const deleteAnnouncement = useCallback(async (id: string): Promise<void> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}announcement_v2/delete/${id}`, {
				method: 'DELETE',
				headers: {
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to delete announcement');
			}

			setAnnouncements((prevAnnouncements) => prevAnnouncements.filter(announcement => announcement._id !== id));
		} catch (error) {
			console.error('Error deleting announcement:', error);
		}
	}, []);

	const fetchNotifications = useCallback(async (id: string): Promise<void> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}notifaction/send-notifaction-list/${id}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to fetch announcement list');
			}

			const data = await response.json();
			return data.result;
		} catch (error) {
			console.error('Error fetching notification:', error);
		}
	}, []);

	return (
		<AnnouncementContext.Provider value={{ announcements, fetchAnnouncements, addAnnouncement, editAnnouncement, deleteAnnouncement, notifications, fetchNotifications }}>
			{children}
		</AnnouncementContext.Provider>
	);
};

export const useAnnouncement = (): AnnouncementContextType => {
	const context = React.useContext(AnnouncementContext);
	if (context === undefined) {
		throw new Error('useAnnouncement must be used within an AnnouncementProvider');
	}
	return context;
};
