import React, { createContext, useState, ReactNode, useCallback } from 'react';

export interface Winner {
	position: number;
	batch: {
		filename: string;
		path: string;
		size: number;
	};
	name: string;
	trainer: string;
	race_completion_time: number | null;
	mgn: number | null;
	split: number | null;
	inRun: number | null;
	weight: number | null;
	dogPrice: number | null;
	dogObjectId: string | null;
	time?: string;
}

interface Round {
	rug: string;
	time: string;
	winners: Winner[];
}

export interface Result {
	_id: string;
	result_id: string; // Assuming you have a result_id
	result_name: string; // Assuming you have a result_name
	date: string;
	time: string;
	location: string;
	distance: string;
	grade: string;
	status: string;
	details: string;
	title: string;
	resultDate: string; // Changed from raceDate to resultDate
	round: Round[];
}

export interface EditableResult extends NewResult {
	_id: string; // Include the _id property for editing
}

export type NewResult = Omit<Result, '_id' | 'result_id' | 'result_name' | 'date' | 'distance' | 'status' | 'details' | 'time'>;

interface ResultContextType {
	results: Result[];
	fetchResults: () => Promise<void>;
	fetchResultById: (id: string) => Promise<Result | null>;
	addResult: (result: NewResult) => Promise<any>; // <-- Fixed to return API response
	updateResult: (id: string, result: NewResult) => Promise<any>; // <-- Fixed to return API response
	deleteResult: (id: string) => Promise<Result | null>;
}

const ResultContext = createContext<ResultContextType | undefined>(undefined);

export const ResultProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
	const [results, setResults] = useState<Result[]>([]);

	const fetchResults = useCallback(async () => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}result/list`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to fetch result list');
			}

			const data = await response.json();
			setResults(data.result);
		} catch (error) {
			console.error('Error fetching results:', error);
		}
	}, []);

	const fetchResultById = useCallback(async (id: string): Promise<Result | null> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}result/edit/${id}`, {
				method: 'GET', // Changed to GET for fetching by ID
				headers: {
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to fetch result by ID');
			}

			const data = await response.json();
			return data.data || null;
		} catch (error) {
			console.error('Error fetching result by ID:', error);
			return null;
		}
	}, []);

	const addResult = useCallback(async (result: NewResult): Promise<any> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}result/add`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
				body: JSON.stringify(result),
			});

			const responseData = await response.json();

			if (!response.ok) {
				return responseData;
			}

			setResults((prevResults) => [...prevResults, responseData]);
			return responseData;
		} catch (error: any) {
			console.error('Error adding result:', error);
			return { message: error?.message || 'Error adding result' };
		}
	}, []);

	const updateResult = useCallback(async (id: string, result: NewResult): Promise<any> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}result/update/${id}`, {
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
				body: JSON.stringify(result),
			});

			const responseData = await response.json();

			if (!response.ok) {
				return responseData;
			}

			setResults((prevResults) =>
				prevResults.map((r) => (r._id === id ? responseData.data || r : r))
			);
			return responseData;
		} catch (error) {
			console.error('Error updating result:', error);
			return { message: 'Failed to update result' };
		}
	}, []);

	const deleteResult = useCallback(async (id: string): Promise<Result | null> => {
		try {
			const response = await fetch(`${process.env.REACT_APP_API_URL}result/delete/${id}`, {
				method: 'DELETE',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
				},
			});

			if (!response.ok) {
				throw new Error('Failed to delete result');
			}

			const deletedResult = await response.json();
			setResults((prevResults) => prevResults.filter((result) => result._id !== id));
			return deletedResult;
		} catch (error) {
			console.error('Error deleting result:', error);
			return null;
		}
	}, []);

	return (
		<ResultContext.Provider value={{ results, fetchResults, fetchResultById, addResult, updateResult, deleteResult }}>
			{children}
		</ResultContext.Provider>
	);
};

export const useResult = (): ResultContextType => {
	const context = React.useContext(ResultContext);
	if (context === undefined) {
		throw new Error('useResult must be used within a ResultProvider');
	}
	return context;
};
