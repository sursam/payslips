import { promises } from 'dns';
import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';

interface Dog {
    _id: string;
    dog_id: string;
    dog_name: string;
    date_of_birth: string;
    gender: string;
    color: string;
    breed_s: string;
    breed_d: string;
    owner_id: string;
    trainer_id: string;
    status: string;
    details: string;
    raceHistory: string;
}

interface Race {
    raceId: string;
    raceDate: string;
    position: number;
    details: string;
}

interface DogContextType {
    dogs: Dog[];
    fetchDogs: () => Promise<void>;
    fetchDogById: (id: string) => Promise<Dog | null>;
    adminDogList: () => Promise<Dog[]>; // Update to return Dog[]
    profileDogList: () => Promise<Dog[] | null>;
    addDog: (dogData: FormData) => Promise<void>; // Add the addDog function
    placeOrder: (orderData: {
        member_ObjectId: string;
        billing_name: string;
        billing_address: string;
        country: string;
        state: string;
        city: string;
        orders: Array<{
            dog_ObjectId: string;
            unit_qty: number;
            unit_price: number;
            total_unit_price: number;
        }>;
        total_price: number;
        tax: number;
        platformCharges: number;
        paybleAmount: number;
    }) => Promise<void>;
    updateDog: (dogId: string, dogData: FormData) => Promise<void>; // Add updateDog
    changeDogStatus: (dogId: string, status: string) => Promise<void>; // Add changeDogStatus
    deleteDog: (dogId: string) => Promise<void>; // Add deleteDog
    cartItems: any[]; // Add cartItems to the context type
    setCartItems: React.Dispatch<React.SetStateAction<any[]>>; // Add setCartItems to the context type
    addToCart: (memberId: string, dogId: string, quantity: number, unitPrice: number) => Promise<boolean>; // Change to return boolean
    fetchCartItems: () => Promise<any[]>;
    deleteCartItem: (cartId: string) => Promise<void>; // Add deleteDog
    updateCartItem: (cartId: string, quantity: number) => Promise<void>; // Updated to accept two arguments
    raceHistory: (id: string) => Promise<{ results: Race[] } | null>; // Update raceHistory type
}

const DogContext = createContext<DogContextType | undefined>(undefined);

export const DogProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [dogs, setDogs] = useState<Dog[]>([]);
    const [cartItems, setCartItems] = useState<any[]>([]);

    const fetchDogs = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}member/dog/list`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch dog list');
            }

            const data = await response.json();
            setDogs(data.data);
        } catch (error) {
            console.error('Error fetching dogs:', error);
        }
    };

    const addDog = async (dogData: FormData) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}dog/details/add`, {
                method: 'POST',
                body: dogData,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                    'contenttype': 'multipart/form-data',
                    'Accept': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to add dog');
            }

            await adminDogList(); // Refresh the dog list after adding a new dog  
        } catch (error) {
            console.error('Error adding dog:', error);
        }
    };

    const adminDogList = useCallback(async (): Promise<Dog[]> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}dog/details/list`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch dog list for admin');
            }

            const data = await response.json();
            setDogs(data.result);
            return data.result;
        } catch (error) {
            console.error('Error fetching dog list for admin:', error);
            return [];
        }
    }, []);

    const profileDogList = useCallback(async (): Promise<Dog[] | null> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}member/dog/my-list`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch profile dog list');
            }

            const data = await response.json();
            return data.result ?? null; // Return the result array or null
        } catch (error) {
            console.error('Error fetching dog list:', error);
            return null; // Return null in case of error
        }
    }, []);


    const fetchDogById = useCallback(async (id: string): Promise<Dog | null> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}member/dog/details/${id}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch dog by ID');
            }

            const data = await response.json();
            return data.data || null; // Assuming the API returns the dog object in 'result'
        } catch (error) {
            console.error('Error fetching dog by ID:', error);
            return null; // Return null in case of error
        }
    }, []);

    const updateDog = async (dogId: string, dogData: FormData) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}dog/details/update/${dogId}`, {
                method: 'PUT',
                body: dogData,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                    'contenttype': 'multipart/form-data',
                    'Accept': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to update dog');
            }

            await adminDogList(); // Refresh the dog list after updating
        } catch (error) {
            console.error('Error updating dog:', error);
        }
    };

    const changeDogStatus = async (dogId: string, status: string) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}dog/details/status-update/${dogId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status }),
            });

            if (!response.ok) {
                throw new Error('Failed to change dog status');
            }

            await adminDogList(); // Refresh the dog list after changing status
        } catch (error) {
            console.error('Error changing dog status:', error);
        }
    };

    const deleteDog = async (dogId: string) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}dog/details/delete/${dogId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to delete dog');
            }

            await adminDogList(); // Refresh the dog list after deleting
        } catch (error) {
            console.error('Error deleting dog:', error);
        }
    };

    // const placeOrder = async (orderData: {
    //     member_ObjectId: string;
    //     billing_name: string;
    //     billing_address: string;
    //     country: string;
    //     state: string;
    //     city: string;
    //     orders: Array<{
    //         dog_ObjectId: string;
    //         unit_qty: number;
    //         unit_price: number;
    //         total_unit_price: number;
    //     }>;
    //     total_price: number;
    //     tax: number;
    //     platformCharges: number;
    //     paybleAmount: number;
    // }) => {
    //     try {
    //         const memberObjectId = localStorage.getItem('member_ObjectId');
    //         const orders = cartItems.map(item => ({
    //             dog_ObjectId: item.dog_ObjectId,
    //             unit_qty: item.unit_qty,
    //             unit_price: item.unit_price,
    //             total_unit_price: item.unit_qty * item.unit_price // Calculate total price for each item
    //         }));

    //         const total_price = cartItems.reduce((total, item) => total + (item.unit_price * item.unit_qty), 0);
    //         const tax = 5.00; // Assuming tax is fixed for now
    //         const platformCharges = 10.00; // Assuming platform charges are fixed for now
    //         const paybleAmount = total_price + tax + platformCharges;

    //         const response = await fetch(`${process.env.REACT_APP_API_URL}order/purches-dogs`, {
    //             method: 'POST',
    //             headers: {
    //                 'Content-Type': 'application/json',
    //                 'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
    //             },
    //             body: JSON.stringify({
    //                 member_ObjectId: memberObjectId,
    //                 orders,
    //                 total_price,
    //                 tax,
    //                 platformCharges,
    //                 paybleAmount,
    //                 billing_name: orderData.billing_name,
    //                 billing_address: orderData.billing_address,
    //                 country: orderData.country,
    //                 state: orderData.state,
    //                 city: orderData.city,
    //             }),
    //         });

    //         if (!response.ok) {
    //             throw new Error('Failed to place order');
    //         }

    //         const data = await response.json();
    //         return data; // Return the response data if needed
    //     } catch (error) {
    //         console.error('Error placing order:', error);
    //     }
    // };




    interface PlaceOrderPayload {
        member_ObjectId: string;
        billing_name: string;
        billing_address: string;
        country: string;
        state: string;
        city: string;
        orders: Array<{
            dog_ObjectId: string;
            unit_qty: number;
            unit_price: number;
            total_unit_price: number;
        }>;
        total_price: number;
        tax: number;
        platformCharges: number;
        paybleAmount: number;
    }

    const placeOrder = async (orderData: PlaceOrderPayload) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}order/purches-dogs`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify(orderData),
            });

            if (!response.ok) {
                // Try to get detailed error message for debugging
                const errorBody = await response.text();
                throw new Error(`Failed to place order. Status: ${response.status}, Response: ${errorBody}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error placing order:', error);
            throw error;
        }
    };

    const addToCart = async (memberId: string, dogId: string, quantity: number, unitPrice: number): Promise<boolean> => {
        try {
            const memberObjectId = localStorage.getItem('member_ObjectId');

            const response = await fetch(`${process.env.REACT_APP_API_URL}add-to-cart/add-dogs`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify({
                    member_ObjectId: localStorage.getItem('member_id'),
                    dog_ObjectId: dogId,
                    unit_qty: quantity,
                    unit_price: unitPrice,
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to add to cart');
            }

            const data = await response.json();
            // Update cart items with the new item
            setCartItems((prevItems) => {
                const existingItemIndex = prevItems.findIndex(item => item.dogId === dogId);
                if (existingItemIndex > -1) {
                    const updatedItems = [...prevItems];
                    updatedItems[existingItemIndex].quantity += quantity;
                    return updatedItems;
                } else {
                    return [...prevItems, { dogId, quantity, unitPrice }];
                }
            });

            return true; // Indicate success
        } catch (error) {
            console.error('Error adding to cart:', error);
            return false; // Indicate failure
        }
    };

    const fetchCartItems = useCallback(async (): Promise<any[]> => { // Specify the return type
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}add-to-cart/cart-list/${localStorage.getItem('member_id')}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch cart items');
            }

            const data = await response.json();
            return data.result || []; // Return the result or an empty array if undefined
        } catch (error) {
            console.error("Error fetching cart items:", error);
            return []; // Return an empty array in case of error
        }
    }, []);

    const deleteCartItem = async (cartId: string) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}add-to-cart/delete-item`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify({ cart_id: cartId }), // Send the payload
            });

            if (!response.ok) {
                throw new Error('Failed to delete cart item');
            }

            // Fetch the updated cart items after successful deletion
            const updatedCartItems = await fetchCartItems();
            setCartItems(updatedCartItems); // Update the context state with the new cart items
        } catch (error) {
            console.error('Error deleting cart item:', error);
        }
    };

    const updateCartItem = async (cartId: string, quantity: number): Promise<void> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}add-to-cart/update-cart-item/${cartId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
                body: JSON.stringify({ unit_qty: quantity }),
            });

            if (!response.ok) {
                throw new Error('Failed to update cart item');
            }

            const updatedCartItems = await fetchCartItems();
            setCartItems(updatedCartItems);
        } catch (error) {
            console.error('Error updating cart item:', error);
        }
    };


    interface Race {
        raceId: string;
        raceDate: string;
        position: number;
        details: string;
    }

    const raceHistory = useCallback(async (id: string): Promise<{ results: Race[] } | null> => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}race-result/dog-history/${id}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('@jwt')}`,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch race history');
            }

            const data = await response.json();
            return data || null; // Now returning entire API response
        } catch (error) {
            console.error('Error fetching dog by ID:', error);
            return null;
        }
    }, []);



    return (
        <DogContext.Provider value={{ dogs, placeOrder, fetchDogs, addDog, adminDogList, profileDogList, updateDog, changeDogStatus, deleteDog, fetchDogById, cartItems, setCartItems, addToCart, fetchCartItems, deleteCartItem, updateCartItem, raceHistory }}>
            {children}
        </DogContext.Provider>
    );
};

export const useDog = (): DogContextType => {
    const context = React.useContext(DogContext);
    if (context === undefined) {
        throw new Error('useDog must be used within a DogProvider');
    }
    return context;
};