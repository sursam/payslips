import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './styles/app.css';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Login from './components/Auth/login';
import ForgetPassword from './components/Auth/forget_password';
import Registration from './components/Auth/registration';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Dashboard from './components/Dashboard/dashboard';
import JobList from './components/Job/jobList';
import JobPost from './components/Job/jobPost';
import Profile from './components/Profile/profile';
import UpdateProfile from './components/Profile/updateProfile';
import Notification from './components/Announcement/Notification';
import PrivateRoute from './utils/PrivateRoute'; // Adjust the import path as necessary
import PublicRoute from './utils/PublicRoute'; // Adjust the import path as necessary

const theme = createTheme({
  typography: {
    fontFamily: ['Poppins', 'sans-serif'].join(','),
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          fontSize: '.9rem',
          fontWeight: 500,
          padding: '7px 20px',
          margin: '10px 0',
          backgroundColor: '#ffffff',
          textTransform: 'capitalize',
          borderRadius: '25px',
          textDecoration: 'none',
          color: '#000000',
          '&:hover': {
            backgroundColor: '#d3d3d3',
          },
        },
        contained: {
          backgroundColor: '#87903D',
          color: '#fff',
          '&:hover': {
            backgroundColor: '#303f9f',
          },
        },
        outlined: {
          borderColor: '#3f51b5',
          color: '#3f51b5',
          '&:hover': {
            borderColor: '#303f9f',
            color: '#303f9f',
          },
        },
      },
    },
    MuiFormControl: {
      styleOverrides: {
        root: {
          '& .MuiInputBase-root': {
            border: 0,
            borderRadius: '8px',
            padding: '10px 14px',
            '&:hover': {
              border: 0,
            },
            '&.Mui-focused': {
              border: 0,
              outline: 'none',
            },
          },
          '& .MuiInputLabel-root': {
            color: '#84818A'
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        input: {
          padding: '4px 0 5px',
          border: 0
        },
      },
    },
  },
});

// const stripePromise = loadStripe('pk_test_6pRNASCoBOKtIshFeQd4XMUh');
// const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

const App: React.FC = () => {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <ToastContainer />
        {/* <Elements stripe={stripePromise}> */}

        <Routes>
          {/* Public Routes */}
          <Route element={<PublicRoute />}>
            <Route path='/' element={<Login />} />
            <Route path='/forgot-password' element={<ForgetPassword />} />
            <Route path='/sign-up' element={<Registration />} />
          </Route>


          {/* Private Routes */}
          <Route element={<PrivateRoute />}>
            <Route path='/dashboard' element={<Dashboard />} />
            <Route path='/profile' element={<Profile />} />
            <Route path='/notification' element={<Notification />} />
            <Route path='/profile/edit' element={<UpdateProfile />} />
            <Route path='/job-list' element={<JobList />} />
            <Route path='/post-job' element={<JobPost />} />
          </Route>

        </Routes>
        {/* </Elements> */}
      </Router>
    </ThemeProvider>
  );
}

export default App;
