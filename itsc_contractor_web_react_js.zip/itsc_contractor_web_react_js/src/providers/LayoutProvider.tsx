import React, { useState, useEffect } from "react";
import {
  Box, Typography
} from '@mui/material';
import Header from '../components/Header/header';
import Sidebar from '../components/Sidebar/sidebar';

import styles from '../styles/header.module.css';
import { CalendarMonthOutlined } from '@mui/icons-material';

interface LayoutProps {
  children: any;
  pageTitle?: string;
}
const LayoutProvider: React.FC<LayoutProps> = ({ children, pageTitle }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };
  useEffect(() => {
    // Update the time every second
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);

    // Clean up the interval when the component unmounts
    return () => clearInterval(timer);
  }, []);
  return (
    <Box className={styles.container}>
      <Sidebar isOpen={isSidebarOpen} />
      <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', transition: 'margin-left 0.3s' }}>
        <div className={styles.pageHeader}>
          <div className={styles.pageHeaderTitle}>
            <h5>{pageTitle}</h5>
          </div>
          <div className={styles.pageHeaderTime}>
            <CalendarMonthOutlined style={{ width: '17px', height: '17px', color: '#005DAB', marginRight: '5px', verticalAlign: 'middle' }} />
            <label style={{ verticalAlign: 'middle' }}>
              {currentDateTime.toLocaleString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false }).replace('at', '|')}
            </label>

          </div>
        </div>
        <Box sx={{ padding: '20px' }}>
          {children}
        </Box>
        <Box className={styles.pageFooter}>
          <Typography className={styles.pageFooterText}>Copyright &copy; {currentDateTime.toLocaleString('en-US', { year: 'numeric' })}</Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default LayoutProvider;
