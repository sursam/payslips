import React, { useState, useEffect } from 'react';
import { Box, TextField, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination, Stack, Pagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import styles from '../../styles/raceresult.module.css';
import { api } from '../../utils/api';

const UpcomingRaceList: React.FC = () => {
	const [isSidebarOpen, setSidebarOpen] = useState(true);
	const [searchQuery, setSearchQuery] = useState('');
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [races, setRaces] = useState<any[]>([]); // Update to hold the race data

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	const handlePageChange = (event: unknown, newPage: number) => {
		setPage(newPage - 1); // Convert to 0-based index
	};


	const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		setRowsPerPage(parseInt(event.target.value, 10));
		setPage(0);
	};

	const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
		setSearchQuery(e.target.value.toLowerCase());
	};

	const fetchRaces = async () => {
		try {
			const response = await api.dashboard.getUpcomingRace(); // Fetch upcoming races
			if (response?.result) {
				setRaces(response.result); // Set the race data
			}
		} catch (error) {
			console.error("Error fetching race list:", error);
		}
	};

	useEffect(() => {
		fetchRaces(); // Fetch races on component mount
	}, []);

	const filteredRaces = races.filter((race) => {
		const searchQueryLower = searchQuery.toLowerCase();
		return (
			race.location.toLowerCase().includes(searchQueryLower) ||
			race.country.toLowerCase().includes(searchQueryLower) ||
			race.grade.toLowerCase().includes(searchQueryLower) ||
			new Date(race.race_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }).toLowerCase().includes(searchQueryLower) ||
			race.race_time.toLowerCase().includes(searchQueryLower) ||
			race.race_name.toLowerCase().includes(searchQueryLower) // Include race name in search
		);
	});

	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Upcoming Race List</h3>
					<div className={styles.headerRtSide}>
						<TextField
							variant="outlined"
							placeholder="Search Race"
							size="small"
							sx={{ marginRight: 2 }}
							value={searchQuery}
							onChange={handleSearch} // Add search handler
						/>
					</div>
				</div>

				<div className={styles.customtable}>
					<TableContainer className={styles.tableContainer}>
						<Table className={`${styles.table} table`}>
							<TableHead>
								<TableRow>
									<TableCell className={styles.stickyColumn}>Race Name</TableCell>
									<TableCell className={styles.stickyColumn}>Venue</TableCell>
									<TableCell className={styles.stickyColumn}>Date & Time</TableCell>
									<TableCell className={styles.stickyColumn}>Country</TableCell>
									<TableCell className={styles.stickyColumn}>Grade</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{filteredRaces
									.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
									.map((race) => (
										<TableRow key={race._id}>
											<TableCell>{race.race_name}</TableCell>
											<TableCell>{race.location}</TableCell>
											<TableCell>
												{new Date(race.race_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })} <br />
												{race.race_time}
											</TableCell>
											<TableCell>{race.country}</TableCell>
											<TableCell>{race.grade}</TableCell>
										</TableRow>
									))}
							</TableBody>
						</Table>
					</TableContainer>

					<Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
						<Pagination
							count={Math.ceil(filteredRaces.length / rowsPerPage)} // Calculate total pages
							page={page + 1} // MUI Pagination is 1-based
							onChange={handlePageChange}
							color="primary"
						/>
					</Stack>
				</div>
			</Box>
		</Box>
	);
};

export default UpcomingRaceList;
