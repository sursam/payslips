import { useEffect, useState } from "react";
import { logo } from "../../../../assets";
import { Link, useLocation } from 'react-router-dom';

const Navbar = () => {
	const [isScrolled, setIsScrolled] = useState<boolean>(false);
	const location = useLocation();
	const currentPath = location.pathname;

	const handleScroll = () => {
		if (window.scrollY > 50) {
			setIsScrolled(true);
		} else {
			setIsScrolled(false);
		}
	};

	useEffect(() => {
		window.addEventListener('scroll', handleScroll);
		// Cleanup function to remove the event listener
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	return (
		<>
			{/* <!-- Main Nav Section --> */}
			<div className={`main-nav ${isScrolled ? 'scroll' : ''}`}>
				<div className="container-fluid">
					<div className="row">
						<div className="col-lg-3 col-md-3 col-4">
							<div className="logo animate__animated animate__rotateIn">
								<a className="navbar-brand" href="/">
									<img
										className=""
										src={logo}
										alt=""
										title="Winners Are Grinners"
									/>
								</a>
							</div>
						</div>
						<div className="col-lg-9 col-md-9 col-8">
							<div id="main-nav" className="stellarnav">
								<ul>
									<li>
										<a href="/" className={currentPath === '/' ? 'active' : ''}>
											Home
										</a>
									</li>
									<li>
										<a href="/blog" className={currentPath === '/blog' ? 'active' : ''}>Blogs</a>
									</li>
									<li>
										<a href="/#membership" className={currentPath === '/#membership' ? 'active' : ''}>Membership</a>
									</li>
									<li>
										<a href="/faq" className={currentPath === '/faq' ? 'active' : ''}>FAQ</a>
									</li>
									<li>
										<a href="/about-us" className={currentPath === '/about-us' ? 'active' : ''}>About Us</a>
									</li>
									<li>
										<a href="/contact" className={currentPath === '/contact' ? 'active' : ''}>Contact</a>
									</li>
								</ul>
								<div className="rightlink animate__animated animate__rotateIn">
									<a href="/login" className="brochurebtn">
										Member Login
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			{/* <!-- Mainnav Section End --> */}
		</>
	);
}

export default Navbar;
