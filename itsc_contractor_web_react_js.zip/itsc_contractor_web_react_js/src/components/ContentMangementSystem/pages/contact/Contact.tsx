import React, { useEffect, useState } from 'react';
import { EmailAddress01, innerbanner, Location01, PhoneNo01, up_arrow } from "../../../../assets";
import Footer from "../../shared/footer/Footer";

// CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../../ContentMangementSystem/globalStyles/stellarnav.css";
import "../../../ContentMangementSystem/globalStyles/animate.css";
import "../../../ContentMangementSystem/globalStyles/style.css";
import "../../../ContentMangementSystem/globalStyles/responsive.css";

import { Button } from 'react-bootstrap';

import { toast, ToastContainer } from 'react-toastify'; // Import toast and ToastContainer
import 'react-toastify/dist/ReactToastify.css';
import Navbar from '../../shared/navbar/Navbar';
import axios from 'axios';
import { Message } from '@mui/icons-material';

interface FormData {
	name: string;
	email: string;
	phone: string;
	description: string;
}
const Contact = () => {
	const [isVisible, setIsVisible] = useState(false);
	const [formData, setFormData] = useState<FormData>({
		name: '',
		email: '',
		phone: '',
		description: '',
	});

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
		const { name, value } = e.target;
		setFormData({ ...formData, [name]: value });
	};

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();
		const data = { ...formData };
		try {
			const response = await axios.post(
				`${process.env.REACT_APP_API_URL}marketing-page/add-contact-us`,
				data,
				{
					headers: { "Content-Type": "application/json" },
				}
			);
			if (response) {
				// toast.success("We have successfully added your query!");
				alert("We have successfully added your query!")
			} else {
				toast.error("Please try again later!");
			}
		} catch (error) {
			toast.error("Something went wrong!");
		}
	};

	return (
		<>
			<div className="flex flex-col gap-4">
				<Navbar />

				{/* <!-- Inner Banner Section --> */}
				<section className="breadcumb">
					<div className="swiper-slide breadcumb">
						<img src={innerbanner} alt="" className="img-fluid" />
						<div id="overlay"></div>
						<div className="hero-content">
							<div className="hero-content-upper">
								<div className="container">
									<h2 className="wow animate fadeInUp">CONTACT US</h2>
								</div>
							</div>
						</div>
					</div>
				</section>
				{/* <!-- Inner Banner Section End --> */}

				{/* <!-- Send Message Section --> */}
				<div className="sendmessage-section wow animate fadeInUp">
					<div className="container-fluid">
						<h2>Any question? Send us message.</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>

						<form onSubmit={handleSubmit} className="quoteform">
							<div className="row">
								<div className="col-lg-12 col-md-12 col-12">
									<label>Name*</label>
									<input type="text" className="form-control" name='name' placeholder="Enter Your Name" onChange={handleChange} required />
								</div>

								<div className="col-lg-6 col-md-6 col-12">
									<label>Email*</label>
									<input type="email" className="form-control" name='email' placeholder="Enter your email" onChange={handleChange} required />
								</div>

								<div className="col-lg-6 col-md-6 col-12">
									<label>Phone*</label>
									<input type="tel" className="form-control" name='phone' placeholder="Enter Your Phone No" onChange={handleChange} required />
								</div>

								<div className="col-lg-12 col-md-12 col-12">
									<label>Your Message*</label>
									<textarea className="form-control" name='description' placeholder="Enter Your Message" onChange={handleChange} required></textarea>
								</div>
							</div>

							<div className="row">
								<div className="col-lg-12 col-md-12 col-12 d-flex justify-content-center mt-3">
									<button type="submit" className="submitbtn">Submit Query</button>
								</div>
							</div>
						</form>

						{/* Contact details section */}
						<div className="contactus-left">
							<div className="addresscard">
								<div className="addresscard-icon"><img className="" src={Location01} alt="" title="" /></div>
								<div className="addresscard-text">
									<h5>Our Address</h5>
									<p>Villa 6 34 Kowara Crs Merimbula NSW 2548 Australia</p>
								</div>
							</div>

							<div className="addresscard">
								<div className="addresscard-icon"><img className="" src={PhoneNo01} alt="" title="" /></div>
								<div className="addresscard-text">
									<h5>Live support</h5>
									<p>Open a chat or give us call at <a href="tel:+61416330019">+61 416330019</a></p>
								</div>
							</div>

							<div className="addresscard">
								<div className="addresscard-icon"><img className="" src={EmailAddress01} alt="" title="" /></div>
								<div className="addresscard-text">
									<h5>live chat service </h5>
									<p><a href="mailto:admin@wagbet.com">admin@wagbet.com</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				{/* <!-- Send Message Section End --> */}
				<Footer />
				<div className={`go-top ${isVisible ? 'active' : ''}`} onClick={scrollToTop}>
					<img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" />
				</div>
			</div>
		</>
	);
}

export default Contact;
