import React, { useEffect, useState } from 'react';
import { innerbanner, up_arrow } from "../../../../assets";
import Footer from "../../shared/footer/Footer";
import Navbar from '../../shared/navbar/Navbar';

// CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../../ContentMangementSystem/globalStyles/stellarnav.css";
import "../../../ContentMangementSystem/globalStyles/animate.css";
import "../../../ContentMangementSystem/globalStyles/style.css";
import "../../../ContentMangementSystem/globalStyles/responsive.css";


import FaqList from './FaqList';

const Faq = () => {
	const [isVisible, setIsVisible] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrolled = window.scrollY;
			setIsVisible(scrolled > 600);
		};

		window.addEventListener('scroll', handleScroll);

		// Cleanup event listener on unmount
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	}, []);

	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};

	return (
		<>
			<div className="flex flex-col gap-4">
				<Navbar />

				{/* Inner Banner Section */}
				<section className="breadcumb">
					<div className="swiper-slide breadcumb">
						<img src={innerbanner} alt="" className="img-fluid" />
						<div id="overlay"></div>
						<div className="hero-content">
							<div className="hero-content-upper">
								<div className="container">
									<h2 className="wow animate fadeInUp">Frequently Asked Questions</h2>
								</div>
							</div>
						</div>
					</div>
				</section>
				{/* Inner Banner Section End */}

				{/* Faq Section */}
				<FaqList />
				{/* Faq Section End */}

				<Footer />
				<div className={`go-top ${isVisible ? 'active' : ''}`} onClick={scrollToTop}>
					<img src={up_arrow} width="50%" style={{ marginTop: '-9px' }} alt="Scroll to top" />
				</div>
			</div>
		</>
	);
}

export default Faq;
