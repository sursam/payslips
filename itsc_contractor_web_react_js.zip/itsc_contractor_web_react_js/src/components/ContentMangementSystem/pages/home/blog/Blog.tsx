import Slider from "react-slick";
// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import { blogsimg01 } from "../../../../../assets";

const Blog = () => {
	const settings = {
		dots: true,
		infinite: true,
		speed: 500,
		autoplay: true,
		autoplaySpeed: 2000,
		slidesToShow: 2,
		slidesToScroll: 1,
		responsive: [
			{
				breakpoint: 600,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				},
			},
			{
				breakpoint: 1000,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
				},
			},
		],
	};

	const blogPosts = [
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
		// Add more blog post objects here if necessary
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
		{
			date: "12 Jan 2025",
			imgSrc: blogsimg01,
			description: "Winners Are Grinners® has been crafted by experts deeply immersed in the wo...",
		},
	];
	return (
		<div className="owl-carousel ourblogs-carousel">
			<Slider {...settings}>
				{blogPosts.map((post, index) => (
					<div className="item" key={index}>
						<div className="blogscard">
							<div className="blogsimg">
								<img src={post.imgSrc} alt="" />
							</div>
							<h5>POSTED DATE <a href="/blog-details">{post.date}</a></h5>
							<p>{post.description}</p>
							<a href="/blog-details" className="readlink">Read More</a>
						</div>
					</div>
				))
				}
			</Slider >
		</div >
	);

}

export default Blog