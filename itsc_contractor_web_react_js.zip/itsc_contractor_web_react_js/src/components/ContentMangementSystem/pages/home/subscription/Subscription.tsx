import { leftarrow02 } from "../../../../../assets";

const Subscription = () => {
	return (
		<div className="pacingcard-sect">
			<div className="leftarrow03">
				<img src={leftarrow02} className="" alt="" />
			</div>
			<div className="pacinghead">
				<h2>$999</h2>
				<a href="/login" className="buynow-btn">
					Buy Now
				</a>
			</div>
			<ul>
				<li>Receive 3 Greyhound selections every Wednesday and Saturday.</li>
				<li>All major events on the calendar Plus the Black Book.</li>
				<li>Full access to the greyhound racing portal.</li>
				<li>
					Saturday Night audio from Punters HQ Joe Lannutti (She's A Pearl).
				</li>
				<li>
					1% share in prizemoney from your selected greyhound (coming soon)
				</li>
			</ul>
		</div>
	);

}

export default Subscription