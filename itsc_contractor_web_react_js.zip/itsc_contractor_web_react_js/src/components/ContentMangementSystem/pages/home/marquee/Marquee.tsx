import React, { useEffect, useRef, useState } from 'react';
import { leftarrow01 } from '../../../../../assets';

const Marquee = () => {
	const [mouseEntered, setMouseEntered] = useState(false);
	const containerRef = useRef(null);
	const speed = 4;

	useEffect(() => {
		const container: any = containerRef.current;

		if (!container) return;

		let progress = 0;
		const loop = () => {
			if (!mouseEntered) {
				progress -= speed;
				if (progress <= -container.scrollWidth) {
					progress = container.clientWidth; // Reset to start
				}
			}
			container.style.transform = `translateX(${progress}px)`;
			window.requestAnimationFrame(loop);
		};

		loop();

		// Cleanup function to stop the animation if needed
		return () => {
			container.style.transform = "translateX(0)";
		};
	}, [mouseEntered]);

	return (
		<div className="marqueecard">
			<div className="leftarrow02">
				<img src={leftarrow01} className="" alt="" />
			</div>
			<div className="marquee">
				<div
					className="marquee"
					onMouseEnter={() => setMouseEntered(true)}
					onMouseLeave={() => setMouseEntered(false)}
					ref={containerRef}
					style={{ whiteSpace: "nowrap", overflow: "hidden" }}
				>
					<div className="inner" style={{ display: "inline-block" }}>
						<p>
							<a href="#">
								Experienced in greyhound racing, with deep industry insight
							</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Marquee;
