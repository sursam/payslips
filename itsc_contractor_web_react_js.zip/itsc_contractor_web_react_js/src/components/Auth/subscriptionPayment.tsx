import { useEffect, useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import {
  PaymentElement,
  Elements,
  useStripe,
  useElements
} from '@stripe/react-stripe-js';
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { CheckoutFormProps, VerifyPaymentType } from '../../types';
import { StripePaymentElementChangeEvent } from "@stripe/stripe-js";
import { Box, Typography, Card } from '@mui/material';
import { subscriptionPaymentReceived } from '../../context/subscriptionContext';
import styles from '../../styles/wallet.module.css';
import { api } from '../../utils/api';
// import { STRIPE_PUBLISHABLE_KEY } from '../../config/config';
export const LOCAL_STRIPE_PUBLISHABLE_KEY = "pk_test_51NdpkRBuHqQNZg72XOlkNZRZZO9aXVTnGAyzbNP8QXJkZwW5gVY9r3PxjNQ6e9Yz5htDWyIKuMRaAHmS5EZfk4Oz00sCUF6Kvr"

const SubscriptionPayment = () => {
  const location = useLocation();
  const { state } = location;
  console.log({ state })

  const [stripePromise, setStripePromise] = useState<any>(null);

  useEffect(() => {
    const loadStripeInstance = async () => {
      const stripe = await loadStripe(LOCAL_STRIPE_PUBLISHABLE_KEY);
      setStripePromise(stripe);
    };
    loadStripeInstance();
  }, []);

  const options = {
    clientSecret: state?.response?.payment_data?.client_secret || ""
  }

  return (
    <div>
      {state?.response?.payment_data?.client_secret && stripePromise && (
        <Elements options={options} stripe={stripePromise}>
          <CheckoutForm id={state?.response?.id as string} stripeData={state?.response} />
        </Elements>
      )}
    </div>
  )
}

export default SubscriptionPayment

const CheckoutForm: React.FC<CheckoutFormProps> = ({ id, stripeData }) => {

  const stripe = useStripe();
  const elements = useElements();
  const navigate = useNavigate();

  const [isPaymentComplete, setIsPaymentComplete] = useState(false);
  const [errorMessage, setErrorMessage] = useState<any | null>(null);

  const handlePaymentElementChange = (event: StripePaymentElementChangeEvent) => {
    setIsPaymentComplete(event.complete)
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      console.error('Stripe.js has not yet loaded.');
      return;
    }

    try {
      const result = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // return_url: `${process.env.REACT_APP_API_URL}confirm`,
        },
        redirect: 'if_required',
      });

      if (result?.error) {
        setErrorMessage(result?.error?.message);
        console.error("Payment error:", result.error);
      } else {
        console.log('Payment succeeded:', result);
        await handlePostPayment(result);
      }
    } catch (error) {
      console.error("Error confirming payment:", error);
    }
  };
  const handlePostPayment = async (result: any) => {
    try {
      let verifyPayload: VerifyPaymentType = {
        "status": "SUCCESS",
        "member_id": stripeData?.member_objectId,
        "paymentIntent_id": stripeData?.payment_intent_id,
        "payment_respons": {
          "id": stripeData?.payment_intent_id,
          "object": stripeData?.payment_intent_id,
          "amount": stripeData?.payment_data?.amount,
          "amount_capturable": stripeData?.payment_data?.amount_capturable,
          "amount_received": stripeData?.payment_data?.amount_received,
          "application": stripeData?.payment_data?.application
        }
      }
      const response = await api.settings.subscriptionPaymentReceived(verifyPayload, id)
      // const response = await subscriptionPaymentReceived(verifyPayload, id)
      if (response) {
        return (
          navigate('/subscription-confirm')
        )
      }
    } catch (error) {
      console.log(error)
    }
  };
  return (
    <form onSubmit={handleSubmit}>
      <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-around' }}>
        <Box sx={{ width: '50%', margin: '10px 50px', backgroundColor: '#f5f5f5' }}>
          <PaymentElement onChange={handlePaymentElementChange} />
        </Box>
        <Box>
          <Card sx={{ flex: 1, borderRadius: 5, p: 2, m: '20px', width: '300px' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: '20px' }}>
              <Typography variant="body2" color="textSecondary">Subtotal(1 item)</Typography>
              <Typography variant="body2" color="textSecondary">$999</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="body2" color="textSecondary">Shipping</Typography>
              <Typography variant="body2" color="textSecondary">Free</Typography>
            </Box>
            <hr />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="body2" color="textSecondary">Total</Typography>
              <Typography variant="body2" color="textSecondary">$999.00</Typography>
            </Box>
            <button
              type="submit"
              disabled={!stripe || !isPaymentComplete}
              className={styles.pay_btn}
            >
              Place Order
            </button>
          </Card>
        </Box>
      </Box>
      {errorMessage && <div style={{ color: 'red', marginTop: '10px' }}>{errorMessage}</div>}
    </form>
  )
}
