import { use, useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { TextField, Box } from '@mui/material';
import styles from '../../../styles/registration.module.css';
import PhoneInput from 'react-phone-input-2';

interface ChildProps {
    errors: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onCompanyMobileChange: (value: any, data: any, event: React.ChangeEvent<HTMLInputElement>, formattedValue: any) => void;
    register: any;
    companyName: string;
    companyDba: string;
    taxId: string;
    companyPhone: string;

}
const CompanyInformation: React.FC<ChildProps> = ({ errors, register, handleChange, onCompanyMobileChange, companyName, companyDba, taxId, companyPhone }) => {

    return (
        <Box className={styles.formContainer}>
            {/* company name */}
            <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                <Box sx={{ flex: 1 }}>
                    <TextField
                        label="Company Name"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.companyName}
                        helperText={!!errors?.companyName}
                        className={`${styles.formControl} ${errors?.companyName ? 'is-invalid' : ''}`}
                        {...register('companyName', { onChange: handleChange })}
                        value={companyName}
                        inputProps={{ autoComplete: "companyName" }}
                    />
                    <div className="invalid-feedback">{errors.companyName?.message?.toString()}</div>
                </Box>
                <Box sx={{ flex: 1 }}>
                    <TextField
                        label="Company DBA"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.companyDba}
                        helperText={!!errors?.companyDba}
                        className={`${styles.formControl} ${errors?.companyDba ? 'is-invalid' : ''}`}
                        {...register('companyDba', { onChange: handleChange })}
                        value={companyDba}
                        inputProps={{ autoComplete: "companyDba" }}
                    />
                    <div className="invalid-feedback">{errors.companyDba?.message?.toString()}</div>
                </Box>
            </Box>
            <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                <Box sx={{ flex: 1 }}>
                    <TextField
                        label="Company EIN / TAX ID"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        error={!!errors?.taxId}
                        helperText={!!errors?.taxId}
                        className={`${styles.formControl} ${errors?.taxId ? 'is-invalid' : ''}`}
                        {...register('taxId', { onChange: handleChange })}
                        value={taxId}
                        inputProps={{ autoComplete: "companyEinTaxId" }}
                    />
                    <div className="invalid-feedback">{errors.taxId?.message?.toString()}</div>
                </Box>
                <Box sx={{ flex: 1 }}>
                    <PhoneInput
                        country={'us'}
                        value={companyPhone}
                        onChange={onCompanyMobileChange}
                        containerStyle={{ marginTop: '16px', marginBottom: '8px' }}
                        inputProps={{
                            name: 'phone2',
                            autoFocus: true,
                        }}
                        inputStyle={{
                            borderColor: errors?.companyPhone ? '#d32f2f' : '#ccc',
                        }}
                    />
                    <div className="invalid-feedback" >{errors.companyPhone?.message?.toString()}</div>
                </Box>
            </Box>
        </Box>

    );
};

export default CompanyInformation;
