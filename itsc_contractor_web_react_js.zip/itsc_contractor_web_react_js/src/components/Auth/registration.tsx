import React, { useEffect, useState } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { Button, Typography, Box, Grid2, Stepper, Step, StepLabel } from '@mui/material';
import styles from '../../styles/registration.module.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { api } from '../../utils/api'
import { styled } from '@mui/material/styles';
import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';
import { StepIconProps } from '@mui/material/StepIcon';
import Check from '@mui/icons-material/Check';

import PersonalDetails from './Forms/personalDetails';
import ContactInformation from './Forms/contactInformation';
import CreatePassword from './Forms/createPassword';
import CompanyInformation from './Forms/companyInformation';
import MakePayment from './Forms/makePayment';

import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import 'react-phone-input-2/lib/style.css';

interface RegistrationForm {
    firstName: string;
    lastName: string;
    dob: string;
    userState: string;
    stateName: string;
    city: string;
    cityName: string;
    zipCode: string;
    streetAddress: string;
    email: string;
    mobileNumber: string;
    countryCode: string;
    mobile: string;
    password: string;
    confirmPassword: string;
    acceptedTerms: string;
    acceptedPolicy: string;
    acceptedOthers: string;
    companyName: string;
    companyDba: string;
    taxId: string;
    companyPhone: string;
    country: string,
    imageUrl: string;
    profileImage: File | null;
    paymentTerms: number
}

const steps = ['Your Personal Details', 'Contact Information', 'Create Password', 'Your Company Information', 'Make Your Payment'];
const FormConnector = styled(StepConnector)(({ theme }) => ({
    [`&.${stepConnectorClasses.alternativeLabel}`]: {
        top: 10,
        left: 'calc(-50% + 16px)',
        right: 'calc(50% + 16px)',
    },
    [`&.${stepConnectorClasses.active}`]: {
        [`& .${stepConnectorClasses.line}`]: {
            borderColor: '#f9f9f9',
        },
    },
    [`&.${stepConnectorClasses.completed}`]: {
        [`& .${stepConnectorClasses.line}`]: {
            borderColor: '#f9f9f9',
        },
    },
    [`& .${stepConnectorClasses.line}`]: {
        borderColor: '#f9f9f9',
        borderTopWidth: 3,
        borderRadius: 1,
        ...theme.applyStyles('dark', {
            borderColor: theme.palette.grey[800],
        }),
    },
}));
const FormStepIconRoot = styled('div')<{ ownerState: { active?: boolean } }>(
    ({ theme }) => ({
        color: '#c3c3c3',
        display: 'flex',
        height: 22,
        alignItems: 'center',
        '& .FormStepIcon-completedIcon': {
            width: 30,
            height: 3,
            backgroundColor: '#007A2F',
        },
        '& .FormStepIcon-current': {
            width: 30,
            height: 3,
            backgroundColor: 'currentColor',
        },
        ...theme.applyStyles('dark', {
            color: theme.palette.grey[700],
        }),
        variants: [
            {
                props: ({ ownerState }) => ownerState.active,
                style: {
                    color: '#784af4',
                },
            },
        ],
    }),
);

function FormStepIcon(props: StepIconProps) {
    const { active, completed, className } = props;
    return (
        <FormStepIconRoot ownerState={{ active }} className={className}>
            {completed ? (
                <Check className="FormStepIcon-completedIcon" />
            ) : (
                <div className="FormStepIcon-current" />
            )}
        </FormStepIconRoot>
    );
}

const Registration = () => {
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [activeStep, setActiveStep] = React.useState(0);
    const [states, setStates] = useState({});
    const [cities, setCities] = useState({});
    const [isDragging, setIsDragging] = useState<boolean>(false);
    const searchParams = useSearchParams()[0];
    const stepParam = searchParams.get('step');

    useEffect(() => {
        if (stepParam !== null) {
            const stepFromQuery = parseInt(stepParam, 10);
            if (!isNaN(stepFromQuery)) {
                setActiveStep(stepFromQuery + 1);
            }
        }
    }, [stepParam]);
    var [state, setState] = useState<RegistrationForm>({
        firstName: '',
        lastName: '',
        dob: '',
        userState: '',
        stateName: '',
        city: '',
        cityName: '',
        zipCode: '',
        streetAddress: '',
        email: '',
        mobileNumber: '',
        countryCode: '',
        mobile: '',
        password: '',
        confirmPassword: '',
        acceptedTerms: '',
        acceptedPolicy: '',
        acceptedOthers: '',
        companyName: '',
        companyDba: '',
        taxId: '',
        companyPhone: '',
        country: '',
        imageUrl: '',
        profileImage: null,
        paymentTerms: 0
    });
    var { firstName, lastName, dob, userState, stateName, city, cityName, zipCode, streetAddress, mobileNumber, countryCode, mobile, email, password, confirmPassword, acceptedTerms, acceptedPolicy, acceptedOthers, companyName, companyDba, taxId, companyPhone, imageUrl, paymentTerms } = state;

    var validationObject: any;
    if (activeStep === 0) {
        validationObject = {
            firstName: Yup.string().required('First name is required'),
            lastName: Yup.string().required('Last name is required'),
            dob: Yup.string().required('Date of birth is required'),
            zipCode: Yup.string().required('zip code is required'),
        };
    }
    if (activeStep === 1) {
        validationObject = {
            email: Yup.string()
                .required('Email is required')
                .email('Invalid email format'),
            countryCode: Yup.string().required('Country code is required'),
            mobile: Yup.string().required('Mobile number is required'),
        };
    }
    if (activeStep === 2) {
        validationObject = {
            password: Yup.string()
                .required('Password is required')
                .min(8, 'Password must be at least 8 characters')
                .matches(
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/,
                    'Password must include at least one uppercase letter, one lowercase letter, one number, and one special character'
                ),
            confirmPassword: Yup.string()
                .required('Confirm password is required')
                .oneOf([Yup.ref('password')], 'Passwords must match'),
            acceptedTerms: Yup.string()
                .oneOf(['on'], 'Terms and conditions must be accepted'),
            acceptedPolicy: Yup.string()
                .oneOf(['on'], 'Privacy policy must be accepted'),
            acceptedOthers: Yup.string()
                .oneOf(['on'], 'Others must be accepted')
        };
    }
    if (activeStep === 3) {
        validationObject = {
            companyName: Yup.string().required('Company name is required'),
            // companyDba: Yup.string().required('Company DBA is required'),
            taxId: Yup.string().required('Tax ID is required'),
            companyPhone: Yup.string().required('Company phone is required'),
        };
    }
    if (activeStep === 4) {
        validationObject = {
            paymentTerms: Yup.number().required('Payment terms is required'),
        };
    }


    const validationSchema = Yup.object().shape(validationObject);
    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }
    const onSubmit = async (data: any) => {
        setIsLoading(true);
        switch (activeStep) {
            case 0:
                setActiveStep((prevActiveStep) => prevActiveStep + 1);
                setIsLoading(false);
                break;
            case 1:
                const formData = state;
                const payloadForChecking = {
                    email: formData.email,
                    mobile: formData.mobile,
                    country: formData.countryCode,
                    role: 'contractor'
                }

                const isExist = await api.auth.checkEmailOrPhoneExists(payloadForChecking)
                console.log("responseMember", isExist);

                if (isExist?.status === true) {
                    setActiveStep((prevActiveStep) => prevActiveStep + 1);
                    setIsLoading(false);
                }
                else {
                    toast.error(isExist?.message);
                    setIsLoading(false);
                }
                break;
            case 2:
                // let formData = new FormData();
                let formPayload = new FormData();
                formPayload.append('first_name', data.firstName);
                formPayload.append('last_name', data.lastName);
                formPayload.append('email', data.email);
                formPayload.append('country_code', data.countryCode);
                formPayload.append('mobile', data.mobile);
                formPayload.append('password', data.password);
                formPayload.append('registration_source', '1');
                formPayload.append('latitude', '22.87897398');
                formPayload.append('longitude', '78.978976');
                formPayload.append('dob', data.dob);
                formPayload.append('state_id', data.userState);
                formPayload.append('city_id', data.city);
                formPayload.append('address', data.streetAddress);
                formPayload.append('pin_code', data.zipCode);
                formPayload.append('role', 'contractor');
                formPayload.append('device_token', '12345');
                formPayload.append('fcm_token', '12345');
                formPayload.append('device_type', '1');
                if (data.profileImage) {
                    formPayload.append('image', data.profileImage);
                }
                formPayload.forEach((value, key) => {
                    console.log(key, value);
                })
                const responseMember = await api.auth.registerUser(formPayload)

                if (responseMember?.status) {
                    toast.success(responseMember?.message);
                    setActiveStep((prevActiveStep) => prevActiveStep + 1);
                    setIsLoading(false);
                }
                else {
                    // console.error('Registration failed:');
                    toast.error(responseMember?.message);
                    setIsLoading(false);
                }
                break;
            case 3:
                const companyPayload = {
                    company_legal_name: data.companyName,
                    company_dba: data.companyDba,
                    country: data.country,
                    phone_2: data.phone2,
                    tax_id: data.taxId,
                };
                const response = await api.auth.addCompanyDetails(companyPayload)
                console.log("responseMember", response);

                if (response) {
                    toast.success('Company Details Updated');
                    setActiveStep((prevActiveStep) => prevActiveStep + 1);
                    setIsLoading(false);
                }
                else {
                    // console.error('Registration failed:');
                    toast.error('Failed to add company Details. Please try again.');
                    setIsLoading(false);
                }
                break;
            case 4:
                console.log("data payment terms", data.paymentTerms);

                const updatePaymentTermsPayload = {
                    pay_in: data.paymentTerms
                };
                const isPaymentTermsUpdated = await api.auth.updatePaymentTerms(updatePaymentTermsPayload)
                console.log("responseMember", isPaymentTermsUpdated);

                if (isPaymentTermsUpdated) {
                    toast.success('SuccessFully Registered');
                    navigate('/dashboard');
                }
                else {
                    toast.error('Payment terms updation failed');
                    setIsLoading(false);
                }
                break;
        }

    };
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        // console.log(name, value)
        setState(prevState => ({
            ...prevState,
            [name]: value,
        }));
        // trigger(name);
    };
    const handleStateChange = async (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        if (value?.id) {
            setState(prevState => ({
                ...prevState,
                userState: value?.id ?? '',
                city: '',
                cityName: '',
            }));
            const payload = {
                state_id: value.id
            };
            const response = await api.auth.citiesByStateId(payload);
            let citiesData = (response?.data?.length) ? response.data : [];
            setCities(citiesData);
        }
    };
    const handleStateInputChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            stateName: value ?? '',
        }));
    };
    const handleCityChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            city: value?.id ?? '',
        }));
    };
    const handleCityInputChange = (event: React.ChangeEvent<HTMLInputElement>, value: any) => {
        setState(prevState => ({
            ...prevState,
            cityName: value ?? '',
        }));
    };
    const onMobileChange = (value: any, data: any, event: any, formattedValue: any) => {
        // console.log(data.dialCode, value.slice(data.dialCode.length));
        setState(prevState => ({
            ...prevState,
            mobileNumber: formattedValue,
            countryCode: data.dialCode,
            mobile: value.slice(data.dialCode.length),
        }));
    };
    const onCompanyMobileChange = (value: any, data: any, event: any, formattedValue: any) => {
        // console.log(data.dialCode, value.slice(data.dialCode.length));
        setState(prevState => ({
            ...prevState,
            companyPhone: formattedValue,
            country: data.dialCode,
            phone2: value.slice(data.dialCode.length),
        }));
    };
    const handleDateChange = (e: any) => {
        const selectedDate = new Date(e.target.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Set time to midnight for accurate comparison

        if (selectedDate > today) {
            toast.error('Date of Birth cannot be future date.');
        } else {
            setState(prevState => ({
                ...prevState,
                dob: e.target.value
            }));
        }
    };
    // const setPaymentTerms = (value: number) => {
    //     setState((prev) => ({ ...prev, paymentTerms: value }));
    // };

    const getStates = async () => {
        const payload = {
            country_code: "US"
        };
        const response = await api.auth.statesByCountryCode(payload);
        setStates(response.data);
    }

    useEffect(() => {
        getStates();
    }, []);


    const navigate = useNavigate();

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };
    const handleReset = () => {
        setActiveStep(0);
    };

    const handleFileChange = (event: any) => {
        const file = event.target.files[0];
        setFile(file);
    };
    const handleDragEnter = (e: any) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragOver = (e: any) => {
        e.preventDefault();
    };

    const handleDragLeave = () => {
        setIsDragging(false);
    };

    const handleDrop = (e: any) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files[0];
        setFile(file);
    };
    const setFile = (file: File) => {
        if (file) {
            setState(prevState => ({
                ...prevState,
                profileImage: file,
                imageUrl: URL.createObjectURL(file)
            }));
        } else {
            setState(prevState => ({
                ...prevState,
                profileImage: null,
                imageUrl: '',
            }));
        }
    };
    const handlePaymentTerms = (value: string | number) => {
        setState(prevState => ({
            ...prevState,
            paymentTerms: Number(value)
        }));
    };

    return (

        <Grid2 container className={styles.container}>
            <ToastContainer />
            <Grid2 container size={{ md: 12, sm: 12, xs: 12 }} display="flex" justifyContent="center" alignItems="center" flexDirection={'column'} className={styles.container}>
                <Box className={styles.logoContainer}>
                    <Link to="/">
                        <img src="/assets/images/auth_logo.png" alt="Logo" className={styles.logo} />
                    </Link>
                </Box>
                <Typography variant="body1" color="textSecondary" gutterBottom className={styles.formSubtitle}>
                    Welcome to <strong>Conectar</strong> web applications, let's Create your account and start posting your job requirement.
                </Typography>
                <Typography variant="h4" gutterBottom className={styles.formTitle}>
                    {steps[activeStep]}
                </Typography>
                <Box className={styles.signupForm}>
                    <form onSubmit={handleSubmit(onSubmit)} className='custom-Form' encType='multipart/form-data'>
                        <Box className={styles.formContainer}>
                            {activeStep === steps.length ? (
                                <React.Fragment>
                                    <Typography sx={{ mt: 2, mb: 1 }}>
                                        All steps completed - you&apos;re finished
                                    </Typography>
                                    <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                                        <Box sx={{ flex: '1 1 auto' }} />
                                        <Button onClick={handleReset} className={styles.formButton}>Reset</Button>
                                    </Box>
                                </React.Fragment>
                            ) : (
                                <React.Fragment>
                                    {activeStep === 0 ?
                                        <PersonalDetails
                                            errors={errors}
                                            register={register}
                                            handleChange={handleChange}
                                            handleDateChange={handleDateChange}
                                            handleStateChange={handleStateChange}
                                            handleStateInputChange={handleStateInputChange}
                                            handleCityChange={handleCityChange}
                                            handleCityInputChange={handleCityInputChange}
                                            firstName={firstName}
                                            lastName={lastName}
                                            dob={dob}
                                            states={states}
                                            stateName={stateName}
                                            cities={cities}
                                            cityName={cityName}
                                            zipCode={zipCode}
                                            streetAddress={streetAddress}
                                            imageUrl={imageUrl}
                                            handleFileChange={handleFileChange}
                                            handleDragEnter={handleDragEnter}
                                            handleDragOver={handleDragOver}
                                            handleDragLeave={handleDragLeave}
                                            handleDrop={handleDrop}
                                            isDragging={isDragging}
                                        />
                                        : ''}
                                    {activeStep === 1 ?
                                        <ContactInformation
                                            errors={errors}
                                            register={register}
                                            handleChange={handleChange}
                                            onMobileChange={onMobileChange}
                                            email={email}
                                            mobileNumber={mobileNumber}
                                        />
                                        : ''}
                                    {activeStep === 2 ? <CreatePassword
                                        errors={errors}
                                        register={register}
                                        handleChange={handleChange}
                                        password={password}
                                        confirmPassword={confirmPassword}
                                        acceptedTerms={acceptedTerms}
                                        acceptedPolicy={acceptedPolicy}
                                        acceptedOthers={acceptedOthers}
                                    />
                                        : ''}
                                    {activeStep === 3 ?
                                        <CompanyInformation
                                            errors={errors}
                                            register={register}
                                            handleChange={handleChange}
                                            onCompanyMobileChange={onCompanyMobileChange}
                                            companyName={companyName}
                                            companyDba={companyDba}
                                            taxId={taxId}
                                            companyPhone={companyPhone}
                                        />
                                        : ''}
                                    {activeStep === 4 ? <MakePayment
                                        errors={errors}
                                        register={register}
                                        handleChange={handleChange}
                                        paymentTerms={paymentTerms}
                                        handlePaymentTerms={handlePaymentTerms}
                                    />
                                        : ''}

                                    <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2, justifyContent: 'center', alignItems: 'center', gap: "30px" }}>
                                        {activeStep > 0 ?
                                            <Button
                                                type='button'
                                                variant="contained"
                                                color="primary"
                                                onClick={handleBack}
                                                sx={{ mr: 1 }}
                                                className={styles.formButton}
                                            >
                                                Back
                                            </Button>
                                            : ''}
                                        <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.formButton}`} onClick={submitForm}>
                                            {activeStep === steps.length - 1 ? 'Finish' : 'Continue'}
                                        </Button>
                                    </Box>
                                </React.Fragment>
                            )}
                            <Stepper alternativeLabel activeStep={activeStep} connector={<FormConnector />} className={styles.formStepper}>
                                {steps.map((label) => (
                                    <Step key={label}>
                                        <StepLabel StepIconComponent={FormStepIcon}></StepLabel>
                                    </Step>
                                ))}
                            </Stepper>
                        </Box>
                    </form>
                </Box>
                <Box className={styles.authBottomContainer} style={{ marginTop: '40px' }}>
                    <Typography variant="body2" color="textSecondary" component="span" style={{ marginRight: '10px' }}>
                        Already have an account?
                    </Typography>
                    <Link to="/" color="primary" className={styles.signupButton}>
                        Login
                    </Link>
                </Box>
            </Grid2>
        </Grid2>
    );
};

export default Registration;
