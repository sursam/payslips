import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Container, Typography, Select, MenuItem, FormControl, InputLabel, Box, Grid, Checkbox, FormControlLabel, InputAdornment, IconButton } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import '../../styles/login.css';
import { useAuth } from '../../context/AuthContext'; // Import the AuthContext

const Login: React.FC = () => {
    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [role, setRole] = useState<string>('User ');
    const [emailError, setEmailError] = useState<string>('');
    const [passwordError, setPasswordError] = useState<string>('');
    const [rememberMe, setRememberMe] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState<boolean>(false);

    const navigate = useNavigate();
    const { login } = useAuth(); // Use the login function from context

    const handleLogin = async () => {
        setEmailError('');
        setPasswordError('');

        let isValid = true;

        if (!email) {
            setEmailError('Email is required.');
            isValid = false;
        } else {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                setEmailError('Please enter a valid email address.');
                isValid = false;
            }
        }

        if (!password) {
            setPasswordError('Password is required.');
            isValid = false;
        } else if (password.length < 6) {
            setPasswordError('Password must be at least 6 characters long.');
            isValid = false;
        }

        if (isValid) {
            try {
                await login(role, email, password); // Call the login function
                navigate('/dashboard'); // Redirect to dashboard or another page on successful login
            } catch (error) {
                console.error('Login failed:', error);
                setPasswordError('Invalid credentials. Please try again.'); // Handle error
            }
        }
    };

    const handleSignup = () => {
        navigate('/signup');
    };

    return (
        <Grid container className="login-container">
            <Grid item xs={6} className="left-panel">
                <div className="background-image" />
                <Box className="signup-prompt">
                    <Typography variant="body2" component="span">
                        Don’t have an account?
                    </Typography>
                    <Button color="primary" className="signup-button" onClick={handleSignup}>
                        Sign Up
                    </Button>
                </Box>
            </Grid>

            <Grid item xs={6} className="right-panel">
                <Container maxWidth="sm" className="form-container">
                    <Box className="logo-container">
                        <img src="/assets/images/login_logo.png" alt="Logo" className="logo" />
                    </Box>
                    <Box className="form-box custom-Form">
                        <Box className="form-box-inner">
                            <Typography variant="h4" gutterBottom className="form-title">
                                Sign In
                            </Typography>
                            <Typography variant="body1" color="textSecondary" gutterBottom className="form-subtitle">
                                Please enter your login credentials
                            </Typography>
                            <FormControl fullWidth margin="normal">
                                <InputLabel>Role</InputLabel>
                                <Select value={role} onChange={(e) => setRole(e.target.value)} label="Role" className="role-select"
                                    startAdornment={
                                        <InputAdornment position="start">
                                            <Box className="icon-container">
                                                <img src='/assets/images/circle.png' alt="Background Role Icon" className="icon-background" />
                                                <img src='/assets/images/user.png' alt="Role Icon" className="icon" />
                                            </Box>
                                        </InputAdornment>
                                    }>
                                    <MenuItem value="MEMBER">User</MenuItem>
                                    <MenuItem value="Admin">Admin</MenuItem>
                                </Select>
                            </FormControl>
                            <TextField
                                label="Email ID"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Box className="icon-container">
                                                <img src='/assets/images/circle.png' alt="Background Email Icon" className="icon-background" />
                                                <img src='/assets/images/email.png' alt="Email Icon" className="icon" />
                                            </Box>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!emailError}
                                helperText={emailError}
                            />
                            <TextField
                                label="Password"
                                type={showPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                                                {showPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Box className="icon-container">
                                                <img src='/assets/images/circle.png' alt="Background Password Icon" className="icon-background" />
                                                <img src='/assets/images/lock.png' alt="Password Icon" className="icon" />
                                            </Box>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!passwordError}
                                helperText={passwordError}
                            />
                            <Box className="actions-container">
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={rememberMe}
                                            onChange={(e) => setRememberMe(e.target.checked)}
                                            color="primary"
                                        />
                                    }
                                    label="Remember Me"
                                />
                                <Button variant="contained" color="primary" onClick={handleLogin} className="login-button">
                                    Login
                                </Button>
                            </Box>
                        </Box>
                    </Box>
                    <Typography variant="body2" color="textSecondary" className="forgot-password">
                        Forgot Password?
                    </Typography>
                    <Typography variant="body2" color="textSecondary" className="copyright">
                        Copyright © 2025 Winners Are Grinners®.
                    </Typography>
                </Container>
            </Grid>
        </Grid>
    );
};

export default Login;
