import React, { useState } from "react";

interface ContractorDetails {
	id: number;
	fname: string;
	lname: string;
	country_code: number;
	mobile: string;
	email: string;
}

interface Job {
	id: number;
	unique_id: string;
	user_id: number;
	job_status: number;
	source: string;
	source_lat: string;
	source_lng: string;
	destination: string;
	delivery_lat: string;
	delivery_lng: string;
	pickup_date_time: string;
	delivery_date_time: string;
	contractor_details: ContractorDetails;
}

interface MarkerProps {
	lat: string;
	lng: string;
	unique_id: string;
	job: Job;
	onClick: () => any;
}

const Marker: React.FC<MarkerProps> = ({ lat, lng, unique_id, job, onClick }) => {
	const [showPopup, setShowPopup] = useState(false);

	const handleClick = () => {
		onClick();
		setShowPopup((prev) => !prev);
	};

	return (
		<div
			style={{
				position: "absolute",
				transform: "translate(-50%, -100%)",
				left: `${lng}%`,
				top: `${lat}%`,
				textAlign: "center",
				cursor: "pointer"
			}}
			onClick={handleClick}
		>
			<img
				src="../../assets/images/marker.png"
				alt="Marker"
				style={{
					height: "30px",
					width: "30px",
				}}
			/>
			<div
				style={{
					marginTop: "4px",
					background: "white",
					padding: "2px 6px",
					borderRadius: "4px",
					fontSize: "10px",
					fontWeight: "bold",
					boxShadow: "0 0 2px rgba(0,0,0,0.3)",
					whiteSpace: "nowrap"
				}}
			>
				{unique_id}
			</div>
			{showPopup && (
				<div
					style={{
						position: "absolute",
						top: "40px",
						left: "50%",
						transform: "translateX(-50%)",
						background: "#fff",
						padding: "8px",
						borderRadius: "6px",
						boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
						fontSize: "12px",
						width: "200px",
						zIndex: 10
					}}
				>
					<strong>{unique_id}</strong>
					<div><strong>Pickup:</strong> {job.source}</div>
					<div><strong>Drop-off:</strong> {job.destination}</div>
				</div>
			)}
		</div>
	);
};

export default Marker;

