import React, { useEffect, useState } from 'react';
import GoogleMapReact from 'google-map-react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
// import { GoogleMap, LoadScript } from '@react-google-maps/api';
import Marker from './marker';
import {
    Box,
    Card,
    CardContent,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid2,
    Button,
    Typography
} from '@mui/material';
import moment from 'moment';
import { SelectChangeEvent } from '@mui/material/Select';
import { Chart, registerables } from 'chart.js';
import styles from '../../styles/dashboard.module.css';
import { api } from '../../utils/api';
import LayoutProvider from '../../providers/LayoutProvider';
import { BusinessCenterOutlined, ErrorOutlineOutlined, TaskAltOutlined, SaveOutlined } from '@mui/icons-material';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import { toast } from 'react-toastify';

Chart.register(...registerables);

const AnyReactComponent = ({ text }: any) => <div>{text}</div>;

interface Banners {
    banner_title: string;
    banner_image: string;
    banner_url: string;
}
interface Job {
    id: string;
    unique_id: string;
    material_name: string;
    created_at: string;
    pickup_date_time: string;
    job_estimate_price: number;
    delivery_date_time: string;
    no_of_trucks: number;
}
interface currentLocation {
    lat: number;
    lng: number;
}

interface ActiveJobCodinates {
    id: number;
    unique_id: string;
    user_id: number;
    job_status: number;
    source: string;
    source_lat: string;
    source_lng: string;
    destination: string;
    delivery_lat: string;
    delivery_lng: string;
    pickup_date_time: string;
    delivery_date_time: string;
    contractor_details: {
        id: number;
        fname: string;
        lname: string;
        country_code: number;
        mobile: string;
        email: string;
    };
}

const Main: React.FC = () => {
    const defaultProps = {
        center: {
            lat: 10.99835602,
            lng: 77.01502627
        },
        zoom: 11
    };
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [age, setAge] = React.useState('');
    const [banners, setBanners] = useState<Banners[]>([]);
    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const [value, setValue] = useState(0);
    const [jobs, setJobs] = useState<Job[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [currentLocation, setCurrentLocation] = useState<currentLocation>({ lat: 0, lng: 0 });
    const [jobCoordinates, setJobCoordinates] = useState<ActiveJobCodinates[]>([]);
    const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
        lat: 22.5810906,  // default or initial location
        lng: 88.4818398
    });
    const [selectedJob, setSelectedJob] = useState<ActiveJobCodinates | null>(null);



    const memberid = localStorage.getItem("member_id") as string

    const barData = {
        labels: ['Jan 12', 'Jan 13', 'Jan 14', 'Jan 15', 'Jan 16', 'Jan 17', 'Jan 18'],
        datasets: [{
            data: [895.57, 100, 500, 804.59, 816.5, 700.65, 800],
            backgroundColor: '#66D2CC',
            label: "January"
        }],
    };


    const handleChange = (event: SelectChangeEvent) => {
        setAge(event.target.value as string);
    };
    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    // show map and fetch current location
    useEffect(() => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    console.log("Current location:", { lat: latitude, lng: longitude });
                    fetchActiveJobs(latitude, longitude);
                    setCurrentLocation({ lat: latitude, lng: longitude });
                    setMapCenter({ lat: latitude, lng: longitude }); // this moves the map!

                },
                (error) => {
                    console.error("Error getting location:", error);
                }
            );
        } else {
            console.error("Geolocation is not supported by this browser.");
        }
    }, []);

    // fetch active job co-ordinates
    const fetchActiveJobs = async (latitiude: number, longitude: number) => {
        try {
            const payload = {
                "latitude": latitiude,
                "longitude": longitude
            }
            const activeJobCoOrdiantes = await api.job.getActiveJobs(payload);
            if (activeJobCoOrdiantes.length > 0) {
                console.log("active Job Co-ordiantes", activeJobCoOrdiantes);
                const activeJobCoordinates = activeJobCoOrdiantes.map((job: any) => ({
                    id: job.id,
                    unique_id: job.unique_id,
                    user_id: job.user_id,
                    job_status: job.job_status,
                    source: job.source,
                    source_lat: job.source_lat,
                    source_lng: job.source_lng,
                    destination: job.destination,
                    delivery_lat: job.delivery_lat,
                    delivery_lng: job.delivery_lng,
                    pickup_date_time: job.pickup_date_time,
                    delivery_date_time: job.delivery_date_time,
                    contractor_details: job.contractor_details
                }));

                setJobCoordinates(activeJobCoordinates);
                console.log("activeJobCoordinates", activeJobCoordinates);
            }
        } catch (error) {
            toast.error('Failed to fetch active jobs');
        }
    }

    // fetch banners via api call
    useEffect(() => {
        const fetchBanners = async () => {
            try {
                const response = await api.activity.fetchActivity();
                console.log("Response:", response);
                setBanners(response);
            } catch (error) {
                console.error("Failed to fetch jobs:", error);
            }
        };
        fetchBanners();
    }, []);


    // upcoming jobs api call
    useEffect(() => {
        const fetchJobs = async () => {
            try {
                const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
                console.log("current Date", currentDate);

                const response = await api.job.getMyJobs(
                    1,
                    currentDate.toString(),
                    currentPage
                );
                setJobs(response?.data || []);
                setTotalPages(response?.pagination?.total_pages || 0);
                setCurrentPage(response?.pagination?.current_page || 1);
            } catch (error) {
                console.error("Failed to fetch jobs:", error);
                setJobs([]);
            }
        };

        fetchJobs();
    }, [value]); // Re-fetch when tab value changes
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 4
    };


    return (
        <LayoutProvider pageTitle="Dashboard">
            {/* Dashboard cards */}
            <Grid2 container spacing={3} style={{ marginBottom: '20px' }}>
                <Grid2 size={{ md: 3, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.dbuserBoxwrap}>
                        <Box className={`${styles.ttlBar} ${styles.cardBlue}`}>
                            <div className={styles.cardIcon}>
                                <IconButton className={styles.toggleButton}>
                                    <BusinessCenterOutlined style={{ width: '18px', height: '18px', color: '#005DAA' }} />
                                </IconButton>
                            </div>
                            <div className={styles.cardBox}>
                                <h6 className={styles.cardCount}>
                                    100
                                </h6>
                                <span>Total Posted Jobs</span>
                            </div>
                        </Box>
                    </CardContent>
                </Grid2>
                <Grid2 size={{ md: 3, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.dbuserBoxwrap}>
                        <Box className={`${styles.ttlBar} ${styles.cardOrange}`}>
                            <div className={styles.cardIcon}>
                                <IconButton className={styles.toggleButton}>
                                    <ErrorOutlineOutlined style={{ width: '18px', height: '18px', color: '#E07211' }} />
                                </IconButton>
                            </div>
                            <div className={styles.cardBox}>
                                <h6 className={styles.cardCount}>
                                    30
                                </h6>
                                <span>Pending Jobs</span>
                            </div>
                        </Box>
                    </CardContent>
                </Grid2>
                <Grid2 size={{ md: 3, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.dbuserBoxwrap}>
                        <Box className={`${styles.ttlBar} ${styles.cardGreen}`}>
                            <div className={styles.cardIcon}>
                                <IconButton className={styles.toggleButton}>
                                    <TaskAltOutlined style={{ width: '18px', height: '18px', color: '#079D0F' }} />
                                </IconButton>
                            </div>
                            <div className={styles.cardBox}>
                                <h6 className={styles.cardCount}>
                                    70
                                </h6>
                                <span>Completed Jobs</span>
                            </div>
                        </Box>
                    </CardContent>
                </Grid2>
                <Grid2 size={{ md: 3, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.dbuserBoxwrap}>
                        <Box className={`${styles.ttlBar} ${styles.cardGray}`}>
                            <div className={styles.cardIcon}>
                                <IconButton className={styles.toggleButton}>
                                    <SaveOutlined style={{ width: '18px', height: '18px', color: '#283c50' }} />
                                </IconButton>
                            </div>
                            <div className={styles.cardBox}>
                                <h6 className={styles.cardCount}>
                                    10
                                </h6>
                                <span>Drafted Jobs</span>
                            </div>
                        </Box>
                    </CardContent>
                </Grid2>
            </Grid2>
            {/* Dashboard cards */}
            <Grid2 container spacing={3} style={{ marginBottom: '20px' }}>
                <Grid2 size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className="slider-container">
                            <Slider {...settings}>
                                {banners.map((banner, index) => (
                                    <div key={index}>
                                        <a href={banner.banner_url} target="_blank" rel="noopener noreferrer">
                                            <img
                                                src={banner.banner_image}
                                                alt={banner.banner_title}
                                                className="object-contain"
                                                style={{ height: '70px', width: '100px' }}
                                            />
                                        </a>
                                    </div>
                                ))}
                            </Slider>

                        </div>
                    </CardContent>
                </Grid2>
            </Grid2>
            <Grid2 container spacing={3}>
                <Grid2 size={{ md: 9, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className={styles.cardTitle}>
                            <h5>Live Active Jobs</h5>
                        </div>
                        <div className={styles.cardContent}>
                            <div style={{ height: '40vh', width: '100%' }}>
                                <GoogleMapReact
                                    bootstrapURLKeys={{ key: "AIzaSyBvhh3BKrnIsuvRCLuPlsUEdcOt4Kj5stY" }}
                                    defaultCenter={defaultProps.center}
                                    center={mapCenter}
                                    defaultZoom={14}
                                    zoom={14}
                                >
                                    {jobCoordinates.map((coord, index) => (
                                        <Marker key={coord.unique_id} lat={coord.source_lat} lng={coord.source_lng} unique_id={coord.unique_id} job={coord} // entire job object
                                            onClick={() => setSelectedJob(coord)} />
                                    ))}
                                </GoogleMapReact>

                            </div>
                        </div>
                    </CardContent>
                </Grid2>
                <Grid2 size={{ md: 3, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className={styles.cardContent}>
                            <img src="/assets/images/post-job.png" alt="Post a new job" style={{ marginBottom: '20px' }} />
                            <Button type='button' variant="contained" color="primary" className={styles.formButton}>Post a new job</Button>
                        </div>
                    </CardContent>
                </Grid2>

                <Grid2 size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className={styles.cardTitle}>
                            <h5>Upcoming Pickups</h5>
                        </div>

                        <TableContainer>
                            {jobs.length > 0 ? (
                                <Table className={styles.table}>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Job ID</TableCell>
                                            <TableCell>Material</TableCell>
                                            <TableCell>Posted Date & Time</TableCell>
                                            <TableCell>Job Cost</TableCell>
                                            <TableCell>No. Of Trucks</TableCell>
                                            <TableCell>Pickup Date & Time</TableCell>
                                            <TableCell>Delivery Date & Time</TableCell>
                                            <TableCell></TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {jobs.map((job) => (
                                            <TableRow key={job.id}>
                                                <TableCell>{job?.unique_id}</TableCell>
                                                <TableCell>{job?.material_name}</TableCell>
                                                <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                <TableCell>${job.job_estimate_price}</TableCell>
                                                <TableCell>
                                                    <span className={`${styles.badge} ${styles.blueBg}`}>
                                                        {job.no_of_trucks}
                                                    </span>
                                                </TableCell>
                                                <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                <TableCell>
                                                    {/* Actions (e.g. menu) */}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            ) : (
                                <div className={styles.noDataContainer}>
                                    <Typography variant="h6" color="textSecondary" align="center">
                                        <AssignmentLateIcon fontSize="large" />
                                        <br />
                                        No jobs found
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary" align="center">
                                        There are currently no jobs matching your criteria
                                    </Typography>
                                </div>
                            )}

                        </TableContainer>

                    </CardContent>
                </Grid2>
            </Grid2>

        </LayoutProvider>
    );
};

export default Main;
