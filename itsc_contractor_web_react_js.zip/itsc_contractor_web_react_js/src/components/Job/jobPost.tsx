import React, { useEffect, useState } from 'react';
import {
    Box,
    Card,
    CardContent,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid2,
    Button,
    Tabs,
    Tab,
    Container,
    Paper,
    Typography,
    Stepper,
    Step,
    StepLabel
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
import Location from './Forms/location';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import JobDescription from './Forms/jobDescription';
import { GOOGLE_MAPS_API_KEY } from "../../config/config";

function jobTabProps(index: number) {
    return {
        id: `job-tab-${index}`,
        'aria-controls': `job-tabpanel-${index}`,
        className: styles.jobTabLink,
    };
}

interface JobForm {
    pickupLocation: string;
    pickupLongitude: string;
    pickupLatitude: string;
    pickupCompanyName: string;
    pickupPointOfContact: string;
    pickupEmail: string;
    pickupContactNumber: string;
    pickupDate: string;
    pickupTime: string;
    dropoffLocation: string;
    dropoffLongitude: string;
    dropoffLatitude: string;
    dropoffCompanyName: string;
    dropoffPointOfContact: string;
    dropoffEmail: string;
    dropoffContactNumber: string;
    dropoffDate: string;
    dropoffTime: string;


    truckTypes: string[];
}

const JobPost: React.FC = () => {
    const [activeStep, setActiveStep] = React.useState(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);

    var [state, setState] = useState<JobForm>({
        pickupLocation: '',
        pickupLongitude: '',
        pickupLatitude: '',
        pickupCompanyName: '',
        pickupPointOfContact: '',
        pickupEmail: '',
        pickupContactNumber: '',
        pickupDate: '',
        pickupTime: '',
        dropoffLocation: '',
        dropoffLongitude: '',
        dropoffLatitude: '',
        dropoffCompanyName: '',
        dropoffPointOfContact: '',
        dropoffEmail: '',
        dropoffContactNumber: '',
        dropoffDate: '',
        dropoffTime: '',


        truckTypes: [],
    });
    var {
        pickupLocation,
        pickupLongitude,
        pickupLatitude,
        pickupCompanyName,
        pickupPointOfContact,
        pickupEmail,
        pickupContactNumber,
        pickupDate,
        pickupTime,
        dropoffLocation,
        dropoffLongitude,
        dropoffLatitude,
        dropoffCompanyName,
        dropoffPointOfContact,
        dropoffEmail,
        dropoffContactNumber,
        dropoffDate,
        dropoffTime,
        truckTypes,
    } = state;

    var validationObject: any;
    const validationSchema = Yup.object().shape(validationObject);
    var formOptions = { resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => {
        clearErrors()
        reset(state)
    }
    const onSubmit = async (data: any) => {
        setIsLoading(true);
        console.log(data)
        switch (activeStep) {
            case 0:
            case 1:
            case 2:
                break;
        }
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        setIsLoading(false);

    };

    const labels = ["Locations", "Job Description", "Summary"];
    const handleSteps = (step: number) => {
        switch (step) {
            case 0:
                return <Location
                    errors={errors}
                    register={register}
                    handleChange={handleChange}
                    handleDateChange={handleDateChange}
                    setLocationData={setLocationData}
                    pickupLocation={pickupLocation}
                    dropoffLocation={dropoffLocation}
                    pickupLongitude={pickupLongitude}
                    pickupLatitude={pickupLatitude}
                    dropoffLongitude={dropoffLongitude}
                    dropoffLatitude={dropoffLatitude}
                />;
            case 1:
                return <JobDescription
                    errors={errors}
                    register={register}
                    handleChange={handleChange}
                    truckTypes={truckTypes}
                />;
            case 2:
                return <></>;
            default:
                throw new Error("Unknown step");
        }
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        let address = '';
        // console.log(name, value)
        switch (name) {
            case 'pickupLongitude':
                if (pickupLongitude && value) {
                    address = fetchLocationByCoordinate(pickupLongitude, value);
                    setState(prevState => ({
                        ...prevState,
                        pickupLocation: address,
                        pickupLongitude: value,
                    }));
                }
                break;
            case 'pickupLatitude':
                if (value && pickupLongitude) {
                    address = fetchLocationByCoordinate(value, pickupLongitude);
                    setState(prevState => ({
                        ...prevState,
                        pickupLocation: address,
                        pickupLatitude: value,
                    }));
                }
                break;
            case 'dropoffLongitude':
                if (dropoffLongitude && value) {
                    address = fetchLocationByCoordinate(dropoffLongitude, value);
                    setState(prevState => ({
                        ...prevState,
                        dropoffLocation: address,
                        dropoffLongitude: value,
                    }));
                }
                break;
            case 'dropoffLatitude':
                if (value && dropoffLongitude) {
                    address = fetchLocationByCoordinate(value, dropoffLongitude);
                    setState(prevState => ({
                        ...prevState,
                        dropoffLocation: address,
                        dropoffLatitude: value,
                    }));
                }
                break;
            default:
                setState(prevState => ({
                    ...prevState,
                    [name]: value,
                }));
        }
        // trigger(name);
    };
    const fetchLocationByCoordinate = (latitude: string, longitude: string): any => {
        fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`)
            .then(response => response.json())
            .then(data => {
                console.log(latitude, longitude, data.results[0].formatted_address);
                return data.results[0].formatted_address;
            });
    }
    const handleDateChange = (e: any) => {
        setState(prevState => ({
            ...prevState,
            [e.target.name]: e.target.value
        }));
    };

    const setLocationData = (fieldName: string, locationData: any) => {
        console.log(fieldName, locationData);
        switch (fieldName) {
            case 'pickupLocation':
                setState(prevState => ({
                    ...prevState,
                    pickupLocation: locationData.address,
                    pickupLongitude: locationData.longitude,
                    pickupLatitude: locationData.latitude
                }));
                break;
            case 'dropoffLocation':
                setState(prevState => ({
                    ...prevState,
                    dropoffLocation: locationData.address,
                    dropoffLongitude: locationData.longitude,
                    dropoffLatitude: locationData.latitude
                }));
                break;
        }

    }

    return (
        <LayoutProvider pageTitle="Post New Job">
            <Grid2 container spacing={3}>
                <Grid2 size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <form className='custom-Form' encType='multipart/form-data' onSubmit={handleSubmit(onSubmit)}>
                        {activeStep === labels.length ? (
                            <></>
                        ) : (
                            <>
                                <div className={styles.cardTitle}>
                                    <Stepper activeStep={activeStep} alternativeLabel>
                                        {labels.map((label) => (
                                            <Step key={label}>
                                                <StepLabel>{label}</StepLabel>
                                            </Step>
                                        ))}
                                    </Stepper>
                                </div>
                                <CardContent className={styles.gridBoxwrap}>
                                    {handleSteps(activeStep)}
                                </CardContent>
                            </>
                        )}
                        <Box sx={{ display: 'flex', flexDirection: 'row', paddingBottom: '20px', justifyContent: 'center', alignItems: 'center', gap: "30px" }}>
                            {activeStep > 0 ?
                                <Button
                                    type='button'
                                    variant="contained"
                                    color="primary"
                                    onClick={handleBack}
                                    sx={{ mr: 1 }}
                                    className={styles.formButton}
                                >
                                    Previous
                                </Button>
                                : ''}
                            <Button type='submit' variant="contained" color="primary" className={`${isLoading ? 'loading disabled' : ''} ${styles.formButton}`} onClick={submitForm}>
                                {activeStep === labels.length - 1 ? 'Finish' : 'Continue'}
                            </Button>
                        </Box>
                    </form>
                </Grid2>
            </Grid2>

        </LayoutProvider>
    );
};

export default JobPost;
