import React, { useState, useEffect } from 'react';
import { TextField, Typography, Box, Grid2, FormControlLabel, Radio, Select, MenuItem, FormControl, InputLabel, Stack, ListItemIcon, Checkbox, ListItemText } from '@mui/material';
import Switch, { SwitchProps } from '@mui/material/Switch';
import { styled } from '@mui/material/styles';
import styles from '../../../styles/job.module.css';
import { api } from '../../../utils/api';
import Loader from '../../Loader/loader';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    truckTypes: string[];
}
const SwitchButton = styled((props: SwitchProps) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(16px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#65C466',
                opacity: 1,
                border: 0,
                ...theme.applyStyles('dark', {
                    backgroundColor: '#2ECA45',
                }),
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#33cf4d',
            border: '6px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color: theme.palette.grey[100],
            ...theme.applyStyles('dark', {
                color: theme.palette.grey[600],
            }),
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: 0.7,
            ...theme.applyStyles('dark', {
                opacity: 0.3,
            }),
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 22,
        height: 22,
    },
    '& .MuiSwitch-track': {
        borderRadius: 26 / 2,
        backgroundColor: '#E9E9EA',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
        ...theme.applyStyles('dark', {
            backgroundColor: '#39393D',
        }),
    },
}));
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250
        }
    },
    getContentAnchorEl: null,
    anchorOrigin: {
        vertical: "bottom",
        horizontal: "center"
    },
    transformOrigin: {
        vertical: "top",
        horizontal: "center"
    },
    variant: "menu"
};

const JobDescription: React.FC<ChildProps> = ({ errors, register, handleChange, truckTypes }) => {
    const [materialTypeList, setMaterialTypeList] = useState([]);
    const [loadTypeList, setLoadTypeList] = useState([]);
    const [equipmentTypeList, setEquipmentTypeList] = useState([]);
    const [truckTypeList, setTruckTypeList] = useState([]);
    const [switchChecked, setSwitchChecked] = useState(false);
    const [anyEquipment, setAnyEquipment] = useState('no');
    const [isFormLoading, setIsFormLoading] = useState<boolean>(true);
    const filterTruckTypeValues = () => {
        let filteredValues = truckTypeList.filter((item: any) => truckTypes.includes(item.truck_type_id)).map((item: any) => item.name).join(", ");
        return filteredValues;
    }
    const getMaterialTypes = async () => {
        const response = await api.job.getMaterialTypeList();
        setMaterialTypeList(response.data);
        getloadTypes();
        // console.log(response);
    }
    const getloadTypes = async () => {
        const response = await api.job.getLoadTypeList();
        setLoadTypeList(response.data);
        getEquipmentTypes();
        // console.log(response);
    }
    const getEquipmentTypes = async () => {
        const response = await api.job.getEquipmentTypeList();
        setEquipmentTypeList(response.data);
        getTruckTypes();
        // console.log(response);
    }
    const getTruckTypes = async () => {
        const response = await api.job.getTruckTypeList();
        setTruckTypeList(response.data);
        setIsFormLoading(false);
        // console.log(response);
    }
    useEffect(() => {
        getMaterialTypes();
    }, []);
    return (
        <Box className={styles.formContainer}>
            <Typography variant="h6" gutterBottom className={styles.formTitle}>
                Description
            </Typography>

            {isFormLoading ?
                <Box className="loaderContainer">
                    <Loader />
                </Box>
                : ''
            }
            <Grid2 container spacing={3}>
                <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                    <FormControl fullWidth>
                        <Typography variant="h6" gutterBottom className={styles.formTitle}>
                            Job Type
                            <FormControlLabel
                                control={
                                    <Radio
                                        checked={true}
                                        color="primary"
                                        value={'short-haul'}
                                        {...register('jobType', { onChange: handleChange })}
                                    />
                                }
                                label="Short-Haul"
                                sx={{ marginLeft: "5px" }}
                            />
                        </Typography>
                        <div className="invalid-feedback">{errors.jobType?.message?.toString()}</div>
                    </FormControl>

                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <InputLabel id="material-type-label">Material Type</InputLabel>
                        <Select
                            labelId="material-type-label"
                            id="material-type"
                            label="Material Type"
                            {...register('materialType', { onChange: handleChange })}
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {materialTypeList && materialTypeList.map((materialType: any) => (
                                <MenuItem value={materialType.material_id} key={materialType.material_id}>{materialType.name}</MenuItem>
                            ))}
                        </Select>
                        <div className="invalid-feedback">{errors.materialType?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Order Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.orderNumber ? 'is-invalid' : ''}`}
                            {...register('orderNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "orderNumber" }}
                        />
                        <div className="invalid-feedback">{errors.orderNumber?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Total Millage (Miles)"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.totalMillage ? 'is-invalid' : ''}`}
                            {...register('totalMillage', { onChange: handleChange })}
                            inputProps={{ autoComplete: "totalMillage" }}
                        />
                        <div className="invalid-feedback">{errors.totalMillage?.message?.toString()}</div>
                    </FormControl>
                    <Grid2 container spacing={0}>
                        <Grid2 size={{ md: 8, sm: 12, xs: 12 }}>
                            <FormControl fullWidth>
                                <TextField
                                    label="Number of Units"
                                    variant="outlined"
                                    fullWidth
                                    margin="normal"
                                    className={`${styles.formControl} ${errors?.numberOfUnits ? 'is-invalid' : ''}`}
                                    {...register('numberOfUnits', { onChange: handleChange })}
                                    inputProps={{ autoComplete: "numberOfUnits" }}
                                />
                                <div className="invalid-feedback">{errors.numberOfUnits?.message?.toString()}</div>
                            </FormControl>
                        </Grid2>
                        <Grid2 size={{ md: 4, sm: 12, xs: 12 }}>
                            <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                                <InputLabel id="unit-label">Unit</InputLabel>
                                <Select
                                    labelId="unit-label"
                                    id="unit"
                                    label="Unit"
                                    {...register('unit', { onChange: handleChange })}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    {loadTypeList && loadTypeList.map((loadType: any) => (
                                        <MenuItem value={loadType.load_id} key={loadType.load_id}>{loadType.name}</MenuItem>
                                    ))}
                                </Select>
                                <div className="invalid-feedback">{errors.unit?.message?.toString()}</div>
                            </FormControl>
                        </Grid2>
                    </Grid2>
                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
                            <Typography>Hourly Job</Typography>
                            <SwitchButton inputProps={{ 'aria-label': 'Hourly Job' }} checked={switchChecked} onChange={(event) => setSwitchChecked(event.target.checked)} />
                        </Stack>
                    </FormControl>
                    {switchChecked ?
                        <Grid2 container spacing={0}>
                            <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                                <FormControl fullWidth>
                                    <TextField
                                        label="Minimum Hour(s)"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        className={`${styles.formControl} ${errors?.minimumHours ? 'is-invalid' : ''}`}
                                        {...register('minimumHours', { onChange: handleChange })}
                                        inputProps={{ autoComplete: "minimumHours" }}
                                    />
                                    <div className="invalid-feedback">{errors.minimumHours?.message?.toString()}</div>
                                </FormControl>
                            </Grid2>
                            <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                                <FormControl fullWidth>
                                    <TextField
                                        label="Maximum Hour(s)"
                                        variant="outlined"
                                        fullWidth
                                        margin="normal"
                                        className={`${styles.formControl} ${errors?.maximumHours ? 'is-invalid' : ''}`}
                                        {...register('maximumHours', { onChange: handleChange })}
                                        inputProps={{ autoComplete: "maximumHours" }}
                                    />
                                    <div className="invalid-feedback">{errors.maximumHours?.message?.toString()}</div>
                                </FormControl>
                            </Grid2>
                        </Grid2>
                        : ''}
                </Grid2>
                <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                    <FormControl fullWidth>
                        <Typography variant="h6" gutterBottom className={styles.formTitle}>
                            Any Equipment
                            <FormControlLabel
                                control={
                                    <Radio
                                        color="primary"
                                        value={'yes'}
                                        checked={anyEquipment == 'yes'}
                                        onChange={() => setAnyEquipment('yes')}
                                    />
                                }
                                label="Yes"
                                sx={{ marginLeft: "5px" }}
                            />
                            <FormControlLabel
                                control={
                                    <Radio
                                        color="primary"
                                        value={'no'}
                                        checked={anyEquipment == 'no'}
                                        onChange={() => setAnyEquipment('no')}
                                    />
                                }
                                label="No"
                            />
                        </Typography>
                        <div className="invalid-feedback">{errors.anyEquipment?.message?.toString()}</div>
                    </FormControl>
                    {anyEquipment == 'yes' ?
                        <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                            <InputLabel id="equipment-type-label">Equipment Type</InputLabel>
                            <Select
                                labelId="equipment-type-label"
                                id="equipment-type"
                                label="Equipment Type"
                                {...register('equipmentType', { onChange: handleChange })}
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                {equipmentTypeList && equipmentTypeList.map((equipmentType: any) => (
                                    <MenuItem value={equipmentType.equipment_id} key={equipmentType.equipment_id}>{equipmentType.name}</MenuItem>
                                ))}
                            </Select>
                            <div className="invalid-feedback">{errors.equipmentType?.message?.toString()}</div>
                        </FormControl>
                        : ''}
                    <FormControl sx={{ marginTop: "16px", marginBottom: "8px" }} fullWidth>
                        <InputLabel id="truck-type-label">Truck Type</InputLabel>
                        <Select
                            labelId="truck-type-label"
                            id="truck-type"
                            label="Truck Type"
                            multiple
                            value={truckTypes}
                            {...register('truckTypes', { onChange: handleChange })}
                            renderValue={filterTruckTypeValues}
                            MenuProps={MenuProps}
                            className={`${styles.formControl} ${errors?.truckTypes ? 'is-invalid' : ''}`}
                        >
                            {truckTypeList.length && truckTypeList.map((truckType: any) => (
                                <MenuItem key={truckType.truck_type_id} value={truckType.truck_type_id} className={styles.truck_type_menu_item}>
                                    <ListItemIcon className={`${styles.truck_type_check} ${truckTypes.indexOf(truckType.truck_type_id) > -1 ? styles.checked : ''}`}>
                                        <Checkbox checked={truckTypes.indexOf(truckType.truck_type_id) > -1} />
                                    </ListItemIcon>
                                    <ListItemText primary={truckType.name} secondary={`${truckType.specs} Axels | ${truckType.weight_capacity} Tons`} className={styles.truck_type_option} />
                                    <ListItemIcon>
                                        <img src={truckType.trucktype_image} alt={truckType.name} className={styles.trucktype_image} />
                                    </ListItemIcon>
                                </MenuItem>
                            ))}
                        </Select>
                        <div className="invalid-feedback">{errors.truckTypes?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Load Spacing in Minutes"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.loadSpacingMinutes ? 'is-invalid' : ''}`}
                            {...register('loadSpacingMinutes', { onChange: handleChange })}
                            inputProps={{ autoComplete: "loadSpacingMinutes" }}
                        />
                        <div className="invalid-feedback">{errors.loadSpacingMinutes?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Price Per Unit"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.pricePerUnit ? 'is-invalid' : ''}`}
                            {...register('pricePerUnit', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pricePerUnit" }}
                        />
                        <div className="invalid-feedback">{errors.pricePerUnit?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Total Job Cost"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.totalJobCost ? 'is-invalid' : ''}`}
                            {...register('totalJobCost', { onChange: handleChange })}
                            inputProps={{ autoComplete: "totalJobCost" }}
                        />
                        <div className="invalid-feedback">{errors.totalJobCost?.message?.toString()}</div>
                    </FormControl>

                </Grid2>
            </Grid2>


        </Box >

    );
};

export default JobDescription;
