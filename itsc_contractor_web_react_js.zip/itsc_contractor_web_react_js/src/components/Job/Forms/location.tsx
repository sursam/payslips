import React, { useState } from 'react';
import { TextField, Typography, Box, Grid2, FormControl } from '@mui/material';
import styles from '../../../styles/job.module.css';
import LocationInput from '../../CustomFields/locationInput';

interface ChildProps {
    errors: any;
    register: any;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleDateChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    setLocationData: any;
    pickupLocation: string;
    dropoffLocation: string;
    pickupLongitude: string;
    pickupLatitude: string;
    dropoffLongitude: string;
    dropoffLatitude: string;
}
const Location: React.FC<ChildProps> = ({ errors, register, handleChange, handleDateChange, setLocationData, pickupLocation, dropoffLocation, pickupLongitude, pickupLatitude, dropoffLongitude, dropoffLatitude }) => {

    return (
        <Box className={styles.formContainer}>
            <Grid2 container spacing={3}>
                <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle}>
                        Pickup Location
                    </Typography>
                    <FormControl fullWidth>
                        <LocationInput
                            setLocationData={setLocationData}
                            name="pickupLocation"
                            value={pickupLocation}
                            className={`${styles.formControl} ${errors?.pickupLocation ? 'is-invalid' : ''}`}
                        />
                        <div className="invalid-feedback">{errors.pickupLocation?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Longitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={pickupLongitude}
                                className={`${styles.formControl} ${errors?.pickupLongitude ? 'is-invalid' : ''}`}
                                {...register('pickupLongitude', { onChange: handleChange })}
                                inputProps={{ autoComplete: "pickupLongitude" }}
                            />
                            <div className="invalid-feedback">{errors.pickupLongitude?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Latitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={pickupLatitude}
                                className={`${styles.formControl} ${errors?.pickupLatitude ? 'is-invalid' : ''}`}
                                {...register('pickupLatitude', { onChange: handleChange })}
                                inputProps={{ autoComplete: "pickupLatitude" }}
                            />
                            <div className="invalid-feedback">{errors.pickupLatitude?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                    <FormControl fullWidth>
                        <TextField
                            label="Company Name"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.pickupCompanyName ? 'is-invalid' : ''}`}
                            {...register('pickupCompanyName', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupCompanyName" }}
                        />
                        <div className="invalid-feedback">{errors.pickupCompanyName?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Point Of Contact"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.pickupPointOfContact ? 'is-invalid' : ''}`}
                            {...register('pickupPointOfContact', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupPointOfContact" }}
                        />
                        <div className="invalid-feedback">{errors.pickupPointOfContact?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            type='email'
                            label="Email Id"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.pickupEmail ? 'is-invalid' : ''}`}
                            {...register('pickupEmail', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupEmail" }}
                        />
                        <div className="invalid-feedback">{errors.pickupEmail?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Contact Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.pickupContactNumber ? 'is-invalid' : ''}`}
                            {...register('pickupContactNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "pickupContactNumber" }}
                        />
                        <div className="invalid-feedback">{errors.pickupContactNumber?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Pickup Date"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="date"
                                className={`${styles.formControl} ${errors?.pickupDate ? 'is-invalid' : ''}`}
                                {...register('pickupDate', { onChange: handleDateChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                            <div className="invalid-feedback">{errors.pickupDate?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Pickup Time"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.pickupTime ? 'is-invalid' : ''}`}
                                {...register('pickupTime', { onChange: handleChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                            <div className="invalid-feedback">{errors.pickupTime?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                </Grid2>
                <Grid2 size={{ md: 6, sm: 12, xs: 12 }}>
                    <Typography variant="h6" gutterBottom className={styles.formTitle}>
                        Drop off Location
                    </Typography>
                    <FormControl fullWidth>
                        <LocationInput
                            setLocationData={setLocationData}
                            name="dropoffLocation"
                            value={dropoffLocation}
                            className={`${styles.formControl} ${errors?.dropoffLocation ? 'is-invalid' : ''}`}
                        />
                        <div className="invalid-feedback">{errors.dropoffLocation?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Longitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={dropoffLongitude}
                                className={`${styles.formControl} ${errors?.dropoffLongitude ? 'is-invalid' : ''}`}
                                {...register('dropoffLongitude', { onChange: handleChange })}
                                inputProps={{ autoComplete: "dropoffLongitude" }}
                            />
                            <div className="invalid-feedback">{errors.dropoffLongitude?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Latitude"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                value={dropoffLatitude}
                                className={`${styles.formControl} ${errors?.dropoffLatitude ? 'is-invalid' : ''}`}
                                {...register('dropoffLatitude', { onChange: handleChange })}
                                inputProps={{ autoComplete: "dropoffLatitude" }}
                            />
                            <div className="invalid-feedback">{errors.dropoffLatitude?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                    <FormControl fullWidth>
                        <TextField
                            label="Company Name"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.dropoffCompanyName ? 'is-invalid' : ''}`}
                            {...register('dropoffCompanyName', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffCompanyName" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffCompanyName?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Point Of Contact"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.dropoffPointOfContact ? 'is-invalid' : ''}`}
                            {...register('dropoffPointOfContact', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffPointOfContact" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffPointOfContact?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            type='email'
                            label="Email Id"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.dropoffEmail ? 'is-invalid' : ''}`}
                            {...register('dropoffEmail', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffEmail" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffEmail?.message?.toString()}</div>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            label="Contact Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            className={`${styles.formControl} ${errors?.dropoffContactNumber ? 'is-invalid' : ''}`}
                            {...register('dropoffContactNumber', { onChange: handleChange })}
                            inputProps={{ autoComplete: "dropoffContactNumber" }}
                        />
                        <div className="invalid-feedback">{errors.dropoffContactNumber?.message?.toString()}</div>
                    </FormControl>
                    <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
                        <FormControl fullWidth>
                            <TextField
                                label="Drop off Date"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                type="date"
                                className={`${styles.formControl} ${errors?.dropoffDate ? 'is-invalid' : ''}`}
                                {...register('dropoffDate', { onChange: handleDateChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffDate?.message?.toString()}</div>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                label="Drop off Time"
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.dropoffTime ? 'is-invalid' : ''}`}
                                {...register('dropoffTime', { onChange: handleChange })}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                            <div className="invalid-feedback">{errors.dropoffTime?.message?.toString()}</div>
                        </FormControl>
                    </Box>
                </Grid2>
                <FormControl fullWidth>
                    <TextField
                        type='textarea'
                        label="Additional Note"
                        variant="outlined"
                        multiline
                        rows={3}
                        fullWidth
                        margin="normal"
                        className={`${styles.formControl} ${errors?.additionalNote ? 'is-invalid' : ''}`}
                        {...register('additionalNote', { onChange: handleChange })}
                        inputProps={{ autoComplete: "additionalNote" }}
                    />
                    <div className="invalid-feedback">{errors.additionalNote?.message?.toString()}</div>
                </FormControl>
            </Grid2>

        </Box >

    );
};

export default Location;
