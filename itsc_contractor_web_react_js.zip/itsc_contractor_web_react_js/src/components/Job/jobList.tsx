import React, { use, useCallback, useEffect, useState, useRef } from 'react';
import { api } from '../../utils/api';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import moment from 'moment';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import {
    Box,
    Card,
    CardContent,
    Menu,
    MenuItem,
    Pagination,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Grid2,
    Button,
    Tabs,
    Tab,
    Typography
} from '@mui/material';
import styles from '../../styles/job.module.css';
import LayoutProvider from '../../providers/LayoutProvider';
const options = [
    'view Job',
    'Edit Job',
    'cancel Job'
];

const ITEM_HEIGHT = 48;

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
}
interface Job {
    id: string;
    unique_id: string;
    material_name: string;
    created_at: string;
    pickup_date_time: string;
    job_estimate_price: number;
    delivery_date_time: string;
    no_of_trucks: number;
}

function JobTabPanel(props: TabPanelProps) {
    const { children, value, index, ...other } = props;


    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`job-tabpanel-${index}`}
            aria-labelledby={`job-tab-${index}`}
            {...other}
        >
            {value === index && <Box sx={{ p: 0 }}>{children}</Box>}
        </div>
    );
}
function jobTabProps(index: number) {
    return {
        id: `job-tab-${index}`,
        'aria-controls': `job-tabpanel-${index}`,
        className: styles.jobTabLink,
    };
}

const JobList: React.FC = () => {
    const [value, setValue] = useState(0);
    const [jobs, setJobs] = useState<Job[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const hasFetched = useRef(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);

    // Separate useEffect for data fetching
    useEffect(() => {
        if (hasFetched.current) return;

        const fetchJobs = async () => {
            try {
                const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
                console.log("current Date", currentDate);

                const response = await api.job.getMyJobs(
                    value + 1,
                    currentDate.toString(),
                    currentPage
                );
                setJobs(response?.data || []);
                setTotalPages(response?.pagination?.total_pages || 0);
                setCurrentPage(response?.pagination?.current_page || 1);
            } catch (error) {
                console.error("Failed to fetch jobs:", error);
                setJobs([]);
            } finally {
                hasFetched.current = true;
            }
        };

        fetchJobs();
    }, [value]); // Re-fetch when tab value changes

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);
        setCurrentPage(1); // Reset to first page on tab change
        hasFetched.current = false; // Reset fetch flag on tab change
    };

    // Menu handlers
    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };
    return (
        <LayoutProvider pageTitle="Job List">
            <Grid2 container spacing={3}>
                <Grid2 size={{ md: 12, sm: 12, xs: 12 }} className={styles.gridBox}>
                    <CardContent className={styles.gridBoxwrap}>
                        <div className={styles.cardTitle}>
                            <Tabs value={value} className="jobTabList" onChange={handleChange} aria-label="job tabs">
                                <Tab label="Posted" {...jobTabProps(0)} />
                                <Tab label="Accepted" {...jobTabProps(1)} />
                                <Tab label="Completed" {...jobTabProps(2)} />
                                <Tab label="Past Jobs" {...jobTabProps(3)} />
                                <Tab label="Saved Jobs" {...jobTabProps(4)} />
                                <Tab label="Cancelled" {...jobTabProps(5)} />
                            </Tabs>
                        </div>
                        <JobTabPanel value={value} index={0}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                className={styles.menuList}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                        className={`${styles.menuItem} ${styles[option.toLowerCase().replace(' ', '')]}`}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                            {/* Pagination Section */}
                            {totalPages > 1 && (
                                <Box
                                    display="flex"
                                    justifyContent="center"
                                    mt={3}
                                    mb={2}
                                    className={styles.paginationContainer}
                                >
                                    <Pagination
                                        count={totalPages}
                                        page={currentPage}
                                        onChange={(_, page) => {
                                            setCurrentPage(page);
                                            hasFetched.current = false;
                                            window.scrollTo({ top: 0, behavior: 'smooth' });
                                        }}
                                        color="primary"
                                        showFirstButton
                                        showLastButton
                                        shape="rounded"
                                        siblingCount={1}
                                        boundaryCount={1}
                                    />
                                </Box>
                            )}
                        </JobTabPanel>

                        <JobTabPanel value={value} index={1}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                        </JobTabPanel>
                        <JobTabPanel value={value} index={2}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                        </JobTabPanel>
                        <JobTabPanel value={value} index={3}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                        </JobTabPanel>
                        <JobTabPanel value={value} index={4}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                        </JobTabPanel>
                        <JobTabPanel value={value} index={5}>
                            <TableContainer>
                                {jobs.length > 0 ? (
                                    <Table className={styles.table}>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Job ID</TableCell>
                                                <TableCell>Material</TableCell>
                                                <TableCell>Posted Date & Time</TableCell>
                                                <TableCell>Job Cost</TableCell>
                                                <TableCell>Pickup Date & Time</TableCell>
                                                <TableCell>Delivery Date & Time</TableCell>
                                                <TableCell>No. Of Trucks</TableCell>
                                                <TableCell></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {jobs.map((job) => (
                                                <TableRow key={job.id}>
                                                    {/* Table cell content remains same */}
                                                    <TableCell>{job?.unique_id}</TableCell>
                                                    <TableCell>{job?.material_name}</TableCell>
                                                    <TableCell>{moment(job?.created_at).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>${job.job_estimate_price}</TableCell>
                                                    <TableCell>{moment(job.pickup_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>{moment(job.delivery_date_time).format("D MMM YYYY | HH:mm")}</TableCell>
                                                    <TableCell>
                                                        <span className={`${styles.badge} ${styles.blueBg}`}>
                                                            {job.no_of_trucks}
                                                        </span>
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Menu component remains same */}
                                                        <div>
                                                            <IconButton
                                                                aria-label="more"
                                                                id="long-button"
                                                                aria-controls={open ? 'long-menu' : undefined}
                                                                aria-expanded={open ? 'true' : undefined}
                                                                aria-haspopup="true"
                                                                onClick={handleClick}
                                                            >
                                                                <MoreVertIcon />
                                                            </IconButton>
                                                            <Menu
                                                                id="long-menu"
                                                                anchorEl={anchorEl}
                                                                open={open}
                                                                onClose={handleClose}
                                                                slotProps={{
                                                                    paper: {
                                                                        style: {
                                                                            maxHeight: ITEM_HEIGHT * 4.5,
                                                                            width: '20ch',
                                                                        },
                                                                    },
                                                                    list: {
                                                                        'aria-labelledby': 'long-button',
                                                                    },
                                                                }}
                                                            >
                                                                {options.map((option) => (
                                                                    <MenuItem
                                                                        key={option}
                                                                        selected={option === 'view Job'}
                                                                        onClick={handleClose}
                                                                    >
                                                                        {option}
                                                                    </MenuItem>
                                                                ))}
                                                            </Menu>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                ) : (
                                    <div className={styles.noDataContainer}>
                                        <Typography variant="h6" color="textSecondary" align="center">
                                            <AssignmentLateIcon fontSize="large" />
                                            <br />
                                            No jobs found
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            There are currently no jobs matching your criteria
                                        </Typography>
                                    </div>
                                )}
                            </TableContainer>
                        </JobTabPanel>

                    </CardContent>
                </Grid2>
            </Grid2>

        </LayoutProvider>
    );
};

export default JobList;
