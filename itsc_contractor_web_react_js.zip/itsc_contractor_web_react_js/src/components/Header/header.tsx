import React, { useEffect, useRef, useState } from 'react';
import { AppBar, Toolbar, Typography, IconButton, Menu, MenuItem, Modal, TextField, Button, Box, InputAdornment } from '@mui/material';
import styles from '../../styles/header.module.css'
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext'; // Import the AuthContext
import Badge from '@mui/material/Badge';
import { MenuOutlined, ArrowBackOutlined, NotificationsOutlined, ShoppingCartOutlined, ExpandMoreOutlined, ExpandLessOutlined, Person2Outlined, KeyOutlined, LogoutOutlined } from '@mui/icons-material';
import { api } from '../../utils/api';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { ToastContainer, toast } from 'react-toastify';
import moment from 'moment';

interface HeaderProps {
    isOpen: boolean;
    toggleSidebar: () => void;
}
interface UpdatePasswordForm {
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
}

const Header: React.FC<HeaderProps> = ({ isOpen, toggleSidebar }) => {
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const [showNoti, setShowNoti] = React.useState(false);
    const [showAnnounce, setShowAnnounce] = React.useState(false);
    const [announcementList, setAnnouncementList] = React.useState<any>([]);
    const [imageUrl, setImageUrl] = React.useState<any>();
    const [notificationList, setNotificationList] = React.useState<any>([]);
    const [openChangePasswordModal, setOpenChangePasswordModal] = React.useState(false);
    const [showOldPassword, setShowOldPassword] = useState<boolean>(false);
    const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
    const [open, setOpen] = React.useState(false);
    const navigate = useNavigate();
    const { logout } = useAuth(); // Get the logout function from context

    const location = useLocation(); // Get the current location
    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const notificationRef = useRef<HTMLDivElement>(null);
    const announcementRef = useRef<HTMLDivElement>(null);

    // validation for change password modal
    const validationSchema = Yup.object().shape({
        oldPassword: Yup.string().required('Old password is required'),
        newPassword: Yup.string()
            .required('New Password is required')
            .min(8, 'New Password must be at least 8 characters')
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/,
                'New Password must include at least one uppercase letter, one lowercase letter, one number, and one special character'
            ),
        confirmPassword: Yup.string()
            .required('Confirm password is required')
            .oneOf([Yup.ref('newPassword')], 'Passwords must match'),
    });
    // Form setup with proper default values
    const { register, handleSubmit, control, formState: { errors } } = useForm<UpdatePasswordForm>({
        resolver: yupResolver(validationSchema),
        defaultValues: {
            oldPassword: '',
            newPassword: '',
            confirmPassword: '',
        }
    });
    const getTitle = () => {
        if (location.pathname.startsWith('/resultdetails/')) {
            return 'Result Details';
        }
        switch (location.pathname) {
            case '/dashboard':
                return 'Dashboard';
            case '/profile':
                return 'My Profile';
            case '/announcements':
                return 'Announcement Management';
            case '/users':
                return 'Users Management';
            case '/admin':
                return 'Admin Management';
            case '/member':
                return 'Member Management';
            case '/dogs':
                return 'Dogs Management';
            case '/cart':
                return 'Cart';
            case '/rewards':
                return 'Rewards Management';
            case '/wallet':
                return 'Wallet Management';
            case '/plateformcharges':
                return 'Platform Charge Management';
            case '/subscription':
                return 'Subscription Management';
            case '/race':
                return 'Race Management';
            case '/result':
                return 'Result Management';
            case '/notification':
                return 'Notification';
            case '/upcommingrace':
                return 'Upcomming Race Management';
            default:
                return ''; // Default title
        }
    };

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleProfileClick = () => {
        navigate('/profile');
    };
    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const response = await api.notifications.fetchNotifications();
                if (response) {
                    console.log("notifications ", response);

                    setNotificationList(response);
                }
            } catch (error) {
                console.error("Failed to fetch notifications:", error);
            }
        };

        fetchNotifications();
    }, []);

    const handleAnnouncementClick = async () => {
        setShowAnnounce(!showAnnounce)
        const response = await api.Announcement.fetchAnnouncements();
        setAnnouncementList(response)
    };
    const handleNotification = async () => {
        setShowNoti(!showNoti)
        let memberId = localStorage.getItem("memberId")
        if (memberId) {
            const notiresponse = await api.Announcement.fetchNotifications(memberId)
            // const notiresponse = await fetchNotifications(memberId)
            console.log({ notiresponse })
        }
    }
    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = async () => {
        await api.auth.logout();
        logout(); // Call the logout function
        navigate('/'); // Redirect to the login page after logout
        handleClose();
    };

    const handleCartClick = () => {
        navigate('/cart'); // Navigate to the /cart route
    };
    const handleAllNoti = () => {
        navigate('/notification');
    }
    const handleShowAnnouncement = () => {
        navigate('/announcements', { state: { announcementList } });
    }
    const handleClickOutside = (event: MouseEvent) => {
        if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
            setShowNoti(false)
        }
        if (announcementRef.current && !announcementRef.current.contains(event.target as Node)) {
            setShowAnnounce(false)
        }
    }
    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);
    useEffect(() => {
        let objectUrl: any;

        announcementList.map((list: any) => {
            console.log({ list })
            if (list.image instanceof File) {
                objectUrl = URL.createObjectURL(list?.image);
                setImageUrl(objectUrl);
            } else {
                setImageUrl(list?.image);
            }
        })

        return () => {
            if (objectUrl) {
                URL.revokeObjectURL(objectUrl);
            }
        };
    }, [announcementList]);
    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleModalClose = () => {
        setOpen(false);
    };
    // update password api call
    const onSubmit = async (data: UpdatePasswordForm) => {
        try {
            const payload = {
                old_password: data.oldPassword,
                new_password: data.newPassword,
                confirm_password: data.confirmPassword
            };
            // console.log("payload", payload);

            // Submit to API
            const response = await api.profile.changePassword(payload);
            if (response?.status) {
                toast.success('password changed successfully');
                handleModalClose();
            } else {
                toast.error(response?.message);
            }
        } catch (error) {
            console.error('Error updating password', error);
        }
    };
    return (
        <>
            <AppBar position="static" className={styles.navBar}>
                <Toolbar className={styles.header} sx={{ marginLeft: isOpen ? '251px' : '60px', transition: 'margin-left 0.3s' }}>
                    <IconButton onClick={toggleSidebar} className={styles.toggleButton}>
                        {isOpen ?
                            <ArrowBackOutlined style={{ width: '30px', height: '30px', color: '#283c50' }}></ArrowBackOutlined>
                            :
                            <MenuOutlined style={{ width: '30px', height: '30px', color: '#283c50' }}></MenuOutlined>
                        }
                    </IconButton>
                    {/* <Typography variant="h6" className={styles.title}>
                        {getTitle()}
                    </Typography> */}
                    <div className={styles.icons}>
                        {userRole === "MEMBER" && (
                            <IconButton color="inherit" onClick={handleCartClick}>
                                <Badge badgeContent={1} color="error">
                                    <ShoppingCartOutlined
                                        style={{ width: '30px', height: '30px', color: '#283c50' }}
                                    />
                                </Badge>
                            </IconButton>
                        )}
                        <div className={styles.iconBox}>
                            <IconButton color="inherit" onClick={handleNotification}>
                                <Badge badgeContent={notificationList.length > 0 ? notificationList.length : ''} color="error">
                                    <NotificationsOutlined style={{ width: '30px', height: '30px', color: '#666666' }}></NotificationsOutlined>
                                </Badge>
                            </IconButton>
                        </div>
                        <div className={styles.iconBox}>
                            <IconButton color="inherit" onClick={handleClick}>
                                <img src={`${userDetails.profileImage}`} alt="User " style={{ width: '35px', height: '35px' }} />
                                {
                                    Boolean(anchorEl) ?
                                        <ExpandLessOutlined sx={{ width: '20px', height: '20px', color: '#666666' }} />
                                        :
                                        <ExpandMoreOutlined sx={{ width: '20px', height: '20px', color: '#666666' }} />
                                }
                            </IconButton>
                        </div>
                    </div>
                    <Menu
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={handleClose}
                        className={styles.headerDropdownMenu}
                    >
                        <MenuItem className={`${styles.menuItem} ${styles.borderBottom}`} onClick={handleProfileClick}>
                            <img src={`${userDetails.profileImage}`} alt="User " style={{ width: '40px', height: '40px', paddingRight: '15px' }} />
                            <div>
                                <Typography className={styles.menuTitle}>{`${userDetails.firstName} ${userDetails.lastName}`}</Typography>
                                <Typography className={styles.menuSubTitle}>{userDetails.email}</Typography>
                            </div>
                        </MenuItem>
                        <MenuItem className={styles.menuItem} onClick={handleProfileClick}><Person2Outlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Profile Details</MenuItem>
                        <MenuItem className={`${styles.menuItem} ${styles.borderBottom}`} onClick={handleClickOpen} ><KeyOutlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Change Password</MenuItem>
                        <MenuItem className={styles.menuItem} onClick={handleLogout}><LogoutOutlined sx={{ width: '20px', height: '20px', color: '#666666', paddingRight: '15px' }} /> Logout</MenuItem>
                    </Menu>
                </Toolbar>
            </AppBar>

            {showNoti && (
                <div className={styles.notificationcontainer} ref={notificationRef}>
                    <h2 className={styles.notiheader}>Notifications</h2>

                    {notificationList.length > 0 ? (
                        <>
                            {notificationList.slice(0, 3).map((noti: any, index: number) => (
                                <div key={index} className={styles.notification}>
                                    <div className={styles.notificationicon}>
                                        <IconButton color="inherit">
                                            <img
                                                src="/assets/images/bell.png"
                                                alt="Notifications"
                                                style={{ width: '20px', height: '20px' }}
                                            />
                                        </IconButton>
                                    </div>
                                    <div className={styles.notificationtext}>
                                        <p>{noti.description}</p>
                                    </div>
                                </div>
                            ))}

                            {notificationList.length > 3 && (
                                <button className={styles.noti_btn} onClick={handleAllNoti}>
                                    View All Notifications
                                </button>
                            )}
                        </>
                    ) : (
                        <div className={styles.notificationEmpty}>
                            <p>No new notifications at the moment</p>
                        </div>
                    )}
                </div>
            )}
            <Dialog
                open={open}
                onClose={handleModalClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                    sx: { width: '500px', maxWidth: '90%' } // adjust the width as needed
                }}
            >
                <DialogTitle id="alert-dialog-title">
                    {"Change Password"}
                </DialogTitle>
                <DialogContent>
                    <form className="custom-Form" onSubmit={handleSubmit(onSubmit)}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="Old Password"
                                type={showOldPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.oldPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowOldPassword(!showOldPassword)} edge="end">
                                                {!showOldPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.oldPassword}
                                helperText={!!errors?.oldPassword}

                                {...register('oldPassword')}
                            />
                            <div className="invalid-feedback">{errors.oldPassword?.message?.toString()}</div>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="New Password"
                                type={showNewPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.newPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowNewPassword(!showNewPassword)} edge="end">
                                                {!showNewPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.newPassword}
                                helperText={!!errors?.newPassword}

                                {...register('newPassword')}
                            />
                            <div className="invalid-feedback">{errors.newPassword?.message?.toString()}</div>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
                            <TextField
                                label="Confirm Password"
                                type={showConfirmPassword ? 'text' : 'password'}
                                variant="outlined"
                                fullWidth
                                margin="normal"
                                className={`${styles.formControl} ${errors?.confirmPassword ? 'is-invalid' : ''}`}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={() => setShowConfirmPassword(!showConfirmPassword)} edge="end">
                                                {!showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                error={!!errors?.confirmPassword}
                                helperText={!!errors?.confirmPassword}

                                {...register('confirmPassword')}
                            />
                            <div className="invalid-feedback">{errors.confirmPassword?.message?.toString()}</div>
                        </Box>
                        <div className={styles.formButtonWrap}>
                            <Button onClick={handleModalClose}>Cancel</Button>
                            <Button
                                type='submit'
                                variant="contained"
                                color="primary"
                                className={styles.formButton}
                            >
                                Update
                            </Button>
                        </div>
                    </form>
                </DialogContent>
            </Dialog >
        </>
    );
};

export default Header;