import React, { useState } from 'react';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import { Box, Typography } from '@mui/material';
import styles from '../../styles/dashboard.module.css';

const Confirm: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box
                sx={{
                    marginLeft: isSidebarOpen ? '250px' : '60px',
                    transition: 'margin-left 0.3s',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: '89vh',
                    backgroundColor: '#f5f5f5'
                }}
            >
                <Typography variant="h5" color="success.main" align="center" gutterBottom>
                    Payment Successful
                </Typography>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                    <img src='/assets/images/success.png' alt="Success" />
                </div>
                <Typography variant="h5" color="success.main" align="center" gutterBottom>
                    Your payment is done
                </Typography>
            </Box>
        </Box>
    );
};

export default Confirm;
