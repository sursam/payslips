import React, { useState } from 'react';
import { usePlacesWidget } from "react-google-autocomplete";
import { GOOGLE_MAPS_API_KEY } from "../../config/config";
import { TextField, InputAdornment, IconButton } from '@mui/material';
import MyLocation from '@mui/icons-material/MyLocation';

interface ChildProps {
    name: string;
    className: string;
    setLocationData: any;
    value: string;
}

const LocationInput: React.FC<ChildProps> = ({ name, className, setLocationData, value }) => {
    const [locationVal, setLocationVal] = useState<string>(value);
    const { ref } = usePlacesWidget(
        {
            apiKey: GOOGLE_MAPS_API_KEY,
            onPlaceSelected: (place: any) => {
                // console.log(place.geometry.location.lat());
                setLocationVal(place.formatted_address);
                let locationData = {
                    latitude: place.geometry.location.lat(),
                    longitude: place.geometry.location.lng(),
                    address: place.formatted_address
                };
                setLocationData(name, locationData);
            },
            //   options: options,
        }
    );
    const fetchCurrentLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;

                    // use the latitude and longitude to get the user's address
                    fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`)
                        .then(response => response.json())
                        .then(data => {
                            setLocationVal(data.results[0].formatted_address);
                            let locationData = {
                                latitude: position.coords.latitude,
                                longitude: position.coords.longitude,
                                address: data.results[0].formatted_address
                            };
                            setLocationData(name, locationData);
                        });
                },
                (err) => {
                    console.log(err.message);
                }
            );
        } else {
            console.log("Geolocation is not supported by this browser.");
        }
    }
    return (
        <TextField
            label="Location"
            variant="outlined"
            fullWidth
            margin="normal"
            inputRef={ref} // Attach the Google places autocomplete hook
            className={className}
            value={locationVal}
            onChange={(e) => setLocationVal(e.target.value)}
            InputProps={{
                endAdornment: (
                    <InputAdornment position="end">
                        <IconButton onClick={fetchCurrentLocation} edge="end">
                            <MyLocation />
                        </IconButton>
                    </InputAdornment>
                ),
            }}
        />
    );
};

export default LocationInput;
