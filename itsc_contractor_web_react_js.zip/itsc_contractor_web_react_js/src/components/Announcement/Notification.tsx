import React, { useEffect, useState } from 'react';
import { Box, IconButton } from '@mui/material';
import styles from '../../styles/dashboard.module.css';
import notistyles from '../../styles/header.module.css';
import LayoutProvider from '../../providers/LayoutProvider';

const Notification = () => {
	return (
		<LayoutProvider pageTitle="Notifications">
			<Box className={styles.container}>
				<Box className={styles.notifiWrap}>
					<Box >
						<div >
							<h2 className={notistyles.notiheader}>All Notifications</h2>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

							<div className={notistyles.notification}>
								<div className={notistyles.notificationicon_grey}>
									<IconButton color="inherit">
										<img src="/assets/images/grey_bell.png" alt="Notifications" style={{ width: '20px', height: '20px' }} />
									</IconButton>
								</div>
								<div className={notistyles.notificationtext}>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
								</div>
							</div>

						</div>
					</Box>
				</Box>
			</Box>
		</LayoutProvider>
	)
}

export default Notification
