import React, { useState, useEffect } from 'react';
import {
	Box,
	Button,
	Typography,
	Modal,
	Dialog,
	DialogTitle,
	DialogContent,
	DialogContentText,
	DialogActions,
	TextField,
	Link as MuiLink,
	TableContainer,
	Table,
	TableHead,
	TableRow,
	TableCell,
	TableBody,
	TablePagination,
	Chip,
	Card,
	CardActions,
	CardContent,
	CardMedia,
	IconButton,
	Pagination,
	Stack
} from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/Edit';
import LanguageIcon from '@mui/icons-material/Language';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import { toast } from 'react-toastify';
import Sidebar from '../Sidebar/sidebar';
import Header from '../Header/header';

import { api } from '../../utils/api';
import { AnnouncementType } from '../../types';
import { Link } from 'react-router-dom';
import EventIcon from '@mui/icons-material/Event';
import SubjectIcon from '@mui/icons-material/Topic';
import DescriptionIcon from '@mui/icons-material/Description';
import LinkIcon from '@mui/icons-material/Link';
import styles from '../../styles/announcement.module.css';

const AnnouncementList: React.FC = () => {
	const [isSidebarOpen, setSidebarOpen] = useState(true);
	const [openModal, setOpenModal] = useState(false);
	const [openViewModal, setOpenViewtModal] = useState(false);
	const [openEditModal, setOpenEditModal] = useState(false);
	const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
	const [selectedAnnouncementId, setSelectedAnnouncementId] = useState<string | null>(null);
	const [announcementData, setAnnouncementData] = useState<AnnouncementType>({
		subject: '',
		date: '',
		description: '',
		link: undefined as '' | undefined,
		image: undefined as File | undefined,
	});
	const [announcementList, setAnnouncementList] = useState<any>([])
	const [formErrors, setFormErrors] = useState<{ subject?: string; date?: string; description?: string; link?: string }>({});
	const [searchQuery, setSearchQuery] = useState('');
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [imageUrl, setImageUrl] = useState<any>("")

	const role = localStorage.getItem("role")

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	const getAnnouncement = async () => {
		const response = await api.Announcement.fetchAnnouncements();
		if (response) {
			setAnnouncementList(response)
		}
		return response
	}
	useEffect(() => {
		getAnnouncement()
	}, []);

	const handleOpenModal = () => {
		setOpenModal(true);
		setAnnouncementData({ subject: '', date: '', description: '', link: '', image: undefined });
		setSelectedAnnouncementId(null);
		setFormErrors({});
	};

	const handleCloseModal = () => {
		setOpenModal(false);
		setAnnouncementData({ subject: '', date: '', description: '', link: '', image: undefined });
		setSelectedAnnouncementId(null);
		setFormErrors({});
	};
	const handleOpenViewModal = (announcement: any) => {
		setAnnouncementData({
			subject: announcement.subject || '',
			date: announcement.date || '',
			description: announcement.description || '',
			link: announcement.link || '',
			image: announcement.image[0],
		});
		setOpenViewtModal(true)
	}

	const handleViewClose = () => {
		setOpenViewtModal(false)
	}
	const handleOpenEditModal = (announcement: any) => {
		setAnnouncementData({
			subject: announcement.subject || '',
			date: announcement.date ? announcement.date.split("T")[0] : '',
			description: announcement.description || '',
			link: announcement.link || '',
			image: undefined,
		});
		setSelectedAnnouncementId(announcement._id || null);
		setOpenEditModal(true);
		setFormErrors({});
	};

	const handleCloseEditModal = () => {
		setOpenEditModal(false);
		setAnnouncementData({ subject: '', date: '', description: '', link: '', image: undefined });
		setSelectedAnnouncementId(null);
		setFormErrors({});
	};

	// Validation helper function with error messages for fields
	const validateFormData = (data: AnnouncementType) => {
		const errors: { subject?: string; date?: string; description?: string; link?: string; image?: string } = {};
		let isValid = true;

		if (!data.subject.trim()) {
			errors.subject = 'Subject is required';
			isValid = false;
		}

		if (!data.date) {
			errors.date = 'Date is required';
			isValid = false;
		}

		if (!data?.link?.trim()) {
			errors.link = 'Link is required';
			isValid = false;
		}

		if (!data.description.trim()) {
			errors.description = 'Description is required';
			isValid = false;
		}

		setFormErrors(errors);
		return isValid;
	};

	const handleSaveAnnouncement = async () => {
		if (!validateFormData(announcementData)) {
			return; // validation failed, do not proceed
		}

		const payload: AnnouncementType = {
			subject: announcementData.subject.trim(),
			description: announcementData.description.trim(),
			link: announcementData?.link?.trim(),
			image: announcementData?.image,
			date: announcementData?.date
		};

		try {
			await api.Announcement.addAnnouncement(payload);
			// await addAnnouncement(payload);
			toast.success("Announcement added successfully!");
			handleCloseModal(); // Close modal only on success
			getAnnouncement();
		} catch (error) {
			// TypeScript safe check
			const err = error as any;
			if (err?.response?.err?.details) {
				err.response.err.details.forEach((detail: any) => {
					toast.error(detail.message);
				});
			} else {
				toast.error("Error adding announcement.");
			}
			console.error("Error:", error);
		}
	};

	const handleSaveEditAnnouncement = async () => {
		if (!selectedAnnouncementId) {
			toast.error("No announcement selected to edit.");
			return;
		}

		if (!validateFormData(announcementData)) {
			return; // validation failed, do not proceed
		}

		const payload = {
			subject: announcementData.subject.trim(),
			description: announcementData.description.trim(),
			link: announcementData?.link?.trim(),
			date: announcementData?.date
		};

		try {
			await api.Announcement.editAnnouncement(selectedAnnouncementId, payload);
			// await editAnnouncement(selectedAnnouncementId, payload);
			toast.success("Announcement updated successfully!");
			handleCloseEditModal(); // Close modal only on success
			getAnnouncement()
		} catch (error) {
			const err = error as any;
			if (err?.response?.err?.details) {
				err.response.err.details.forEach((detail: any) => {
					toast.error(detail.message); // Show each error message in a toast
				});
			} else {
				toast.error("Error updating announcement.");
			}
			console.error("Error:", error);
		}
	};

	const handleOpenDeleteDialog = (id: string) => {
		setSelectedAnnouncementId(id);
		setOpenDeleteDialog(true);
		getAnnouncement();
	};

	const handleCloseDeleteDialog = () => {
		setOpenDeleteDialog(false);
		setSelectedAnnouncementId(null);
	};

	const handleDeleteAnnouncement = async () => {
		if (selectedAnnouncementId) {
			try {
				await api.Announcement.deleteAnnouncement(selectedAnnouncementId);
				// await deleteAnnouncement(selectedAnnouncementId);
				toast.success("Announcement deleted successfully!");
				handleCloseDeleteDialog();
			} catch (error) {
				toast.error("Error deleting announcement.");
				console.error("Error:", error);
			}
		}
	};

	const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		if (event.target.files && event.target.files.length > 0) {
			setAnnouncementData(prev => ({ ...prev, image: event.target.files![0] }));
		}
	};

	const handleChangePage = (event: unknown, newPage: number) => {
		setPage(newPage - 1); // Convert to 0-based index
	};

	const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
		setRowsPerPage(parseInt(event.target.value, 10));
		setPage(0);
	};

	const filteredAnnouncements = announcementList.filter((announcement: AnnouncementType) =>
		announcement?.subject?.toLowerCase().includes(searchQuery.toLowerCase())
	);
	useEffect(() => {
		let objectUrl: any;
		if (announcementData.image instanceof File) {
			objectUrl = URL.createObjectURL(announcementData?.image);
			setImageUrl(objectUrl);
		} else {
			setImageUrl(announcementData?.image);
		}
		return () => {
			if (objectUrl) {
				URL.revokeObjectURL(objectUrl);
			}
		};
	}, [announcementData.image]);

	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Announcement List</h3>
					<div className={styles.headerRtSide}>
						<TextField
							variant="outlined"
							placeholder="Search Announcement"
							size="small"
							sx={{ marginRight: 2 }}
							value={searchQuery}
							onChange={(e) => setSearchQuery(e.target.value)}
						/>
						{role !== "MEMBER" &&
							<Button variant="contained" onClick={handleOpenModal}>
								Add Announcement
							</Button>
						}

					</div>
				</div>

				<div className={styles.customtable}>
					{filteredAnnouncements.length === 0 ? (
						<Typography variant="h6" color="textSecondary" align="center" sx={{ marginTop: 2 }}>
							No Announcements Found
						</Typography>
					) : (
						<TableContainer className={styles.tableContainer}>
							<Table className={`${styles.table} table`}>
								<TableHead>
									<TableRow>
										<TableCell>Subject</TableCell>
										<TableCell>Date</TableCell>
										<TableCell>Description</TableCell>
										<TableCell>Link</TableCell>
										<TableCell style={{ textAlign: 'center' }}>Actions</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{filteredAnnouncements?.
										slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).
										map((announcement: AnnouncementType) => (
											<TableRow key={announcement._id}>
												<TableCell>{announcement.subject}</TableCell>
												<TableCell>{announcement?.date ? announcement.date.split("T")[0] : "N/A"}</TableCell>
												<TableCell style={{ whiteSpace: 'pre-wrap' }}>{announcement.description}</TableCell>
												<TableCell>
													{announcement.link ? (
														<MuiLink href={announcement.link} target="_blank" rel="noopener">
															{announcement.link}
														</MuiLink>
													) : (
														'-'
													)}
												</TableCell>

												<TableCell style={{ textAlign: 'center' }}>
													<div style={{ display: 'flex', gap: '8px' }}>
														<Button
															className={styles.roundBtn}
															variant="outlined"
															sx={{ color: 'blue', borderColor: 'blue' }} onClick={() => handleOpenViewModal(announcement)}
														>
															<VisibilityIcon />
														</Button>
														{role !== 'MEMBER' && (
															<>
																<Button
																	className={styles.roundBtn}
																	variant="outlined"
																	color="primary"
																	onClick={() => handleOpenEditModal(announcement)}
																>
																	<EditIcon />
																</Button>
																<Button
																	variant="outlined"
																	className={styles.roundBtn}
																	sx={{ color: 'red', borderColor: 'red' }}
																	onClick={() => handleOpenDeleteDialog(announcement._id!)}
																>
																	<DeleteIcon />
																</Button>
															</>
														)}
													</div>
												</TableCell>
											</TableRow>
										))}
								</TableBody>
							</Table>
						</TableContainer>
					)}
					{filteredAnnouncements.length > 0 && (
						<Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
							<Pagination
								count={Math.ceil(filteredAnnouncements.length / rowsPerPage)} // Calculate total pages
								page={page + 1} // MUI Pagination is 1-based
								onChange={handleChangePage}
								color="primary"
							/>
						</Stack>
					)}
				</div>

				{/* Add Announcement Modal */}
				<Modal open={openModal} onClose={handleCloseModal}>
					<Box
						sx={{
							position: 'absolute',
							top: '50%',
							right: '0px',
							transform: 'translateY(-50%)',
							padding: 3,
							backgroundColor: 'white',
							borderRadius: 2,
							width: '400px',
							height: '100vh',
							overflowY: 'auto',
						}}
					>
						<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
							<Typography variant="h5" mb={2}>Add Announcement</Typography>
							<IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
								<CloseIcon />
							</IconButton>
						</Box>

						<TextField
							fullWidth
							label="Subject"
							value={announcementData.subject}
							onChange={e => setAnnouncementData(prev => ({ ...prev, subject: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.subject)}
							helperText={formErrors.subject}
						/>

						<TextField
							fullWidth
							type="date"
							value={announcementData.date}
							onChange={e => setAnnouncementData(prev => ({ ...prev, date: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.date)}
							helperText={formErrors.date}
						/>

						<TextField
							fullWidth
							label="Link"
							value={announcementData.link}
							onChange={e => setAnnouncementData(prev => ({ ...prev, link: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.link)}
							helperText={formErrors.link}
						/>

						<TextField
							fullWidth
							multiline
							rows={6}
							label="Description"
							value={announcementData.description}
							onChange={e => setAnnouncementData(prev => ({ ...prev, description: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.description)}
							helperText={formErrors.description}
						/>

						<Box sx={{ mb: 2 }}>
							<input
								accept="image/*"
								id="upload-image-file"
								type="file"
								style={{ display: 'none' }}
								onChange={handleImageChange}
							/>
							<label htmlFor="upload-image-file">
								<Button
									variant="outlined"
									component="span"
									startIcon={<UploadFileIcon />}
								>
									Upload Image
								</Button>
							</label>
							{announcementData.image && (
								<Chip
									label={announcementData.image.name}
									onDelete={() => setAnnouncementData(prev => ({ ...prev, image: undefined }))}
									color="primary"
									variant="outlined"
									sx={{ ml: 2, height: 32 }}
									deleteIcon={<CloseIcon />}
								/>
							)}
						</Box>

						<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
							<Button onClick={handleCloseModal} sx={{ mr: 1 }}>Cancel</Button>
							<Button variant="contained" onClick={handleSaveAnnouncement}>Save</Button>
						</Box>
					</Box>
				</Modal>

				{/* View Announcement Modal */}

				<Modal
					open={openViewModal}
					onClose={handleViewClose}
					aria-labelledby="modal-modal-title"
					aria-describedby="modal-modal-description"
				>
					<Box sx={{
						position: 'absolute',
						top: '50%',
						left: '50%',
						right: '50%',
						transform: 'translate(-50%, -50%)',
						width: 500,
						bgcolor: 'background.paper',
						boxShadow: 24,
						p: 2,
						borderRadius: 2,
					}}>

						<Card sx={{ maxWidth: 500, boxShadow: 5, borderRadius: 2 }}>
							<CardMedia
								sx={{ height: 180, objectFit: "cover", borderRadius: '4px 4px 0 0' }}
								image={imageUrl ? imageUrl : "/assets/images/announcement-banner.jpg"}
								title="Announcement Image"
							/>
							<CardContent sx={{ p: 3 }}>
								<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
									<SubjectIcon color="primary" />
									<Typography variant="h6" fontWeight="bold">{announcementData.subject}</Typography>
								</Box>
								<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 2 }}>
									<EventIcon color="secondary" />
									<Typography variant="body2" color="text.secondary">
										<strong>Date:</strong> {announcementData.date ? new Date(announcementData.date).toISOString().split('T')[0] : 'N/A'}
									</Typography>
								</Box>
								{announcementData.link && (
									<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 2 }}>
										<LinkIcon color="primary" />
										<Link to={announcementData.link} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none', fontWeight: 'bold' }}>
											{announcementData.link}
										</Link>
									</Box>
								)}
								<Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 2 }}>
									<DescriptionIcon color="success" />
									<Typography variant="body2">{announcementData.description}</Typography>
								</Box>
							</CardContent>
						</Card>

					</Box>
				</Modal>

				{/* Edit Announcement Modal */}
				<Modal className={'css-1acyv19'} open={openEditModal} onClose={handleCloseEditModal}>
					<Box
						sx={{
							position: 'absolute',
							top: '50%',
							right: '0px',
							transform: 'translateY(-50%)',
							padding: 3,
							backgroundColor: 'white',
							borderRadius: 2,
							width: '400px',
							height: '100vh',
							overflowY: 'auto',
						}}
					>
						<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
							<Typography variant="h5" mb={2}>Edit Announcement</Typography>
							<IconButton onClick={handleCloseEditModal} sx={{ color: 'gray' }}>
								<CloseIcon />
							</IconButton>
						</Box>

						<TextField
							fullWidth
							label="Subject"
							value={announcementData.subject}
							onChange={e => setAnnouncementData(prev => ({ ...prev, subject: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.subject)}
							helperText={formErrors.subject}
						/>

						<TextField
							fullWidth
							type="date"
							value={announcementData.date} // This should now be in 'YYYY-MM-DD' format
							onChange={e => setAnnouncementData(prev => ({ ...prev, date: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.date)}
							helperText={formErrors.date}
						/>


						<TextField
							fullWidth
							label="Link"
							value={announcementData.link}
							onChange={e => setAnnouncementData(prev => ({ ...prev, link: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.link)}
							helperText={formErrors.link}
						/>

						<TextField
							fullWidth
							multiline
							rows={6}
							label="Description"
							value={announcementData.description}
							onChange={e => setAnnouncementData(prev => ({ ...prev, description: e.target.value }))}
							sx={{ mb: 2 }}
							required
							error={Boolean(formErrors.description)}
							helperText={formErrors.description}
						/>

						<Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
							<Button onClick={handleCloseEditModal} sx={{ mr: 1 }}>Cancel</Button>
							<Button variant="contained" onClick={handleSaveEditAnnouncement}>Save</Button>
						</Box>
					</Box>
				</Modal>

				{/* Delete Confirmation Dialog */}
				<Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
					<DialogTitle>Confirm Delete</DialogTitle>
					<DialogContent>
						<DialogContentText>Are you sure you want to delete this announcement?</DialogContentText>
					</DialogContent>
					<DialogActions>
						<Button onClick={handleCloseDeleteDialog} color="primary">Cancel</Button>
						<Button onClick={handleDeleteAnnouncement} color="secondary">Delete</Button>
					</DialogActions>
				</Dialog>
			</Box>
		</Box>
	);
};

export default AnnouncementList;

