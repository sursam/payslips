import React, { useState, useEffect } from 'react';
import { Box, TextField, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination, Button, Modal, FormControl, InputLabel, Select, MenuItem, IconButton, Card, CardContent, Typography, Divider, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import styles from '../../styles/raceresult.module.css';
import { useGrievance } from '../../context/GrievanceContext';
import { useNavigate } from 'react-router-dom';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import { toast } from 'react-toastify';

const GrievanceList: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [openModal, setOpenModal] = useState(false);
    const [openModal1, setOpenModal1] = useState(false);
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [selectedGrievanceId, setSelectedGrievanceId] = useState<string | null>(null);
    const [grievanceData, setGrievanceData] = useState({
        description: '',
    });
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [replyGrievanceId, setReplyGrievanceId] = useState<string | null>(null);

    const navigate = useNavigate();
    const { fetchGrievances, addGrievance, grievances, replyToGrievance, deleteGrievance } = useGrievance(); // Assuming you have a context for grievances

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    useEffect(() => {
        fetchGrievances();
    }, [fetchGrievances]);

    const handlePageChange = (event: unknown, newPage: number) => {
        setPage(newPage);
    };

    const handleOpenReplyModal = (grievanceId: string, replyMessage: string, replyId?: string) => {
        console.log(grievanceId, replyMessage, replyId)
        setReplyGrievanceId(grievanceId); // Use replyId if available, otherwise use grievanceId
        setGrievanceData({ description: replyMessage }); // Prefill the form with the existing reply
        setOpenModal1(true); // Open the reply modal
    };


    const handleCloseReplyModal = () => {
        setOpenModal1(false);
    };

    const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleOpenModal = () => {
        setOpenModal(true);
        setGrievanceData({
            description: '',
        });
    };

    const handleCloseModal = () => {
        setOpenModal(false);
    };

    const handleSaveReply = async () => {
        if (replyGrievanceId) {
            const payload = {
                message: grievanceData.description,
            };

            try {
                await replyToGrievance(replyGrievanceId, payload);
                toast.success("Reply added successfully!");
                handleCloseReplyModal();
            } catch (error) {
                toast.error("Error adding reply.");
                console.error("Error:", error);
            }
        }
    };

    const handleSaveGrievance = async () => {
        const payload = {
            // complaintType: grievanceData.complaintType,
            description: grievanceData.description,
        };

        try {
            await addGrievance(payload);
            toast.success("Grievance added successfully!");
            handleCloseModal();
        } catch (error) {
            toast.error("Error adding grievance.");
            console.error("Error:", error);
        }
    };

    const handleOpenDeleteDialog = (id: string) => {
        setSelectedGrievanceId(id);
        setOpenDeleteDialog(true);
    };

    const handleCloseDeleteDialog = () => {
        setOpenDeleteDialog(false);
        setSelectedGrievanceId(null);
    };

    const handleDeleteGrievance = async () => {
        if (selectedGrievanceId) {
            try {
                await deleteGrievance(selectedGrievanceId);
                toast.success("Grievance deleted successfully!");
                handleCloseDeleteDialog();
            } catch (error) {
                toast.error("Error deleting grievance.");
                console.error("Error:", error);
            }
        }
    };


    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                <div className={styles.topsection}>
                    <h3>Grievance List</h3>
                    {userRole === 'MEMBER' && (
                        <Button variant="contained" onClick={handleOpenModal}>
                            Add Grievance
                        </Button>
                    )}
                </div>

                <div className={styles.customtable}>
                    {grievances.length === 0 ? (
                        <Typography variant="h6" color="textSecondary" align="center" sx={{ marginTop: 2 }}>
                            No Data Found
                        </Typography>
                    ) : (
                        grievances.map((grievance) => (
                            <Card
                                key={grievance._id || Math.random().toString()} // Use a fallback key if _id is undefined
                                sx={{
                                    mb: 2,
                                    p: 0,
                                    width: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    wordBreak: 'break-word',
                                }}
                            >
                                <Box className={styles.reqNoWrap} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <Typography className={styles.reqNoTtl} variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                                        Req. No: #{grievance._id || 'N/A'} {/* Show 'N/A' if _id is undefined */}
                                        {/* Delete Button added here */}
                                        {userRole !== 'MEMBER' && (
                                            <IconButton
                                                size="small"
                                                color="primary"
                                                onClick={() => {
                                                    if (typeof grievance._id === 'string') {
                                                        handleOpenDeleteDialog(grievance._id);
                                                    }
                                                }} sx={{
                                                    marginLeft: '10px',
                                                    backgroundColor: '#e0f7fa', // Set the background color
                                                    borderRadius: '50%', // Make it circular
                                                    padding: '8px', // Ensure proper spacing inside the circle
                                                    '&:hover': {
                                                        backgroundColor: '#b2ebf2', // Change background color on hover
                                                    },
                                                }}
                                            >
                                                <DeleteIcon />
                                            </IconButton>
                                        )}
                                    </Typography>

                                    <Typography variant="subtitle2" color="textSecondary">
                                        {grievance.createdAt
                                            ? new Date(grievance.createdAt).toLocaleDateString('en-GB', {
                                                day: '2-digit',
                                                month: 'short',
                                                year: 'numeric',
                                            }) +
                                            ' | ' +
                                            new Date(grievance.createdAt).toLocaleTimeString('en-GB', {
                                                hour: '2-digit',
                                                minute: '2-digit',
                                                hour12: false,
                                            })
                                            : 'N/A'}
                                    </Typography>
                                </Box>

                                <Box
                                    sx={{
                                        mt: 1,
                                        p: 2,
                                        bgcolor: '#f9f9f9',
                                        borderRadius: '8px',
                                        overflow: 'hidden',
                                        wordBreak: 'break-word',
                                        whiteSpace: 'pre-wrap',
                                    }}
                                >
                                    <Typography variant="body2" dangerouslySetInnerHTML={{ __html: grievance.description }} />
                                </Box>

                                <Divider sx={{ my: 2, borderStyle: 'dotted' }} />

                                {grievance.reply && grievance.reply.length > 0 ? (
                                    <Box
                                        sx={{
                                            mt: 1,
                                            p: 2,
                                            bgcolor: '#f9f9f9',
                                            borderRadius: '8px',
                                            overflow: 'hidden',
                                            wordBreak: 'break-word',
                                            whiteSpace: 'pre-wrap',
                                        }}
                                    >
                                        {grievance.reply.map((reply) => (
                                            <Box key={reply._id} sx={{ mb: 1 }}>
                                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                    <img
                                                        src={'/assets/images/reply_img.png'}
                                                        alt="Reply User"
                                                        style={{
                                                            width: '24px',
                                                            height: '24px',
                                                            borderRadius: '50%',
                                                            marginRight: '5px',
                                                        }}
                                                    />
                                                    <Typography variant="body2" color="#1976d2" sx={{ marginRight: '10px' }}>
                                                        Reply From {reply.repliedBy.role}
                                                    </Typography>
                                                    {/* Edit Button added here */}
                                                    {/* {userRole !== 'MEMBER' && (
                                                        <IconButton
                                                            size="small"
                                                            color="primary"
                                                            onClick={() =>
                                                                grievance._id && handleOpenReplyModal(grievance._id, reply.message, reply._id)
                                                            }
                                                            sx={{
                                                                backgroundColor: '#e0f7fa', // Set the background color
                                                                borderRadius: '50%', // Make it circular
                                                                padding: '8px', // Ensure proper spacing inside the circle
                                                                '&:hover': {
                                                                    backgroundColor: '#b2ebf2', // Change background color on hover
                                                                },
                                                            }}
                                                        >
                                                            <EditIcon />
                                                        </IconButton>
                                                    )} */}
                                                </Box>
                                                <Typography
                                                    variant="body2"
                                                    color="textSecondary"
                                                    dangerouslySetInnerHTML={{ __html: reply.message }}
                                                ></Typography>
                                                <Typography variant="caption" color="textSecondary">
                                                    {reply.repliedBy.replyTime
                                                        ? new Date(reply.repliedBy.replyTime).toLocaleDateString('en-GB', {
                                                            day: '2-digit',
                                                            month: 'short',
                                                            year: 'numeric',
                                                        }) +
                                                        ' | ' +
                                                        new Date(reply.repliedBy.replyTime).toLocaleTimeString('en-GB', {
                                                            hour: '2-digit',
                                                            minute: '2-digit',
                                                            hour12: false,
                                                        })
                                                        : 'No reply time'}
                                                </Typography>
                                            </Box>
                                        ))}
                                    </Box>
                                ) : (
                                    userRole !== 'MEMBER' && grievance._id && (
                                        <Box sx={{ p: 2, display: 'flex', justifyContent: 'flex-end' }}>
                                            <Button variant="contained" onClick={() => grievance._id && handleOpenReplyModal(grievance._id, '', '')}>
                                                Reply
                                            </Button>
                                        </Box>
                                    )
                                )}

                            </Card>
                        ))
                    )}
                </div>



                <Modal open={openModal} onClose={handleCloseModal}>
                    <Box className={styles.modalBox}
                        sx={{
                            position: 'absolute',
                            top: '50%',
                            right: '0px',
                            transform: 'translateY(-50%)',
                            padding: 2,
                            backgroundColor: 'white',
                            borderRadius: 2,
                            height: '100%'
                        }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h2>Add Grievance</h2>
                            <IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                        <Box sx={{ minHeight: '65%', maxHeight: '90%', border: '1px solid #ccc', padding: '8px' }}>
                            <CKEditor
                                editor={ClassicEditor as any}
                                data={grievanceData.description}
                                onChange={(event: any, editor: any) => {
                                    const data = (editor as any).getData();
                                    setGrievanceData((prev) => ({ ...prev, description: data }));
                                }}
                            // onReady={(editor) => {
                            //     editor.ui.view.editable.element.style.minHeight = '60%';
                            //     editor.ui.view.editable.element.style.maxHeight = '100%';
                            //     editor.ui.view.editable.element.style.overflowY = 'auto';
                            // }}
                            />
                        </Box>
                        <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
                            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>Close</Button>
                            <Button variant="contained" onClick={handleSaveGrievance}>Save</Button>
                        </Box>
                    </Box>
                </Modal>

                <Modal open={openModal1} onClose={handleCloseReplyModal}>
                    <Box className={styles.modalBox}
                        sx={{
                            position: 'absolute',
                            top: '50%',
                            right: '0px',
                            transform: 'translateY(-50%)',
                            padding: 2,
                            backgroundColor: 'white',
                            borderRadius: 2,
                            height: '100%'
                        }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h2>Grievance Reply</h2>
                            <IconButton onClick={handleCloseReplyModal} sx={{ color: 'gray' }}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                        <Box sx={{ minHeight: '65%', maxHeight: '90%', border: '1px solid #ccc', padding: '8px' }}>
                            <CKEditor
                                editor={ClassicEditor as any}
                                data={grievanceData.description} // Ensure this is set correctly
                                onChange={(event: any, editor: any) => {
                                    const data = (editor as any).getData();
                                    setGrievanceData((prev) => ({ ...prev, description: data }));
                                }}
                            // onReady={(editor) => {
                            //     editor.ui.view.editable.element.style.minHeight = '60%';
                            //     editor.ui.view.editable.element.style.maxHeight = '100%';
                            //     editor.ui.view.editable.element.style.overflowY = 'auto';
                            // }}
                            />
                        </Box>
                        <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
                            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseReplyModal}>Close</Button>
                            <Button variant="contained" onClick={handleSaveReply}>Save</Button>
                        </Box>
                    </Box>
                </Modal>

                {/* Delete Confirmation Dialog */}
                <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
                    <DialogTitle>Confirm Delete</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Are you sure you want to delete this grievance?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseDeleteDialog} color="primary">Cancel</Button>
                        <Button onClick={handleDeleteGrievance} color="secondary">Delete</Button>
                    </DialogActions>
                </Dialog>
            </Box>
        </Box>
    );
};

export default GrievanceList;