import React, { useEffect, useState } from 'react';
import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import styles from '../../styles/dogList.module.css';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';

const RaceDetails: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [selectedRound, setSelectedRound] = useState<number>(1); // State to track the selected race round
    const { id } = useParams<{ id: string }>(); // get race id from URL param
    const [race, setRace] = useState<Race | null>(null); // State to hold the fetched race details
    interface Dog {
        dog_name: string;
    }

    interface Winner {
        _id: string;
        position: number;
        dog_object_id: Dog | null; // Dog can be null
        box_number: number;
        race_completion_time: string;
        rug_number: number; // Add rug_number to the Winner interface
        mgn: number; // Add mgn to the Winner interface
        split: number; // Add split to the Winner interface
        in_run: number; // Add in_run to the Winner interface
        weight: number; // Add weight to the Winner interface
        dog_price: number; // Add dog_price to the Winner interface
    }

    interface Round {
        _id: string;
        race_round_no: number;
        winners: Winner[];
    }

    interface Race {
        _id: string; // Add the missing _id property
        race_date: string;
        race_object_id: {
            race_name: string;
            country: string;
        };
        round: Round[];
    }

    const navigate = useNavigate();

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    useEffect(() => {
        const fetchRaceDetails = async () => {
            try {
                if (!id) {
                    console.error("Race ID is undefined.");
                    return;
                }
                const response = await api.result.fetchResultById(id); // Fetch the race details by ID
                if (response && response.result) {
                    setRace(response.result); // Set the race details directly from the result
                } else {
                    console.warn("Invalid response format:", response);
                }
            } catch (error) {
                console.error("Error fetching race details:", error);
            }
        };

        fetchRaceDetails();
    }, [id]);

    if (!race) {
        return (
            <Box className={styles.container}>
                <Sidebar isOpen={isSidebarOpen} />
                <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
                <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                    <Typography variant="h5" sx={{ mt: 4 }}>
                        Result not found...
                    </Typography>
                </Box>
            </Box>
        );
    }

    const formattedRaceDate = new Date(race.race_date).toLocaleDateString('en-GB', {
        weekday: 'long', day: '2-digit', month: 'short', year: 'numeric'
    }).replace(/(\d+)\s(\w+)\s(\d+)/, '$1 $2 $3');

    const handleRoundClick = (roundNo: number) => {
        setSelectedRound(roundNo); // Update the selected round
    };


    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                <div className={styles.topsection}>

                    <Box className="tllInfo">
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }} className="tllCountry">
                            <h3>{race.race_object_id.race_name}</h3>
                            <Box className="countimgpanel" sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '20px' }}>
                                <div className="flagTham">
                                    <img src='/assets/images/aus_flag.png' alt="country flag" className={styles.walletIcon}></img>
                                </div>
                                <div className="counTtl">
                                    <p className='mb-0' style={{ color: '#5e5c5a', fontWeight: '500' }}>{race.race_object_id.country}</p>
                                </div>
                            </Box>
                        </Box>
                        <i>{formattedRaceDate}</i>
                    </Box>


                    {/* <div className={styles.headerRtSide}>
                        <TextField
                            variant="outlined"
                            placeholder="Search here"
                            onChange={(e) => setSearchQuery(e.target.value)}
                            size="small"
                            sx={{ marginRight: 2 }}
                        />
                    </div> */}
                </div>

                <Box className={styles.raceTabNavWrap}>
                    {race.round.map((round) => (
                        <button
                            key={round._id}
                            className={`${styles.raceTabNavBtn} ${selectedRound === round.race_round_no ? 'active' : ''}`}
                            onClick={() => handleRoundClick(round.race_round_no)}
                            style={selectedRound === round.race_round_no ? { backgroundColor: "#00B4AA", color: "white" } : {}}
                        >
                            Race {round.race_round_no}
                        </button>
                    ))}
                </Box>

                <Box className={styles.raceTabtableWrap}>
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Position</TableCell>
                                    {/* <TableCell>Rug Number</TableCell> */}
                                    <TableCell>Box Number</TableCell>
                                    <TableCell>MGN</TableCell>
                                    <TableCell>Split</TableCell>
                                    <TableCell>In Run</TableCell>
                                    <TableCell>Weight</TableCell>
                                    {/* <TableCell>Price</TableCell> */}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {race.round
                                    .filter(round => round.race_round_no === selectedRound) // Filter to show only the selected round
                                    .map((round) => (
                                        round.winners.length > 0 ? round.winners.map((winner) => (
                                            <TableRow key={winner._id}>
                                                <TableCell>{winner.position}</TableCell>
                                                {/* <TableCell>{winner.rug_number}</TableCell> */}
                                                <TableCell>{winner.box_number}</TableCell>
                                                <TableCell>{winner.mgn}</TableCell>
                                                <TableCell>{winner.split}</TableCell>
                                                <TableCell>{winner.in_run}</TableCell>
                                                <TableCell>{winner.weight}</TableCell>
                                                {/* <TableCell>{winner.dog_price}</TableCell> */}
                                            </TableRow>
                                        )) : (
                                            <TableRow key={round._id}>
                                                <TableCell colSpan={8} style={{ textAlign: "center", verticalAlign: "middle", fontWeight: '600' }}>
                                                    No winners
                                                </TableCell>
                                            </TableRow>

                                        )
                                    ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            </Box>
        </Box>
    );
};

export default RaceDetails;