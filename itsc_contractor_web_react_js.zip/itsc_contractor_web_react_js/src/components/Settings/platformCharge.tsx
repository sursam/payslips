import React, { useEffect, useState } from 'react';
import { Box, Tabs, Tab, TextField, Button, Typography } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import styles from '../../styles/dogList.module.css';
import { toast } from 'react-toastify';
import { PlatformType } from '../../types';
import { api } from '../../utils/api';
import {
	Card,
	CardContent,
	TableContainer,
	Table,
	TableHead,
	TableRow,
	TableBody
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';

const PlatformCharges: React.FC = () => {
	const role = localStorage.getItem("role");

	const [isSidebarOpen, setSidebarOpen] = useState(true);
	const [selectedTab, setSelectedTab] = useState(0);
	const [errors, setErrors] = useState<any>({});
	const [settingsList, setSettingsList] = useState<PlatformType[]>([]);
	const [isPlatformEditing, setIsPlatformEditing] = useState(false);
	const [isTaxEditing, setIsTaxEditing] = useState(false);
	const [platformData, setPlatformData] = useState<any>({});
	const [taxData, setTaxData] = useState<any>({});

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	const handlePlatformChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		const { name, value } = event.target
		console.log({ name }, { value })
		setPlatformData((prevState: any) => ({
			...prevState,
			[name]: value
		}
		))
	}
	const handleTaxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		const { name, value } = event.target
		setTaxData((prevState: any) => ({
			...prevState,
			[name]: value
		}
		))
	}
	const getSettingsList = async () => {
		const response = await api.settings.getSettingsList()
		setSettingsList(response)
	}
	useEffect(() => {
		getSettingsList()
	}, [])

	useEffect(() => {
		if (settingsList?.length > 0) {
			const platformSetting = settingsList[0];
			const taxSetting = settingsList[1];

			setPlatformData({
				name: platformSetting?.name,
				value: platformSetting?.value,
				description: platformSetting?.description
			})
			setTaxData({
				name: taxSetting?.name,
				value: taxSetting?.value,
				description: taxSetting?.description
			})
		}
	}, [settingsList])

	const handlePlatformEditClick = () => {
		setIsPlatformEditing(true)
	}
	const handleTaxEditClick = () => {
		setIsTaxEditing(true)
	}

	const handlePlatformUpdate = async () => {
		const newErrors: any = {};
		if (!platformData.value) newErrors.value = 'Price is required';
		if (!platformData.description) newErrors.description = 'Description is required'; // Fixed the key here

		if (Object.keys(newErrors)?.length > 0) {
			setErrors(newErrors);
			return;
		}
		const payload = {
			name: platformData?.name,
			value: platformData.value,
			description: platformData.description
		}
		try {
			const response = await api.settings.addupdate(payload);
			if (response) {
				setIsPlatformEditing(false)
				toast.success("Platform updated successfully!");
				getSettingsList();
				setErrors({})
			}
		} catch (e) {
			throw e;
		}
	}
	const handleTaxUpdate = async () => {
		const newErrors: any = {};
		if (!taxData.value) newErrors.value = 'Price is required';
		if (!taxData.description) newErrors.description = 'Description is required';

		if (Object.keys(newErrors)?.length > 0) {
			setErrors(newErrors);
			return;
		}
		const payload = {
			name: taxData?.name,
			value: taxData.value,
			description: taxData.description
		}
		try {
			const response = await api.settings.addupdate(payload);
			if (response) {
				setIsTaxEditing(false)
				toast.success("Tax updated successfully!");
				getSettingsList();
				setErrors({})
			}
		} catch (e) {
			throw e;
		}
	}
	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Platform Charge List</h3>
				</div>

				<Tabs className='commonTab' value={selectedTab} onChange={(e, newValue) => setSelectedTab(newValue)}>
					<Tab className='tabLink' label="Platform Charges" />
					<Tab className='tabLink' label="Tax" />
				</Tabs>

				<Box>
					<Card sx={{ minWidth: 275 }}>
						<CardContent>
							<TableContainer>
								<Table className={styles.table}>
									<TableHead>
										<TableRow>
											<th>Name</th>
											<th>Price</th>
											<th>Description</th>
											{role === "MEMBER" ? <></> : (
												<th>Action</th>
											)}
										</TableRow>
									</TableHead>
									<TableBody>
										{selectedTab === 0 ? (
											<TableRow>
												<td>
													{platformData?.name?.toUpperCase()}
												</td>
												<td>
													{
														isPlatformEditing ? (
															<TextField
																name="value"
																variant="standard"
																fullWidth
																value={platformData.value}
																onChange={handlePlatformChange}
																required
															/>
														) : platformData?.value}
													{errors ? <p className={styles.error}>{errors?.value}</p> : ""}
												</td>
												<td>
													{
														isPlatformEditing ? (
															<TextField
																name="description"
																variant="standard"
																fullWidth
																value={platformData.description}
																onChange={handlePlatformChange}
																required
															/>
														) : platformData?.description}
													{errors ? <p className={styles.error}>{errors?.description}</p> : ""}
												</td>
												{role === "MEMBER" ? <></> : (
													<td>
														{
															isPlatformEditing ?
																<Button
																	className={styles.roundBtn}
																	variant="outlined"
																	sx={{ color: 'blue', borderColor: 'blue' }} onClick={handlePlatformUpdate}
																>
																	<SaveOutlinedIcon style={{ color: "#00B4AA" }}></SaveOutlinedIcon>
																</Button>
																:
																<Button
																	className={styles.roundBtn}
																	variant="outlined"
																	sx={{ color: 'blue', borderColor: 'blue' }} onClick={handlePlatformEditClick}
																>
																	<EditIcon style={{ color: "#00B4AA" }}></EditIcon>
																</Button>
														}
													</td>
												)}

											</TableRow>
										) : (
											<TableRow>
												<td>
													{taxData?.name?.toUpperCase()}
												</td>
												<td>
													{isTaxEditing ? (
														<TextField
															name="value"
															variant="standard"
															fullWidth
															value={taxData.value}
															onChange={handleTaxChange}
															required
														/>
													) : taxData?.value}
													{errors ? <p className={styles.error}>{errors?.value}</p> : ""}
												</td>
												<td>{isTaxEditing ? (
													<TextField
														name="description"
														variant="standard"
														fullWidth
														value={taxData.description}
														onChange={handleTaxChange}
														required
													/>
												) : taxData?.description}
													{errors ? <p className={styles.error}>{errors?.description}</p> : ""}
												</td>
												{role === "MEMBER" ? <></> : (
													<td>
														{
															isTaxEditing ?
																<Button
																	className={styles.roundBtn}
																	variant="outlined"
																	sx={{ color: 'blue', borderColor: 'blue' }} onClick={handleTaxUpdate}
																>
																	<SaveOutlinedIcon style={{ color: "#00B4AA" }}></SaveOutlinedIcon>
																</Button>
																:
																<Button
																	className={styles.roundBtn}
																	variant="outlined"
																	sx={{ color: 'blue', borderColor: 'blue' }} onClick={handleTaxEditClick}
																>
																	<EditIcon style={{ color: "#00B4AA" }}></EditIcon>
																</Button>
														}
													</td>
												)}
											</TableRow>
										)}

										{/* <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
					<Button variant="contained" onClick={handleSubmit}>Save changes</Button>
				</Box> */}
									</TableBody>
								</Table>
							</TableContainer>
						</CardContent>
					</Card>
				</Box>
			</Box>
		</Box>
	);
};

export default PlatformCharges;