import React, { useCallback, useEffect, useState } from 'react';
import { Box, Button, Modal, TextField, IconButton, Menu, MenuItem, Table, TableBody, TableContainer, TableHead, TableRow, TablePagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import styles from '../../styles/dogList.module.css';
import EditIcon from '@mui/icons-material/Edit';
import { toast } from 'react-toastify';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';
import MoreVert from '@mui/icons-material/MoreVert';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';

const Subscription: React.FC = () => {
	const role = localStorage.getItem("role");

	const [isSidebarOpen, setSidebarOpen] = useState(true); // State for search query
	const [errors, setErrors] = useState<any>({});
	const [addSubs, setAddSubs] = useState({
		name: "",
		price: 0,
		type: "",
		duration: 0,
		description: ""
	})
	const [isSubscriptionEditing, setIsSubscriptionEditing] = useState(false);
	const [selectedRow, setSelectedRow] = useState<string>('');

	const toggleSidebar = () => {
		setSidebarOpen(!isSidebarOpen);
	};

	const getSubscription = async () => {
		const subcriptionInstance = await api.settings.getSubscriptionList();
		setAddSubs({
			name: subcriptionInstance[0]?.name,
			price: subcriptionInstance[0]?.price,
			type: subcriptionInstance[0]?.type,
			duration: subcriptionInstance[0]?.duration,
			description: subcriptionInstance[0]?.description
		})
		setSelectedRow(subcriptionInstance[0]?._id)
	}

	useEffect(() => {
		getSubscription()
	}, [])

	const handleEditSubscription = () => {
		setIsSubscriptionEditing(true)
	};

	const handleChangeSubsList = (event: React.ChangeEvent<HTMLInputElement>) => {
		const { name, value } = event.target
		console.log({ name }, { value })
		setAddSubs((prevState: any) => ({
			...prevState,
			[name]: value
		}));
	}

	const handleSubscriptionUpdate = async (event: any) => {
		event.preventDefault();

		const newErrors: any = {};
		if (!addSubs.price) newErrors.price = 'Subscription price is required';
		if (!addSubs.duration) newErrors.duration = 'Subscription duration is required';
		if (!addSubs.type) newErrors.type = 'Subscription type is required';
		if (!addSubs.description) newErrors.description = 'Subscription description is required';

		if (Object.keys(newErrors)?.length > 0) {
			setErrors(newErrors);
			return;
		}
		const payload = {
			name: addSubs.name,
			price: addSubs.price,
			type: addSubs.type,
			duration: addSubs.duration,
			description: addSubs.description
		};

		try {
			const response = await api.settings.updateSubscription(selectedRow, payload);
			if (response) {
				toast.success("Subscription edited successfully!");
				setIsSubscriptionEditing(false)
				setErrors({})
				await api.settings.getSubscriptionList();
			} else {
				toast.error('Subscription creation failed.');
			}
		} catch (error) {
			toast.error("Error adding/updating Subscription.");
		}
	};
	console.log({ errors })
	return (
		<Box className={styles.container}>
			<Sidebar isOpen={isSidebarOpen} />
			<Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
			<Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
				<div className={styles.topsection}>
					<h3>Subscription List</h3>
				</div>

				<div className={styles.customtable}>
					<TableContainer>
						<Table className={`${styles.table} table`}>
							<TableHead>
								<TableRow>
									<th>Name</th>
									<th>Type</th>
									<th>Price</th>
									<th>Duration</th>
									<th>Description</th>
									{role === "MEMBER" ? <></> : (
										<th>Action</th>
									)}
								</TableRow>
							</TableHead>
							<TableBody>
								<TableRow>
									<td>{addSubs?.name?.toUpperCase()}</td>
									<td>
										{
											isSubscriptionEditing ? (
												<TextField
													name="type"
													variant="standard"
													fullWidth
													value={addSubs?.type}
													onChange={handleChangeSubsList}
													required
												/>
											) : addSubs?.type
										}

										{errors ? <p className={styles.error}>{errors?.type}</p> : ""}
									</td>
									<td>
										{
											isSubscriptionEditing ? (
												<TextField
													name="price"
													variant="standard"
													fullWidth
													value={addSubs?.price}
													onChange={handleChangeSubsList}
													required
												/>
											)
												: addSubs?.price
										}
										{errors ? <p className={styles.error}>{errors?.price}</p> : ""}
									</td>
									<td>
										{
											isSubscriptionEditing ? (
												<TextField
													name="duration"
													variant="standard"
													fullWidth
													value={addSubs?.duration}
													onChange={handleChangeSubsList}
													required
												/>
											)
												: addSubs?.duration
										}
										{errors ? <p className={styles.error}>{errors?.duration}</p> : ""}
									</td>
									<td>
										{
											isSubscriptionEditing ? (
												<TextField
													name="description"
													variant="standard"
													fullWidth
													value={addSubs?.description}
													onChange={handleChangeSubsList}
													required
												/>
											)
												: addSubs?.description
										}
										{errors ? <p className={styles.error}>{errors?.description}</p> : ""}
									</td>
									{role === "MEMBER" ? <></> : (
										<td>
											{
												isSubscriptionEditing ? (
													<Button
														className={styles.roundBtn}
														variant="outlined"
														sx={{ color: 'blue', borderColor: 'blue' }} onClick={handleSubscriptionUpdate}
													>
														<SaveOutlinedIcon style={{ color: "#00B4AA" }}></SaveOutlinedIcon>
													</Button>
												) : (
													<Button
														className={styles.roundBtn}
														variant="outlined"
														sx={{ color: 'blue', borderColor: 'blue' }} onClick={handleEditSubscription}
													>
														<EditIcon style={{ color: "#00B4AA" }}></EditIcon>
													</Button>
												)
											}
										</td >
									)}
								</TableRow >
							</TableBody >
						</Table >
					</TableContainer >
				</div >
			</Box >
		</Box >
	);
};

export default Subscription;