import React, { useEffect, useState } from 'react';
import { Box, Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, FormControl, InputLabel, MenuItem, Modal, Select, TextField, ToggleButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination, FormHelperText, Autocomplete, Chip, Switch, IconButton, Stack, Pagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import styles from '../../styles/dogList.module.css';
import { useDog } from '../../context/DogContext';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import { toast } from 'react-toastify';
import { useUsers } from '../../context/Users';
import { useNavigate } from 'react-router-dom';
import VisibilityIcon from '@mui/icons-material/Visibility';
import { api } from '../../utils/api';
import { MESSAGE } from '../../constants/api/message';
import { DogPayload } from '../../utils/api/dogs/dogList';

const DogList: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [openModal, setOpenModal] = useState(false);
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [openStatusDialog, setOpenStatusDialog] = useState(false);
    const [dogName, setDogName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [gender, setGender] = useState('');
    const [ownerId, setOwnerId] = useState('');
    const [trainerId, setTrainerId] = useState('');
    const [color, setColor] = useState('');
    const [breedS, setBreedS] = useState('');
    const [breedD, setBreedD] = useState('');
    const [dogPrice, setdogPrice] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [errors, setErrors] = useState<any>({});
    const [dogList, setDogList] = useState<any[]>([]); // State to hold the dog list
    const [selectedDogId, setSelectedDogId] = useState<string | null>(null);
    const [newStatus, setNewStatus] = useState<string>('ACTIVE');
    const [searchQuery, setSearchQuery] = useState(''); // State for search query
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [users, setUsers] = useState<any[]>([]);
    const [owner, setOwner] = useState<any[]>([]);
    const [filePreview, setFilePreview] = useState<string | null>(null); // State for file preview

    const { addDog, adminDogList, deleteDog, changeDogStatus, updateDog } = useDog(); // Use the context
    const { fetchUsers, fetchSuperAdmin } = useUsers(); // Use the Users context

    const navigate = useNavigate();

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    // useEffect(() => {
    //     const fetchDogList = async () => {
    //         const dogs = await adminDogList();
    //         setDogList(dogs);
    //     };
    //     fetchDogList();
    // }, [adminDogList]);

    useEffect(() => {
        const getDogList = async () => {
            try {
                const response = await api.dogs.getDogList();

                if (response?.result) {
                    setDogList(response.result); // Ensure result is an array before setting state
                } else {
                    console.warn("Invalid dog list response format:", response);
                }
            } catch (error) {
                console.error("Error fetching dogs list:", error);
            }
        };

        getDogList();
    }, []);

    useEffect(() => {
        const loadUsers = async () => {
            const usersList = await fetchUsers(); // Fetch users from context
            setUsers(usersList);
        };
        loadUsers();
    }, [fetchUsers]);

    useEffect(() => {
        const loadOwner = async () => {
            const ownerList = await fetchSuperAdmin(); // Fetch users from context
            setOwner(ownerList);
        };
        loadOwner();
    }, [fetchSuperAdmin]);

    const handleOpenModal = (dog?: any) => {
        setOpenModal(true);
        if (dog) {
            setSelectedDogId(dog._id);
            setDogName(dog.dog_name);
            setDateOfBirth(dog.date_of_birth);
            setGender(dog.gender);
            setOwnerId(dog.owner_id ? dog.owner_id._id : ''); // Set owner ID
            setTrainerId(dog.trainer_id ? dog.trainer_id._id : ''); // Set trainer ID
            setColor(dog.color);
            setBreedS(dog.breed_s);
            setBreedD(dog.breed_d);
            setdogPrice(dog.dog_price);
            setFile(null);
            setFilePreview(dog.img && dog.img.length > 0 ? dog.img[0] : null);
        } else {
            // Reset form for adding a new dog
            setSelectedDogId(null);
            setDogName('');
            setDateOfBirth('');
            setGender('');
            setOwnerId('');
            setTrainerId('');
            setColor('');
            setBreedS('');
            setBreedD('');
            setdogPrice('');
            setFile(null);
            setFilePreview(null);
        }
        setErrors({});
    };

    const handleCloseModal = () => {
        setOpenModal(false);
        setErrors({});
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (files && files.length > 0) {
            const selectedFile = files[0];
            setFile(selectedFile);

            // Create a file preview URL
            const reader = new FileReader();
            reader.onloadend = () => {
                setFilePreview(reader.result as string); // Set the file preview
            };
            reader.readAsDataURL(selectedFile); // Read the file as a data URL
        } else {
            setFile(null);
            setFilePreview(null); // Reset file preview if no file is selected
        }
    };



    const handleSubmit = async () => {
        const newErrors: any = {};
        if (!dogName) newErrors.dogName = 'Dog name is required';
        if (!dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
        if (!gender) newErrors.gender = 'Gender is required';
        if (!ownerId) newErrors.ownerId = 'Owner ID is required';
        if (!trainerId) newErrors.trainerId = 'Trainer ID is required';
        if (!color) newErrors.color = 'Color is required';
        if (!breedS) newErrors.breedS = 'Breed (S) is required';
        if (!breedD) newErrors.breedD = 'Breed (D) is required';
        if (!dogPrice) newErrors.dogPrice = 'Dog Price is required';
        // if (!file) newErrors.file = 'Profile Image is required';

        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
        }

        const formData = new FormData();
        formData.append('dog_name', dogName);
        formData.append('date_of_birth', dateOfBirth);
        formData.append('gender', gender);
        formData.append('color', color);
        formData.append('breed_s', breedS);
        formData.append('breed_d', breedD);
        formData.append('owner_id', ownerId);
        formData.append('trainer_id', trainerId);
        formData.append('dog_price', dogPrice.toString());

        if (file) {
            console.log("Appending file:", file.name, file.type);
            formData.append('file', file);
        }

        try {
            if (selectedDogId) {
                await api.dogs.updateDog(selectedDogId, formData);
            } else {
                await api.dogs.addDog(formData);
            }

            const updatedDogList = await api.dogs.getDogList();
            if (updatedDogList) {
                setDogList(updatedDogList.result);
            }
            handleCloseModal();
        } catch (error) {

        }
    };




    const handleDeleteDog = async () => {
        if (selectedDogId) {
            await deleteDog(selectedDogId);
            setOpenDeleteDialog(false);
            toast.success("Dog deleted successfully!");
            // Refresh the dog list after deletion
            const updatedDogList = await adminDogList();
            setDogList(updatedDogList);
        }
    };

    const handleToggleStatus = async (dogId: string, currentStatus: string) => {
        setSelectedDogId(dogId);
        setNewStatus(currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE');
        setOpenStatusDialog(true);
    };

    const handleConfirmStatusChange = async () => {
        if (selectedDogId) {
            await changeDogStatus(selectedDogId, newStatus);
            setOpenStatusDialog(false);
            toast.success(`Dog status changed to ${newStatus}!`);
            // Refresh the dog list after status change
            const updatedDogList = await adminDogList();
            setDogList(updatedDogList);
        }
    };

    const filteredDogs = dogList?.filter(dog =>
        dog.dog_name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Handle pagination change
    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage - 1); // Convert to 0-based index
    };


    // Handle rows per page change
    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0); // Reset to the first page
    };

    const handleViewDogDetails = (dogId: string) => {
        navigate(`/dogdetails/${dogId}`);
    };

    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                <div className={styles.topsection}>
                    <h3>Dog List</h3>
                    <div className={styles.headerRtSide}>
                        <TextField
                            variant="outlined"
                            placeholder="Search Dog"
                            onChange={(e) => setSearchQuery(e.target.value)}
                            size="small"
                        // sx={{ marginRight: 2 }}
                        />
                        {userRole !== 'MEMBER' && (
                            <Button variant="contained" onClick={handleOpenModal}>
                                Add Dog
                            </Button>
                        )}
                    </div>
                </div>

                <div className={styles.customtable}>
                    <TableContainer>
                        <Table className={`${styles.table} table`}>
                            <TableHead>
                                <TableRow>
                                    <th>Dog Name</th>
                                    <th>Color</th>
                                    <th>Sex & DOB</th>
                                    <th>Trainer & Owner</th>
                                    <th>Price</th>
                                    {/* <th>Bid Value</th> */}
                                    <th style={{ textAlign: userRole !== 'MEMBER' ? 'center' : 'left' }}>Status</th>
                                    <th style={{ textAlign: userRole !== 'MEMBER' ? 'center' : 'left' }}>Actions</th>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {filteredDogs?.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((dog) => (<TableRow key={dog._id}>
                                    <td>
                                        <div className={styles.dogInfoContainer}>
                                            <img
                                                src={dog.img.length > 0 ? dog.img[0] : '/assets/images/dog_profile.png'}
                                                className={styles.dogImage}
                                                alt={dog.dog_name}
                                            />
                                            <div className={styles.dogText}>
                                                {dog.dog_name}<br />
                                                S : {dog.breed_s}<br />
                                                D : {dog.breed_d}
                                            </div>
                                        </div>
                                    </td>
                                    <td>{dog.color}</td>
                                    <td>{dog.gender}<br />
                                        {dog.date_of_birth}</td>
                                    <td>
                                        T : {dog.trainer_id ? dog.trainer_id.first_name : 'N/A'}<br />
                                        O : {dog.owner_id ? dog.owner_id.first_name : 'N/A'}
                                    </td>
                                    <td>{dog.dog_price}</td>
                                    <td style={{ textAlign: userRole !== 'MEMBER' ? 'center' : 'left' }}>
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                            {userRole !== 'MEMBER' ? (
                                                <>
                                                    <Switch
                                                        checked={dog.status === 'ACTIVE'}
                                                        onChange={(event) => {
                                                            handleToggleStatus(dog._id, dog.status);
                                                        }}
                                                        color="success"
                                                        sx={{
                                                            '&.Mui-checked': {
                                                                color: 'green', // Color of the switch when checked (Active)
                                                            },
                                                            '&.Mui-checked + .MuiSwitch-track': {
                                                                backgroundColor: 'green', // Track color when checked (Active)
                                                            },
                                                            '& .MuiSwitch-thumb': {
                                                                backgroundColor: 'white', // Thumb color
                                                            },
                                                            '& .MuiSwitch-track': {
                                                                backgroundColor: 'lightgray', // Track color when unchecked (Inactive)
                                                            },
                                                        }}
                                                    />
                                                    <span style={{
                                                        color: dog.status === 'ACTIVE' ? 'green' : 'red',
                                                        fontWeight: 'bold',
                                                        fontSize: '14px',
                                                        lineHeight: '1.2',
                                                        marginLeft: '8px',
                                                        padding: '4px 8px',
                                                        borderRadius: '4px',
                                                        backgroundColor: dog.status === 'ACTIVE' ? '#e0f7e0' : '#f8d7da',
                                                        border: `1px solid ${dog.status === 'ACTIVE' ? 'green' : 'red'}`,
                                                    }}>
                                                        {dog.status === 'ACTIVE' ? 'Active' : 'Inactive'}
                                                    </span>
                                                </>
                                            ) : (
                                                <span style={{
                                                    color: dog.status === 'ACTIVE' ? 'green' : 'red',
                                                    fontWeight: 'bold',
                                                    fontSize: '14px',
                                                    lineHeight: '1.2',
                                                    marginLeft: '8px',
                                                    padding: '4px 8px',
                                                    borderRadius: '4px',
                                                    backgroundColor: dog.status === 'ACTIVE' ? '#e0f7e0' : '#f8d7da',
                                                    border: `1px solid ${dog.status === 'ACTIVE' ? 'green' : 'red'}`,
                                                }}>
                                                    {dog.status === 'ACTIVE' ? 'Active' : 'Inactive'}
                                                </span>
                                            )}
                                        </div>
                                    </td>
                                    <td style={{ textAlign: userRole !== 'MEMBER' ? 'center' : 'left' }}>
                                        <div style={{ display: 'flex', gap: '8px' }}>
                                            <Button
                                                className={styles.roundBtn}
                                                variant="outlined"
                                                sx={{ color: 'blue', borderColor: 'blue' }} onClick={() => handleViewDogDetails(dog._id)}
                                            >
                                                <VisibilityIcon />
                                            </Button>
                                            {userRole !== 'MEMBER' && (
                                                <>
                                                    <Button
                                                        className={styles.roundBtn}
                                                        variant="outlined"
                                                        color="primary"
                                                        onClick={() => handleOpenModal(dog)}
                                                    >
                                                        <EditIcon />
                                                    </Button>
                                                    <Button
                                                        variant="outlined"
                                                        className={styles.roundBtn}
                                                        sx={{ color: 'red', borderColor: 'red' }}
                                                        onClick={() => {
                                                            setSelectedDogId(dog._id);
                                                            setOpenDeleteDialog(true);
                                                        }}
                                                    >
                                                        <DeleteIcon />
                                                    </Button>
                                                </>
                                            )}
                                        </div>
                                    </td>
                                </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
                        <Pagination
                            count={Math.ceil(filteredDogs?.length / rowsPerPage)} // Calculate total pages
                            page={page + 1} // MUI Pagination is 1-based
                            onChange={handleChangePage}
                            color="primary"
                        />
                    </Stack>
                </div>

                <Modal open={openModal} onClose={handleCloseModal}>
                    <Box className={styles.modalBox}
                        sx={{
                            position: 'absolute',
                            top: '50%',
                            right: '0px',
                            transform: 'translateY(-50%)',
                            padding: 2,
                            backgroundColor: 'white',
                            borderRadius: 2,
                            // height: '100%',
                            // maxWidth: '30%',
                        }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h2>{selectedDogId ? 'Edit Dog' : 'Add Dog'}</h2>
                            <IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                        <TextField
                            label="Dog Name"
                            variant="outlined"
                            fullWidth
                            value={dogName}
                            onChange={(e) => setDogName(e.target.value)}
                            error={!!errors.dogName}
                            helperText={errors.dogName}
                            sx={{ marginBottom: 2 }}
                        />
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <TextField
                                select
                                label="Gender"
                                variant="outlined"
                                fullWidth
                                value={gender}
                                onChange={(e) => setGender(e.target.value)}
                                sx={{ flex: '1 1 45%' }}
                                error={Boolean(errors.gender)}
                                helperText={errors.gender}
                                required
                            >
                                <MenuItem value="">
                                    <em>Select Gender</em>
                                </MenuItem>
                                <MenuItem value="MALE">MALE</MenuItem>
                                <MenuItem value="FEMALE">FEMALE</MenuItem>
                            </TextField>

                            <Box className={styles.detailsWrap}>
                                <TextField
                                    variant="outlined"
                                    type="date"
                                    fullWidth
                                    value={dateOfBirth}
                                    onChange={(e) => setDateOfBirth(e.target.value)}
                                    error={!!errors.dateOfBirth}
                                    helperText={errors.dateOfBirth}
                                    sx={{ marginBottom: 2 }}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <Autocomplete
                                    options={owner}
                                    fullWidth
                                    getOptionLabel={(option) => option.first_name}
                                    value={owner.find(o => o._id === ownerId) || null}
                                    onChange={(event, newValue) => {
                                        setOwnerId(newValue ? newValue._id : '');
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Owner"
                                            variant="outlined"
                                            error={!!errors.ownerId}
                                            helperText={errors.ownerId}
                                            sx={{ marginBottom: 2 }}
                                        />
                                    )}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <Autocomplete
                                    options={users}
                                    fullWidth
                                    getOptionLabel={(option) => option.first_name}
                                    value={users.find(t => t._id === trainerId) || null}
                                    onChange={(event, newValue) => {
                                        setTrainerId(newValue ? newValue._id : '');
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Trainer"
                                            variant="outlined"
                                            error={!!errors.trainerId}
                                            helperText={errors.trainerId}
                                            sx={{ marginBottom: 2 }}
                                        />
                                    )}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Color"
                                    fullWidth
                                    variant="outlined"
                                    value={color}
                                    onChange={(e) => setColor(e.target.value)}
                                    error={!!errors.color}
                                    helperText={errors.color}
                                    sx={{ marginBottom: 2 }}
                                // InputProps={{
                                //     style: { backgroundColor: color, height: '56px' }, // Full box with selected color
                                // }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Breed (S)"
                                    variant="outlined"
                                    fullWidth
                                    value={breedS}
                                    onChange={(e) => setBreedS(e.target.value)}
                                    error={!!errors.breedS}
                                    helperText={errors.breedS}
                                    sx={{ marginBottom: 2 }}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Breed (D)"
                                    variant="outlined"
                                    fullWidth
                                    value={breedD}
                                    onChange={(e) => setBreedD(e.target.value)}
                                    error={!!errors.breedD}
                                    helperText={errors.breedD}
                                    sx={{ marginBottom: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Price"
                                    variant="outlined"
                                    fullWidth
                                    value={dogPrice}
                                    onChange={(e) => setdogPrice(e.target.value)}
                                    error={!!errors.dogPrice}
                                    helperText={errors.dogPrice}
                                    sx={{ marginBottom: 2 }}
                                />
                            </Box>
                        </Box>

                        <Box sx={{ marginBottom: 2 }}>
                            <input
                                type="file"
                                onChange={handleFileChange}
                            />
                            {errors.file && <p style={{ color: 'red' }}>{errors.file}</p>}
                        </Box>
                        {/* File preview box */}
                        {filePreview && (
                            <Box sx={{ marginBottom: 2, border: '1px solid #ccc', padding: 1, borderRadius: 1, width: '25%', height: '25%' }}>
                                <img
                                    src={filePreview}
                                    alt="File Preview"
                                    style={{ width: '100%', height: '100%', borderRadius: '4px' }}
                                />
                            </Box>
                        )}



                        <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
                            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>Close</Button>
                            <Button variant="contained" onClick={handleSubmit}>Save changes</Button>
                        </Box>
                    </Box>
                </Modal>

                {/* Delete Confirmation Dialog */}
                <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
                    <DialogTitle>Confirm Delete</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Are you sure you want to delete this dog?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setOpenDeleteDialog(false)} color="primary">Cancel</Button>
                        <Button onClick={handleDeleteDog} color="secondary">Delete</Button>
                    </DialogActions>
                </Dialog>

                {/* Status Change Confirmation Dialog */}
                <Dialog open={openStatusDialog} onClose={() => setOpenStatusDialog(false)}>
                    <DialogTitle>Confirm Status Change</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Are you sure you want to change the status to {newStatus}?
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setOpenStatusDialog(false)} color="primary">Cancel</Button>
                        <Button onClick={handleConfirmStatusChange} color="secondary">Change Status</Button>
                    </DialogActions>
                </Dialog>

            </Box>
        </Box>
    );
};

export default DogList;