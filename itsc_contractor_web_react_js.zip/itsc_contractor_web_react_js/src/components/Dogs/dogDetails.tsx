import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Box, Button, Typography, Tabs, Tab, Paper, TableContainer, TableHead, TableRow, TableCell, TableBody, Stack, Pagination } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import { useDog } from '../../context/DogContext';
import styles from '../../styles/dogList.module.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Table } from 'react-bootstrap';

const DogDetails: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [selectedTab, setSelectedTab] = useState(0);
    const { fetchDogById, addToCart, fetchCartItems, raceHistory } = useDog();
    const [dog, setDog] = useState<any>(null);
    const [cartItems, setCartItems] = useState<any[]>([]); // State to manage cart items
    const [dogHistory, setDogHistory] = useState<any | any[]>([]); // State to manage cart items
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const userRole = userDetails.userRole;

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    // Handle pagination change
    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage - 1); // Convert to 0-based index
    };

    // Handle rows per page change (if needed)
    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0); // Reset to the first page
    };

    useEffect(() => {
        const fetchDogDetails = async () => {
            if (id) { // Check if id is defined
                const dogData = await fetchDogById(id); // Fetch dog by ID
                setDog(dogData);
            }
        };
        fetchDogDetails();
    }, [id, fetchDogById]);

    useEffect(() => {
        const fetchRaceHistory = async () => {
            if (id) {
                const dogData = await raceHistory(id);

                // Check if dogData is null before proceeding
                if (!dogData) {
                    setDogHistory([]);
                    return;
                }

                setDogHistory(Array.isArray(dogData.results) ? dogData.results : []);
            }
        };
        fetchRaceHistory();
    }, [id, raceHistory]);



    const handleAddToCart = async (item: any) => {
        const unitPrice = item.dog_price; // Assuming item has a unit_price property
        const success = await addToCart('67bec4e8ec9c664769fa4bc0', item._id, 1, unitPrice); // Call the addToCart function from context

        if (success) {
            // Fetch cart items to show updated list
            const cartResponse = await fetchCartItems();
            // if (cartResponse && cartResponse.result) {
            //     setCartItems(cartResponse.result); // Update cart items from API response
            // }
            // Navigate to cart page
            navigate('/cart');
        }
    };

    const handleRemoveFromCart = (index: number) => {
        setCartItems((prevItems) => prevItems.filter((_, i) => i !== index)); // Remove item from cart
    };

    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                {cartItems.length > 0 ? (
                    <Box sx={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
                        <Typography variant="h6">Items ({cartItems.length})</Typography>
                        {cartItems.map((item, index) => (
                            <Box key={index} sx={{ display: 'flex', alignItems: 'center', marginBottom: '20px', borderBottom: '1px dashed #ccc', paddingBottom: '10px' }}>
                                <img
                                    src={item.img?.length > 0 ? item.img[0] : '/assets/images/dog_profile.png'}
                                    alt={item.dog_name}
                                    style={{ width: '80px', height: '80px', borderRadius: '50%', marginRight: '20px', objectFit: 'cover' }}
                                />
                                <Box sx={{ flex: 1 }}>
                                    <Typography variant="body1">{item.dog_name}</Typography>
                                    <Typography variant="body2">S: {item.breed_s} | D: {item.breed_d}</Typography>
                                    <Typography variant="body2">Unit Value: ${item.unitValue || 150.00}</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Button variant="outlined" onClick={() => handleRemoveFromCart(index)}>-</Button>
                                    <Typography variant="body1" sx={{ margin: '0 10px' }}>{item.quantity}</Typography>
                                    <Button variant="outlined" onClick={() => handleAddToCart(item)}>+</Button>
                                    <Button variant="outlined" color="error" onClick={() => handleRemoveFromCart(index)} sx={{ marginLeft: '10px' }}>Delete</Button>
                                </Box>
                            </Box>
                        ))}
                    </Box>
                ) : (
                    <Box>
                        <Box className={styles.detailsBox}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <img
                                    src={dog?.img?.length > 0 ? dog.img[0] : '/assets/images/dog_profile.png'}
                                    alt={dog?.dog_name}
                                    style={{ width: '80px', height: '80px', borderRadius: '50%', marginRight: '10px' }}
                                />
                                <Box>
                                    <Typography variant="h6">{dog?.dog_name}</Typography>
                                    <Box sx={{ display: 'flex', flexDirection: 'row', marginTop: '5px' }}>
                                        <Box sx={{ marginRight: '20px' }}>
                                            <Typography variant="body2"><strong>Career</strong></Typography>
                                            <Typography variant="body2">6: 0 -0 -1</Typography>
                                        </Box>
                                        <Box>
                                            <Typography variant="body2"><strong>WIN/PLC</strong></Typography>
                                            <Typography variant="body2">0%  /  17%</Typography>
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <Box sx={{ marginRight: '10px' }}>
                                    <Typography variant="body2"><strong>Unit Value</strong></Typography>
                                    <Typography variant="body2"
                                        sx={{
                                            fontSize: '16px',
                                            fontWeight: 'bold',
                                            color: '#2facb5'
                                        }}>$ {dog?.dog_price}</Typography>
                                </Box>
                                {userRole === 'MEMBER' && (
                                    <Button variant="contained" color="primary" onClick={() => handleAddToCart(dog)}>Add To Cart</Button>
                                )}
                                {/* {userRole !== 'MEMBER' && (
                                <MoreVertIcon sx={{ marginLeft: '10px', cursor: 'pointer' }} />
                                )} */}
                            </Box>
                        </Box>

                        <Box className={styles.dogdetailsPage} >
                            <Tabs value={selectedTab} onChange={(event, newValue) => setSelectedTab(newValue)}>
                                <Tab label="Dog Details" />
                                <Tab label="Race History" />
                            </Tabs>
                            <Box sx={{ padding: '20px 0 0' }}>
                                {selectedTab === 0 && (
                                    <Paper elevation={3} sx={{ padding: '20px', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
                                        <Box>
                                            {[
                                                { label: 'Breeding S', value: dog?.breed_s },
                                                { label: 'Breeding D', value: dog?.breed_d },
                                                { label: 'Color', value: dog?.color },
                                                { label: 'Sex', value: dog?.gender },
                                                { label: 'Date Of Birth', value: new Date(dog?.date_of_birth).toLocaleDateString() },
                                                { label: 'Owner Name', value: `${dog?.owner_id?.first_name} ${dog?.owner_id?.last_name}` },
                                                { label: 'Trainer Name', value: `${dog?.trainer_id?.first_name} ${dog?.trainer_id?.last_name}` },
                                            ].map((item, index) => (
                                                <Box className={styles.dogInfolist}
                                                    key={index}
                                                    sx={{
                                                        display: 'flex',
                                                        borderBottom: '1px dashed #ccc',
                                                        padding: '10px 0',
                                                        alignItems: 'center',
                                                        '&:last-child': {
                                                            borderBottom: 'none',
                                                        },
                                                        '&:hover': {
                                                            backgroundColor: '#f0f0f0',
                                                        },
                                                    }}
                                                >
                                                    <Typography className={styles.dogInfoitem} variant="body1" sx={{ fontWeight: 'bold', paddingLeft: '10px', marginRight: '10px' }}>
                                                        <strong>{item.label}</strong> :
                                                    </Typography>
                                                    {/* <Typography variant="body1" sx={{ padding: '0 6px' }}>:</Typography> */}
                                                    <Typography variant="body1" sx={{}}>
                                                        <span>{item.value}</span>
                                                    </Typography>
                                                </Box>
                                            ))}
                                        </Box>
                                    </Paper>
                                )}
                                {selectedTab === 1 && (
                                    <Box>
                                        <TableContainer component={Paper}>
                                            <Table>
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell>Race Name</TableCell>
                                                        <TableCell>Race Date</TableCell>
                                                        <TableCell>Grade</TableCell>
                                                        <TableCell>Round No</TableCell>
                                                        <TableCell>Position</TableCell>
                                                        <TableCell>Completion Time</TableCell>
                                                        <TableCell>Box Number</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {dogHistory.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((race: any) => (
                                                        race.rounds.map((round: any) => (
                                                            round.winners.map((winner: any) => (
                                                                <TableRow key={winner._id}>
                                                                    <TableCell>{race.race_object_id.race_name}</TableCell>
                                                                    <TableCell>{new Date(race.race_date).toLocaleDateString()}</TableCell>
                                                                    <TableCell>{race.grade}</TableCell>
                                                                    <TableCell>{round.race_round_no}</TableCell>
                                                                    <TableCell>{winner.position}</TableCell>
                                                                    <TableCell>{winner.race_completion_time}</TableCell>
                                                                    <TableCell>{winner.box_number}</TableCell>
                                                                </TableRow>
                                                            ))
                                                        ))
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>

                                        <Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
                                            <Pagination
                                                count={Math.ceil(dogHistory.reduce((acc: number, race: any) => acc + race.rounds.reduce((roundAcc: number, round: any) => roundAcc + round.winners.length, 0), 0) / rowsPerPage)} // Calculate total pages
                                                page={page + 1} // MUI Pagination is 1-based
                                                onChange={handleChangePage}
                                                color="primary"
                                            />
                                        </Stack>
                                    </Box>
                                )}
                            </Box>
                        </Box>
                    </Box>
                )}
            </Box>
        </Box>
    );
};

export default DogDetails;