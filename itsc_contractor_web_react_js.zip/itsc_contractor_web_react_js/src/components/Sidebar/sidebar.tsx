import React, { useEffect, useState } from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import styles from '../../styles/header.module.css';
import { useLocation, useNavigate } from 'react-router-dom';
import Chip from '@mui/material/Chip';
import Avatar from '@mui/material/Avatar';
import { deepOrange, deepPurple } from '@mui/material/colors';
import { DashboardOutlined, ChevronRightOutlined, ExpandLess, BusinessCenterOutlined, CasesOutlined, CardTravelOutlined, LocalShippingOutlined, PolicyOutlined, StarBorderOutlined } from '@mui/icons-material';
// #f2f2f2 - Hexcode of Sidebar background color

interface SidebarProps {
    isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
    const [activeItem, setActiveItem] = useState<string | null>(null);
    const [isUserManagementOpen, setUserManagementOpen] = useState(false);
    const [isJobOpen, setJobOpen] = useState(false);
    const [isRacesOpen, setRacesOpen] = useState(false);
    const [isSettingsOpen, setSettingsOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        setActiveItem(location.pathname);
        if (location.pathname === '/admin' || location.pathname === '/member') {
            setUserManagementOpen(true);
        } else {
            setUserManagementOpen(false);
        }
    }, [location.pathname]);

    useEffect(() => {
        setActiveItem(location.pathname);
        if (location.pathname === '/subscription' || location.pathname === '/plateformcharges') {
            setSettingsOpen(true);
        } else {
            setSettingsOpen(false);
        }
    }, [location.pathname]);

    const handleMenuItemClick = (item: string) => {
        if (item === '/users') {
            setUserManagementOpen(!isUserManagementOpen);
        } else {
            setActiveItem(item);
            navigate(item);
        }
    };

    const handleJobManagementClick = () => {
        setJobOpen(!isJobOpen); // Toggle Races submenu
    };
    const handleRaceManagementClick = () => {
        setRacesOpen(!isRacesOpen); // Toggle Races submenu
    };

    // const toggleUserManagement = () => {
    //     setUserManagementOpen(!isUserManagementOpen);
    //     if (!isUserManagementOpen) {
    //         setActiveItem('/users');
    //     } else {
    //         setActiveItem(null);
    //     }
    // };

    const toggleSettings = () => {
        setSettingsOpen(!isSettingsOpen);
        if (!isSettingsOpen) {
            setActiveItem('/settings');
        } else {
            setActiveItem(null);
        }
    };

    const handleSubMenuClick = (item: string, event: React.MouseEvent) => {
        event.stopPropagation();
        setActiveItem(item);
        navigate(item);
    };

    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const firstName = userDetails.firstName || '';
    const lastName = userDetails.lastName || '';
    const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    const userRole = userDetails.userRole;

    return (
        <>
            <Box className={`${styles.sidebar} ${isOpen ? styles.open : styles.closed}`}>
                <Box className={styles.headerContainer}>
                    {isOpen ?
                        <img src='/assets/images/logo.png' alt="Logo" className={styles.logo} />
                        :
                        <img src='/assets/images/logo-short.png' alt="Logo" className={styles.logo} />
                    }
                </Box>
                {isOpen ?
                    <div className={styles.menuCaptionContainer}>
                        <Typography className={styles.menuCaption}>Navigation</Typography>
                    </div>
                    : ''
                }
                <div className={styles.menu}>
                    <div className={`${styles.menuItem} ${activeItem === '/dashboard' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/dashboard')}>
                        <DashboardOutlined className={styles.menuIcon}></DashboardOutlined>
                        {isOpen && <Typography className={styles.menuLabel}>Dashboard</Typography>}
                    </div>

                    {(userRole === 'SUPER ADMIN' || userRole === 'ADMIN') && (
                        <div className={styles.menuItem} onClick={() => handleMenuItemClick('/users')}>
                            <img src='/assets/images/users_mngt.png' alt="User  Management" className={styles.menuIcon} />
                            {isOpen && (
                                <Typography variant="body1">
                                    User Management
                                    {isUserManagementOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>
                            )}
                        </div>
                    )}
                    {isUserManagementOpen && userRole === 'SUPER ADMIN' && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/admin' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/admin', event)}>
                                <img src='/assets/images/user.png' alt="Admin" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Admin</Typography>}
                            </div>
                        </div>
                    )}
                    {isUserManagementOpen && (userRole === 'SUPER ADMIN' || userRole === 'ADMIN') && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/member' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/member', event)}>
                                <img src='/assets/images/user.png' alt="Member" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Member</Typography>}
                            </div>
                        </div>
                    )}


                    <div className={`${styles.menuItem} ${activeItem === '/jobs' ? styles.active : ''}`} onClick={handleJobManagementClick}>
                        <BusinessCenterOutlined className={styles.menuIcon}></BusinessCenterOutlined>
                        {isOpen && (
                            <Typography className={styles.menuLabel}>
                                Jobs
                                {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                            </Typography>
                        )}
                    </div>
                    {isJobOpen && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/job-list' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/job-list', event)}>
                                <CasesOutlined className={styles.menuIcon}></CasesOutlined>
                                {isOpen && <Typography className={styles.menuLabel}>Job List</Typography>}
                            </div>
                            <div className={`${styles.menuItem} ${activeItem === '/post-job' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/post-job', event)}>
                                <CardTravelOutlined className={styles.menuIcon}></CardTravelOutlined>
                                {isOpen && <Typography className={styles.menuLabel}>Post New Job</Typography>}
                            </div>
                        </div>
                    )}

                    <div className={`${styles.menuItem} ${activeItem === '/live-tracks' ? styles.active : ''}`}>
                        <LocalShippingOutlined className={styles.menuIcon} />
                        {isOpen && (
                            <Typography className={styles.menuLabel}>
                                Live Tracks
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>
                        )}
                    </div>
                    <div className={`${styles.menuItem} ${activeItem === '/job-action' ? styles.active : ''}`}>
                        <LocalShippingOutlined className={styles.menuIcon} />
                        {isOpen && (
                            <Typography className={styles.menuLabel}>
                                Job Action
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>
                        )}
                    </div>
                    <div className={`${styles.menuItem} ${activeItem === '/legal' ? styles.active : ''}`}>
                        <PolicyOutlined className={styles.menuIcon} />
                        {isOpen && (
                            <Typography className={styles.menuLabel}>
                                Legal
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>
                        )}
                    </div>
                    <div className={`${styles.menuItem} ${activeItem === '/my-ratings' ? styles.active : ''}`}>
                        <StarBorderOutlined className={styles.menuIcon} />
                        {isOpen && (
                            <Typography className={styles.menuLabel}>
                                My Ratings
                                {/* {isJobOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ChevronRightOutlined className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />} */}
                            </Typography>
                        )}
                    </div>



                    {/* <div className={`${styles.menuItem} ${activeItem === '/races' ? styles.active : ''}`} onClick={handleRaceManagementClick}>
                        <img src='/assets/images/carbon_result.png' alt="Race Results" className={styles.menuIcon} />
                        {isOpen && (
                            <Typography variant="body1">
                                Race Management
                                {isRacesOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ExpandMore className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                            </Typography>
                        )}
                    </div>
                    {isRacesOpen && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/race' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/race', event)}>
                                <img src='/assets/images/carbon_result.png' alt="Race" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Race</Typography>}
                            </div>
                            <div className={`${styles.menuItem} ${activeItem === '/result' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/result', event)}>
                                <img src='/assets/images/carbon_result.png' alt="Result" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Result</Typography>}
                            </div>
                        </div>
                    )}

                    <div className={`${styles.menuItem} ${activeItem === '/upcommingrace' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/upcommingrace')}>
                        <img src='/assets/images/maki_racetrack.png' alt="Upcoming Races" className={styles.menuIcon} />
                        {isOpen && <Typography variant="body1">Upcoming Races</Typography>}
                    </div>

                    <div className={`${styles.menuItem} ${activeItem === '/rewards' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/rewards')}>
                        <img src='/assets/images/carbon_result.png' alt="Rewards" className={styles.menuIcon} />
                        {isOpen && <Typography variant="body1">Rewards</Typography>}
                    </div>




                    {
                        userRole === "MEMBER" ? (
                            <div className={`${styles.menuItem} ${activeItem === '/wallet' || activeItem === '/confirm' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/wallet')}>
                                <img src='/assets/images/solar_wallet.png' alt="Wallet" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Wallet</Typography>}
                            </div>
                        ) : null
                    }
                    <div className={`${styles.menuItem} ${activeItem === '/grievances' ? styles.active : ''}`} onClick={() => handleMenuItemClick('/grievances')}>
                        <img src='/assets/images/carbon_rule.png' alt="Grievances" className={styles.menuIcon} />
                        {isOpen && <Typography variant="body1">Grievances Details</Typography>}
                    </div>
                    {isUserManagementOpen && (userRole === 'SUPER ADMIN' || userRole === 'ADMIN') && (
                        <div className={`${styles.menuItem} ${activeItem === '/settings' ? styles.active : ''}`} onClick={toggleSettings}>
                            <img src='/assets/images/solar_settings.png' alt="Settings" className={styles.menuIcon} />
                            {isOpen && (
                                <Typography variant="body1">
                                    Settings
                                    {isSettingsOpen ? <ExpandLess className={`${styles.squeezeArrow} ${styles.arrowPosition}`} /> : <ExpandMore className={`${styles.squeezeArrow} ${styles.arrowPosition}`} />}
                                </Typography>
                            )}
                        </div>
                    )}
                    {isSettingsOpen && (
                        <div className={styles.subMenu}>
                            <div className={`${styles.menuItem} ${activeItem === '/plateformcharges' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/plateformcharges', event)}>
                                <img src='/assets/images/solar_settings.png' alt="PlateformCharges" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Platform Charge</Typography>}
                            </div>
                            <div className={`${styles.menuItem} ${activeItem === '/subscription' ? styles.active : ''}`} onClick={(event) => handleSubMenuClick('/subscription', event)}>
                                <img src='/assets/images/solar_settings.png' alt="Subscription" className={styles.menuIcon} />
                                {isOpen && <Typography variant="body1">Subscription</Typography>}
                            </div>
                        </div>
                    )} */}
                </div>
            </Box>
        </>
    );
};

export default Sidebar;