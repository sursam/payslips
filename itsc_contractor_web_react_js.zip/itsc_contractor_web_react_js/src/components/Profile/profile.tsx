import React, { useEffect, useState } from 'react';
import { api } from '../../utils/api';
import moment from 'moment';
import { FaEdit } from 'react-icons/fa';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import { useNavigate } from 'react-router-dom';
import {
    Avatar,
    Box,
    Grid2,
    Card,
    CardContent,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Typography,
} from '@mui/material';
import 'react-toastify/dist/ReactToastify.css';
import styles from '../../styles/profile.module.css';
import LayoutProvider from '../../providers/LayoutProvider';

interface Profile {
    fname: string;
    lname: string;
    country_code: string;
    mobile: string;
    email: string;
    dob: string;
    address: string;
    days_ago: string;
    my_jobs: string;
    average_rating: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    profile_image: string;
    complete_profile_info: {
        company_legal_name: string;
        company_dba: string;
        phone_2: string;
        tax_id: string;
    };
    country_details: {
        country_id: string;
        country_name: string;
    };

    state_details: {
        state_id: string;
        state_name: string;
    };

    city_details: {
        id: string;
        name: string;
    };
}

const Profile: React.FC = () => {
    const navigate = useNavigate();
    const [profile, setProfile] = useState<Profile>({
        fname: '',
        lname: '',
        country_code: '',
        mobile: '',
        email: '',
        dob: '',
        address: '',
        city: '',
        state: '',
        country: '',
        pincode: '',
        days_ago: '',
        my_jobs: '',
        average_rating: '',
        profile_image: '',
        complete_profile_info: {
            company_legal_name: '',
            company_dba: '',
            phone_2: '',
            tax_id: ''
        },
        country_details: {
            country_id: '',
            country_name: ''
        },
        state_details: {
            state_id: '',
            state_name: ''
        },
        city_details: {
            id: '',
            name: ''
        }
    });

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await api.profile.fetchProfile();
                console.log("Response:", response.user);
                setProfile(response.user);
            } catch (error) {
                console.error("Failed to fetch jobs:", error);
            }
        };

        fetchProfile();
    }, []);
    const handleEditProfile = () => {
        navigate('/profile/edit');
    };
    return (
        <LayoutProvider pageTitle="Profile">
            <Grid2 container spacing={3} sx={{ marginBottom: '20px' }}>
                <Grid2>
                    <CardContent className={styles.gridBoxwrap}>
                        {/* Image Card */}
                        <Card sx={{ borderRadius: 2, boxShadow: 3, width: '100%', height: "700px", py: 2 }}>
                            <div style={{ "position": "relative", }}>
                                <div className={styles.cardTitle} style={{ "height": "200px" }}>
                                    <img
                                        src='/assets/images/profile_background.png'
                                        alt="Profile Background"
                                        style={{
                                            width: '95%',
                                            height: '100%',
                                            borderRadius: '8px',
                                            objectFit: 'cover'
                                        }}
                                    />
                                </div>

                                {/* Profile Summary Card */}
                                <Card className='testingcard' sx={{
                                    borderRadius: 2,
                                    boxShadow: 3,
                                    padding: { xs: 2, md: 4 },
                                    width: '80%',
                                    mx: 'auto',
                                    position: "absolute",
                                    top: "75%",
                                    left: "50%",
                                    transform: "translateX(-50%)",
                                    height: "476px"
                                }}>
                                    <IconButton
                                        sx={{
                                            position: 'absolute',
                                            top: 16,
                                            right: 16,
                                            backgroundColor: '#f0f0f0',
                                            boxShadow: 1,
                                            '&:hover': {
                                                backgroundColor: '#e0e0e0'
                                            }
                                        }}
                                        aria-label="edit profile"
                                        onClick={handleEditProfile}
                                    >
                                        <EditIcon sx={{ color: '#333' }} />
                                    </IconButton>
                                    <Box sx={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        alignItems: 'flex-start',
                                        flexWrap: 'wrap',
                                        gap: 2
                                    }}>
                                        {/* Left: Avatar and Name */}
                                        <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                                            <Avatar
                                                alt="Remy Sharp"
                                                src={profile?.profile_image}
                                                sx={{ width: '100px', height: 100 }}
                                            />
                                            <Box>
                                                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>{profile?.fname + " " + profile?.lname}</Typography>
                                                <Typography variant="body2">Contractor</Typography>
                                            </Box>
                                        </Box>
                                        {/* Member Since */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Member</Typography>
                                            <Typography variant="h6">{profile?.days_ago} Days</Typography>
                                        </Box>

                                        {/* Posted Jobs */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Posted Jobs</Typography>
                                            <Typography variant="h6">{profile?.my_jobs}</Typography>
                                        </Box>

                                        {/* Ratings */}
                                        <Box sx={{ textAlign: 'center' }}>
                                            <Typography variant="body1" fontWeight="bold">Rating</Typography>
                                            <Typography variant="h6">{profile?.average_rating}</Typography>
                                        </Box>
                                    </Box>
                                    <TableContainer sx={{ marginTop: 2, height: "500px" }}>
                                        <Table sx={{
                                            tableLayout: 'fixed',
                                            '& .MuiTableCell-root': {
                                                width: '50%',
                                                height: '30px',
                                                border: '1px solid #ddd',
                                                textAlign: 'center',
                                                verticalAlign: 'middle',
                                                whiteSpace: 'nowrap',
                                                textOverflow: 'ellipsis'
                                            }
                                        }}>
                                            <TableBody>
                                                <TableRow>
                                                    <TableCell>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            flexDirection: 'row',
                                                            alignItems: 'center',
                                                            gap: 2
                                                        }}>
                                                            <Typography sx={{
                                                                fontWeight: 'bold',
                                                                minWidth: '60px'
                                                            }}>
                                                                Email ID:
                                                            </Typography>
                                                            <Typography >
                                                                {profile?.email}
                                                            </Typography>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Date Of Birth:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {moment(profile?.dob).format('MMMM Do YYYY')}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>

                                                <TableRow>
                                                    <TableCell>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            flexDirection: 'row',
                                                            alignItems: 'center',
                                                            gap: 2
                                                        }}>
                                                            <Typography variant="body1" sx={{
                                                                fontWeight: 'bold',
                                                                minWidth: '60px'
                                                            }}>
                                                                Mobile Number:
                                                            </Typography>
                                                            <Typography variant="body1">
                                                                +{profile?.country_code}-{profile?.mobile}
                                                            </Typography>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Company Name:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.complete_profile_info?.company_legal_name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Address:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.address}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Company DBA:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.complete_profile_info?.company_dba}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Country:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.country_details?.country_name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Company Ph No.:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            +{profile?.complete_profile_info?.phone_2}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            State:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.state_details?.state_name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            EIN / TAX ID:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.complete_profile_info?.tax_id}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            City:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.city_details?.name}
                                                        </Typography>
                                                    </Box></TableCell>
                                                    <TableCell><Box sx={{
                                                        display: 'flex',
                                                        flexDirection: 'row',
                                                        alignItems: 'center',
                                                        gap: 2
                                                    }}>
                                                        <Typography variant="body1" sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: '60px'
                                                        }}>
                                                            Zip Code:
                                                        </Typography>
                                                        <Typography variant="body1">
                                                            {profile?.pincode}
                                                        </Typography>
                                                    </Box></TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Card>
                            </div>
                        </Card>
                    </CardContent>
                </Grid2>
            </Grid2>
        </LayoutProvider >
    );
};

export default Profile;