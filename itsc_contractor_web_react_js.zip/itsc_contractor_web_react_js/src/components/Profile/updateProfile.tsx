import React, { useState, useEffect } from 'react';
import { api } from '../../utils/api';
import { TextField, Typography, Box, Autocomplete, Button } from '@mui/material';
import styles from '../../styles/updateProfile.module.css';
import { AccountBoxOutlined } from '@mui/icons-material';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import PhoneInput from 'react-phone-input-2';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import LayoutProvider from '../../providers/LayoutProvider';
interface Profile {
	fname: string;
	lname: string;
	country_code: string;
	mobile: string;
	email: string;
	dob: string;
	address: string;
	days_ago: string;
	my_jobs: string;
	average_rating: string;
	city: string;
	state: string;
	country: string;
	pincode: string;
	profile_image: string;
	complete_profile_info: {
		company_legal_name: string;
		company_dba: string;
		phone_2: string;
		tax_id: string;
	};
	country_details: {
		country_id: string;
		country_name: string;
	};

	state_details: {
		state_id: number;
		state_name: string;
	};

	city_details: {
		id: number;
		name: string;
	};
}
interface UpdateProfileForm {
	firstName: string;
	lastName: string;
	email: string;
	password?: string;
	country_code?: string;
	mobile?: string;
	mobile_number?: string;
	dob: string;
	zipCode: string;
	state: string;
	city: string;
	address: string;
	profileImage?: File | null;
}

interface StateOption {
	label: string;
	id: number;
}

interface CityOption {
	id: number;
	label: string;
}

const UpdateProfile: React.FC = () => {
	const navigate = useNavigate();
	const [isDragging, setIsDragging] = useState<boolean>(false);
	const [imageUrl, setImageUrl] = useState<string>('');
	const [states, setStates] = useState<StateOption[]>([]);
	const [cities, setCities] = useState<CityOption[]>([]);
	const [selectedState, setSelectedState] = useState<StateOption | null>(null);
	const [selectedCity, setSelectedCity] = useState<CityOption | null>(null);
	// Add state for mobile handling
	const [mobileValue, setMobileValue] = useState<string>("");
	const [countryCode, setCountryCode] = useState<string>("");
	const [mobileNumber, setMobileNumber] = useState<string>("");
	const [profile, setProfile] = useState<Profile>({
		fname: '',
		lname: '',
		country_code: '',
		mobile: '',
		email: '',
		dob: '',
		address: '',
		city: '',
		state: '',
		country: '',
		pincode: '',
		days_ago: '',
		my_jobs: '',
		average_rating: '',
		profile_image: '',
		complete_profile_info: {
			company_legal_name: '',
			company_dba: '',
			phone_2: '',
			tax_id: ''
		},
		country_details: {
			country_id: '',
			country_name: ''
		},
		state_details: {
			state_id: 0,
			state_name: ''
		},
		city_details: {
			id: 0,
			name: ''
		}
	});
	// Validation schema
	const validationSchema = Yup.object().shape({
		firstName: Yup.string().required('First name is required'),
		lastName: Yup.string().required('Last name is required'),
		dob: Yup.string().required('Date of birth is required'),
		zipCode: Yup.string().required('Zip code is required'),
		email: Yup.string()
			.required('Email is required')
			.email('Invalid email format'),
		state: Yup.string().required('State is required'),
		city: Yup.string().required('City is required'),
		address: Yup.string().required('Address is required'),
		// profileImage: Yup.mixed()
		// 	.nullable()
		// 	.test('file-size', 'File size must be less than 2MB', (value) => {
		// 		if (!value) return true;
		// 		return (value as File).size <= 2 * 1024 * 1024; // 2MB
		// 	})
		// 	.test('file-type', 'Only image files are allowed', (value) => {
		// 		if (!value) return true;
		// 		return ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'].includes((value as File).type);
		// 	})
	});

	// Form setup with proper default values
	const { register, handleSubmit, control, formState: { errors }, setValue, watch, reset } = useForm<UpdateProfileForm>({
		resolver: yupResolver(validationSchema),
		defaultValues: {
			firstName: '',
			lastName: '',
			email: '',
			mobile: '',
			dob: '',
			zipCode: '',
			state: '',
			city: '',
			address: '',
			profileImage: null
		}
	});
	// Fetch profile data
	useEffect(() => {
		const fetchProfile = async () => {
			try {
				const response = await api.profile.fetchProfile();
				const userData = response.user;
				setProfile(userData);
				// Set form values with fetched data
				setValue('firstName', userData.fname || '');
				setValue('lastName', userData.lname || '');
				setValue('email', userData.email || '');
				setValue('country_code', userData.country_code || '');
				setValue('mobile_number', userData.mobile || '');
				setValue('mobile', userData.mobile || '');
				setValue('dob', userData.dob || '');
				setValue('zipCode', userData.pincode || '');
				setValue('address', userData.address || '');
				setValue('state', userData.state_details?.state_name || '');
				setValue('city', userData.city_details?.name || '');
				// Set mobile data - combine country code and mobile number
				if (userData.country_code && userData.mobile) {
					const fullMobile = userData.country_code + userData.mobile
					setMobileValue(fullMobile)
					setCountryCode(userData.country_code)
					setMobileNumber(userData.mobile)
				}
				// Set profile image if exists
				if (userData.profile_image) {
					setImageUrl(userData.profile_image);
				}
			} catch (error) {
				console.error("Failed to fetch profile:", error);
			}
		};
		fetchProfile();
	}, [setValue]);

	// Get states
	useEffect(() => {
		const getStates = async () => {
			try {
				const payload = { country_code: "US" };
				const response = await api.auth.statesByCountryCode(payload);
				setStates(response.data || []);
			} catch (error) {
				console.error('Failed to fetch states:', error);
			}
		};
		getStates();
	}, []);

	// Set initial state when profile and states are loaded
	useEffect(() => {
		if (profile && states.length > 0 && profile.state_details?.state_id) {
			const initialState = states.find(state => state.id === profile.state_details.state_id);
			if (initialState) {
				setSelectedState(initialState);
			}
		}
	}, [profile, states]);

	// Load cities when state is selected
	useEffect(() => {
		const getCities = async () => {
			if (selectedState?.id) {
				try {
					const payload = { state_id: selectedState.id };
					const response = await api.auth.citiesByStateId(payload);
					setCities(response.data || []);
				} catch (error) {
					console.error('Failed to fetch cities:', error);
					setCities([]);
				}
			} else {
				setCities([]);
				setSelectedCity(null);
			}
		};
		getCities();
	}, [selectedState]);

	// Set initial city when cities are loaded
	useEffect(() => {
		if (profile && cities.length > 0 && profile.city_details?.id) {
			const initialCity = cities.find(city => city.id === profile.city_details.id);
			if (initialCity) {
				setSelectedCity(initialCity);
			}
		}
	}, [profile, cities]);
	//  	
	const onMobileChange = (value: string, data: any) => {
		setMobileValue(value)
		setCountryCode(data.dialCode)
		setMobileNumber(value.slice(data.dialCode.length))

		// Update form values
		setValue("country_code", data.dialCode)
		setValue("mobile", value.slice(data.dialCode.length))
		setValue("mobile_number", value)
	}
	// Handle state change
	const handleStateChange = (event: any, value: StateOption | null) => {
		setSelectedState(value);
		setSelectedCity(null); // Clear city when state changes
	};

	// Handle city change
	const handleCityChange = (event: any, value: CityOption | null) => {
		setSelectedCity(value);
	};

	// File handling
	const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		const file = event.target.files?.[0];
		if (file) {
			setFile(file);
		}
	};

	const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault();
		setIsDragging(true);
	};

	const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault();
	};

	const handleDragLeave = () => {
		setIsDragging(false);
	};

	const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault();
		setIsDragging(false);
		const file = e.dataTransfer.files[0];
		if (file) {
			setFile(file);
		}
	};

	const setFile = (file: File) => {
		if (file) {
			console.log("File:", file);

			setValue('profileImage', file);
			setImageUrl(URL.createObjectURL(file));
		} else {
			setValue('profileImage', null);
			setImageUrl('');
		}
	};

	const onSubmit = async (data: UpdateProfileForm) => {
		console.log("Form submission started");

		try {

			// Create FormData for file upload
			const formData = new FormData();
			formData.append('fname', data.firstName);
			formData.append('lname', data.lastName);
			formData.append('email', data.email);
			formData.append('mobile', mobileNumber || '');
			formData.append('country', countryCode || '');
			formData.append('dob', data.dob);
			formData.append('pincode', data.zipCode);
			formData.append('address', data.address);

			if (selectedState) {
				formData.append('state', selectedState.id.toString());
				// formData.append('stateName', selectedState.label);
			}

			if (selectedCity) {
				formData.append('city', selectedCity.id.toString());
				// formData.append('cityName', selectedCity.label);
			}

			if (data.profileImage) {
				formData.append('profile_image', data.profileImage);
				// console.log(formData.get('profile_image'));
			}

			// Submit to API
			const response = await api.profile.updateProfile(formData);
			if (response?.status) {
				toast.success('profile updated successfully');
				navigate('/profile');
			} else {
				toast.error(response?.message);
			}
		} catch (error) {
			console.error('Error updating profile:', error);
		}
	};

	return (
		<LayoutProvider pageTitle="Profile">
			<Box className={styles.formContainer}>
				<form className="custom-Form" encType="multipart/form-data" onSubmit={handleSubmit(onSubmit)}>
					{/* Profile Image Upload Section */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px", marginBottom: '20px' }}>
						<Box
							className={`${styles.fileUploadContainer} ${isDragging ? styles.dragging : ''}`}
							onDragEnter={handleDragEnter}
							onDragOver={handleDragOver}
							onDragLeave={handleDragLeave}
							onDrop={handleDrop}
						>
							<Typography className={styles.ariaLabel}>
								Profile Image
							</Typography>
							<label htmlFor="file-upload" className={styles.fileUpload} style={{ display: "flex", flexDirection: 'column', alignItems: 'center' }}>
								{imageUrl ? (
									<img
										src={imageUrl}
										className={styles.profileImage}
										alt="Profile Image"
									/>
								) : (
									<AccountBoxOutlined style={{ width: '70px', height: '70px', color: '#AAAAAA' }} />
								)}
								<span>
									Drag and drop an image or{" "}
									<span className="text-primary text-decoration-underline">
										Browse
									</span>
								</span>
							</label>
							<label className={styles.fileFieldContainer}>
								<TextField
									type="file"
									id="file-upload"
									onChange={handleFileChange}
									inputProps={{ accept: 'image/*' }}
									sx={{ display: 'none' }}
								/>
							</label>
						</Box>
					</Box>

					{/* First Name and Last Name */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="First Name"
								variant="outlined"
								fullWidth
								margin="normal"
								error={!!errors?.firstName}
								helperText={!!errors?.firstName}
								className={`${styles.formControl} ${errors?.firstName ? 'is-invalid' : ''}`}
								{...register('firstName')}
							/>
							<div className="invalid-feedback">{errors.firstName?.message?.toString()}</div>
						</Box>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="Last Name"
								variant="outlined"
								fullWidth
								margin="normal"
								error={!!errors?.lastName}
								helperText={!!errors?.lastName}
								className={`${styles.formControl} ${errors?.lastName ? 'is-invalid' : ''}`}
								{...register('lastName')}
							/>
							<div className="invalid-feedback">{errors.lastName?.message?.toString()}</div>
						</Box>
					</Box>
					{/* email and mobile */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="Email"
								variant="outlined"
								fullWidth
								margin="normal"
								type="email"
								error={!!errors?.email}
								helperText={errors?.email?.message}
								{...register('email')}
							/>
						</Box>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<PhoneInput
								country={"us"}
								value={mobileValue} // Show the existing mobile value
								onChange={onMobileChange}
								containerStyle={{ marginTop: "16px", marginBottom: "8px" }}
								inputProps={{
									name: "mobile",
									autoFocus: false,
								}}
								inputStyle={{
									borderColor: errors?.mobile ? "#d32f2f" : "#ccc",
								}}
							/>
							{errors.mobile && <div className="invalid-feedback">{errors.mobile?.message?.toString()}</div>}
						</Box>
					</Box>

					{/* Date of Birth and State */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="Date of Birth"
								variant="outlined"
								fullWidth
								margin="normal"
								type="date"
								error={!!errors?.dob}
								helperText={!!errors?.dob}
								className={`${styles.formControl} ${errors?.dob ? 'is-invalid' : ''}`}
								{...register('dob')}
							/>
						</Box>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<Autocomplete
								options={states}
								getOptionLabel={(option) => option.label}
								isOptionEqualToValue={(option, value) => option.id === value.id}
								value={selectedState}
								onChange={handleStateChange}
								renderInput={(params) => (
									<TextField
										{...params}
										label="State"
										margin="normal"
										error={!!errors?.state}
										helperText={!!errors?.state}
										{...register('state')}
									/>
								)}
								noOptionsText="No state found"
							/>
							<div className="invalid-feedback">{errors.state?.message?.toString()}</div>
						</Box>
					</Box>

					{/* City and Zip Code */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<Autocomplete
								options={cities}
								getOptionLabel={(option) => option.label}
								isOptionEqualToValue={(option, value) => option.id === value.id}
								value={selectedCity}
								onChange={handleCityChange}
								disabled={!selectedState}
								renderInput={(params) => (
									<TextField
										{...params}
										label="City"
										margin="normal"
										error={!!errors?.city}
										helperText={!!errors?.city}
										{...register('city')}
									/>
								)}
								noOptionsText={!selectedState ? "Please select a state first" : "No city found"}
							/>
							<div className="invalid-feedback">{errors.city?.message?.toString()}</div>
						</Box>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="Zip Code"
								variant="outlined"
								fullWidth
								margin="normal"
								value={profile?.pincode}
								error={!!errors?.zipCode}
								helperText={!!errors?.zipCode}
								className={`${styles.formControl} ${errors?.zipCode ? 'is-invalid' : ''}`}
								{...register('zipCode')}
							/>
							<div className="invalid-feedback">{errors.zipCode?.message?.toString()}</div>
						</Box>
					</Box>

					{/* Street Address */}
					<Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "space-between", gap: "30px" }}>
						<Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', marginBottom: '5px' }}>
							<TextField
								label="Street Address"
								variant="outlined"
								fullWidth
								margin="normal"
								value={profile?.address}
								error={!!errors?.address}
								helperText={!!errors?.address}
								className={`${styles.formControl} ${errors?.address ? 'is-invalid' : ''}`}
							/>
							<div className="invalid-feedback">{errors.address?.message?.toString()}</div>
						</Box>
					</Box>

					<Button
						type='submit'
						variant="contained"
						color="primary"
						className={styles.formButton}
						disabled={Object.keys(errors).length > 0}
					>
						Update Profile
					</Button>
				</form>
			</Box>
		</LayoutProvider>
	);
};

export default UpdateProfile;