import React, { useEffect, useState } from 'react';
import { Box, Button, Modal, TextField, IconButton, Menu, MenuItem, Table, TableBody, TableContainer, TableHead, TableRow, Pagination, Stack } from '@mui/material';
import { MoreVert } from '@mui/icons-material'; // Material-UI icon for the dropdown
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import CloseIcon from '@mui/icons-material/Close';
import styles from '../../styles/userList.module.css';
import { useUsers } from '../../context/Users'; // Import the context
import ModeOutlinedIcon from '@mui/icons-material/ModeOutlined';
import DeleteIcon from '@mui/icons-material/Delete';

const MemberList: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [openModal, setOpenModal] = useState(false);
    const [editData, setEditData] = useState(null);
    const [firstName, setFirstName] = useState('');
    const [middleName, setMiddleName] = useState('');
    const [lastName, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [cnfpassword, setCnfPassword] = useState('');
    const [mobile, setMobile] = useState('');
    const [email, setEmail] = useState('');
    const [gender, setGender] = useState('');
    const [dob, setDob] = useState('');
    const [username, setUsername] = useState('');
    const [addressLine1, setAddressLine1] = useState('');
    const [addressLine2, setAddressLine2] = useState('');
    const [city, setCity] = useState('');
    const [state, setState] = useState('');
    const [country, setCountry] = useState('');
    const [zip, setZip] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [errors, setErrors] = useState('');
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null); // For dropdown menu
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10); // Number of rows per page
    const { users, fetchMember, addMember } = useUsers(); // Use the context

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    // const handleOpenModal = () => {
    //     setOpenModal(true);
    //     setEditData(null);
    //     setFirstName('');
    //     setMiddleName('');
    //     setLastName('');
    //     setDob('');
    //     setGender('');
    //     setUsername('');
    //     setPassword('');
    //     setCnfPassword('');
    //     setEmail('');
    //     setMobile('');
    //     setAddressLine1('');
    //     setAddressLine2('');
    //     setCity('');
    //     setState('');
    //     setCountry('');
    //     setZip('');
    //     setErrors('');
    // };

    const handleCloseModal = () => {
        setOpenModal(false);
        setErrors('');
    };

    const handleSubmit = async () => {
        const newErrors: any = {};
        if (!firstName) newErrors.firstName = 'First name is required';
        if (!lastName) newErrors.lastName = 'Last name is required';
        if (!password) newErrors.password = 'Password is required';
        if (password !== cnfpassword) newErrors.cnfpassword = 'Passwords do not match';
        if (!email) newErrors.email = 'Email is required';
        if (!mobile) newErrors.mobile = 'Mobile number is required';

        if (Object.keys(newErrors)?.length > 0) {
            setErrors(newErrors);
            return;
        }

        const payload = {
            first_name: firstName,
            last_name: lastName,
            middle_name: middleName,
            password: password,
            email: email,
            phone_number: mobile,
            date_of_birth: dob,
            user_name: username,
            gender: gender,
            address_line_1: 'kolkata',
            address_line_2: 'New Town',
            city: 'kolkata',
            role: 'MEMBER',
            state: 'West Bengal',
            country: 'India',
            ZIP: '700030',
            contact_label: 'HOME',
            phone_extension: '91',
        };

        await addMember(payload);
        handleCloseModal();
    };

    const handleEditUser = (user: any) => {
        setEditData(user);
        setFirstName(user.first_name);
        setLastName(user.last_name);
        setMiddleName(user.middle_name || ''); // Handle middle name
        setEmail(user.email);
        setMobile(user.mobile);
        setAddressLine1(user.address_line_1);
        setAddressLine2(user.address_line_2);
        setCity(user.city);
        setGender(user.gender);
        setDob(user.date_of_birth);
        setUsername(user.user_name);
        setState(user.state);
        setCountry(user.country);
        setZip(user.zip);
        setOpenModal(true);
    };

    const handleDeleteUser = () => {
        // Implement delete functionality
    };

    useEffect(() => {
        const loadUsers = async () => {
            await fetchMember();
        };
        loadUsers();
    }, [fetchMember]);

    const filteredUsers = users.filter(user => {
        const fullName = `${user.first_name} ${user.last_name}`.toLowerCase();
        return fullName.includes(searchQuery.toLowerCase());
    });

    // Calculate total pages
    const totalPages = Math.ceil(filteredUsers.length / rowsPerPage);

    // Handle page change
    const handleChangePage = (event: React.ChangeEvent<unknown>, value: number) => {
        setPage(value);
    };

    // Calculate the current users to display
    const currentUsers = filteredUsers.slice((page - 1) * rowsPerPage, page * rowsPerPage);


    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                <div className={styles.topsection}>
                    <h3>Member List</h3>
                    <div className={styles.headerRtSide}>
                        <TextField
                            variant="outlined"
                            placeholder="Search Member"
                            onChange={(e) => setSearchQuery(e.target.value)}
                            size="small"
                            sx={{ marginRight: 2 }}
                        />
                    </div>
                </div>

                <div className={styles.customtable}>
                    <TableContainer>
                        <Table className={`${styles.table} table`}>
                            <TableHead>
                                <TableRow>
                                    <th>User ID</th>
                                    <th>Member Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    {/* <th>DOB</th> */}
                                    {/* <th>Actions</th> */}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {currentUsers.map((user) => (
                                    <TableRow key={user._id}>
                                        <td>{user.user_name}</td>
                                        <td>{`${user.first_name} ${user.last_name}`}</td>
                                        <td>{user.email}</td>
                                        <td>{user.phone_number}</td>
                                        {/* <td></td> */}
                                        {/* <td>
                                            <IconButton onClick={(event) => setAnchorEl(event.currentTarget)}>
                                                <MoreVert />
                                            </IconButton>
                                            <Menu
                                                className='siteTableOption'
                                                anchorEl={anchorEl}
                                                open={Boolean(anchorEl)}
                                                onClose={() => setAnchorEl(null)}
                                            >
                                                <MenuItem onClick={() => { handleEditUser(user); setAnchorEl(null); }}><ModeOutlinedIcon fontSize="small" />&nbsp; Edit</MenuItem>
                                                <MenuItem className='deteleBtn' onClick={() => { handleDeleteUser(); setAnchorEl(null); }}><DeleteIcon fontSize="small" />&nbsp; Delete</MenuItem>
                                            </Menu>
                                        </td> */}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
                        <Pagination
                            count={totalPages}
                            page={page}
                            onChange={handleChangePage}
                            color="primary"
                        />
                    </Stack>
                </div>

                <Modal open={openModal} onClose={handleCloseModal}>
                    <Box className={styles.modalBox}
                        sx={{
                            position: 'absolute',
                            top: '50%',
                            right: '0px',
                            transform: 'translateY(-50%)',
                            padding: 2,
                            backgroundColor: 'white',
                            borderRadius: 2,
                            maxHeight: '100%', /* Set a maximum height for the modal */
                            overflowY: 'auto', /* Enable vertical scrolling */
                            maxWidth: '50%',
                        }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h2>{editData ? 'Edit Member' : 'Add Member'}</h2>
                            <IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="First Name"
                                    variant="outlined"
                                    fullWidth
                                    value={firstName}
                                    onChange={(e) => setFirstName(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Last Name"
                                    variant="outlined"
                                    fullWidth
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Middle Name"
                                    variant="outlined"
                                    fullWidth
                                    value={middleName}
                                    onChange={(e) => setMiddleName(e.target.value)}
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Mobile Number"
                                    variant="outlined"
                                    fullWidth
                                    value={mobile}
                                    onChange={(e) => setMobile(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Username"
                                    variant="outlined"
                                    fullWidth
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    variant="outlined"
                                    type='date'
                                    fullWidth
                                    value={dob}
                                    onChange={(e) => setDob(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Password"
                                    variant="outlined"
                                    type="password"
                                    fullWidth
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Confirm Password"
                                    variant="outlined"
                                    type="password"
                                    fullWidth
                                    value={cnfpassword}
                                    onChange={(e) => setCnfPassword(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>
                        <TextField
                            label="Email"
                            variant="outlined"
                            fullWidth
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            sx={{ marginTop: 2 }}
                        />
                        <TextField
                            label="Gender"
                            variant="outlined"
                            fullWidth
                            value={gender}
                            onChange={(e) => setGender(e.target.value)}
                            required
                            sx={{ marginTop: 2 }}
                        />
                        {/* <Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                            <TextField
                                label="Address Line 1"
                                variant="outlined"
                                fullWidth
                                value={addressLine1}
                                onChange={(e) => setAddressLine1(e.target.value)}
                                required
                                sx={{ marginTop: 2 }}
                            />
                            <TextField
                                label="Address Line 2"
                                variant="outlined"
                                fullWidth
                                value={addressLine2}
                                onChange={(e) => setAddressLine2(e.target.value)}
                                sx={{ marginTop: 2 }}
                            />
                        </Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                            <TextField
                                label="City"
                                variant="outlined"
                                fullWidth
                                value={city}
                                onChange={(e) => setCity(e.target.value)}
                                required
                                sx={{ marginTop: 2 }}
                            />
                            <TextField
                                label="State"
                                variant="outlined"
                                fullWidth
                                value={state}
                                onChange={(e) => setState(e.target.value)}
                                required
                                sx={{ marginTop: 2 }}
                            />
                        </Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                            <TextField
                                label="Country"
                                variant="outlined"
                                fullWidth
                                value={country}
                                onChange={(e) => setCountry(e.target.value)}
                                required
                                sx={{ marginTop: 2 }}
                            />
                            <TextField
                                label="ZIP Code"
                                variant="outlined"
                                fullWidth
                                value={zip}
                                onChange={(e) => setZip(e.target.value)}
                                required
                                sx={{ marginTop: 2 }}
                            />
                        </Box> */}
                        <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
                            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>Close</Button>
                            <Button variant="contained" onClick={handleSubmit}>Save changes</Button>
                        </Box>
                    </Box>
                </Modal>
            </Box>
        </Box>
    );
};

export default MemberList;