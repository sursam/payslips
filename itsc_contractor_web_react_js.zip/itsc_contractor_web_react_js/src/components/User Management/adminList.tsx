import React, { useEffect, useState } from 'react';
import { Box, Button, Modal, TextField, IconButton, Menu, MenuItem, Table, TableBody, TableContainer, TableHead, TableRow, Stack, Pagination } from '@mui/material';
import { MoreVert, WidthFull } from '@mui/icons-material'; // Material-UI icon for the dropdown
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import CloseIcon from '@mui/icons-material/Close';
import styles from '../../styles/userList.module.css';
import { useUsers } from '../../context/Users'; // Import the context
import { toast } from 'react-toastify';

import ModeOutlinedIcon from '@mui/icons-material/ModeOutlined';
import DeleteIcon from '@mui/icons-material/Delete';
const UserList: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [openModal, setOpenModal] = useState(false);
    const [userName, setUserName] = useState('');
    const [editData, setEditData] = useState(null);
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [cnfpassword, setCnfPassword] = useState('');
    const [email, setEmail] = useState(''); const [searchQuery, setSearchQuery] = useState('');
    const [errors, setErrors] = useState('');
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null); // For dropdown menu
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10); // Number of rows per page
    const { users, fetchUsers, addUser } = useUsers(); // Use the context

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleOpenModal = () => {
        setOpenModal(true);
        setUserName('');
        setEditData(null);
        setFirstName('');
        setLastName('');
        setPassword('');
        setCnfPassword('');
        setEmail('');
        setErrors('');
    };

    const handleCloseModal = () => {
        setOpenModal(false);
        setErrors('');
    };

    const handleSubmit = async () => {
        const newErrors: any = {};
        if (!firstName) newErrors.firstName = 'First name is required';
        if (!lastName) newErrors.lastName = 'Last name is required';
        if (!password) newErrors.password = 'Password is required';
        if (password !== cnfpassword) newErrors.cnfpassword = 'Passwords do not match';
        if (!email) newErrors.email = 'Email is required';

        if (Object.keys(newErrors)?.length > 0) {
            setErrors(newErrors);
            return;
        }

        const payload = {
            first_name: firstName,
            last_name: lastName,
            password: cnfpassword,
            email: email,
        };

        try {
            await addUser(payload);
            toast.success("User added successfully!");
            handleCloseModal();
            await fetchUsers();
        } catch (error) {
            toast.error("Error adding/updating user.");
        }
    };

    const handleEditUser = (user: any) => {
        setEditData(user);
        setFirstName(user.first_name);
        setLastName(user.last_name);
        setEmail(user.email);
        setOpenModal(true);
    };

    const handleDeleteUser = () => {
        // setUserList(userList.filter(user => user.id !== userId));
    };

    useEffect(() => {
        const loadUsers = async () => {
            await fetchUsers();
        };
        loadUsers();
    }, [fetchUsers]);

    const filteredUsers = users.filter(user => {
        const fullName = `${user.first_name} ${user.last_name}`.toLowerCase();
        return fullName.includes(searchQuery.toLowerCase());
    });

    // Handle pagination change
    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage - 1); // Convert to 0-based index
    };


    // Handle rows per page change
    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0); // Reset to the first page
    };

    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>

                <div className={styles.topsection}>
                    <h3>Admin List</h3>
                    <div className={styles.headerRtSide}>
                        <TextField
                            variant="outlined"
                            placeholder="Search Admin"
                            onChange={(e) => setSearchQuery(e.target.value)}
                            size="small"
                            sx={{ marginRight: 2 }}
                        />
                        <Button variant="contained" onClick={handleOpenModal}>
                            Add Admin
                        </Button>
                    </div>
                </div>

                <div className={styles.customtable}>
                    <TableContainer>
                        <Table className={`${styles.table} table`}>
                            <TableHead>
                                <TableRow>
                                    <th>Sl No.</th>
                                    {/* <th>User Name</th> */}
                                    <th>Admin Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    {/* <th>DOB</th> */}
                                    {/* <th>Actions</th> */}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((user, index) => (
                                    <TableRow key={user._id}>
                                        <td>{page * rowsPerPage + index + 1}</td>
                                        {/* <td>{user.user_name ?? "---"}</td> */}
                                        <td>{`${user.first_name} ${user.last_name}`}</td>
                                        <td>{user.phone_number}</td>
                                        <td>{user.email}</td>
                                        {/* <td></td> */}
                                        {/* <td>
                                            <IconButton onClick={(event) => setAnchorEl(event.currentTarget)}>
                                                <MoreVert />
                                            </IconButton>
                                            <Menu
                                                className='siteTableOption'
                                                anchorEl={anchorEl}
                                                open={Boolean(anchorEl)}
                                                onClose={() => setAnchorEl(null)}
                                            >
                                                <MenuItem onClick={() => { handleEditUser(user); setAnchorEl(null); }}><ModeOutlinedIcon fontSize="small" />&nbsp; Edit</MenuItem>
                                                <MenuItem className='deteleBtn' onClick={() => { handleDeleteUser(); setAnchorEl(null); }}><DeleteIcon fontSize="small" />&nbsp; Delete</MenuItem>
                                            </Menu>
                                        </td> */}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <Stack spacing={2} sx={{ marginTop: 2, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
                        <Pagination
                            count={Math.ceil(filteredUsers.length / rowsPerPage)} // Calculate total pages
                            page={page + 1} // MUI Pagination is 1-based
                            onChange={handleChangePage}
                            color="primary"
                        />
                    </Stack>
                </div>

                <Modal open={openModal} onClose={handleCloseModal}>
                    <Box className={styles.modalBox}
                        sx={{
                            position: 'absolute',
                            top: '50%',
                            right: '0px',
                            transform: 'translateY(-50%)',
                            padding: 2,
                            backgroundColor: 'white',
                            borderRadius: 2,
                            height: '100%',
                        }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h2>{editData ? 'Edit Admin' : 'Add Admin'}</h2>
                            <IconButton onClick={handleCloseModal} sx={{ color: 'gray' }}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="First Name"
                                    variant="outlined"
                                    fullWidth
                                    value={firstName}
                                    onChange={(e) => setFirstName(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Last Name"
                                    variant="outlined"
                                    fullWidth
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>

                        <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Password"
                                    variant="outlined"
                                    type="password"
                                    fullWidth
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>

                            <Box className={styles.detailsWrap}>
                                <TextField
                                    label="Confirm Password"
                                    variant="outlined"
                                    type="password"
                                    fullWidth
                                    value={cnfpassword}
                                    onChange={(e) => setCnfPassword(e.target.value)}
                                    required
                                    sx={{ marginTop: 2 }}
                                />
                            </Box>
                        </Box>

                        <TextField
                            label="Email"
                            variant="outlined"
                            fullWidth
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            sx={{ marginBottom: 0, marginTop: 3 }}
                        />
                        <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'right' }}>
                            <Button variant="contained" sx={{ marginRight: 1 }} onClick={handleCloseModal}>Close</Button>
                            <Button variant="contained" onClick={handleSubmit}>Save changes</Button>
                        </Box>
                    </Box>
                </Modal>
            </Box>
        </Box>
    );
};

export default UserList;