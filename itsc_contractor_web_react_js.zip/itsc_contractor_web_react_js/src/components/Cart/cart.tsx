import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Paper, TextField } from '@mui/material';
import Header from '../Header/header';
import Sidebar from '../Sidebar/sidebar';
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import styles from '../../styles/dogList.module.css';
import { useDog } from '../../context/DogContext';
import { toast } from 'react-toastify';
import { Navigate, useNavigate } from 'react-router-dom';

const CartPage: React.FC = () => {
    const { fetchCartItems, deleteCartItem, updateCartItem, placeOrder } = useDog();
    const [cartItems, setCartItems] = useState<any[]>([]);
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [showBillingAddress, setShowBillingAddress] = useState(false);
    const [billingInfo, setBillingInfo] = useState<{
        billing_name: string;
        billing_address: string;
        country: string;
        state: string;
        city: string;
        member_ObjectId: string;
    }>({
        billing_name: '',
        billing_address: '',
        country: 'AUSTRALIA',
        state: '',
        city: '',
        member_ObjectId: '', // Added member_ObjectId to the billingInfo state
    });

    const navigate = useNavigate(); // Initialize navigation

    const toggleSidebar = () => {
        setSidebarOpen(!isSidebarOpen);
    };

    const handleCheckout = () => {
        if (cartItems.length > 0) {
            setShowBillingAddress(true);
        } else {
            toast.error('Your cart is empty. Please add items to the cart before checking out.');
        }
    };

    const handleRemoveFromCart = async (cartId: string) => {
        await deleteCartItem(cartId);
    };

    const handleAddToCart = (index: number) => {
        const updatedCart = cartItems.map((cartItem, i) => {
            if (i === index) {
                return { ...cartItem, unit_qty: cartItem.unit_qty + 1 };
            }
            return cartItem;
        });
        setCartItems(updatedCart);
    };

    useEffect(() => {
        const loadCartItems = async () => {
            const items = await fetchCartItems();
            if (items.length > 0) {
                setCartItems(items);
            }
        };
        loadCartItems();
    }, [fetchCartItems]);

    const totalPrice = cartItems.reduce((total, item) => total + (item.unit_price * item.unit_qty), 0);
    const tax = 0.00; // Assuming tax is fixed for now
    const platformCharges = 0.00; // Assuming platform charges are fixed for now
    const payableAmount = totalPrice + tax + platformCharges;

    const handleUpdateCart = async (cartId: string, newQuantity: number) => {
        try {
            if (newQuantity < 1) {
                await deleteCartItem(cartId);
                toast.success('Item removed from cart!');
            } else {
                await updateCartItem(cartId, newQuantity);
                toast.success('Cart updated successfully!');
            }

            const updatedCartItems = await fetchCartItems();
            setCartItems(updatedCartItems);
        } catch (error) {
            console.error('Error updating cart:', error);
            toast.error('Failed to update cart. Please try again!');
        }
    };

    const validateBillingInfo = () => {
        const { billing_name, billing_address, country, state, city } = billingInfo;
        if (!billing_name || !billing_address || !country || !state || !city) {
            toast.error('Please fill in all required fields.');
            return false;
        }
        return true;
    };

    const handlePlaceOrder = async () => {
        if (validateBillingInfo()) {
            const orders = cartItems.map(item => ({
                dog_ObjectId: item.dog_ObjectId._id, // Use the dog ID from the API response
                unit_qty: item.unit_qty,
                unit_price: item.unit_price,
                total_unit_price: item.total_price // Use the total price from the API response
            }));
            console.log("orders", orders);

            // Extract member_ObjectId from the first cart item
            const memberObjectId = cartItems[0]?.member_ObjectId?._id;
            console.log("memberObjectId_-----------------", memberObjectId);

            if (!memberObjectId) {
                toast.error('Member information is missing.');
                return;
            }

            try {
                await placeOrder({
                    member_ObjectId: memberObjectId,
                    orders,
                    total_price: totalPrice,
                    tax,
                    platformCharges,
                    paybleAmount: payableAmount,
                    billing_name: billingInfo.billing_name,
                    billing_address: billingInfo.billing_address,
                    country: billingInfo.country,
                    state: billingInfo.state,
                    city: billingInfo.city,
                });

                setCartItems([]); // Clear cart items after successful order
                setShowBillingAddress(false); // Hide billing address form
                toast.success('Order placed successfully!'); // Show success message before navigating
                navigate('/profile'); // Navigate on success 🚀   
            } catch (error) {
                console.error('Error placing order:', error);
                toast.error('Failed to place order. Please try again!');
            }
        }
    };


    return (
        <Box className={styles.container}>
            <Sidebar isOpen={isSidebarOpen} />
            <Header isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
            <Box className={styles.BodyWrap} sx={{ display: 'flex', marginLeft: isSidebarOpen ? '250px' : '60px', padding: '20px', transition: 'margin-left 0.3s' }}>
                <Box className={styles.cartbody} sx={{ marginRight: '20px' }}>
                    <h3 className={styles.summaryTtl}>Total Items ({
                        cartItems.map(item => item.unit_qty).reduce((a, b) => a + b, 0)})</h3>
                    {cartItems.length === 0 ? (
                        <div className={styles.noItemsWrap}>
                            <div className={styles.noItemstham}>
                                <img src="/assets/images/empty-cart.png" alt="empty cart" />
                            </div>
                            <Typography className={styles.noitemsTtl} variant="h6">No items in cart</Typography>
                        </div>
                    ) : (
                        cartItems.map((item, index) => (
                            item.unit_qty >= 1 ? (
                                <Box key={item._id} sx={{ display: 'flex', alignItems: 'center', marginBottom: '20px', borderBottom: '1px dashed #ccc', paddingBottom: '10px', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', borderRadius: '5px', padding: '10px' }}>
                                    <Box sx={{ border: '2px solid #ccc', borderRadius: '50%', overflow: 'hidden', width: '80px', height: '80px', marginRight: '20px' }}>
                                        <img
                                            src={item.dog_ObjectId.img[0]} // Use the image URL from the API response
                                            alt={`Dog ${item.dog_ObjectId ? item.dog_ObjectId.dog_name : 'Unknown'}`}
                                            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                        />
                                    </Box>
                                    <Box sx={{ flex: 1 }}>
                                        <Typography variant="body1" sx={{ fontWeight: 'bold', marginBottom: '5px' }}>Dog ID: {item.dog_ObjectId ? item.dog_ObjectId.dog_id : 'N/A'}</Typography>
                                        <Typography variant="body2" sx={{ marginBottom: '5px' }}>Dog Name: {item.dog_ObjectId ? item.dog_ObjectId.dog_name : 'N/A'}</Typography>
                                        <Typography variant="body2" sx={{ marginBottom: '5px' }}>Quantity: {item.unit_qty}</Typography>
                                        <Typography variant="body2" sx={{ marginBottom: '5px' }}>Unit Price: ${item.unit_price}</Typography>
                                        <Typography variant="body2" sx={{ marginBottom: '5px' }}>Total Price: ${item.unit_price * item.unit_qty}</Typography>
                                    </Box>
                                    <Box sx={{ display: 'flex', alignItems: 'center', marginLeft: '20px' }}>
                                        <div key={item._id}>
                                            <Button sx={{ marginLeft: '5px' }}
                                                variant="outlined"
                                                color="error"
                                                onClick={() => handleUpdateCart(item._id, item.unit_qty - 1)}
                                            >
                                                <RemoveIcon />
                                            </Button>
                                            <span style={{ margin: "10px" }}>{item.unit_qty}</span>
                                            <Button sx={{ marginRight: '5px' }}
                                                variant="outlined"
                                                onClick={() => handleUpdateCart(item._id, item.unit_qty + 1)}
                                            >
                                                <AddIcon />
                                            </Button>
                                        </div>
                                    </Box>
                                </Box>
                            ) : null
                        ))
                    )}

                    {showBillingAddress && (
                        <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '50px', borderBottom: '1px dashed #ccc', paddingBottom: '10px', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', borderRadius: '5px', padding: '10px' }}>
                            <Box sx={{ flex: 1 }}>
                                <Typography variant="h6" sx={{ fontWeight: 'bold', marginBottom: '10px' }}>
                                    Billing Address
                                </Typography>
                                <form>
                                    <TextField
                                        label="Billing Name"
                                        fullWidth
                                        sx={{ marginBottom: '10px' }}
                                        value={billingInfo.billing_name}
                                        onChange={(e) => setBillingInfo({ ...billingInfo, billing_name: e.target.value })}
                                    />
                                    <Box sx={{ display: 'flex', gap: 2, marginBottom: '10px' }}>
                                        <TextField
                                            label="Country"
                                            sx={{ flex: 1 }}
                                            value={billingInfo.country}
                                            onChange={(e) => setBillingInfo({ ...billingInfo, country: e.target.value })}
                                        />
                                        <TextField
                                            label="State"
                                            sx={{ flex: 1 }}
                                            value={billingInfo.state}
                                            onChange={(e) => setBillingInfo({ ...billingInfo, state: e.target.value })}
                                        />
                                    </Box>

                                    <Box sx={{ display: 'flex', gap: 2, marginBottom: '10px' }}>
                                        <TextField
                                            label="City"
                                            sx={{ flex: 1 }}
                                            value={billingInfo.city}
                                            onChange={(e) => setBillingInfo({ ...billingInfo, city: e.target.value })}
                                        />
                                        <TextField
                                            label="Zipcode"
                                            sx={{ flex: 1 }}
                                        />
                                    </Box>

                                    <TextField
                                        label="Address"
                                        fullWidth
                                        multiline
                                        rows={3}
                                        sx={{ marginBottom: '10px' }}
                                        value={billingInfo.billing_address}
                                        onChange={(e) => setBillingInfo({ ...billingInfo, billing_address: e.target.value })}
                                    />
                                </form>
                            </Box>
                        </Box>
                    )}

                </Box>
                <Paper className={styles.cartPrice} sx={{
                    borderRadius: '16px',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                    background: 'linear-gradient(to right, #f8f9fa, #e9ecef)',
                    padding: '15px',
                    maxWidth: '350px',
                    margin: 'auto'
                }}>
                    <h3 className={styles.cartsummary} style={{
                        textAlign: 'center',
                        fontWeight: 'bold',
                        fontSize: '22px',
                        color: '#333'
                    }}>
                        🛒 Summary
                    </h3>
                    <Box sx={{ marginTop: '20px' }}>
                        {[
                            { label: 'Price', value: totalPrice.toFixed(2) },
                            { label: 'Tax', value: tax.toFixed(2) },
                            { label: 'Platform Charges', value: platformCharges.toFixed(2) },
                        ].map((item, index) => (
                            <div key={index} className={styles.cartitems} style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '5px 0',  // Reduced spacing
                                fontSize: '15px',
                                fontWeight: '500',
                                color: '#555',
                                marginBottom: '2px !important',
                                lineHeight: 1.2 /* Tightened line height */

                            }}>
                                <p>{item.label}</p>
                                <span style={{
                                    fontWeight: 'bold',
                                    color: '#222',
                                    marginRight: '5px',
                                    marginBottom: '12px',
                                    fontSize: '17px' // Slightly larger value
                                }}>
                                    ${item.value}
                                </span>
                            </div>
                        ))}

                        {/* Payable Amount - Highlighted */}
                        <div className={styles.cartitems} style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: '10px 10px',
                            fontSize: '18px',
                            fontWeight: 'bold',
                            color: '#1976d2',
                            borderTop: '2px solid #ddd',
                            marginTop: '15px',
                            marginBottom: '5px',
                        }}>
                            <p style={{ width: '100%' }}>Payable Amount</p>
                            <span style={{ marginBottom: '15px' }}>${payableAmount.toFixed(2)}</span>
                        </div>
                    </Box>

                    {/* Checkout Buttons */}
                    {!showBillingAddress ? (
                        <Button variant="contained" className={styles.cart_continuebtn} color="primary" onClick={handleCheckout} disabled={cartItems.length === 0} sx={{
                            width: '100%',
                            marginTop: '12px',
                            fontSize: '15px',
                            borderRadius: '10px',
                            '&:hover': { backgroundColor: '#1558b0' }
                        }}>
                            Check Out
                        </Button>
                    ) : (
                        <Button variant="contained" className={styles.cart_continuebtn} color="secondary" onClick={handlePlaceOrder} disabled={cartItems.length === 0} sx={{
                            width: '100%',
                            marginTop: '12px',
                            fontSize: '15px',
                            borderRadius: '10px',
                            '&:hover': { backgroundColor: '#d32f2f' }
                        }}>
                            Place Order
                        </Button>
                    )}
                </Paper>


            </Box>
        </Box>
    );
};

export default CartPage;
