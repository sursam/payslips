export interface walletrecharge {
	member_id: string | null;
	wallet_amount: any;
}

export interface transUpdate {
	id: string | null;
	payment_status: string;
}

export interface transDetails {
	member_id: string | null;
}

export interface PaymentOption {
	mode: "payment" | "setup" | "subscription"; // Specific string literal type
	amount: number;
	currency: string;
	clientSecret: string; // Ensure this is just string
}
export interface CheckoutFormProps {
	id: string;
	stripeData: any;
}
export interface SubscriptionType {
	member_id: string | null;
	subscription_id: string | null;
	price: number;
}
export interface Subscription {
	_id: string;
	name: string;
}
export interface SubscriptionListResponse {
	subscription: Subscription[];
}
export interface VerifyPaymentType {
	status: string;
	member_id: string;
	paymentIntent_id: string;
	payment_respons: {
		id: string;
		object: string;
		amount: number;
		amount_capturable: number;
		amount_received: number;
		application: string | null;
	};
}
export interface TransactionResponse {
	data: {
		message: string;
		data: [];
	};
}
export interface UsePaginationTypes {
	totalCount: number;
	pageSize: number;
	siblingCount?: number;
	currentPage: number;
}
export interface RowData {
	transaction_date: string;
	amount: number;
	transaction_status: string;
	payment_status: string;
	// status: string;
	payment_type: string;
}
export interface AdminSubscription {
	name: string;
	price: number;
	type: string;
	duration: number;
	description: string;
}

export interface PlatformType {
	name: string;
	value: number;
	description: string;
}

export type EmailVerificationType = "forgotemail" | "otp" | "password" | "email";
export interface VerificationPayload {
	type: EmailVerificationType;
	email: string;
	role?: string;
	otp?: string;
	password?: string;
	confirmPassword?: string;
}

export interface AnnouncementType {
	_id?: string;
	subject: string;
	date: string; // Ensure this line is present
	description: string;
	link?: string | undefined;
	image?: File | undefined; // URL for the uploaded image if provided by API
	createdAt?: string;
}
