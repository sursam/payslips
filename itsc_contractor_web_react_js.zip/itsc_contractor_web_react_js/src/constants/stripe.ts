export const STRIPE_PAYMENT_STATUS = {
	success: "SUCCESS",
	failed: "FAILED",
	pending: "PENDING",
	cancelled: "CANCELLED"
};
