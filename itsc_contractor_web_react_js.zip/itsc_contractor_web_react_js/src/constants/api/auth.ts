const auth = {
	Authorization: "Authorization",
	Bearer: `Bearer ${localStorage.getItem("@jwt")}`
};

export const AUTHORIZATION = auth;
