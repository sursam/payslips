import {
	fetchAnnouncements,
	addAnnouncement,
	editAnnouncement,
	deleteAnnouncement,
	fetchNotifications
} from "./announcement";

export const Announcement = {
	fetchAnnouncements,
	addAnnouncement,
	editAnnouncement,
	deleteAnnouncement,
	fetchNotifications
};
