import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { MESSAGE } from "../../../constants/api/message";

const { get, post, put, del } = request;
const { Authorization, Bearer } = AUTHORIZATION;

const initialRoute = "announcement_v2";

interface AnnouncementCreatePayload {
	subject: string;
	date?: string; // Add this line
	description: string;
	link?: string;
	image?: File; // image file for add (optional)
}

interface AnnouncementUpdatePayload {
	subject: string;
	date?: string; // Add this line
	description: string;
	link?: string;
}

export const fetchAnnouncements = async () => {
	try {
		const endpoint = `${initialRoute}/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { result } = response?.data;
			return result;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.message.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const addAnnouncement = async (_payload: AnnouncementCreatePayload) => {
	try {
		const formData = new FormData();
		formData.append("subject", _payload.subject);
		if (_payload.date) formData.append("date", _payload.date);
		formData.append("description", _payload.description);
		if (_payload.link) formData.append("link", _payload.link);
		if (_payload.image) formData.append("image", _payload.image);

		const endpoint = `${initialRoute}/add`;
		const payload = formData;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.CREATED) {
			return response;
		}
	} catch (error: any) {
		if (error.response.message === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.message === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const editAnnouncement = async (id: string, _payload: AnnouncementUpdatePayload) => {
	try {
		const endpoint = `${initialRoute}/update/${id}`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await put(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.message === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.message === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const deleteAnnouncement = async (id: string) => {
	try {
		const endpoint = `${initialRoute}/delete/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await del(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.message === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.message === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const fetchNotifications = async (id: string) => {
	try {
		const endpoint = `notifaction/send-notifaction-list/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.message === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.message === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
