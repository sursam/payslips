import { getRaceResultList, getUpcomingRace, getTotalCount, getmemberCount, getownerCount } from "./dashboard";

export const dashboard = {
	getRaceResultList,
	getUpcomingRace,
	getTotalCount,
	getmemberCount,
	getownerCount
};
