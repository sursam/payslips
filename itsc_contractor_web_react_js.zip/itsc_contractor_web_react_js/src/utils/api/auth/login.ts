/* eslint-disable arrow-parens */
import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { number, string } from "yup";
const { get, post } = request;
const { Authorization, Bearer } = AUTHORIZATION;

// const initialRoute = "auth";

export type LoginTypes = {
	email: string;
	password: string;
	device_type: number;
	device_token: string;
	fcm_token: string;
};
export type MobileLoginTypes = {
	country_code: number;
	mobile: string;
	device_type: number;
	device_token: string;
};
export type LoginVerificationTypes = {
	mobile: string;
	otp: number;
};
export type StateTypes = {
	country_code: string;
};
export type CityTypes = {
	state_id: number;
};

export const login = async (_payload: LoginTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `email-login`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { token, user } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role,
					completedSteps: user.completed_steps,
					profileImage: user.profile_image
				};

				localStorage.setItem("@jwt", token);
				localStorage.setItem("completedSteps", user.completed_steps);
				user.completed_steps === 4 && localStorage.setItem("userDetails", JSON.stringify(userDetails));
				return { status, message, userDetails };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const mobileLogin = async (_payload: MobileLoginTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `login-with-phone`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { verification_code } = response.data.data;
				return { status, message, verification_code };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const countries = async () => {
	try {
		const endpoint = `countries`;
		const response = await get(endpoint, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const statesByCountryCode = async (_payload: StateTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `states-by-country`;
		// console.log(endpoint);
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const citiesByStateId = async (_payload: CityTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `cities-by-state`;
		// console.log(endpoint);
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status === true) {
				const { status, data } = response.data;
				return { status, data };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const loginVerification = async (_payload: LoginVerificationTypes) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `verify-otp`;
		const response = await post(endpoint, payload, headers);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status } = response.data;
				const { token, user, message } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role,
					completedSteps: user.completed_steps,
					profileImage: user.profile_image
				};
				localStorage.setItem("@jwt", token);
				localStorage.setItem("userDetails", JSON.stringify(userDetails));
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
