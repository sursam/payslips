/* eslint-disable arrow-parens */
import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
// import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { VerificationPayload } from "../../../types";
import { toast } from "react-toastify";
const { post, get } = request;
const { Authorization, Bearer } = AUTHORIZATION;

const initialRoute = "auth";
interface ChangePassword {
	email: string;
	oldPassword: string;
	newPassword: string;
	confirmPassword: string;
}
export const signupVerification = async (_payload: VerificationPayload) => {
	try {
		const endpoint = `${initialRoute}/email-verification-with-password-change`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const checkEmailOrPhoneExists = async (_payload: any) => {
	try {
		const endpoint = `email-or-phone-exist`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers
		};
		const response = await post(endpoint, payload, authHeaders);
		console.log("response", response);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const registerUser = async (_payload: any) => {
	console.log("payload", _payload);

	try {
		// const payload = JSON.stringify(_payload);
		const endpoint = `registration`;
		const authHeaders = {
			...headers,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				const { token, user } = response.data.data;
				const userDetails = {
					id: user.id,
					firstName: user.fname,
					lastName: user.lname,
					email: user.email,
					mobile: user.mobile,
					userRole: user.user_role
				};
				localStorage.setItem("@jwt", token);
				localStorage.setItem("userDetails", JSON.stringify(userDetails));
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const addCompanyDetails = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `add-professional-details`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const updatePaymentTerms = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	console.log("payload", _payload);

	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `update-payment-terms`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			toast.error(message);

			// alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			toast.error(message);
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const fetchProfile = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		// 	setUser(null); // Clear user state if no token
		throw new Error("No token found");
	}
	try {
		const endpoint = `${initialRoute}/get-profile`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { userDetails } = response?.data?.result;
			return {
				first_name: userDetails.first_name || "",
				middle_name: userDetails.middle_name || "",
				last_name: userDetails.last_name || "",
				phone_number: userDetails.phone_number || "",
				email: userDetails.email || "",
				date_of_birth: userDetails.date_of_birth || null,
				user_name: userDetails.user_name || "",
				gender: userDetails.gender || "",
				address_line_1: userDetails.address_line_1 || "",
				address_line_2: userDetails.address_line_2 || "",
				city: userDetails.city || "",
				state: userDetails.state || "",
				country: userDetails.country || "",
				ZIP: userDetails.ZIP || "",
				contact_label: userDetails.contact_label || "",
				phone_extension: userDetails.phone_extension || "",
				profilePicture: null, // Handle profile picture separately if needed
				role: userDetails.role || ""
			};
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const updateProfile = async (_payload: FormData) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `${initialRoute}/update-profile`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const changePassword = async (
	// email: string,
	// oldPassword: string,
	// newPassword: string,
	// confirmPassword: string
	_payload: ChangePassword
) => {
	const token = localStorage.getItem("@jwt"); // Retrieve the token from local storage
	if (!token) {
		throw new Error("No token found"); // Handle case where token is not available
	}

	try {
		const endpoint = `${initialRoute}/password-change`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const fetchDogs = async () => {
	try {
		const endpoint = `member/dog/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const logout = async () => {
	try {
		const endpoint = `logout`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		console.log(authHeaders);
		const response = await get(endpoint, authHeaders);

		if (response) {
			if (response.data.status === true) {
				// console.log(response);
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
