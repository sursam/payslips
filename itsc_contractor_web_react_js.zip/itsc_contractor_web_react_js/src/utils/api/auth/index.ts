import { login, mobileLogin, loginVerification, countries, statesByCountryCode, citiesByStateId } from "./login";
import { getProfile } from "./profile";
import { forgotPassword, otpVerification, resetPassword } from "./forgotPassword";
import {
	signupVerification,
	checkEmailOrPhoneExists,
	registerUser,
	addCompanyDetails,
	updatePaymentTerms,
	fetchProfile,
	updateProfile,
	changePassword,
	logout
} from "./signup";

export const auth = {
	login,
	logout,
	mobileLogin,
	loginVerification,
	signupVerification,
	checkEmailOrPhoneExists,
	registerUser,
	addCompanyDetails,
	updatePaymentTerms,
	fetchProfile,
	updateProfile,
	changePassword,
	countries,
	statesByCountryCode,
	citiesByStateId,
	forgotPassword,
	otpVerification,
	resetPassword,
	getProfile
};
