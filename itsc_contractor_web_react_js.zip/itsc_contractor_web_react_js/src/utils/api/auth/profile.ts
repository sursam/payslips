import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";

const { get, post } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getProfile = async () => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `my-profile`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);

		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
		throw new Error();
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};
export const updateProfile = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `update-profile`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`,
			"Content-Type": "multipart/form-data"
		};
		const response = await post(endpoint, _payload, authHeaders);
		if (response) {
			console.log(response);

			if (response.status) {
				const userDetails = {
					id: response.data.data.user.id,
					firstName: response.data.data.user.fname,
					lastName: response.data.data.user.lname,
					email: response.data.data.user.email,
					mobile: response.data.data.user.mobile_number,
					userRole: response.data.data.user.user_role,
					completedSteps: response.data.data.user.completed_steps,
					profileImage: response.data.data.user.profile_image
				};
				localStorage.setItem("userDetails", JSON.stringify(userDetails));
				const { status, message } = response.data;
				return { status, message };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const changePassword = async (_payload: any) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	const endpoint = `chnge-password`;
	const authHeaders = {
		...headers,
		[Authorization]: `Bearer ${token}`
	};
	const response = await post(endpoint, _payload, authHeaders);
	if (response) {
		if (response.data.status) {
			const { status, message } = response.data;
			return { status, message };
		} else {
			const { status, message } = response.data;
			return { status, message };
		}
	}
};
