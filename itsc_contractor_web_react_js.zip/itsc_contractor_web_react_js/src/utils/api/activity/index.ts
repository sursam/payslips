import { getBanners } from "./activity";

export const activity = { getBanners };
