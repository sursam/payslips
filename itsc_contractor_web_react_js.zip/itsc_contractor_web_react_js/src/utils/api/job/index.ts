import {
	getActiveJobs,
	getMaterialTypeList,
	getLoadTypeList,
	getEquipmentTypeList,
	getTruckTypeList,
	getMyJobs
} from "./job";

export const job = {
	getMaterialTypeList,
	getLoadTypeList,
	getEquipmentTypeList,
	getTruckTypeList,
	getMyJobs,
	getActiveJobs
};
