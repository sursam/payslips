import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export const getActiveJobs = async (payload: any) => {
	console.log("payload", payload);

	try {
		const endpoint = `active-job-cordinates`;
		const response = await post(endpoint, payload, headers);
		if (response) {
			if (response.data.status) {
				const { data } = response.data;
				return data;
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		throw error;
	}
};
export const getMyJobs = async (status: number, currentDateTime: string, page: number) => {
	const token = localStorage.getItem("@jwt");
	if (!token) {
		throw new Error("No token found");
	}
	try {
		const endpoint = `contractor/manage-job?status=${status}&currentDateTime=${currentDateTime}&page=${page}`;
		const authHeaders = {
			...headers,
			[Authorization]: `Bearer ${token}`
		};
		const response = await get(endpoint, authHeaders);
		if (response) {
			if (response.data.status === true) {
				console.log(response.data);
				const { status, message, data, pagination } = response.data;
				return { data, pagination };
			} else {
				const { status, message } = response.data;
				return { status, message };
			}
		}
	} catch (error: any) {
		console.log("Error", error);
		if (error?.response?.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else if (error?.response?.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;
			return { message };
			// alert(message);
		} else {
			throw error;
		}
	}
};

export const getMaterialTypeList = async () => {
	try {
		const endpoint = `materials`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getLoadTypeList = async () => {
	try {
		const endpoint = `load-types`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getEquipmentTypeList = async () => {
	try {
		const endpoint = `equipments`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
export const getTruckTypeList = async () => {
	try {
		const endpoint = `truck-types`;
		const response = await get(endpoint, headers);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
