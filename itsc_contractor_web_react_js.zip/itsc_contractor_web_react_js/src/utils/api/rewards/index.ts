import { addReward, deleteReward, fetchRewardById, getRaceWiseDogList, getRewardList, updateReward } from "./rewardList";

export const reward = {
	addReward,
	getRewardList,
	updateReward,
	deleteReward,
	fetchRewardById,
	getRaceWiseDogList,
};
