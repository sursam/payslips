import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { MESSAGE } from "../../../constants/api/message";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { toast } from "react-toastify";
import { Message } from "@mui/icons-material";
const { post, get, put, del } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export type RewardCreatePayload = {
    raceId: string; // Ensure raceId is included
    dogId: string;
    rewardType: string;
    description: string;
    points: number;
};


export const addReward = async (payload: RewardCreatePayload): Promise<{ message: string; result: any; } | null> => {
    try {
        const endpoint = `win-price/distribution-rewards/`;
        const authHeaders = {
            ...headers,
            Authorization: Bearer, // Ensure token is correctly formatted
            'Content-Type': 'application/json', // Set content type to JSON
        };

        // Ensure correct POST structure
        const response = await post(endpoint, payload, authHeaders); // Serialize payload to JSON

        if (response?.data?.message === MESSAGE.post.succ) {
            return {
                message: response.data.message,
                result: response.data.result,
            };
        }

        throw new Error("Unexpected API response");
    } catch (error: any) {
        console.error("API Error:", error);

        if (error.response?.status === StatusCodes.BAD_REQUEST) {
            toast(error.response.data?.message || "Bad Request Error");
            return null;
        }

        throw error;
    }
};



// Function to fetch race list
export const getRewardList = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `win-price/reward-all-list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const getRaceWiseDogList = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/race-wise-dog-list/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.post.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Update Race**
export const updateReward = async (id: string, payload: RewardCreatePayload): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/edit/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await put(endpoint, payload, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === "Race updated successfully!") {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Delete Race**
export const deleteReward = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `reward/delete/${id}`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await del(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === "Race deleted successfully!") {
			return {
				message: response.data.message,
				result: response.data.result,
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

// **Fetch Race by ID**
export const fetchRewardById = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `race/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === "Race fetched successfully!") {
			return {
				message: response.data.message,
				result: response.data.result[0],
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};