import { addRace, deleteRace, fetchRaceById, getRaceList, updateRace } from "./raceList";

export const race = {
	addRace,
	getRaceList,
	updateRace,
	deleteRace,
	fetchRaceById
};
