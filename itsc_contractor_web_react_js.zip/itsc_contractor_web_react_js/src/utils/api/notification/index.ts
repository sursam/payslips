import { getNotifications } from "./notification";

export const notification = { getNotifications };
