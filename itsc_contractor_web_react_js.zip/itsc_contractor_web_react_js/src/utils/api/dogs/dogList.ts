import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { toast } from "react-toastify";
import { MESSAGE } from "../../../constants/api/message";
import { Message } from "@mui/icons-material";
const { post, get, put, del, fetch, patch } = request;
const { Authorization, Bearer } = AUTHORIZATION;

export type DogPayload = {
	name: string;
	dateOfBirth: string;
	gender: string;
	color: string;
	breedS: string;
	breedD: string;
	ownerId: string;
	trainerId: string;
	price: number;
	file?: File;
};

export const fetchDogList = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `member/dog/list`;
		const authHeaders = {
			...headers,
			Authorization: Bearer // Ensure correct Bearer token format
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result
			};
		}

		throw new Error("Unexpected API response structure");
	} catch (error: any) {
		console.error("API Error:", error);
		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}
		throw error;
	}
};

export const addDog = async (formData: FormData): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `dog/details/add`;

		const authHeaders = {
			...headers,
			Authorization: Bearer,
			"Content-Type": "multipart/form-data"
		};

		const response = await post(endpoint, formData, authHeaders);

		if (response?.data?.message === MESSAGE.post.succ) {
			toast.success(response.data.message);
			return {
				message: response.data.message,
				result: response.data.result,
				// token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response format or missing data.");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast.error(error.response.data?.message || "Bad Request Error");
			return null;
		}
        toast.error(error.message || "An error occurred while adding the dog.");

		return null;
	}
};

export const getDogList = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `dog/details/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			// toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const fetchDogById = async (id: string): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `member/dog/details`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		const response = await put(endpoint, id, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const updateDog = async (
	dogId: string,
	dogData: FormData
): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `dog/details/update/${dogId}`;

		const authHeaders = {
			...headers,
			[Authorization]: Bearer,
			"Content-Type": "multipart/form-data"
		};

		// Ensure 'content-type' is removed to allow proper FormData submission
		if ("content-type" in authHeaders) {
			delete authHeaders["content-type"];
		}

		const response = await put(endpoint, dogData, authHeaders);

		if (response?.data?.message === MESSAGE.put.succ) {
			toast.success(response.data.message);
			return {
				message: response.data.message,
				result: response.data.result,
				// token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}
        toast.error(error.message || "An error occurred while updating the dog.");
		throw error;
	}
};

export const changeDogStatus = async (
	dogId: string,
	status: string
): Promise<{ message: string; result: any; token: string } | null> => {
	try {
		const endpoint = `dog/details/status-update/${dogId}`;

		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		// Ensure 'content-type' is removed to allow proper FormData submission
		if ("content-type" in authHeaders) {
			delete authHeaders["content-type"];
		}

		const response = await put(endpoint, status, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const deleteDog = async (dogId: string): Promise<{ message: string; result: any; token: string } | null> => {
	try {
		const endpoint = `dog/details/delete/${dogId}`;

		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		// Ensure 'content-type' is removed to allow proper FormData submission
		if ("content-type" in authHeaders) {
			delete authHeaders["content-type"];
		}

		const response = await del(endpoint, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const addToCart = async (
	memberId: string,
	dogId: string,
	quantity: number,
	unitPrice: number
): Promise<{ message: string; result: any; token: string } | null> => {
	try {
		const endpoint = `add-to-cart/add-dogs`;

		const payload = {
			member_id: memberId,
			dog_id: dogId,
			quantity: quantity,
			unit_price: unitPrice
		};

		const authHeaders = {
			...headers,
			Authorization: Bearer
		};

		const response = await post(endpoint, payload, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const updateCartItem = async (
	memberId: string,
	dogId: string,
	quantity: number,
	unitPrice: number
): Promise<{ message: string; result: any; token: string } | null> => {
	try {
		const endpoint = `add-to-cart/update-cart-item`;

		const payload = {
			member_id: memberId,
			dog_id: dogId,
			quantity: quantity,
			unit_price: unitPrice
		};

		const authHeaders = {
			...headers,
			Authorization: Bearer
		};

		const response = await patch(endpoint, payload, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const fetchCartItems = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `member/dog/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);
		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}
		throw error;
	}
};

export const deleteCartItem = async (
	dogId: string
): Promise<{ message: string; result: any; token: string } | null> => {
	try {
		const endpoint = `dog/details/delete/${dogId}`;

		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		// Ensure 'content-type' is removed to allow proper FormData submission
		if ("content-type" in authHeaders) {
			delete authHeaders["content-type"];
		}

		const response = await del(endpoint, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};

export const purchaseDog = async (_payload: any) => {
	try {
		const endpoint = `order/purches-dogs`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			Authorization: Bearer
		};

		const response = await post(endpoint, payload, authHeaders);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result,
				token: response.data.result.token
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const getMemberDogsList = async (): Promise<{ message: string; result: any } | null> => {
	try {
		const endpoint = `member/dog/my-list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};

		const response = await get(endpoint, authHeaders);
		console.log("API Response:", response);

		if (response?.data?.message === MESSAGE.get.succ) {
			return {
				message: response.data.message,
				result: response.data.result
			};
		}

		throw new Error("Unexpected API response");
	} catch (error: any) {
		console.error("API Error:", error);

		if (error.response?.status === StatusCodes.BAD_REQUEST) {
			toast(error.response.data?.message || "Bad Request Error");
			return null;
		}

		throw error;
	}
};