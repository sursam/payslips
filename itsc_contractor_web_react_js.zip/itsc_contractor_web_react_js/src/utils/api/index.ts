import { auth } from "./auth";
import { settings } from "./settings";
import { Wallet } from "./wallet";
import { race } from "./race";
import { Announcement } from "./announcement";
import { dogs } from "./dogs";
import { reward } from "./rewards";
import { result } from "./results";
import { dashboard } from "./dashboard";
import { job } from "./job";
import { notification } from "./notification";
import { activity } from "./activity";
import { getProfile, updateProfile, changePassword } from "./auth/profile";
import { getActiveJobs } from "./job/job";

export const api = {
	auth: {
		login: auth.login,
		logout: auth.logout,
		mobileLogin: auth.mobileLogin,
		loginVerification: auth.loginVerification,
		signupVerification: auth.signupVerification,
		checkEmailOrPhoneExists: auth.checkEmailOrPhoneExists,
		registerUser: auth.registerUser,
		addCompanyDetails: auth.addCompanyDetails,
		updatePaymentTerms: auth.updatePaymentTerms,
		fetchProfile: auth.fetchProfile,
		updateProfile: auth.updateProfile,
		changePassword: auth.changePassword,
		countries: auth.countries,
		statesByCountryCode: auth.statesByCountryCode,
		citiesByStateId: auth.citiesByStateId,
		forgotPassword: auth.forgotPassword,
		otpVerification: auth.otpVerification,
		resetPassword: auth.resetPassword
	},
	job: {
		getActiveJobs: job.getActiveJobs,
		getMyJobs: job.getMyJobs,
		getMaterialTypeList: job.getMaterialTypeList,
		getLoadTypeList: job.getLoadTypeList,
		getEquipmentTypeList: job.getEquipmentTypeList,
		getTruckTypeList: job.getTruckTypeList
	},
	settings: {
		getSubscriptionList: settings.getSubscriptionList,
		createAdminSubscription: settings.createAdminSubscription,
		editSubscription: settings.editSubscription,
		updateSubscription: settings.updateSubscription,
		addupdate: settings.addupdate,
		editPlatform: settings.editPlatform,
		getSettingsList: settings.getSettingsList,
		subscriptionPaymentReceived: settings.subscriptionPaymentReceived,
		createSubscription: settings.createSubscription
	},
	Wallet: {
		walletDetails: Wallet.walletDetails,
		walletRecharge: Wallet.walletRecharge,
		transactionUpdate: Wallet.transactionUpdate,
		transactionDetails: Wallet.transactionDetails,
		paymentReceived: Wallet.paymentReceived,
		transactionList: Wallet.transactionList
	},
	race: {
		addRace: race.addRace,
		getRaceList: race.getRaceList,
		updateRace: race.updateRace,
		deleteRace: race.deleteRace,
		fetchRaceById: race.fetchRaceById
	},
	Announcement: {
		fetchAnnouncements: Announcement.fetchAnnouncements,
		addAnnouncement: Announcement.addAnnouncement,
		editAnnouncement: Announcement.editAnnouncement,
		deleteAnnouncement: Announcement.deleteAnnouncement,
		fetchNotifications: Announcement.fetchNotifications
	},
	dogs: {
		addDog: dogs.addDog,
		getDogList: dogs.getDogList,
		fetchDogList: dogs.fetchDogList,
		updateDog: dogs.updateDog,
		fetchDogById: dogs.fetchDogById,
		changeDogStatus: dogs.changeDogStatus,
		deleteDog: dogs.deleteDog,
		addToCart: dogs.addToCart,
		updateCartItem: dogs.updateCartItem,
		fetchCartItems: dogs.fetchCartItems,
		deleteCartItem: dogs.deleteCartItem,
		purchaseDog: dogs.purchaseDog,
		getMemberDogsList: dogs.getMemberDogsList
	},
	reward: {
		addReward: reward.addReward,
		getRewardList: reward.getRewardList,
		updateReward: reward.updateReward,
		deleteReward: reward.deleteReward,
		fetchRewardById: reward.fetchRewardById,
		getRaceWiseDogList: reward.getRaceWiseDogList
	},
	result: {
		addResult: result.addResult,
		getResultList: result.getResultList,
		updateResult: result.updateResult,
		deleteResult: result.deleteResult,
		fetchResultById: result.fetchResultById
	},
	dashboard: {
		getRaceResultList: dashboard.getRaceResultList,
		getUpcomingRace: dashboard.getUpcomingRace,
		getTotalCount: dashboard.getTotalCount,
		getownerCount: dashboard.getownerCount,
		getmemberCount: dashboard.getmemberCount
	},
	profile: {
		fetchProfile: getProfile,
		updateProfile: updateProfile,
		changePassword: changePassword
	},
	notifications: {
		fetchNotifications: notification.getNotifications
	},
	activity: {
		fetchActivity: activity.getBanners
	}
};
