import { StatusCodes } from "http-status-codes";
import { request } from "../api";
import { headers } from "../../../config/config";
import { AUTHORIZATION } from "../../../constants/api/auth";
import { MESSAGE } from "../../../constants/api/message";
import { AdminSubscription, PlatformType, SubscriptionType } from "../../../types";

const { get, post, put } = request;
const { Authorization, Bearer } = AUTHORIZATION;

const initialRoute = "subscription";
const initialRouteSetting = "setting";

export const getSubscriptionList = async () => {
	try {
		const endpoint = `${initialRoute}/list`;
		const response = await get(endpoint, headers);

		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			const { subscription } = data;
			return subscription;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const createAdminSubscription = async (_payload: AdminSubscription) => {
	try {
		const payload = JSON.stringify(_payload);
		const endpoint = `${initialRoute}/create`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.CREATED) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const editSubscription = async (id: string, _payload: AdminSubscription) => {
	try {
		const endpoint = `${initialRoute}/edit/${id}`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await put(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			return data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const updateSubscription = async (id: string, _payload: AdminSubscription) => {
	try {
		const endpoint = `${initialRoute}/update/${id}`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await put(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const addupdate = async (_payload: PlatformType) => {
	try {
		const endpoint = `${initialRouteSetting}/add-update`;
		const payload = JSON.stringify(_payload);
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await post(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			const { result } = data;
			return { result };
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const editPlatform = async (type: string) => {
	try {
		const endpoint = `${initialRouteSetting}/edit/platform-charges`;
		const payload = type;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await put(endpoint, payload, authHeaders);
		if (response?.status === StatusCodes.OK) {
			return response.data.data;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const getSettingsList = async () => {
	try {
		const endpoint = `${initialRouteSetting}/list`;
		const authHeaders = {
			...headers,
			[Authorization]: Bearer
		};
		const response = await get(endpoint, authHeaders);
		if (response?.status === StatusCodes.OK) {
			const { data } = response;
			const { setting } = data;
			return setting;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const subscriptionPaymentReceived = async (_payload: any, id: string) => {
	try {
		const endpoint = `transaction/verify-subscription-payment/${id}`;
		const payload = JSON.stringify(_payload);

		const response = await put(endpoint, payload, headers);
		if (response?.status === StatusCodes.OK) {
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};

export const createSubscription = async (_payload: SubscriptionType) => {
	try {
		const endpoint = `member/subscription/create`;
		const payload = JSON.stringify(_payload);

		const response = await post(endpoint, payload, headers);
		if (response?.status === StatusCodes.CREATED) {
			console.log("createSubscription", { response });
			return response;
		}
	} catch (error: any) {
		if (error.response.status === StatusCodes.BAD_REQUEST) {
			const { message } = error.response.data;

			alert(message);
		} else if (error.response.status === StatusCodes.UNAUTHORIZED) {
			const { message } = error.response.data;

			alert(message);
		} else {
			throw error;
		}
	}
};
