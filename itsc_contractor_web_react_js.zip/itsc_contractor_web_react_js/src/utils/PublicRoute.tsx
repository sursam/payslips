import React, { ReactNode } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PublicRoute: React.FC = () => {
    const { user } = useAuth();
    const token = localStorage.getItem('@jwt'); // Check for token in local storage
    const completedSteps = localStorage.getItem('completedSteps');
    // console.log(!completedSteps ? true : false);

    return (!user && !token && !completedSteps) ? <Outlet /> : <Navigate to="/dashboard" />;
};

export default PublicRoute;