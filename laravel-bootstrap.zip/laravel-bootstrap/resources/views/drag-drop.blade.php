<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Trezo - Laravel Admin Dashboard Template</title>
        <!-- Styles -->
        @include('partials.styles')
    </head>
    <body class="boxed-size">
        @include('partials.preloader')
        @include('partials.sidebar')

        <div class="container-fluid">
			<div class="main-content d-flex flex-column">
				<!-- Start Header Area -->
				@include('partials.header')
				<!-- End Header Area -->

				<div class="main-content-container overflow-hidden">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                        <h3 class="mb-0">Drag & Drop</h3>

                        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                            <ol class="breadcrumb align-items-center mb-0 lh-1">
                                <li class="breadcrumb-item">
                                    <a href="#" class="d-flex align-items-center text-decoration-none">
                                        <i class="ri-home-4-line fs-18 text-primary me-1"></i>
                                        <span class="text-secondary fw-medium hover">Dashboard</span>
                                    </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <span class="fw-medium">Extra Pages</span>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <span class="fw-medium">Drag & Drop</span>
                                </li>
                            </ol>
                        </nav>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                            <div class="card bg-white border-0 rounded-3 mb-4">
                                <div class="card-body p-4 pb-0">
                                    <h4 class="fs-18 mb-4">Grid Drag & Drop</h4>
                                    <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="preview-tab" data-bs-toggle="tab" data-bs-target="#preview-tab-pane" type="button" role="tab" aria-controls="preview-tab-pane" aria-selected="true">Preview</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="code-tab" data-bs-toggle="tab" data-bs-target="#code-tab-pane" type="button" role="tab" aria-controls="code-tab-pane" aria-selected="false">Code</button>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="preview-tab-pane" role="tabpanel" aria-labelledby="preview-tab" tabindex="0">
                                            <div class="row js-grid cursor-move">
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-body border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-secondary border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-success border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-danger border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-warning border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-info border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-light border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6">
                                                    <div class="card bg-dark border-0 rounded-3 mb-4 text-center bg-for-dark-mode">
                                                        <div class="card-body p-5">
                                                            <h4 class="fs-18 fw-semibold mb-0 text-white">Drog & Drop Me</h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="code-tab-pane" role="tabpanel" aria-labelledby="code-tab" tabindex="0">
                                            <button class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0" data-clipboard-target="#basicAlertsCode">
                                                Copy
                                            </button>
<pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode">
&lt;div class="row js-grid cursor-move"&gt;
    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-body border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-secondary border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-success border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-danger border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-warning border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-info border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-light border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;

    &lt;div class="col-lg-3 col-sm-6"&gt;
        &lt;div class="card bg-dark border-0 rounded-3 mb-4 text-center"&gt;
            &lt;div class="card-body p-5"&gt;
                &lt;h4 class="fs-18 fw-semibold mb-0 text-white"&gt;Drog &amp; Drop Me&lt;/h4&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;
</code>
</pre>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card bg-white border-0 rounded-3 mb-4">
                                <div class="card-body p-4">
                                    <h4 class="fs-18 mb-4">List Drag & Drop</h4>
                                    <ul class="nav nav-tabs mb-4" id="myTab2" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="preview2-tab" data-bs-toggle="tab" data-bs-target="#preview2-tab-pane" type="button" role="tab" aria-controls="preview2-tab-pane" aria-selected="true">Preview</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="code2-tab" data-bs-toggle="tab" data-bs-target="#code2-tab-pane" type="button" role="tab" aria-controls="code2-tab-pane" aria-selected="false">Code</button>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent2">
                                        <div class="tab-pane fade show active" id="preview2-tab-pane" role="tabpanel" aria-labelledby="preview2-tab" tabindex="0">
                                            <ul class="ps-0 mb-0 list-unstyled o-sortable cursor-move">
                                                <li class="bg-body p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-dark">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-primary p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-secondary p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-success p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-danger p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-warning p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-info p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-light p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                                <li class="bg-dark p-4 rounded-2 mb-3">
                                                    <span class="fs-16 fw-semibold text-white">Drag & Drop Me</span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="tab-pane fade" id="code2-tab-pane" role="tabpanel" aria-labelledby="code2-tab" tabindex="0">
                                            <button class="btn btn-outline-primary bg-white btn-sm copy-btn position-absolute top-0 end-0" data-clipboard-target="#basicAlertsCode2">
                                                Copy
                                            </button>
<pre class="line-numbers pt-0 pb-0 ps-25 pe-25 mb-0">
<code class="language-markup" id="basicAlertsCode2">
&lt;ul class="ps-0 mb-0 list-unstyled o-sortable cursor-move"&gt;
    &lt;li class="bg-body p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-dark"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-primary p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-secondary p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-success p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-danger p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-warning p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-info p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-light p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
    &lt;li class="bg-dark p-4 rounded-2 mb-3"&gt;
        &lt;span class="fs-16 fw-semibold text-white"&gt;Drag &amp; Drop Me&lt;/span&gt;
    &lt;/li&gt;
&lt;/ul&gt;
</code>
</pre>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

				<div class="flex-grow-1"></div>

				<!-- Start Footer Area -->
				@include('partials.footer')
				<!-- End Footer Area -->
			</div>
		</div>

        
        @include('partials.theme_settings')
        @include('partials.scripts')
    </body>
</html>
