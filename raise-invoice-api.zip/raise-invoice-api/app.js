const express = require("express");
const app = express();
// const axios = require("axios");
const morgan = require("morgan")
const cors = require("cors");
const session = require('express-session');
const errorMiddleware = require("./src/middleware/error");
const cookieParser = require("cookie-parser");
const expressFileUpload = require("express-fileupload");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
// const path = require("path");
// const cron = require("node-cron");
// const moment = require('moment-timezone');
// const dateFns = require('date-fns');
const oneYear = 1000 * 60 * 60 * 24 * 365;

// app.use(express.json({ limit: "50mb" }))


app.use(express.json());
// app.use(express.urlencoded({ limit: "50mb", extended: true }))
app.use(
  express.urlencoded({
    extended: true,
  })
);

app.use(cookieParser());
app.use(expressFileUpload({ parseNested: true }));
app.use(cors());
app.use(session({
  secret: "53536311secrctekeyfhgfgrfrty0687564rw3234e5659884fwir764",
  saveUninitialized: true,
  cookie: { maxAge: oneYear },
  resave: false
}));
app.use(
  helmet({
    crossOriginResourcePolicy: false,
    contentSecurityPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginEmbedderPolicy: true,
  })
);

// app.use('./public/uploads', express.static('uploads'))

// =================== express-rate-limit ===================
const limiter = rateLimit({
  windowMs: 1 * 1000, // 1 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP, please try again later."
});
app.use(limiter);
// ========== error handling for rateLimit exceeded ============
app.use((err, req, res, next) => {
  if (err instanceof rateLimit.RateLimitError) {
    // Handle rate limit exceeded error
    res.status(429).send("Rate limit exceeded");
  } else {
    next(err);
  }
});
// ========== error handling for rateLimit exceeded ============
// =================== express-rate-limit ===================

// ======= use the route files here =======
app.use("/", require("./src/routes/apiRoute"));
app.use("/", require("./src/routes/authenticationRoute"));
app.use("/", require("./src/routes/userRoute"));
app.use("/", require("./src/routes/cmsRoute"));
app.use("/", require("./src/routes/pricingPlanRoute"));

app.use("/", require("./src/routes/testimonialRoute"));
app.use("/", require("./src/routes/ourTeamRoute"));
app.use("/", require("./src/routes/faqRoute"));
app.use("/", require("./src/routes/jobRoute"));
app.use("/", require("./src/routes/contactRoute"));

app.use("/", require("./src/routes/pageRoute"));
app.use("/", require("./src/routes/blockRoute"));

app.use("/", require("./src/routes/menuRoute"));

app.use("/", require("./src/routes/userHomeRoute"));
app.use("/", require("./src/routes/rolePermissionRoute"));
app.use("/", require("./src/routes/settingsRoute"));
app.use("/api/v1", require("./src/routes/accountRoute"));
app.use("/api/v1", require("./src/routes/invoiceRoute"));
app.use("/api/v1", require("./src/routes/itemsRoute"));
app.use("/api/v1", require("./src/routes/services/clientadmin/clientInvoiceRoute"));
app.use("/api/v1", require("./src/routes/services/clientadmin/addExpenseRoute"));
app.use('/api/v1', require('./src/routes/services/clientadmin/rolesRoute'));

app.use('/', require('./src/routes/homeRoute'));
// ======= use the route files here =======

// ======= API route files here =======
app.use('/api/v1/common', require('./src/routes/services/commonRoute'));
app.use('/api/v1/home', require('./src/routes/services/homeRoute'));
// ======= API route files here =======

// ======= API route files here =======
app.use('/api/v1/clients', require('./src/routes/services/clientadmin/authRoute'));
app.use('/api/v1/main', require('./src/routes/services/clientadmin/clientRoute'));
app.use('/api/v1/main', require('./src/routes/services/clientadmin/clientProjectRoute'));

// ======= API route files here =======

/*************** Morgan Log Configuration ****************/
if (process.env.APP_ENV == 'production') {
  app.use(morgan('combined'));
}
if (process.env.APP_ENV == 'development') {
  // app.use(morgan("combined"));
}

// app.use('src/public/uploads', express.static('uploads'));

app.use(errorMiddleware);
app.use('/uploads', express.static('src/public/uploads/'));
app.use('/images', express.static('src/public/images/'));
app.use('/projectimages', express.static('src/public/projectimages/'));

module.exports = app;
