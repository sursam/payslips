const { Sequelize } = require('sequelize');
const ClientAdminModel = require('../models/clientModel');
const RoleModel = require('../models/roleModel');
const UserRoleModel = require('../models/usersRoleModel');
const usersPermissionModel = require('../models/usersPermissionModel');
const UserCompanyModel = require('../models/userCompanyModel');
const ModulesModel = require('../models/modulesModel');
const PermissionModel = require('../models/permissionModel');
const ClientModel = require('../models/raiseClientModel');
const ClientContactModel = require('../models/raiseClientContactModel');
const ClientOtherModel = require('../models/raiseClientOthersModel');

const PlanModel = require('../models/planModel');
const PlanPriceModel = require('../models/planPriceModel');
const UserSubscriptionModel = require('../models/userSubscriptionsModel');

const connectSpecificToDatabase = async (dbName, dbUser, dbPassword, dbHost, dbPort) => {
    const sequelize2 = new Sequelize(dbName, dbUser, dbPassword, {
        dialect: 'mysql',
        host: dbHost,
        port: dbPort,
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    });

    const ClientAdmin = ClientAdminModel(sequelize2, Sequelize);
    const RoleModelClient = RoleModel(sequelize2, Sequelize);
    const UserRoleModelClient = UserRoleModel(sequelize2, Sequelize);
    const usersPermissionModelClient = usersPermissionModel(sequelize2, Sequelize);
    const PermissionModelClient = PermissionModel(sequelize2, Sequelize);
    const UserCompanyModelClient = UserCompanyModel(sequelize2, Sequelize);
    const ModulesModelClient = ModulesModel(sequelize2, Sequelize);
    const ClientRaiseModel = ClientModel(sequelize2, Sequelize);
    const ClientRaiseContactModel = ClientContactModel(sequelize2, Sequelize);
    const ClientRaiseOtherModel = ClientOtherModel(sequelize2, Sequelize);

    const ClientPlanModel = PlanModel(sequelize2, Sequelize);
    const ClientPlanPriceModel = PlanPriceModel(sequelize2, Sequelize);
    const ClientSubscriptionModel = UserSubscriptionModel(sequelize2, Sequelize);

    // Set up associations
    ClientRaiseModel.associate({ ClientContact: ClientRaiseContactModel, ClientOther: ClientRaiseOtherModel });
    ClientRaiseContactModel.associate({ Client: ClientRaiseModel });
    ClientRaiseOtherModel.associate({ Client: ClientRaiseModel });

    await sequelize2.authenticate();
    console.log(`Connected to database: ${dbName}`);

    await sequelize2.sync({ alter: true });

    return { sequelize2, ClientAdmin, RoleModelClient, UserRoleModelClient, usersPermissionModelClient, PermissionModelClient, UserCompanyModelClient, ModulesModelClient, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel, ClientPlanModel, ClientPlanPriceModel, ClientSubscriptionModel };
};

module.exports = { connectSpecificToDatabase }; 