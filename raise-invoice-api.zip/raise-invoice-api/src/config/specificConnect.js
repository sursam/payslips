const { Sequelize } = require('sequelize');
const connectionCache = new Map();

const modelDefinitions = {
    ClientAdmin: require('../models/client/clientAdminModel'),
    Role: require('../models/client/roleModel'),
    Roles: require('../models/client/raiseRoleModel'),
    UserRole: require('../models/client/usersRoleModel'),
    UserPermission: require('../models/client/usersPermissionModel'),
    UserCompany: require('../models/client/userCompanyModel'),
    Module: require('../models/client/modulesModel'),
    Permission: require('../models/client/permissionModel'),
    RolePermission: require('../models/client/rolesPermissionModel'),

    Client: require('../models/client/raiseClientModel'),
    ClientContact: require('../models/client/raiseClientContactModel'),
    ClientOther: require('../models/client/raiseClientOthersModel'),
    Plan: require('../models/client/planModel'),
    PlanPrice: require('../models/client/planPriceModel'),

    Subscription: require('../models/client/userSubscriptionsModel'),
    UserLanguage: require('../models/client/userLanguageModel'),
    CompanyTaxSecurity: require('../models/client/companyTaxSecurityModel'),

    CompanyAppointment: require('../models/client/clientAppointmentModel'),

    CompanyProject: require('../models/client/clientProjectModel'),
    ProjectContacts: require('../models/client/projectContactModel'),
    ProjectFiles: require('../models/client/projectFilesModel'),
    ProjectTimes: require('../models/client/projectTimeModel'),
    ProjectTasks : require('../models/client/projectTaskModel'),

    TaxRates: require('../models/client/taxRatesModel'),
    Items: require('../models/client/itemsModel'),
    Transactions: require('../models/client/transactionsModel'),

    Invoice: require('../models/client/clientInvoiceModel'),
    InvoiceSetting : require('../models/client/invoiceSettingModel'),
    InvoiceOptionSetting : require('../models/client/invoiceOptionSettingModel'),
    Expense: require('../models/client/addExpenseModel'),
    LanguageSetting: require('../models/client/languageModel'),
    CommunicationSetting: require('../models/client/communicationSettingModel'),
    ProjectSetting: require('../models/client/projectSettingModel')
};

const getPoolConfig = () => ({
    max: process.env.NODE_ENV === 'production' ? 15 : 5,
    min: process.env.NODE_ENV === 'production' ? 5 : 0,
    acquire: 30000,
    idle: 10000,
    evict: process.env.NODE_ENV === 'production' ? 60000 : 30000
});

const initializeModels = (sequelize) => {
    const models = {};
    for (const [modelName, definer] of Object.entries(modelDefinitions)) {
        models[modelName] = definer(sequelize, Sequelize.DataTypes);
    }
    return models;
};

const configureAssociations = (models) => {
    // Client associations
    models.Client.associate({
        ClientContact: models.ClientContact,
        ClientOther: models.ClientOther
    });

    // Contact associations
    models.ClientContact.associate({
        Client: models.Client
    });

    // Other client associations
    models.ClientOther.associate({
        Client: models.Client
    });

    // Expense associations
    models.Expense.associate({
        CompanyProject: models.CompanyProject
    });

    // Project associations
    models.CompanyProject.associate({
        Expense: models.Expense
    });

    // ClientAdmin associations
    models.Role.belongsToMany(models.ClientAdmin, {
        through: models.UserRole, // Name of the junction table
        foreignKey: 'userId',
        otherKey: 'roleId',
        as: 'userRole'
    });
    models.ClientAdmin.belongsToMany(models.Role, {
        through: models.UserRole, // Name of the junction table
        foreignKey: 'userId',
        otherKey: 'roleId',
        as: 'userRole'
    });
};

const initializeDatabase = async (sequelize) => {
    // Check if the migrations table exists
    // const [results, metadata] = await sequelize.query("SHOW TABLES LIKE 'migrations'");

    // if (results.length == 0) {
    //     // Migrations table does not exist, so we need to sync
    //     console.log('Syncing database for the first time in production mode...');
    //     // await sequelize.sync({ alter: true, logging: console.log });
    // await sequelize.sync();

    //     // Create the migrations table to indicate that the database has been initialized
    //     await sequelize.query(`
    //         CREATE TABLE migrations (
    //             id INT AUTO_INCREMENT PRIMARY KEY,
    //             initialized_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    //         )
    //     `);
    //     console.log('Database synchronized and migrations table created.');
    // } else {
    //     console.log('Database already initialized. Skipping sync.');
    // }
};

const connectSpecificToDatabase = async (dbName, dbUser, dbPassword, dbHost, dbPort) => {
    const cacheKey = `${dbName}|${dbHost}|${dbPort}`;

    // Return cached connection if available and healthy
    if (connectionCache.has(cacheKey)) {
        const cached = connectionCache.get(cacheKey);
        if (await validateConnection(cached.sequelize)) {
            return cached;
        }
        connectionCache.delete(cacheKey);
    }

    // Create new optimized connection
    const sequelize = new Sequelize(dbName, dbUser, dbPassword, {
        dialect: 'mysql',
        host: dbHost,
        port: dbPort,
        logging: process.env.NODE_ENV === 'development' ? console.log : false,
        retry: {
            match: [/Deadlock/i, /Timeout/i],
            max: 3
        },
        pool: getPoolConfig(),
        dialectOptions: process.env.NODE_ENV === 'production' ? {
            ssl: { rejectUnauthorized: true }
        } : {}
    });

    try {
        // Connection validation
        await sequelize.authenticate({ logging: false });

        // Model initialization
        const models = initializeModels(sequelize);

        // Initialize the database
        await initializeDatabase(sequelize);

        // Association configuration
        configureAssociations(models);

        // Conditional sync (development only)
        if (process.env.NODE_ENV === 'development') {
            console.log('Syncing database in development mode...');
            await sequelize.sync({ alter: true, force: false, logging: console.log });
        } else {
            console.log('Syncing database in production mode...');
            await sequelize.sync({ alter: true, force: false });
        }
        console.log('Database synchronized successfully.');

        // Prepare connection package
        const connection = { sequelize, ...models };

        // Cache connection
        connectionCache.set(cacheKey, connection);

        // Setup periodic validation
        scheduleConnectionValidation(connection, cacheKey);

        return connection;
    } catch (error) {
        console.error('Error synchronizing database:', error);
        // Cleanup failed connection
        await sequelize.close();
        throw new Error(`Connection failed: ${error.message}`);
    }
    // finally {
    //     // Ensure the connection is closed
    //     if (sequelize) {
    //         await sequelize.close();
    //     }
    // }
};

const validateConnection = async (sequelize) => {
    try {
        await sequelize.authenticate({ logging: false });
        return true;
    } catch (error) {
        return false;
    }
};

const scheduleConnectionValidation = (connection, cacheKey) => {
    const interval = setInterval(async () => {
        if (!await validateConnection(connection.sequelize)) {
            clearInterval(interval);
            connectionCache.delete(cacheKey);
            await connection.sequelize.close();
        }
    }, 300000);

    // Cleanup on process exit
    process.on('exit', async () => {
        clearInterval(interval);
        await connection.sequelize.close();
    });
};

setInterval(() => {
    const now = Date.now();
    for (const [key, connection] of connectionCache) {
        const lastUsed = connection.sequelize.connectionManager.pool.lastUsedAt;
        if (now - lastUsed > 3600000) { // 1 hour inactivity
            connection.sequelize.close();
            connectionCache.delete(key);
        }
    }
}, 1800000);

module.exports = { connectSpecificToDatabase };