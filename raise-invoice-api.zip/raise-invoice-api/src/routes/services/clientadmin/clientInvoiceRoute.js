const express = require('express');
const router = express.Router();
const clientInvoiceController = require('../../../controllers/services/clientInvoiceController');
const { isAuthenticatedClient } = require('../../../middleware/auth');


/***************************** Clients Invoice *********************************/

router.route('/create-invoice').post(isAuthenticatedClient, clientInvoiceController.createInvoice);
router.route('/update-invoice').post(isAuthenticatedClient, clientInvoiceController.updateInvoice);
router.route('/next-invoice-number').post(isAuthenticatedClient, clientInvoiceController.fetchNextInvoiceNumber);
router.route('/invoice-list').post(isAuthenticatedClient, clientInvoiceController.getAllInvoices)
router.route('/invoice-details').post(isAuthenticatedClient, clientInvoiceController.getInvoiceDetails)
router.route('/delete-invoice').post(isAuthenticatedClient, clientInvoiceController.deleteInvoice);

router.route('/create-tax').post(isAuthenticatedClient, clientInvoiceController.createTaxRate)
router.route('/rate-list').post(isAuthenticatedClient, clientInvoiceController.getAllRates);
router.route('/delete-tax').post(isAuthenticatedClient, clientInvoiceController.deleteTaxRate);

/***************************** Clients Invoice Controller ***********************/

module.exports = router;