const express = require('express');
const router = express.Router();
const projectClientController = require('../../../controllers/services/projectClientController');
const { isAuthenticatedClient } = require('../../../middleware/auth');

/***************************** Clients Project Management Start  *********************************/
router.route('/add-project').post(isAuthenticatedClient, projectClientController.createProject);
router.route('/project-list').post(isAuthenticatedClient, projectClientController.getAllProjects);
router.route('/project-details').post(isAuthenticatedClient, projectClientController.getProjectDetails)
router.route('/update-project').post(isAuthenticatedClient, projectClientController.updateProject)
router.route('/delete-project').post(isAuthenticatedClient, projectClientController.deleteProject);

router.route('/save-contact').post(isAuthenticatedClient, projectClientController.saveContacts);
router.route('/get-contacts').post(isAuthenticatedClient, projectClientController.getContacts);

router.route('/save-files').post(isAuthenticatedClient, projectClientController.saveProjectFile);
router.route('/get-files').post(isAuthenticatedClient, projectClientController.getProjectFile);
router.route('/remove-files').post(isAuthenticatedClient, projectClientController.removeProjectFile);

router.route('/save-tasks').post(isAuthenticatedClient, projectClientController.saveTask);
router.route('/get-tasks').post(isAuthenticatedClient, projectClientController.getTask);

router.route('/save-times').post(isAuthenticatedClient, projectClientController.saveProjectTime);
// router.route('/get-times').post(isAuthenticatedClient, projectClientController.getProjectTime);
/***************************** Clients Project Management Section End  *********************************/

module.exports = router;