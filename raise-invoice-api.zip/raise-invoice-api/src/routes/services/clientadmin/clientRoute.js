const express = require('express');
const router = express.Router();
const clientController = require('../../../controllers/services/clientController');
const appointmentController = require('../../../controllers/services/appointmentController');
const { isAuthenticatedClient } = require('../../../middleware/auth');

/***************************** Clients Management Start  *********************************/
router.route('/add-client').post(isAuthenticatedClient, clientController.createClient);
router.route('/clients').post(isAuthenticatedClient, clientController.getAllClients);
router.route('/client/:clientId')
    .get(isAuthenticatedClient, clientController.detailsClient)
    .put(isAuthenticatedClient, clientController.updateClient)
    .delete(isAuthenticatedClient, clientController.clientDeleteAPI);

router.route('/buy-plan').post(isAuthenticatedClient, clientController.clientSubscription);
/***************************** Clients Management End  *********************************/

/***************************** Clients Appointment Management Section Start  *********************************/
router.route('/add-appointment').post(isAuthenticatedClient, appointmentController.createAppointment);
router.route('/appointments').post(isAuthenticatedClient, appointmentController.getAllAppointments);
/***************************** Clients Appointment Management Section End  *********************************/

/***************************** Clients Project Management Section Start  *********************************/
// router.route('/add-project').post(isAuthenticatedClient, clientController.createClient);
// router.route('/projects').post(isAuthenticatedClient, clientController.getAllClients);
// router.route('/project/:projectId')
//     .get(isAuthenticatedClient, clientController.detailsClient)
//     .put(isAuthenticatedClient, clientController.updateClient)
//     .delete(isAuthenticatedClient, clientController.clientDeleteAPI);
/***************************** Clients Project Management Section End  *********************************/

/***************************** Role Management Start  *********************************/
router.route('/add-role').post(isAuthenticatedClient, clientController.createRole);
router.route('/roles').post(isAuthenticatedClient, clientController.getAllRoles);
router.route('/role/:roleId')
    .get(isAuthenticatedClient, clientController.detailsRole)
    .put(isAuthenticatedClient, clientController.updateRole)
    .delete(isAuthenticatedClient, clientController.roleDeleteAPI);
/***************************** Role Management End  *********************************/

/***************************** Client Admin Management Start  *********************************/
router.route('/add-client-admin').post(isAuthenticatedClient, clientController.createClientAdmin);
router.route('/client-admins').post(isAuthenticatedClient, clientController.getAllClientAdmins);
router.route('/client-admin/:clientAdminId')
    .get(isAuthenticatedClient, clientController.detailsClientAdmin)
    .put(isAuthenticatedClient, clientController.updateClientAdmin)
    .delete(isAuthenticatedClient, clientController.clientAdminDeleteAPI);
router.route('/client-admin-by-uuid/:uuid')
    .get(isAuthenticatedClient, clientController.detailsClientAdmin);
/***************************** Clients Management End  *********************************/

module.exports = router;