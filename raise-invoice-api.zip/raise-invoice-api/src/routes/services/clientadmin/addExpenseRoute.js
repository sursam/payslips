const express = require('express');
const router = express.Router();
const addExpenseController = require('../../../controllers/services/addExpenseController');
const {
  isAuthenticated,
} = require('../../../middleware/auth');

router.route('/create-expense').post(isAuthenticated, addExpenseController.addExpense);
router.route('/expense-list').post(isAuthenticated, addExpenseController.listExpenses);
router.route('/expense-update').post(isAuthenticated, addExpenseController.updateExpense);
router.route('/expense-details').post(isAuthenticated, addExpenseController.getExpenseDetails);
router.route('/expense-delete').post(isAuthenticated, addExpenseController.deleteExpense);

module.exports = router;