const express = require('express');
// const {
//     getFaqList,
//     getTestimonialList,
//     getPlanList
// } = require("../../controllers/common/commonController");
// const {
//     isAuthenticatedRider
// } = require("../../middleware/auth");

const faqController = require('../../controllers/faqController');
const pricingPlanController = require('../../controllers/pricingPlanController');
const jobController = require('../../controllers/jobController');
const commonController = require('../../controllers/common/commonController');
const router = express.Router();
const { isAuthenticatedClient } = require('../../middleware/auth');

//For Faq
// router.route('/faq-list').get(getFaqList);
router.route('/testimonial-list').get(commonController.getTestimonialList);
router.route('/get-role-list').get(isAuthenticatedClient, commonController.getRoleList);
router.route('/get-master-data').get(commonController.getMasterDataList);
// router.route('/price-plan-list').post(getPlanList);

router.route('/get-faq-categories').post(faqController.getFaqCategories);
router.route('/get-faq-category-details').post(faqController.getFaqCategoryDetails);
router.route('/get-faq-list').post(faqController.getFaqList);
router.route('/get-faq-details').post(faqController.getFaqDetails);

router.route('/get-features-categories').post(pricingPlanController.getPlanFeaturesCategories);
router.route('/get-plan-list').post(pricingPlanController.getPlanList);

router.route('/get-job-categories').post(jobController.getJobCategories);
router.route('/get-job-category-details').post(jobController.getJobCategoryDetails);
router.route('/get-job-list').post(jobController.getJobList);
router.route('/get-job-details').post(jobController.getJobDetails);

router.route('/submit-enquiry').post(commonController.submitEnquiry);

module.exports = router;