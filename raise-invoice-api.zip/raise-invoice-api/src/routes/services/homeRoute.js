const express = require('express');

const homeController = require('../../controllers/services/homeController');
const router = express.Router();

router.route('/feedback-list').get(homeController.getHomeFeedbackList);
router.route('/save-newsletter').post(homeController.saveNewletterUser);

router.route('/menu-list').post(homeController.navMenuList);
router.route('/menu-details').post(homeController.navMenuDetails);

module.exports = router;