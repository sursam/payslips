const express = require('express');
const router = express.Router();
const vehicleTypeController = require('../controllers/vehicleTypeController');
const {
    isAuthenticated,
  } = require('../middleware/auth')


router.route('/vehicle-type-add-update').post(isAuthenticated, vehicleTypeController.vehicleTypeAddUpdate);
router.route('/vehicle-type-list').post(isAuthenticated, vehicleTypeController.vehicleTypeList);

module.exports = router;