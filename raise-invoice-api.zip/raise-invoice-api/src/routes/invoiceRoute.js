const express = require('express');
const router = express.Router();
const invoiceController = require('../controllers/invoiceController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-invoice').post(isAuthenticated, invoiceController.getTemplateList);
router.route('/preview-invoice').post(isAuthenticated, invoiceController.previewTemplate);

router.route('/get-invoice-setting').post(isAuthenticated, invoiceController.getInvoiceSetting);
router.route('/update-invoice-setting').post(isAuthenticated, invoiceController.updateInvoiceSetting);

router.route('/get-invoice-option-setting').post(isAuthenticated, invoiceController.getInvoiceOptionSetting);
router.route('/invoice-option-setting').post(isAuthenticated, invoiceController.invoiceOptionSetting);

//logo route
router.route('/create-logo').post(isAuthenticated, invoiceController.addLogo);
router.route('/logo-list').post(isAuthenticated, invoiceController.logoList);

//Colour route
router.route('/colour-list').post( isAuthenticated, invoiceController.colourList);

//header route
router.route('/header-list').post( isAuthenticated, invoiceController.headerList);

//watermark route
router.route('/water-mark-list').post( isAuthenticated, invoiceController.waterMarkList);

module.exports = router;