const express = require('express');
const router = express.Router();
const itemsController = require('../controllers/services/itemsController');
const { isAuthenticatedClient } = require('../middleware/auth');

//For Items
router.route('/create-item').post(isAuthenticatedClient, itemsController.createItem);
router.route('/update-item').post(isAuthenticatedClient, itemsController.updateItems);
router.route('/list-item').post(isAuthenticatedClient, itemsController.listAllItems);
router.route('/item-details').post(isAuthenticatedClient, itemsController.itemDetails);
router.route('/delet-item').post(isAuthenticatedClient, itemsController.deletItems);

//For Currency
router.route('/create-currency').post(isAuthenticatedClient, itemsController.createCurrency);
router.route('/currency-list').post(isAuthenticatedClient, itemsController.currencyList);

//For Units
router.route('/create-unit').post(isAuthenticatedClient, itemsController.createUnit);
router.route('/unit-list').post(isAuthenticatedClient, itemsController.unitList);

//For Times
router.route('/create-time').post(isAuthenticatedClient, itemsController.createTime);
router.route('/time-list').post(isAuthenticatedClient, itemsController.timeList);

module.exports = router;