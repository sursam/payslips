const express = require('express');
const router = express.Router();
// const moduleController = require('../controllers/moduleController')
const rolePermissionController = require('../controllers/rolePermissionController')

const {
    validateUser
} = require('../validation/userValidator');
const {
    isAuthenticated
} = require('../middleware/auth')

// ======== for dropdown =======
// router.route('/rolePermission-list').get(isAuthenticated, rolePermissionController.rolePermissionList);
// // ======== for dropdown =======
// router.route('/rolePermission-list').post(isAuthenticated, rolePermissionController.rolePermissionList);
// router.route('/rolePermission-addUpdate').post(isAuthenticated, rolePermissionController.rolePermissionAddUpdate); // validateUser, 
// router.route('/get-rolePermissionDetail').post(isAuthenticated, rolePermissionController.getRolePermissionDetail);
// router.route('/delete-rolePermissionDetail').post(isAuthenticated, rolePermissionController.deleteRolePermission);

router.route('/get-role-list').post(isAuthenticated, rolePermissionController.getRoleList);
router.route('/get-admin-role-list').post(isAuthenticated, rolePermissionController.getAdminRoleList);
router.route('/get-role-details').post(isAuthenticated, rolePermissionController.getRoleDetails);
router.route('/save-role').post(isAuthenticated, rolePermissionController.saveRole);
router.route('/delete-role').post(isAuthenticated, rolePermissionController.deleteRole);

router.route('/get-module-list').post(isAuthenticated, rolePermissionController.getModuleList);
router.route('/get-module-details').post(isAuthenticated, rolePermissionController.getModuleDetails);
router.route('/save-module').post(isAuthenticated, rolePermissionController.saveModule);
router.route('/delete-module').post(isAuthenticated, rolePermissionController.deleteModule);
// router.route('/role-wise-module-list').post(isAuthenticated, rolePermissionController.roleWiseModuleList);

router.route('/permission-list').post(isAuthenticated, rolePermissionController.permissionList);

router.route('/update-role-permission').post(isAuthenticated, rolePermissionController.updateRolePermission);
router.route('/get-role-permissions').post(isAuthenticated, rolePermissionController.getRolePermissions);

// ============================== App APIs ==============================

// ============================== App APIs ==============================


module.exports = router;