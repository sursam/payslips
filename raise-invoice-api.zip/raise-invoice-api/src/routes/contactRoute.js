const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/get-enquiry-list').post(isAuthenticated, contactController.getEnquiryList);
router.route('/get-enquiry-details').post(isAuthenticated, contactController.getEnquiryDetails);
router.route('/mark-enquiry-read').post(isAuthenticated, contactController.markEnquiryRead);
router.route('/delete-enquiry').post(isAuthenticated, contactController.deleteEnquiry);

router.route('/get-newsletter-subscriptions').post(isAuthenticated, contactController.getNewsletterSubscriptions);
router.route('/get-newsletter-subscription-details').post(isAuthenticated, contactController.getNewsletterSubscriptionDetails);
router.route('/save-newsletter-subscription-details').post(isAuthenticated, contactController.saveNewsletterSubscriptionDetails);
router.route('/delete-newsletter-subscription').post(isAuthenticated, contactController.deleteNewsletterSubscription);

module.exports = router;