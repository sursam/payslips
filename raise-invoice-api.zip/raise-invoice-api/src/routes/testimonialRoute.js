const express = require('express');
const router = express.Router();
const testimonialController = require('../controllers/testimonialController');
const {
  isAuthenticated,
} = require('../middleware/auth')


router.route('/get-testimonial-list').post(isAuthenticated, testimonialController.getTestimonialList);
router.route('/save-testimonial').post(isAuthenticated, testimonialController.saveTestimonial);
router.route('/delete-testimonial').post(isAuthenticated, testimonialController.deleteTestimonial);
router.route('/get-testimonial-details').post(isAuthenticated, testimonialController.getTestimonialDetails);

module.exports = router;