const express = require('express');
const router = express.Router();
const homeController = require('../controllers/homeController');
const {
    isAuthenticated,
} = require('../middleware/auth')


router.route('/get-language-list').post(homeController.getLanguageList);
router.route('/save-language').post(homeController.saveLanguage);
router.route('/delete-language').post(homeController.deleteLanguage);
router.route('/set-default-language').post(homeController.setDefaultLanguage);
router.route('/get-language-details').post(homeController.getLanguageDetails);

router.route('/get-currency-list').post(homeController.getCurrencyList);
router.route('/save-currency').post(homeController.saveCurrency);
router.route('/set-default-currency').post(homeController.setDefaultCurrency);
router.route('/get-currency-info').post(homeController.getCurrencyInfo);

router.route('/get-exchange-rates').post(homeController.getExchangeRates);
router.route('/save-exchange-rate').post(homeController.saveExchangeRate);

module.exports = router;