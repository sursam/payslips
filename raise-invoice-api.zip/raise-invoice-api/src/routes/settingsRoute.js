const express = require('express');
const router = express.Router();
const settingsController = require('../controllers/settingsController')
const {
    isAuthenticated,
  } = require('../middleware/auth')

// ============================ PAYMENT GATEWAY APIs ============================
router.route('/import-payment-gateway').post(isAuthenticated, settingsController.importPaymentGateway);
router.route('/get-payment-gateway-list').post(isAuthenticated, settingsController.getPaymentGatewayList);
router.route('/get-payment-gateway-details').post(isAuthenticated, settingsController.getPaymentGatewayDetails);
router.route('/save-payment-gateway').post(isAuthenticated, settingsController.savePaymentGateway);
router.route('/get-payment-gateway-field-values').post(isAuthenticated, settingsController.getPaymentGatewayFieldValues);
router.route('/save-payment-gateway-fields').post(isAuthenticated, settingsController.savePaymentGatewayFields);

router.route('/test-mail').get(settingsController.testMail);

// ============================ PAYMENT GATEWAY APIs ============================

module.exports = router;