const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController')
const pricingPlanController = require('../controllers/pricingPlanController')
const {
  isAuthenticated,
} = require('../middleware/auth');

router.route('/save-user').post(isAuthenticated, userController.saveUser);
router.route('/get-user-details').post(isAuthenticated, userController.getUserDetails);
router.route('/get-user-list').post(isAuthenticated, userController.getUserList);
router.route('/get-admin-user-list').post(isAuthenticated, userController.getAdminUserList);
router.route('/user-soft-delete').post(isAuthenticated, userController.userSoftDelete);
router.route('/get-country-list').get(userController.getCountryList);

// ============================ SUBSCRIPTION APIs ============================
router.route('/get-client-subscription-list').post(isAuthenticated, userController.getClientSubscriptionList);
router.route('/get-client-subscription-details').post(isAuthenticated, userController.getClientSubscriptionDetails);
router.route('/save-client-subscription').post(isAuthenticated, userController.saveClientSubscription);
router.route('/delete-client-subscription').post(isAuthenticated, userController.deleteClientSubscription);

router.route('/subscription-details').post(isAuthenticated, userController.getSubscriptionDetails);
router.route('/subscription-update').post(isAuthenticated, userController.updateSubscription);
router.route('/subscription-delete').post(isAuthenticated, userController.deleteSubscription);
// ============================ SUBSCRIPTION APIs ============================

// ============================ CUSTOMER APIs ============================
router.route('/customer-register').post(userController.customerRegister);
router.route('/customer-booking-history').post(isAuthenticated, userController.customerBookingHistory);
router.route('/request-to-mark-ready').post(isAuthenticated, userController.requestToMarkReady);
// ============================ CUSTOMER APIs ============================

// ============ from admin-end ============
router.route('/car-ready-status-change').post(isAuthenticated, userController.carReadyStatusChange);
// ============ from admin-end ============

router.route('/admin/client-list/:id').get(userController.allUserClientList);

router.route('/export-data').post(userController.exportData);

module.exports = router;