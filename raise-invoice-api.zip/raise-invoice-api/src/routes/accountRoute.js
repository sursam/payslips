const express = require('express');
const router = express.Router();
const accountController = require('../controllers/accountController');
const { isAuthenticatedClient } = require('../middleware/auth');

router.route('/create-account').post(isAuthenticatedClient, accountController.createAccount);
router.route('/account-list').post(isAuthenticatedClient, accountController.listAllAccounts);
router.route('/account-update').post(isAuthenticatedClient, accountController.updateAccount);
router.route('/account-details').post(isAuthenticatedClient, accountController.accountDetails);
router.route('/account-delete').post(isAuthenticatedClient, accountController.deleteAccounts);

router.route('/switch-accounts').post(accountController.switchAccount);

module.exports = router;