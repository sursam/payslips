const express = require('express');
const router = express.Router();
const agentController = require('../controllers/agentController');
const {
  isAuthenticated,
} = require('../middleware/auth');

router.route('/agent-list').post(isAuthenticated, agentController.agentList);
router.route('/agent-add-update').post(isAuthenticated, agentController.agentAddUpdate);
router.route('/agent-details').post(isAuthenticated, agentController.agentDetails);
router.route('/agent-delete').post(isAuthenticated, agentController.agentDelete);

module.exports = router;