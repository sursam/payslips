const express = require('express');
const router = express.Router();
const pricingPlanController = require('../controllers/pricingPlanController');
const {
  isAuthenticated,
} = require('../middleware/auth')


// router.route('/get-currency-list').get(isAuthenticated, pricingPlanController.getCurrencyList);
router.route('/get-plan-list').post(isAuthenticated, pricingPlanController.getPlanList);
router.route('/get-plans').post(isAuthenticated, pricingPlanController.getPlans);
router.route('/save-plan').post(isAuthenticated, pricingPlanController.savePlan);
router.route('/save-plan-prices').post(isAuthenticated, pricingPlanController.savePlanPrices);
router.route('/delete-plan').post(isAuthenticated, pricingPlanController.deletePlan);
router.route('/get-features-categories').post(isAuthenticated, pricingPlanController.getFeaturesCategories);
router.route('/get-plan-details').post(isAuthenticated, pricingPlanController.getPlanDetails);
router.route('/get-plan-features').post(isAuthenticated, pricingPlanController.getPlanFeatures);
router.route('/save-plan-features').post(isAuthenticated, pricingPlanController.savePlanFeatures);
router.route('/update-plan-features').post(isAuthenticated, pricingPlanController.updatePlanFeatures);
router.route('/update-plan-status').post(isAuthenticated, pricingPlanController.updatePlanStatus);

module.exports = router;