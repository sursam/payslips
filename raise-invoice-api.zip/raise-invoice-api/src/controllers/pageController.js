const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const pageModel = db.PageModel;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");
const { slugify } = require("../utils/utilities");
// const blockModel = require("../models/blockModel");
const blockModel = db.BlockModel;

class pageController extends BaseController {
  constructor() {
    super();
  }

  static getPageList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, page = 1, limit = 0 } = req.body;
    let whereClause = {
      deletedAt: null,
    };

    if (searchText) {
      whereClause[Op.or] = [
        {
          id: {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          page_title: {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }

    let options = {
      where: whereClause,
      order: [["page_title", "ASC"]],

      // limit: limit,
      // offset: (page - 1) * limit
    };

    if (page && limit) {
      options.limit = limit;
      options.offset = (page - 1) * limit;
    }
    // console.log(options);

    let pageLists = await super.getList(req, pageModel, options);
    const totalCount = await pageModel.count({ where: whereClause });

    if (pageLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: pageLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });
  static getAllPageList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      deletedAt: null,
    };

    if (searchText) {
      whereClause[Op.or] = [
        {
          id: {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          page_title: {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }

    let options = {
      where: whereClause,
      order: [["page_title", "ASC"]],
    };

    // console.log(options);
    let pageLists = await pageModel.findAll(options);

    if (pageLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: pageLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });

  static savePage = catchAsyncErrors(async (req, res, next) => {
    const { id, page_title, meta_title, meta_keywords, meta_description } = req.body;
    //Slug add
    let slug = slugify(page_title);
    const updateFields = {
      page_title,
      slug: slug,
      meta_title,
      meta_keywords,
      meta_description
    };

    let updated;
    if (id) {
      updated = await super.updateById(pageModel, id, updateFields);
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, pageModel, updateFields);
    }

    const msg = updated
      ? (id ? "Page updated successfully." : "Page added successfully.")
      : "Page addition failed.";

    return res.status(updated ? 200 : 400).json({
      status: !!updated,
      message: updated ? msg : "Oops.. Something wrong happened!",
      data: updated || {},
    });
  });
  static getPageDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let pageDetails = await super.getByCustomOptionsSingle(req, pageModel, {
      where: queryConditions,
    });

    if (pageDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: pageDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deletePage = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let pageDetail = await super.getByCustomOptionsSingle(req, pageModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!pageDetail) {
      return res.status(403).json({
        status: false,
        message: "page not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      pageModel,
      {
        id: pageDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Page successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });
  static getPagecontentBySlug = catchAsyncErrors(async (req, res, next) => {
    const { slug, id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
    };

    if (slug) {
      queryConditions.slug = slug
    }
    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let pageDetails = await super.getByCustomOptionsSingle(req, pageModel, {
      where: queryConditions,
      include: [
        {
          model: blockModel,
          where: {
            deletedAt: null,
            status: true,
          },
          required: false
        },
      ],
    });

    if (pageDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: pageDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
}

module.exports = pageController;
