const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");
const crypto = require("crypto");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const pageModel = db.Pages;
const customFieldModel = db.CustomFields;

class CmsController extends BaseController {
  constructor() {
    super();
  }

  static pageAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { roleId, firstName, lastName, email, password, dialCode, phone, dob, gender, address, id, moduleAccess } = req.body;

    // user add happening ===
    if (!roleId) {
      return res.status(422).json({
        status: false,
        message: "Role Id is required.",
        data: {},
      });
    }
    if (!firstName || !lastName) {
      return res.status(422).json({
        status: false,
        message: "First name or Last name is required.",
        data: {},
      });
    }
    if (!email) {
      return res.status(422).json({
        status: false,
        message: "Email is required.",
        data: {},
      });
    }
    if (!id && !password) {      
      return res.status(422).json({
        status: false,
        message: "Password is required.",
        data: {},
      });
    }
    if (!phone) {
      return res.status(422).json({
        status: false,
        message: "Phone is required.",
        data: {},
      });
    }
    /*let role = await roleModel.findOne({
      where: {
        id: roleId,
        deletedAt: null,
      }
    });
    if(role.roleName != 'Employee'){
      if (!moduleAccess) {
        return res.status(422).json({
          status: false,
          message: "Please specify module access permissions.",
          data: {},
        });
      }
    }*/

    let condition = {
      deletedAt: null,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await userModel.findOne({
      attributes: ["firstName", "lastName"],
      where: {
        ...condition,
        [Op.or]: [{ phone: phone }, { email: email }],
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "User with this phone or email already exist!",
        data: checkExist,
      });
    }

    // =========== single file upload ================
    let fileName = "";
    if (req.files.profileImage) {
      let image = await fileUploaderSingle(
        "src/public/uploads/userImages/",
        req.files.profileImage
      );
      fileName = image.newfileName;
    }
    // =========== single file upload ================

    let updateFields = {
    };
    if (firstName) {
      updateFields.firstName = firstName;
    }
    if (lastName) {
      updateFields.lastName = lastName;
    }
    if (email) {
      updateFields.email = email;
    }
    if (dialCode) {
      updateFields.dialCode = dialCode;
    }
    if (phone) {
      updateFields.phone = phone;
    }
    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }
    if (dob) {
      updateFields.dob = dob;
    }
    if (gender) {
      updateFields.gender = gender;
    }
    if (address) {
      updateFields.address = address;
    }
    if (fileName != "") {
      updateFields.profileImage = fileName;
    }
    // console.log('updateFields', updateFields);
    let updated = null;
    if(id && id != "" && id != null){
      updated = await super.updateById(userModel, id, updateFields)
    }else{
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, userModel, updateFields);
    }
    // let updated =
    //   id && id != "" && id != null
    //     ? await super.updateById(userModel, id, updateFields)
    //     : await super.create(res, userModel, updateFields);

    if (updated) {
      let userId = (id && id != "" && id != null) ? id : updated.id;
      let userDetails = await userModel.findOne({
        where: {
          id: userId,
        }
      });
      
      if(!id){
        await usersrolesModel.create({userId: parseInt(userId), roleId: parseInt(roleId)});
      }      

			// ====== create permissions START ======
			/*let moduleAccessArr = JSON.parse(moduleAccess);
			if(Array.isArray(moduleAccessArr)){
				// moduleAccess should always be array ========
				moduleAccessArr.forEach(async (moduleId)=>{
					let dataToBeUpdated = {
						userId: id,
						moduleId: moduleId,
					};
					let checkPermissionExists = await modulePermissionsModel.findOne({
						where: {
							userId: id,
							moduleId: moduleId,
						}
					});
					let modulePermissionUpdate = 
						checkPermissionExists && checkPermissionExists != "" && checkPermissionExists != null
							? await super.updateByCustomOptions(
                modulePermissionsModel, 
                {
                  userId: id,
                  moduleId: moduleId,
                }, 
                dataToBeUpdated
              )
							: await modulePermissionsModel.create(dataToBeUpdated);

					if(modulePermissionUpdate){
						console.log("Module permissions created/updated.");
					} else{
						console.log("Module permissions not affected.");
					}
				});
			} else {
				return res.status(422).json({
					status: false,
					message: "moduleAccess variable in payload must be an array.",
					data: moduleAccess
				});
			}*/
			// ====== create permissions END ======

      return res.status(200).json({
        status: true,
        message: "Successful.",
        data: userDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });

  static pageDetails = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;
    
    let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
      where: { 
        uuid: uuid 
      },
      attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      },
      include: [
        {
          model: roleModel, // including associated model
          attributes: ["id", "roleName", "roleSlug"], // Attributes to select from the included model
          as: 'userRole',
          where: {
            roleSlug: {
              [Op.notIn]: ["super-admin"],
            },
          }
        },
      ],
    });
    // userDetail = userDetail.get({ plain: true });
    // console.log(userDetail);

    // Remove the password before sending the response
    // delete userDetail.password;

    /*let modulePermissions = await modulePermissionsModel.findAll({
      where:{
        userId: Number(id),
      }
    });
    // console.log("modulePermissions ===>");
    // console.log(modulePermissions);
    if(modulePermissions){
      let moduleAccess = [];
      modulePermissions.forEach((modulePermission)=>{
        moduleAccess.push(modulePermission.moduleId);
      });
      // console.log("moduleAccess ===>");
      // console.log(moduleAccess);
      userDetail["moduleAccess"] = moduleAccess;
    } else {
      userDetail["moduleAccess"] = [];
    }*/

    if(userDetail){
      return res.status(200).json({
        status: true,
        message: "Details found.",
        data: userDetail
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No details found.",
        data: {}
      });
    }
  });

  static pageList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
        status: true,
        deletedAt: null,
    };
    if(searchText){
      let searchId = searchText.toLowerCase().replace('invoice-page-','').replace(/^0+/, '');
      whereClause = {
        status: true,
          deletedAt: null,
          [Op.or]: [
              {
                id: 
                {
                    [Op.like]: `%${searchId}%`
                }
              }, 
              {
                name: 
                {
                    [Op.like]: `%${searchText}%`
                }
              }, 
              {
                slug: 
                {
                    [Op.like]: `%${searchText}%`
                }
              }, 
              {
                title: 
                {
                    [Op.like]: `%${searchText}%`
                }
              }, 
              {
                subtitle: 
                {
                    [Op.like]: `%${searchText}%`
                }
              }
          ] 
      };
    }
    let options = {
      where: whereClause,
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: customFieldModel, // including associated model
          attributes: ["field_type", "field_name", "field_value"], // Attributes to select from the included model
          where: {
            status: 1,
          },
        },
      ],
      // raw: true
    };
    let pageList = await super.getList(req, pageModel, options);

    let pageImageUrl = process.env.API_URL + "uploads/cmsImages/";

    if (pageList.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: {
          pageList: pageList,
          pageImageUrl: pageImageUrl,
        },
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: {},
      });
    }
  });

  static pageSoftDelete = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let userDetail = await super.getByCustomOptionsSingle(req, userModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
      include: [
        {
          model: roleModel,
          attributes: ["id", "roleName", "roleSlug"], 
          as: 'userRole',
          where: {
            roleSlug: {
              [Op.notIn]: ["super-admin"],
            },
          }
        },
      ],
    });
    
    if(!userDetail){
      return res.status(403).json({
        status: false,
        message: "User not found!",
        data: {},
      });
    } 
    // userDetail = userDetail.get({ plain: true });
    
    // let userCheckExist = await super.getByCustomOptions(req, userModel, {uuid: uuid});
    // let role = await super.getById(req, roleModel, userCheckExist.roleId);

    // if(
    //   (userDetail.id == 1)
    //   || (userDetail.userRole.roleSlug == "super-admin")
    // ){
    //   // ---- prevent Super Admin deletion by mistake or ill-intent ----
    //   return res.status(403).json({
    //     status: false,
    //     message: "You can't delete superadmin.",
    //     data: {},
    //   });
    // } 
    // if (role.roleSlug == "vendor"){
    //   let vendorDelete = await super.softDeleteByCondition(
    //     vendorModel, 
    //     {
    //       userId: id,
    //     },
    //     req.user.id,
    //   );
    // }

    let deleted = await super.softDeleteByCondition(
      userModel, 
      {
        id: userDetail.id,
      },
      req.user.id,
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Soft deletion successful.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = CmsController;
