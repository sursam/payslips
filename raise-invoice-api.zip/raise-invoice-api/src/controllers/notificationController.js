const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op, fn, col, } = require("sequelize");
const { sequelizeConnectionInstance, Sequelize } = require("../models");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const parkingBusinessesModel = db.ParkingBusinesses;
const parkingGroundsModel = db.ParkingGrounds;
const parkingLotsModel = db.ParkingLots;
const slotModel = db.Slots;
const roleModel = db.Roles;
const userModel = db.Users;
const notificationModel = db.Notifications;

class notificationController extends BaseController {
  constructor() {
    super();
  }

  static notificationList = catchAsyncErrors(async (req, res, next) => {
    let loggedUserId = req.user.id;
		
		let loggedUserDetail = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: loggedUserId,
			},
			include: [
				{
					model: roleModel,
				}
			]
		});
		
		let roleOfLoggedUser = await super.getByCustomOptionsSingle(req, roleModel, {
			where: {
				id: loggedUserDetail?.roleId,
			}
		});

    let options = {
			include: [
				{
					model: userModel,
					attributes: {
						exclude: [
              "roleId",
              "password",
              "webLogin",
              "appLogin",
              "fcmToken",
              "OTP",
              "macAddress",
              "deviceId",
						],
					},
					required: false,
				},
			],
			where: {
				isActive: true,
				deletedAt: null,

        userId: loggedUserDetail?.roleId,
			},
			order: [["createdAt", "DESC"]],
		};

    let notifications = [];
    notifications = await super.getList(req, notificationModel, options);

    if(notifications.length > 0){
      return res.status(200).json({
        status: true,
        message: "Notifications found.",
        data: {
          notifications: notifications,
        }
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No notifications found.",
        data: {
          notifications: [],
        }
      });
    }
  });

  static notiReadStatusChange = catchAsyncErrors(async (req, res, next) => {
    let { notificationId, isRead } = req.body;
    // ======= "isRead": false // true => Read <OR> false => Unread =======
    if(
			(!notificationId || notificationId == "" || notificationId == null || notificationId == undefined)
			|| (isRead == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

    let conditions = { 
      id: notificationId
    };
    let updateFields = {
      isRead: isRead,
    };

    let notiUpdate = await super.updateByCustomOptions(
      notificationModel,
      conditions,
      updateFields
    );

    if(notiUpdate){
      return res.status(200).json({
        status: true,
        message: `Notification marked as ${(isRead == true)? 'Read':'Unread'}`,
        data: {} 
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something went wrong..!!",
        data: {} 
      });
    }
  });

  static deleteNotification = catchAsyncErrors(async (req, res, next) => {
    let { notificationId } = req.body;
    
    if(
			(!notificationId || notificationId == "" || notificationId == null || notificationId == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

    let notiDelete = await super.deleteById(notificationModel, notificationId);

    if(notiDelete){
      return res.status(200).json({
        status: true,
        message: "Deleted successfully.",
        data: {}
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Soemthing wrong happened.",
        data: {}
      });
    }
  });
}

module.exports = notificationController;
