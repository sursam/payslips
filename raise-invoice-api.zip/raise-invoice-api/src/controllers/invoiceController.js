const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const mustache = require('mustache');

const db = require("../models");
const { where } = require("sequelize");
const clientModel = db.Clients;
const mysqlConfig = require("../config/index").Mysql;
const invoiceModel = db.InvoiceTemplate
const logoModel = db.InvoiceLogo
const invoiceHeaderModel = db.InvoiceHeader
const InvoiceWaterMarkModel = db.InvoiceWaterMark
const colourList = db.InvoiceColour

const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const { connectSpecificToDatabase } = require("../config/specificConnect");

class invoiceController extends BaseController {
  constructor() {
    super();
  }

//For Invoice Template Setting
static getTemplateList = catchAsyncErrors(async (req, res, next) => {
    try {
        const { templateName, logoId, logoSize = "100px", logoPosition = "center", colourId, headerId, waterMarkId } = req.body;

        // Fetch the invoice template
        let result = await invoiceModel.findOne({
            where: { name: templateName }
        });

        if (!result) {
            return res.status(404).json({
                status: false,
                message: "No templates found.",
                data: []
            });
        }

        let template = result.dataValues.text;

        // Fetch header image as base64 if headerId is provided
        let headerBase64 = null;
        if (headerId) {
            const headerRecord = await invoiceHeaderModel.findOne({ where: { id: headerId } });
            if (headerRecord && headerRecord.headerImg && Buffer.isBuffer(headerRecord.headerImg)) {
                headerBase64 = headerRecord.headerImg.toString('base64');
            }
        }

        // Fetch watermark image as base64 if waterMarkId is provided
        let waterMarkBase64 = null;
        if (waterMarkId) {
            const waterMarkRecord = await InvoiceWaterMarkModel.findOne({ where: { id: waterMarkId } });
            if (waterMarkRecord && waterMarkRecord.waterMarkImg && Buffer.isBuffer(waterMarkRecord.waterMarkImg)) {
                waterMarkBase64 = waterMarkRecord.waterMarkImg.toString('base64');
            }
        }


        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const uuid = crypto.randomUUID();
        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const invoiceField = {
            client_admin_id : req.user.id,
            uuid: uuid,
            name: templateName,
            logoPosition: logoPosition,
            logoSize: logoSize,
            logo: logoId ? `${logoId}` : null,
            colour: colourId ? `${colourId}` : null,
            header : headerId,
            waterMark: waterMarkId
        }

        // Create the invoice template
        await super.create(res, connection.InvoiceSetting, invoiceField, { transaction });

        // Define invoice data
        const invoiceData = {
            logoPosition: logoPosition,
            logoSize: logoSize,
            logo: logoId ? `${logoId}` : null,
            colour: colourId ? `${colourId}` : null,
            header: headerBase64,
            waterMark: waterMarkBase64,
            invoice_number: 1,
            created_date: new Date().toISOString().split('T')[0],
            due_date: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
            company_name: "Raise Invoice",
            company_address: "5678 Innovation Blvd, Tech City, TX 75001",
            client_name: "Alice Doe",
            client_email: "alice@example.com",
            client_phone: "1232456765",
            items: [
                { name: "Web Development Package", price: "$500.00" }
            ],
            subtotal_amount: "$500.00",
            total_amount: "$500.00",
            discount_amount: "$0.00",
            tax: "GST 18% ($500.00)",
            tax_amounts: "$90.00",
            paid_amount: "$100.00",
            balance_due: "$425.00"
        };

        // Render final invoice template with dynamic data
        const renderedInvoice = mustache.render(template, invoiceData);

        if (renderedInvoice) {
            // res.setHeader("Content-Type", "text/html");
            // return res.status(200).send(renderedInvoice);
            return res.status(200).json({
                status: true,
                message: "Template fetched successfully.",
                data: {
                    logoPosition: logoPosition,
                    logoSize: logoSize,
                    logo: logoId ? `${logoId}` : null,
                    colour: colourId ? `${colourId}` : null,
                    header: headerId,
                    waterMark: waterMarkId
                }
            });
        } else {
            return res.status(500).send({});
        }
    } catch (error) {
        console.error("Error fetching invoice templates:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: []
        });
    }
});

static getInvoiceSetting = catchAsyncErrors(async (req, res, next) => {
    try{
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const invoiceSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: req.user.id}
        });

        if (!invoiceSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice setting not found.",
                data: {}
            });
        }

        // Populate header, waterMark, colour, and logo details if present
        let settingData = invoiceSetting.toJSON();

        // Populate header details
        if (settingData.header) {
            const headerRecord = await invoiceHeaderModel.findOne({ where: { id: settingData.header } });
            if (headerRecord) {
                const headerObj = headerRecord.toJSON();
                if (headerObj.headerImg && Buffer.isBuffer(headerObj.headerImg)) {
                    headerObj.headerBase64 = headerObj.headerImg.toString('base64');
                    delete headerObj.headerImg;
                }
                settingData.headerDetails = headerObj;
            }
        }

        // Populate waterMark details
        if (settingData.waterMark) {
            const waterMarkRecord = await InvoiceWaterMarkModel.findOne({ where: { id: settingData.waterMark } });
            if (waterMarkRecord) {
                const wmObj = waterMarkRecord.toJSON();
                if (wmObj.waterMarkImg && Buffer.isBuffer(wmObj.waterMarkImg)) {
                    wmObj.imageBase64 = wmObj.waterMarkImg.toString('base64');
                    delete wmObj.waterMarkImg;
                }
                settingData.waterMarkDetails = wmObj;
            }
        }

        // Populate colour details
        if (settingData.colour) {
            const colourRecord = await colourList.findOne({ where: { id: settingData.colour } });
            if (colourRecord) {
                settingData.colourDetails = colourRecord.toJSON();
            }
        }

        // Populate logo details
        if (settingData.logo) {
            const logoRecord = await logoModel.findOne({ where: { id: settingData.logo } });
            if (logoRecord) {
                const logoObj = logoRecord.toJSON();
                if (logoObj.logoImage) {
                    logoObj.logoImage = `${req.protocol}://${req.get('host')}/uploads/${logoObj.logoImage}`;
                }
                settingData.logoDetails = logoObj;
            }
        }

        return res.status(200).json({
            status: true,
            message: "Invoice setting retrieved successfully.",
            data: settingData
        });
    }
    catch (error) {
        console.error("Error fetching invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static updateInvoiceSetting = catchAsyncErrors(async (req, res, next) => {
    const { templateName, logoPosition, logoSize, logoId, colourId, headerId, waterMarkId } = req.body;
    const userId = req.user.id;
    const user = await clientModel.findOne({
        attributes: ['id', 'database_name'],
        where: { id: userId }
    });
    if (!user) {
        return res.status(404).json({ status: false, message: 'User not found' });
    }
    const db_name = user.database_name;
    if (!db_name) {
        return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
    }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );
    try {
        // Find the existing invoice setting
        const existingSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: req.user.id }
        });
        if (!existingSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice setting not found.",
                data: {}
            });

        }
        // Update the invoice setting
        const updatedSetting = await existingSetting.update({
            name: templateName || existingSetting.name,
            logoPosition: logoPosition || existingSetting.logoPosition,
            logoSize: logoSize || existingSetting.logoSize,
            logo: logoId || existingSetting.logo,
            colour: colourId || existingSetting.colour,
            header: headerId || existingSetting.headerId,
            waterMark: waterMarkId || existingSetting.waterMarkId
        });
        return res.status(200).json({
            status: true,
            message: "Invoice setting updated successfully.",
            data: updatedSetting
        });
    } catch (error) {
        console.error("Error updating invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});


//For Invoice Option Setting
static getInvoiceOptionSetting = catchAsyncErrors(async (req, res, next) => {
    try{
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const invoiceOptionSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: req.user.id}
        });

        if (!invoiceOptionSetting) {
            return res.status(404).json({
                status: false,
                message: "Invoice option setting not found.",
                data: {}
            });
        }

        return res.status(200).json({
            status: true,
            message: "Invoice option setting retrieved successfully.",
            data: invoiceOptionSetting
        });
    }
    catch (error) {
        console.error("Error fetching invoice setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
});

static invoiceOptionSetting = catchAsyncErrors(async (req, res, next) => {
    try {
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const {
            shippingDetails,
            due_date,
            payment_terms,
            itemCode,
            quantityAndRate,
            pTax,
            tax_amounts,
            includeSignatureLine,
            invoicePrifix
        } = req.body;

        // Prepare data for upsert
        const invoiceOptionSettingData = {
            client_admin_id: userId,
            shippingDetails: shippingDetails ?? null,
            due_date: due_date ?? null,
            payment_terms: payment_terms ?? null,
            itemCode: itemCode ?? null,
            quantityAndRate: quantityAndRate ?? null,
            pTax: pTax ?? null,
            tax_amounts: tax_amounts ?? null,
            includeSignatureLine: includeSignatureLine ?? null,
            invoicePrifix: invoicePrifix || null
        };

        // Check if the setting already exists
        let invoiceOptionSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: userId }
        });

        if (invoiceOptionSetting) {
            // Update existing setting
            await invoiceOptionSetting.update(invoiceOptionSettingData);
        } else {
            // Create new setting
            invoiceOptionSetting = await connection.InvoiceOptionSetting.create(invoiceOptionSettingData);
        }

        // Fetch the latest data to return
        const savedSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: userId }
        });

        return res.status(200).json({
            status: true,
            message: "Invoice option setting saved successfully.",
            data: savedSetting
        });
    } catch (error) {
        console.error("Error saving invoice option setting:", error);
        return res.status(500).json({
            status: false,
            message: "Internal server error.",
            data: {}
        });
    }
})

//For Invoice Template Preview
static previewTemplate = catchAsyncErrors(async (req, res, next) => {
    try {
        const { templateName } = req.body;
        // Fetch template
        const result = await invoiceModel.findOne({
            where: { name: templateName }
        });

        if (!result) {
            return res.status(404).json({
                status: false,
                message: "No templates found.",
                data: []
            });
        }

        let templateData = result.dataValues.text;

        // Get user and DB info
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Fetch settings
        const optionSetting = await connection.InvoiceOptionSetting.findOne({
            where: { client_admin_id: userId }
        });
        const invoiceSetting = await connection.InvoiceSetting.findOne({
            where: { client_admin_id: userId }
        });

        // Prepare preview data based on settings
        let previewData = {
            invoice_number: 1,
            created_date: new Date().toISOString().split('T')[0],
            due_date: optionSetting?.due_date ? new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0] : undefined,
            company_name: "Raise Invoice",
            company_address: "5678 Innovation Blvd, Tech City, TX 75001",
            client_name: "Alice Doe",
            client_email: "alice@example.com",
            client_phone: "1232456765",
            items: [
                { name: "Web Development Package", price: "$500.00" }
            ],
            subtotal_amount: "$500.00",
            total_amount: "$500.00",
            discount_amount: "$0.00",
            tax: optionSetting?.tax_amounts ? "GST 18% ($500.00)" : undefined,
            tax_amounts: optionSetting?.tax_amounts ? "$90.00" : undefined,
            paid_amount: "$100.00",
            balance_due: "$425.00",
            shippingDetails: optionSetting?.shippingDetails ? "1234 Shipping Lane, Ship City, ST 12345" : undefined,
            payment_terms: optionSetting?.payment_terms ? "Net 30" : undefined,
            itemCode: optionSetting?.itemCode ? "ITEM-001" : undefined,
            quantityAndRate: optionSetting?.quantityAndRate ? "Qty: 1, Rate: $500.00" : undefined,
            pTax: optionSetting?.pTax ? "18%" : undefined,
            includeSignatureLine: optionSetting?.includeSignatureLine ? true : undefined,
            invoicePrifix: optionSetting?.invoicePrifix || ""
        };

        // Add logo, header, watermark, colour if present in invoiceSetting
        if (invoiceSetting) {
            previewData.logoPosition = invoiceSetting.logoPosition;
            // Set logoSize based on value
            if (invoiceSetting.logoSize === 'small') {
                previewData.logoSize = '100px';
            } else if (invoiceSetting.logoSize === 'middium') {
                previewData.logoSize = '150px';
            } else if (invoiceSetting.logoSize === 'large') {
                previewData.logoSize = '200px';
            } else {
                previewData.logoSize = invoiceSetting.logoSize;
            }

            // Populate logo details
            if (invoiceSetting.logo) {
                const logoRecord = await logoModel.findOne({ where: { id: invoiceSetting.logo } });
                if (logoRecord) {
                    const logoObj = logoRecord.toJSON();
                    if (logoObj.logoImage) {
                        logoObj.logoImage = `${req.protocol}://${req.get('host')}/uploads/${logoObj.logoImage}`;
                    }
                    previewData.logo = logoObj.logoImage;
                }
            }

            // Populate colour details
            if (invoiceSetting.colour) {
                const colourRecord = await colourList.findOne({ where: { id: invoiceSetting.colour } });
                if (colourRecord) {
                    const colourObj = colourRecord.toJSON();
                    previewData.colour = colourObj.colourCode;
                    
                }
            }

            // Fetch header image as base64 if header is present
            if (invoiceSetting.header) {
                const headerRecord = await invoiceHeaderModel.findOne({ where: { id: invoiceSetting.header } });
                if (headerRecord && headerRecord.headerImg && Buffer.isBuffer(headerRecord.headerImg)) {
                    previewData.header = headerRecord.headerImg.toString('base64');
                }
            }

            // Fetch watermark image as base64 if waterMark is present
            if (invoiceSetting.waterMark) {
                const waterMarkRecord = await InvoiceWaterMarkModel.findOne({ where: { id: invoiceSetting.waterMark } });
                if (waterMarkRecord && waterMarkRecord.waterMarkImg && Buffer.isBuffer(waterMarkRecord.waterMarkImg)) {
                    previewData.waterMark = waterMarkRecord.waterMarkImg.toString('base64');
                }
            }
        }

        // Remove undefined fields
        Object.keys(previewData).forEach(key => previewData[key] === undefined && delete previewData[key]);

        // Render template
        const renderedInvoice = mustache.render(templateData, previewData);

        if (renderedInvoice) {
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(renderedInvoice);
        } else {
            return res.status(500).send({});
        }
    } catch (error) {
        console.error("Error Rendering Invoice:", error);
        return res.status(500).send({});
    }
});


//For All the Logo, Image, Colour, Header and Watermark related operations
static addLogo = catchAsyncErrors(async (req, res, next) =>{
    try {
        let fileName = "";

        if (req.files && req.files.logoImage) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.logoImage);
            fileName = image.newfileName;
        }
        
        const uuid = crypto.randomUUID();
        let logoFields = {
            uuid,
            logoImage : fileName || null
        };

        const logoCreated = await super.create(res, logoModel , logoFields);

        return res.status(200).json({
            status: true,
            message: "Logo Added successfully.",
            data: logoCreated
        });
    } catch (error) {
        console.error('Error creating Items:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
})

static logoList = catchAsyncErrors(async (req, res, next) =>{
    try {
        const invoiceLogo = await logoModel.findAll();

        // Add full image URL to the response
        const logoWithImageURL = invoiceLogo.map(logo => ({
        ...logo.toJSON(),
        logoImage: logo.logoImage ? `${req.protocol}://${req.get('host')}/uploads/${logo.logoImage}` : null
    }));

        return res.status(200).json({
            status: true,
            message: "logo retrieved successfully.",
            data: logoWithImageURL,
        });
    } catch (error) {
        console.error("Error fetching Items:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
})

static uploadImage = catchAsyncErrors(async (req, res, next) =>{
    try {
        let fileName = "";

        if (req.files && req.files.uploadImage) {
            let image = await fileUploaderSingle("src/public/uploads/", req.files.uploadImage);
            fileName = image.newfileName;
        }
        
        const uuid = crypto.randomUUID();
        let uploadFields = {
            uuid,
            uploadImage : fileName || null
        };

        const imageCreated = await super.create(res, uploadImage , uploadFields);

        return res.status(200).json({
            status: true,
            message: "Image Added successfully.",
            data: imageCreated
        });
    } catch (error) {
        console.error('Error creating Items:', error);
        return res.status(500).json({
            status: false,
            message: "Oops.. something went terribly wrong!",
            data: {}
        });
    }
})

static colourList = catchAsyncErrors(async (req, res, next) =>{
        try {
        const colourlist = await colourList.findAll();

        return res.status(200).json({
            status: true,
            message: "colourList retrieved successfully.",
            data: colourlist,
        });
    } catch (error) {
        console.error("Error fetching Items:", error);
        return res.status(500).json({
            status: false,
            message: "Oops... something went terribly wrong!",
            data: {}
        });
    }
})

static headerList = catchAsyncErrors(async (req, res, next) => {
try {
    const HeaderList = await invoiceHeaderModel.findAll();

    // Convert buffer images to base64 with MIME type prefix
    const headersWithBase64 = HeaderList.map(header => {
        const headerObj = header.toJSON();
        if (headerObj.headerImg && Buffer.isBuffer(headerObj.headerImg)) {
            const base64String = headerObj.headerImg.toString('base64');
            headerObj.headerBase64 = `${base64String}`; // Assuming PNG format
            delete headerObj.headerImg; // Remove raw buffer from response
        }
        return headerObj;
    });

    return res.status(200).json({
        status: true,
        message: "Headers retrieved successfully.",
        data: headersWithBase64,
    });
} catch (error) {
    console.error("Error fetching Items:", error);
    return res.status(500).json({
        status: false,
        message: "Oops... something went terribly wrong!",
        data: {}
    });
}
})

static waterMarkList = catchAsyncErrors(async (req, res, next) => {
try {
    const InvoiceWaterMarks = await InvoiceWaterMarkModel.findAll();

    // Convert buffer images to base64 with MIME type prefix
    const watermarksWithBase64 = InvoiceWaterMarks.map(wm => {
        const wmObj = wm.toJSON();
        if (wmObj.waterMarkImg && Buffer.isBuffer(wmObj.waterMarkImg)) {
            const base64String = wmObj.waterMarkImg.toString('base64');
            wmObj.imageBase64 = `${base64String}`; // Assuming PNG format
            delete wmObj.waterMarkImg; // Remove raw buffer from response
        }
        return wmObj;
    });

    return res.status(200).json({
        status: true,
        message: "WaterMarks retrieved successfully.",
        data: watermarksWithBase64,
    });
} catch (error) {
    console.error("Error fetching Items:", error);
    return res.status(500).json({
        status: false,
        message: "Oops... something went terribly wrong!",
        data: {}
    });
}
})
}
module.exports = invoiceController;






