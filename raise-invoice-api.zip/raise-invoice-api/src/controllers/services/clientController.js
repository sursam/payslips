const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const roleModel = db.Roles;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { generateUniqueAccountId, createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;


const { connectSpecificToDatabase } = require("../../config/specificConnect");

class clientController extends BaseController {
    constructor() {
        super();
    }

    static createClient = catchAsyncErrors(async (req, res, next) => {
        const {
            name,
            email,
            address,
            alt_email,
            dialCode,
            phone,
            contact_name,
            contactdialCode,
            contactPhone,
            contactWebsite,
            payment_term,
            tax_no,
            notes
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let clientFields = {};
            let clientContactFields = {};
            let clientOtherFields = {};
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.profileImage) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
                fileName = image.newfileName;
            }
            const uuid = crypto.randomUUID();
            clientFields = {
                uuid,
                name,
                email,
                address,
                alt_email,
                dialCode,
                phone,
                created_by: userId,
                profileImage: fileName || null
            };

            // Create client
            const addClient = await super.create(res, connection.Client, clientFields, { transaction });

            // Prepare contact fields
            clientContactFields = {
                uuid: uuid,
                clientId: addClient.id,
                contact_name,
                dialCode: contactdialCode,
                phone: contactPhone,
                website: contactWebsite
            };

            // Create client contact
            await super.create(res, connection.ClientContact, clientContactFields, { transaction });

            // Prepare other fields
            clientOtherFields = {
                uuid: uuid,
                clientId: addClient.id,
                payment_term,
                tax_no,
                notes
            };

            // Create client other details
            await super.create(res, connection.ClientOther, clientOtherFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client added successfully.",
                data: addClient
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static getAllClients = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id ?? req.body.uuid;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const clients = await connection.Client.findAll({
            });

            // Add full image URL to the response
            const clientsWithImageURL = clients.map(client => ({
                ...client.toJSON(),
                profileImage: client.profileImage ? `${req.protocol}://${req.get('host')}/uploads/${client.profileImage}` : null
            }));

            return res.status(200).json({
                status: true,
                message: "Clients retrieved successfully.",
                data: clientsWithImageURL
            });
        } catch (error) {
            console.error('Error fetching clients:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    //--------------------------------------------------------------------------------------------
    // static getAllClients = catchAsyncErrors(async (req, res, next) => {
    //     const userId = req.user.id ?? req.body.uuid;
    //     const user = await clientModel.findOne({
    //         attributes: ['id', 'database_name'],
    //         where: { id: userId }
    //     });

    //     if (!user) {
    //         return res.status(404).json({ status: false, message: 'User  not found' });
    //     }

    //     const db_name = user.database_name;
    //     if (!db_name) {
    //         return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
    //     }

    //     // const { sequelize2, ClientRaiseModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
    //     const connection = await connectSpecificToDatabase(
    //         db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
    //     );

    //     try {
    //         const clients = await connection.Client.findAll({
    //         });

    //         return res.status(200).json({
    //             status: true,
    //             message: "Clients retrieved successfully.",
    //             data: clients
    //         });
    //     } catch (error) {
    //         console.error('Error fetching clients:', error);
    //         return res.status(500).json({
    //             status: false,
    //             message: "Oops.. something went terribly wrong!",
    //             data: {}
    //         });
    //     }
    // });

    static detailsClient = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params; // Assuming clientId is passed as a URL parameter
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );


        try {
            // Fetch client details
            const client = await connection.Client.findOne({
                where: { id: clientId },
                include: [
                    {
                        model: connection.ClientContact,
                        as: 'contacts'
                    },
                    {
                        model: connection.ClientOther,
                        as: 'otherDetails'
                    }
                ]
            });

            if (!client) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client details retrieved successfully.",
                data: client
            });
        } catch (error) {
            console.error('Error fetching client details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateClient = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params;
        const {
            name,
            email,
            alt_email,
            dialCode,
            phone,
            address,
            contact_name,
            contactdialCode,
            contactPhone,
            contactWebsite,
            payment_term,
            tax_no,
            notes
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }
        let fileName = "";
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const clientUpdateFields = {
                name,
                email,
                address,
                alt_email,
                dialCode,
                phone,
                updated_by: userId,
                // profileImage: fileName || null
            };

            if (req.files && req.files.profileImage) {
                try {
                    let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
                    fileName = image.newfileName;
                } catch (error) {
                    console.log(error);
                }
            }

            if (fileName) {
                clientUpdateFields.profileImage = fileName;
            }

            const [updatedClientCount, updatedClient] = await connection.Client.update(clientUpdateFields, {
                where: { id: clientId },
                returning: true,
                transaction
            });

            if (updatedClientCount === 0) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            // Update client contact information
            const clientContactUpdateFields = {
                contact_name,
                dialCode: contactdialCode,
                phone: contactPhone,
                website: contactWebsite
            };

            await connection.ClientContact.update(clientContactUpdateFields, {
                where: { clientId: clientId },
                transaction
            });

            // Update other client details
            const clientOtherUpdateFields = {
                payment_term,
                tax_no,
                notes
            };

            await connection.ClientOther.update(clientOtherUpdateFields, {
                where: { clientId: clientId },
                transaction
            });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client updated successfully.",
                data: updatedClient[0]
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static clientDeleteAPI = catchAsyncErrors(async (req, res, next) => {
        const { clientId } = req.params; // Assuming clientId is passed as a URL parameter
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            // Delete associated contacts
            await connection.ClientContact.destroy({
                where: { clientId: clientId },
                transaction
            });

            // Delete associated other details
            await connection.ClientOther.destroy({
                where: { clientId: clientId },
                transaction
            });

            // Delete the client
            const deletedClientCount = await connection.Client.destroy({
                where: { id: clientId },
                transaction
            });

            if (deletedClientCount === 0) {
                return res.status(404).json({ status: false, message: 'Client not found' });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client deleted successfully."
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error deleting client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static clientSubscription = catchAsyncErrors(async (req, res, next) => {
        const {
            planId,
            price,
            startDate,
            planType
        } = req.body;

        let userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name', 'email'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientPlanModel, ClientPlanPriceModel, ClientSubscriptionModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const plans = await planModel.findAll({
            include: [
                {
                    model: planPriceModel,
                    where: {
                        deletedAt: null,
                        status: true,
                    }
                },
            ],
            order: [['createdAt', 'DESC']]
        });

        // await sequelize2.query('SET FOREIGN_KEY_CHECKS = 0;');
        // await sequelize2.query('TRUNCATE TABLE plan_prices;');
        // await sequelize2.query('TRUNCATE TABLE plans;');
        // await sequelize2.query('SET FOREIGN_KEY_CHECKS = 1;');

        // for (const planData of plans) {
        //     const clientPlan = await ClientPlanModel.create({
        //         id: planData.id,
        //         uuid: planData.uuid,
        //         name: planData.name,
        //         slug: planData.slug,
        //         short_description: planData.short_description,
        //         description: planData.description,
        //         is_trial_available: planData.is_trial_available,
        //         trial_duration: planData.trial_duration,
        //         is_recommended: planData.is_recommended,
        //         status: planData.status,
        //         createdAt: planData.createdAt,
        //         updatedAt: planData.updatedAt,
        //         deletedAt: planData.deletedAt
        //     });

        //     for (const price of planData.plan_prices) {
        //         await ClientPlanPriceModel.create({
        //             id: price.id,
        //             plan_id: clientPlan.id,
        //             country_id: price.country_id,
        //             name: price.name,
        //             interval: price.interval,
        //             price: price.price,
        //             discount: price.discount,
        //             status: price.status,
        //             createdAt: price.createdAt,
        //             updatedAt: price.updatedAt,
        //             deletedAt: price.deletedAt
        //         });
        //     }
        // }

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const startDateCal = new Date(startDate);
        let endDate;

        if (planType === 'monthly') {
            endDate = new Date(startDateCal);
            endDate.setDate(startDateCal.getDate() + 30);
        } else if (planType === 'yearly') {
            endDate = new Date(startDateCal);
            endDate.setFullYear(startDateCal.getFullYear() + 1);
        }

        const clientAdmin = await connection.ClientAdmin.findOne({
            where: { email: user.email }
        });

        try {
            let buyPlanFields = {};
            userId = clientAdmin.id;
            buyPlanFields = {
                userId: userId,
                subscriptionId: planId,
                startDate,
                endDate,
                price,
                planType,
                isPaid: true
            };

            // Create client
            const addClient = await super.create(res, connection.Subscription, buyPlanFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Subscribed successfully.",
                data: addClient
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static createRole = catchAsyncErrors(async (req, res, next) => {
        const {
            roleName,
            roleSlug,
            status,
            order,
            accessStatus
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let roleFields = {};
            const uuid = crypto.randomUUID();
            roleFields = {
                uuid,
                roleName,
                roleSlug,
                status,
                order,
                accessStatus
            };

            // Create role
            const addRole = await super.create(res, connection.Role, roleFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Role added successfully.",
                data: addRole
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating role:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static getAllRoles = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const roles = await connection.Role.findAll({
            });
            return res.status(200).json({
                status: true,
                message: "Roles retrieved successfully.",
                data: roles
            });
        } catch (error) {
            console.error('Error fetching roles:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static detailsRole = catchAsyncErrors(async (req, res, next) => {
        const { roleId } = req.params; // Assuming roleId is passed as a URL parameter
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Fetch role details
            const role = await connection.Role.findOne({
                where: { id: roleId },
            });

            if (!role) {
                return res.status(404).json({ status: false, message: 'Role does not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Role details retrieved successfully.",
                data: role
            });
        } catch (error) {
            console.error('Error fetching role details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateRole = catchAsyncErrors(async (req, res, next) => {
        const { roleId } = req.params;
        const {
            roleName,
            roleSlug,
            status,
            order,
            accessStatus
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }
        let fileName = "";
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const roleUpdateFields = {
                roleName,
                roleSlug,
                status,
                order,
                accessStatus
            };
            const [updatedRoleCount, updatedRole] = await connection.Role.update(roleUpdateFields, {
                where: { id: roleId },
                returning: true,
                transaction
            });

            if (updatedRoleCount === 0) {
                return res.status(404).json({ status: false, message: 'Role does not found' });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Role updated successfully.",
                data: updatedRole[0]
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating role:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static roleDeleteAPI = catchAsyncErrors(async (req, res, next) => {
        const { roleId } = req.params; // Assuming roleId is passed as a URL parameter
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            // Delete role
            await connection.Role.destroy({
                where: { id: roleId },
                transaction
            });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Role deleted successfully."
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error deleting role:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static createClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const {
            roleId,
            name,
            email,
            address,
            dialCode,
            phone,
            password
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let clientFields = {};
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.profileImage) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
                fileName = image.newfileName;
            }
            const uuid = crypto.randomUUID();
            const hashedPassword = await bcrypt.hash(password, 10);
            const accountId = await generateUniqueAccountId();
            clientFields = {
                uuid,
                account_id: accountId,
                roleId,
                name,
                email,
                password: hashedPassword,
                address,
                dialCode,
                phone,
                created_by: userId,
                profileImage: fileName || null,
                database_name : db_name
            };

            // Create client
            const addClient = await super.create(res, connection.ClientAdmin, clientFields, { transaction });
            const clientAdmin = await super.create(res, clientModel, clientFields, { transaction });

            // Prepare contact fields
            const userRoleFields = {
                userId: addClient.id,
                roleId,
            };

            // Create client contact
            await super.create(res, connection.UserRole, userRoleFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Member added successfully.",
                data: addClient
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating member:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static getAllClientAdmins = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id ?? req.body.uuid;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const clientAdmins = await connection.ClientAdmin.findAll({
                include: [
                    {
                        model: connection.Role,
                        as: 'userRole'
                    },
                ]
            });

            // Add full image URL to the response
            const clientAdminsWithImageURL = clientAdmins.map(clientAdmin => ({
                ...clientAdmin.toJSON(),
                profileImage: clientAdmin.profileImage ? `${req.protocol}://${req.get('host')}/uploads/${clientAdmin.profileImage}` : null
            }));

            return res.status(200).json({
                status: true,
                message: "Client Admins retrieved successfully.",
                data: clientAdminsWithImageURL
            });
        } catch (error) {
            console.error('Error fetching client admins:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    static detailsClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { clientAdminId, uuid } = req.params;
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );


        try {
            // Fetch client admin details
            let whereClause = {};
            if (clientAdminId) {
                whereClause.id = clientAdminId;
            }
            if (uuid) {
                whereClause.uuid = uuid;
            }
            const clientAdmin = await connection.ClientAdmin.findOne({
                where: whereClause,
                include: [
                    {
                        model: connection.Role,
                        as: 'userRole'
                    },
                ]
            });

            if (!clientAdmin) {
                return res.status(404).json({ status: false, message: 'Client admin not found' });
            }

            return res.status(200).json({
                status: true,
                message: "Client admin details retrieved successfully.",
                data: clientAdmin
            });
        } catch (error) {
            console.error('Error fetching client admin details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateClientAdmin = catchAsyncErrors(async (req, res, next) => {
        const { clientAdminId } = req.params;
        const {
            name,
            roleId,
            // email,
            dialCode,
            phone,
            address,
            password
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }
        let fileName = "";
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const editedUser = await connection.ClientAdmin.findOne({
                attributes: ['id'],
                include: [
                    {
                        model: connection.Role,
                        as: 'userRole'
                    },
                ],
                where: { id: clientAdminId }
            });
            const clientAdminUpdateFields = {
                name,
                // roleId,
                // email,
                address,
                dialCode,
                phone,
            };
            if (editedUser && editedUser.userRole[0].roleSlug != 'super-admin') {
                clientAdminUpdateFields.roleId = roleId;
            }

            if (password) {
                const hashedPassword = await bcrypt.hash(password, 10);
                clientAdminUpdateFields.password = hashedPassword;
            }
            if (req.files && req.files.profileImage) {
                try {
                    let image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
                    fileName = image.newfileName;
                } catch (error) {
                    console.log(error);
                }
            }

            if (fileName) {
                clientAdminUpdateFields.profileImage = fileName;
            }

            const [updatedClientAdminCount, updatedClientAdmin] = await connection.ClientAdmin.update(clientAdminUpdateFields, {
                where: { id: clientAdminId },
                returning: true,
                transaction
            });

            // console.log(clientAdminId, updatedClientAdminCount, updatedClientAdmin)

            if (updatedClientAdminCount === 0) {
                return res.status(404).json({ status: false, message: 'Client admin not found' });
            }

            // Prepare contact fields
            const userRoleFields = {
                roleId,
            };
            await connection.UserRole.update(userRoleFields, {
                where: { userId: clientAdminId },
                transaction
            });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client admin updated successfully.",
                data: updatedClientAdmin[0]
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating client admin:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static clientAdminDeleteAPI = catchAsyncErrors(async (req, res, next) => {
        const { clientAdminId } = req.params; // Assuming clientAdminId is passed as a URL parameter
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            await connection.UserRole.destroy({
                where: { userId: clientAdminId },
                transaction
            });
            // Delete the client admin
            const deletedClientAdminCount = await connection.ClientAdmin.destroy({
                where: { id: clientAdminId },
                transaction
            });

            if (deletedClientAdminCount === 0) {
                return res.status(404).json({ status: false, message: 'Client admin not found' });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Client admin deleted successfully."
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error deleting client admin:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
}

module.exports = clientController;