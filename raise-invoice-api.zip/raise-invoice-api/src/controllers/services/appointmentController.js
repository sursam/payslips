const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const clientApp = db.clientApp;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB, getWeekRange, getAllWeekRanges } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");
const { addAbortListener } = require("events");

class appointmentController extends BaseController {
    constructor() {
        super();
    }

    static createAppointment = catchAsyncErrors(async (req, res, next) => {
        const {
            client_id,
            location,
            latitude,
            longitude,
            start_date,
            start_time,
            end_date,
            end_time,
            notes,
            status
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let appointmentFields = {};
            let fileName = "";

            // Handle file upload
            if (req.files && req.files.document) {
                let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
                fileName = image.newfileName;
            }
            const uuid = crypto.randomUUID();
            appointmentFields = {
                uuid,
                client_id,
                client_admin_id: userId,
                location,
                latitude,
                longitude,
                start_date,
                start_time,
                end_date,
                end_time,
                notes,
                status,
                document: fileName || null
            };

            // Create Appointment
            const addAppointment = await super.create(res, connection.CompanyAppointment, appointmentFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Appointment created successfully.",
                data: addAppointment
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating client:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
    //--------------------------------------------------------------------------------------------
    static getAllAppointments = catchAsyncErrors(async (req, res, next) => {
        try {
            const { month, year } = req.body;
            const userId = req.user.id;

            // Fetch user and database details
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });

            if (!user) {
                return res.status(404).json({ status: false, message: 'User not found' });
            }

            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }

            // Connect to the specific database
            const connection = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

            // Use provided year or current year
            const selectedYear = year ? parseInt(year) : new Date().getFullYear();

            // Fetch appointments and filter them by start date within the selected year and requested month
            const appointments = await connection.CompanyAppointment.findAll();
            const filteredAppointments = appointments.filter(app => {
                const startDate = new Date(app.start_date);
                return startDate.getFullYear() === selectedYear && startDate.getMonth() + 1 === parseInt(month);
            });

            // Get unique client_ids from filtered appointments
            const clientIds = [...new Set(filteredAppointments.map(app => app.client_id))];

            // Fetch client data for these client_ids
            const clients = await connection.Client.findAll({
                where: { id: { [Op.in]: clientIds } }
            });

            // Map client id to client data for quick lookup
            const clientMap = {};
            clients.forEach(client => {
                clientMap[client.id] = client;
            });

            // Attach client data to each appointment
            const appointmentsWithClient = filteredAppointments.map(app => {
                const appObj = app.toJSON ? app.toJSON() : { ...app };
                return {
                    ...appObj,
                    client: clientMap[app.client_id] || null
                };
            });

            // Get the correct month name based on the requested month
            const dateObj = new Date(selectedYear, parseInt(month) - 1);
            const monthName = dateObj.toLocaleString('default', { month: 'short' });

            // Initialize all expected week ranges for the requested month
            const weekRanges = getAllWeekRanges(monthName);
            const groupedAppointments = {};
            weekRanges.forEach(range => {
                groupedAppointments[range] = [];
            });

            // Group appointments into week ranges
            appointmentsWithClient.forEach(app => {
                const startDate = new Date(app.start_date);
                const weekRange = getWeekRange(startDate);

                if (groupedAppointments[weekRange]) {
                    groupedAppointments[weekRange].push(app);
                }
            });

            // Convert object to array format
            const formattedResponse = Object.keys(groupedAppointments).map(range => ({
                range,
                appointments: groupedAppointments[range]
            }));

            return res.status(200).json({
                status: true,
                message: "Appointments retrieved successfully.",
                data: formattedResponse
            });
        } catch (error) {
            console.error('Error fetching appointments:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });
}

module.exports = appointmentController;