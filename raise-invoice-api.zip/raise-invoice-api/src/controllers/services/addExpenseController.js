const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const db = require("../../models");
const clientModel = db.Clients;
const crypto = require("crypto");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");


class addExpenseController extends BaseController {
        constructor() {
            super();
        }
        static addExpense = catchAsyncErrors(async (req, res, next) => {
            const {
                projectId,
                date,
                merchant,
                catagory,
                rate,
                tax,
                tip,
                description
            } = req.body;

            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
        
            const transaction = await connection.sequelize.transaction();
        
            try {
                let expenseFields = {};
                let fileName = "";
        
                if (req.files && req.files.document) {
                    let image = await fileUploaderSingle("src/public/uploads/", req.files.document);
                    fileName = image.newfileName;
                }
                
                const uuid = crypto.randomUUID();
                expenseFields = {
                    uuid,
                    projectId,
                    date,
                    merchant,
                    catagory,
                    rate,
                    tax,
                    tip,
                    description,
                    profileImage : fileName || null
                };
        
                const expenseCreated = await super.create(res, connection.Expense, expenseFields, { transaction });
        
                await transaction.commit();
        
                return res.status(200).json({
                    status: true,
                    message: "Expense added successfully",
                    data: expenseCreated
                });
            } catch (error) {
                await transaction.rollback();
                console.error('Error creating Expense:', error);
                return res.status(500).json({
                    status: false,
                    message: "Oops.. something went terribly wrong!",
                    data: {}
                });
            }
        });

        static updateExpense = catchAsyncErrors(async (req, res, next) => {
            const {
                id,
                projectId,
                date,
                merchant,
                catagory,
                rate,
                tax,
                tip,
                description,
                profileImage
            } = req.body;

            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
        
            const transaction = await connection.sequelize.transaction();

            try {

                const updateFields = {
                    projectId,
                    date,
                    merchant,
                    catagory,
                    rate,
                    tax,
                    tip,
                    description,
                    profileImage
                }

                const [updatedexpenseCount] = await connection.Expense.update(updateFields, { 
                    where: { id: id },
                    transaction
                });
      
                const updatedExpense = await connection.Expense.findOne({
                    where: { id: id },
                    transaction
                });
        
                if (updatedexpenseCount === 0) {
                    return res.status(404).json({ status: false, message: "Expense not found or no changes made." });
                }
        
                await transaction.commit();

                res.status(200).json({
                    status: true,
                    message: "Expense updated successfully",
                    data: updatedExpense
                });
            } catch (error) {
                await transaction.rollback();
                console.error("Error updating Expense:", error);
                return res.status(500).json({
                    status: false,
                    message: "An error occurred while updating the Expense.",
                    data: {}
                });
            }
        });

        static deleteExpense = catchAsyncErrors(async (req, res, next) => {
            const { uuid } = req.body;
        
            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
        
            const transaction = await connection.sequelize.transaction();
        
            try {
                const deletedExpenseCount = await connection.Expense.destroy({
                    where: { uuid: uuid },
                    transaction
                });
        
                if (!deletedExpenseCount) {
                    return res.status(404).json({ status: false, message: "Expense not found." });
                }
        
                await transaction.commit();
        
                return res.status(200).json({
                    status: true,
                    message: "Expense deleted successfully."
                });
            } catch (error) {
                await transaction.rollback();
                console.error("Error deleting Expense:", error);
                return res.status(500).json({
                    status: false,
                    message: "An error occurred while deleting the Expense.",
                    data: {}
                });
            }
        });

        static getExpenseDetails = catchAsyncErrors(async (req, res, next) => {
            const { id } = req.body;
        
            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
        
            try {
                const expense = await connection.Expense.findOne(
                    { where: { id: id },
                    include: [
                        {
                            model: connection.CompanyProject,
                            as: 'client_projects'
                        }
                    ]
                });
        
                if (!expense) {
                    return res.status(404).json({ status: false, message: "Expense not found." });
                }
        
                return res.status(200).json({
                    status: true,
                    message: "Expense details retrieved successfully.",
                    data: expense
                });
            } catch (error) {
                console.error("Error fetching expense details:", error);
                return res.status(500).json({
                    status: false,
                    message: "An error occurred while retrieving expense details.",
                    data: {}
                });
            }
        });

        static listExpenses = catchAsyncErrors(async (req, res, next) => {
            const userId = req.user.id;
            const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        
            if (error) {
                return res.status(404).json({ status: false, message: error });
            }
        
            try {
                const expenses = await connection.Expense.findAll({
                    include: [
                        {
                            model: connection.CompanyProject,
                            as: 'client_projects'
                        }
                    ]
                });
    
                // Add full image URL to the response
                const expenseWithImageURL = expenses.map(expense => ({
                ...expense.toJSON(),
                profileImage: expense.profileImage ? `${req.protocol}://${req.get('host')}/uploads/${expense.profileImage}` : null
            }));
        
                return res.status(200).json({
                    status: true,
                    message: "Expense retrieved successfully.",
                    data: expenses,
                });
            } catch (error) {
                console.error("Error fetching Expense:", error);
                return res.status(500).json({
                    status: false,
                    message: "Oops... something went terribly wrong!",
                    data: {}
                });
            }
        });

        static getConnectionForClient = async (userId, mysqlConfig) => {
            try {
                // Fetch user and their database name
                const user = await clientModel.findOne({
                    attributes: ['id', 'database_name'],
                    where: { id: userId }
                });
        
                if (!user) {
                    return { error: 'User not found', connection: null };
                }
        
                const db_name = user.database_name;
                if (!db_name) {
                    return { error: 'Please create your company first before accessing this resource.', connection: null };
                }
        
                // Establish connection
                const connection = await connectSpecificToDatabase(
                    db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
                );
        
                return { error: null, connection };
            } catch (err) {
                console.error("Error in getConnectionForClient:", err);
                return { error: 'Failed to establish a connection.', connection: null };
            }
        };
}
module.exports = addExpenseController;