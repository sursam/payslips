const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const userCompanyModel = db.UserCompanies;
const planModel = db.Plans;
const planPriceModel = db.PlanPrices;
const userModel = db.Users;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");
const taxModel = require("../../models/client/taxRatesModel");

class clientInvoiceController extends BaseController {
    constructor() {
        super();
    }

    //Invoice Operations 
    static createInvoice = catchAsyncErrors(async (req, res, next) => {
        const { client_id, items, date, term, dueDate, subTotal, discount, total, paid, balance, paymentStatus, logo } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const uuid = crypto.randomUUID();

            const invoiceFields = {
                uuid,
                client_id,
                items,
                date,
                term,
                dueDate,
                subTotal,
                discount,
                total,
                paid,
                balance,
                paymentStatus,
                logo
            };

            const invoiceCreated = await super.create(res, connection.Invoice, invoiceFields, { transaction });

            const client = await connection.Client.findOne({ where: { id: client_id } });

            const itemDetails = await Promise.all(
                items.map(async (d) => {
                    if(d?.id){
                        const item = await connection.Items.findOne({ where: { id: d.id } });
                        return item;
                    } else {
                        const item = await connection.Items.create({
                            uuid: crypto.randomUUID(),
                            item_name: d.item_name,
                            item_Description: d.item_Description,
                            rate: d.rate,
                            qty: d.qty,
                            status: 1,

                        });
                        return item;
                    }

                }))   


            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Invoice created successfully.",
                data: {
                    invoice: invoiceCreated,
                    client,
                    items: itemDetails
                }
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error creating Invoice:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getAllInvoices = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { paymentStatus } = req.body;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const filter = {};
            if (paymentStatus && paymentStatus !== "") {
                filter.paymentStatus = paymentStatus;
            }


            let invoices = await connection.Invoice.findAll({
                where: filter
            });

            const enrichedInvoices = await Promise.all(
                invoices.map(async (inv) => {
                    const client = await connection.Client.findOne({ where: { id: inv.client_id } });

                    let parsedItems;
                    if (typeof inv?.items === "string") {
                        try {
                            parsedItems = JSON.parse(inv.items);
                        } catch (err) {
                            console.error("Error parsing items JSON:", err);
                            parsedItems = [];
                        }
                    } else {
                        parsedItems = inv?.items || [];
                    }

                    return { ...inv.toJSON(), client, items: parsedItems };
                })
            );

            return res.status(200).json({
                status: true,
                message: "Invoices retrieved successfully.",
                data: enrichedInvoices
            });
        } catch (error) {
            console.error('Error fetching invoices:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static fetchNextInvoiceNumber = catchAsyncErrors(async (req, res) => {
        const userId = req.user.id;
        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            let invoices = await connection.Invoice.findAll({});

            const nextInvoiceNumber = invoices.length > 0 ? invoices[invoices.length - 1].id + 1 : 1;

            return res.status(200).json({
                status: true,
                message: "Next invoice number retrieved successfully.",
                data: { nextInvoiceNumber }
            });
        } catch (error) {
            console.error('Error fetching invoices:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getInvoiceDetails = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        try {
            const invoice = await connection.Invoice.findOne({
                where: { id: id },
            });

            if (!invoice) {
                return res.status(404).json({ status: false, message: 'Invoice not found' });
            }

            const client = await connection.Client.findOne({ where: { id: invoice.client_id } });
            let items;
            if (typeof invoice?.items === "string") {
                try {
                    items = JSON.parse(invoice.items);
                } catch (err) {
                    console.error("Error parsing items JSON:", err);
                    items = [];
                }
            } else {
                items = invoice?.items || [];
            }

            return res.status(200).json({
                status: true,
                message: "Invoice details retrieved successfully.",
                data: {
                    invoice,
                    client,
                    items
                }
            });
        } catch (error) {
            console.error('Error fetching invoice details:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static updateInvoice = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const { client_id, items, date, term, dueDate, subTotal, discount, total, paid, balance, paymentStatus, logo } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const invoiceUpdateFields = {
                client_id,
                items,
                date,
                term,
                dueDate,
                subTotal,
                discount,
                total,
                paid,
                balance,
                paymentStatus,
                logo
            };

            const [updatedInvoiceCount, updatedInvoice] = await connection.Invoice.update(invoiceUpdateFields, {
                where: { id: id },
                returning: true,
                transaction
            });

            if (updatedInvoiceCount === 0) {
                return res.status(404).json({ status: false, message: 'Invoice not found' });
            }

            const client = await connection.Client.findOne({ where: { id: client_id } });
            const itemDetails = await Promise.all(
                items.map(async (item_id) => {
                    const item = await connection.Items.findOne({ where: { id: item_id } });
                    return item;
                })
            );

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Invoice updated successfully.",
                data: {
                    invoice: updatedInvoice[0],
                    client,
                    items: itemDetails
                }
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating invoice:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static deleteInvoice = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.body;
        const userId = req.user.id;

        const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
        if (error) {
            return res.status(404).json({ status: false, message: error });
        }

        const transaction = await connection.sequelize.transaction();
        try {
            const deletedInvoiceCount = await connection.Invoice.destroy({
                where: { id: id },
                transaction
            });

            if (deletedInvoiceCount === 0) {
                return res.status(404).json({ status: false, message: 'Invoice not found' });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Invoice deleted successfully."
            });
        } catch (error) {
            await transaction.rollback();
            console.error('Error deleting invoice:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    //tax rates 
    static createTaxRate = catchAsyncErrors(async (req, res, next) => {
          const { rate, percentage, client_id } = req.body;
    
          if ((!rate && rate == "") && (!percentage && percentage == "")) {
            return res.status(404).json({ status: false, message: 'rate or percentage not found' });
         }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });
        
        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }
        
        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let taxFields = {};

            const uuid = crypto.randomUUID();
            taxFields = {
                uuid : uuid,
                rate : rate,
                percentage : percentage,
                client_id : client_id,
                client_admin_id : userId
            };

            // Create Appointment
            const taxCreated = await super.create(res, connection.TaxRates, taxFields, { transaction });

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Tax rate created successfully.",
                data: taxCreated
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating Tax rate:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    
    });

    static getAllRates = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id ?? req.body.uuid;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const allRates = await connection.TaxRates.findAll({
            });

            return res.status(200).json({
                status: true,
                message: "Tax rates retrieved successfully.",
                data: allRates
            });
        } catch (error) {
            console.error('Error fetching clients:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static deleteTaxRate = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.' ,data:{}});
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const { id } = req.body;
            const deletedRate = await connection.TaxRates.destroy({
                where: { id }
            });

            if (!deletedRate) {
                return res.status(404).json({
                    status: false,
                    message: "Tax rate not found.",
                    data: {}
                });
            }

            return res.status(200).json({
                status: true,
                message: "Tax rate deleted successfully.",
                data: {}
            });
        } catch (error) {
            console.error('Error deleting tax rate:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    static getConnectionForClient = async (userId, mysqlConfig) => {
        try {
            // Fetch user and their database name
            const user = await clientModel.findOne({
                attributes: ['id', 'database_name'],
                where: { id: userId }
            });
    
            if (!user) {
                return { error: 'User not found', connection: null };
            }
    
            const db_name = user.database_name;
            if (!db_name) {
                return { error: 'Please create your company first before accessing this resource.', connection: null };
            }
    
            // Establish connection
            const connection = await connectSpecificToDatabase(
                db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
            );
    
            return { error: null, connection };
        } catch (err) {
            console.error("Error in getConnectionForClient:", err);
            return { error: 'Failed to establish a connection.', connection: null };
        }
    };

}

module.exports = clientInvoiceController;