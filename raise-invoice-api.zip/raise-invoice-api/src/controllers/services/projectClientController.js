const BaseController = require("../BaseController");
const catchAsyncErrors = require("../../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");
const db = require("../../models");
const clientModel = db.Clients;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { createDatabase, getConnectedSpecificDB } = require("../../utils/utilities");
const JWTAuth = require("../../utils/jwtToken");
const mysqlConfig = require("../../config/index").Mysql;
const fileUploaderSingle = require("../../utils/fileUpload").fileUploaderSingle;

const { connectSpecificToDatabase } = require("../../config/specificConnect");

class ProjectController extends BaseController {
    constructor() {
        super();
    }

    // Create Project
    static createProject = catchAsyncErrors(async (req, res, next) => {
        const {
            client_id,
            project_name,
            project_location,
            latitude,
            longitude,
            project_desc,
            start_date,
            end_date,
            status,
        } = req.body;

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            let projectFields = {};

            const uuid = crypto.randomUUID();
            projectFields = {
                uuid,
                client_id,
                client_admin_id: userId,
                project_name,
                project_location,
                latitude,
                longitude,
                project_desc,
                start_date,
                end_date,
                status
            };

            // Create Project
            const addProject = await super.create(res, connection.CompanyProject, projectFields, { transaction });

            const clientDetails = await connection.Client.findOne({
                where: { id: addProject.dataValues.client_id },
            });

            if (clientDetails) {
                await connection.ProjectContacts.create({
                    uuid,
                    project_id: addProject.dataValues.id,
                    client_id,
                    client_admin_id: userId,
                    contact_name: clientDetails.name,
                    contact_email: clientDetails.email,
                    contact_phone: clientDetails.phone,
                    address: clientDetails.address
                }, { transaction });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Projects created successfully.",
                data: addProject
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error('Error creating project:', error);
            return res.status(500).json({
                status: false,
                message: "Oops.. something went terribly wrong!",
                data: {}
            });
        }
    });

    // Get All Projects
    static getAllProjects = catchAsyncErrors(async (req, res, next) => {
        const userId = req.user.id;
        const { status } = req.body;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            let filter = {};
            if (status === 1) {
                filter.status = 1; // Filter active projects
            } else if (status === 3) {
                filter.status = 3; // Filter completed projects
            }

            const projects = await connection.CompanyProject.findAll({
                where: filter,
            });

            const enrichedProjects = await Promise.all(
                projects.map(async (project) => {
                    const client = await connection.Client.findOne({
                        where: { id: project.client_id },
                    });

                    return {
                        ...project.dataValues,
                        client: client ? client.dataValues : null,
                    };
                })
            );

            return res.status(200).json({
                status: true,
                message: "Projects retrieved successfully.",
                data: enrichedProjects,
            });
        } catch (error) {
            console.error('Error fetching projects:', error);
            return res.status(500).json({
                status: false,
                message: "Oops... something went terribly wrong!",
                data: {},
            });
        }
    });

    // Get Project Details
    static getProjectDetails = catchAsyncErrors(async (req, res, next) => {

        const { client_id, projectId } = req.body;
        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Fetch project details
            const project = await connection.CompanyProject.findOne({
                where: { id: projectId, client_id: client_id },
            });

            if (!project) {
                return res.status(404).json({ status: false, message: "Project not found." });
            }

            // Fetch client details
            const client = await connection.Client.findOne({
                where: { id: project.client_id },
            });

            const enrichedProject = {
                ...project.dataValues,
                client: client ? client.dataValues : null,
            };

            return res.status(200).json({
                status: true,
                message: "Project details retrieved successfully.",
                data: {
                    enrichedProject
                },
            });
        } catch (error) {
            console.error("Error fetching project details:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving project details.",
                data: {},
            });
        }
    });

    // Update Project
    static updateProject = catchAsyncErrors(async (req, res, next) => {
        const updatedData = req.body;

        if (!updatedData.client_id && !updatedData.projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }
        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        const updateFields = {};

        // Only include fields in the `updateFields` object if they have a value
        if (updatedData.project_name) updateFields.project_name = updatedData.project_name;
        if (updatedData.project_location) updateFields.project_location = updatedData.project_location;
        if (updatedData.latitude) updateFields.latitude = updatedData.latitude;
        if (updatedData.longitude) updateFields.longitude = updatedData.longitude;
        if (updatedData.project_desc) updateFields.project_desc = updatedData.project_desc;
        if (updatedData.start_date) updateFields.start_date = updatedData.start_date;
        if (updatedData.end_date) updateFields.end_date = updatedData.end_date;
        if (updatedData.status) updateFields.status = updatedData.status;
        if (updatedData.notes) updateFields.notes = updatedData.notes;
        if (updatedData.taskName) updateFields.taskName = updatedData.taskName;
        if (updatedData.taskDescription) updateFields.taskDescription = updatedData.taskDescription;
        if (updatedData.taskStartDate) updateFields.taskStartDate = updatedData.taskStartDate;
        if (updatedData.taskEndDate) updateFields.taskEndDate = updatedData.taskEndDate;
        if (updatedData.taskPriority) updateFields.taskPriority = updatedData.taskPriority;


        try {
            const [updatedProjectCount, updatedProject] = await connection.CompanyProject.update(updateFields, {
                where: { id: updatedData.projectId, client_id: updatedData.client_id },
                returning: true,
                transaction
            });

            if (updatedProjectCount === 0) {
                return res.status(404).json({ status: false, message: "Project not found or no changes made." });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Project updated successfully.",
                data: updatedProject[0],
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error updating project:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while updating the project.",
                data: {},
            });
        }
    });

    // Delete Project
    static deleteProject = catchAsyncErrors(async (req, res, next) => {
        const { client_id, projectId } = req.body;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }
        const userId = req.user.id;

        // Find the user to get the database name
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User  not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        // const { sequelize2, ClientRaiseModel, ClientRaiseContactModel, ClientRaiseOtherModel } = await connectSpecificToDatabase(db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306');
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const deletedProject = await connection.CompanyProject.destroy({
                where: { id: projectId, client_id: client_id },
                transaction
            });
            if (!deletedProject) {
                return res.status(404).json({ status: false, message: "Project not found." });
            }

            // Commit the transaction
            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Project deleted successfully.",
            });
        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            console.error("Error deleting project:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the project.",
                data: {},
            });
        }
    });

    // Project Contacts
    static saveContacts = catchAsyncErrors(async (req, res, next) => {
        const { contact_name, contact_email, contact_phone, address, client_id, projectId } = req.body;
        const userId = req.user.id;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const uuid = crypto.randomUUID();
            const newContact = await connection.ProjectContacts.create({
                uuid: uuid,
                project_id: projectId,
                client_id: client_id,
                client_admin_id: userId,
                contact_name,
                contact_email,
                contact_phone,
                address
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Contact added successfully.",
                data: newContact,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving contact:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the contact.",
            });
        }
    });

    static getContacts = catchAsyncErrors(async (req, res, next) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(404).json({ status: false, message: 'projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const contacts = await connection.ProjectContacts.findAll({
                where: {
                    project_id: projectId,
                },
            });

            return res.status(200).json({
                status: true,
                message: "Contacts retrieved successfully.",
                data: contacts,
            });
        } catch (error) {
            console.error("Error fetching contacts:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching contacts.",
            });
        }
    });

    //Project Tasks
    static saveTask = catchAsyncErrors(async (req, res, next) => {
        const { projectId, client_id, taskName, taskDescription, taskStartDate, taskEndDate, taskPriority } = req.body;
        const userId = req.user.id;

        if (!client_id && !projectId) {
            return res.status(404).json({ status: false, message: 'client_id or projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const uuid = crypto.randomUUID();
            const newTask = await connection.ProjectTasks.create({
                uuid: uuid,
                project_id: projectId,
                client_id: client_id,
                taskName,
                taskDescription,
                taskStartDate,
                taskEndDate,
                taskPriority
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Task added successfully.",
                data: newTask,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving task:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the task.",
            });
        }
    });

    static getTask = catchAsyncErrors(async (req, res, next) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(404).json({ status: false, message: 'projectId not found' });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            // Get all tasks for the project
            const tasks = await connection.ProjectTasks.findAll({
                where: {
                    project_id: projectId,
                },
                raw: true
            });

            // Get all ProjectTimes for this project
            const projectTimes = await connection.ProjectTimes.findAll({
                where: {
                    project_id: projectId
                },
                raw: true
            });


            function msToHHMMSS(ms) {
                let totalSeconds = Math.floor(ms / 1000);
                let hours = Math.floor(totalSeconds / 3600);
                let minutes = Math.floor((totalSeconds % 3600) / 60);
                let seconds = totalSeconds % 60;
                return [
                    hours.toString().padStart(2, '0'),
                    minutes.toString().padStart(2, '0'),
                    seconds.toString().padStart(2, '0')
                ].join(':');
            }

            // Add timeDifference to each projectTime
            const projectTimesWithDiff = projectTimes.map((record) => {
                let diff = null;
                if (record.start_time) {
                    let startDate = record.createdAt;
                    let endDate = record.end_time ? record.updatedAt : new Date();

                    if (record.start_time.length > 8) {
                        startDate = new Date(record.start_time);
                    }
                    if (record.end_time && record.end_time.length > 8) {
                        endDate = new Date(record.end_time);
                    }

                    diff = msToHHMMSS(Math.abs(endDate - startDate));
                }
                return {
                    ...record,
                    timeDifference: diff
                };
            });

            // Attach matched ProjectTimes (with timeDifference) to each task
            const tasksWithTimes = tasks.map(task => {
                const matchedTimes = projectTimesWithDiff.filter(time => time.task_id === task.id);
                return {
                    ...task,
                    projectTimes: matchedTimes
                };
            });

            return res.status(200).json({
                status: true,
                message: "Tasks retrieved successfully.",
                data: tasksWithTimes,
            });
        } catch (error) {
            console.error("Error fetching tasks:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while fetching tasks.",
            });
        }
    });



    // Save Files
    // Save Project File (supports PDF and photo uploads)
    static saveProjectFile = catchAsyncErrors(async (req, res) => {
        const { projectId, client_id } = req.body;
        const userId = req.user.id;

        if (!projectId || !client_id) {
            return res.status(400).json({ status: false, message: "Missing required fields: projectId, client_id." });
        }

        if (!req.files || !req.files.document) {
            return res.status(400).json({ status: false, message: "No file uploaded." });
        }

        const uploadedFile = await fileUploaderSingle("./src/public/uploads/", req.files.document);
        const fileContent = uploadedFile.newfileName;
        const fileType = req.files.document.mimetype;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            const newFile = await connection.ProjectFiles.create({
                uuid: crypto.randomUUID(),
                project_id: projectId,
                client_id,
                client_admin_id: userId,
                fileContent: fileContent || null,
                fileType: fileType || null
            }, { transaction });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "File uploaded successfully.",
                data: newFile
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving file:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the file."
            });
        }
    });

    static getProjectFile = catchAsyncErrors(async (req, res) => {
        const { projectId } = req.body;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(400).json({ status: false, message: "Project ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const files = await connection.ProjectFiles.findAll({ where: { project_id: projectId } });

            if (!files || files.length === 0) {
                return res.status(200).json({ 
                    status: false, 
                    message: "No files found.",
                    data: {}
                });
            }

            const fileData = files.map(file => {
                const formatDate = (date) => {
                    if (!date) return null;
                    const d = new Date(date);
                    return d.toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: '2-digit'
                    });
                };
                return {
                    id: file.id,
                    uuid: file.uuid,
                    fileType: file.fileType,
                    fileName: file.fileContent,
                    url: `${req.protocol}://${req.get('host')}/uploads/${file.fileContent}`,
                    createdAt: formatDate(file.createdAt),
                    updatedAt: formatDate(file.updatedAt)
                };
            });

            return res.status(200).json({
                status: true,
                message: "Files retrieved successfully.",
                data: fileData
            });
        } catch (error) {
            console.error("Error retrieving files:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while retrieving the files."
            });
        }
    });

    static removeProjectFile = catchAsyncErrors(async (req, res) => {
        const { fileId } = req.body;
        const userId = req.user.id;

        if (!fileId) {
            return res.status(400).json({ status: false, message: "File ID is required." });
        }

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: "User not found." });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }

        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        try {
            const deletedFileCount = await connection.ProjectFiles.destroy({ 
                where: { 
                    id: fileId
                } });

              if (!deletedFileCount) {
                return res.status(404).json({ status: false, message: "Files not deleted." });
            }

            return res.status(200).json({
                status: true,
                message: "File deleted successfully."
            });
     
        } catch (error) {
            console.error("Error deleting the files:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while deleting the files."
            });
        }
    });
    
    //Time Tracking
    static saveProjectTime = catchAsyncErrors(async (req, res) => {
        const { id, project_id, client_id, task_id, start_time, end_time, notes } = req.body;
        const userId = req.user.id;

        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        const transaction = await connection.sequelize.transaction();

        try {
            let result;
            if (id) {
                const updateData = {};
                if (project_id !== undefined) updateData.project_id = project_id;
                if (client_id !== undefined) updateData.client_id = client_id;
                if (task_id !== undefined) updateData.task_id = task_id;
                if (notes !== undefined) updateData.notes = notes;
                if (start_time !== undefined) updateData.start_time = start_time;
                if (end_time !== undefined) updateData.end_time = end_time;

                const [updatedCount, updatedRows] = await connection.ProjectTimes.update(
                    updateData,
                    { where: { id }, returning: true, transaction }
                );

                if (updatedCount === 0) {
                    await transaction.rollback();
                    return res.status(404).json({ status: false, message: "Time record not found." });
                }
                result = updatedRows[0];
            } else {
                const createData = {
                    uuid: crypto.randomUUID(),
                    project_id,
                    client_id,
                    task_id,
                    notes,
                    start_time,
                    end_time
                };
                result = await connection.ProjectTimes.create(createData, { transaction });
            }

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Time saved successfully.",
                data: result,
            });
        } catch (error) {
            await transaction.rollback();
            console.error("Error saving time:", error);
            return res.status(500).json({
                status: false,
                message: "An error occurred while saving the time.",
            });
        }
    })
    // static getProjectTime = catchAsyncErrors(async (req, res) => {
    //     const { project_id, client_id } = req.body;
    //     const userId = req.user.id;

    //     const user = await clientModel.findOne({
    //         attributes: ['id', 'database_name'],
    //         where: { id: userId }
    //     });

    //     if (!user) {
    //         return res.status(404).json({ status: false, message: 'User not found' });
    //     }

    //     const db_name = user.database_name;
    //     if (!db_name) {
    //         return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
    //     }
    //     const connection = await connectSpecificToDatabase(
    //         db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
    //     );

    //     try {
    //         const time = await connection.ProjectTimes.findAll({
    //             where: {
    //                 project_id: project_id,
    //                 client_id: client_id
    //             },
    //             order: [
    //                 ['id', 'DESC']
    //             ]
    //         });

    //         if (!time || time.length === 0) {
    //             return res.status(200).json({ 
    //                 status: false, 
    //                 message: "No time records found.",
    //                 data : []
    //             });
    //         }

            // function msToHHMMSS(ms) {
            //     let totalSeconds = Math.floor(ms / 1000);
            //     let hours = Math.floor(totalSeconds / 3600);
            //     let minutes = Math.floor((totalSeconds % 3600) / 60);
            //     let seconds = totalSeconds % 60;
            //     return [
            //         hours.toString().padStart(2, '0'),
            //         minutes.toString().padStart(2, '0'),
            //         seconds.toString().padStart(2, '0')
            //     ].join(':');
            // }

            // const timeWithDiff = time.map((record) => {
            //     let diff = null;
            //     if (record.start_time) {
            //         let startDate = record.createdAt;
            //         let endDate = record.end_time ? record.updatedAt : new Date();

            //         if (record.start_time.length > 8) {
            //             startDate = new Date(record.start_time);
            //         }
            //         if (record.end_time && record.end_time.length > 8) {
            //             endDate = new Date(record.end_time);
            //         }

            //         diff = msToHHMMSS(Math.abs(endDate - startDate));
            //     }
            //     return {
            //         ...record.dataValues,
            //         timeDifference: diff
            //     };
            // });

    //         return res.status(200).json({
    //             status: true,
    //             message: "Time retrieved successfully.",
    //             data: timeWithDiff,
    //         });
    //     } catch (error) {
    //         console.error("Error fetching time:", error);
    //         return res.status(500).json({
    //             status: false,
    //             message: "An error occurred while fetching time.",
    //         });
    //     }
    // })
}

module.exports = ProjectController;