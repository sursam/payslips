const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const vehicleTypesModel = db.VehicleTypes;
const priceChartsModel = db.PriceCharts;

class priceChartController extends BaseController {
  constructor() {
    super();
  }

  static priceChartAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { vehicleTypeId, dailyParkingRate, overSizeRate, lateFees, id } = req.body;

    if(!vehicleTypeId) {
      return res.status(422).json({
        status: false,
        message: "Vehicle type is required.",
        data: {},
      });
    }
    if(!dailyParkingRate) {
      return res.status(422).json({
        status: false,
        message: "Daily parking rate is required.",
        data: {},
      });
    }
    if(!overSizeRate) {
      return res.status(422).json({
        status: false,
        message: "Over sized rate is required.",
        data: {},
      });
    }
    if(!lateFees) {
      return res.status(422).json({
        status: false,
        message: "Late fees is required.",
        data: {},
      });
    }

		let priceChartExists = await super.getByCustomOptionsSingle(req, priceChartsModel, {
			include: [
        {
          model: vehicleTypesModel, // including associated model
          attributes: ["typeName"], // Attributes to select from the included model
        },
      ],
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
				deletedAt: null,
			},
		});

		if(!id && priceChartExists){
			return res.status(400).json({
				status: false,
				message: "Oops..Price structure for this vehicle-type already exists..!! Please choose another vehicle-type Or, if you want to modify the prices for the currently selected vehicle-type, please edit the existing record.",
				data: priceChartExists,
			});
		}
    let updateFields = {
      vehicleTypeId: vehicleTypeId || 0,
      dailyParkingRate: dailyParkingRate || 0,
      overSizeRate: overSizeRate || 0,
      lateFees: lateFees || 0,
    };

    let updated =
      id && id != "" && id != null
        ? await super.updateById(priceChartsModel, id, updateFields)
        : await super.create(res, priceChartsModel, updateFields);

    let updatedData = {};
    if (id && id != "" && id != null) {
      updatedData = await super.getByCustomOptionsSingle(
        req,
        priceChartsModel,
        {
          where: { id: id },
        }
      );
    } else {
      updatedData = updated;
    }

    if (updatedData) {
      return res.status(200).json({
        status: true,
        message: "Success.",
        data: updatedData,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened.",
        data: {},
      });
    }
  });

  static priceChartsList = catchAsyncErrors(async (req, res, next) => {
    let options = {
			include: [
        {
          model: vehicleTypesModel, // including associated model
          attributes: ["typeName"], // Attributes to select from the included model
        },
      ],
      where: {
        isActive: true,
        deletedAt: null,
      },
      order: [["createdAt", "ASC"]],
    };

    let getPriceCharts = await super.getList(req, priceChartsModel, options);

    if (getPriceCharts.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: getPriceCharts,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });

  static priceChartDelete = catchAsyncErrors(async (req, res, next) => {
    let { id } = req.body;

    let checkExist = await super.getById(req, priceChartsModel, id);

    if(!checkExist){
      return res.status(400).json({
        status: false,
        message: "Please check the id.",
        data: {}
      });
    }
    let priceChartDeleted = await super.deleteById(
      priceChartsModel, 
      id
    );

    if(priceChartDeleted){
      let vehicleTypeDeleted = await super.deleteById(
        vehicleTypesModel, 
        checkExist.vehicleTypeId
      );

      if(vehicleTypeDeleted){
        return res.status(200).json({
          status: true,
          message: "Deleted successfully.",
          data: {}
        });
      } else {
        return res.status(500).json({
          status: false,
          message: "Price chart deletion successful. But, something went wrong while deleting vehicle type..!!",
          data: {}
        });
      }
      
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong..!!",
        data: {}
      });
    }
  });

}

module.exports = priceChartController;
