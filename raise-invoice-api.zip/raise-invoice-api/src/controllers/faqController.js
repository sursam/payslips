const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const fileUploaderSingle = require("../utils/fileUpload.js").fileUploaderSingle;
const db = require("../models");
const faqModel = db.Faqs;
const faqCategoriesModel = db.Categories;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { slugify } = require("../utils/utilities");

class faqController extends BaseController {
  constructor() {
    super();
  }
  static getFaqCategories = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
      type: 'faq',
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          name: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          slug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          description: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }
    let options = {
      where: whereClause,
      order: [["order", "ASC"]],
      include: [
        {
          model: faqModel, 
          where: {
            deletedAt: null,
            status: true,
          },
          required:false
        },
      ],
    };

    let faqCategories = await super.getList(req, faqCategoriesModel, options);

    if (faqCategories.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: faqCategories,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getFaqCategoryDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let categoryDetails = await super.getByCustomOptionsSingle(req, faqCategoriesModel, {
      where: queryConditions,
      include: [
        {
          model: faqModel, 
          where: {
            deletedAt: null,
            status: true,
          },
          required:false
        },
      ],
    });
  
    if(categoryDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: categoryDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static saveFaqCategory = catchAsyncErrors(async (req, res, next) => {
    let { id, name, description } = req.body;

    if (!name) {
      return res.status(422).json({
        status: false,
        message: "Category name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      name: name,
      type: 'faq'
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await faqCategoriesModel.findOne({
      attributes: ["name"],
      where: {
        ...condition,
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Category with this same name already exists!",
        data: checkExist,
      });
    }
    let updateFields = {
      name: name,
      slug: slugify(name),
      description: description,
      type: 'faq'
    };
    // =========== single file upload ================
    if (req.files.image) {
      let imageData = await fileUploaderSingle(
        "src/public/uploads/faq/",
        req.files.image
      );
      updateFields.image = imageData.newfileName;
    }
    // console.log(updateFields);
    // =========== single file upload ================
    let updated = null;
    let message = '';
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(faqCategoriesModel, id, updateFields)
      message = 'FAQ category successfully updated.'
    }else{
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, faqCategoriesModel, updateFields);
      message = 'FAQ category successfully created.'
    }

    if (updated) {
      let categoryId = (id && id != "" && id != null && id != 'null') ? id : updated.id;
      let categoryDetails = await faqCategoriesModel.findOne({
        where: {
          id: categoryId,
        }
      });

      return res.status(200).json({
        status: true,
        message: message,
        data: categoryDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteFaqCategory = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let categoryDetail = await super.getByCustomOptionsSingle(req, faqCategoriesModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!categoryDetail){
      return res.status(403).json({
        status: false,
        message: "Category not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      faqCategoriesModel, 
      {
        id: categoryDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Category successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });
  static getFaqList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, faqIds } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          question: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          answer: 
          {
              [Op.like]: `%${searchText}%`
          }
        },
      ] ;
    }
    if(faqIds){
      whereClause[Op.and] = [
        {
          id: 
          {
              [Op.in]: faqIds
          }
        }
      ] ;
    }
    let options = {
      where: whereClause,
      order: [["order", "ASC"]],
      include: [
        {
          model: faqCategoriesModel, 
          attributes: ["id", "name"], 
          where: {
            deletedAt: null,
            status: true,
          }
        },
      ],
    };

    let faqLists = await super.getList(req, faqModel, options);

    if (faqLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: faqLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getFaqListByCategory = catchAsyncErrors(async (req, res, next) => {
    let { searchText, id, uuid, slug} = req.body;
    let categoryDetail = null;
    let categoryId = id;
    if(slug){
      categoryDetail = await super.getByCustomOptionsSingle(req, faqCategoriesModel, {
        where: { 
          slug: slug 
        },
        attributes: ["id"],
      });
      categoryId = categoryDetail.id;
    }else if(uuid){
      categoryDetail = await super.getByCustomOptionsSingle(req, faqCategoriesModel, {
        where: { 
          uuid: uuid 
        },
        attributes: ["id"],
      });
      categoryId = categoryDetail.id;
    }
    
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    if(categoryId){
      whereClause.category_id = categoryId;
    }
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          question: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          answer: 
          {
              [Op.like]: `%${searchText}%`
          }
        },
      ] ;
    }
    let options = {
      where: whereClause,
      order: [["order", "ASC"]],
      include: [
        {
          model: faqCategoriesModel, 
          attributes: ["id", "name"], 
          where: {
            deletedAt: null,
            status: true,
          }
        },
      ],
    };

    let faqLists = await super.getList(req, faqModel, options);

    if (faqLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: faqLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getFaqDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let faqDetails = await super.getByCustomOptionsSingle(req, faqModel, {
      where: queryConditions,
      include: [
        {
          model: faqCategoriesModel, 
          attributes: ["id", "name"], 
          where: {
            deletedAt: null,
            status: true,
          }
        },
      ],
    });
  
    if(faqDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: faqDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getFaqCategoryList = catchAsyncErrors(async (req, res, next) => {
      let options = {
        attributes: [["id", "value"], ["name", "label"]],
        where: {
          type: 'faq',
          status: true,
          deletedAt: null,
        },
        order: [["order", "ASC"]],
      };
  
      let categoryLists = await faqCategoriesModel.findAll(options);
  
      if (categoryLists.length > 0) {
        return res.status(200).json({
          status: true,
          message: "Data found.",
          data: categoryLists,
        });
      } else {
        return res.status(200).json({
          status: false,
          message: "No data found.",
          data: [],
        });
      }
  });


  static saveFaq = catchAsyncErrors(async (req, res, next) => {
    let { id, question, answer, category_id } = req.body;

    if (!question) {
      return res.status(422).json({
        status: false,
        message: "Question is required.",
        data: {},
      });
    }
    if (!answer) {
      return res.status(422).json({
        status: false,
        message: "Answer is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      question: question,
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await faqModel.findOne({
      attributes: ["question"],
      where: {
        ...condition,
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "FAQ with this same questiobn already exists!",
        data: checkExist,
      });
    }
    let updateFields = {
      question: question,
      answer: answer,
      category_id: category_id
    };
    let updated = null;
    let message = '';
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(faqModel, id, updateFields)
      message = 'FAQ successfully updated.'
    }else{
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, faqModel, updateFields);
      message = 'FAQ successfully created.'
    }
    
    if (updated) {
      let faqId = (id && id != "" && id != null && id != 'null') ? id : updated.id;
      let faqDetails = await faqModel.findOne({
        where: {
          id: faqId,
        }
      });

      return res.status(200).json({
        status: true,
        message: message,
        data: faqDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteFaq = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let faqDetail = await super.getByCustomOptionsSingle(req, faqModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!faqDetail){
      return res.status(403).json({
        status: false,
        message: "FAQ not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      faqModel, 
      {
        id: faqDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "FAQ successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = faqController;
