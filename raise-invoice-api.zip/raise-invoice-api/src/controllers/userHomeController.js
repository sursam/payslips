const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const NewsLetterModel = db.NewsLetterModel;
const FeedbackHomeModel = db.FeedbackHomeModel;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");

class userHomeController extends BaseController {
  constructor() {
    super();
  }

  static getNewsletterUsrList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          email_address:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    let options = {
      where: whereClause,
      order: [["email_address", "ASC"]],
    };

    let newsLetterUsrLists = await super.getList(req, NewsLetterModel, options);

    if (newsLetterUsrLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: newsLetterUsrLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });

  static getFeedBackList = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      deletedAt: null,
    };
    if (searchText) {
      whereClause[Op.or] = [
        {
          id:
          {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          title:
          {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }
    let options = {
      where: whereClause,
      order: [["title", "ASC"]],
    };

    let feedBackUsrLists = await super.getList(req, FeedbackHomeModel, options);

    if (feedBackUsrLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: feedBackUsrLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });

  static saveFeedBack = catchAsyncErrors(async (req, res, next) => {
    let { id, title, rating, description, user_name, status } = req.body;

    let updateFields = {
      title, rating, description, user_name, status
    };
    let updated = null;
    if (id && id != "" && id != null) {
      updated = await super.updateById(FeedbackHomeModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, FeedbackHomeModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = (id && id != "" && id != null) ? "Feedback updated successfully." : "Feedback added successfully.";
    } else {
      msg = "Feedback addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });

  static deleteFeedBack = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let feedbackDetail = await super.getByCustomOptionsSingle(req, FeedbackHomeModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!feedbackDetail) {
      return res.status(403).json({
        status: false,
        message: "Feedback not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      FeedbackHomeModel,
      {
        id: feedbackDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Feedback successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = userHomeController;
