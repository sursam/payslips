const BaseController = require("../controllers/BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const db = require("../models");
const clientModel = db.Clients;
const bcrypt = require("bcryptjs");
const { Op } = require("sequelize");
const crypto = require("crypto");
const { generateUniqueAccountId, getConnectedSpecificDB } = require("../utils/utilities");
const JWTAuth = require("../utils/jwtToken");
const mysqlConfig = require("../config/index").Mysql;
const { connectSpecificToDatabase } = require("../config/specificConnect");

class accountController extends BaseController {
    constructor() {
      super();
    }
  
    // Create Accounts API
    static createAccount = catchAsyncErrors(async (req, res, next) => {
        const { name, roleId, email, password, deviceType } = req.body;

        if (!name || !roleId || !email || !password) {
            return res.status(422).json({
                status: false,
                message: "Name, Role ID, Email, and Password are required.",
                data: {},
            });
        }

        const userId = req.user.id;
        const user = await clientModel.findOne({
            attributes: ['id', 'database_name'],
            where: { id: userId }
        });

        if (!user) {
            return res.status(404).json({ status: false, message: 'User not found' });
        }

        const db_name = user.database_name;
        if (!db_name) {
            return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
        }
        const connection = await connectSpecificToDatabase(
            db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
        );

        // Start a transaction
        const transaction = await connection.sequelize.transaction();

        try {
            const existingAccount = await connection.ClientAdmin.findOne({
                attributes: ["name"],
                where: {
                    deletedAt: null,
                    [Op.or]: [{ email }],
                },
            });

            if (existingAccount) {
                return res.status(400).json({
                    status: false,
                    message: "Account already exists!",
                    data: existingAccount,
                });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            const updateFields = {
                name,
                roleId,
                email,
                password: hashedPassword,
                account_id: await generateUniqueAccountId(),
                uuid: crypto.randomUUID(),
                database_name: db_name,
            };

            const newAccount = await super.create(res, connection.ClientAdmin, updateFields, { transaction });
            const clientAdmin = await super.create(res, clientModel, updateFields, { transaction });

            // const token = JWTAuth.ClientSign({
            //     id: newAccount?.id,
            //     uuid: updateFields.uuid,
            //     name,
            //     email,
            //     deviceType,
            //     isVerified: false,
            //     isSubscribed: false,
            // });

            // const clientUpdateFields = Number(deviceType) === 2
            //     ? { webLogin: token }
            //     : { appLogin: token };

            // await super.updateById(connection.ClientAdmin, newAccount?.id, clientUpdateFields, { transaction });

            // await super.updateById(clientModel, clientAdmin?.id, clientUpdateFields, { transaction });

            const userDetails = await connection.ClientAdmin.findOne({
                attributes: ["id", "uuid", "email", "isActive", "isVerified"],
                where: { id: newAccount?.id },
            });

            await transaction.commit();

            return res.status(200).json({
                status: true,
                message: "Account created successfully.",
                data: { userDetails, deviceType },
            });
        } catch (err) {
            await transaction.rollback();
            console.error("Error creating account:", err);
            return res.status(500).json({
                status: false,
                message: "An error occurred while creating the account.",
                data: {},
            });
        }
    });

    //Update Accounts
    static updateAccount = catchAsyncErrors(async (req, res, next) => {
      const { id, name, roleId, email } = req.body;
  
      if (!name || !roleId || !email) {
          return res.status(400).json({
              status: false,
              message: "Name, Role ID, and Email are required.",
              data: {}
          });
      }
  
      const userId = req.user.id;
      const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
  
      if (error) {
          return res.status(404).json({ status: false, message: error });
      }
  
      const transaction = await connection.sequelize.transaction();
  
      try {
          const updateFields = {
                name, 
                roleId, 
                email
          };
  
          const [updatedAccountCount] = await connection.ClientAdmin.update(updateFields, { 
              where: { id: id },
              transaction
          });

          const updatedAccount = await connection.ClientAdmin.findOne({
              where: { id: id },
              transaction
          });
  
          if (updatedAccountCount === 0) {
              return res.status(404).json({ status: false, message: "account not found or no changes made." });
          }
  
          await transaction.commit();
  
          return res.status(200).json({
              status: true,
              message: "Account updated successfully.",
              data: updatedAccount
          });
      } catch (error) {
          await transaction.rollback();
          console.error("Error updating Accounts:", error);
          return res.status(500).json({
              status: false,
              message: "An error occurred while updating the account.",
              data: {}
          });
      }
    });
  
    // List All Accounts API
    static listAllAccounts = catchAsyncErrors(async (req, res, next) => {
      const userId = req.user.id;
      const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
  
      if (error) {
          return res.status(404).json({ status: false, message: error });
      }
  
      try {
          const accounts = await connection.ClientAdmin.findAll({
                where: { roleId: { [Op.ne]: null } },
                order: [["createdAt", "ASC"]],
          });

          for (const account of accounts) {
              const role = await connection.Role.findOne({
                  where: { id: account.roleId }
              });
              account.dataValues.role = role;
          }

          return res.status(200).json({
              status: true,
              message: "Accounts retrieved successfully.",
              data: accounts,
          });
      } catch (error) {
          console.error("Error fetching Accounts:", error);
          return res.status(500).json({
              status: false,
              message: "Oops... something went terribly wrong!",
              data: {}
          });
      }
    });
  
    //Fetch Single Accounts Data
    static accountDetails = catchAsyncErrors(async (req, res, next) => {
      const { id } = req.body;
  
      const userId = req.user.id;
      const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
  
      if (error) {
          return res.status(404).json({ status: false, message: error });
      }
  
      try {
          const Account = await connection.ClientAdmin.findOne({ where: { id: id } });
  
          if (!Account) {
              return res.status(404).json({ status: false, message: "Account not found." });
          }
  
          return res.status(200).json({
              status: true,
              message: "Account details retrieved successfully.",
              data: Account
          });
      } catch (error) {
          console.error("Error fetching account details:", error);
          return res.status(500).json({
              status: false,
              message: "An error occurred while retrieving account details.",
              data: {}
          });
      }
    });
  
    //Delete Accounts
    static deleteAccounts = catchAsyncErrors(async (req, res, next) => {
      const { uuid } = req.body;
  
      const userId = req.user.id;
      const { error, connection } = await this.getConnectionForClient(userId, mysqlConfig);
  
      if (error) {
          return res.status(404).json({ status: false, message: error });
      }
  
      const transaction = await connection.sequelize.transaction();
  
      try {
          const deletedAccountCount = await connection.ClientAdmin.destroy({
              where: { uuid: uuid },
              transaction
          });
  
          if (!deletedAccountCount) {
              return res.status(404).json({ status: false, message: "Account not found." });
          }
  
          await transaction.commit();
  
          return res.status(200).json({
              status: true,
              message: "Account deleted successfully."
          });
      } catch (error) {
          await transaction.rollback();
          console.error("Error deleting Account:", error);
          return res.status(500).json({
              status: false,
              message: "An error occurred while deleting the account.",
              data: {}
          });
      }
    });

    //switch account from one account to another
    static switchAccount = catchAsyncErrors(async (req, res, next) => {
        const { email, deviceType } = req.body;

        const user = await clientModel.findOne({ attributes: ['id', 'uuid', 'name', 'password', 'isVerified', 'database_name'], where: { email } });

        if (!user) {
            return res.status(200).json({
                status: false,
                message: "Client not found!",
                data: null,
            });
        }

        var token = JWTAuth.ClientSign({
            id: user?.id,
            uuid: user.uuid,
            name: user.name,
            email: email,
            deviceType: deviceType,
            isVerified: user.isVerified
        });
        let clientUpdateFields = {};
        if (Number(deviceType) == 2) {
            clientUpdateFields.webLogin = token;
        } else {
            clientUpdateFields.appLogin = token;
        }

        var clientUpdate = await super.updateById(clientModel, user?.id, clientUpdateFields);

        //////////////////////////////////////////////////////////////////////////////////////////////////

        /******************************* Specific DB Connected Start ************************************/
        if (user?.database_name) {
            const db_name = user.database_name;
            if (!db_name) {
                return res.status(200).json({ status: false, message: 'Please create your company first before accessing this resource.', data: {} });
            }
            const sequelize = await getConnectedSpecificDB(db_name);
            /******************************* Specific DB Connected End ************************************/

            const asasasa = await clientModel.findAll({ attributes: ['id', 'uuid', 'name'] });
            const [results, metadata] = await sequelize.query("SELECT id, uuid, name FROM clientadmins");

            if (sequelize) {
                await sequelize.close();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////

        return res.status(200).json({
            status: true,
            message: "Account Switch successful.",
            data: {
                user: {
                    "id": user.id,
                    "uuid": user.uuid,
                    "name": user.name,
                    "isVerified": false,
                    "isSubscribed": false,
                    "database_name": user?.database_name ?? null
                }, deviceToken: token
            },
        });
    });
  
    static getConnectionForClient = async (userId, mysqlConfig) => {
      try {
          // Fetch user and their database name
          const user = await clientModel.findOne({
              attributes: ['id', 'database_name'],
              where: { id: userId }
          });
  
          if (!user) {
              return { error: 'User not found', connection: null };
          }
  
          const db_name = user.database_name;
          if (!db_name) {
              return { error: 'Please create your company first before accessing this resource.', connection: null };
          }
  
          // Establish connection
          const connection = await connectSpecificToDatabase(
              db_name, mysqlConfig.user, mysqlConfig.pwd, mysqlConfig.host, '3306'
          );
  
          return { error: null, connection };
      } catch (err) {
          console.error("Error in getConnectionForClient:", err);
          return { error: 'Failed to establish a connection.', connection: null };
      }
    };
}

module.exports = accountController;
