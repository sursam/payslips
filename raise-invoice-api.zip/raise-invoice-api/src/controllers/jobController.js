const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const jobModel = db.Jobs;
const jobCategoriesModel = db.Categories;
const jobCategoryModel = db.JobCategories;
const { Op } = require("sequelize");
const crypto = require("crypto");
const { slugify } = require("../utils/utilities");

class jobController extends BaseController {
  constructor() {
    super();
  }
  static getJobCategories = catchAsyncErrors(async (req, res, next) => {
    let { searchText } = req.body;
    let whereClause = {
      status: true,
      deletedAt: null,
      type: 'job',
    };
    if(searchText){
      whereClause[Op.or] = [
        {
          id: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          name: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          slug: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          description: 
          {
              [Op.like]: `%${searchText}%`
          }
        }
      ] ;
    }
    let options = {
      where: whereClause,
      order: [["order", "ASC"]],
    };

    let jobCategories = await super.getList(req, jobCategoriesModel, options);

    if (jobCategories.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: jobCategories,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getJobCategoryDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let categoryDetails = await super.getByCustomOptionsSingle(req, jobCategoriesModel, {
      where: queryConditions,
    });
  
    if(categoryDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: categoryDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static saveJobCategory = catchAsyncErrors(async (req, res, next) => {
    let { id, name, description, image } = req.body;

    if (!name) {
      return res.status(422).json({
        status: false,
        message: "Category name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      name: name,
      type: 'job'
    };
    if (id) {
      // during edit -> should not check self ===
      condition.id = `{
            [Op.ne]: id
        }`;
    }

    let checkExist = await jobCategoriesModel.findOne({
      attributes: ["name"],
      where: {
        ...condition,
      },
    });

    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Category with this same name already exists!",
        data: checkExist,
      });
    }
    let updateFields = {
      name: name,
      slug: slugify(name),
      description: description,
      type: 'job'
    };
    let updated = null;
    let message = '';
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(jobCategoriesModel, id, updateFields)
      message = 'Job category successfully updated.'
    }else{
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, jobCategoriesModel, updateFields);
      message = 'Job category successfully created.'
    }

    if (updated) {
      let categoryId = (id && id != "" && id != null && id != 'null') ? id : updated.id;
      let categoryDetails = await jobCategoriesModel.findOne({
        where: {
          id: categoryId,
        }
      });

      return res.status(200).json({
        status: true,
        message: message,
        data: categoryDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteJobCategory = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let categoryDetail = await super.getByCustomOptionsSingle(req, jobCategoriesModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!categoryDetail){
      return res.status(403).json({
        status: false,
        message: "Category not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      jobCategoriesModel, 
      {
        id: categoryDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Category successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });
  static getJobList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, categoryUuid } = req.body;
    
    let whereClause = {
      status: true,
      deletedAt: null,
    };
    let whereClauseCategory = {
      status: true,
      deletedAt: null,
      type: "job"
    };
    if(categoryUuid){
      let categoryDetails = await jobCategoriesModel.findOne({
        where: {
          uuid: categoryUuid,
        }
      });
      if(categoryDetails){
        whereClauseCategory.id = categoryDetails.id;
      }
    }
    if(searchText){
      searchText = searchText.toLowerCase();
      let is_remote = 0;
      if(searchText == 'remote'){
        is_remote = 1;
      }
      whereClause[Op.or] = [
        // {
        //   id: 
        //   {
        //       [Op.like]: `%${searchText}%`
        //   }
        // }, 
        {
          title: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          description: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          key_responsibilities: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          technology_stack: 
          {
              [Op.like]: `%${searchText}%`
          }
        }, 
        {
          experience: 
          {
              [Op.like]: parseFloat(searchText)
          }
        },  
        {
          is_remote: 
          {
              [Op.like]: is_remote
          }
        }, 
        {
          language: 
          {
              [Op.like]: `%${searchText}%`
          }
        },
      ] ;
      // whereClauseCategory[Op.or] = [
      //   {
      //     name: 
      //     {
      //         [Op.like]: `%${searchText}%`
      //     }
      //   }, 
      // ]
    } 
    
    let options = {
      where: whereClause,
      order: [["order", "ASC"]],
      include: [
        {
          model: jobCategoriesModel,
          attributes: ["id", "name"],  
          where: whereClauseCategory,
        },
      ],
    };

    let jobLists = await super.getList(req, jobModel, options);

    if (jobLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: jobLists,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
  static getJobDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }

    let jobDetails = await super.getByCustomOptionsSingle(req, jobModel, {
      where: queryConditions,
      include: [
        {
          model: jobCategoriesModel, 
          attributes: ["id", "name"], 
          where: {
            deletedAt: null,
            status: true,
          }
        },
      ],
    });
  
    if(jobDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: jobDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static getJobCategoryList = catchAsyncErrors(async (req, res, next) => {
      let options = {
        attributes: ["id", "name"],
        where: {
          type: 'job',
          status: true,
          deletedAt: null,
        },
        order: [["order", "ASC"]],
      };
  
      let categoryLists = await jobCategoriesModel.findAll(options);
  
      if (categoryLists.length > 0) {
        return res.status(200).json({
          status: true,
          message: "Data found.",
          data: categoryLists,
        });
      } else {
        return res.status(200).json({
          status: false,
          message: "No data found.",
          data: [],
        });
      }
  });


  static saveJob = catchAsyncErrors(async (req, res, next) => {
    let { id, job_title, description, key_responsibilities, technology_stack, experience, language, is_remote, job_categories } = req.body;

    if (!job_title) {
      return res.status(422).json({
        status: false,
        message: "Job title is required.",
        data: {},
      });
    }
    if (!key_responsibilities) {
      return res.status(422).json({
        status: false,
        message: "Key responsibilities are required.",
        data: {},
      });
    }
    if (!technology_stack) {
      return res.status(422).json({
        status: false,
        message: "Technology stack is required.",
        data: {},
      });
    }
    if (!experience) {
      return res.status(422).json({
        status: false,
        message: "Year count of experience is required.",
        data: {},
      });
    }
    if (!job_categories) {
      return res.status(422).json({
        status: false,
        message: "Job category is required.",
        data: {},
      });
    }
    let updateFields = {
      title: job_title,
      description: description,
      key_responsibilities: key_responsibilities,
      technology_stack: technology_stack,
      experience: experience,
      language: language,
      is_remote: is_remote
    };
    let updated = null;
    let message = '';
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(jobModel, id, updateFields)
      message = 'Job successfully updated.'
    }else{
      updateFields.uuid = crypto.randomUUID();
      updated = await super.create(res, jobModel, updateFields);
      message = 'Job successfully created.'
    }

    if (updated) {
      let jobId = (id && id != "" && id != null && id != 'null') ? id : updated.id;
      await super.deleteByCondition(
        jobCategoryModel, 
        {
          job_id: jobId,
        }
      );
      job_categories.forEach(async (categoryId) => {
        let categoryFields = {
          job_id: jobId,
          category_id: categoryId,
        }
        await super.create(res, jobCategoryModel, categoryFields);
      });

      let jobDetails = await jobModel.findOne({
        where: {
          id: jobId,
        }
      });

      return res.status(200).json({
        status: true,
        message: message,
        data: jobDetails,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static deleteJob = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let jobDetail = await super.getByCustomOptionsSingle(req, jobModel, {
      where: { 
        uuid: uuid 
      },
      attributes: ["id"],
    });
    
    if(!jobDetail){
      return res.status(403).json({
        status: false,
        message: "Job not found!",
        data: {},
      });
    } 
    let deleted = await super.deleteByCondition(
      jobModel, 
      {
        id: jobDetail.id,
      }
    );

    if(deleted){
      return res.status(200).json({
        status: true,
        message: "Job successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = jobController;
