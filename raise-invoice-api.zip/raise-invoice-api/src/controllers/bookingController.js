const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op, Sequelize } = require("sequelize");

const timeZone = require("../config/index.js").Timezone;
const moment = require('moment-timezone');

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const userModel = db.Users;
const roleModel = db.Roles;
const modulePermissionsModel = db.ModulePermissions;
const vendorModel = db.Vendors;
const priceChartsModel = db.PriceCharts;
const staticChargesModel = db.StaticCharges;
const parkingLotsModel = db.ParkingLots;
const slotsModel = db.Slots;
const bookingRequestsModel = db.BookingRequests;
const vehicleTypesModel = db.VehicleTypes;
const agentModel = db.Agents;
const agentBookingMappingsModel = db.AgentBookingMappings;
const carMovementsModel = db.CarMovements;
const invoiceModel = db.Invoices;
const notificationModel = db.Notifications;

class BookingController extends BaseController {
  constructor() {
    super();
  }

	static generateBookingTicket(businessNameInitials, groundNameInitials) {
		let momentZone = moment().tz(timeZone);
		// format today's date as dd-mm-yy without spaces or hyphens
		let todayDate = momentZone.format('DDMMYY'); // "280924" for 28-09-2024
		
		// format current time in 24 (hh:mm) format without spaces or hyphens
		let currentTime = momentZone.format('HHmm'); // "2230" for 22:30

		// -------- generate ticket --------
		let ticket = `${businessNameInitials}-${groundNameInitials}-${todayDate}-${currentTime}`;
		// -------- generate ticket --------
		
		return ticket;
	}

	static customerExistCheck = catchAsyncErrors(async (req, res, next) => {
		let { customerMobile } = req.body;

		let cusotmerRole = await roleModel.findOne({
			where: {
				roleName: "Customer",
			}
		});
		let checkReturningCustomer = await userModel.findOne({
			where: {
				deletedAt: null,
				phone: customerMobile,
				roleId: cusotmerRole.id, 
			},
			attributes: {
        exclude: [
          "password",
          "webLogin",
          "appLogin",
          "fcmToken",
          "OTP",
          "macAddress",
        ],
      },
		});
		if(checkReturningCustomer){
			return res.status(200).json({
				status: true,
				message: "Returning customer found.",
				data: checkReturningCustomer,
			});
		} else {
			return res.status(200).json({
				status: false,
				message: "New customer.",
				data: {},
			});
		}
	});

	static slotDeciderOld = catchAsyncErrors(async (req, res, next) => {
		let { vehicleTypeId, checkinDate, checkoutDate, startTime, endTime } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}
		
		let termArray = ["ST", "FM", "LT", "OF"];
		let term = "";
		if(dayCount <= 3){
			// ===== SHORT TERM =====
			term = "ST";

		} else if(
			(dayCount >= 4) && (dayCount <= 15)
		){
			// ===== FAST MOVING =====
			term = "FM";

		} else if(
			(dayCount >= 16)
		){
			// ===== LONG TERM =====
			term = "LT";

		}

		let foundLotsIdArr = [];
		// ===== find lots according to STAY TERM =====
		foundLotsIdArr = await BookingController.findSlotTermWise(term);
		
		let searchedInTerms = [];
		if(foundLotsIdArr){
			termArray.forEach((item, index)=>{
				if(item == term){
					searchedInTerms.push(term);
				}
			});
		}

		let slotAvailableInFoundLots = await slotsModel.findAll({
			where: {
				occupancyStatus: "Vacant",
				parkingLotId: {
					[Op.in]: foundLotsIdArr
				}
			},
			order: [["slotRowNumber", "DESC"]],
		});
		if(slotAvailableInFoundLots.length > 0){
			// atleast one empty slot found =======
		} else {
			// search lot for another "term" =====

		}

		return res.status(200).json({
			status: true,
			data: {
				dayCount: dayCount,
				slotAvailableInFoundLots: slotAvailableInFoundLots,
			}
		});
	});

	static checkSlotValidity = catchAsyncErrors(async (req, res, next) => {
		let { slotName } = req.body;

		let foundSlot = await slotsModel.findOne({
			where: Sequelize.where(
				Sequelize.fn('lower', Sequelize.col('slotName')),
				Sequelize.fn('lower', `${slotName}`)
			),
			include: [
				{model: parkingLotsModel}
			],
		});

		let message = 'The Slot is invalid';

		if(foundSlot){
			if(foundSlot.occupancyStatus == 'Vacant'){
				let termArr = foundSlot.parkingLot.lotName.split("-");
				let term = termArr[termArr.length - 1];
				switch(term){
					case "ST":
						message = 'The Slot is available. The minimum day for booking is 1 and the maximum day is 3.';
						break;
					case "FM":
						message = 'The Slot is available. The minimum day for booking is 4 and the maximum day is 15.';
						break;
					case "LT":
						message = 'The Slot is available. The minimum day for booking is 16';
						break;
				}

				return res.status(200).json({
					status: true,
					message: message,
					data: {
						foundSlot: foundSlot ?? [],
					}
				});
			}else{
				message = 'The Slot is already booked';
			}  

		}
		return res.status(200).json({
			status: false,
			message: message,
			data: {
				foundSlot: foundSlot ?? [],
			}
		});
	});

	static slotDecider = catchAsyncErrors(async (req, res, next) => {
		let { vehicleTypeId, checkinDate, checkoutDate, startTime, endTime } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}
		
		// let termArray = ["ST", "FM", "LT", "OF"];
		let termArray = {
			"ST" : {
				"minDays": 1, "maxDays" : 3
			},
			"FM" : {
				"minDays": 4, "maxDays" : 15
			},
			"LT" : {
				"minDays": 16, "maxDays" : 365
			},
		};
		let term = "";
		if(dayCount <= 3){
			// ===== SHORT TERM =====
			term = "ST";
		} else if(
			(dayCount >= 4) && (dayCount <= 15)
		){
			// ===== FAST MOVING =====
			term = "FM";
		} else if(
			(dayCount >= 16)
		){
			// ===== LONG TERM =====
			term = "LT";
		}

		let bookedSlot = await BookingController.getBookingSlotByLot(termArray, dayCount, term);

		return res.status(200).json({
			status: true,
			data: {
				dayCount: dayCount,
				bookedSlot: bookedSlot,
				// daysArr: daysArr.reverse(),
				// slotAvailableInFoundLots: foundLotsIdArr,
			}
		});
	});
	static async getBookingSlotByLot(termArray = {}, dayCount = 0, term = "ST"){
		let minDays = termArray[term].minDays;
		let maxDays = termArray[term].maxDays;

		var foundLotsIdArr = await BookingController.findLotsWithAvailableSlots(term);
		
		let parkingLotCount = foundLotsIdArr.length;
		const step = (maxDays - minDays) / parkingLotCount;
		const daysArr = Array.from({ length: parkingLotCount}, (_, i) => Math.ceil(minDays + (i * step)));
		
		let lotKey = BookingController.findClosest(daysArr, dayCount);
		
		let bookedSlot = BookingController.getBookingSlot(foundLotsIdArr, daysArr, lotKey);
		if(bookedSlot == null){
			if(term == "ST"){
				term = "FM";
				bookedSlot = BookingController.getBookingSlotByLot(termArray, dayCount, term);
			}else if(term == "FM"){
				term = "LT";
				bookedSlot = BookingController.getBookingSlotByLot(termArray, dayCount, term);
			}
		}
		return bookedSlot;
	}
	static getBookingSlot(availableLots, daysArr, lotKey = 0, updatedKey = 0, isPrevious = false, isNext = false){
		if (!isPrevious && !isNext) {
      isPrevious = true;
      isNext = false;
    } else if (isPrevious && !isNext) {
      lotKey -= updatedKey;
      isPrevious = false;
      isNext = true;
    } else if (!isPrevious && isNext) {
      lotKey += updatedKey;
      isPrevious = true;
      isNext = false;
    }
		updatedKey++;
		if (lotKey >= 0 && lotKey <= availableLots.length) {
      if (availableLots[lotKey]?.slots.length) {
        return availableLots[lotKey].slots[0];
      } else {
        return BookingController.getBookingSlot(
          availableLots,
          daysArr,
          lotKey,
          updatedKey,
          isPrevious,
          isNext
        );
      }
    } else {
      return null;
    } 
	}
	static async findLotsWithAvailableSlots (term="ST"){
		let foundLots = [];
		foundLots = await parkingLotsModel.findAll({
			attributes: [
				'id', 'lotName'
			],
			where: {
				lotName: {
					[Op.like]: `%${term}%`
				},				
			},
			include: [
				{model: slotsModel, as: 'slots', where: {occupancyStatus: "Vacant"}}
			],
			order: [["slots", "slotRowNumber", "DESC"]],
		});

		return foundLots;
	}
	static findClosest(arr, target) {
		let left = 0,
			right = arr.length - 1;
		while (left < right) {
			if (Math.abs(arr[left] - target) <= Math.abs(arr[right] - target)) {
				right--;
			} else {
				left++;
			}
		}
		//return arr[left];
		return left;
	}

	static async findSlotTermWise (term="ST"){
		let foundLots = [];
		foundLots = await parkingLotsModel.findAll({
			where: {
				lotName: {
					[Op.like]: `%${term}%`
				}
			}
		});
		let foundLotsIdArr = [];
		foundLots.forEach((lot)=>{
			foundLotsIdArr.push(lot.id);
		});

		return foundLotsIdArr;
	}

	static async bookingRequestUpdate (id, data){
		let slotStatusUpdate = await super.updateById(bookingRequestsModel, id, data);
		return slotStatusUpdate;
	}

	static bookingRequestList = catchAsyncErrors(async (req, res, next) => {
		let loggedUserId = req.user.id;
		
		let loggedUserDetail = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				id: loggedUserId,
			},
			include: [
				{
					model: roleModel,
				}
			]
		});
		
		let roleOfLoggedUser = await super.getByCustomOptionsSingle(req, roleModel, {
			where: {
				id: loggedUserDetail?.roleId,
			}
		});
		
		let options = {
			include: [
				{
					model: userModel,
					attributes: {
						exclude: [
						"password",
						"webLogin",
						"appLogin",
						"fcmToken",
						"OTP",
						"macAddress",
						],
					},
					required: false,
				},
				{
					model: slotsModel,
					required: false,
				},
				{
					model: agentBookingMappingsModel,
					include: [
						{
							model: agentModel,
							required: false,
						},
					],
				},
			],
			where: {
				isActive: true,
				deletedAt: null,
			},
			order: [["createdAt", "DESC"]],
		};

		let totalCount = await bookingRequestsModel.count();
		let bookingRequests = await super.getList(req, bookingRequestsModel, options);

		let filteredBookingRequestsUserWise = [];
		filteredBookingRequestsUserWise = bookingRequests;

		// if(roleOfLoggedUser.roleName == "Super Admin"){
		// 	filteredBookingRequestsUserWise = bookingRequests;
		// }

		// if(roleOfLoggedUser.roleName == "Agent"){
		// 	// --------- agent can only see the bookings he is tagged in ---------
		// 	// filteredBookingRequestsUserWise = bookingRequests.filter(async (bookingRequest)=>{
		// 	// 	if(bookingRequest?.agentBookingMapping?.agent?.userId == loggedUserId){
		// 	// 		return bookingRequest;
		// 	// 	}
		// 	// });
		// }

		if(filteredBookingRequestsUserWise.length > 0){
			return res.status(200).json({
				status: true,
				message: "Data found.",
				data: filteredBookingRequestsUserWise,
				totalCount: totalCount,
			});
		} else {
			return res.status(200).json({
				status: false,
				message: "No data found.",
				data: {}
			});
		}
	});

	static bookingRequestDetail = catchAsyncErrors(async (req, res, next) => {
		let { 
			// ================= INSTRUCTIONS =================
			// ===== send parameter/s from either Group-1 <or> Group-2 ======
			// ================= INSTRUCTIONS =================

			// ============= Group-1 ============= 
    	// ---- single search fields (send either of the following ones) ----
			bookingRequestId, 
			bookingTicketNo, 
    	// ---- single search fields (send either of the following ones) ----
			// ============= Group-1 ============= 

			// ============= <OR> =============

			// ============= Group-2 ============= 
    	// ---- search with these 2 fields is possible together (send single <or> both as per need)----
			customerMobile, 
			plateNumber, 
    	// ---- search with these 2 fields is possible together (send single <or> both as per need)----
			// ============= Group-2 ============= 
		} = req.body;

		if(!bookingRequestId && !bookingTicketNo && !customerMobile && !plateNumber){
			return res.status(422).json({
				status: false,
				message: "Blank search not allowed. Please search with either bookingRequestId <or> bookingTicketNo <or> customerMobile <or> plateNumber",
				data: {}
			});
		}

		let searchOptions = {};

		if(bookingRequestId){
			searchOptions.id = bookingRequestId;

		} else if(bookingTicketNo){
			searchOptions.bookingTicketNo = bookingTicketNo;

		} else if(customerMobile || plateNumber){
			// ===== only these two things can be searched together =====
			if(customerMobile){
				searchOptions.customerMobile = customerMobile;
			}
			if(plateNumber){
				searchOptions.plateNumber = plateNumber;
			}
			// ===== only these two things can be searched together =====
		}

		let bookingRequest = await super.getByCustomOptionsSingle(
			req, 
			bookingRequestsModel, 
			{
				where: searchOptions,
				include: [
					{
						model: slotsModel
					}
				],
			}
		);

		if(bookingRequest){
			if(bookingRequest.isCancelled){
				return res.status(200).json({
					status: false,
					message: "Booking request data found. But request was cancelled.",
					data: bookingRequest
				});
			}
			return res.status(200).json({
				status: true,
				message: "Booking request found.",
				data: bookingRequest
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "No data found.",
				data: {}
			});
		}
	});

  static bookingRequestCreate = catchAsyncErrors(async (req, res, next) => {
		let { bookingPlatform, logInType, customerId, vehicleTypeId, firstName, lastName, email, dialCode, phone, plateNumber, fromDate, selectedCheckInTime, toDate, selectedCheckOutTime, passengerCount, vendorId, reservationId, actualvehicleTypeId, actualFromDate, actualCheckInTime, actualToDate, actualCheckOutTime, slotId,  } = req.body;
		
		let roleOfSuperAdmin = await super.getByCustomOptionsSingle(req, roleModel,  {
			where: { 
				roleName: "Super Admin",
			},
		});

		let superUser = await super.getByCustomOptionsSingle(req, userModel, {
			where: {
				roleId: roleOfSuperAdmin?.id,
			},
		});

		if(!bookingPlatform){
			// ==== bookingPlatform => "adminPanel", "customerPanel"
			return res.status(422).json({
				status: false,
				message: "Booking platform is required.",
				data: {},
			});
		}
		if((bookingPlatform != "adminPanel") && (bookingPlatform != "customerPanel")){
			return res.status(422).json({
				status: false,
				message: `Booking platform can either be "adminPanel", "customerPanel"`,
				data: {},
			});
		}
		if(bookingPlatform == "customerPanel"){
			// ==== bookingPlatform =>"adminPanel", "customerPanel"
			if(!logInType){
				return res.status(422).json({
					status: false,
					message: `Please specify login type: "as a guest" or "as a customer".`,
					data: {},
				});
			}
			if((logInType != "Guest") && (logInType != "Customer")){
				return res.status(422).json({
					status: false,
					message: `Login type can either be "Guest" or "Customer".`,
					data: {},
				});
			}
		}
		if(!vehicleTypeId){
			return res.status(422).json({
				status: false,
				message: "Vehicle type is required.",
				data: {},
			});
		}
		if(!email){
			return res.status(422).json({
				status: false,
				message: "Email is required.",
				data: {},
			});
		}
		if(!phone || !dialCode){
			return res.status(422).json({
				status: false,
				message: "Phone and dialcode is required.",
				data: {},
			});
		}
		if(!plateNumber || !fromDate || !selectedCheckInTime || !toDate || !selectedCheckOutTime){
			return res.status(422).json({
				status: false,
				message: "Plate no., From Date, Check-in time, To Date, Check-out time is required.",
				data: {},
			});
		}

		let cusotmerRole = await roleModel.findOne({
			where: {
				roleName: "Customer",
			}
		});

		let createCustomer = {};
		if(!customerId || customerId == '' || customerId == null || customerId == undefined){
			// ========= login as guest =========
			// --------- guest customer profile should be created ---------
			let guestRole = await roleModel.findOne({
				where: {
					roleName: "Guest",
				}
			});
			// ----- default password for guests -----
			let password = "password";
			let encryptedPass = await bcrypt.hash(password, 10);
			// ----- default password for guests -----

			let customerData = {
				roleId: guestRole.id,
				firstName: "Guest",
				lastName: "User",
				email: email,
				dialCode: dialCode,
				phone: phone,
				password: encryptedPass,
			};
			createCustomer = await super.create(res, userModel, customerData);
			
			if(createCustomer){
				// ===== created customerId =====
				customerId = createCustomer.id;
				// ===== created customerId =====
			} else {
				return res.status(400).json({
					status: false,
					message: "Oops.. we ran into some problem and can't proceed with the booking..!!",
					data: {},
				});
			}
		} else {
			if(!firstName || !lastName){
				return res.status(422).json({
					status: false,
					message: "First Name and Last Name is required.",
					data: {},
				});
			}

		}

		// ============== booking STARTS ==============
		// ----- auto-generate booking ticket -----
		let bookingTicketNo = BookingController.generateBookingTicket("PP", "JFKA");
		// ----- auto-generate booking ticket -----
		let bookingData = {
			customerId: customerId,
			// ----- to be decided by "/decide-slot" API -----
			slotId: slotId,
			// ----- to be decided by "/decide-slot" API -----

			vehicleTypeId: vehicleTypeId,

			customerMobile:phone,
			plateNumber: plateNumber,

			fromDate: fromDate,
			selectedCheckInTime: selectedCheckInTime,

			toDate: toDate,
			selectedCheckOutTime: selectedCheckOutTime,

			bookingStatus: "Booked",

			bookingTicketNo: bookingTicketNo,
		};

		// ----- calculate booking charges -----
		
		// ----- calculate booking charges -----
		
		// ----- handle payment here ----
		// let paidAmount = 0;
		// let dueAmount = 0;
		
		// ----- handle payment here ----

		// ----- if payment successful, proceed with booking -----
		// ----- if payment successful, proceed with booking -----

		let checkSlot = {};
		if(slotId){
			checkSlot = await super.getByCustomOptionsSingle(req, slotsModel, {
				where: { 
					id: slotId,
				},
			});

			if(checkSlot.occupancyStatus != "Vacant"){
				return res.status(422).json({
					status: false,
					message: "Ooppss..!! Someone already booked this slot while you were filling up the form. Please try again.",
					data: {}
				});
			}
		}

		let createBookingRequest = await super.create(res, bookingRequestsModel, bookingData);
		// ============== booking ENDS ==============

		if(createBookingRequest){
			if(bookingPlatform == "adminPanel"){
				// ----- admin panel -----
				let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
					occupancyStatus: "Occupied"
				});
				// ----- create carMovementRecord -----
				let carMovementData = {
					bookingRequestId: createBookingRequest.id,
					actualvehicleTypeId: actualvehicleTypeId,
					
					actualFromDate: actualFromDate,
					actualCheckInTime: actualCheckInTime,
					
					// actualToDate: actualToDate,
					// actualCheckOutTime: actualCheckOutTime,
				};
				if(vendorId){
					// ----- booking through a vendor -----
					carMovementData.vendorId = vendorId?? vendorId;
					carMovementData.reservationId = reservationId?? reservationId;
				}
				let carMovementRecordCreate = await super.create(res, carMovementsModel, carMovementData);

				if(carMovementRecordCreate){
					// ----- car movement record created -----
					console.log(`Car movement record created. carMovementId: ${carMovementRecordCreate.id}`);
					
					// ----- check-in -----
					let dataToBeUpdated = {
						bookingStatus: "Checked In",
					};
					let checkInTheBookedRequest = await super.updateByCustomOptions(
						bookingRequestsModel, 
						{
							id: createBookingRequest.id,
						}, 
						dataToBeUpdated
					);
					if(checkInTheBookedRequest){
						console.log("Booking from admin panel, so checked-in as well.");
					}
					// ----- check-in -----
					let createdBookingRequest = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
						where: { 
							id: createBookingRequest.id, 
						},
					});

					// ================================
					// ----- Handle Notifications -----
					// ================================
					// ----- send successful booking notification -----
					
					// ----- 1. to customer -----
					let notiDataForCustomer = {
						userId: customerId?? customerId,
						bookingRequestId: createdBookingRequest?.id,

						notiTitle: `On Site Booking Successful..!! Spot confirmed..!!`,

						notiBody: `Dear Customer, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]. For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`
					}
					let createNotificationForCustomer = await super.create(res, notificationModel, notiDataForCustomer);
					// ----- 1. to customer -----

					// ----- 2. to super admin -----
					let notiDataForSuperAdmin = {
						userId: superUser.id?? superUser.id,
						bookingRequestId: createdBookingRequest?.id,

						notiTitle: `New On Site Booking Made..!!`,

						notiBody: `Dear Admin, Booking confirmed. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]; assigned to customer (${createCustomer?.firstName} ${createCustomer?.lastName})(Ph.: ${phone?? phone}). For more details, please refer to ticket: ${createdBookingRequest?.bookingTicketNo}.`
					}
					let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
					// ----- 2. to super admin -----

					// ----- send successful booking notification -----
					// ================================
					// ----- Handle Notifications -----
					// ================================
					// createdBookingRequest.reservationId = reservationId;
					return res.status(200).json({
						status: true,
						message: "Booked Successfully.",
						data: createdBookingRequest,
						reservationId: reservationId
					});
				} else {
					return res.status(400).json({
						status: false,
						message: "Ooppss..!! Some error occured while creating car movement record.",
						data: {},
					});
				}

			} else if(bookingPlatform == "customerPanel") {
				// ----- customer panel -----
				let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
					occupancyStatus: "Booked"
				});
				// ----- DO NOT CREATE carMovementRecord, it will be created during CHECK-IN -----

				// ================================
				// ----- Handle Notifications -----
				// ================================
				// ----- send successful booking notification -----

				// ----- 1. to super admin -----
				let notiDataForSuperAdmin = {
					userId: superUser.id?? superUser.id,
					bookingRequestId: createBookingRequest?.id,

					notiTitle: `New Booking Request Arrived..!!`,

					notiBody: `Dear Admin, a new booking has been made; expected arrival on ${createBookingRequest.fromDate} at ${createBookingRequest.selectedCheckInTime}. Parking slot no.: ${checkSlot?.slotName}; Slot location: [Bay-no.: ${checkSlot?.slotBayNumber}, Row-no.: ${checkSlot?.slotRowNumber}]; assigned to customer (${createCustomer?.firstName} ${createCustomer?.lastName})(Ph.: ${phone?? phone}). For more details, please refer to ticket: ${createBookingRequest?.bookingTicketNo}.`
				}
				let createNotificationForSuperAdmin = await super.create(res, notificationModel, notiDataForSuperAdmin);
				// ----- 1. to super admin -----

				// ----- send successful booking notification -----
				// ================================
				// ----- Handle Notifications -----
				// ================================
				// createBookingRequest.reservationId = reservationId;
				return res.status(200).json({
					status: true,
					message: "Booked Successfully.",
					data: createBookingRequest,
					reservationId: reservationId
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Ooppss..!! Some error occured during booking creation.",
				data: {},
			});
		}
	});

	static preBookingChargeSummaryBack = catchAsyncErrors(async (req, res, next) => {
		let { onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = staticCharges.reservationCharge;
		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;
		
		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if(Number(passengerCount) > Number(staticCharges.defaultPassengerCount)){
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);
		
		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;
		
		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		if(!onSiteChargeForVendor){
			onSiteChargeForVendor = 0;
		}

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor);

		let paidAmount = 0;
		paidAmount = Number(reservationAmount);
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let bookingChargesSummary = {
			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};
		
		return res.status(200).json({
			status: true,
			message: "Estimated booking charges summary.",
			data: {
				bookingChargesSummary: bookingChargesSummary
			},
		});
	});

	static preBookingChargeSummary = catchAsyncErrors(async (req, res, next) => {
		let { onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}		

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = staticCharges.reservationCharge;
		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;
		
		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if(Number(passengerCount) > Number(staticCharges.defaultPassengerCount)){
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);
		
		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;
		
		let extraDayCharge = 0;
		let totalExtraDays = 0;
		if(onSiteChargeForVendor){
			parkingChargeTotal = Number(dayCount) * Number(priceChart.overSizeRate);

			let today = moment.tz(timeZone).startOf('day');
			let checkedDate = moment.tz(checkinDate, timeZone).startOf('day');
			totalExtraDays = checkedDate.diff(today, 'days');
			extraDayCharge = Number(totalExtraDays) * Number(priceChart.dailyParkingRate);
			if(Number(totalExtraDays) == 0){
				let extraMinutes = moment.tz(checkinDate+ " " +startTime, timeZone).diff(moment.tz(timeZone), 'minutes');
				if(extraMinutes > 120){
					extraDayCharge = Number(priceChart.dailyParkingRate);
				}
			}
		}else{
			parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);
		}
		
		// if(!onSiteChargeForVendor){
		// 	onSiteChargeForVendor = 0;
		// }

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor) + Number(extraDayCharge);

		let paidAmount = 0;
		paidAmount = Number(reservationAmount);
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let bookingChargesSummary = {
			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
			extraDayCharge: extraDayCharge,
			totalExtraMinutes: moment.tz(checkinDate+ " " +startTime, timeZone).diff(moment.tz(timeZone), 'minutes'),
		};
		
		return res.status(200).json({
			status: true,
			message: "Estimated booking charges summary.",
			data: {
				bookingChargesSummary: bookingChargesSummary
			},
		});
	});

	// ----- creates a invoice with booking request data received while booking -----
	// ----- invoice data needs to be updated after check-in and before final check-out ----- 
	static calculateBookingChargesBeforeBooking = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, vendorId, onSiteChargeForVendor, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = staticCharges.reservationCharge;
		let parkingChargeTotal = 0;
		let overSizeChargeTotal = 0;
		
		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if(Number(passengerCount) > Number(staticCharges.defaultPassengerCount)){
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);
		
		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;
		
		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		if(!onSiteChargeForVendor){
			onSiteChargeForVendor = 0;
		}
		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(onSiteChargeForVendor);

		let paidAmount = 0;
		if(vendorId && vendorId != "" && vendorId != null){
			// ====== if booking through a vendor all charges are paid to vendor ======
			paidAmount = payableAmount;
			// ====== if booking through a vendor all charges are paid to vendor ======
		} else {
			paidAmount = reservationAmount;
		}
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let invoiceData = {
			bookingRequestId: bookingRequestId,

			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			onSiteChargeForVendor: onSiteChargeForVendor,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		let invoiceCreate = await super.create(res, invoiceModel, invoiceData);

		if(invoiceCreate){
			let prebookingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
				where: {
					id: invoiceCreate.id,
				}
			});
			
			let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
				where: {
					id: invoiceCreate.bookingRequestId,
				},
			});
			
			return res.status(200).json({
				status: true,
				message: "Pre-booking invoice created.",
				data: {
					invoiceCreate: invoiceCreate,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating pre-booking invoice.",
				data: {},
			});
		}
	});

	static payBookingCharges = catchAsyncErrors(async (req, res, next) => {
		// payment should be handled here
		// as of now => payment offline ====
	});

	static markCheckIn = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, vendorId, reservationId, actualvehicleTypeId, actualFromDate, actualCheckInTime, slotId, plateNumber, } = req.body;

		if(
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			// || (!vendorId || vendorId == "" || vendorId == null || vendorId == undefined)
			// || (!reservationId || reservationId == "" || reservationId == null || reservationId == undefined)
			|| (!actualvehicleTypeId || actualvehicleTypeId == "" || actualvehicleTypeId == null || actualvehicleTypeId == undefined)
			|| (!actualFromDate || actualFromDate == "" || actualFromDate == null || actualFromDate == undefined)
			|| (!actualCheckInTime || actualCheckInTime == "" || actualCheckInTime == null || actualCheckInTime == undefined)
			|| (!slotId || slotId == "" || slotId == null || slotId == undefined)
			|| (!plateNumber || plateNumber == "" || plateNumber == null || plateNumber == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let checkCarMovementExist = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: { 
				bookingRequestId: bookingRequestId,
			},
		});

		if(checkCarMovementExist){
			// if an attempt to mark a car as check-in is made, then carMovement record should not pre-exist ===
			return res.status(422).json({
				status: false,
				message: "Ooppss..!! Unable to process request. Either this car has already checked in or something wrong happened.",
				data: checkCarMovementExist,
			});
		}

		let carMovementData = {
			bookingRequestId: bookingRequestId,

			actualvehicleTypeId: actualvehicleTypeId,

			actualFromDate: actualFromDate,
			actualCheckInTime: actualCheckInTime,

			// default value
			carStatus: "Checked In", 
		};

		if(vendorId){
			carMovementData.vendorId = vendorId?? vendorId;
			carMovementData.reservationId = reservationId?? reservationId;
		}

		let carMovementCreate = await super.create(
			res, 
			carMovementsModel,
			carMovementData,
		);

		if(carMovementCreate){
			let slotStatusUpdate = await super.updateById(slotsModel, slotId, {
				occupancyStatus: "Occupied"
			});
			let updateBookingRequest = await super.updateById(
				bookingRequestsModel, 
				bookingRequestId, 
				{
					slotId: slotId,
					plateNumber: plateNumber,
					bookingStatus: "Checked In",
				}
			);
			let updatedBookingRequest = await super.getById(req, bookingRequestsModel, bookingRequestId);

			if(updatedBookingRequest){
				return res.status(200).json({
					status: true,
					message: "Successfully checked in.",
					data: {
						updatedBookingRequest: updatedBookingRequest,
						updatedCarMovement: carMovementCreate,
					}
				});
			} else {
				return res.status(200).json({
					status: false,
					message: "Succesfully checked-in, but error fetching updated booking request.",
					data: {
						updatedBookingRequest: {},
						updatedCarMovement: carMovementCreate,
					}
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Something went wrong while checking the car in.",
				data: {}
			});
		}
	});

	static calculateBookingChargesAfterCheckIn = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, vehicleTypeId, checkinDate, startTime, checkoutDate, endTime, passengerCount, } = req.body;

		if(
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!vehicleTypeId || vehicleTypeId == "" || vehicleTypeId == null || vehicleTypeId == undefined)
			|| (!checkinDate || checkinDate == "" || checkinDate == null || checkinDate == undefined) 
			|| (!startTime || startTime == "" || startTime == null || startTime == undefined) 
			|| (!checkoutDate || checkoutDate == "" || checkoutDate == null || checkoutDate == undefined) 
			|| (!endTime || endTime == "" || endTime == null || endTime == undefined) 
			|| (!passengerCount || passengerCount == "" || passengerCount == null || passengerCount == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let bookingRequestData = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: { 
				id: bookingRequestId
			},
		});

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(checkinDate+ " " +startTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}

		let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		let selectedEndDate = moment.tz(bookingRequestData.toDate+ " " +bookingRequestData.selectedCheckOutTime, timeZone);

		// Calculate the difference in total minutes
		const selectedTotalMinutes = selectedEndDate.diff(selectedStartDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let selectedDayCount = Math.floor(selectedTotalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let selectedRemainingMinutes = selectedTotalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (selectedRemainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			selectedDayCount += 1; 
		}

		if(selectedDayCount >= dayCount){
			// if user checkes in later than the booked date ==== day count will be selected days ====
			dayCount = selectedDayCount;
		} 

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: vehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = Number(staticCharges.reservationCharge);
		let parkingChargeTotal = 0;
		let overSizeRate = Number(priceChart.overSizeRate);
		let overSizeChargeTotal = Number(dayCount) * overSizeRate;
		
		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if(Number(passengerCount) > Number(staticCharges.defaultPassengerCount)){
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);
		
		let overstayDays = 0;
		let overstayAmountTotal = 0;
		let payableAmount = 0;
		
		let existingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		let existingOnSiteChargeForVendor = 0;
		existingOnSiteChargeForVendor = Number(existingInvoice?.onSiteChargeForVendor);

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(existingOnSiteChargeForVendor);

		let earlyCheckinDays = 0;
		let earlyCheckinAmountTotal = 0;

		earlyCheckinAmountTotal = Number(payableAmount) - Number(existingInvoice?.payableAmount) || 0;

		let paidAmount = 0;
		paidAmount = Number(reservationAmount) + Number(earlyCheckinAmountTotal);
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let invoiceData = {
			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			earlyCheckinAmountTotal: earlyCheckinAmountTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,
			
			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Due",
		};

		let conditions = { 
			bookingRequestId: bookingRequestId 
		};

		let updateInvoice = await super.updateByCustomOptions(
			invoiceModel,
			conditions,
      invoiceData
		);

		let updatedInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: { 
				bookingRequestId: bookingRequestId 
			},
		});

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: updatedInvoice.bookingRequestId,
			},
		});

		if(updateInvoice){
			return res.status(200).json({
				status: true,
				message: "Invoice updated after check-in.",
				data: {
					updatedInvoice: updatedInvoice,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating after check-in invoice.",
				data: {},
			});
		}
	});

	static markCheckOut = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, actualToDate, actualCheckOutTime, } = req.body;

		if(
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!actualToDate || actualToDate == "" || actualToDate == null || actualToDate == undefined)
			|| (!actualCheckOutTime || actualCheckOutTime == "" || actualCheckOutTime == null || actualCheckOutTime == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let checkCarMovementExist = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: { 
				bookingRequestId: bookingRequestId,
			},
		});

		if(!checkCarMovementExist){
			// if an attempt to mark a car as check-out is made, then carMovement record must pre-exist ===
			return res.status(400).json({
				status: false,
				message: "Ooppss..!! Car movement record not found.",
				data: {},
			});
		}

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: { 
				id: bookingRequestId,
			},
		});

		// check if overstay =====

		// handle check-out =====
		let carMovementData = {
			actualToDate: actualToDate,
			actualCheckOutTime: actualCheckOutTime,

			// default value
			carStatus: "Checked Out", 
		};

		let conditions = {
			bookingRequestId: bookingRequestId,
		};
		let carMovementUpdate = await super.updateByCustomOptions(
			carMovementsModel,
			conditions,
			carMovementData
		);

		if(carMovementUpdate){
			let updatedCarMovement = await super.getByCustomOptionsSingle(req, carMovementsModel, {
				where: {
					bookingRequestId: bookingRequestId,
				},
			});
			let slotStatusUpdate = await super.updateById(slotsModel, bookingRequestDetail.slotId, {
				occupancyStatus: "Vacant"
			});
			let updateBookingRequest = await super.updateById(
				bookingRequestsModel, 
				bookingRequestId, 
				{
					bookingStatus: "Checked Out",
				}
			);
			let updatedBookingRequest = await super.getById(req, bookingRequestsModel, bookingRequestId);

			if(updatedBookingRequest){
				return res.status(200).json({
					status: true,
					message: "Successfully checked Out.",
					data: {
						updatedBookingRequest: updatedBookingRequest,
						updatedCarMovement: updatedCarMovement,
					}
				});
			} else {
				return res.status(200).json({
					status: false,
					message: "Succesfully checked-out, but error fetching updated booking request.",
					data: {
						updatedBookingRequest: {},
						updatedCarMovement: updatedCarMovement,
					}
				});
			}
		} else {
			return res.status(400).json({
				status: false,
				message: "Something went wrong while checking the car out.",
				data: {}
			});
		}
	});

	static calculateBookingChargesAfterCheckOut = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId, checkoutDate, endTime, } = req.body;

		if(
			(!bookingRequestId || bookingRequestId == "" || bookingRequestId == null || bookingRequestId == undefined)
			|| (!checkoutDate || checkoutDate == "" || checkoutDate == null || checkoutDate == undefined) 
			|| (!endTime || endTime == "" || endTime == null || endTime == undefined)
		){
			return res.status(422).json({
				status: false,
				message: "All parameters are not present. Please pass all the required parameters.",
				data: {},
			});
		}

		let bookingRequestData = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: { 
				id: bookingRequestId
			},
		});

		let carMovementData = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		let existingInvoiceData = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			}
		});

		// Define startDate and endDate in the same time zone
		let startDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		let endDate = moment.tz(checkoutDate+ " " +endTime, timeZone);

		// Calculate the difference in total minutes
		const totalMinutes = endDate.diff(startDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let dayCount = Math.floor(totalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let remainingMinutes = totalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (remainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			dayCount += 1; 
		}

		let selectedStartDate = moment.tz(bookingRequestData.fromDate+ " " +bookingRequestData.selectedCheckInTime, timeZone);
		let selectedEndDate = moment.tz(bookingRequestData.toDate+ " " +bookingRequestData.selectedCheckOutTime, timeZone);

		// Calculate the difference in total minutes
		const selectedTotalMinutes = selectedEndDate.diff(selectedStartDate, 'minutes');

		// Calculate the full days, rounding up if minutes exceed 15
		// 1440 minutes in a day ---------------
		let selectedDayCount = Math.floor(selectedTotalMinutes / 1440); 
		// Remaining minutes after full days ---------------
		let selectedRemainingMinutes = selectedTotalMinutes % 1440; 

		// Check if remaining minutes exceed 15 ---------------
		if (selectedRemainingMinutes > 15) {
			// Count an additional day if more than 15 minutes ---------------
			selectedDayCount += 1; 
		}

		if(selectedDayCount >= dayCount){
			// if user checkes out earlier than the booked date ==== day count will be selected days ====
			dayCount = selectedDayCount;
		} 

		let staticCharges = await staticChargesModel.findOne({
			where: {
				parkingGroundId: 1,
				isActive: true,
			},
		});

		let priceChart = await priceChartsModel.findOne({
			where: {
				vehicleTypeId: carMovementData.actualvehicleTypeId,
				isActive: true,
			},
		});

		let reservationAmount = Number(staticCharges?.reservationCharge);
		let parkingChargeTotal = 0;
		let overSizeRate = Number(priceChart.overSizeRate);
		let overSizeChargeTotal = Number(dayCount) * overSizeRate;
		
		let passengerCount = existingInvoiceData.extraPassengers;

		let extraPassengers = 0;
		let extraPassengerChargesTotal = 0;
		// ----- extra charges for more than 4 passengers -----
		if(Number(passengerCount) > Number(staticCharges.defaultPassengerCount)){
			extraPassengers = Number(passengerCount) - Number(staticCharges.defaultPassengerCount);
		}
		// ----- extra charges for more than 4 passengers -----
		extraPassengerChargesTotal = Number(extraPassengers) * Number(staticCharges.extraPassengerChargePerHead);

		let overstayDays = Number(dayCount) - Number(selectedDayCount);
		let overstayAmountTotal = Number(overstayDays) * Number(priceChart.lateFees);
		let payableAmount = 0;
		
		let existingInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
		});

		parkingChargeTotal = Number(dayCount) * Number(priceChart.dailyParkingRate);

		payableAmount = Number(parkingChargeTotal) + Number(overSizeChargeTotal) + Number(extraPassengerChargesTotal) + Number(overstayAmountTotal) + Number(existingInvoice?.onSiteChargeForVendor);

		let paidAmount = 0;
		paidAmount = Number(payableAmount);
		let dueAmount = 0;

		dueAmount = Number(payableAmount) - Number(paidAmount);

		let invoiceData = {
			reservationAmount: reservationAmount,

			parkingChargeTotal: parkingChargeTotal,
			overSizeChargeTotal: overSizeChargeTotal,

			extraPassengers: extraPassengers,
			extraPassengerChargesTotal: extraPassengerChargesTotal,

			overstayDays: overstayDays,
			overstayAmountTotal: overstayAmountTotal,

			payableAmount: payableAmount,

			paidAmount: paidAmount,

			dueAmount: dueAmount,

			paymentStatus: "Fully Paid",
		};

		let conditions = { 
			bookingRequestId: bookingRequestId 
		};

		let updateInvoice = await super.updateByCustomOptions(
			invoiceModel,
			conditions,
      invoiceData
		);

		let updatedInvoice = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: { 
				bookingRequestId: bookingRequestId 
			},
		});

		let bookingRequestDetail = await super.getByCustomOptionsSingle(req, bookingRequestsModel, {
			where: {
				id: updatedInvoice.bookingRequestId,
			},
		});

		if(updateInvoice){
			return res.status(200).json({
				status: true,
				message: "Invoice updated after check-out.",
				data: {
					updatedInvoice: updatedInvoice,
					bookingRequestDetail: bookingRequestDetail,
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "Trouble creating final invoice.",
				data: {},
			});
		}
	});

	static invoiceDetail = catchAsyncErrors(async (req, res, next) => {
		let { bookingRequestId } = req.body;

		let invoiceDetail = await super.getByCustomOptionsSingle(req, invoiceModel, {
			where: {
				bookingRequestId: bookingRequestId,
			},
			include: [
				{
					model: bookingRequestsModel,
					include: [
						{
							model: slotsModel,
						},
						{
							model: userModel,
						},
						{
							model: vehicleTypesModel,
						},
					]
				}
			]
		});

		let carMovementDetail = await super.getByCustomOptionsSingle(req, carMovementsModel, {
			where: {
				bookingRequestId: bookingRequestId,
			}
		}); 

		if(invoiceDetail){
			return res.status(200).json({
				status: true,
				message: "Details found",
				data: {
					invoiceDetail: invoiceDetail,
					carMovementDetail: carMovementDetail
				},
			});
		} else {
			return res.status(400).json({
				status: false,
				message: "No details found. Wrong booking id.",
				data: {},
			});
		}
	});
}

module.exports = BookingController;
