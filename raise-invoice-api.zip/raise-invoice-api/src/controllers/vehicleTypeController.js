const axios = require("axios");
const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const { Op, col, literal } = require("sequelize");

const {
  calculateDistance,
  calculateDistanceInsTentApi,
  calculateTimeInKilometers,
  getRateChartCategory,
} = require("../utils/utilities");
const {
  MSG_RECORD_STATUS_SUCCESS,
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");
const requestHandler = new RequestHandler();

const db = require("../models");
const priceChartModel = db.PriceCharts;
const vehicleTypesModel = db.VehicleTypes;

class vehicleTypeController extends BaseController {
  constructor() {
    super();
  }

  static vehicleTypeAddUpdate = catchAsyncErrors(async (req, res, next) => {
    let { typeName, dailyParkingRate, overSizeRate, lateFees, id } = req.body;

    if (!typeName) {
      return res.status(422).json({
        status: false,
        message: "Vehicle type name is required.",
        data: {},
      });
    }
    if (!dailyParkingRate) {
      return res.status(422).json({
        status: false,
        message: "Daily parking rate is required.",
        data: {},
      });
    }
    if (!overSizeRate) {
      return res.status(422).json({
        status: false,
        message: "Over sized rate is required.",
        data: {},
      });
    }
    if (!lateFees) {
      return res.status(422).json({
        status: false,
        message: "Late fees is required.",
        data: {},
      });
    }

    let updateFields = {
      typeName: typeName,
    };

		let checkExist = await super.getByCustomOptionsSingle(req, vehicleTypesModel, {
			where: {
				typeName: {
					[Op.like]: `%${typeName}%`
				},
			}
		});

		if(checkExist){
			return res.status(400).json({
				status: false,
				message: "Vehicle type with same name already exists..!!",
				data: {}
			});
		}

    let updated =
      id && id != "" && id != null
        ? await super.updateById(vehicleTypesModel, id, updateFields)
        : await super.create(res, vehicleTypesModel, updateFields);

    let updatedData = {};
    if (id && id != "" && id != null) {
      updatedData = await super.getByCustomOptionsSingle(
        req,
        vehicleTypesModel,
        {
          where: { id: id },
        }
      );
    } else {
			// ==== create blank rate-chart for the entered vehicle type ====
			let priceChartData = {
				vehicleTypeId: updated.id,
				dailyParkingRate: dailyParkingRate,
				overSizeRate: overSizeRate,
				lateFees: lateFees,
			};
			let blankPriceChartCreate = await super.create(res, priceChartModel, priceChartData);
			// ==== create blank rate-chart for the entered vehicle type ====
			if(blankPriceChartCreate){
				updatedData = updated;
			} else {
				return res.status(500).json({
					status: false,
					message: "Oops..!! Can not create price chart for this vehicle type.",
					data: {}
				});
			}
    }

    if (updatedData) {
      return res.status(200).json({
        status: true,
        message: "Success.",
        data: updatedData,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops..!! Something wrong happened.",
        data: {},
      });
    }
  });

  static vehicleTypeList = catchAsyncErrors(async (req, res, next) => {
    let options = {
      where: {
        deletedAt: null,
      },
      order: [["createdAt", "ASC"]],
    };

    let getVehicleTypes = await super.getList(req, vehicleTypesModel, options);

    if (getVehicleTypes.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: getVehicleTypes,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
      });
    }
  });
}

module.exports = vehicleTypeController;
