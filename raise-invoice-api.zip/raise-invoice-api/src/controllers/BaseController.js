const RequestHandler = require("../utils/RequestHandler");
const _ = require("lodash");
const requestHandler = new RequestHandler();
const timeZone = require("../config/index.js").Timezone;
const moment = require('moment-timezone');

class BaseController {
  constructor(options) {
    this.limit = 20;
    this.options = options;
  }

  static async sendPasswordResetToken(modelName, email, res) {
    try {
      const user = await modelName.findOne({ email });

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Generate a unique token for password reset
      const resetToken = crypto.randomBytes(20).toString("hex");
      user.resetPasswordToken = resetToken;
      user.resetPasswordExpires = Date.now() + 3600000; // Token expires in 1 hour

      await user.save();

      // Send the reset token to the user (you can use your preferred method here, e.g., email)
      // Example: sendResetTokenViaEmail(user.email, resetToken);

      res.status(200).json({ message: "Password reset token sent" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }

  static async getById(req, modelName, id) {
    let result;
    try {
      result = await modelName.findOne({
        where: {
          id: id, // Primary key column, adjust if different
          // deletedAt: null, // Handling soft deletes
          // isActive: true // Include if you want to check active status
        },
      });

      return result;
    } catch (err) {
      console.error("Error fetching record by ID:", err);
      throw err; // Rethrow the error for further handling
    }
  }

  static async getByToken(req, modelName, condition) {
    const reqParam = req;
    let result;
    try {
      result = await modelName
        .findOne({ _id: reqParam, isDeleted: false }, condition)
        .select("-__v");
    } catch (err) {
      return Promise.reject(err);
    }
    return result;
  }

  static async getByCustomOptions(req, modelName, options) {
    let results;
    try {
      results = await modelName.findAll(options);

    } catch (err) {
      return Promise.reject(err);
    }
    return results;
  }

  static async getByCustomOptionsSingle(req, modelName, options) {
    let result;
    try {
      result = await modelName.findOne({
        ...options,
        // order: [["createdAt", "DESC"]], // Order by createdAt in descending order
        // logging: console.log,
      });
    } catch (err) {
      return Promise.reject(err);
    }
    return result;
  }

  // ======== HARD DELETE ========
  static async deleteById(modelName, id) {
    try {
      const result = await modelName.destroy({
        where: { id: id },
      });
      return result; // This returns the number of affected rows
    } catch (err) {
      return Promise.reject(err);
    }
  }
  static async deleteByCondition(modelName, condition) {
    try {
      const result = await modelName.destroy({
        where: condition,
      });
      return result; // This returns the number of affected rows
    } catch (err) {
      return Promise.reject(err);
    }
  }
  // ======== HARD DELETE ========

  // ======== SOFT DELETE ========
  static async softDeleteByCondition(modelName, condition, deleted_by) {
    // Get the current time in defined time zone =======
    let momentZone = moment().tz(timeZone);
    let currentDate = momentZone.format('YYYY-MM-DD');
    let currentDay = momentZone.format('dddd');
    let currentTime = momentZone.format('HH:mm');

    // Convert the local time to UTC
    let momentUTC = momentZone.utc(); // Converts the local time to UTC
    // Get the full date and time in UTC format
    let utcDateTime = momentUTC.format('YYYY-MM-DDTHH:mm:ssZ'); // Example format: 2024-09-14T09:30:00Z

    // Get the current time in defined time zone =======

    let result;
    try {
      result = await modelName.update(
        {
          "deletedAt": utcDateTime,
          "deleted_by": deleted_by,

          "isActive": false,
        },
        {
          where: condition,
        }
      );
      return result;
    } catch (err) {
      console.error("Error while soft deleting record:", err);
      throw err; // Rethrow the error for further handling
    }
  }
  // ======== SOFT DELETE ========

  static async create(res, modelName, data) {
    let obj = data;
    if (_.isUndefined(obj)) {
      obj = req.body;
    }
    let result;
    try {
      result = await modelName.create(obj);
    } catch (err) {
      return Promise.reject(err);
    }
    return result;
  }

  static async updateById(modelName, id, updateFields) {
    let result;
    try {
      result = await modelName.update(updateFields, {
        where: { id: id },
      });
      return result;
    } catch (err) {
      console.error(err);
      throw err;
    }
  }

  static async updateByCustomOptions(modelName, condition, updateFields) {
    let result;
    try {
      result = await modelName.update(updateFields, {
        where: condition,
      });
      return result;
    } catch (err) {
      console.error("Error updating record:", err);
      throw err; // Rethrow the error for further handling
    }
  }

  static async upsert(modelName, updateFields, condition) {
    try {
      return await modelName
        .findOne({ where: condition })
        .then(function(obj) {
            // update
            if(obj)
                return obj.update(updateFields);
            // insert
            return modelName.create(updateFields);
        })
    } catch (err) {
      console.error("Error updating record:", err);
      throw err; // Rethrow the error for further handling
    }
  }

  static async countRecords(req, modelName, options) {
    let count;
    try {
      // Default options if not provided
      options = options || {};

      // Prepare query options for counting
      let queryOptions = {
        where: {
          ...options.where,
          // deletedAt: null,
          // isActive: true,
        },
      };

      // Use Sequelize's count method
      count = await modelName.count(queryOptions);
    } catch (err) {
      return Promise.reject(err);
    }
    return count;
  }

  static async getList(req, modelName, options) {   

    let results;
    try {
      // Default options if not provided
      options = options || {};

      // Apply pagination and default filtering to options
      let queryOptions = {
        ...options,
        where: {
          ...options.where,
          // deletedAt: null, // Assuming soft delete with `deletedAt`
          // isActive: true,
        },
        // offset, // Skip the first `offset` rows
        // limit, // Return `limit` rows
        // Handle attributes if provided in options
        attributes: options.attributes || {},
        logging: console.log
      };

      if(parseInt(req.query.limit) || parseInt(req.body.limit)){
        const page = parseInt(req.query.page) || parseInt(req.body.page) || 1;
        const limit = parseInt(req.query.limit) || parseInt(req.body.limit) || 10;
        const offset = (page - 1) * limit;

        queryOptions.limit = limit;
        queryOptions.offset = offset;
      }

      if (options.include) {
        // Handle includes if provided in options
        queryOptions.include = options.include || [];
        // queryOptions.raw = true
      }

      // queryOptions.logging = console.log;

      results = await modelName.findAll(queryOptions);
    } catch (err) {
      return Promise.reject(err);
    }
    return results;
  }

  static async statusChange(modelName, id, updateFields) {
    let result;
    try {
      result = await modelName.findByIdAndUpdate(id, updateFields, {
        new: true,
        runValidators: true,
      });
    } catch (err) {
      return Promise.reject(err);
    }
    return result;
  }

  static async verifyOTP(ModelName, phone, code) {
    User.findOne({
      _id: userId,
      "otp.code": enteredOTP,
      "otp.expiration": { $gte: new Date() }, // Verify that OTP is not expired
    })
      .then((user) => {
        if (user) {
          user.otp.code = null;
          user.otp.expiration = null;
          user.save();
        } else {
          console.log("Invalid OTP or expired.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }

  // const no_of_docs_each_page = 2; // 2 docs in single page
  // const current_page_number = 2; // 3rd page
  // db.collection.find({})
  // .skip(no_of_docs_each_page * current_page_number)
  // .limit(no_of_docs_each_page)

  // with aggregate =========
  // const no_of_docs_each_page = 2; // 2 docs in single page
  // const current_page_number = 2; // 3rd page
  // db.collection.aggregate([
  // { $skip : no_of_docs_each_page * current_page_number },
  // { $limit : no_of_docs_each_page }
  // ]);
  // with aggregate =========
}

module.exports = BaseController;
