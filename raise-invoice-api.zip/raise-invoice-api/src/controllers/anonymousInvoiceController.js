const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const anonymousInvoiceModel = db.AnonymousInvoice;
const { Sequelize, Op } = require("sequelize");

class anonymousInvoiceController extends BaseController {
  constructor() {
    super();
  }

static createAnonymousInvoice = catchAsyncErrors(async (req, res, next) => {
    const data = req.body;

    const invoice = await anonymousInvoiceModel.create(data);
    if (invoice) {
        return res.status(200).json({
            status: true,
            message: "Anonymous invoice created successfully.",
            data: invoice,
        });
    } else {
        return res.status(400).json({
            status: false,
            message: "Failed to create anonymous invoice.",
            data: {},
        });
    }
});

static getAllAnonymousInvoice = catchAsyncErrors(async (req, res, next) => {
    let { ip, page = 1, limit = 0 } = req.query;
    let whereClause = {
        deletedAt: null,
        ip: {
            [Op.like]: `%${ip || ''}%`
        }
    };

    let options = {
        where: whereClause,
        order: [["createdAt", "DESC"]],
    };

    if (page && limit) {
        options.limit = parseInt(limit);
        options.offset = (parseInt(page) - 1) * parseInt(limit);
    }

    const invoices = await anonymousInvoiceModel.findAll(options);
    const totalCount = await anonymousInvoiceModel.count({ where: whereClause });

    // Format logo and signatureData fields
    const result = invoices.map(inv => {
        let invoice = inv.toJSON();
        if (typeof invoice.logo === "string") {
            try {
            invoice.logo = JSON.parse(invoice.logo);
            } catch (e) {
            }
        }
        if (typeof invoice.signatureData === "string") {
            try {
            invoice.signatureData = JSON.parse(invoice.signatureData);
            } catch (e) {
            }
        }
        ["from", "billTo", "items"].forEach(field => {
            if (typeof invoice[field] === "string") {
                try {
                    invoice[field] = JSON.parse(invoice[field]);
                } catch (e) {
                }
            }
        });
        return invoice;
    });

    return res.status(200).json({
        status: true,
        message: invoices.length > 0 ? "Data found." : "No data found.",
        data: result,
        totalPages: limit ? Math.ceil(totalCount / limit) : 1,
        currentPage: page
    });
});

static getAnonymousInvoice = catchAsyncErrors(async (req, res, next) => {
    const { uuid } = req.query;
    if (!uuid) {
        return res.status(400).json({
            status: false,
            message: "UUID is required.",
            data: {},
        });
    }
    const invoice = await anonymousInvoiceModel.findOne({
        where: { uuid, deletedAt: null }
    });

    if (!invoice) {
        return res.status(404).json({
            status: false,
            message: "Anonymous invoice not found.",
            data: {},
        });
    }

    let result = invoice.toJSON();
    if (typeof result.logo === "string") {
        try {
        result.logo = JSON.parse(result.logo);
        } catch (e) {
        }
    }
    if (typeof result.signatureData === "string") {
        try {
        result.signatureData = JSON.parse(result.signatureData);
        } catch (e) {
        }
    }
    // Parse JSON fields if stored as strings
    ["from", "billTo", "items"].forEach(field => {
        if (typeof result[field] === "string") {
            try {
                result[field] = JSON.parse(result[field]);
            } catch (e) {
            }
        }
    });

    return res.status(200).json({
        status: true,
        message: "Anonymous invoice found.",
        data: result,
    });
});

static updateAnonymousInvoice = catchAsyncErrors(async (req, res, next) => {
    const { uuid, ...updateFields } = req.body;
    if (!uuid) {
        return res.status(400).json({
            status: false,
            message: "UUID is required.",
            data: {},
        });
    }
    const [updated] = await anonymousInvoiceModel.update(updateFields, {
        where: { uuid, deletedAt: null }
    });
    if (updated) {
        const invoice = await anonymousInvoiceModel.findOne({ where: { uuid } });
        return res.status(200).json({
            status: true,
            message: "Anonymous invoice updated successfully.",
            data: invoice,
        });
    } else {
        return res.status(404).json({
            status: false,
            message: "Anonymous invoice not found or not updated.",
            data: {},
        });
    }
});

static deleteAnonymousInvoice = catchAsyncErrors(async (req, res, next) => {
    const { uuid } = req.body;
    if (!uuid) {
        return res.status(400).json({
            status: false,
            message: "UUID is required.",
            data: {},
        });
    }
    const invoice = await anonymousInvoiceModel.findOne({
        where: { uuid, deletedAt: null }
    });
    if (!invoice) {
        return res.status(404).json({
            status: false,
            message: "Anonymous invoice not found.",
            data: {},
        });
    }
    await anonymousInvoiceModel.destroy({
        where: { uuid }
    });
    return res.status(200).json({
        status: true,
        message: "Anonymous invoice deleted successfully.",
        data: {},
    });
});
}

module.exports = anonymousInvoiceController;
