const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

const db = require("../models");
const blockModel = db.BlockModel;
const pageModel = db.PageModel;
const { Sequelize, Op } = require("sequelize");
const crypto = require("crypto");

class blockController extends BaseController {
  constructor() {
    super();
  }

  // static getBlockList = catchAsyncErrors(async (req, res, next) => {
  //   let { searchText } = req.body;
  //   let whereClause = {
  //     status: true,
  //     deletedAt: null,
  //   };
  //   if (searchText) {
  //     whereClause[Op.or] = [
  //       {
  //         id:
  //         {
  //           [Op.like]: `%${searchText}%`
  //         }
  //       },
  //       {
  //         title:
  //         {
  //           [Op.like]: `%${searchText}%`
  //         }
  //       }
  //     ];
  //   }
  //   let options = {
  //     where: whereClause,
  //     order: [["title", "ASC"]],
  //     include: [
  //       {
  //         model: pageModel,
  //         attributes: ["id", "page_title"],
  //         where: {
  //           deletedAt: null,
  //           // status: true,
  //         }
  //       },
  //     ],
  //   };

  //   let blockLists = await super.getList(req, blockModel, options);
  //   // let planLists = await blockModel.findAll(options);

  //   if (blockLists.length > 0) {
  //     return res.status(200).json({
  //       status: true,
  //       message: "Data found.",
  //       data: blockLists,
  //     });
  //   } else {
  //     return res.status(200).json({
  //       status: false,
  //       message: "No data found.",
  //       data: [],
  //     });
  //   }
  // });

  static getBlockList = catchAsyncErrors(async (req, res, next) => {
    let { searchText, page_id, page = 1, limit = 5 } = req.body;
    let pageDetails = await super.getByCustomOptionsSingle(req, pageModel, {
      where: {
        uuid: page_id
      }
    });

    if (!pageDetails) {
      return res.status(200).json({
        status: false,
        message: "Page not found!",
        data: "",
      });
    }
    let whereClause = {
      status: true,
      page_id: pageDetails.id,
      deletedAt: null,
    };

    if (searchText) {
      whereClause[Op.or] = [
        {
          id: {
            [Op.like]: `%${searchText}%`
          }
        },
        {
          title: {
            [Op.like]: `%${searchText}%`
          }
        }
      ];
    }

    let options = {
      where: whereClause,
      order: [['order_number', 'ASC']],
      include: [
        {
          model: pageModel,
          attributes: ["id", "page_title"],
          where: {
            deletedAt: null,
          },
          required: false
        },
      ],
      limit: limit,
      offset: (page - 1) * limit
    };

    let blockLists = await super.getList(req, blockModel, options);

    // Get the total count of records for pagination
    const totalCount = await blockModel.count({ where: whereClause });

    if (blockLists.length > 0) {
      return res.status(200).json({
        status: true,
        message: "Data found.",
        data: blockLists,
        totalPages: Math.ceil(totalCount / limit),
        currentPage: page
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No data found.",
        data: [],
        totalPages: 0,
        currentPage: page
      });
    }
  });

  static saveBlock = catchAsyncErrors(async (req, res, next) => {
    let { id, page_id, title, subtitle, description, template, section_type, status, faq_ids, testimonial_ids } = req.body;

    let pageDetails = await super.getByCustomOptionsSingle(req, pageModel, {
      where: {
        uuid: page_id
      }
    });

    if (!pageDetails) {
      return res.status(200).json({
        status: false,
        message: "Page not found!",
        data: "",
      });
    }

    let blockDetails = await super.getByCustomOptionsSingle(req, blockModel, {
      where: {
        page_id: pageDetails.id,
      },
      order: [['id', 'DESC']],
      limit: 1
    });

    let updateFields = {
      page_id: pageDetails.id,
      // order_number: blockDetails ? (blockDetails.order_number ? blockDetails.order_number + 1 : 1) : 1,
      title,
      subtitle,
      description,
      template,
      // section_type,
      status,
      faq_ids: faq_ids ? faq_ids.join(',') : '',
      testimonial_ids: testimonial_ids ? testimonial_ids.join(',') : '',
    };

    let updated = null;
    if (id && id != "" && id != null) {
      updated = await super.updateById(blockModel, id, updateFields)
    } else {
      updateFields.uuid = crypto.randomUUID();
      updateFields.section_type = section_type;
      updateFields.order_number = blockDetails ? (blockDetails.order_number ? blockDetails.order_number + 1 : 1) : 1;
      updated = await super.create(res, blockModel, updateFields);
    }
    let msg = "";
    if (updated) {
      msg = (id && id != "" && id != null) ? "Block updated successfully." : "Block added successfully.";
    } else {
      msg = "Block addition failed.";
    }

    if (updated) {
      return res.status(200).json({
        status: true,
        message: msg,
        data: updated,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Oops.. Something wrong happened!",
        data: {},
      });
    }
  });
  static getBlockDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid } = req.body;
    let queryConditions = {
      deletedAt: null,
      status: true,
    };

    if (id) {
      queryConditions.id = id
    }
    if (uuid) {
      queryConditions.uuid = uuid
    }

    let blockDetails = await super.getByCustomOptionsSingle(req, blockModel, {
      where: queryConditions,
      include: [
        {
          model: pageModel,
          attributes: ["id", "page_title", 'uuid'],
          where: {
            deletedAt: null,
            // status: true,
          },
          required: false
        },
      ],
    });

    if (blockDetails) {
      return res.status(200).json({
        status: true,
        message: "Success",
        data: blockDetails
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteBlock = catchAsyncErrors(async (req, res, next) => {
    let { uuid } = req.body;

    let blockDetail = await super.getByCustomOptionsSingle(req, blockModel, {
      where: {
        uuid: uuid
      },
      attributes: ["id"],
    });

    if (!blockDetail) {
      return res.status(403).json({
        status: false,
        message: "Block not found!",
        data: {},
      });
    }
    let deleted = await super.deleteByCondition(
      blockModel,
      {
        id: blockDetail.id,
      }
    );

    if (deleted) {
      return res.status(200).json({
        status: true,
        message: "Block successfully deleted.",
        data: {}
      });
    } else {
      return res.status(500).json({
        status: false,
        message: "Oops.. something went terribly wrong!",
        data: {}
      });
    }
  });

}

module.exports = blockController;
