module.exports = (sequelize, DataTypes) => {
    const waterMarkSchema = sequelize.define("invoicewatermark", {
        waterMarkImg : {
            type: DataTypes.BLOB('long'),
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return waterMarkSchema;
};
