module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for AGENTS ONLY ----
  // ========================================================================
  const agentsSchema = sequelize.define("agents", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users",
        key: "id",
      },
      allowNull: false,
    },

    parkingGroundId: { type: DataTypes.INTEGER, allowNull: false, },

    employeeCode: { type: DataTypes.STRING, allowNull: true, defaultValue: null },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // false for No, true for Yes
      comment: "false-No, true-Yes",
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return agentsSchema;
};
