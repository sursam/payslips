module.exports = (sequelize, DataTypes) => {
  const pagesSchema = sequelize.define("blocks", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    section_type: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 3,
      comment: 'Start from 1-Faq,2-Testimonial,3-Content'
    },
    page_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'pages',
        key: 'id'
      },
      allowNull: true
    },
    title: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    subtitle: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    description: {
      type: DataTypes.TEXT("long"),
      allowNull: true,
    },
    faq_ids: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    testimonial_ids: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    template: {
      type: DataTypes.TEXT("long"),
      allowNull: true,
    },
    order_number: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: 'start from 1'
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '0 => in-active, 1 => active'
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return pagesSchema;
};

