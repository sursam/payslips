module.exports = (sequelize, DataTypes) => {
  const carMovementSchema = sequelize.define("carmovements", {
    bookingRequestId: { type: DataTypes.INTEGER, allowNull: false },
    
    // ============= only if customer has a reservation through a vendor =============
    vendorId: { type: DataTypes.INTEGER, allowNull: true },
    reservationId: { type: DataTypes.STRING, allowNull: true },
    // ============= only if customer has a reservation through a vendor =============
    
    actualvehicleTypeId: { type: DataTypes.INTEGER, allowNull: false },

    // ============= duration =============
    actualFromDate: { type: DataTypes.DATEONLY, allowNull: false },
    actualCheckInTime: { type: DataTypes.TIME, allowNull: false },
    
    actualToDate: { type: DataTypes.DATEONLY, allowNull: true, defaultValue: null },
    actualCheckOutTime: { type: DataTypes.TIME, allowNull: true, defaultValue: null },
    // ============= duration =============

    // isEligibleForRefund: {
    //   type: DataTypes.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: true, // true for Yes, false for No
    //   comment: "false-No, true-Yes",
    // },

    carStatus: { type: DataTypes.ENUM("Checked In", "Checked Out", "Over Stay"), allowNull: false, defaultValue: "Checked In" },

    isOverStay: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for "yes", false for "no"
      comment: "false-no, true-yes",
    },

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for "Active", false for "Inactive"
      comment: "false-Inactive, true-Active",
    },

    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return carMovementSchema;
};
