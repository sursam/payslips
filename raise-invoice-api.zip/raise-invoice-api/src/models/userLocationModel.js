module.exports = (sequelize, DataTypes) => {
  const userLocationSchema = sequelize.define("user_locations", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'id'
      },
      allowNull: false,
    },
    countryId: {
      type: DataTypes.INTEGER, 
      allowNull: false,
      references: {
        model: 'countries',
        key: 'id'
      },
    },
    // stateId: {
    //   type: DataTypes.INTEGER,
    //   allowNull: false,
    //   references: {
    //     model: 'states',
    //     key: 'id'
    //   },
    //   primaryKey: true, 
    // },
    // cityId: {
    //   type: DataTypes.INTEGER,
    //   allowNull: false,
    //   references: {
    //     model: 'cities',
    //     key: 'id'
    //   },
    //   primaryKey: true, 
    // },
    streetAddess: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    zipcode: { 
      type: DataTypes.STRING, 
      allowNull: true, 
    },
    latitude: {
      type: DataTypes.FLOAT(10, 8),
      allowNull: true,
    },
    longitude: {
      type: DataTypes.FLOAT(10, 8),
      allowNull: true,
    },
    status: {
      type: DataTypes.TINYINT(4),
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return userLocationSchema;
};
