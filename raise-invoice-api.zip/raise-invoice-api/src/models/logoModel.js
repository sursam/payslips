module.exports = (sequelize, DataTypes) => {
    const logoSchema = sequelize.define("invoicelogo", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        logoImage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return logoSchema;
};
