module.exports = (sequelize, DataTypes) => {
  const planFeaturesSchema = sequelize.define("plan_features", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    plan_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'plans',
        key: 'id'
      },
      allowNull: false,  
    },
    feature_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'features',
        key: 'id'
      },
      allowNull: false,  
    },
    value: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return planFeaturesSchema;
};

