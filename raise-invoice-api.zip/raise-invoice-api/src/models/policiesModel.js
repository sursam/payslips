module.exports = (sequelize, DataTypes) => {
  const policiesSchema = sequelize.define("policies", {
    policies: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return policiesSchema;
};

