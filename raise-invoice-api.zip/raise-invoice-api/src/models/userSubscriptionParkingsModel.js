module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for USER SUBSCRIPTIONS ONLY ----
  // ========================================================================
  const userSubscriptionParkingsSchema = sequelize.define("usersubscriptionparkings", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    // userSubscriptionId: {
    //   type: DataTypes.INTEGER,
    //   references: {
    //     model: "userSubscriptions",
    //     key: "id",
    //   },
    //   allowNull: false,
    // },
    parkingBusinessId: {
      type: DataTypes.INTEGER,
      references: {
        model: "parkingBusinesses",
        key: "id",
      },
      allowNull: false,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return userSubscriptionParkingsSchema;
};
