const mysqlConfig = require("../config/index.js").Mysql;
const Sequelize = require("sequelize");
const session = require('express-session');
const SequelizeStore = require('connect-session-sequelize')(session.Store);

const sequelizeConnectionInstance = new Sequelize(mysqlConfig.dbName, mysqlConfig.user, mysqlConfig.pwd, {
    host: mysqlConfig.host,
    dialect: mysqlConfig.dialect,
    logging: mysqlConfig.debug,
    // logging: console.log,
});

sequelizeConnectionInstance
    .authenticate()
    .then(() => {
        console.log('Mysql connection has been established successfully.')
    })
    .catch(err => {
        console.error('Unable to connect to the Mysql database:', err)
    })

// storing the session
const sequelizeSessionStore = new SequelizeStore({
    db: sequelizeConnectionInstance,
})


const db = {};
db.sequelizeConnectionInstance = sequelizeConnectionInstance;
db.Sequelize = Sequelize;

db.sequelizeSessionStore = sequelizeSessionStore;

// =======================================================================
// ======== include the Models and group the table-relations here ========
// =======================================================================

// ---- users ----
db.Users = require("./userModel")(sequelizeConnectionInstance, Sequelize);
// ---- users ----
db.UserTokens = require("./userTokenModel")(sequelizeConnectionInstance, Sequelize);
db.Users.hasMany(db.UserTokens, { foreignKey: 'userId' });

// ---- roles ----
db.Roles = require("./roleModel")(sequelizeConnectionInstance, Sequelize);
// ---- roles ----

// ---- usersRoles ----
db.UsersRoles = require("./usersRoleModel")(sequelizeConnectionInstance, Sequelize);
// ---- usersRoles ----

db.Users.belongsToMany(db.Roles, {
    through: db.UsersRoles, // Name of the junction table
    foreignKey: 'userId',
    otherKey: 'roleId',
    as: 'userRole'
});

// db.Users.belongsTo(db.Roles, { foreignKey: 'roleId' });
// db.Roles.hasMany(db.Users, { foreignKey: 'roleId' });

//Clients
// ---- users ----
db.Clients = require("./clientAdminModel.js")(sequelizeConnectionInstance, Sequelize);

db.InvoiceTemplate = require("./invoiceTemplateModel.js")(sequelizeConnectionInstance, Sequelize);

db.InvoiceLogo = require("./logoModel.js")(sequelizeConnectionInstance, Sequelize);

db.clientApp = require("./client/clientAppointmentModel.js")(sequelizeConnectionInstance, Sequelize);

db.InvoiceColour = require("./invoiceColourModel.js")(sequelizeConnectionInstance, Sequelize);

db.InvoiceHeader = require("./invoiceHeaderModel.js")(sequelizeConnectionInstance, Sequelize);

db.InvoiceWaterMark = require("./invoiceWaterMarkModel.js")(sequelizeConnectionInstance, Sequelize);

db.Contact = require("./client/projectContactModel.js")(sequelizeConnectionInstance, Sequelize);

db.Items = require("./client/itemsModel.js")(sequelizeConnectionInstance, Sequelize);

db.Transactions = require("./transactionsModel.js")(sequelizeConnectionInstance, Sequelize);

db.Currency = require("./currencyModel.js")(sequelizeConnectionInstance, Sequelize);
db.ExchangeRate = require("./exchangeRateModel.js")(sequelizeConnectionInstance, Sequelize);
db.Currency.hasMany(db.ExchangeRate, { foreignKey: 'currency_to' });

db.Units = require("./unitsModel.js")(sequelizeConnectionInstance, Sequelize);

db.Times = require("./timesUnitModel.js")(sequelizeConnectionInstance, Sequelize);

// ---- permissions ----
db.Permissions = require("./permissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- permissions ----

// ---- rolesPermissions ----
db.RolesPermissions = require("./rolesPermissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- rolesPermissions ----

db.Roles.belongsToMany(db.Permissions, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'roleId',
    otherKey: 'permissionId',
});
db.Permissions.belongsToMany(db.Roles, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'permissionId',
    otherKey: 'roleId',
});

// ---- usersPermissions ----
db.UsersPermissions = require("./usersPermissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- usersPermissions ----

db.AnonymousInvoice = require("./anonymousInvoiceModel.js")(sequelizeConnectionInstance, Sequelize);

db.Users.belongsToMany(db.Permissions, {
    through: db.UsersPermissions, // Name of the junction table
    foreignKey: 'userId',
    otherKey: 'permissionId',
});
db.Permissions.belongsToMany(db.Users, {
    through: db.UsersPermissions, // Name of the junction table
    foreignKey: 'permissionId',
    otherKey: 'userId',
});

// ---- pages ----
db.Pages = require("./pageModel_old.js")(sequelizeConnectionInstance, Sequelize);
// ---- custom fields ----
db.CustomFields = require("./customFieldModel")(sequelizeConnectionInstance, Sequelize);
db.Pages.hasMany(db.CustomFields, { foreignKey: 'page_id' });
// ---- categories ----
db.Categories = require("./categoryModel")(sequelizeConnectionInstance, Sequelize);
db.Categories.belongsTo(db.Categories, { foreignKey: 'parent_id', }); //  as: 'parentCategory'
db.Categories.hasOne(db.Categories, { foreignKey: 'parent_id', });
// ---- features ----
db.Features = require("./featureModel")(sequelizeConnectionInstance, Sequelize);
// db.Features.hasOne(db.Categories, { foreignKey: 'category_id', });
db.Categories.hasMany(db.Features, {
    foreignKey: 'category_id',
});
// ---- plans ----
db.Plans = require("./planModel")(sequelizeConnectionInstance, Sequelize);

// ---- countries ----
db.Countries = require("./countryModel")(sequelizeConnectionInstance, Sequelize);
// ---- plan prices ----
db.PlanPrices = require("./planPriceModel")(sequelizeConnectionInstance, Sequelize);
db.PlanPrices.belongsTo(db.Plans, { foreignKey: 'plan_id', onDelete: 'CASCADE' });
db.PlanPrices.belongsTo(db.Currency, { foreignKey: 'currency_id' });
db.Plans.hasMany(db.PlanPrices, {
    foreignKey: 'plan_id',
    onDelete: 'CASCADE'
});
db.Plans.belongsTo(db.Currency, { foreignKey: 'default_currency' });
// ---- plan features ----
db.PlanFeatures = require("./planFeatureModel")(sequelizeConnectionInstance, Sequelize);
db.PlanFeatures.belongsTo(db.Plans, { foreignKey: 'plan_id', onDelete: 'CASCADE' });
db.PlanFeatures.belongsTo(db.Features, { foreignKey: 'feature_id', onDelete: 'CASCADE' });
// db.PlanFeatures.belongsTo(db.Plans, { foreignKey: 'plan_id', onDelete: 'CASCADE' }); 
db.Plans.belongsToMany(db.Features, {
    through: db.PlanFeatures,
    foreignKey: 'plan_id',
    otherKey: 'feature_id',
});
db.Features.belongsToMany(db.Plans, {
    through: db.PlanFeatures,
    foreignKey: 'feature_id',
    otherKey: 'plan_id',
});
db.PlanFeatures.belongsTo(db.Features, { foreignKey: 'feature_id', onDelete: 'CASCADE' });
db.Plans.hasMany(db.PlanFeatures, {
    foreignKey: 'plan_id',
    onDelete: 'CASCADE'
});
db.Features.hasMany(db.PlanFeatures, {
    foreignKey: 'feature_id',
});

// ---- FAQs ----
db.Faqs = require("./faqModel")(sequelizeConnectionInstance, Sequelize);
db.Faqs.belongsTo(db.Categories, { foreignKey: 'category_id', });
db.Categories.hasMany(db.Faqs, { foreignKey: 'category_id', });

// ---- Jobs ----
db.Jobs = require("./jobModel")(sequelizeConnectionInstance, Sequelize);
db.JobCategories = require("./jobCategoryModel")(sequelizeConnectionInstance, Sequelize);
db.Jobs.belongsToMany(db.Categories, {
    through: db.JobCategories,
    foreignKey: 'job_id',
    otherKey: 'category_id',
});
db.Categories.belongsToMany(db.Jobs, {
    through: db.JobCategories,
    foreignKey: 'category_id',
    otherKey: 'job_id',
});

// ---- User Enquiries ----
db.UserEnquiries = require("./userEnquiryModel")(sequelizeConnectionInstance, Sequelize);
db.UserEnquiries.belongsTo(db.Users, { foreignKey: 'userId', });
db.UserEnquiries.belongsTo(db.Countries, { foreignKey: 'countryId', });
db.Testimonials = require("./testimonialModel.js")(sequelizeConnectionInstance, Sequelize);


// ---- Newsletter Subscriptions ----
db.NewsletterSubscriptions = require("./newsletterSubscriptionModel")(sequelizeConnectionInstance, Sequelize);
db.NewsletterSubscriptions.belongsTo(db.Users, { foreignKey: 'userId', });


db.LanguageModel = require("./languageModel.js")(sequelizeConnectionInstance, Sequelize);
db.OurTeamModel = require("./ourTeamModel.js")(sequelizeConnectionInstance, Sequelize);

db.PageModel = require("./pageModel.js")(sequelizeConnectionInstance, Sequelize);
db.BlockModel = require("./blockModel.js")(sequelizeConnectionInstance, Sequelize);
db.BlockModel.belongsTo(db.PageModel, { foreignKey: 'page_id', });
db.PageModel.hasMany(db.BlockModel, {
    foreignKey: 'page_id',
});

db.MenuModel = require("./menuModel.js")(sequelizeConnectionInstance, Sequelize);
db.MenuModel.belongsTo(db.PageModel, { foreignKey: 'page_id', });

db.MenuModel.belongsTo(db.MenuModel, { foreignKey: 'parent_id', });

db.NewsLetterModel = require("./newsLetterModel.js")(sequelizeConnectionInstance, Sequelize);
db.FeedbackHomeModel = require("./feedbackHomeModel.js")(sequelizeConnectionInstance, Sequelize);
// ---- permissions ----
db.Permissions = require("./permissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- permissions ----

// ---- rolesPermissions ----
db.RolesPermissions = require("./rolesPermissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- rolesPermissions ----

db.Roles.belongsToMany(db.Permissions, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'roleId',
    otherKey: 'permissionId',
});
db.Permissions.belongsToMany(db.Roles, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'permissionId',
    otherKey: 'roleId',
});

// ---- modules ----
db.Modules = require("./modulesModel")(sequelizeConnectionInstance, Sequelize);

db.Modules.belongsTo(db.Modules, { foreignKey: 'parentModuleId', }); //  as: 'parentModule'
db.Modules.hasOne(db.Modules, { foreignKey: 'parentModuleId', });
db.Modules.hasMany(db.Permissions, {
    foreignKey: 'moduleId',
});
// ---- modules ----

// ---- modulePermissions ----
db.ModulePermissions = require("./modulePermissionsModel")(sequelizeConnectionInstance, Sequelize);
// ---- modulePermissions ----

db.Users.belongsToMany(db.Modules, {
    through: db.ModulePermissions, // Name of the junction table
    foreignKey: 'userId',
    otherKey: 'moduleId',
});
db.Modules.belongsToMany(db.Users, {
    through: db.ModulePermissions, // Name of the junction table
    foreignKey: 'moduleId',
    otherKey: 'userId',
});
db.UserLocations = require("./userLocationModel")(sequelizeConnectionInstance, Sequelize);
db.Users.hasOne(db.UserLocations, {
    foreignKey: 'userId',
    as: 'userLocation'
});
db.UserCompanies = require("./userCompanyModel")(sequelizeConnectionInstance, Sequelize);
db.Users.hasOne(db.UserCompanies, {
    foreignKey: 'userId',
    as: 'userCompany'
});
db.Clients.hasOne(db.UserCompanies, {
    foreignKey: 'userId',
    as: 'userCompany'
});
db.ClientSubscriptions = require("./clientSubscriptionsModel")(sequelizeConnectionInstance, Sequelize);

db.Clients.hasMany(db.ClientSubscriptions, { foreignKey: 'clientId' });
db.ClientSubscriptions.belongsTo(db.Plans, { foreignKey: 'planId', });

db.PaymentGateways = require("./paymentGatewayModel")(sequelizeConnectionInstance, Sequelize);
db.PaymentGatewayFields = require("./paymentGatewayFieldModel")(sequelizeConnectionInstance, Sequelize);
db.PaymentGateways.hasMany(db.PaymentGatewayFields, {
    foreignKey: 'paymentGatewayId',
    onDelete: 'CASCADE'
});

module.exports = db;