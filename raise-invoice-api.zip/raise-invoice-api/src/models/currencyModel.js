module.exports = (sequelize, DataTypes) => {
    const currencySchema = sequelize.define("currencies", {
        currency_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        currency_code: {
            type: DataTypes.STRING,
            allowNull: false,
            // unique: true,
        },
        symbol: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        isDefault: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 0,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });
    return currencySchema;
};