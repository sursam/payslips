module.exports = (sequelize, DataTypes) => {
  const projectTask = sequelize.define("project_task", {
     uuid: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    client_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    taskName: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    taskDescription: {
        type: DataTypes.TEXT("long"),
        allowNull: true,
    },
    taskStartDate: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    taskEndDate: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    taskPriority: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
    deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
    }
  });

  return projectTask;
};


