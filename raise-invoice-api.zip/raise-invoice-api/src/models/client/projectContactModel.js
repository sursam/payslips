module.exports = (sequelize, DataTypes) => {
    const projectContactsSchema = sequelize.define("project_contact", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        project_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        client_admin_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        contact_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        contact_email: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        contact_phone: {
            type: DataTypes.STRING,
        },
        address: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return projectContactsSchema;
};
