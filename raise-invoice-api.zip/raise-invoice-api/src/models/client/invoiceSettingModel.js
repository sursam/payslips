module.exports = (sequelize, DataTypes) => {
    const invoiceSetting = sequelize.define("invoice_setting", {
        client_admin_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        uuid: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        logoPosition: {
             type: DataTypes.STRING,
            allowNull: true,
        },
        logoSize: {
             type: DataTypes.STRING,
            allowNull: true,
        },
        logo: {
             type: DataTypes.INTEGER,
            allowNull: true,
        },
        colour: {
             type: DataTypes.INTEGER,
            allowNull: true,
        },
        header: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        waterMark: {
            type: DataTypes.INTEGER,
            allowNull: true,        
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    return invoiceSetting;
};