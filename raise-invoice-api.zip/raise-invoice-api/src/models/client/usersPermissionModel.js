module.exports = (sequelize, DataTypes) => {
  const usersPermissionsSchema = sequelize.define("userspermissions", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'clientadmins',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    permissionId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'permissions',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    }
  });

  return usersPermissionsSchema;

  /* 
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  1. To get all modules for a user:
  -----------------------------------
  const userWithModules = await db.Users.findByPk(userId, {
    include: db.Modules
  });

  2. To get all users for a module:
  -----------------------------------
  const moduleWithUsers = await db.Modules.findByPk(moduleId, {
    include: db.Users
  });
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  */
};
