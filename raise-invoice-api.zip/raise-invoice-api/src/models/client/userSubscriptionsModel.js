module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for USER SUBSCRIPTIONS ONLY ----
  // ========================================================================
  const userSubscriptionsSchema = sequelize.define("usersubscriptions", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      // references: {
      //   model: "users",
      //   key: "id",
      // },
      allowNull: false,
    },
    subscriptionId: {
      type: DataTypes.INTEGER,
      // references: {
      //   model: "plans",
      //   key: "id",
      // },
      allowNull: false,
    },
    startDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    endDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    price: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    isPaid: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: "false-Not-Paid, true-Paid",
    },
    planType: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: "yearly,monthly",
    },
    isExpired: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for Expired, false for Not Expired
      comment: "false-Not-Expired, true-Expired",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return userSubscriptionsSchema;
};
