module.exports = (sequelize, DataTypes) => {
  const modulesSchema = sequelize.define("modules", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    parentModuleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'modules',
        key: 'id'
      },
      allowNull: true,  // Allow null if a module has no parent
    },
    moduleName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    moduleSlug: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    moduleIcon: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '0 => in-active, 1 => active'
    },
    order: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },

    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  // Modules.associate = function(models) {
  //   // Define the relationship here if needed
  //   Modules.belongsTo(Modules, { foreignKey: 'parentModuleId', as: 'parentModule' });
  // };

  return modulesSchema;
};
