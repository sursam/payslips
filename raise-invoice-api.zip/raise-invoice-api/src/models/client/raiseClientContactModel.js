module.exports = (sequelize, DataTypes) => {
  const ClientContact = sequelize.define("clientcontactdetails", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    clientId: {
      type: DataTypes.INTEGER,
      references: {
        model: "clients",
        key: "id",
      },
      allowNull: true,
      defaultValue: null,
    },
    contact_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dialCode: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    phone: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    website: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  ClientContact.associate = (models) => {
    ClientContact.belongsTo(models.Client, {
      foreignKey: 'clientId',
      as: 'client'
    });
  };
  return ClientContact;
};

