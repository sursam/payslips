module.exports = (sequelize, DataTypes) => {
    const userTaxSecuritySchema = sequelize.define("user_tax_security", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        userId: {
            type: DataTypes.INTEGER,
            references: {
                model: 'clientadmins',
                key: 'id'
            },
            allowNull: true,
        },
        countryId: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        currency: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        gst_no: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        co_reg_no: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        pan_no: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tax_year_month: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tax_year_day: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        gst_rate: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        enable_withholding_tax: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });
    return userTaxSecuritySchema;
};
