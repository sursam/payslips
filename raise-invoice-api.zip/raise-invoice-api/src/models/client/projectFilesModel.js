module.exports = (sequelize, DataTypes) => {
    const projectFilesSchema = sequelize.define("project_files", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        project_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        client_admin_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        fileContent: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        fileType : {
            type: DataTypes.STRING,
            allowNull: true,
            comment: 'Type of the file, e.g., image, document, etc.'
        },
        uploadedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    })

    return projectFilesSchema;
};

