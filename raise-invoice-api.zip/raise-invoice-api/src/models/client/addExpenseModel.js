module.exports = (sequelize, DataTypes) => {
    const expenseSchema = sequelize.define("expense", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        projectId: {
            type: DataTypes.INTEGER,
            references: {
              model: "client_projects",
              key: "id",
            },
            allowNull: true,
            defaultValue: null,
          },
        date : {
            type: DataTypes.DATE,
            allowNull: false,
        },
        merchant : {
            type: DataTypes.STRING,
            allowNull: false,
        },
        catagory : {
            type: DataTypes.STRING,
            allowNull: false,
        },
        rate : {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        tax : {
            type: DataTypes.INTEGER,
            allowNull: true,
        },  
        tip : {
            type: DataTypes.INTEGER,
            allowNull: true,
        }, 
        description : {
            type: DataTypes.STRING,
            allowNull: false,
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '0 => in-active, 1 => active'
        },
        profileImage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        }
    });

    expenseSchema.associate = (models) => {
        expenseSchema.belongsTo(models.CompanyProject, {
          foreignKey: 'projectId',
          as: 'client_projects'
        });
      };
      return expenseSchema;
};
