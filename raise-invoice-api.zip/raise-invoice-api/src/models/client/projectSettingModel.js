// Project Setting Model
module.exports = (sequelize, DataTypes) => {
const projectSettingSchema = sequelize.define("projectsetting", {
    addNewClient: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    newEstimate: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    newInvoice: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    prefix: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
    deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
    },
});
  return projectSettingSchema;
};

