module.exports = (sequelize, DataTypes) => {
    const clientInvoiceSchema = sequelize.define("invoices", {
        client_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        items: {
            type: DataTypes.JSON,
            allowNull: false,
        },        
        date: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        term: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        dueDate: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        subTotal: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        discount: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        total: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paid: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        balance: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        paymentStatus: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        logo: {
            type: DataTypes.TEXT('long'),
            allowNull: true,
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    return clientInvoiceSchema;
};
