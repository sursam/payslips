module.exports = (sequelize, DataTypes) => {
    const transactionSchema = sequelize.define("transactions", {
      client_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
  
      paymentGatewayOrderId: { type: DataTypes.STRING, allowNull: false, },
      paidVia: { type: DataTypes.STRING, defaultValue: null },
  
      paymentType: {
        type: DataTypes.ENUM("Wallet Recharge", "Registration Fees"),
        allowNull: false,
        defaultValue: "Registration Fees",
      },
      signature: { type: DataTypes.STRING, defaultValue: null },
  
      paidAmount: { type: DataTypes.DOUBLE, defaultValue: 0 },
      paidCurrency: { type: DataTypes.STRING, defaultValue: null },
  
      paymentDate: { type: DataTypes.DATE, allowNull: false },
  
      paymentStatus: {
        type: DataTypes.ENUM("Pending", "Paid", "Failed"),
        allowNull: false,
        defaultValue: "Pending",
      },
  
      remarks: { type: DataTypes.STRING, defaultValue: null },
  
      isActive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true, // true for Active, false for Inactive
        comment: "false-Inactive, true-Active",
      },
  
      createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
      },
      updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
      },
  
      deletedAt: {
        field: "deleted_at",
        type: DataTypes.DATE,
      },
    });
    return transactionSchema;
  };
  