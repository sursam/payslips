module.exports = (sequelize, DataTypes) => {
    const ClientAppointment = sequelize.define("client_appointments", {
        uuid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        client_id: {
            type: DataTypes.INTEGER,
            // references: {
            //     model: 'clients',
            //     key: 'id'
            // },
            allowNull: false
        },
        client_admin_id: {
            type: DataTypes.INTEGER,
            // references: {
            //     model: 'clientAdmins',
            //     key: 'id'
            // },
            allowNull: false
        },
        location: {
            type: DataTypes.TEXT("long"),
            allowNull: true,
        },
        latitude: {
            type: DataTypes.FLOAT,
            allowNull: true,
        },
        longitude: {
            type: DataTypes.FLOAT,
            allowNull: true,
        },
        start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        document: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        notes: {
            type: DataTypes.STRING,
            allowNull: false
        },
        status: {
            type: DataTypes.TINYINT,
            allowNull: false,
            defaultValue: 1,
            comment: '1: Active, 2: Rescheduled, 3: Canceled'
        },
        createdAt: {
            field: "created_at",
            type: DataTypes.DATE,
        },
        updatedAt: {
            field: "updated_at",
            type: DataTypes.DATE,
        },
        deletedAt: {
            field: "deleted_at",
            type: DataTypes.DATE,
        },
    });

    return ClientAppointment;
};