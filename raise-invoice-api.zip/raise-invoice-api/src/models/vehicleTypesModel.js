module.exports = (sequelize, DataTypes) => {
  const vehicleTypesSchema = sequelize.define("vehicletypes", {
    typeName: { type: DataTypes.STRING, allowNull: false,},

    createdAt: { field: "created_at", type: DataTypes.DATE,},
    updatedAt: { field: "updated_at", type: DataTypes.DATE,},

    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    deletedAt: { field: "deleted_at", type: DataTypes.DATE,},
  });

  return vehicleTypesSchema;
};
