module.exports = (sequelize, DataTypes) => {
  const pagesSchema = sequelize.define("menus", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    parent_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'menus',
        key: 'id'
      },
      allowNull: true,
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE'
    },
    page_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'pages',
        key: 'id'
      },
      allowNull: true,
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE'
    },
    menu_type: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '1 => header, 2 => footer'
    },
    menu_group: {
      type: DataTypes.TINYINT,
      allowNull: true,
      comment: '1 => Product, 2 => Explore, 3 => Community, 4 => Company'
    },
    slug: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    menu_title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    link_type: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '1 => Internal, 2 => External'
    },
    menu_link: {
      type: DataTypes.STRING,
      allowNull: false
    },
    order_number: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: 'start from 1'
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '0 => in-active, 1 => active'
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return pagesSchema;
};

