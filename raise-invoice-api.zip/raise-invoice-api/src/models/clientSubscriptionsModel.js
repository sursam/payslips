module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for USER SUBSCRIPTIONS ONLY ----
  // ========================================================================
  const clientSubscriptionsSchema = sequelize.define("client_subscriptions", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    planId: {
      type: DataTypes.INTEGER,
      references: {
        model: "plans",
        key: "id",
      },
      allowNull: false,
    },
    clientId: {
      type: DataTypes.INTEGER,
      references: {
        model: "clientadmins",
        key: "id",
      },
      allowNull: false,
    },
    isTrial: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for Trial Period, false for Not Trial Period
      comment: "false-Not-Trial-Period, true-Trial-Period",
    }, 
    duration: {
      type: DataTypes.STRING,
      allowNull: false,
    }, 
    trialDuration: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    trialStartDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    trialEndDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    startDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    endDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    nextBillingDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    price: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    paymentMode: {
      type: DataTypes.ENUM("online", "offline"),
      allowNull: true,
    },
    transactionId: {
      type: DataTypes.STRING,
      allowNull: true,
    },    
    isPaid: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for Paid, false for Not Paid
      comment: "false-Not-Paid, true-Paid",
    },
    isExpired: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false, // true for Expired, false for Not Expired
      comment: "false-Not-Expired, true-Expired",
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true, // true for Active, false for Inactive
      comment: "false-Inactive, true-Active",
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return clientSubscriptionsSchema;
};
