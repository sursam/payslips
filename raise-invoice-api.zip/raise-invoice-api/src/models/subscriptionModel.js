module.exports = (sequelize, DataTypes) => {
  // ========================================================================
  // ---- this schema is intended to be used for SUBSCRIPTIONS ONLY ----
  // ========================================================================
  const subscriptionSchema = sequelize.define("subscriptions", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    price: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });
  return subscriptionSchema;
};
