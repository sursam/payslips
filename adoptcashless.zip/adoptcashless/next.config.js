module.exports = {
  exportPathMap: async function (
    defaultPathMap,
    { dev, dir, outDir, distDir, buildId }
  ) {
    let newPathMap = { ...defaultPathMap };
    return newPathMap;
  },
  env: {    
    serverUrl: 'http://api.localhost:3000/',
    //serverUrl: 'https://tapngosolutions.com.au/',
    hashedkey: '$2a$10$CwTycUXWue0Thq9StjUM0u',
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  trailingSlash: false,
  //distDir: 'out',
  webpack: (config) => {
    config.output.globalObject = `(typeof self !== 'undefined' ? self : this)`;
    return config;
  },
  reactStrictMode: true,
  async rewrites() {
    return [
      {
        source: '/',
        has: [{ type: 'host', value: 'localhost' }],
        destination: '/front/',
      },
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'localhost' }],
        destination: '/front/:path*',
      },
      {
        source: '/',
        has: [{ type: 'host', value: 'admin.localhost' }],
        destination: '/admin/',
      },
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'admin.localhost' }],
        destination: '/admin/:path*',
      },
      {
        source: '/',
        has: [{ type: 'host', value: 'member.localhost' }],
        destination: '/member/',
      },
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'member.localhost' }],
        destination: '/member/:path*',
      },
      {
        source: '/',
        has: [{ type: 'host', value: 'prepaid.localhost' }],
        destination: '/prepaid/',
      },
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'prepaid.localhost' }],
        destination: '/prepaid/:path*',
      },
    ]
  },
}
