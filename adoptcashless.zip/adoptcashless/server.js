const express = require('express')
const next = require('next')
const vhost = require('vhost')
const path = require('path');

let env = require('./app/config/env.js');
const port = env.port || 3000
const dev = env.NODE_ENV !== 'production'
const app = next({ dev })
const handle = app.getRequestHandler()

app.prepare().then(() => {
  const mainServer = express()
  const apiServer = express()
  const siteServer = express()
  const adminServer = express()
  const memberServer = express()
  const prepaidServer = express()  

  var bodyParser = require('body-parser'); 
  global.__basedir = __dirname; 

  const db = require('./app/config/db.config.js');
  let router = require('./app/routers/router.js');

  /*const sitePort = (env.NODE_ENV != 'development') ? '' : ':'+port;
  const cors = require('cors');
  const corsOptions = {
    origin: env.protocol+'://'+env.siteDomain+sitePort,
    optionsSuccessStatus: 200,
    methods: ['GET','POST','DELETE','UPDATE','PUT','PATCH']
  }

  //mainServer.use(bodyParser.json());
  //mainServer.use(cors(corsOptions));
  siteServer.use(cors(corsOptions));
  adminServer.use(cors(corsOptions));
  memberServer.use(cors(corsOptions));*/
  
  mainServer.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    //console.log('MAIN ---- '+req.method)
    if ('OPTIONS' == req.method) {
      res.sendStatus(200);
    } else {
      next();
    }
  });
  
  siteServer.use(bodyParser.json());
  adminServer.use(bodyParser.json());  
  memberServer.use(bodyParser.json()); 
  prepaidServer.use(bodyParser.json());

  mainServer.use(express.static(path.join(__dirname, 'public')));
  //mainServer.use('/api', router);
  apiServer.use('/', router);
  
  adminServer.get('/', (req, res) => {
    return app.render(req, res, '/admin', req.query)
  })
  adminServer.get('/*', (req, res) => {
    return app.render(req, res, `/admin${req.path}`, req.query)
  })
  adminServer.all('*', (req, res) => {
    return handle(req, res)
  }) 

  memberServer.get('/', (req, res) => {
    return app.render(req, res, '/member', req.query)
  })

  memberServer.get('/*', (req, res) => {
    return app.render(req, res, `/member${req.path}`, req.query)
  })

  memberServer.all('*', (req, res) => {
    return handle(req, res)
  })

  prepaidServer.get('/', (req, res) => {
    return app.render(req, res, '/prepaid', req.query)
  })

  prepaidServer.get('/*', (req, res) => {
    return app.render(req, res, `/prepaid${req.path}`, req.query)
  })

  prepaidServer.all('*', (req, res) => {
    return handle(req, res)
  })
  
  siteServer.get('/', (req, res) => {
    return app.render(req, res, '/front', req.query)
  })
  siteServer.get('/*', (req, res) => {
    //console.log(req.path)
    return app.render(req, res, `/front${req.path}`, req.query)
  })
  siteServer.all('*', (req, res) => {
    return handle(req, res)
  }) 
  
  mainServer.use(vhost(env.apiDomain, apiServer))
  mainServer.use(vhost(env.adminDomain, adminServer))
  mainServer.use(vhost(env.siteDomain, siteServer))
  mainServer.use(vhost(env.memberDomain, memberServer))
  mainServer.use(vhost(env.prepaidDomain, prepaidServer))
  mainServer.listen(port, (err) => {
    if (err) throw err

    console.log(`> Ready on http://${env.siteDomain}:${port}`)
  })
}).catch(ex => {
  console.info('error')
  console.error(ex.stack)
})
