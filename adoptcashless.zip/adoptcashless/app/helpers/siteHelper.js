const db = require('../config/db.config.js');
const { QueryTypes } = require('sequelize');

exports.setSlug = async function(req, res) {
    var request = JSON.parse(JSON.stringify(req));    
    try{
        let tableName = request.tableName;
        let title = request.title;
        let sulg = title.toLowerCase()
                .replace(/[^\w ]+/g, '')
                .replace(/ +/g, '-');
        let sql = "SELECT COUNT(id) AS NumHits FROM "+tableName+" WHERE slug LIKE '"+sulg+"%'";
        const records = await db.sequelize.query(sql, { type: QueryTypes.SELECT });
        var rows = JSON.parse(JSON.stringify(records[0]));
        if(rows['NumHits']){
            sulg = sulg +'-'+ rows['NumHits'];
        }        
        return sulg;
    }catch(error){
        return error.message;
    }
}

exports.setFieldSlug = async function(req, res) {
    var request = JSON.parse(JSON.stringify(req));    
    try{
        let tableName = request.tableName;
        let title = request.title;
        let sulg = title.toLowerCase()
                .replace(/[^\w ]+/g, '')
                .replace(/ +/g, '_');
        let sql = "SELECT COUNT(id) AS NumHits FROM "+tableName+" WHERE slug LIKE '"+sulg+"%'";
        const records = await db.sequelize.query(sql, { type: QueryTypes.SELECT });
        var rows = JSON.parse(JSON.stringify(records[0]));
        if(rows['NumHits']){
            sulg = sulg + rows['NumHits'];
        }        
        return sulg;
    }catch(error){
        return error.message;
    }
}

exports.getCustomFields = async function(req, res) {
    var request = JSON.parse(JSON.stringify(req));    
    try{
        let id = request.id;
        
        let sql = "SELECT * FROM cms_metadata WHERE page_id = '"+id +"'";

        const records = await db.sequelize.query(sql, { type: QueryTypes.SELECT });

        return records;
       
    }catch(error){
        return error.message;
    }

}
exports.formatDate = function (date, format = 'y-m-d') {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    switch(format){
        case 'd/m/y': retDate = [day, month, year].join('/');
            break;
        case 'y-m-d': 
        default:
            retDate = [year, month, day].join('-');
            break;
    }
    return retDate;
}

exports.formatDateForMySql = function (d) {
    var date = new Date(d);
    date = date.getUTCFullYear() + '-' +
    ('00' + (date.getUTCMonth()+1)).slice(-2) + '-' +
    ('00' + date.getUTCDate()).slice(-2) + ' ' + 
    ('00' + date.getUTCHours()).slice(-2) + ':' + 
    ('00' + date.getUTCMinutes()).slice(-2) + ':' + 
    ('00' + date.getUTCSeconds()).slice(-2);
    return date;
}
/*exports.formatDateForMySql = function (d) {
    var date = new Date(d)
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}*/
exports.formatToDate = function (d) {
    var date = new Date(d);
    date = date.getUTCFullYear() + '-' +
    ('00' + (date.getUTCMonth()+1)).slice(-2) + '-' +
    ('00' + date.getUTCDate()).slice(-2);
    return date;
}