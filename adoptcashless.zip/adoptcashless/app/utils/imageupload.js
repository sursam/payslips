var express	= require("express");
var multer	= require('multer');
const path  = require('path');

var storage	= multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/news'));
    },
    filename: function (req, file, callback) {
	    callback(null, file.originalname);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadSingleImg = async (req, res) =>{
    upload(req,res,function(err) {
        //console.log("RES", res.json(req.file.filename));
		if(err) {
			return res.end("Error uploading file::"+err);
		}
		res.end("File is uploaded successfully!");
	});
}