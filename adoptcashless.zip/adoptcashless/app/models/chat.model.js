module.exports = (sequelize, Sequelize) => {
	const chatHistory = sequelize.define('chat_histories', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		sender_id: {
				type: Sequelize.STRING
		},
		end_consumer_id: {
				type: Sequelize.STRING
		},
		message: {
			type: Sequelize.STRING
		},
		status: {
				type: Sequelize.STRING
		},
		created_on: {
				type: Sequelize.STRING
		}
	});
	
	return chatHistory;
}
