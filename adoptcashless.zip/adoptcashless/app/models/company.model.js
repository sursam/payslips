module.exports = (sequelize, Sequelize) => {
	const Company = sequelize.define('companies', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		companyTitle: {
				type: Sequelize.STRING
		},
		slug: {
				type: Sequelize.STRING
		},
		companyImage: {
			type: Sequelize.STRING
		},
		companyStatus: {
				type: Sequelize.STRING
		},
		modifiedOn: {
				type: Sequelize.STRING
		},
		addedOn: {
				type: Sequelize.STRING
		}
	});
	
	return Company;
}
