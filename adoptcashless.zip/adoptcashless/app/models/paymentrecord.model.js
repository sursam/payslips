module.exports = (sequelize, Sequelize) => {
	const PaymentRecord = sequelize.define('payment_records', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
			type: Sequelize.STRING
		},
		name: {
			type: Sequelize.STRING
		},
		end_consumer_id: {
			type: Sequelize.STRING
		},
		associate_id: {
			type: Sequelize.STRING
		},
		account: {
			type: Sequelize.STRING
		},
		net_amount: {
			type: Sequelize.INTEGER
		},
		total_amount: {
			type: Sequelize.INTEGER
		},
		stripe_fees: {
			type: Sequelize.INTEGER
		},
		tng_commission: {
			type: Sequelize.INTEGER
		},
		tax_invoice: {
			type: Sequelize.STRING
		},
		recharge_procedure: {
			type: Sequelize.STRING
		},
		extra_credit: {
			type: Sequelize.INTEGER
		},
		previous_balance: {
			type: Sequelize.INTEGER
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	return PaymentRecord;
}
