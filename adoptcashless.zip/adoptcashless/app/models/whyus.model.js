module.exports = (sequelize, Sequelize) => {
	const Whyus = sequelize.define('whyus', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		title: {
				type: Sequelize.STRING
		},
		slug: {
			type: Sequelize.STRING
		},
		content: {
				type: Sequelize.STRING
		},
		meta_title: {
				type: Sequelize.STRING
		},
		meta_keywords: {
				type: Sequelize.STRING
		},
		meta_description: {
				type: Sequelize.STRING
		},
		meta_og_url: {
				type: Sequelize.STRING
		},
		order: {
				type: Sequelize.STRING
		},
		status: {
				type: Sequelize.STRING
		},
		created_at : {
				type: Sequelize.STRING
		},
		updated_at : {
				type: Sequelize.STRING
		}
	});
	
	return Whyus;
}
