module.exports = (sequelize, Sequelize) => {
	const Member = sequelize.define('members', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		first_name: {
				type: Sequelize.STRING
		},
		end_consumer_id: {
				type: Sequelize.STRING
		},
		last_name: {
			type: Sequelize.STRING
		},
		mobile: {
				type: Sequelize.STRING
		},
		email: {
				type: Sequelize.STRING
		},
		password: {
			type: Sequelize.STRING
		},
		date_of_birth: {
			type: Sequelize.STRING
		},
		business_name: {
				type: Sequelize.STRING
		},
		abn: {
			type: Sequelize.STRING
		},
		company_name: {
			type: Sequelize.STRING
		},
		end_consumer_id: {
			type: Sequelize.STRING
		},
		licence_serial_number: {
			type: Sequelize.STRING
		},
		otp: {
			type: Sequelize.STRING
		},
		account_type: {
			type: Sequelize.STRING
		},
		activation_code: {
			type: Sequelize.STRING
		},
		status: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	
	return Member;
}
