module.exports = (sequelize, Sequelize) => {
	const News = sequelize.define('news_articles', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		title: {
				type: Sequelize.STRING
		},
		slug: {
			type: Sequelize.STRING
		},
		sub_title: {
				type: Sequelize.STRING
		},
		tags: {
				type: Sequelize.STRING
		},
		short_content: {
				type: Sequelize.STRING
		},
		content: {
				type: Sequelize.STRING
		},
		author: {
				type: Sequelize.STRING
		},
		author_designation: {
				type: Sequelize.STRING
		},
		featured_image: {
				type: Sequelize.STRING
		},
		meta_title: {
				type: Sequelize.STRING
		},
		meta_keywords: {
				type: Sequelize.STRING
		},
		meta_description: {
				type: Sequelize.STRING
		},
		order: {
				type: Sequelize.INTEGER
		},
		status: {
				type: Sequelize.STRING
		},
		created_by: {
				type: Sequelize.STRING
		},
		updated_by: {
				type: Sequelize.STRING
		},
		deleted_by: {
				type: Sequelize.INTEGER
		},
		published_at: {
				type: Sequelize.STRING
		},
		created_at: {
				type: Sequelize.STRING
		},
		updated_at: {
				type: Sequelize.INTEGER
		},
		deleted_at: {
				type: Sequelize.INTEGER
		}
	});
	
	return News;
}
