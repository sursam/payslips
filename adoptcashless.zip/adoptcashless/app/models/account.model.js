module.exports = (sequelize, Sequelize) => {
	const Account = sequelize.define('accounts', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
			type: Sequelize.STRING
		},
		name: {
			type: Sequelize.STRING
		},
		abn: {
			type: Sequelize.STRING
		},
		acn: {
			type: Sequelize.STRING
		},
		billing_street: {
				type: Sequelize.STRING
		},
		billing_suburb: {
				type: Sequelize.STRING
		},
		billing_zip: {
			type: Sequelize.STRING
		},
		billing_state: {
				type: Sequelize.STRING
		},
		billing_country: {
			type: Sequelize.STRING
		},
		status: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	
	return Account;
}
