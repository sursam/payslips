module.exports = (sequelize, Sequelize) => {
	const AutoTopup = sequelize.define('auto_topups', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		endconsumer_id: {
				type: Sequelize.STRING
		},
		/*source_id: {
				type: Sequelize.STRING
		},
		source_type: {
			type: Sequelize.STRING
		},*/
		auto_recharge_amount: {
			type: Sequelize.INTEGER
		},
		auto_trigger_point: {
			type: Sequelize.INTEGER
		},
		extra_credit_val: {
			type: Sequelize.INTEGER
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	return AutoTopup;
}
