module.exports = (sequelize, Sequelize) => {
	const Settings = sequelize.define('site_settings', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		site_title: {
				type: Sequelize.STRING
		},
		address: {
				type: Sequelize.STRING
		},
		postal_address: {
				type: Sequelize.STRING
		},
		working_hours: {
				type: Sequelize.STRING
		},
		helpline_no: {
				type: Sequelize.STRING
		},
		helpline_email_address: {
				type: Sequelize.STRING
		},
		logo: {
				type: Sequelize.STRING
		},
		twitter_link: {
				type: Sequelize.STRING
		},
		facebook_link: {
				type: Sequelize.STRING
		},
		instagram_link: {
				type: Sequelize.STRING
		},
		youtube_link: {
				type: Sequelize.INTEGER
		},
		about_site: {
				type: Sequelize.STRING
		},
		logo: {
			type: Sequelize.STRING
		},
		twitter_link: {
				type: Sequelize.STRING
		},
		facebook_link: {
				type: Sequelize.STRING
		},
		instagram_link: {
				type: Sequelize.STRING
		},
		youtube_link: {
				type: Sequelize.INTEGER
		},
		about_site: {
				type: Sequelize.STRING
		},
		smtphost: {
			type: Sequelize.STRING
		},
		smtpport: {
				type: Sequelize.STRING
		},
		secure: {
				type: Sequelize.STRING
		},
		smtpuser: {
				type: Sequelize.STRING
		},
		smtppassword: {
				type: Sequelize.INTEGER
		},
		smtpfrommail: {
				type: Sequelize.STRING
		}
	});
	
	return Settings;
}
