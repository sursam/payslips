module.exports = (sequelize, Sequelize) => {
	const Card = sequelize.define('cards', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
			type: Sequelize.STRING
		},
		unique_id: {
			type: Sequelize.STRING
		},
		account_id: {
			type: Sequelize.STRING
		},
		Name: {
			type: Sequelize.STRING
		},
		card_number: {
			type: Sequelize.STRING
		},
		card_id: {
			type: Sequelize.STRING
		},
		card_type: {
			type: Sequelize.STRING
		},
		expiration_date: {
			type: Sequelize.DATE
		},
		end_consumer_id: {
			type: Sequelize.STRING
		},
		available_credit: {
			type: Sequelize.INTEGER
		},
		status: {
			type: Sequelize.STRING
		},
		assignment_status: {
			type: Sequelize.STRING
		},
		auto_topup: {
			type: Sequelize.STRING
		},
		topup_trigger_val: {
			type: Sequelize.INTEGER
		},
		topup_recharge_val: {
			type: Sequelize.INTEGER
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	
	return Card;
}
