const CustomField = require('./customfield.model')

module.exports = (sequelize, Sequelize) => {
	const Cms = sequelize.define('cms_pages', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		pageName: {
				type: Sequelize.STRING
		},
		slug: {
			type: Sequelize.STRING
		},
		pageTitle: {
				type: Sequelize.STRING
		},
		innerBannerImage: {
				type: Sequelize.STRING
		},
		pageKeywords: {
				type: Sequelize.STRING
		},
		pageContent: {
				type: Sequelize.STRING
		},
		metaTitle: {
				type: Sequelize.STRING
		},
		metaKeyword: {
				type: Sequelize.STRING
		},
		metaDescription: {
				type: Sequelize.STRING
		},
		pageStatus: {
				type: Sequelize.INTEGER
		},
		addedOn: {
				type: Sequelize.STRING
		},
		modifiedOn: {
				type: Sequelize.STRING
		},
		isDeleted: {
				type: Sequelize.INTEGER
		}
	});

	//Cms.hasMany(CustomField);
	//CustomField.belongsTo(Cms);
	
	return Cms;

}