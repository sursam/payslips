module.exports = (sequelize, Sequelize) => {
	const Testimonial = sequelize.define('testimonials', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		title: {
				type: Sequelize.STRING
		},
		sub_title: {
				type: Sequelize.STRING
		},
		name: {
				type: Sequelize.STRING
		},
		slug: {
			type: Sequelize.STRING
		},
		content: {
				type: Sequelize.STRING
		},
		author_name: {
				type: Sequelize.STRING
		},
		author_designation: {
				type: Sequelize.STRING
		},
		meta_title: {
				type: Sequelize.STRING
		},
		meta_keywords: {
				type: Sequelize.STRING
		},
		meta_description: {
				type: Sequelize.STRING
		},
		meta_og_url: {
				type: Sequelize.STRING
		},
		order: {
				type: Sequelize.STRING
		},
		status: {
				type: Sequelize.STRING
		},
		created_at : {
				type: Sequelize.STRING
		},
		updated_at : {
				type: Sequelize.STRING
		},
		deleted_at : {
				type: Sequelize.STRING
		}
	});
	
	return Testimonial;
}
