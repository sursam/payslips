module.exports = (sequelize, Sequelize) => {
	const Profile = sequelize.define('users', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		username: {
				type: Sequelize.STRING
		},
		first_name: {
				type: Sequelize.STRING
		},
		last_name: {
				type: Sequelize.STRING
		},
		phone: {
				type: Sequelize.STRING
		},
		email: {
				type: Sequelize.STRING
		},
		user_profile_pic: {
				type: Sequelize.STRING
		},
		password: {
			type: Sequelize.STRING
		},
	});
	
	return Profile;
}
