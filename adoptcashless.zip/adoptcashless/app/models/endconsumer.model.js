module.exports = (sequelize, Sequelize) => {
	const EndConsumer = sequelize.define('end_consumers', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
				type: Sequelize.STRING
		},
		name: {
				type: Sequelize.STRING
		},
		first_name: {
			type: Sequelize.STRING
		},
		last_name: {
				type: Sequelize.STRING
		},
		mobile: {
				type: Sequelize.STRING
		},
		email: {
			type: Sequelize.STRING
		},
		date_of_birth: {
			type: Sequelize.STRING
		},
		account_type: {
				type: Sequelize.STRING
		},
		business_name: {
			type: Sequelize.STRING
		},
		abn: {
			type: Sequelize.STRING
		},
		company_name: {
			type: Sequelize.STRING
		},
		licence_serial_number: {
			type: Sequelize.STRING
		},
		password: {
			type: Sequelize.STRING
		},
		is_auto_topup: {
			type: Sequelize.STRING
		},
		activation_code: {
			type: Sequelize.STRING
		},
		current_balance: {
			type: Sequelize.INTEGER
		},
		recharge_procedure: {
			type: Sequelize.STRING
		},
		status: {
			type: Sequelize.STRING
		},
		stripe_customer_id: {
			type: Sequelize.STRING
		},
		connected_account: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	return EndConsumer;
}
