module.exports = (sequelize, Sequelize) => {
	const SupportCase = sequelize.define('support_cases', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		case_id: {
				type: Sequelize.STRING
		},
		related_to: {
				type: Sequelize.STRING
		},
		associates_id: {
			type: Sequelize.STRING
		},
		card_id: {
				type: Sequelize.STRING
		},
		added_date_time: {
				type: Sequelize.STRING
		},
		message: {
				type: Sequelize.STRING
		},
		status: {
				type: Sequelize.STRING
		},
		end_consumer_id: {
				type: Sequelize.STRING
		},
		updated_on: {
				type: Sequelize.STRING
		},
		created_on: {
				type: Sequelize.STRING
		}
	});
	
	return SupportCase;
}
