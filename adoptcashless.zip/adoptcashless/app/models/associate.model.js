module.exports = (sequelize, Sequelize) => {
	const Associate = sequelize.define('associates', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
			type: Sequelize.STRING
		},
		name: {
			type: Sequelize.STRING
		},
		first_name: {
			type: Sequelize.STRING
		},
		last_name: {
			type: Sequelize.STRING
		},
		mobile: {
				type: Sequelize.STRING
		},
		email: {
				type: Sequelize.STRING
		},
		date_of_birth: {
			type: Sequelize.STRING
		},
		gender: {
				type: Sequelize.STRING
		},
		car_reg: {
			type: Sequelize.STRING
		},
		card_id: {
			type: Sequelize.STRING
		},
		end_consumer_id: {
			type: Sequelize.STRING
		},
		status: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		},
		activation_code: {
			type: Sequelize.STRING
		}
	});
	
	return Associate;
}
