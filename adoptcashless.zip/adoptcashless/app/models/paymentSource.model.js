module.exports = (sequelize, Sequelize) => {
	const PaymentSource = sequelize.define('payment_sources', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		source_id: {
			type: Sequelize.STRING
		},
		source_type: {
			type: Sequelize.STRING
		},
		end_consumer_id: {
			type: Sequelize.STRING
		},
		associate_id: {
			type: Sequelize.STRING
		},
		account_type: {
			type: Sequelize.STRING
		},
		brand: {
			type: Sequelize.STRING
		},
		country: {
			type: Sequelize.STRING
		},
		last_four_digits: {
			type: Sequelize.STRING
		},
		bsb_number: {
			type: Sequelize.STRING
		},
		expiry_date: {
			type: Sequelize.STRING
		},
		zipcode: {
			type: Sequelize.STRING
		},
		email: {
			type: Sequelize.STRING
		},
		name: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	return PaymentSource;
}
