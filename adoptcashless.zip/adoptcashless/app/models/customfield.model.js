const cmsData = require('./cms.model');

module.exports = (sequelize, Sequelize) => {
	const CustomField = sequelize.define('cms_metadata', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		page_id: {
				type: Sequelize.INTEGER
		},
		title: {
				type: Sequelize.STRING
		},
		slug: {
				type: Sequelize.STRING
		},
		field_type: {
			     type: Sequelize.STRING
		},
		meta_value: {
				type: Sequelize.STRING
		},
		added_on: {
				type: Sequelize.STRING
		},
		status: {
				type: Sequelize.STRING
		}
	});

	//cmsData.hasMany(CustomField);
	//CustomField.belongsTo(cmsData);

	return CustomField;
}