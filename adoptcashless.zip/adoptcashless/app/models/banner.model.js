module.exports = (sequelize, Sequelize) => {
	const Banner = sequelize.define('banners', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		bannerTitle: {
				type: Sequelize.STRING
		},
		slug: {
				type: Sequelize.STRING
		},
		bannerImage: {
			type: Sequelize.STRING
		},
		bannerStatus: {
				type: Sequelize.STRING
		},
		modifiedOn: {
				type: Sequelize.STRING
		},
		addedOn: {
				type: Sequelize.STRING
		}
	});
	
	return Banner;
}
