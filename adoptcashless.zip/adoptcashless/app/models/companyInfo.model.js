module.exports = (sequelize, Sequelize) => {
	const CompanyInfo = sequelize.define('company_informations', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		endconsumer_id: {
				type: Sequelize.STRING
		},
		field_title: {
				type: Sequelize.STRING
		},
		field_name: {
			type: Sequelize.STRING
		},
		field_type: {
				type: Sequelize.STRING
		},
		field_value: {
				type: Sequelize.STRING
		},
		added_on: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		}
	});
	return CompanyInfo;
}
