module.exports = (sequelize, Sequelize) => {
    const responseData = sequelize.define(
        'repo',
        {
            'resourceName': {type:Sequelize.STRING},
            'errorCode': {type:Sequelize.INTEGER},
            'errorMessage': {type:Sequelize.STRING},
            'data': {type:Sequelize.ANY}
        }
    );
    return responseData;
}