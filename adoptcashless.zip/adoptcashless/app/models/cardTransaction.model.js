module.exports = (sequelize, Sequelize) => {
	const CardTransaction = sequelize.define('card_transactions', {	
	  	id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		name: {
			type: Sequelize.STRING
		},
		salesforce_id: {
			type: Sequelize.STRING
		},
		description: {
			type: Sequelize.STRING
		},
		spent_amount: {
			type: Sequelize.INTEGER
		},
		balance: {
			type: Sequelize.INTEGER
		},
		prepaid_card_id: {
			type: Sequelize.STRING
		},
		display_card_number: {
			type: Sequelize.STRING
		},
		settlement_time: {
			type: Sequelize.STRING
		},
		rfid_card: {
			type: Sequelize.STRING
		},
		account_id: {
			type: Sequelize.STRING
		},
		associate_id: {
			type: Sequelize.STRING
		},
		transaction_id: {
			type: Sequelize.STRING
		},
		machine_name: {
			type: Sequelize.STRING
		},
		batch_job_id: {
			type: Sequelize.STRING
		},
		updated_on: {
			type: Sequelize.STRING
		},
		created_on: {
			type: Sequelize.STRING
		}
	});
	
	return CardTransaction;
}
