module.exports = (sequelize, Sequelize) => {
	const Enquiry = sequelize.define('contact_mails', {	
		id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
		},
		salesforce_id: {
				type: Sequelize.STRING
		},
		first_name: {
				type: Sequelize.STRING
		},
		last_name: {
				type: Sequelize.STRING
		},
		mobile_no: {
				type: Sequelize.STRING
		},
		email: {
			type: Sequelize.STRING
		},
		best_contactable_time: {
				type: Sequelize.STRING
		},
		company_name: {
				type: Sequelize.STRING
		},
		trading_name: {
				type: Sequelize.STRING
		},
		abn: {
				type: Sequelize.STRING
		},
		acn: {
				type: Sequelize.STRING
		},
		address: {
				type: Sequelize.STRING
		},
		industry_type: {
				type: Sequelize.STRING
		},
		credit_card: {
				type: Sequelize.STRING
		},
		message: {
				type: Sequelize.STRING
		},
		is_view : {
				type: Sequelize.STRING
		},
		created_on : {
				type: Sequelize.STRING
		}
	});
	
	return Enquiry;
}
