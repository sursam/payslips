let express = require('express');
let router = express.Router();
const nodemailer = require('nodemailer');
var cors = require('cors')
let env = require('../config/env.js');
const port = env.port || 3000;
const sitePort = (env.NODE_ENV != 'development') ? '' : ':'+port;
const corsOptions = {
    origin: [env.protocol + '://' + env.apiDomain + sitePort, env.protocol + '://' + env.siteDomain + sitePort, env.protocol + '://' + env.adminDomain + sitePort, env.protocol + '://' + env.memberDomain + sitePort, env.protocol + '://' + env.prepaidDomain + sitePort],
    optionsSuccessStatus: 200,
    methods: ['GET','POST','DELETE','UPDATE','PUT','PATCH'],
}

router.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

/*var whitelist = [env.protocol + '://' + env.siteDomain + sitePort, env.protocol + '://' + env.adminDomain + sitePort, env.protocol + '://' + env.memberDomain + sitePort];
router.all("*", (req, res, next) => {
    var origin = req.headers.origin;
    if (whitelist.indexOf(origin) != -1) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Headers", ["Content-Type","X-Requested-With","X-HTTP-Method-Override","Accept"]);
    res.header("Access-Control-Allow-Credentials", true);
    res.header("Access-Control-Allow-Methods", "GET,POST,DELETE,UPDATE,PUT,PATCH");
    res.header("Cache-Control", "no-store,no-cache,must-revalidate");
    res.header("Vary", "Origin");
    if (req.method === "OPTIONS") {
        res.status(200).send("");
        return;
    }
    next();
});
console.log(whitelist)*/

router.use(express.json());

const adminauth = require('../controllers/admin/auth.controller.js');

router.post('/admin-login', cors(corsOptions), adminauth.doLogin);
router.post('/admin-request-password', cors(corsOptions), adminauth.doResetPassword);
router.get('/admin-set-password/', cors(corsOptions), adminauth.doSetPassword);
router.get('/users', cors(corsOptions), adminauth.users);

const admincms = require('../controllers/admin/cms.controller.js');

router.get('/pages', cors(corsOptions), admincms.pages);
router.get('/page-details/:slug', cors(corsOptions), admincms.pageDetails);
router.post('/save-page', cors(corsOptions), admincms.savePage);
router.post('/delete-page', cors(corsOptions), admincms.deletePage);
router.post('/upload-page-field-image', cors(corsOptions), admincms.uploadPageFieldImg);

const adminsite = require('../controllers/admin/site.controller.js');

router.get('/site-settings', cors(corsOptions), adminsite.settings);
router.post('/upload-logo', cors(corsOptions), adminsite.uploadLogo);
router.post('/save-settings', cors(corsOptions), adminsite.saveSettings);

const adminprofile = require('../controllers/admin/profile.controller.js');

router.get('/profile', cors(corsOptions), adminprofile.profile);
router.post('/save-profile', cors(corsOptions), adminprofile.saveProfile);
router.get('/change-password', cors(corsOptions), adminprofile.changePassword);
router.post('/save-password', cors(corsOptions), adminprofile.savePassword);
router.post('/upload-profile-image', cors(corsOptions), adminprofile.uploadProfileImg);

const adminnews = require('../controllers/admin/news.controller.js');

router.get('/news', cors(corsOptions), adminnews.news);
router.post('/upload-news-image', cors(corsOptions), adminnews.uploadNewsImg);
router.post('/edit-news', cors(corsOptions), adminnews.newsDetails);
router.post('/save-news', cors(corsOptions), adminnews.saveNews);
router.post('/delete-news', cors(corsOptions), adminnews.deleteNews);

// const imageUpload = require('../utils/imageupload.js');
// router.post('/upload-news-image', cors(corsOptions), imageUpload.uploadSingleImg);

const adminwhyus = require('../controllers/admin/whyus.controller.js');

router.get('/whyus', cors(corsOptions), adminwhyus.whyus);
router.get('/whyus-details/:slug', cors(corsOptions), adminwhyus.whyusDetails);
router.post('/save-whyus', cors(corsOptions), adminwhyus.saveWhyus);
router.post('/delete-whyus', cors(corsOptions), adminwhyus.deleteWhyus);

const admintestimonial = require('../controllers/admin/testimonial.controller.js');

router.get('/testimonial', cors(corsOptions), admintestimonial.testimonial);
router.get('/testimonial-details/:slug', cors(corsOptions), admintestimonial.testimonialDetails);
router.post('/save-testimonial', cors(corsOptions), admintestimonial.saveTestimonial);
router.post('/delete-testimonial', cors(corsOptions), admintestimonial.deleteTestimonial);

const adminenquiry = require('../controllers/admin/enquiry.controller.js');

router.get('/enquiry', cors(corsOptions), adminenquiry.enquiry);
router.get('/enquiry-details/:id', cors(corsOptions), adminenquiry.enquiryDetails);
router.post('/delete-enquiry', cors(corsOptions), adminenquiry.deleteEnquiry);

const admincustomfield = require('../controllers/admin/customfield.controller.js');

router.get('/custom-field', cors(corsOptions), admincustomfield.customField);
router.post('/get-all-page', cors(corsOptions), admincustomfield.pages);
router.post('/get-page-field', cors(corsOptions), admincustomfield.pageField);
router.get('/custom-field-details/:slug', cors(corsOptions), admincustomfield.customFieldDetails);
router.post('/save-custom-field', cors(corsOptions), admincustomfield.saveCustomField);
router.post('/delete-custom-field', cors(corsOptions), admincustomfield.deleteCustomField);

const adminbanner = require('../controllers/admin/banner.controller.js');

router.get('/banners', cors(corsOptions), adminbanner.banners);
router.get('/banner-details/:slug', cors(corsOptions), adminbanner.bannerDetails);
router.post('/save-banner', cors(corsOptions), adminbanner.saveBanner);
router.post('/upload-banner-image', cors(corsOptions), adminbanner.uploadBannerImg);
router.post('/upload-page-banner-image', cors(corsOptions), adminbanner.uploadBannerImg);
router.post('/delete-banner', cors(corsOptions), adminbanner.deleteBanner);

const admincompany = require('../controllers/admin/company.controller.js');

router.get('/company', cors(corsOptions), admincompany.company);
router.get('/company-details/:slug', cors(corsOptions), admincompany.companyDetails);
router.post('/save-company', cors(corsOptions), admincompany.saveCompany);
router.post('/upload-company-image', cors(corsOptions), admincompany.uploadCompanyImg);
router.post('/delete-company', cors(corsOptions), admincompany.deleteCompany);

const contact = require('../controllers/frontend/contact.controller.js');

router.post('/send-enquiry', contact.sendEnquiry);
router.get('/test-salesforce', contact.testSalesforce);

const pageContent = require('../controllers/frontend/pageContent.controller.js');

router.get('/page-content/:slug', pageContent.pageDetailsBySlug);
router.get('/all-testimonial/', pageContent.testimonial);
router.get('/all-news/', pageContent.news);
router.get('/list-news/', pageContent.listnews);
router.get('/other-news/', pageContent.othernews);
router.get('/news-details/:slug', pageContent.newsdetails);
router.get('/all-whyus/', pageContent.whyusList);
router.get('/company-list/', pageContent.companylist);

const member = require('../controllers/frontend/member.controller.js');

router.post('/member-signup/', cors(corsOptions), member.registrationData);
router.post('/check-member-email/', cors(corsOptions), member.checkMemberEmail);
router.post('/validate-otp/', cors(corsOptions), member.validateOtp);
router.post('/member-login/', cors(corsOptions), member.memberLogin);
router.post('/member-forgot-password/', cors(corsOptions), member.memberForgotPassword);
router.post('/member-reset-password/', cors(corsOptions), member.memberResetPassword);
router.get('/get-associates/:econ', cors(corsOptions), member.getAssociates);
router.get('/get-associate-details/:id', cors(corsOptions), member.getAssociateDetails);
router.get('/get-available-cards/:econ', cors(corsOptions), member.getAvailableCards);
router.get('/get-card-details/:id', cors(corsOptions), member.getCardDetails);
router.post('/save-associate/', cors(corsOptions), member.saveAssociate);
router.post('/delete-associate/', cors(corsOptions), member.deleteAssociate);
router.post('/end-consumer-reference/', cors(corsOptions), member.getEndConsumerReference);
router.post('/verification-email-code/', cors(corsOptions), member.verificationEmailCode);
router.post('/search-associates/', cors(corsOptions), member.searchAssociates);
router.get('/get-endconsumer-details/:id', cors(corsOptions), member.getEndconsumerDetails);
router.get('/get-corporate-cards/:id', cors(corsOptions), member.getCorporateCards);
router.get('/get-corporate-card-ids/:id', cors(corsOptions), member.getCorporateCardIds);
router.get('/get-salesforce-cards/:econ', cors(corsOptions), member.getSalesforceCards);
router.post('/get-all-cards/', cors(corsOptions), member.getAllCards);
router.post('/search-corporate-cards/', cors(corsOptions), member.searchCorporateCards);
router.get('/unlink-corporate-card/:id', cors(corsOptions), member.unlinkCorporateCard);
router.get('/get-available-associate/:id', cors(corsOptions), member.getAvailableAssociate);
router.post('/link-corporate-cards/', cors(corsOptions), member.linkCorporateCards);
router.post('/transfer-corporate-card/', cors(corsOptions), member.transferCorporateCard);
router.post('/transfer-corporate-card-associate/', cors(corsOptions), member.transferCorporateCardAssociate);
router.get('/get-corporate-card-details/:id', cors(corsOptions), member.getCorporateCardDetails);
router.post('/update-card-status-details/', cors(corsOptions), member.updateCardStatusDetails);
router.get('/get-salesforce-card-details/:id', cors(corsOptions), member.getSalesforceCardDetails);
router.get('/get-card-associates/:id', cors(corsOptions), member.getCardAssociates);

//router.get('/get-all-associates/:id', cors(corsOptions), member.getAllAssociates);
router.get('/get-associate-corporate-cards/:id', cors(corsOptions), member.getAssociateCorporateCard);
router.post('/save-support-case/', cors(corsOptions), member.saveSupportCase);
router.get('/get-support-cases/:id', cors(corsOptions), member.getSupportCases);
router.get('/get-support-case-details/:id', cors(corsOptions), member.getSupportCaseDetails);
router.get('/support-case-status/:id', cors(corsOptions), member.supportCaseStatus);
router.get('/get-active-support-cases/:id', cors(corsOptions), member.activeSupportCase);
router.get('/get-support-chat-history/:id', cors(corsOptions), member.supportCaseHistory);
// router.get('/change-associate-card/:id', cors(corsOptions), member.changeAssociateCard);
router.post('/update-associate-status-details/', cors(corsOptions), member.updateAssociateStatusDetails);

router.get('/get-slesforce-sssociates/:id', cors(corsOptions), member.getSalesforceAssociates);
router.get('/salesforce-associate-update/:id', cors(corsOptions), member.salesforceAssociateUpdate);
router.post('/salesforce-callback', cors(corsOptions), member.salesforceCallback);

router.get('/get-card-counts/:econ', cors(corsOptions), member.getCardCounts);

router.get('/get-aws-messages', cors(corsOptions), member.getAwsMessages);
router.get('/get-extra-credit/:econ', cors(corsOptions), member.getExtraCredit);
router.get('/get-stripe-account/:econ', cors(corsOptions), member.getStripeAccount);
router.get('/get-recent-transactions/:econ', cors(corsOptions), member.getRecentTransactions);
router.get('/get-all-transactions/:econ', cors(corsOptions), member.getAllTransactions);
router.get('/get-transaction-details/:sid', cors(corsOptions), member.getTransactionDetails);
router.post('/do-stripe-recharge/', cors(corsOptions), member.doStripeRecharge);
router.post('/setup-auto-topup/', cors(corsOptions), member.setupAutoTopup);
router.post('/setup-payment-methods/', cors(corsOptions), member.setupPaymentMethods);
router.get('/get-endconsumer-account-sources/:econ', cors(corsOptions), member.getEndconsumerAccountSources);
router.get('/get-endconsumer-selected-sources/:econ', cors(corsOptions), member.getEndconsumerSelectedSources);
router.post('/add-stripe-bank-account/', cors(corsOptions), member.addStripeBankAccount);
router.get('/get-stripe-client-secret/:econ', cors(corsOptions), member.getStripeClientSecret);
router.post('/create-stripe-source/', cors(corsOptions), member.createStripeSource);
router.post('/allocate-unassigned-credit/', cors(corsOptions), member.allocateUnassignedCredit);
router.get('/get-endconsumer-db-data/:id', cors(corsOptions), member.getEndconsumerDbData);
router.get('/get-auto-topup-values/:econ', cors(corsOptions), member.getAutoTopupValues);
router.post('/is-mobile-exists', cors(corsOptions), member.isMobileExists);
router.post('/update-associate-autotopup', cors(corsOptions), member.updateAssociateAutotopup);
router.post('/update-endconsumer-autotopup', cors(corsOptions), member.updateEndconsumerAutotopup);
router.post('/delete-rfid-card', cors(corsOptions), member.deleteRfidCard);
//router.get('/get-prepaid-card-usage/:econ', cors(corsOptions), member.getPrepaidCardUsage);
router.get('/get-prepaid-card-usage', cors(corsOptions), member.getPrepaidCardUsage);
router.get('/get-latest-transactions/:id/:day', cors(corsOptions), member.getLatestTransactions);
router.post('/get-most-used-cards', cors(corsOptions), member.getMostUsedCards);
router.post('/get-usage-statements', cors(corsOptions), member.getUsageStatements);
router.post('/get-usage-statements-months', cors(corsOptions), member.getUsageStatementsMonths);
router.post('/send-invoice', cors(corsOptions), member.sendInvoice);
router.post('/save-company-info', cors(corsOptions), member.saveCompanyInfo);
router.get('/get-company-info/:econ', cors(corsOptions), member.getCompanyInfo);
router.post('/upload-company-logo', cors(corsOptions), member.uploadCompanyLogo);
router.get('/get-account-info-by-endconsumer/:econ', cors(corsOptions), member.getAccountInfoByEndconsumer);

const prepaid = require('../controllers/frontend/prepaid.controller.js');

router.post('/register-indivisual-consumer/', cors(corsOptions), prepaid.registerIndivisualConsumer);
//router.post('/register-associate/', cors(corsOptions), prepaid.registerAssociate);
router.post('/login-associate/', cors(corsOptions), prepaid.loginAssociate);
router.get('/get-available-corporate-cards', cors(corsOptions), prepaid.getAvailableCorporateCards);
router.post('/verify-associate-email', cors(corsOptions), prepaid.verifyAssociateEmail);
router.post('/update-associate-data/', cors(corsOptions), prepaid.updateAssociateData);
//router.get('/get-card-by-number/:num', cors(corsOptions), prepaid.getCardByNumber);
router.get('/get-associate-transactions/:aid', cors(corsOptions), prepaid.getAssociateTransactions);
router.get('/do-associate-autotopup', cors(corsOptions), prepaid.doAssociateAutotopup);
router.post('/do-prepaid-stripe-recharge/', cors(corsOptions), prepaid.doPrepaidStripeRecharge);
router.get('/test-query/:id', cors(corsOptions), prepaid.testQuery);

router.get('/apple-wallet-pass', cors(corsOptions), prepaid.appleWalletPass);

module.exports = router;
