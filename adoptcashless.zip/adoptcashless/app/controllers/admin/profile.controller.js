const db = require('../../config/db.config.js');
const env = require('../../config/env.js');
const Profile = db.Profile;

var multer  = require('multer');
const path  = require('path');

const userID = 1;

exports.profile = (req, res) => {
    try{
        Profile.findOne({
            attributes: ['id', 'username', 'first_name', 'last_name', 'phone', 'email', 'user_profile_pic'], 
            where: {
                id: userID, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveProfile = (req, res) => {    
    let pageObject = {
        username: req.body.username,
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        phone: req.body.phone,
        email: req.body.email,
        user_profile_pic: req.body.profile_pic
    }
    try{
        let id = req.body.id;

            let page = Profile.findByPk(id);                   
                let result = Profile.update(pageObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'username', 'first_name', 'last_name', 'phone', 'email', 'user_profile_pic']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update settings ",
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Profile successfully updated.",
                    slug: '',
                    success: "Success",
                });
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}
exports.changePassword = (req, res) => {
    try{
        Profile.findOne({
            attributes: ['id'], 
            where: {
                id: userID, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.savePassword = async (req, res) => {
    const bcrypt = require('bcryptjs');

    const salt = await bcrypt.genSalt(10);

    let password = await bcrypt.hash(req.body.password, salt); 

    let updatedObject = {
        password: password,
    }

    try{

        let id = req.body.id;

        Profile.findOne({
            where: {
                id: id, 
            },
        }).then(user => {
            if (bcrypt.compareSync(req.body.currentPassword, user.password)) {

                let result = Profile.update(updatedObject,
                    { 
                      returning: true, 
                      where: {id: id},
                      attributes: ['password']
                    }
                  );

                res.status(200).json({
                    message: "Password updated successfully.",
                    slug: '',
                    success: "Success",
                });

            }else
            {
                res.status(200).json({
                    status: 0,
                    error: "Current password does not matched"
                });
            }
        }).catch(error => {
            res.status(500).json({
                status: 0,
                error: "Something wrong! Please try again."
            });
        })        
    }catch(error){
        res.status(500).json({
            status: 0,
            error: error.message
        });
    }
    
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/profile'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadProfileImg = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}