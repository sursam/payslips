const { json } = require('body-parser');
const { QueryTypes } = require('sequelize');
const db = require('../../config/db.config.js');
const Cms = db.Cms;
const CustomField = db.CustomField;
const siteHelper = require('../../helpers/siteHelper.js');
const env = require('../../config/env.js');

var multer  = require('multer');
const path  = require('path');

exports.pages = (req, res) => {
    try{
        Cms.findAll({
            attributes: ['id', 'pageName', 'innerBannerImage', 'slug', 'pageTitle', 'pageKeywords', 'pageContent', 'metaTitle', 'metaKeyword', 'metaDescription', 'pageStatus', 'addedOn', 'modifiedOn', 'isDeleted'], 
            where: {
                pageStatus: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.pageDetails = (req, res) => {
    let slug = req.params.slug;
    //console.log(slug);
    try{
        Cms.findOne({
            attributes: ['id', 'pageName', 'innerBannerImage', 'slug', 'pageTitle', 'pageKeywords', 'pageContent', 'metaTitle', 'metaKeyword', 'metaDescription', 'pageStatus', 'addedOn', 'modifiedOn', 'isDeleted'], 
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.savePage = async (req, res) => { 
    //console.log(req.body);   
    let pageObject = {
        pageName: req.body.pageName,
        pageTitle: req.body.pageTitle,
        innerBannerImage: req.body.bannerImageName,
        pageContent: req.body.pageContent,
        metaTitle: req.body.metaTitle,
        metaKeyword: req.body.metaKeyword,
        metaDescription: req.body.metaDescription
    }
    try{
        let id = req.body.id;
        if(id){
            let page = await Cms.findByPk(id);
            if(!page){
                res.status(404).json({
                    message: "Not Found for updating a page with id = " + id,
                    error: "404"
                });
            } else {    
                let date_ob = new Date();
                let date = ("0" + date_ob.getDate()).slice(-2);
                let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                let year = date_ob.getFullYear();
                let hours = date_ob.getHours();
                let minutes = date_ob.getMinutes();
                let seconds = date_ob.getSeconds(); 
                let modifiedOn = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;   
                pageObject['modifiedOn'] = modifiedOn; 

                let fieldParams = { id: id};

                pageCustomField = await siteHelper.getCustomFields(fieldParams);

                for(var i = 0; i < pageCustomField.length; i++)
                {
                    const customSlug = pageCustomField[i].slug;

                    let customFieldObject = {
                                meta_value: req.body[customSlug],
                            }

                    CustomField.update(customFieldObject,
                        { 
                            returning: true, 
                            where: {slug: customSlug},
                            attributes: ['meta_value']
                        }
                    );
                }

                let result = Cms.update(pageObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'pageName', 'innerBannerImage', 'pageTitle', 'pageContent', 'metaTitle', 'metaKeyword', 'metaDescription']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update a page with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Page successfully updated.",
                        slug: page.slug,
                        success: "Success",
                    });
                } 
            }
        }else{
            let params = { title: req.body.pageName, tableName: 'cms_pages' };
            slug = await siteHelper.setSlug(params);
            pageObject['slug'] = slug;
            Cms.create(pageObject, 
                {attributes: ['id', 'pageName', 'innerBannerImage', 'slug', 'pageTitle', 'pageContent', 'metaTitle', 'metaKeyword', 'metaDescription']})
            .then(result => {     
                res.status(200).json({
                    message: "Page successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

exports.deletePage = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let page = await Cms.findByPk(id);
            if(!page){
                res.status(404).json({
                    message: "Not Found for deleting a page with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Cms.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a page with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Page successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Page not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/pages'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadPageFieldImg = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}