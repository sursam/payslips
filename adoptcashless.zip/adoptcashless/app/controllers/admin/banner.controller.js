const db = require('../../config/db.config.js');
const Banner = db.Banner;
const siteHelper = require('../../helpers/siteHelper.js');
const env = require('../../config/env.js');

var multer  = require('multer');
const path  = require('path');

exports.banners = (req, res) => {
    try{
        Banner.findAll({
            attributes: ['id', 'bannerTitle', 'slug', 'bannerImage', 'bannerStatus', 'modifiedOn', 'addedOn'], 
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.bannerDetails = (req, res) => {
    let slug = req.params.slug;
    try{
        Banner.findOne({
            attributes: ['id', 'bannerTitle', 'slug', 'bannerImage', 'bannerStatus', 'modifiedOn', 'addedOn'],  
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveBanner = async (req, res) => {    
    let bannerObject = {
        bannerTitle: req.body.bannerTitle,
        bannerImage: req.body.bannerImageName,
        bannerStatus: req.body.bannerStatus,
        isDeleted: req.body.isDeleted
    }

    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    try{
        let id = req.body.id;

        if(id){
            let banner = Banner.findByPk(id);

            if(!banner){
                res.status(404).json({
                    message: "Not Found for updating a banner with id = " + id,
                    error: "404"
                });
            } else {    

                   

                bannerObject['modifiedOn'] = totalDate;  

                let result = Banner.update(bannerObject,
                    {   
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'bannerTitle', 'bannerImage', 'bannerStatus', 'modifiedOn']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update banner with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Banner successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{

            let params = { title: req.body.bannerTitle, tableName: 'banners' };

            slug = await siteHelper.setSlug(params);

            bannerObject['slug'] = slug;
            bannerObject['addedOn'] = totalDate;

            Banner.create(bannerObject, 
                {attributes: ['id', 'bannerTitle', 'slug', 'bannerImage', 'bannerStatus', 'addedOn']})
            .then(result => {     
                res.status(200).json({
                    message: "Banner successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}
exports.deleteBanner = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let banner = await Banner.findByPk(id);
            if(!banner){
                res.status(404).json({
                    message: "Not Found for deleting a banner with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Banner.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a banner with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Banner successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Banner not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/banner'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});

exports.uploadBannerImg = async (req, res) =>{

var upload = multer({ storage : storage}).single('myfile');
    
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}