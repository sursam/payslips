const db = require('../../config/db.config.js');
const Company = db.Company;
const siteHelper = require('../../helpers/siteHelper.js');
const env = require('../../config/env.js');

var multer  = require('multer');
const path  = require('path');

exports.company = (req, res) => {
    try{
        Company.findAll({
            attributes: ['id', 'companyTitle', 'slug', 'companyImage', 'companyStatus', 'modifiedOn', 'addedOn'], 
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.companyDetails = (req, res) => {
    let slug = req.params.slug;
    try{
        Company.findOne({
            attributes: ['id', 'companyTitle', 'slug', 'companyImage', 'companyStatus', 'modifiedOn', 'addedOn'],  
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveCompany = async (req, res) => {    
    let companyObject = {
        companyTitle: req.body.companyTitle,
        companyImage: req.body.companyImageName,
        companyStatus: req.body.companyStatus,
        isDeleted: req.body.isDeleted
    }

    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    try{
        let id = req.body.id;

        if(id){
            let company = Company.findByPk(id);

            if(!company){
                res.status(404).json({
                    message: "Not Found for updating a company with id = " + id,
                    error: "404"
                });
            } else {    

                   

                companyObject['modifiedOn'] = totalDate;  

                let result = Company.update(companyObject,
                    {   
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'companyTitle', 'companyImage', 'companyStatus', 'modifiedOn']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update company with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Company successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{

            let params = { title: req.body.companyTitle, tableName: 'companys' };

            slug = await siteHelper.setSlug(params);

            companyObject['slug'] = slug;
            companyObject['addedOn'] = totalDate;

            Company.create(companyObject, 
                {attributes: ['id', 'companyTitle', 'slug', 'companyImage', 'companyStatus', 'addedOn']})
            .then(result => {     
                res.status(200).json({
                    message: "Company successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}
exports.deleteCompany = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let company = await Company.findByPk(id);
            if(!company){
                res.status(404).json({
                    message: "Not Found for deleting a company with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Company.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a company with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Company successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Company not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/company'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadCompanyImg = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}