const db = require('../../config/db.config.js');
const Whyus = db.Whyus;
const siteHelper = require('../../helpers/siteHelper.js');

exports.whyus = (req, res) => {
    try{
        Whyus.findAll({
            attributes: ['id', 'title', 'slug', 'content', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_at', 'updated_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.whyusDetails = (req, res) => {
    let slug = req.params.slug;
    try{
        Whyus.findOne({
            attributes: ['id', 'title', 'slug', 'content', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_at', 'updated_at'], 
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.saveWhyus = async (req, res) => {
    let whyusObject = {
        title: req.body.title,
        content: req.body.content,
        meta_title: req.body.meta_title,
        meta_keywords: req.body.meta_keywords,
        meta_description: req.body.meta_description
    }

    try{
        let id = req.body.id;
        if(id){
            let news = Whyus.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for updating a news with id = " + id,
                    error: "404"
                });
            } else {  

                let date_ob = new Date();
                let date = ("0" + date_ob.getDate()).slice(-2);
                let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                let year = date_ob.getFullYear();
                let hours = date_ob.getHours();
                let minutes = date_ob.getMinutes();
                let seconds = date_ob.getSeconds(); 
                let modifiedOn = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;   
                whyusObject['updated_at'] = modifiedOn;
                              
                let result = Whyus.update(whyusObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'title', 'slug', 'content', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'updated_at'], 
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update a news with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Why us successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{
            let params = { title: req.body.title, tableName: 'whyus' };
            slug = await siteHelper.setSlug(params);
            whyusObject['slug'] = slug;
            Whyus.create(whyusObject, 
                {attributes: ['id', 'title', 'slug', 'content', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status']})
            .then(result => {     
                res.status(200).json({
                    message: "Why us successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

exports.deleteWhyus = async (req, res) => {
    try{
        let id = req.body.id;
        if(id){
            let news = await Whyus.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for deleting a news with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Whyus.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a news with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Why us successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Why us not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}