let mysql = require('mysql');
const db = require('../../config/db.config.js');
const Cms = db.Cms;
const CustomField = db.CustomField;
const siteHelper = require('../../helpers/siteHelper.js');
const { QueryTypes } = require('sequelize');

let connection = mysql.createConnection(db);

exports.customField = async (req, res) => {

    let page_id = req.body.page_id;

    try{
        let sql = "select cm.*,cp.pageName from cms_metadata as cm INNER JOIN cms_pages as cp ON cm.page_id = cp.id order by cp.id desc";

        await db.sequelize.query(sql, { type: QueryTypes.SELECT }).then(function (data) {
            res.status(200).json(data);
         })

        // CustomField.findAll({
        //     attributes: ['id', 'page_id', 'title', 'slug', 'field_type', 'meta_value', 'added_on', 'status'], 
        // })
        // .then(data => {
        //     res.status(200).json(data);
        // })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.pages = (req, res) => {
    try{
        Cms.findAll({
            attributes: ['id', 'pageName'], 
            where: {
                pageStatus: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.pageField = (req, res) => {
    let id = req.body.id;
    try{
            if(id){
            CustomField.findAll({
                attributes: ['id', 'page_id', 'title', 'slug', 'field_type', 'meta_value', 'added_on', 'status'],  
                where: {
                    page_id: id, 
                    status: 1, 
                },
            })
            .then(data => {
                res.status(200).json(data);
            })
        }
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.customFieldDetails = (req, res) => {
    let slug = req.params.slug;
    try{
        CustomField.findOne({
            attributes: ['id', 'page_id', 'title', 'slug', 'field_type', 'meta_value', 'added_on', 'status'],  
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveCustomField = async (req, res) => {    
    let customFieldObject = {
        page_id: req.body.page_id,
        title: req.body.title,
        slug: req.body.slug,
        field_type: req.body.field_type,
        meta_value: req.body.meta_value,
        added_on: req.body.added_on,
        status: req.body.status
    }
    try{
        let id = req.body.id;
        if(id){
            let page = CustomField.findByPk(id);
            if(!page){
                res.status(404).json({
                    message: "Not Found for updating a page with id = " + id,
                    error: "404"
                });
            } else {                    
                let result = CustomField.update(customFieldObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['page_id', 'title', 'slug', 'field_type', 'meta_value', 'added_on', 'status']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update custom field with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Custom field successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{
            let params = { title: req.body.title, tableName: 'cms_metadata' };
            slug = await siteHelper.setFieldSlug(params);

            customFieldObject['slug'] = slug;
            CustomField.create(customFieldObject, 
                
                {attributes: ['page_id', 'title', 'slug', 'field_type', 'meta_value', 'added_on', 'status']})
            .then(result => {     
                res.status(200).json({
                    message: "Custom field successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}
exports.deleteCustomField = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let news = await CustomField.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for deleting a custom field with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await CustomField.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a custom field with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Custom field successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Custom field not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}