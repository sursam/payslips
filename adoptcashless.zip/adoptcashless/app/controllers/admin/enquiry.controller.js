const db = require('../../config/db.config.js');
const Enquiry = db.Enquiry;

exports.enquiry = (req, res) => {
    try{
        Enquiry.findAll({
            attributes: ['id', 'first_name', 'last_name', 'mobile_no', 'email', 'best_contactable_time', 'company_name', 'trading_name', 'abn', 'acn', 'address', 'industry_type', 'credit_card', 'message', 'is_view', 'created_on'], 
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.enquiryDetails = (req, res) => {
    let id = req.params.id;
    //console.log(slug);
    try{
        Enquiry.findOne({
            attributes: ['id', 'first_name', 'last_name', 'mobile_no', 'email', 'best_contactable_time', 'company_name', 'trading_name', 'abn', 'acn', 'address', 'industry_type', 'credit_card', 'message'],  
            where: {
                id: id, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.deleteEnquiry = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let enquiry = await Enquiry.findByPk(id);
            if(!enquiry){
                res.status(404).json({
                    message: "Not Found for deleting any enquiry with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Enquiry.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update any enquiry with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Enquiry successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Enquiry not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}