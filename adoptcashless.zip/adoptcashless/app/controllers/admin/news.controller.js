const db = require('../../config/db.config.js');
const News = db.News;
const siteHelper = require('../../helpers/siteHelper.js');
const env = require('../../config/env.js');

var multer  = require('multer');
const path  = require('path');

exports.news = (req, res) => {
    try{
        News.findAll({
            attributes: ['id', 'title', 'slug', 'sub_title', 'tags', 'short_content','content', 'featured_image', 'author', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_by', 'updated_by', 'deleted_by', 'published_at', 'created_at', 'updated_at', 'deleted_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.newsDetails = (req, res) => {
    let slug = req.body.slug;
    try{
        News.findOne({
            attributes: ['id', 'title', 'slug', 'sub_title', 'tags', 'short_content', 'content', 'featured_image', 'author', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_by', 'updated_by', 'deleted_by', 'published_at', 'created_at', 'updated_at', 'deleted_at'], 
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.saveNews = async (req, res) => {
    let newsObject = {
        title: req.body.title,
        sub_title: req.body.sub_title,
        tags: req.body.tags,
        short_content: req.body.short_content,
        content: req.body.content,
        author: req.body.author,
        author_designation: req.body.author_designation,
        published_at: req.body.published_at,
        meta_title: req.body.meta_title,
        meta_keywords: req.body.meta_keywords,
        meta_description: req.body.meta_description
    }

    if(req.body.featured_image_name !="")
    {
           newsObject['featured_image'] = req.body.featured_image_name; 
    }
    else
    {
           newsObject['featured_image'] = ''; 
    }

    try{
        let id = req.body.id;
        if(id){
            let news = News.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for updating a news with id = " + id,
                    error: "404"
                });
            } else {                    
                let result = News.update(newsObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'title', 'slug', 'sub_title', 'tags', 'short_content','content', 'featured_image', 'author', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'published_at', 'updated_at', 'deleted_at']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update a news with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "News successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{
            let params = { title: req.body.title, tableName: 'news_articles' };
            slug = await siteHelper.setSlug(params);
            newsObject['slug'] = slug;
            News.create(newsObject, 
                {attributes: ['id', 'title', 'slug', 'sub_title', 'tags', 'short_content','content', 'featured_image', 'author', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'published_at', 'created_at', 'updated_at', 'deleted_at']})
            .then(result => {     
                res.status(200).json({
                    message: "News successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

exports.deleteNews = async (req, res) => {
    try{
        let id = req.body.id;
        if(id){
            let news = await News.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for deleting a news with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await News.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a news with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "News successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "News not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/news'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadNewsImg = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}