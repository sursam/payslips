const db = require('../../config/db.config.js');
const User = db.User;
const nodemailer = require("nodemailer");

/**
 * Save a User object to database MySQL/PostgreSQL
 * @param {*} req 
 * @param {*} res 
 */
exports.doLogin = (req, res) => {
    let username = req.body.username;
    let password = req.body.password;

    try{
        User.findOne({
            where: {
                email: username, 
            },
        }).then(user => {
            const bcrypt = require('bcryptjs')
            if(user){
                if (!bcrypt.compareSync(password, user.password)) {
                    // authentication failed
                    res.status(200).json({
                        status: 0,
                        error: "Password is incorrect"
                    });
                }else{
                    res.status(200).json({
                        status: 1,
                        userId: user.id,
                        error: ''
                    });
                }
            }else{
                res.status(200).json({
                    status: 0,
                    error: "Email does not found"
                });
            }
        }).catch(error => {
            console.log(error);
            res.status(500).json({
                status: 0,
                error: error
            });
        })        
    }catch(error){
        res.status(500).json({
            status: 0,
            error: error.message
        });
    }
}

function getQueryParams(url) {
    const paramArr = url.slice(url.indexOf('?') + 1).split('&');
    const params = {};
    paramArr.map(param => {
        const [key, val] = param.split('=');
        params[key] = decodeURIComponent(val);
    })
    return params;
}

exports.doSetPassword = async (req, res) => {
    const bcrypt = require('bcryptjs');

    const salt = await bcrypt.genSalt(10);
    let password = await bcrypt.hash(req.body.password, salt); 

    let aCode = req.body.code;

    let updatedObject = {
        password:password,
        activation_code:'',
    }

    try{
        User.findOne({
            where: {
                activation_code: aCode, 
            },
        }).then(user => {
            if(user){

                let result = User.update(updatedObject,
                    { 
                      returning: true, 
                      where: {activation_code: aCode},
                      attributes: ['password', 'activation_code']
                    }
                  );

                res.status(200).json({
                    status: 1,
                    error: ""
                });
            }else{
                res.status(200).json({
                    status: 0,
                    error: "Password reset url does not exit"
                });
            }
        }).catch(error => {
            //console.log(error);
            res.status(200).json({
                    status: 0,
                    error: "Something wrong! Please try again."
                });
        })        
    }catch(error){
       res.status(200).json({
                    status: 0,
                    error: "Activation code not found."
                });
    }
    
}

exports.doResetPassword = async (req, res) => {

    let username = req.body.username;

    let genCode = Math.random().toString(36).slice(2);

    let updatedObject = {
        activation_code: aCode,
    }

    const fullUrl = `${req.protocol}`;

    try{
        Settings.findOne({
            attributes: ['helpline_email_address', 'smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
            where: {
                id: 1, 
            },
        })
        .then(async data => {

    let transporter = nodemailer.createTransport({
                host: data.smtphost,
                port: data.smtpport,
                auth: {
                   user: data.smtpuser,
                   pass: data.smtppassword
                },
              }); 

    let info = await transporter.sendMail({
                from: data.smtpfrommail,
                to: username,
                subject: "Reset Password",
                html: "<b>Hi,</b><br><p>Please <a href="+fullUrl+"/reset-password/?data="+aCode+">click here</a> to reset the password.</p><br><p>Thank You</p><p><b>Tap N Go</b></p>",
              });            

    try{
        User.findOne({
            where: {
                email: username, 
            },
        }).then(user => {
            
            if(user){

                let result = User.update(updatedObject,
                    { 
                      returning: true, 
                      where: {email: username},
                      attributes: ['activation_code']
                    }
                  );
                res.status(200).json({
                    status: 1,
                    error: ""
                });

            }else{
                res.status(200).json({
                    status: 0,
                    error: "Email does not found"
                });
            }
        }).catch(error => {
            //console.log(error);
            res.status(500).json({
                status: 0,
                error: error
            });
        })        
    }catch(error){
        res.status(500).json({
            status: 0,
            error: error.message
        });
    }

    });

    }catch(error) {
            res.status(200).json({
                message: "Error!",
                error: error.message
            });
        }
}

exports.users = (req, res) => {
    try{
        User.findAll({attributes: ['id', 'username', 'password', 'email']})
        .then(users => {
            res.status(200).json(users);
        })
    }catch(error) {
        // log on console
        //console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
