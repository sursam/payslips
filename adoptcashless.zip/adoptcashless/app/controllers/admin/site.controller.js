const db = require('../../config/db.config.js');
const Settings = db.Settings;
const env = require('../../config/env.js');
var multer  = require('multer');
const path  = require('path');

exports.settings = (req, res) => {
    //let slug = req.body.slug;
    //console.log(slug);
    try{
        Settings.findOne({
            attributes: ['id', 'site_title', 'address', 'postal_address', 'helpline_no', 'working_hours', 'helpline_email_address', 'logo', 'twitter_link', 'facebook_link', 'instagram_link', 'youtube_link', 'about_site', 'smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
            where: {
                id: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveSettings = (req, res) => {    
    let pageObject = {
        site_title: req.body.site_title,
        currency: req.body.currency,
        address: req.body.address,
        postal_address: req.body.postal_address,
        working_hours: req.body.working_hours,
        helpline_no: req.body.helpline_no,
        helpline_email_address: req.body.helpline_email_address,
        logo: req.body.logo_name,
        twitter_link: req.body.twitter_link,
        facebook_link: req.body.facebook_link,
        instagram_link: req.body.instagram_link,
        youtube_link: req.body.youtube_link,
        about_site: req.body.about_site,
        smtphost: req.body.smtphost,
        smtpport: req.body.smtpport,
        secure: req.body.secure,
        smtpuser: req.body.smtpuser,
        smtppassword: req.body.smtppassword,
        smtpfrommail: req.body.smtpfrommail
    }
    try{
        let id = req.body.id;

            let page = Settings.findByPk(id);                   
                let result = Settings.update(pageObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['site_title', 'currency', 'address', 'postal_address', 'working_hours', 'helpline_no', 'helpline_email_address', 'logo', 'twitter_link', 'facebook_link', 'instagram_link', 'youtube_link', 'about_site', 'smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update settings ",
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Settings successfully updated.",
                    slug: '',
                    success: "Success",
                });
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/logo'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadLogo = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}