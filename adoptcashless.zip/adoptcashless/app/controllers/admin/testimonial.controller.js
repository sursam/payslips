const db = require('../../config/db.config.js');
const Testimonial = db.Testimonial;
const siteHelper = require('../../helpers/siteHelper.js');

exports.testimonial = (req, res) => {
    try{
        Testimonial.findAll({
            attributes: ['id', 'title', 'sub_title', 'name', 'slug', 'content', 'author_name', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'meta_og_url', 'order', 'status', 'created_at', 'updated_at', 'deleted_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.testimonialDetails = (req, res) => {
    let slug = req.params.slug;
    //console.log(slug);
    try{
        Testimonial.findOne({
            attributes: ['id', 'title', 'sub_title', 'name', 'slug', 'content', 'author_name', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'meta_og_url', 'order', 'status', 'created_at', 'updated_at', 'deleted_at'],  
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.saveTestimonial = async (req, res) => {    
    let testimonialObject = {
        title: req.body.title,
        sub_title: req.body.sub_title,
        name: req.body.name,
        content: req.body.content,
        author_name: req.body.author_name,
        author_designation: req.body.author_designation,
        meta_title: req.body.meta_title,
        meta_keywords: req.body.meta_keywords,
        meta_description: req.body.meta_description
    }
    try{
        let id = req.body.id;
        if(id){
            let page = Testimonial.findByPk(id);
            if(!page){
                res.status(404).json({
                    message: "Not Found for updating a page with id = " + id,
                    error: "404"
                });
            } else {                    
                let result = Testimonial.update(testimonialObject,
                    { 
                        returning: true, 
                        where: {id: id},
                        attributes: ['id', 'title', 'sub_title', 'name', 'content', 'author_name', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description']
                    }
                );
                if(!result) {
                    res.status(500).json({
                        message: "Error -> Can not update testimonial with id = " + id,
                        error: "Can NOT Updated",
                    });
                }    
                
                res.status(200).json({
                    message: "Testimonial successfully updated.",
                    slug: '',
                    success: "Success",
                });
            }
        }else{
            let params = { title: req.body.title, tableName: ' testimonials' };
            slug = await siteHelper.setSlug(params);
            testimonialObject['slug'] = slug;
            Testimonial.create(testimonialObject, 
                {attributes: ['id', 'title', 'sub_title', 'name', 'content', 'author_name', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description']})
            .then(result => {     
                res.status(200).json({
                    message: "Testimonial successfully added.",
                    slug: result.slug,
                    success: "Success",
                });
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}
exports.deleteTestimonial = async (req, res) => {   
    try{
        let id = req.body.id;
        if(id){
            let news = await Testimonial.findByPk(id);
            if(!news){
                res.status(404).json({
                    message: "Not Found for deleting a testimonial with id = " + id,
                    error: "404"
                });
            } else {                    
                const count = await Testimonial.destroy({ where: { id: id } });
                if(!count) {
                    res.status(500).json({
                        message: "Error -> Can not update a testimonial with id = " + id,
                        error: "Can NOT Updated",
                    });
                }else{
                    res.status(200).json({
                        message: "Testimonial successfully deleted.",
                        success: "Success",
                    });
                }
            }
        }else{
            res.status(404).json({
                message: "Testimonial not found",
                error: "404"
            });
        }
    }catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }
}