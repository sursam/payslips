const db = require('../../config/db.config.js');
const Associate = db.Associate;
const EndConsumer = db.EndConsumer;
const Card = db.Card;
const env = require('../../config/env.js');
const siteHelper = require('../../helpers/siteHelper.js');
const nodemailer = require("nodemailer");
const Settings = db.Settings;
const PaymentRecord = db.PaymentRecord;
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
//const moment = require('moment');

exports.registerIndivisualConsumer = (req, res) => {
    //let prepaidController = this;
    let fullName = `${req.body.first_name} ${req.body.last_name}`;
    let mobileNo = (req.body.mobile).replace(/\s/g,'');
    let email = req.body.email;
    /*let dateOfBirth = new Date(req.body.dob);
    let dob_date = ("0" + dateOfBirth.getDate()).slice(-2);
    let dob_month = ("0" + (dateOfBirth.getMonth() + 1)).slice(-2);
    let dob_year = dateOfBirth.getFullYear();
    let dob = dob_year + "-" + dob_month + "-" + dob_date;*/
    let dob = req.body.formattedBirthDate;
    let carReg = req.body.car_reg;
    let cardNumber = req.body.assigned_card;
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });

    conn.login(username, password, function(error) {
        if (!error) { 
            conn.query(`SELECT Id from RecordType WHERE SobjectType='End_Consumer__c' and Name='Individual Consumers'`, function(err, result) {
                if (!err) { 
                    let recordTypeId = result.records[0].Id;
                    console.log(recordTypeId)
                    let individualConsumerObject = {
                        RecordTypeId: recordTypeId,
                        Consumer_Name__c: fullName,
                        Email_1__c: email,
                        Mobile__c: mobileNo,
                        Credit_Type__c: 'Prepaid',
                        Recharge_Procedure__c: 'Manual'
                    };
                    Associate.count({
                        where: { mobile: mobileNo },
                    }).then(async assMobCount => {
                        if(assMobCount){
                            res.status(200).json({
                                message: "Mobile number already exists.",
                                error: true
                            });
                        }else{
                            Card.findOne({
                                attributes: ['salesforce_id', 'account_id', 'assignment_status'], 
                                where: {
                                    card_number: cardNumber, 
                                },
                            })
                            .then(async cardData => {
                                //console.log('Card Data', cardData);
                                if(!cardData){
                                    res.status(200).json({
                                        message: "You entered a wrong card number.",
                                        cardError: true,
                                        error: false
                                    });
                                }else if(cardData.assignment_status == 'assigned'){
                                    res.status(200).json({
                                        message: "The card number is already registered.",
                                        cardError: true,
                                        error: false
                                    });
                                }else{
                                    let cardSalesforceId = cardData.salesforce_id;
                                    individualConsumerObject.account_name__c = cardData.account_id;                                    
                                    //console.log(individualConsumerObject);
                                    conn.sobject("End_Consumer__c").create(individualConsumerObject, function(consumerErr, consumerRet) {
                                        console.log('End Consumer Error', consumerErr);
                                        if (consumerErr) { 
                                            res.status(200).json({
                                                status: 0,
                                                message:'Something wrong! Please try again later.',
                                                cardError: false,
                                                error: true
                                            }); 
                                        }else{
                                            let endConsumerId = consumerRet.id;
                                            let cardObject = {
                                                Status__c: 'Active',
                                                Assignment__c: 'Assigned',
                                                End_Consumer__c: endConsumerId
                                            }
                                            conn.sobject("RFID_Cards__c")
                                            .find({ 'Id' : cardSalesforceId })
                                            .update(cardObject, function(cardErr, cardRet) {   
                                                console.log('Card Error', cardErr);
                                                if(cardErr){
                                                    res.status(200).json({
                                                        message: "Something wrong! Please try again.",
                                                        cardError: false,
                                                        error: true
                                                    });
                                                }else{
                                                    let associateObject = {
                                                        End_Consumer__c: endConsumerId,
                                                        Name: fullName,
                                                        Mobile_Number__c: mobileNo,
                                                        Email__c: email,
                                                        Date_of_Birth__c: dob,
                                                        Vehicle_Rego__c: carReg,
                                                        RFID_Card__c: cardSalesforceId,
                                                        Status__c: 'Active'
                                                    }
                                                    //console.log(associateObject);
                                                    conn.sobject("Associates__c").create(associateObject, function(associateErr, associateRet) {
                                                        console.log('Associate Error', associateErr);
                                                        if (associateErr) { 
                                                            res.status(200).json({
                                                                message: "Something wrong! Please try again.",
                                                                cardError: false,
                                                                error: true
                                                            }); 
                                                        }else{
                                                            res.status(200).json({
                                                                message: "Registration Successful.",
                                                                cardError: false,
                                                                error: false,
                                                                associateId: associateRet.id,
                                                                endConsumerId: endConsumerId,
                                                            });                                            
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    });
                                }                                                
                            });
                        }
                    });
                }else{
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        cardError: false,
                        error: true
                    });
                }
            });
        }else{
            res.status(200).json({
                message: "Something wrong! Please try again.",
                cardError: false,
                error: true
            });
        }
    });

}

/*exports.registerAssociate = (req, res) => {
    let prepaidController = this;
    var mobile = (req.body.mobile).replace(/\s/g,'');
    var email = req.body.email;
    Associate.count({
        where: { mobile: mobile },
    }).then(async assMobCount => {
        if(assMobCount){
            res.status(200).json({
                message: "Mobile number already exists.",
                error: true
            });
        }else{
            Associate.count({
                where: { email: email },
            }).then(async assEmailCount => {
                if(assEmailCount){
                    res.status(200).json({
                        message: "Email already exists.",
                        error: true
                    });
                }else{
                    var dateOfBirth = siteHelper.formatDate(req.body.dob);
                    var cardSalesforceId = req.body.assigned_card;
                    var fullName = req.body.first_name + ' ' + req.body.last_name;
                    var status = '2';
                    let associateObject = {
                        Name: fullName,
                        Mobile_Number__c: mobile,
                        Email__c: email,
                        Date_of_Birth__c: dateOfBirth,
                        Vehicle_Rego__c: req.body.car_reg,
                        RFID_Card__c: cardSalesforceId,
                    }
                    let date_ob = new Date();
                    let date = ("0" + date_ob.getDate()).slice(-2);
                    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                    let year = date_ob.getFullYear();
                    let hours = date_ob.getHours();
                    let minutes = date_ob.getMinutes();
                    let seconds = date_ob.getSeconds(); 
                    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
                    let aCode = Math.random().toString(36).slice(2);
                    let assObject = {   
                        name: fullName,
                        first_name: req.body.first_name,
                        last_name: req.body.last_name,
                        mobile: mobile,
                        email: email,
                        date_of_birth: dateOfBirth,
                        gender:req.body.gender,
                        car_reg: req.body.car_reg,
                        card_id: cardSalesforceId,
                        updated_on: totalDate,
                        status: status,
                        activation_code: aCode,
                    }
                    //console.log(associateObject) 
                    try{                
                        var sf = require('node-salesforce');
                        let password = env.salesforce.password + env.salesforce.securityToken
                        var conn = new sf.Connection({
                            oauth2 : {
                                loginUrl : env.salesforce.loginUrl,
                                clientId : env.salesforce.clientId,
                                clientSecret : env.salesforce.clientSecret,
                                redirectUri : env.salesforce.redirectUri
                            }
                        });
                        conn.login(env.salesforce.username, password, function(err, userInfo) {
                            conn.sobject("Associates__c").create(associateObject, function(err, ret) {
                                if (err) { 
                                    console.error(err, ret);
                                    res.status(200).json({
                                        message: "Something wrong! Please try again.",
                                        error: true
                                    }); 
                                }else{
                                    assObject['salesforce_id'] = ret.id;
                                    assObject['created_on'] = totalDate;
                                    Associate.create(assObject, 
                                        {attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'card_id', 'created_on', 'updated_on', 'status']})
                                    .then(async result => {
                                        prepaidController.updateCardStatus(cardSalesforceId, '1', 'assigned');
                                        Settings.findOne({
                                            attributes: ['smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
                                            where: {
                                                id: 1, 
                                            },
                                        })
                                        .then(async data => {
                    
                                            let transporter = nodemailer.createTransport({
                                                host: data.smtphost,
                                                port: data.smtpport,
                                                auth: {
                                                    user: data.smtpuser,
                                                    pass: data.smtppassword
                                                },
                                            });
                                            const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
                                            const fullUrl = `${env.protocol}://${env.prepaidDomain}${port}`;
                                            let info = await transporter.sendMail({
                                                from: data.smtpfrommail,
                                                to: req.body.email,
                                                subject: "Email Verification URL",
                                                html: "<b>Hi "+fullName+",</b><br><p>Please <a href="+fullUrl+"/activate-account/"+aCode+">click here</a> to activate your account.</p><p><b>Thanks, <br>Tap N Go</b></p>",
                                            }); 
                    
                                        });
                                        res.status(200).json({
                                            message: "Registration Successful. Email verification url has been sent to your registered email address",
                                            error: false,
                                        });
                                    });                    
                                    console.log(ret);
                                }
                            });                
                        });
                    }
                    catch(error){        
                        res.status(200).json({
                            message: "Something wrong! Please try again.",
                            error: true
                        });
                    }
                }
            });
        }
    }); 

}*/


exports.updateCardStatus = (salesforceId, status, assignmentStatus = '') => {
    console.log(salesforceId+", "+status+", "+assignmentStatus)
    try{ 
        var sf = require('node-salesforce');
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(env.salesforce.username, password, function(err, userInfo) {
            let cardStatus = (status == '1') ? 'Active' : 'Not Active';
            let salesforceCardObj = {Status__c: cardStatus};
            if(assignmentStatus){
                salesforceCardObj['Assignment__c'] = (assignmentStatus == 'assigned') ? 'Assigned' : 'Available';
            }
            console.log(salesforceCardObj);
            conn.sobject("RFID_Cards__c")
            .find({ 'Id' : salesforceId })
            .update(salesforceCardObj, function(err, ret) {                    
                //console.log(err);
                //console.log(ret);
                if (!err) { 
                    return true;
                }
            });
        });
    }catch(error) {
        console.log(error);
        return false;
    }
}

exports.getAvailableCorporateCards = (req, res) => {
    try{     
        Card.findAll({
            attributes: ['id', 'salesforce_id', 'card_number', 'card_type', 'expiration_date', 'status', 'updated_on', 'created_on'], 
            where: {
                status: '0',
                assignment_status: 'available',
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.verifyAssociateEmail = async (req, res) => {   
    const activationCode = req.body.activationCode;
    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
    const fullUrl = `${env.protocol}://${env.prepaidDomain}${port}`+"/auth";
    try{
        if(activationCode){    
            Associate.findOne({
                attributes: ['activation_code'], 
                where: {
                    activation_code: activationCode, 
                },
            }).then(data => {    
                if(data)
                {
                    let associateObject = {
                        activation_code: null,
                        status: '1',
                    }
                    Associate.update(associateObject,
                        { 
                            returning: true, 
                            where: {activation_code: activationCode},
                            attributes: ['activation_code', 'status']
                        }                        
                    );
                    res.status(200).json({
                        status: 1,
                        message:'Email successfully verified',
                        req : fullUrl
                    }); 
                }
                else
                {
                    res.status(200).json({
                        status: 0,
                        message:'Activation code is not valid.',
                        req : ''
                    }); 
                }    
            });    
        }else{
            res.status(200).json({
                status: 0,
                error: 'Activation code is not found.',
                req : ''
            });
        }   
    } catch(error){
        res.status(200).json({
            status: 0,
            error: 'Activation code is not found.',
            req : ''
        });
    }     

}

exports.loginAssociate = async (req, res) => {   
    let corporateCard = req.body.corporateCard;
    let mobileNumber = req.body.mobileNumber;
    var dateOfBirth = req.body.formattedDob;
    //let serverTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    //console.log(serverTimezone);
    //var dateOfBirth = moment(new Date(req.body.dateOfBirth)).tz(serverTimezone).format("YYYY-MM-DD");
    //let dateOfBirth = new Date(req.body.dateOfBirth).toDateString();

    //var dateOfBirth = moment(new Date(req.body.dateOfBirth)).format("YYYY-MM-DD");
    
    //console.log(dateOfBirth);

    try{    
        if(corporateCard == "")
        {
            res.status(200).json({
                message: "Corporate card is required",
                cardError: false,
                error: true
            });  
        }
        else if(mobileNumber == "")
        {
            res.status(200).json({
                message: "Mobile number is required",
                cardError: false,
                error: true
            }); 
        }
        else if(dateOfBirth == "")
        {
            res.status(200).json({
                message: "Date of birth is required",
                cardError: false,
                error: true
            }); 
        }
        else
        {
            Card.findOne({
                attributes: ['salesforce_id'], 
                where: {
                    card_number: corporateCard, 
                },
            })
            .then(async data => {
                if(data){
                    Associate.belongsTo(EndConsumer, {targetKey:'salesforce_id', foreignKey: 'end_consumer_id'});
                    Associate.findOne({
                        where: {
                            //card_id: '', 
                            card_id: data.salesforce_id,
                            mobile: mobileNumber.replace(/\s/g,''),
                            date_of_birth: dateOfBirth,
                            //date_of_birth: siteHelper.formatDate(dateOfBirth),
                        },
                        include:[{
                            model: EndConsumer,
                            attributes: ['account_type'],
                            required: true                  
                        }]
                    }).then(user => {
                        //console.log(user)
                        if(user){
                            if(user.end_consumer.account_type == 'Individual_Consumers'){
                                if(user.status == 2){
                                    res.status(200).json({
                                        message: "User account is not active",
                                        cardError: false,
                                        error: true
                                    });
                                }else{
                                    res.status(200).json({
                                        cardError: false,
                                        error: false,
                                        userId: user.id,
                                        associateId: user.salesforce_id,
                                        endConsumerId: user.end_consumer_id,
                                        message: 'Successfully logged in'
                                    });
                                }
                            }else{
                                res.status(200).json({
                                    message: "Access denied!",
                                    cardError: false,
                                    error: true
                                });
                            }                                
                        }else{
                            res.status(200).json({
                                message: "Wrong credentials",
                                cardError: false,
                                error: true
                            });
                        }
                    });
                }else{
                    res.status(200).json({
                        status: 0,
                        message: "Card number is not valid",
                        cardError: true,
                        error: true
                    });
                }
            });
        } 
    }catch(error){
        res.status(200).json({
            status: 0,
            message: error.message,
            error: 1
        });
    }
}

const { Template } = require("@walletpass/pass-js");
const { AutoTopup } = require('../../config/db.config.js');
exports.appleWalletPass = async (req, res) => {
    const template = await Template.load(
        "./public/Card.pass",
        "secretKeyPasswod"
    );
    /*const template = new Template("coupon", {
        passTypeIdentifier: "pass.com.tapngo.passbook",
        teamIdentifier: "MXL",
        backgroundColor: "red",
        sharingProhibited: true
    });*/
    await template.loadCertificate(
        "/etc/passbook/certificate_and_key.pem",
        "secret"
    );
    const pass = template.createPass({
        organizationName: "Eclick Softwares",
        serialNumber: "123456",
        description: "20% off"
    });
    //await pass.images.add("icon", "./public/Card.pass/icon.png", "1x", "ru");
    //await pass.images.add("logo", "./public/Card.pass/logo.png", "1x", "ru");
    const buf = await pass.asBuffer();
    await fs.writeFile("./public/uploads/passes/testPass.pass", buf);
}

exports.updateAssociateData = async (req, res) => {
    let prepaidController = this;
    var dateOfBirth = siteHelper.formatDate(req.body.dob);
    var associateId = req.body.associateId;
    var firstName = req.body.first_name;
    var lastName = req.body.last_name;
    var mobile = req.body.mobile;
    var email = req.body.email;
    var carReg = req.body.car_reg;
    var cardNumber = req.body.assigned_card;
    try{  
        Card.findOne({
            attributes: ['salesforce_id'], 
            where: {
                card_number: cardNumber, 
            },
        })
        .then(data => {
            //console.log(data.salesforce_id)
            if(cardNumber && !data){
                res.status(200).json({
                    message: "You entered a wrong card number.",
                    cardError: true,
                    error: false
                });
            }
            var cardSalesforceId = data ? data.salesforce_id : '';
            let associateObject = {
                Name: firstName + ' ' +lastName,
                Mobile_Number__c: (mobile).replace(/\s/g,''),
                Email__c: email,
                Date_of_Birth__c: dateOfBirth,
                Vehicle_Rego__c: carReg,
                RFID_Card__c: cardSalesforceId,
            }
            var sf = require('node-salesforce');
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(env.salesforce.username, password, function(err, userInfo) {
                Associate.findOne({ where: { email: email,}, }).then(associate => {
                    if(associate && associate.salesforce_id != associateId)
                    {
                        res.status(200).json({
                            message: "Email already exists.",
                            cardError: false,
                            error: true
                        });
                    }else{
                        conn.sobject("Associates__c")
                        .find({ 'Id' : associateId })
                        .update(associateObject, function(err, ret) {
                            //console.error(err, ret);
                            if (!err) {
                                if(associate.card_id != cardSalesforceId){
                                    prepaidController.updateCardStatus(associate.card_id, '0', 'available');
                                    prepaidController.updateCardStatus(cardSalesforceId, '1', 'assigned');
                                }
                                res.status(200).json({
                                    message: "Associate successfully updated.",
                                    cardError: false,
                                    error: false,
                                });
                            }else{ 
                                res.status(200).json({
                                    message: "Something wrong! Please try again.",
                                    cardError: false,
                                    error: true
                                });
                            }
                        });
                    }
                }); 
            });
        });
    }
    catch(error){
        console.error('Error', error);        
        res.status(200).json({
            message: "Something wrong! Please try again.",
            cardError: false,
            error: true
        });
    }
}
exports.getCardByNumber = (req, res) => {
    const cardNumber = req.params.num;
    try{ 
        Card.findOne({
            attributes: ['id', 'unique_id', 'salesforce_id', 'card_number', 'card_id', 'card_type', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'], 
            where: {
                card_number: cardNumber, 
            },
        })
        .then(data => {
            console.log(data)
            res.status(500).json(data);
        });
    }catch(error) {
        console.log(error);
        res.status(500).json({
            error: 1
        });
    }
}
const getPagination = (page, size) => {
    const limit = + size;
    const offset = (page==1) ? 0 : (page-1) * limit;
  
    return { limit, offset };
};
exports.getAssociateTransactions = async (req, res) => { 
    const associateId = req.params.aid; 
    console.log(associateId)
    const page = parseInt(req.query.page); 
    const size = parseInt(req.query.size);
    const { limit, offset } = getPagination(page, size);
    var searchText = req.query.s ? req.query.s : '';
    try{
        if(associateId){

            let whereClause = {
                associate_id: {[Op.eq]: `${associateId}`},
            }
            if(searchText != ''){
                var manualPattern = new RegExp('(\\w*manual\\w*)','gi');
                var autoPattern = new RegExp('(\\w*auto\\w*)','gi');
                if(searchText.match(manualPattern) !== null){
                    searchText = 'manual';
                }else if(searchText.match(autoPattern) !== null){                    
                    searchText = 'auto';
                }
                whereClause = {
                    [Op.or]: [
                        { 
                            total_amount: {[Op.like]: `%${searchText}%`},
                        },
                        { 
                            recharge_procedure: {[Op.like]: `%${searchText}%`},
                        },
                        { 
                            created_on: {[Op.like]: `%${siteHelper.formatToDate(tryParseDateFromString(searchText, 'dmy'))}%`},
                        }
                    ],
                    [Op.and]: [
                        {
                            associate_id: {[Op.eq]: `${associateId}`},
                        }
                    ]
                }
            }
            //console.log(siteHelper.formatToDate(tryParseDateFromString(searchText, 'dmy')));
            PaymentRecord.findAndCountAll({
                attributes: ['id', 'salesforce_id', 'name', 'associate_id', 'account', 'net_amount', 'total_amount', 'stripe_fees', 'tng_commission', 'tax_invoice', 'recharge_procedure', 'updated_on', 'created_on'], 
                where: whereClause,
                limit, 
                offset,
                order: [
                    ['id', 'DESC'],
                ],
            }).then(data => {
                //console.log(data)
                const response = getPagingTxnData(data, page, limit);
                res.status(200).json(response);               
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
const getPagingTxnData = (data, page, limit) => {
    const { count: totalItems, rows: Transactions } = data;
  
    const currentPage = page ? + page : 0;
    const totalPages = Math.ceil(totalItems / limit);
  
    return {totalItems, Transactions, totalPages, currentPage };
};
exports.doAssociateAutotopup = async (req, res) => { 
    try{
        let whereClause = {
            end_consumer_id: null,
            status: "1" 
        };
        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });       
        Associate.findAll({
            attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'end_consumer_id', 'status', 'card_id', 'updated_on', 'created_on'], 
            where: whereClause,
            include:[{
                model: Card,
                attributes: ['id', 'salesforce_id', 'card_number', 'card_id', 'card_type', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'],
                required: false                  
            }]
        })
        .then(associates => {
            //res.status(200).json(associates);
            associates.forEach(associate => {
                if(associate.card !== null && associate.card.auto_topup == '1'){
                    res.status(200).json(associate.card);
                }
            });
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.doPrepaidStripeRecharge = async (req, res) => {
    const paymentMethod  = req.body.paymentMethod;
    const endConsumerId  = req.body.endConsumerId;
    const associateId  = req.body.associateId;
    const rfidCardId  = req.body.rfidCardId;
    const grandTotal  = req.body.grandTotal;
    const grandTotalInternational  = req.body.grandTotalInternational;
    const stripeCustomerId  = req.body.stripeCustomerId;
    const applicationFee  = req.body.applicationFee;
    const stripeFee  = req.body.stripeFee;
    const stripeFeeInternational  = req.body.stripeFeeInternational;
    const connectedAccount  = req.body.connectedAccount;
    const rechargeVal  = req.body.rechargeVal;
    const rechargeProcedure  = req.body.rechargeProcedure;
    const projectedTotalVal  = req.body.projectedTotalVal;
    const extraCredit = req.body.extraCredit;
    const previousBalance = req.body.currentBalance;
    
    try{ 
        const stripe = require('stripe')(env.stripeCreds.secretKey);
        const paymentMethodObj = await stripe.paymentMethods.retrieve(
            paymentMethod
        );
        //console.log(paymentMethodObj);
        if(paymentMethodObj.id){
            const grandTotalVal  = (typeof paymentMethodObj.card !== 'undefined' && paymentMethodObj.card.country != 'AU') ? grandTotalInternational : grandTotal;
            const stripeFeeVal  = (typeof paymentMethodObj.card !== 'undefined' && paymentMethodObj.card.country != 'AU') ? stripeFeeInternational : stripeFee;
            const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
            const returnUrl = `${env.protocol}://${env.prepaidDomain}${port}`+"/checkout";
            const paymentIntent = await stripe.paymentIntents.create({
                //payment_method_types: ['card', 'au_becs_debit', 'sepa_debit'],
                payment_method: paymentMethodObj.id,
                customer: stripeCustomerId, 
                amount: Math.round(grandTotalVal * 100),
                currency: env.stripeCreds.currency,
                automatic_payment_methods: {enabled: true},
                return_url: returnUrl,
                confirm: true,
                application_fee_amount: Math.round(applicationFee * 100),
                transfer_data: {
                    //amount: Math.round(rechargeVal * 100),
                    destination: connectedAccount,
                },
            });
            
            if(paymentIntent.id){
                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                });
                conn.login(username, password, function(err) {
                    if (err) { 
                        res.status(200).json({
                            status: 0,
                            message:'Something wrong! Please try again later.',
                            error: 1
                        }); 
                    }
                    conn.sobject("End_Consumer__c")
                    .select('*')
                    .where({
                        Id: endConsumerId,
                    })
                    .execute(function(err, records) {
                        if(records.length){
                            let paymentObject = {
                                Name: 'Recharge - $'+parseFloat(rechargeVal).toFixed(2)+' - '+records[0].Name,
                                End_Consumer__c: endConsumerId,
                                Date__c: new Date(),
                                Net_Amount__c: parseFloat(rechargeVal).toFixed(2),
                                Stripe_Fees__c: parseFloat(stripeFeeVal).toFixed(2),
                                TNG_Commission__c: parseFloat(applicationFee).toFixed(2),
                                Recharge_Val__c: parseFloat(grandTotalVal).toFixed(2),
                                Recharge_Procedure__c: rechargeProcedure,
                                Extra_Credit__c: parseFloat(extraCredit).toFixed(2),
                                Previous_Balance__c: parseFloat(previousBalance).toFixed(2),
                            }
                            conn.sobject("Payment_Record__c").create(paymentObject, function(recordErr, recordRet) {
                                console.log(recordErr, recordRet);
                                if (!recordErr) { 
                                    let cardObject = {
                                        PrePaid_Credit__c: projectedTotalVal,
                                    }
                                    conn.sobject("RFID_Cards__c").find({ 'Id' :rfidCardId }).update(cardObject, function(cardErr, cardRet) {
                                        console.log(cardErr, cardRet);
                                        let endConsumerObject = {
                                            //UnAssigned_Credit__c: projectedTotalVal,
                                            Recharge_Procedure__c: rechargeProcedure,
                                        }
                                        conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                            console.log(err, ret);
                                            res.status(200).json({
                                                message: "Recharge successfully done.",
                                                //charge: paymentIntent,
                                                recordId: recordRet.id,
                                                error: 0
                                            });
                                        });
                                    });
                                     
                                }else{
                                    console.log('Error', recordErr);
                                    res.status(200).json({
                                        message: "Something wrong! Please try again.",
                                        error: 1
                                    });
                                } 
                            });
                                                                
                        }                                    
                    });
                    
                });            
                
            }
        }
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    

}

exports.testQuery = async (req, res) => { 
    const id = req.params.id; 
    Card.belongsTo(EndConsumer, {targetKey:'salesforce_id', foreignKey: 'end_consumer_id'});
    Card.findOne({
        attributes: ['id'], 
        where: {
            salesforce_id: id, 
        },
        include:[{
            model: EndConsumer,
            attributes: ['salesforce_id', 'is_auto_topup'],
            required: false                  
        }]
    })
    .then(async data => {
        /*res.status(200).json({
            res: data
        });*/
        AutoTopup.findOne({
            attributes: ['source_id','source_type','auto_recharge_amount','auto_trigger_point','extra_credit_val'], 
            where: {
                endconsumer_id: data.end_consumer.salesforce_id, 
            }
        })
        .then(async result => {
            res.status(200).json({
                res: result
            });
        });
    });
}