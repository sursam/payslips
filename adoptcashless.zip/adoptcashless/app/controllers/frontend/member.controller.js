const db = require('../../config/db.config.js');
const Settings = db.Settings;
const EndConsumer = db.EndConsumer;
const AutoTopup = db.AutoTopup;
const Associate = db.Associate;
const nodemailer = require("nodemailer");
const env = require('../../config/env.js');
const siteHelper = require('../../helpers/siteHelper.js');
const Card = db.Card;
const SupportCase = db.SupportCase;
const chatHistory = db.chatHistory;
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
//const Contact = db.Enquiry;
const PaymentRecord = db.PaymentRecord;
const PaymentSource = db.PaymentSource;
const CardTransaction = db.CardTransaction;
const CompanyInfo = db.CompanyInfo;
var multer = require('multer');
const path = require('path');

exports.checkMemberEmail = async (req, res) => { 
    const email = req.body.email;
    EndConsumer.findAll({
        attributes: ['id'], 
        where: {
            email: email, 
        },
    }).then(data => {
        res.status(200).json(data);
    })
}

exports.verificationEmailCode = async (req, res) => { 
   
    const verificationcode = req.body.verificationcode;
    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
    const fullUrl = `${env.protocol}://${env.memberDomain}${port}`+"/login";

    try{
        if(verificationcode){
    
            EndConsumer.findOne({
                attributes: ['activation_code'], 
                where: {
                    activation_code: verificationcode, 
                },
            }).then(data => {
    
                if(data)
                {
                    res.status(200).json({
                        status: 1,
                        message:'Email Verified successfully',
                        req : ''
                    }); 
                }
                else
                {
                    res.status(200).json({
                        status: 0,
                        message:'Activation code is not valid.',
                        req : fullUrl
                    }); 
                }
    
            });    
        }   
     }
        catch(error){
        res.status(200).json({
            status: 0,
            error: 'Activation code not found.',
            req : ''
        });
    }     

}

exports.getEndConsumerReference = async (req, res) => { 
    const endConsumerNumber = req.body.endConsumerNumber;

    try{
        if(endConsumerNumber){
        EndConsumer.findOne({
            attributes: ['salesforce_id'], 
            where: {
                salesforce_id: endConsumerNumber, 
            },
        }).then(data => {
            
            if(data)
            {
                res.status(200).json({
                    status: 0,
                    message:'End consumer already exist.',
                    error: ''
                }); 
            }
            else
            {
                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                });
                conn.login(username, password, function(err, userInfo) {
                    if (err) { 
                        res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                    conn.sobject("End_Consumer__c")
                    .select('*')
                    .where({ Id:endConsumerNumber})
                    .execute(function(err) {

                        if (err) 
                        {
                            res.status(200).json({
                                status: 0,
                                message:'End Consumer Reference Number is not valid',
                                error: err
                            }); 
                        }
                        else
                        {
                            res.status(200).json({
                                status: 1,
                                message:''
                            }); 
                        }
                        
                    });
                });  
            } 
        });    
      }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}

exports.registrationData = async (req, res) => {   

    let aCode = Math.random().toString(36).slice(2);

    let dob_ob_date = new Date(req.body.dateofbirth);
    let dob_date = ("0" + dob_ob_date.getDate()).slice(-2);
    let dob_month = ("0" + (dob_ob_date.getMonth() + 1)).slice(-2);
    let dob_year = dob_ob_date.getFullYear();
    let dob_totalDate = dob_year + "-" + dob_month + "-" + dob_date;

    let full_name = req.body.firstName+' '+req.body.lastName;  
    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
    const fullUrl = `${env.protocol}://${env.memberDomain}${port}`;         

    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    

    let signupObject = {
        salesforce_id: req.body.referenceNumber,
        name: full_name,  
        first_name: req.body.firstName,  
        last_name: req.body.lastName,
        mobile: (req.body.mobile).replace(/\s/g,''),
        email: req.body.email,
        date_of_birth: dob_totalDate,
        account_type:req.body.accountType,
        business_name: req.body.businessName,
        abn: req.body.abn,
        company_name: req.body.companyName,
        licence_serial_number: req.body.licenceSerialNumber,
        activation_code: aCode,
        update_on: totalDate,
        created_on: totalDate
        }

        let signupSalesForceObject = {
            User_Name__c: req.body.email,
            Company_Name__c: req.body.companyName,
            Business_Name__c: req.body.businessName,
            ABN__c: req.body.abn,
            Email_1__c: req.body.email,
            Mobile__c: (req.body.mobile).replace(/\s/g,''),
            ABN__c: req.body.abn,
        }    

        let associateSalesForceObject = {
            Name: full_name,
            Mobile_Number__c: (req.body.mobile).replace(/\s/g,''),
            Email__c: req.body.email,
            Date_of_Birth__c: dob_totalDate,
            End_Consumer__c: req.body.referenceNumber,
        }

        let associatesObject = {
            name: full_name,  
            first_name: req.body.firstName,  
            last_name: req.body.lastName,
            mobile: (req.body.mobile).replace(/\s/g,''),
            email: req.body.email,
            date_of_birth: dob_totalDate,
            end_consumer_id: req.body.referenceNumber,
            update_on: totalDate,
            created_on: totalDate
            }    

    try{
        EndConsumer.findOne({ where: { email: req.body.email,}, }).then(member => {
            if(member)
            {
                res.status(200).json({
                    message: "Email already exist.",
                    error: "404"
                });
            }
            else
            {
                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                });

                conn.login(username, password, function(err, userInfo) {
                    if (err) { 
                        res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }

                    conn.sobject("End_Consumer__c")
                    .select('*')
                    .where({ Id:req.body.referenceNumber})
                    .execute(function(err) {

                        if (err) { 
                            res.status(200).json({
                                message: "Something wrong! Please try again.",
                                error: err
                            }); 
                        }

                        conn.sobject("End_Consumer__c").find({ 'Id' :req.body.referenceNumber }).update(signupSalesForceObject, function(err, ret) {
                            if (err) { 
                                res.status(200).json({
                                    message: "Something wrong! Please try again.",
                                    error: err
                                }); 
                            }
                        });
                    });  

                conn.sobject("Associates__c")
                    .select('*')
                    .where({ Email__c:req.body.email})
                    .execute(function(err, records) {

                        if (err) { 
                            res.status(200).json({
                                message: "Something wrong! Please try again.",
                                error: err
                            }); 
                        }

                        if(records.length === 0)
                        {
                            conn.sobject("Associates__c").create(associateSalesForceObject, function(err, res) {

                                if (err) { 
                                    res.status(200).json({
                                        message: "Something wrong! Please try again.",
                                        error: err
                                    }); 
                                }
                                
                                associatesObject['salesforce_id'] = res.id;  

                                Associate.create(associatesObject, 
                                    {attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'end_consumer_id']});
                            });    
                        }
                        else
                        {
                             conn.sobject("Associates__c").find({ 'Id' :records[0].Id }).update(associateSalesForceObject, function(err, ret) {
                                if (err) { 
                                    res.status(200).json({
                                        message: "Something wrong! Please try again.",
                                        error: err
                                    }); 
                                }

                                Associate.create(associatesObject, 
                                    {attributes: ['name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'end_consumer_id']});
                            });
                        }
                    }); 


                EndConsumer.create(signupObject, 
                    {attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'account_type', 'business_name', 'abn', 'company_name', 'licence_serial_number', 'activation_code', 'created_on']})
                .then(async result => {
                    if(err){ console.log(err); return false;}

                    Settings.findOne({
                        attributes: ['smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
                        where: {
                            id: 1, 
                        },
                    })
                    .then(async data => {

                        let transporter = nodemailer.createTransport({
                            host: data.smtphost,
                            port: data.smtpport,
                            auth: {
                                user: data.smtpuser,
                                pass: data.smtppassword
                            },
                        });
                        let info = await transporter.sendMail({
                            from: data.smtpfrommail,
                            to: req.body.email,
                            subject: "Email Verification URL",
                            html: "<b>Hi "+full_name+",</b><br><p>Please <a href="+fullUrl+"/set-password?data="+aCode+">click here</a> to verify your email.</p><p><b>Thanks, <br>Tap N Go</b></p>",
                        }); 

                    });    

                    res.status(200).json({
                        message: "Member registration successfull. Email verification url has been sent to your registered email address.",
                        status: 1,
                        code: aCode,
                        success: "Success",
                    });

                });

                });  
            }
        });      
    }
    catch(error){
        res.status(500).json({
            message: "Something wrong! Please try again.",
            status: 2,
            error: error.message
        });
    }
} 

exports.validateOtp = async (req, res) => { 
    let code = req.body.code;
    let otpcode = req.body.otpcode;

    let genCode = Math.random().toString(36).slice(2);

    const bcrypt = require('bcryptjs')

    const salt = await bcrypt.genSalt(10);
    let password = await bcrypt.hash(genCode, salt); 

    let otpObject = {
        activation_code: '0',
        otp: '0',
        status: '1',
        password : password,
    }    

    try{
        EndConsumer.findOne({
                where: {
                    activation_code: code, 
                },
            }).then(async member => {
                if(member)
                {
                    if(otpcode == member.otp)
                    {    
                        Settings.findOne({
                            attributes: ['smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
                            where: {
                                id: 1, 
                            },
                        })
                        .then(async data => {
                            let result = EndConsumer.update(otpObject,
                                { 
                                    returning: true, 
                                    where: {activation_code: code},
                                    attributes: ['activation_code', 'otp', 'status']
                                }
                                
                            );
                            res.status(200).json({
                                message: "User validated successfully.",
                                status: 1,
                                success: "Success",
                            });
                            let transporter = nodemailer.createTransport({
                                host: data.smtphost,
                                port: data.smtpport,
                                auth: {
                                    user: data.smtpuser,
                                    pass: data.smtppassword
                                },
                            });
                            let info = await transporter.sendMail({
                                from: data.smtpfrommail,
                                to: member.email,
                                subject: "Login Credentials",
                                html: "<b>Hi "+member.first_name+" "+member.last_name+",</b><br><p>Please check your login credentials</p><p>User ID : <b>"+member.email+"</b></p><p>Password : <b>"+genCode+"</b></p><p><b>Thanks, <br>Tap N Go</b></p>",
                            }); 
                        });
                    }
                    else
                    {
                        res.status(200).json({
                            message: "OTP does not matched.",
                            status: 0,
                            error: "500",
                        });
                    }

                }else{
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        status: 0,
                        error: "404"
                    });
                }
            }).catch(error => {
                console.log(error);
                res.status(500).json({
                    status: 0,
                    error: error
                });
            })  
                
            }
        catch(error){
        res.status(500).json({
            message: "Fail!",
            error: error.message
        });
    }

}

exports.memberLogin = async (req, res) => { 
    let memberUserName = req.body.username;
    let memberPassword = req.body.password;

    const bcrypt = require('bcryptjs')
    
    try{
        
        if(memberUserName == "")
        {
            res.status(200).json({
                message: "Username is required ",
                status: 0,
                error: err
            });  
        }
        else if(memberPassword == "")
        {
            res.status(200).json({
                message: "Password is required ",
                status: 0,
                error: err
            }); 
        }
        else
        {
            EndConsumer.findOne({
                where: {
                    email: memberUserName, password: memberPassword
                },
            }).then(user => {
                //console.log(user)
                if(user){
                    if(user.status == 2){
                        res.status(200).json({
                            status: 0,
                            message: "Member account is not active."
                        });
                    }else{
                        res.status(200).json({
                            status: 1,
                            userId: user.id,
                            salesforce_id: user.salesforce_id,
                            message: 'Successfully logged in.'
                        });
                    }    
                }else{
                    res.status(200).json({
                        status: 0,
                        message: "Wrong credentials."
                    });
                }

            });
        }    
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }

}


exports.memberForgotPassword = async (req, res) => { 

    let email = req.body.email;
    let mobile = req.body.mobile.replace(/\s/g,'');

    let date_ob = new Date(req.body.dateofbirth);
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let totalDate = year + "-" + month + "-" + date;
    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
    const fullUrl = `${env.protocol}://${env.memberDomain}${port}`;

    let aCode = Math.random().toString(36).slice(2);

    let updatedObject = {
        activation_code: aCode,
    }

    try{

        if(email == "")
        {
            res.status(200).json({
                message: "Email address is required ",
                status: 0,
                error: err
            });  
        }
        else if(mobile == "")
        {
            res.status(200).json({
                message: "Mobile number is required ",
                status: 0,
                error: err
            }); 
        }
        else if(totalDate == "")
        {
            res.status(200).json({
                message: "Date of birth is required ",
                status: 0,
                error: err
            }); 
        }
        else
        {
            try{
                Settings.findOne({
                    attributes: ['smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
                    where: {
                        id: 1, 
                    },
                })
                .then(data => {

                let transporter = nodemailer.createTransport({
                    host: data.smtphost,
                    port: data.smtpport,
                    auth: {
                    user: data.smtpuser,
                    pass: data.smtppassword
                    },
                }); 

                try{
                        EndConsumer.findOne({
                            where: {
                                email: email, mobile:mobile, date_of_birth: totalDate
                            },
                        }).then(user => {

                            if(user)
                            {
                                let info = transporter.sendMail({
                                    from: data.smtpfrommail,
                                    to: email,
                                    subject: "Reset Password",
                                    html: "<b>Hi ,</b><br><p>Please <a href="+fullUrl+"/reset-password?data="+aCode+">click here</a> to reset the password.</p><br><p>Thank You</p><p><b>Tap N Go</b></p>",
                                });

                                let result = EndConsumer.update(updatedObject,
                                    { 
                                      returning: true, 
                                      where: {email: email}
                                    }
                                  );

                                res.status(200).json({
                                    message: "Reset password url send to your registered email",
                                    status: 1
                                });
                                
                            }
                            else
                            {
                                res.status(200).json({
                                    message: "User not found",
                                    status: 0,
                                });
                            }
                        });  
                }
                catch(error){
                    res.status(200).json({
                        message: "Something wrong! Please try again2.",
                        error: error.message
                    });
                }
                
            });

        }catch(error){
                res.status(200).json({
                    message: "Something wrong! Please try again.",
                    error: error.message
                });
            }
        }
              
    }catch(error){
        res.status(200).json({
            status: 0,
            message: error.message
        });
    }

}

exports.memberResetPassword = async (req, res) => {
    
    const bcrypt = require('bcryptjs');

    const salt = await bcrypt.genSalt(10);
    let password = await bcrypt.hash(req.body.password, salt); 

    let aCode = req.body.code;

    let updatedObject = {
        password:password,
        status:1,
        activation_code:'',
    }

    try{
        EndConsumer.findOne({
            attributes: ['salesforce_id','email'], 
            where: {
                activation_code: aCode, 
            },
        }).then(data => {
            if(data){

                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                }); 

                conn.login(username, password, function(err, userInfo) {
                    if (err) { 
                            res.status(200).json({
                            status: 0,
                            message:'Something wrong! Please try again later.',
                            error: err
                        }); 
                    }

                    conn.sobject("End_Consumer__c").update([
                    {Id:data.dataValues.salesforce_id,Password__c:req.body.password},
                    ],
                    function(err,rets){
                        if(err){ console.log(err); return false;}
                    });

                let result = EndConsumer.update(updatedObject,
                    { 
                      returning: true, 
                      where: {activation_code: aCode},
                      attributes: ['password', 'activation_code']
                    }
                  );

                res.status(200).json({
                    status: '1',
                    message: "Password changed successfully"
                });
            });

            }else{
                res.status(200).json({
                    status: 0,
                    message: "Password reset url does not exit"
                });
            }
        }).catch(error => {
            //console.log(error);
            res.status(200).json({
                    status: 0,
                    message: "Something wrong! Please try again."
                });
        })        
    }catch(error){
       res.status(200).json({
                    status: 0,
                    message: "Activation code not found."
                });
    }
    
}

exports.searchAssociates = (req, res) => {
    const search = req.body.search;
    const endConsumerId = req.body.endConsumerId;
    
    try{
        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });
        Associate.findAll({
            attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'end_consumer_id', 'status', 'updated_on', 'created_on'], 
            where: {
                [Op.or]: [
                    { 
                        name: {[Op.like]: `%${search}%`},
                    },
                    { 
                        mobile: {[Op.eq]: `${search}`},
                    },
                    {
                        '$card.card_number$': {[Op.eq]: `${search}`},
                    }
                ],
                [Op.and]: [
                    {
                        end_consumer_id: {[Op.eq]: `${endConsumerId}`},
                    }
                ]
            },
            include:[{
                model: Card,
                attributes: ['id', 'salesforce_id', 'card_id', 'card_number', 'card_type'],
                required: false                  
            }]
        }).then(data => {
            res.status(200).json(data);               
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Associates not found.'
        });
    } 
}

exports.getSalesforceAssociates = (req, res) => {
    const endConsumerId  = req.params.id;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                // you can change loginUrl to connect to sandbox or prerelease env.
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }
            conn.query(`SELECT Id, Title__c, Name, Mobile_Number__c, Country_Dialing_Code__c,Email__c, Note__c,Date_of_Birth__c,Portal_Access__c, OwnerId, CreatedDate, LastModifiedDate, LastViewedDate, Employee_User_Identity__c, Vehicle_Type__c,Vehicle_Rego__c, Reg_State__c, Associate_To__c, Designation__c, Last_Updated__c, End_Consumer__c, RFID_Card__r.name, RFID_Card__r.Display_Card_Number__c, RFID_Card__r.Card_Id__c, RFID_Card__r.PrePaid_Credit__c, RFID_Card__r.Updated_DT__c, RFID_Card__r.Status__c, RFID_Card__r.Card_Expiration_Date__c FROM Associates__c where end_consumer__r.id='${endConsumerId}'`, function(err, result) {
                if (err) { console.error(err, ret).error(err); }
                //console.log("fetched : " + result.records.length); (SELECT Card_ID__c FROM RFID_Cards__r)
                res.status(200).json(result);
            });            

            /*conn.sobject("Associates__c")
            .select('*')
            .where({IsDeleted: false})
            //.limit(10)
            //.offset(20) 
            .execute(function(err, records) {
                res.status(200).json(records);
            });*/
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
const getPagination = (page, size) => {
    const limit = + size;
    const offset = (page==1) ? 0 : (page-1) * limit;
  
    return { limit, offset };
};
  
/*const getPagingData = (data, page, limit) => {
    const { count: totalItems, rows: Items } = data;

    const currentPage = page ? + page : 0;
    const totalPages = Math.ceil(totalItems / limit);

    return {totalItems, Items, totalPages, currentPage };
};
exports.getAssociates = (req, res) => {
    const endConsumerId  = req.params.econ;
    const { page, size, status } = req.query;
    console.log(page +"--"+ size +"--"+ status);
    const { limit, offset } = getPagination(page, size);
    try{
        let whereClause = {
            end_consumer_id: endConsumerId, 
        };
        if(status){
            whereClause.status = (status == "active") ? "1" : "0"; 
        }
        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });       
        Associate.findAndCountAll({
            attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'end_consumer_id', 'status', 'updated_on', 'created_on'], 
            where: whereClause,
            limit, offset,
            include:[{
                model: Card,
                attributes: ['id', 'salesforce_id', 'card_id', 'card_number', 'card_type'],
                required: false                  
            }]
        })
        .then(data => {
            const response = getPagingData(data, page, limit);
            console.log(response);
            res.status(200).json(response);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}*/
exports.getAssociates = (req, res) => {
    const endConsumerId  = req.params.econ;
    const status = req.query.status;
    try{
        let whereClause = {
            end_consumer_id: endConsumerId, 
        };
        if(status){
            whereClause.status = (status == "active") ? "1" : "0"; 
        }
        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });       
        Associate.findAll({
            attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'end_consumer_id', 'status', 'card_id', 'updated_on', 'created_on'], 
            where: whereClause,
            include:[{
                model: Card,
                attributes: ['id', 'salesforce_id', 'card_number', 'card_id', 'card_type', 'available_credit'],
                required: false                  
            }]
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getAssociateDetails = (req, res) => {
    const associateId  = req.params.id;
    try{
        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });
        Associate.findOne({
            attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'created_on', 'updated_on'], 
            where: {
                salesforce_id: associateId, 
            },
            include:[{
                model: Card,
                attributes: ['id', 'unique_id', 'salesforce_id', 'card_id', 'card_number', 'card_type', 'status', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'],
                required: false                  
            }]
        })
        .then(async data => {
            res.status(200).json(data); 
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Associate not found.',
        });
    }
    /*try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                // you can change loginUrl to connect to sandbox or prerelease env.
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }
            conn.sobject("Associates__c")
            .select('*')
            .where({
                Id: associateId,
            })
            .execute(function(err, records) {
                if(records)
                    res.status(200).json(records[0]);
            });
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }*/
}
exports.getSalesforceCards = (req, res) => {
    const endConsumerId  = req.params.econ;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).log(err); }
            conn.sobject("RFID_Cards__c")
            .select('*')
            //.where({IsDeleted: false, Status__c: 'Not Active', End_Consumer__c: endConsumerId})
            .where({IsDeleted: false, End_Consumer__c: endConsumerId})
            .execute(function(err, records) {
                res.status(200).json(records);
            });
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getAvailableCards = (req, res) => {
    const endConsumerId  = req.params.econ;
    try{     
        Card.findAll({
            attributes: ['id', 'salesforce_id', 'card_number', 'card_id', 'card_type', 'expiration_date', 'end_consumer_id', 'status', 'updated_on', 'created_on'], 
            where: {
                end_consumer_id: endConsumerId, 
                status: '0',
                assignment_status: 'available'
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getCardDetails = (req, res) => {
    const cardId  = req.params.id;
    try{ 
        Card.findOne({
            attributes: ['id', 'unique_id', 'salesforce_id', 'card_number', 'card_id', 'card_type', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'], 
            where: {
                salesforce_id: cardId, 
            },
        })
        .then(async data => {
            res.status(200).json(data); 
        });
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.getSalesforceCardDetails = (req, res) => {
    const cardId  = req.params.id;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }
            conn.sobject("RFID_Cards__c")
            .select('*')
            .where({
                Id: cardId,
            })
            .execute(function(err, records) {
                if(records)
                    res.status(200).json(records[0]);
            });
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.saveAssociate = async (req, res) => {
    let memberController = this;
    var dateOfBirth = siteHelper.formatDate(req.body.dob);
    var associateId = req.body.associateId;
    var cardSalesforceId = req.body.assigned_card;
    var endConsumerId = req.body.end_consumer_id;
    let associateObject = {
        Name: req.body.first_name + ' ' + req.body.last_name,
        Mobile_Number__c: (req.body.mobile).replace(/\s/g,''),
        Email__c: req.body.email,
        Date_of_Birth__c: dateOfBirth,
        Vehicle_Rego__c: req.body.car_reg,
        RFID_Card__c: cardSalesforceId,
        End_Consumer__c: endConsumerId,
    }
    //console.log(associateObject) 
    try{                
        var sf = require('node-salesforce');
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(env.salesforce.username, password, function(err, userInfo) {
            if(!associateId){
                Associate.findOne({ where: { email: req.body.email,}, }).then(associate => {
                    if(associate)
                    {
                        res.status(200).json({
                            message: "Email already exists.",
                            error: true
                        });
                    }else{
                        conn.sobject("Associates__c").create(associateObject, function(err, ret) {
                            if (err) { 
                                console.error(err, ret);
                                res.status(200).json({
                                    message: "Something wrong! Please try again.",
                                    error: true
                                }); 
                            }else{
                                memberController.updateCardStatus(cardSalesforceId, '1', 'assigned');
                                res.status(200).json({
                                    message: "Associate successfully created.",
                                    error: false,
                                });
                            }
                        });
                    }
                });
            }else{
                Associate.findOne({ where: { email: req.body.email,}, }).then(associate => {
                    if(associate && associate.salesforce_id != associateId)
                    {
                        res.status(200).json({
                            message: "Email already exists.",
                            error: true
                        });
                    }else{
                        conn.sobject("Associates__c")
                        .find({ 'Id' : associateId })
                        .update(associateObject, function(err, ret) {                
                            if (err) { 
                                console.error(err, ret);
                                res.status(200).json({
                                    message: "Something wrong! Please try again.",
                                    error: true
                                }); 
                            }else{
                                if(associate.card_id != cardSalesforceId){
                                    memberController.updateCardStatus(associate.card_id, '0', 'available');
                                    memberController.updateCardStatus(cardSalesforceId, '1', 'assigned');
                                }        
                                res.status(200).json({
                                    message: "Associate successfully updated.",
                                    error: false,
                                });
                            }
                        });
                    }
                }); 
            }
        });
    }
    catch(error){        
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }
}

exports.deleteAssociate = async (req, res) => {
    let memberController = this;
    var associateId = req.body.associateId;
    try{      
        Associate.findOne({ where: { salesforce_id: associateId,}, }).then(associate => { 
            console.log(associate);
            let cardSalesforceId = associate.card_id;        
            var sf = require('node-salesforce');
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(env.salesforce.username, password, function(err, userInfo) {
                conn.sobject("Associates__c").destroy(associateId, function(err, ret) {
                    if (err || !ret.success) { console.error(err, ret).error(err, ret); }
                    Associate.destroy({ where: { salesforce_id: associateId } });
                    memberController.updateCardStatus(cardSalesforceId, '0', 'available');
                    res.status(200).json({
                        message: "Associate successfully deleted.",
                        error: false,
                    });
                });
            });
        });
    }
    catch(error){
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }
}

exports.updateCardStatus = (salesforceId, status, assignmentStatus = '') => {
    //console.log(salesforceId+", "+status+", "+assignmentStatus)
    try{ 
        var sf = require('node-salesforce');
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(env.salesforce.username, password, function(err, userInfo) {
            let cardStatus = (status == '1') ? 'Active' : 'Not Active';
            let salesforceCardObj = {Status__c: cardStatus};
            if(assignmentStatus){
                salesforceCardObj['Assignment__c'] = (assignmentStatus == 'assigned') ? 'Assigned' : 'Available';
            }
            conn.sobject("RFID_Cards__c")
            .find({ 'Id' : salesforceId })
            .update(salesforceCardObj, function(err, ret) {                    
                //console.log(err);
                //console.log(ret);
                if (!err) { 
                    return true;
                }
            });
        });
    }catch(error) {
        console.log(error);
        return false;
    }
}
exports.getEndconsumerDetails = (req, res) => {
    const endConsumerId  = req.params.id;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                // you can change loginUrl to connect to sandbox or prerelease env.
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }

            /*conn.query(`SELECT Id, Name, Consumer_Name__c, Email_1__c, Mobile__c, Record_Type__c, Business_Name__c, UnAssigned_Credit__c, ABN__c, Company_Name__c, Recharge_Procedure__c, Stripe_Customer_Id__c, Auto_Recharge_Amount__c, Threshold_Amount__c, account_name__r.Name, account_name__r.ABN__c, account_name__r.Billing_Country__c, account_name__r.Billing_State_Province__c, account_name__r.Billing_Street__c, account_name__r.Billing_Suburb__c, account_name__r.Billing_Zip_Postal_Code__c FROM End_consumer__c where id='${endConsumerId}'`, function(err, result) {
                if (err) { console.error(err, ret).error(err); }
                res.status(200).json(result);
            });*/

            conn.sobject("End_Consumer__c")
            .select('*')
            .where({
                Id: endConsumerId,
            })
            .execute(function(err, records) {
                if(records)
                    res.status(200).json(records[0]);
            });

            /*conn.sobject("RFID_Cards__c")
            .select('*, End_Consumer__r.*')
            .where({
                Id: 'a639n00000074TVAAY',
            })
            .execute(function(err, records) {
                if(records)
                    res.status(200).json(records[0]);
            });*/
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.getAllCards = (req, res) => {

    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err, userInfo) {
        if (err) { console.error(err, ret).error(err); }
        conn.sobject("RFID_Cards__c")
        .select('*')
        .where({IsDeleted: false})
        .execute(function(err, records) {

            if(records)
            {
                for(var i=0; i<records.length; i++)
                {
                    var record = records[i];
                    //console.log("Card : "+record.Id);

                    if(record.Status__c == "Not Active")
                    {
                        var status = 0;
                    }
                    else if(record.Status__c == "Active")
                    {
                        var status = 1;
                    }
                    else
                    {
                        var status = 2;
                    }

                    let cardObject = {
                        salesforce_id: record.Id,
                        unique_id: record.Name,
                        card_number: record.Display_Card_Number__c,
                        card_type: 'prepaid',
                        expiration_date: '0000-00-00',
                        end_consumer_id: record.End_Consumer__c,
                        status: status,
                        updated_on: totalDate,
                        created_on: totalDate
                    }    

                    Card.create(cardObject, 
                        {attributes: ['salesforce_id','unique_id','card_number', 'card_id','card_type','expiration_date','end_consumer_id','status','updated_on','created_on', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val']})
                
                }
            }
            else
            {
                res.status(200).json({
                    message: "Error!",
                    error: error
                });
            }
        });
    });
}

exports.getCorporateCards = (req, res) => {
    const endconsumerId  = req.params.id;
    const status = req.query.status;

    try{
        let whereClause = {
            end_consumer_id: endconsumerId, 
        };
        if(status){
            whereClause.status = (status == "active") ? "1" : "0"; 
        }

        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });  
        Card.findAll({
            attributes: ['salesforce_id','card_number', 'card_id','card_type','expiration_date','status','updated_on','created_on', 'available_credit'], 
            where: whereClause,
            include:[{
                model: Associate,
                attributes: ['id', 'salesforce_id', 'name'],
                required: false                  
            }]
        })
        .then(async data => {
            //console.log(data);
            res.status(200).json(data); 
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}
exports.getCorporateCardIds = (req, res) => {
    const endconsumerId  = req.params.id;

    try{
        Card.findAll({
            attributes: ['card_id'], 
            where: {
                end_consumer_id: endconsumerId, 
            },
            raw: true
        })
        .then(async data => {
            //console.log(data);
            res.status(200).json(data); 
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}

exports.searchCorporateCards = (req, res) => {
    const endconsumerId  = req.body.endConsumerId;
    const search = req.body.search;

    try{
        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });  
        Card.findAll({
            attributes: ['salesforce_id','card_number', 'card_id','card_type','expiration_date','status','updated_on','created_on'], 
            where: {
                [Op.or]: [
                    { 
                        card_number: {[Op.like]: `%${search}%`},
                    },
                    {
                        '$associate.name$': {[Op.like]: `%${search}%`},
                    }
                ], 
                [Op.and]: [
                    {
                        end_consumer_id: {[Op.eq]: `${endconsumerId}`},
                    }
                ]
            },
            include:[{
                model: Associate,
                attributes: ['id', 'salesforce_id', 'name'],
                required: false                  
            }]
        })
        .then(async data => {
            res.status(200).json(data); 
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}

exports.unlinkCorporateCard = (req, res) => {
    let memberController = this;
    const salesforceId  = req.params.id;

    /*let updatedStatus = {
        card_id: '',
        status: '0',
    }*/
    try{
        Associate.findOne({
            attributes: ['card_id'], 
            where: {
                salesforce_id: salesforceId, 
            },
        }).then(data => {
            
            if(data)
            {
                console.log('Data', data)
                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                });
                conn.login(username, password, function(err, userInfo) {
                    conn.sobject("Associates__c")
                    .find({ 'Id' : salesforceId })
                    .update({RFID_Card__c: '#N/A', Status__c: 'InActive'}, function(err, ret) {
                        console.log('Test', err, ret)
                        /*Associate.update(updatedStatus,
                        { 
                            returning: true, 
                            where: {salesforce_id: salesforceId},
                            attributes: ['salesforce_id', 'card_id']
                        });*/
                        memberController.updateCardStatus(data.card_id, '0', 'available');
                        res.status(200).json({
                            status: '1',
                            message: "Corporate card unlinked successfully.",
                            error: false,
                        });
                    });

                });
            }else{
                res.status(200).json({
                    message: "Something wrong! Please try again.",
                    error: true
                });
            }

        });
    }
    catch(error){    
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }  
}

exports.getAvailableAssociate = (req, res) => {
    const endConsumerId  = req.params.id;
    try{     
        Associate.findAll({
            attributes: ['id', 'salesforce_id', 'name'], 
            where: {
                end_consumer_id: endConsumerId, 
                [Op.or]: [
                    {
                        card_id: ""
                    }, 
                    {
                        card_id: null
                    }, 
                    {
                        card_id: "0"
                    }
                ]
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getCardAssociates = (req, res) => {
    const endConsumerId  = req.params.id;
    try{
        let whereClause = {
            end_consumer_id: endConsumerId, 
        };

        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });  
        Card.findAll({
            attributes: ['salesforce_id','unique_id','card_number', 'card_id','card_type','expiration_date','end_consumer_id','status','updated_on','created_on', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'], 
            where: whereClause,
            include:[{
                model: Associate,
                attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'gender', 'email', 'mobile', 'car_reg', 'date_of_birth' , 'end_consumer_id'],
                required: false                  
            }]
        })
        .then(async records => {
            if(records.length > 0){
                res.status(200).json({
                    message: "Success",
                    records: records,
                    error: 0
                });                        
            }
        });
    }
    catch(error){
        res.status(500).json({
            message: "Error!",
            error: 1
        });
    }
    /*try{     
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        
        conn.login(username, password, function(err, userInfo) {
            conn.query(`SELECT Id, Title__c, Name, Mobile_Number__c, Country_Dialing_Code__c,Email__c, RFID_Card__r.name, RFID_Card__r.Display_Card_Number__c, RFID_Card__r.Id, RFID_Card__r.Card_Id__c, RFID_Card__r.PrePaid_Credit__c, RFID_Card__r.Updated_DT__c, RFID_Card__r.Status__c, RFID_Card__r.Card_Expiration_Date__c FROM Associates__c where RFID_Card__c != NULL and end_consumer__r.id='${endConsumerId}'`, async function(err, result) {
                if (err) { 
                    console.log(err)
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        error: 1
                    });
                }
                if(result.records.length > 0){
                    res.status(200).json({
                        message: "Success",
                        records: result.records,
                        error: 0
                    });                        
                }
            });
        });
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: 1
        });
    }*/
}

exports.linkCorporateCards = (req, res) => {
    let memberController = this;
    const associateId  = req.body.associateId;
    const assigned_card  = req.body.assigned_card;
    let updatedStatus = {
        card_id: assigned_card,
        status: '1',
    }

    try{          
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        
        conn.login(username, password, function(err, userInfo) {   
            // console.log(associateId)         
            // console.log(assigned_card)         
            conn.sobject("Associates__c")
            .find({ 'Id' : associateId })
            .update({RFID_Card__c: assigned_card, Status__c: 'Active'}, function(err, ret) { 
                if (err) { console.error(err, ret).error(err); }
                //console.log(err)
                //console.log(ret)               
                Associate.update(updatedStatus,
                { 
                    returning: true, 
                    where: {salesforce_id: associateId},
                    attributes: ['salesforce_id', 'card_id']
                });
    
                memberController.updateCardStatus(assigned_card, '1', 'assigned');
                res.status(200).json({
                    status: '1',
                    message: "Corporate card and associate linked successfully.",
                    error: false,
                });
            });

        });
    }
    catch(error){  
        console.log(error)      
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }    
}
exports.transferCorporateCard = (req, res) => {
    let memberController = this;
    const transferCard  = req.body.transferCard;
    const transferAssociateId  = req.body.transferAssociateId;
    const assignedCard  = req.body.assignedCard;
    const currentAssociateId  = req.body.currentAssociateId;
    
    try{
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        if(transferCard == assignedCard){
            Associate.findOne({
                attributes: ['card_id'], 
                where: {
                    salesforce_id: currentAssociateId, 
                },
            }).then(associate => { 
                //console.log(associate)           
                if(associate)
                {                    
                    conn.login(username, password, function(err, userInfo) {
                        conn.sobject("Associates__c")
                        .find({ 'Id' : currentAssociateId })
                        .update({RFID_Card__c: '#N/A', Status__c: 'InActive'}, function(err, ret) {    
                            Associate.update({
                                card_id: '',
                                status: '0',
                            },
                            { 
                                returning: true, 
                                where: {salesforce_id: currentAssociateId},
                                attributes: ['salesforce_id', 'card_id']
                            });
                            //memberController.updateCardStatus(associate.card_id, '0', 'available');
                        });
        
                    });
                }else{
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        error: true
                    });
                }
        
            });
        }
        conn.login(username, password, function(err, userInfo) {  
            conn.sobject("Associates__c")
            .find({ 'Id' : transferAssociateId })
            .update({RFID_Card__c: transferCard, Status__c: 'Active'}, function(err, ret) { 
                if (err) { console.error(err, ret).error(err); }
                //console.log(err)
                //console.log(ret)               
                Associate.update({
                    card_id: transferCard,
                    status: '1',
                },
                { 
                    returning: true, 
                    where: {salesforce_id: transferAssociateId},
                    attributes: ['salesforce_id', 'card_id']
                });
                
                memberController.updateCardStatus(transferCard, '1', 'assigned');
                res.status(200).json({
                    status: '1',
                    message: "Corporate card transferred successfully.",
                    error: false,
                });
            });
        });
    }
    catch(error){  
        console.log(error)      
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }

    /*let updatedStatus = {
        card_id: assigned_card,
        status: '1',
    }

    try{          
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        
        conn.login(username, password, function(err, userInfo) {   
            console.log(associateId)         
            conn.sobject("Associates__c")
            .find({ 'Id' : associateId })
            .update({RFID_Card__c: assigned_card, Status__c: 'Active'}, function(err, ret) { 
                if (err) { console.error(err, ret).error(err); }
                //console.log(err)
                //console.log(ret)               
                Associate.update(updatedStatus,
                { 
                    returning: true, 
                    where: {salesforce_id: associateId},
                    attributes: ['salesforce_id', 'card_id']
                });
    
                memberController.updateCardStatus(assigned_card, '1', 'assigned');
                res.status(200).json({
                    status: '1',
                    message: "Corporate card and associate linked successfully.",
                    error: false,
                });
            });

        });
    }
    catch(error){  
        console.log(error)      
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    } */   
}

exports.transferCorporateCardAssociate = (req, res) => {
    let memberController = this;
    const transferCard  = req.body.transferCard;
    const transferAssociateId  = req.body.transferAssociateId;
    const assignedCard  = req.body.assignedCard;
    const currentAssociateId  = req.body.currentAssociateId;
    
    try{
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        if((transferCard != assignedCard && transferAssociateId == currentAssociateId) || (transferCard == assignedCard && transferAssociateId != currentAssociateId)){
            Associate.findOne({
                attributes: ['card_id'], 
                where: {
                    salesforce_id: currentAssociateId, 
                },
            }).then(associate => { 
                //console.log(associate)           
                if(associate)
                {                    
                    conn.login(username, password, function(err, userInfo) {
                        conn.sobject("Associates__c")
                        .find({ 'Id' : currentAssociateId })
                        .update({RFID_Card__c: '#N/A', Status__c: 'InActive'}, function(err, ret) {    
                            Associate.update({
                                card_id: '',
                                status: '0',
                            },
                            { 
                                returning: true, 
                                where: {salesforce_id: currentAssociateId},
                                attributes: ['salesforce_id', 'card_id']
                            });
                            //memberController.updateCardStatus(associate.card_id, '0', 'available');
                        });
        
                    });
                }else{
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        error: true
                    });
                }
        
            });
        }
        conn.login(username, password, function(err, userInfo) {  
            conn.sobject("Associates__c")
            .find({ 'Id' : transferAssociateId })
            .update({RFID_Card__c: transferCard, Status__c: 'Active'}, function(err, ret) { 
                if (err) { console.error(err, ret).error(err); }
                //console.log(err)
                //console.log(ret)               
                Associate.update({
                    card_id: transferCard,
                    status: '1',
                },
                { 
                    returning: true, 
                    where: {salesforce_id: transferAssociateId},
                    attributes: ['salesforce_id', 'card_id']
                });
                
                memberController.updateCardStatus(transferCard, '1', 'assigned');
                res.status(200).json({
                    status: '1',
                    message: "Corporate card transferred successfully.",
                    error: false,
                });
            });
        });
    }
    catch(error){  
        console.log(error)      
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }
 
}
exports.corporateCardDeatils = (req, res) => {
    const salesforceId  = req.body.id;

    console.log(salesforceId);
}

exports.getCorporateCardDetails = (req, res) => {
    const cardId  = req.params.id;

    try{
        let whereClause = {
            salesforce_id: cardId, 
        };

        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });  
        Card.findAll({
            attributes: ['salesforce_id','unique_id','card_number', 'card_id','card_type','expiration_date','end_consumer_id','status','updated_on','created_on', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'], 
            where: whereClause,
            include:[{
                model: Associate,
                attributes: ['id', 'salesforce_id', 'name', 'first_name', 'last_name', 'gender', 'email', 'mobile', 'car_reg', 'date_of_birth' , 'end_consumer_id'],
                required: false                  
            }]
        })
        .then(async records => {
            if(records)
                    res.status(200).json(records[0]);
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}

exports.updateCardStatusDetails = (req, res) => {
    let memberController = this;
    const associateSalesforceId  = req.body.associate_id;
    const cardSalesforceId  = req.body.salesforce_id;
    const cardStatus  = req.body.status;
    const associateStatus = (cardStatus == '1') ? 'Active' : 'InActive';
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            conn.sobject("Associates__c")
            .find({ 'Id' : associateSalesforceId })
            .update({Status__c: associateStatus}, function(err, ret) {
                let updatedStatus = {
                    status: cardStatus,
                }
                Associate.update(updatedStatus,
                { 
                    returning: true, 
                    where: {salesforce_id: associateSalesforceId},
                    attributes: ['salesforce_id', 'status']
                });
    
                memberController.updateCardStatus(cardSalesforceId, cardStatus);
                res.status(200).json({
                    message: "Card successfully updated.",
                    error: false,
                });
            });

        });
        
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }    
}

exports.getCardCounts = async (req, res) => {
    const endconsumerId  = req.params.econ;
    try{
        const totalCards = await Card.count({
            where: { end_consumer_id: endconsumerId },
        });
        const activeCards = await Card.count({
            where: { end_consumer_id: endconsumerId, status: '1' },
        }); 
        res.status(200).json({ totalCards: totalCards, activeCards: activeCards });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}



/*exports.getAllAssociates = (req, res) => {
    const endConsumerId  = req.params.id;
    try{
        Associate.findAll({
            attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'status', 'end_consumer_id'],
            where: {
                end_consumer_id: endConsumerId, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}*/

exports.getAssociateCorporateCard = (req, res) => {
    const associateId  = req.params.id;
    try{
        let whereClause = {
            salesforce_id: associateId, 
        };

        Associate.hasOne(Card, {
            sourceKey: 'card_id',
            foreignKey: 'salesforce_id'
        });  
        Associate.findOne({
            attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'status', 'card_id', 'end_consumer_id'], 
            where: whereClause,
            include:[{
                model: Card,
                attributes: ['salesforce_id','unique_id','card_number', 'card_id','card_type','expiration_date','status','updated_on','created_on', 'available_credit', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'],
                required: false                  
            }]
        })
        .then(async records => {
            if(records)
                    res.status(200).json(records);
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    } 
}

exports.saveSupportCase = (req, res) => {

    //console.log(req.body); return false;

    const case_id = Date.now()+''+Math.random().toString(36).substring(4,9);

    let supportCaseObject = {
        case_id: case_id.toUpperCase(),
        related_to: req.body.related_to,
        associates_id: req.body.associateId,
        card_id: req.body.assigned_card,
        end_consumer_id: req.body.end_consumer_id,
        message: req.body.message
    }

    let time = req.body.added_date_time

    let t = new Date(time)

    let hr = ("0" + t.getHours()).slice(-2);
    let min = ("0" + t.getMinutes()).slice(-2);
    let sec = ("0" + t.getSeconds()).slice(-2);

    let added_totalDate =  t.getFullYear()+"-"+t.getMonth()+1+"-"+t.getDate()+" "+hr+":"+min+":"+sec
    
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    supportCaseObject['added_date_time'] = added_totalDate;
    supportCaseObject['updated_on'] = totalDate;
    supportCaseObject['created_on'] = totalDate;
    console.log(supportCaseObject);
    try{
        SupportCase.create(supportCaseObject, 
            {attributes: ['id', 'case_id' , 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message', 'status', 'end_consumer_id', 'updated_on', 'created_on']})
        .then(result => {     
            res.status(200).json({
                message: "Support case successfully added.",
                status: 1,
                success: "Success",
            });
        });

    }catch(error){
        res.status(200).json({
            message: "Fail!",
            error: error.message
        });
    }
}

exports.getSupportCases = (req, res) => {
    const endConsumerId  = req.params.id;
    try{
            SupportCase.findAll({
                attributes: ['id', 'case_id', 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message', 'status'],
                where: {
                    end_consumer_id: endConsumerId, 
                },
            })
            .then(data => {
                res.status(200).json(data);
            })
        }catch(error){
            res.status(200).json({
                message: "Fail!",
                error: error.message
            });
        }
}

exports.getSupportCaseDetails = (req, res) => {
    const caseId  = req.params.id;
    try{
            SupportCase.findAll({
                attributes: ['id', 'case_id', 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message', 'status'],
                where: {
                    case_id: caseId, 
                },
            })
            .then(data => {
                //console.log(data);
                res.status(200).json(data[0]);
            })
        }catch(error){
            res.status(200).json({
                message: "Fail!",
                error: error.message
            });
        }
}


exports.chatHistory = (req, res) => {
    const user  = req.params.id;

    try{
            SupportCase.findAll({
                attributes: ['id', 'case_id', 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message', 'status'],
                where: {
                    case_id: user, 
                },
            })
            .then(data => {
                //console.log(data);
                res.status(200).json(data[0]);
            })
        }catch(error){
            res.status(200).json({
                message: "Fail!",
                error: error.message
            });
        }
    
}

exports.supportCaseStatus = (req, res) => {
    const caseId  = req.params.id;

    let supportCaseObject = {   
        status: '0'
    }

    try{
        SupportCase.update(supportCaseObject, { 
            returning: true, 
            where: {case_id: caseId},
            attributes: ['id', 'case_id', 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message', 'status']
        }).then(async result => {
            res.status(200).json({
                message: "Associate successfully updated.",
                status: 1,
                error: false,
            });
        });
        }catch(error){
            res.status(200).json({
                message: "Fail!",
                status: 0,
                error: error.message
            });
        }
}

exports.activeSupportCase  = (req, res) => {
    const endConsumerId  = req.params.id;
    try{
            SupportCase.findAll({
                attributes: ['id', 'case_id', 'related_to', 'associates_id', 'card_id', 'added_date_time', 'message'],
                where: {
                    [Op.or]: [
                        { 
                            status: '2'
                        },
                        { 
                            status: '1'
                        }
                    ], 
                    [Op.and]: [
                        {
                            end_consumer_id: endConsumerId,
                        }
                    ]
                },
            })
            .then(data => {
                res.status(200).json(data);
            })
        }catch(error){
            res.status(200).json({
                message: "Fail!",
                error: error.message
            });
        }
}   

exports.supportCaseHistory = (req, res) => {
    const caseId  = req.params.id;
    try{
        SupportCase.hasOne(chatHistory, {
            sourceKey: 'id',
            foreignKey: 'case_id'
        });  
        SupportCase.findAll({
            attributes: ['case_id','associates_id','associates_id','message','added_date_time'], 
            where: {
                [Op.and]: [
                    {
                        case_id: {[Op.eq]: `${caseId}`},
                    }
                ]
            },
            include:[{
                model: chatHistory,
                attributes: ['id', 'end_consumer_id', 'message', 'created_on'],
                required: false                  
            }]
        })
        .then(async data => {
            res.status(200).json(data); 
        });
    }
    catch(error){
        res.status(200).json({
            status: 0,
            error: 'Corporate cards not found.',
        });
    }   
}

exports.updateAssociateStatusDetails = (req, res) => {
    let memberController = this;
    const associateSalesforceId  = req.body.salesforce_id;
    const status  = req.body.status;
    const cardSalesforceId  = req.body.card_id;
    
    const associateStatus = (status == '1') ? 'Active' : 'InActive';

    //console.log(req.body); return false;

    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        
        conn.login(username, password, function(err, userInfo) {
            conn.sobject("Associates__c")
            .find({ 'Id' : associateSalesforceId })
            .update({Status__c: associateStatus}, function(err, ret) {

                let updatedStatus = {
                    card_id: status,
                    status: '0',
                }

                Associate.update(updatedStatus,
                { 
                    returning: true, 
                    where: {salesforce_id: associateSalesforceId},
                    attributes: ['salesforce_id', 'status']
                });
    
                memberController.updateCardStatus(cardSalesforceId, '0', 'available');
                res.status(200).json({
                    message: "Associate successfully updated.",
                    error: false,
                });
            });

        }); 
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: true
        });
    }    

}

/**** Update from Salesforce API Starts ****/

exports.salesforceAssociateUpdate = (req, res) => {
    let memberController = this;
    const associateSalesforceId = req.params.id;
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }
            conn.sobject("Associates__c")
            .select('*')
            .where({
                Id: associateSalesforceId,
            })
            .execute(function(err, records) {
                if(records){
                    const namemyArr = records[0].Name.split(" ");
                    const cardSalesforceId = records[0].RFID_Card__c;
                    const status = cardSalesforceId ? '1' : '0';
                    let associateObject = {   
                        name: records[0].Name,
                        first_name: namemyArr[0],
                        last_name: (namemyArr.length > 1) ? namemyArr[1] : '',
                        mobile: records[0].Mobile_Number__c,
                        email: records[0].Email__c,
                        date_of_birth: records[0].Date_of_Birth__c,
                        //gender:records[0].gender,
                        car_reg: records[0].Vehicle_Rego__c,
                        card_id: cardSalesforceId,
                        updated_on: totalDate,
                        end_consumer_id: records[0].End_Consumer__c,
                        status: status
                    }
                    Associate.findOne({ where: { salesforce_id: associateSalesforceId} }).then(associate => {
                        if(associate)
                        {
                            associate.update(associateObject, { 
                                returning: true, 
                                //where: {salesforce_id: associateSalesforceId},
                                attributes: ['name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'gender', 'car_reg', 'card_id', 'updated_on', 'status']
                            }).then(async result => {
                                //res.status(200).json(records[0]);
                                res.status(200).json({
                                    message: "Associate successfully updated.",
                                    error: false,
                                });
                            });
                        }else{
                            associateObject['salesforce_id'] = associateSalesforceId;
                            associateObject['created_on'] = totalDate;
                            Associate.create(associateObject, 
                                {attributes: ['salesforce_id', 'name', 'first_name', 'last_name', 'mobile', 'email', 'date_of_birth', 'car_reg', 'card_id', 'end_consumer_id', 'created_on', 'updated_on', 'status']})
                            .then(async result => {
                                memberController.updateCardStatus(cardSalesforceId, '1', 'assigned');
                                res.status(200).json({
                                    message: "Associate successfully created.",
                                    error: false,
                                });
                            });
                        }
                    });
                }
            });
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }    
}

exports.getAwsMessages = (req, res) => {
    var AWS = require('aws-sdk');
    AWS.config.update({
        region: env.aws.region,
        accessKeyId: env.aws.accessKeyId,
        secretAccessKey: env.aws.secretAccessKey,
    });
    
    // Create an SQS service object
    //var sqs = new AWS.SQS({apiVersion: '2012-11-05'});
    var sqs = new AWS.SQS();
    
    var queueURL = env.aws.queueURL;
    
    var params = {
        AttributeNames: [
            "SentTimestamp"
        ],
        MaxNumberOfMessages: 10,
        MessageAttributeNames: [
            "All"
        ],
        QueueUrl: queueURL,
        VisibilityTimeout: 20,
        WaitTimeSeconds: 10
    };
    
    sqs.receiveMessage(params, function(err, data) {
        if (err) {
            console.log("Error", err);
        } else if (data.Messages) {
            //console.log("Received Data", data.Messages);
            data.Messages.forEach((txnDetail, k) => {
                console.log(txnDetail.Body);
                data.Messages[k].Body = JSON.parse(txnDetail.Body);
            });
            res.status(200).json(data.Messages);
        }
    });

    //res.status(200).json(this.getMessages(params));
}

exports.getMessages = (params, count = 0, callback) => {
    let allMessages = [];
    let memberController = this;
    var AWS = require('aws-sdk');
    AWS.config.update({
        region: env.aws.region,
        accessKeyId: env.aws.accessKeyId,
        secretAccessKey: env.aws.secretAccessKey,
    });
    
    // Create an SQS service object
    //var sqs = new AWS.SQS({apiVersion: '2012-11-05'});
    var sqs = new AWS.SQS();
    
    var queueURL = env.aws.queueURL;
    
    var params = {
        AttributeNames: [
            "SentTimestamp"
        ],
        MaxNumberOfMessages: 10,
        MessageAttributeNames: [
            "All"
        ],
        QueueUrl: queueURL,
        VisibilityTimeout: 20,
        WaitTimeSeconds: 10
    };
    sqs.receiveMessage(params, function (err, data) {
        if (err || (data && !data.Messages || data.Messages.length <= 0)) {
            
            if(++count >= 7 ){
                return callback(null, allMessages);
            }
    
            return setTimeout(() => {
                return memberController.getMessages(params, count, callback);
            }, 500);
            
        } else if (++count !== 7 ){
            allMessages.push(data);
    
            return setTimeout(() => {
                return memberController.getMessages(params, count, callback);
            }, 500);
        } else {
            allMessages.push(data);
    
            callback(null, allMessages);
        }
    });
}

/**** Update from Salesforce API Ends ****/

exports.getStripeAccount = async (req, res) => { 
    const endConsumerId = req.params.econ;
    try{
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                conn.query(`SELECT Id, Stripe_Customer_Id__c, account_name__r.Stripe_Acc_Id__c, account_name__r.Operator_Id__c FROM End_consumer__c where id='${endConsumerId}'`, function(err, result) {
                    if (err) { console.error(err, ret).error(err); }
                    res.status(200).json(result);
                });
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}

exports.getExtraCredit = async (req, res) => { 
    const endConsumerId = req.params.econ;
    try{
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                
                conn.sobject("End_Consumer__c")
                .select('Record_Type__c')
                .where({
                    Id: endConsumerId,
                })
                .execute(function(err, consumerRecords) {
                    if(consumerRecords.length){
                        //let creditTable = (consumerRecords[0].Record_Type__c == 'Individual_Consumers') ? 'Operator_Credit_Discounts__r' : 'Consumer_Credit_Discounts__r';
                        conn.query(`select id, account_name__c, (select Min_Limit__c, Max_Limit__c, Extra_Credit__c from End_Consumer_Credit_Discounts__r) from End_Consumer__c where id='${endConsumerId}'`, function(err, result) {
                            if (err) { console.error(err); }
                            //console.log(result.records);
                            //let creditResult = (consumerRecords[0].Record_Type__c == 'Individual_Consumers') ? result.records[0].Operator_Credit_Discounts__r : result.records[0].Consumer_Credit_Discounts__r;
                            if(result.records != null && result.records[0].End_Consumer_Credit_Discounts__r != null){
                                res.status(200).json(result.records[0].End_Consumer_Credit_Discounts__r.records);
                            }else{
                                conn.query(`select Min_Limit__c, Max_Limit__c, Extra_Credit__c from Account_Credit_Discount__c where Account__c='${result.records[0].account_name__c}'`, function(accountErr, accountResult) {
                                    if (accountErr) { console.error(accountErr); }
                                    //console.log('Account', accountResult.records);
                                    res.status(200).json(accountResult.records);                  
                                });
                            }                   
                        });
                    }
                });
                /*conn.query(`select id,(select min_limit__c, max_limit__c, Extra_Credit__c from Credit_Discounts__r) from  End_Consumer__c where id='${endConsumerId}'`, function(err, result) {*/
                
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
exports.getRecentTransactions = async (req, res) => { 
    const endConsumerId = req.params.econ;
    try{
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                conn.query(`select id,Recharge_Procedure__c,(select Recharge_Val__c,Net_Amount__c,Recharge_Procedure__c,Date__c from payment_records__r ORDER BY Date__c DESC limit 6) from End_Consumer__c where id='${endConsumerId}'`, function(err, result) {
                    if (err) { console.error(err, ret).error(err); }
                    res.status(200).json(result);
                });
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
exports.getAllTransactions = async (req, res) => { 
    const endConsumerId = req.params.econ; 
    const page = parseInt(req.query.page); 
    const size = parseInt(req.query.size);
    const { limit, offset } = getPagination(page, size);
    var searchText = req.query.s ? req.query.s : '';
    try{
        if(endConsumerId){
            /*var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    console.log(err)
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                let paginationQuery = limit ? 'limit '+limit : '';
                conn.query(`select id,Recharge_Procedure__c,(select Recharge_Val__c,Net_Amount__c,Recharge_Procedure__c,Date__c from payment_records__r ORDER BY Date__c DESC ${paginationQuery}) from End_Consumer__c where id='${endConsumerId}'`, function(err, result) {
                    if (err) { console.error(err, ret).error(err); }
                    res.status(200).json(result);
                });
            });*/

            let whereClause = {
                end_consumer_id: {[Op.eq]: `${endConsumerId}`},
            }
            if(searchText != ''){
                var manualPattern = new RegExp('(\\w*manual\\w*)','gi');
                var autoPattern = new RegExp('(\\w*auto\\w*)','gi');
                if(searchText.match(manualPattern) !== null){
                    searchText = 'manual';
                }else if(searchText.match(autoPattern) !== null){                    
                    searchText = 'auto';
                }
                whereClause = {
                    [Op.or]: [
                        { 
                            total_amount: {[Op.like]: `%${searchText}%`},
                        },
                        { 
                            recharge_procedure: {[Op.like]: `%${searchText}%`},
                        },
                        { 
                            created_on: {[Op.like]: `%${siteHelper.formatToDate(tryParseDateFromString(searchText, 'dmy'))}%`},
                        }
                    ],
                    [Op.and]: [
                        {
                            end_consumer_id: {[Op.eq]: `${endConsumerId}`},
                        }
                    ]
                }
            }
            //console.log(siteHelper.formatToDate(tryParseDateFromString(searchText, 'dmy')));
            PaymentRecord.findAndCountAll({
                attributes: ['id', 'salesforce_id', 'name', 'end_consumer_id', 'account', 'net_amount', 'total_amount', 'stripe_fees', 'tng_commission', 'tax_invoice', 'recharge_procedure', 'updated_on', 'created_on'], 
                where: whereClause,
                limit, 
                offset,
                order: [
                    ['id', 'DESC'],
                ],
            }).then(data => {
                //console.log(data)
                const response = getPagingTxnData(data, page, limit);
                res.status(200).json(response);               
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
const tryParseDateFromString = (dateStringCandidateValue, format = "ymd") => {
    const candidate = (dateStringCandidateValue || ``)
      .split(/[ :\-\/]/g).map(Number).filter(v => !isNaN(v));
    const toDate = () => {
      format = [...format].reduce((acc, val, i) => ({ ...acc,  [val]: i }), {});
      const parts = 
        [candidate[format.y], candidate[format.m] - 1, candidate[format.d] ]
          .concat(candidate.length > 3 ? candidate.slice(3) : []);
      const checkDate = d => d.getDate && 
        ![d.getFullYear(), d.getMonth(), d.getDate()]
          .find( (v, i) => v !== parts[i] ) && d || undefined;
      
      return checkDate( new Date(Date.UTC(...parts)) );
    };
  
    return candidate.length < 3 ? undefined : toDate();
}
const getPagingTxnData = (data, page, limit) => {
    const { count: totalItems, rows: Transactions } = data;
  
    const currentPage = page ? + page : 0;
    const totalPages = Math.ceil(totalItems / limit);
  
    return {totalItems, Transactions, totalPages, currentPage };
};
exports.getTransactionDetails = async (req, res) => { 
    const salesforceId = req.params.sid; 
    try{
        if(salesforceId){            
            PaymentRecord.findOne({
                attributes: ['id', 'salesforce_id', 'name', 'end_consumer_id', 'account', 'net_amount', 'total_amount', 'stripe_fees', 'tng_commission', 'tax_invoice', 'recharge_procedure', 'extra_credit', 'previous_balance', 'updated_on', 'created_on'], 
                where: {
                    salesforce_id: salesforceId
                },
            }).then(data => {
                //console.log(data)
                res.status(200).json(data);               
            });     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}

exports.doStripeRecharge = async (req, res) => {
    const paymentMethod  = req.body.paymentMethod;
    const endConsumerId  = req.body.endConsumerId;
    const grandTotal  = req.body.grandTotal;
    const grandTotalInternational  = req.body.grandTotalInternational;
    const stripeCustomerId  = req.body.stripeCustomerId;
    const applicationFee  = req.body.applicationFee;
    const stripeFee  = req.body.stripeFee;
    const stripeFeeInternational  = req.body.stripeFeeInternational;
    const connectedAccount  = req.body.connectedAccount;
    const rechargeVal  = req.body.rechargeVal;
    const rechargeProcedure  = req.body.rechargeProcedure;
    const projectedTotalVal  = req.body.projectedTotalVal;
    const extraCredit = req.body.extraCredit;
    const previousBalance = req.body.currentBalance;
    
    try{ 
        const stripe = require('stripe')(env.stripeCreds.secretKey);
        const paymentMethodObj = await stripe.paymentMethods.retrieve(
            paymentMethod
        );
        //console.log(paymentMethodObj);
        if(paymentMethodObj.id){
            const grandTotalVal  = (typeof paymentMethodObj.card !== 'undefined' && paymentMethodObj.card.country != 'AU') ? grandTotalInternational : grandTotal;
            const stripeFeeVal  = (typeof paymentMethodObj.card !== 'undefined' && paymentMethodObj.card.country != 'AU') ? stripeFeeInternational : stripeFee;
            const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
            const returnUrl = `${env.protocol}://${env.memberDomain}${port}`+"/checkout";
            const paymentIntent = await stripe.paymentIntents.create({
                //payment_method_types: ['card', 'au_becs_debit', 'sepa_debit'],
                payment_method: paymentMethodObj.id,
                customer: stripeCustomerId, 
                amount: Math.round(grandTotalVal * 100),
                currency: env.stripeCreds.currency,
                automatic_payment_methods: {enabled: true},
                return_url: returnUrl,
                confirm: true,
                application_fee_amount: Math.round(applicationFee * 100),
                transfer_data: {
                    //amount: Math.round(rechargeVal * 100),
                    destination: connectedAccount,
                },
            });
            
            if(paymentIntent.id){
                var sf = require('node-salesforce');
                let username = env.salesforce.username
                let password = env.salesforce.password + env.salesforce.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforce.loginUrl,
                        clientId : env.salesforce.clientId,
                        clientSecret : env.salesforce.clientSecret,
                        redirectUri : env.salesforce.redirectUri
                    }
                });
                conn.login(username, password, function(err) {
                    if (err) { 
                        res.status(200).json({
                            status: 0,
                            message:'Something wrong! Please try again later.',
                            error: 1
                        }); 
                    }
                    conn.sobject("End_Consumer__c")
                    .select('*')
                    .where({
                        Id: endConsumerId,
                    })
                    .execute(function(err, records) {
                        if(records.length){
                            let paymentObject = {
                                Name: 'Recharge - $'+parseFloat(rechargeVal).toFixed(2)+' - '+records[0].Name,
                                End_Consumer__c: endConsumerId,
                                Date__c: new Date(),
                                Net_Amount__c: parseFloat(rechargeVal).toFixed(2),
                                Stripe_Fees__c: parseFloat(stripeFeeVal).toFixed(2),
                                TNG_Commission__c: parseFloat(applicationFee).toFixed(2),
                                Recharge_Val__c: parseFloat(grandTotalVal).toFixed(2),
                                Recharge_Procedure__c: rechargeProcedure,
                                Extra_Credit__c: parseFloat(extraCredit).toFixed(2),
                                Previous_Balance__c: parseFloat(previousBalance).toFixed(2),
                            }
                            conn.sobject("Payment_Record__c").create(paymentObject, function(err, recordRet) {
                                //console.log('Payment Record', recordRet);
                                if (!err) { 
                                    let endConsumerObject = {
                                        UnAssigned_Credit__c: projectedTotalVal,
                                        Recharge_Procedure__c: rechargeProcedure,
                                    }
                                    conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                        console.log(err, ret);
                                        res.status(200).json({
                                            message: "Recharge successfully done.",
                                            //charge: paymentIntent,
                                            recordId: recordRet.id,
                                            error: 0
                                        });
                                    }); 
                                }else{
                                    console.log('Error', err);
                                    res.status(200).json({
                                        message: "Something wrong! Please try again.",
                                        error: 1
                                    });
                                } 
                            });
                                                                
                        }                                    
                    });
                    
                });            
                
            }
        }
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    

}

exports.setupAutoTopup = async (req, res) => {
    const endConsumerId = req.body.endConsumerId;  
    const rechargeType = req.body.rechargeType; 
    const autoRechargeVal = req.body.autoRechargeVal; 
    const triggerRechargeVal = req.body.triggerRechargeVal;  
    const extraCredit = req.body.extraCredit;   
    //const sourceType = req.body.sourceType;   
    //const sourceItem = req.body.sourceItem;  
    const extraCreditVal = parseFloat(autoRechargeVal) * parseFloat(extraCredit) / 100;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err) {
            if (err) { 
                res.status(200).json({
                    status: 0,
                    message:'Something wrong! Please try again later.',
                    error: 1
                }); 
            }
            let endConsumerObject = {
                Recharge_Procedure__c: rechargeType,
                Auto_Recharge_Amount__c: autoRechargeVal,
                Threshold_Amount__c: triggerRechargeVal,
            }
            conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {  
                if (err) {           
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        error: 1
                    }); 
                }   
                let date_ob = new Date();
                let date = ("0" + date_ob.getDate()).slice(-2);
                let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                let year = date_ob.getFullYear();
                let hours = date_ob.getHours();
                let minutes = date_ob.getMinutes();
                let seconds = date_ob.getSeconds(); 
                let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;     
                let autoTopupObj = {
                    endconsumer_id: endConsumerId,
                    //source_id: sourceItem,
                    //source_type: sourceType,
                    auto_recharge_amount: parseFloat(autoRechargeVal).toFixed(2),
                    auto_trigger_point: parseFloat(triggerRechargeVal).toFixed(2),
                    extra_credit_val: parseFloat(extraCreditVal).toFixed(2),
                    updated_on: totalDate
                } 
                AutoTopup
                .findOne({ where: { endconsumer_id: endConsumerId } })
                .then(function(obj) {
                    if(obj)
                        obj.update(autoTopupObj);
                    else{
                        autoTopupObj.created_on = totalDate;
                        AutoTopup.create(autoTopupObj);
                    }                        
                });
                res.status(200).json({
                    message: "Auto Top-Up setup successful.",
                    error: 0
                });
            });
            
        });
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }   
}
exports.setupPaymentMethods = async (req, res) => {
    const endConsumerId = req.body.endConsumerId;  
    const backupItem = req.body.backupItem; 
    const primaryItem = req.body.primaryItem; 
    try{ 
        PaymentSource.findAll({
            where: {
                end_consumer_id: endConsumerId, 
            }
        }).then(records => {
            if(records){
                let i = 0;
                records.forEach(source => {
                    let sourceId = source.source_id;
                    let sourceIndex = backupItem.indexOf(sourceId);
                    let accountType = null;
                    if(sourceId == primaryItem){
                        accountType = 'primary';
                    }else if(sourceIndex > -1){
                        accountType = 'backup';
                    }
                    PaymentSource.update({account_type: accountType},
                    { 
                        returning: true, 
                        where: {source_id: sourceId},
                    });
                    i++;
                    console.log(sourceId, accountType)
                });
                if(i == records.length){
                    res.status(200).json({
                        message: "Payment methods successfully setup",
                        error: 0
                    }); 
                }
                
            }
        });
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }     
}
exports.getEndconsumerAccountSources = async (req, res) => { 
    const endConsumerId = req.params.econ;
    //const sourceType = req.query.type;
    try{
        if(endConsumerId){
            PaymentSource.findAll({
                where: {
                    end_consumer_id: endConsumerId, 
                    //source_type: sourceType,
                },
            }).then(data => {
                res.status(200).json(data);
            });
            /*var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    console.log(err)
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                conn.query(`SELECT Id, Stripe_Customer_Id__c, account_name__r.Stripe_Acc_Id__c, account_name__r.Operator_Id__c FROM End_consumer__c where id='${endConsumerId}'`, async function(err, result) {
                    if (err) { console.error(err, ret).error(err); }
                    if(result.records.length > 0){
                        let stripeCustomeID = result.records[0].Stripe_Customer_Id__c;
                        const stripe = require('stripe')(env.stripeCreds.secretKey);
                        const cards = await stripe.customers.listSources(
                            stripeCustomeID,
                            {object: 'card'}
                        );
                        const bankAccounts = await stripe.customers.listSources(
                            stripeCustomeID,
                            {object: 'bank_account'}
                        );
                        //console.log(cards)
                        res.status(200).json({'bankAccounts':bankAccounts, 'cards':cards});
                    }
                });
            });*/     
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
exports.getEndconsumerSelectedSources = async (req, res) => { 
    const endConsumerId = req.params.econ;
    try{
        if(endConsumerId){
            PaymentSource.findAll({
                where: {
                    end_consumer_id: endConsumerId, 
                    account_type: {
                        [Op.ne]: null,
                        [Op.ne]: ''
                    }
                },
                order: [
                    ['account_type', 'ASC'],
                ],
            }).then(data => {
                res.status(200).json(data);
            });   
        }  
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}

exports.addStripeBankAccount = async (req, res) => {
    const endConsumerId = req.body.end_consumer_id;  
    const accountHolderName = req.body.account_holder_name; 
    const routingRumber = req.body.routing_number; 
    const accountNumber = req.body.account_number; 
    try{ 
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                conn.query(`SELECT Id, Stripe_Customer_Id__c, account_name__r.Stripe_Acc_Id__c, account_name__r.Operator_Id__c FROM End_consumer__c where id='${endConsumerId}'`, async function(err, result) {
                    if (err) { 
                        res.status(200).json({
                            message: "Something wrong! Please try again.",
                            error: 1
                        });
                    }
                    if(result.records.length > 0){
                        let stripeCustomeID = result.records[0].Stripe_Customer_Id__c;
                        const stripe = require('stripe')(env.stripeCreds.secretKey);
                        const bankAccount = await stripe.customers.createSource(stripeCustomeID, {
                            bank_account: {
                              object: "bank_account", 
                              account_holder_name: accountHolderName, 
                              account_holder_type: "individual",  
                              account_number: accountNumber, 
                              routing_number: routingRumber, 
                              country: "US", 
                              currency: "USD",
                            }
                        });
                        console.log(bankAccount);
                        res.status(200).json({
                            message: "Bank account added successfully.",
                            bankAccount: bankAccount,
                            error: 0
                        });
                    }
                });
            });     
        }
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }   
}


exports.getStripeClientSecret = async (req, res) => {
    const endConsumerId = req.params.econ;
    const type = req.query.type; 
    var method_types = ['card', 'au_becs_debit'];
    if(typeof type !== 'undefined'){
        switch(type){
            case 'card': 
                method_types = [
                    'card'
                ];
                break;
            case 'bank': 
                method_types = [
                    'au_becs_debit'
                ];
                break;
        }
    }
    try{ 
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        message:'Something wrong! Please try again later.',
                        error: 1,
                        stripeError: 0
                    }); 
                }
                conn.query(`SELECT Id, Stripe_Customer_Id__c, account_name__r.Stripe_Acc_Id__c, account_name__r.Operator_Id__c FROM End_consumer__c where id='${endConsumerId}'`, async function(err, result) {
                    if (err) { 
                        res.status(200).json({
                            message: "Something wrong! Please try again.",
                            error: 1,
                            stripeError: 0
                        });
                    }
                    if(result.records.length > 0){
                        const stripe = require('stripe')(env.stripeCreds.secretKey);
                        let stripeCustomeID = result.records[0].Stripe_Customer_Id__c;
                        let intentOptions = {
                            customer: stripeCustomeID,
                        };
                        if(method_types.length){
                            intentOptions.payment_method_types = method_types;
                        }else{
                            intentOptions.automatic_payment_methods = {enabled: true};
                        }
                        try{
                            const setupIntent = await stripe.setupIntents.create(intentOptions);
                            res.json({client_secret: setupIntent.client_secret, error: 0, stripeError: 0});
                        }
                        catch(error){   
                            console.log(error)     
                            res.status(200).json({
                                message: "No such customer found in Stripe. Please contact Administrator.",
                                error: 1,
                                stripeError: 1
                            });
                        }                                              
                    }
                });
            });
        }
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    } 
}

exports.createStripeSource = async (req, res) => {
    const endConsumerId = req.body.endConsumerId;
    const paymentMethodId = req.body.paymentMethodId;
    
    try{ 
        if(endConsumerId){
            var sf = require('node-salesforce');
            let username = env.salesforce.username
            let password = env.salesforce.password + env.salesforce.securityToken
            var conn = new sf.Connection({
                oauth2 : {
                    loginUrl : env.salesforce.loginUrl,
                    clientId : env.salesforce.clientId,
                    clientSecret : env.salesforce.clientSecret,
                    redirectUri : env.salesforce.redirectUri
                }
            });
            conn.login(username, password, function(err) {
                if (err) { 
                    res.status(200).json({
                        status: 0,
                        message:'Something wrong! Please try again later.',
                        error: err
                    }); 
                }
                conn.query(`SELECT Id, Stripe_Customer_Id__c, account_name__r.Stripe_Acc_Id__c, account_name__r.Operator_Id__c FROM End_consumer__c where id='${endConsumerId}'`, async function(err, result) {
                    if (err) { 
                        res.status(200).json({
                            message: "Something wrong! Please try again.",
                            error: 1
                        });
                    }
                    if(result.records.length > 0){
                        const stripe = require('stripe')(env.stripeCreds.secretKey);
                        let stripeCustomeID = result.records[0].Stripe_Customer_Id__c;
                        //console.log(stripeCustomeID)
                        
                        const paymentMethod = await stripe.paymentMethods.attach(
                            paymentMethodId,
                            {customer: stripeCustomeID}
                        );
                        console.log(paymentMethod);
                        if(typeof paymentMethod.id !== 'undefined'){
                            let sourceObj = {};
                            sourceObj.source_id = paymentMethod.id;
                            sourceObj.end_consumer_id = endConsumerId;
                            sourceObj.email = paymentMethod.billing_details.email;
                            sourceObj.name = paymentMethod.billing_details.name;
                            sourceObj.zipcode = paymentMethod.billing_details.address.postal_code;
                            switch(paymentMethod.type){
                                case 'card':
                                    sourceObj.source_type = 'card';
                                    sourceObj.brand = paymentMethod.card.brand;
                                    sourceObj.country = paymentMethod.card.country;
                                    sourceObj.last_four_digits = paymentMethod.card.last4;
                                    sourceObj.expiry_date = paymentMethod.card.exp_month+'/'+paymentMethod.card.exp_year;
                                    break;
                                case 'au_becs_debit':
                                    sourceObj.source_type = 'bank';
                                    sourceObj.country = 'AU';
                                    sourceObj.last_four_digits = paymentMethod.au_becs_debit.last4;
                                    sourceObj.bsb_number = paymentMethod.au_becs_debit.bsb_number;
                                    break;
                            }
                            
                            PaymentSource.create(sourceObj).then(async result => {
                                console.log(result);
                                res.status(200).json({
                                    message: "Source added successfully.",
                                    paymentMethod: paymentMethod,
                                    error: 0
                                });
                            });
                        }
                                                
                    }
                });
            });     
        }
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    
    
}

exports.allocateUnassignedCredit = async (req, res) => {
    let memberController = this;
    const endConsumerId  = req.body.endConsId;
    const unAssignedCredit  = req.body.unAssignedCredit;
    const cardAssociate  = req.body.cardAssociate;
    const desiredAmount  = req.body.desiredAmount;
    const autoTopup  = req.body.autoTopup;
    //const autoTopupSourceId = req.body.autoTopupSourceId;
    //const autoTopupSourceType = req.body.autoTopupSourceType;
    const autoTopupRechargeAmount = req.body.autoTopupRechargeAmount;
    const autoTopupTriggerPoint = req.body.autoTopupTriggerPoint;
    const autoTopupCreditVal = req.body.autoTopupCreditVal;
    const connectedAccount = req.body.connectedAccount;
    const stripeCustomerId = req.body.stripeCustomerId;
    const stripeCreds = req.body.stripeCredentials;
    const tngPercentAmount = req.body.tngPercentAmnt;
    //console.log(req.body);
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err) {
            if (err) { 
                res.status(200).json({
                    status: 0,
                    message:'Something wrong! Please try again later.',
                    error: 1
                }); 
            } 
            conn.sobject("RFID_Cards__c")
            .select('PrePaid_Credit__c')
            .where({
                Id: cardAssociate,
            })
            .execute(function(err, records) {
                if(records){
                    let availableCredit = (parseFloat(desiredAmount) + parseFloat(records[0].PrePaid_Credit__c)).toFixed(2);
                    let creditObj = {
                        available_credit: availableCredit,
                    }   
                                     
                    Card.update(creditObj,
                    { 
                        returning: true, 
                        where: {salesforce_id: cardAssociate},
                        attributes: ['available_credit']
                    }).then(async result => {
                        let creditObject = {
                            PrePaid_Credit__c: availableCredit,
                        }
                        conn.sobject("RFID_Cards__c")
                        .find({ 'Id' : cardAssociate })
                        .update(creditObject, function(err, ret) {   
                            console.log(err);
                        });

                        let currentBalance = (parseFloat(unAssignedCredit) - parseFloat(desiredAmount)).toFixed(2);
                        let endConsumerObj = {
                            current_balance: currentBalance,
                        }                      
                        EndConsumer.update(endConsumerObj,
                        { 
                            returning: true, 
                            where: {salesforce_id: endConsumerId},
                            attributes: ['current_balance']
                        }).then(async result => {
                            let endConsumerObject = {
                                UnAssigned_Credit__c: currentBalance,
                            }
                            conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                console.log(err);                                
                            });
                            if(autoTopup == 1 && currentBalance < autoTopupTriggerPoint){
                                let params = { 
                                    endConsumerId: endConsumerId,
                                    //rechargeType: 'Auto',
                                    //autoTopupSourceId: autoTopupSourceId, 
                                    autoTopupRechargeAmount: autoTopupRechargeAmount,
                                    autoTopupCreditVal: autoTopupCreditVal,
                                    connectedAccount: connectedAccount,
                                    stripeCustomerId: stripeCustomerId,
                                    stripeCreds: stripeCreds,
                                    tngPercentAmount: tngPercentAmount,
                                    currentBalance: currentBalance
                                };
                                memberController.doAutoRecharge(params);
                            }
                            
                            res.status(200).json({
                                message: "Amount successfully credited.",
                                error: 0
                            });
                        });
                    });
                }else{
                    res.status(200).json({
                        message: "Something wrong! Please try again.",
                        error: 1
                    });
                }                                    
            });
            
        });

    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }

}

exports.doAutoRecharge = async (data) => {
    let memberController = this;
    let topupData = JSON.parse(JSON.stringify(data));
    const endConsumerId = topupData.endConsumerId,
    //rechargeType = topupData.rechargeType,
    //autoTopupSourceId = topupData.autoTopupSourceId, 
    autoTopupRechargeAmount = parseFloat(topupData.autoTopupRechargeAmount),
    autoTopupCreditVal = parseFloat(topupData.autoTopupCreditVal),
    connectedAccount = topupData.connectedAccount,
    stripeCustomerId = topupData.stripeCustomerId,
    stripeCreds = topupData.stripeCreds,
    tngPercentAmount = parseFloat(topupData.tngPercentAmount),
    currentBalance = parseFloat(topupData.currentBalance);

    try{ 
        PaymentSource.findOne({
            where: {
                end_consumer_id: endConsumerId, 
                account_type: 'primary',
            },
        }).then(async (data) => {
            if(data){
                const paymentMethodId = data.source_id;
                //console.log('Payment Method Id: ', paymentMethodId);
                const stripe = require('stripe')(env.stripeCreds.secretKey);
                const paymentMethodDetails = await stripe.paymentMethods.retrieve(
                    paymentMethodId
                );
                //console.log('Method details: ', paymentMethodDetails);
                if(paymentMethodDetails){
                    let applicationFee = (tngPercentAmount * autoTopupRechargeAmount) / 100;
                    let stripeFee = 0;
                    switch(paymentMethodDetails.type){
                        case 'card':
                            if(paymentMethodDetails.card.country == 'AU'){
                                stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.domesticPercentAmount);
                            }else{
                                stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.internationalPercentAmount);
                            }
                            break;
                        default:
                            stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.domesticPercentAmount);
                            break;
                    }

                    //stripeFee = (sourceDetails.country == 'AU') ? memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.domesticPercentAmount) : memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.internationalPercentAmount);

                    let surcharge = (autoTopupRechargeAmount > 0) ? (stripeFee + applicationFee) : 0;
                    let grandTotal = autoTopupRechargeAmount + surcharge;

                    /*const paymentIntent = await stripe.paymentIntents.create({
                        payment_method_types: ['card'],
                        payment_method: autoTopupSourceId,
                        customer: stripeCustomerId, 
                        amount: Math.round(grandTotal * 100),
                        currency: env.stripeCreds.currency,
                        //automatic_payment_methods: {enabled: true},
                        confirm: true,
                        application_fee_amount: Math.round(applicationFee * 100),
                        transfer_data: {
                            //amount: Math.round(autoTopupRechargeAmount * 100),
                            destination: connectedAccount,
                        },
                    });*/

                    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
                    const returnUrl = `${env.protocol}://${env.memberDomain}${port}`+"/dashboard";
                    const paymentIntent = await stripe.paymentIntents.create({
                        payment_method: paymentMethodId,
                        customer: stripeCustomerId, 
                        amount: Math.round(grandTotal * 100),
                        currency: env.stripeCreds.currency,
                        automatic_payment_methods: {enabled: true},
                        return_url: returnUrl,
                        confirm: true,
                        application_fee_amount: Math.round(applicationFee * 100),
                        transfer_data: {
                            destination: connectedAccount,
                        },
                    });
                    
                    if(paymentIntent.id){
                        console.log('Auto recharge');
                        var sf = require('node-salesforce');
                        let username = env.salesforce.username
                        let password = env.salesforce.password + env.salesforce.securityToken
                        var conn = new sf.Connection({
                            oauth2 : {
                                loginUrl : env.salesforce.loginUrl,
                                clientId : env.salesforce.clientId,
                                clientSecret : env.salesforce.clientSecret,
                                redirectUri : env.salesforce.redirectUri
                            }
                        });
                        conn.login(username, password, function(err) {
                            if (!err) { 
                                conn.sobject("End_Consumer__c")
                                .select('*')
                                .where({
                                    Id: endConsumerId,
                                })
                                .execute(function(err, records) {
                                    if(records){
                                        let paymentObject = {
                                            Name: 'Recharge - $'+autoTopupRechargeAmount.toFixed(2)+' - '+records[0].Name,
                                            End_Consumer__c: endConsumerId,
                                            Date__c: new Date(),
                                            Net_Amount__c: autoTopupRechargeAmount.toFixed(2),
                                            Stripe_Fees__c: stripeFee.toFixed(2),
                                            TNG_Commission__c: applicationFee.toFixed(2),
                                            Recharge_Val__c: grandTotal.toFixed(2),
                                            Recharge_Procedure__c: 'Auto',
                                            Extra_Credit__c: autoTopupCreditVal.toFixed(2),
                                            Previous_Balance__c: currentBalance.toFixed(2),
                                        }
                                        conn.sobject("Payment_Record__c").create(paymentObject, function(err, res) {
                                            console.log(err);
                                            if (!err) { 
                                                /*let paymentObj = {
                                                    salesforce_id: res.id,
                                                    name: 'Recharge - $'+autoTopupRechargeAmount.toFixed(2)+' - '+records[0].Name,
                                                    end_consumer_id: endConsumerId,
                                                    net_amount: autoTopupRechargeAmount.toFixed(2),
                                                    total_amount: grandTotal.toFixed(2),
                                                    stripe_fees: stripeFee.toFixed(2),
                                                    tng_commission: applicationFee.toFixed(2),
                                                    recharge_procedure: rechargeType,
                                                }  
                                                PaymentRecord.create(paymentObj, 
                                                    {attributes: ['salesforce_id', 'name', 'end_consumer_id', 'net_amount', 'total_amount', 'stripe_fees', 'tng_commission', 'tng_commission', 'recharge_procedure']});*/
                                                    
                                                let totalBalance = currentBalance + autoTopupRechargeAmount + autoTopupCreditVal;
                                                let endConsumerObject = {
                                                    UnAssigned_Credit__c: totalBalance.toFixed(2),
                                                    Recharge_Procedure__c: 'Auto Top-Up',
                                                }
                                                conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(error, ret) {
                                                    console.log(error);
                                                });
                                            } 
                                        });

                                        /*let totalBalance = currentBalance + autoTopupRechargeAmount + autoTopupCreditVal;
                                        let endConsumerObj = {
                                            current_balance: totalBalance.toFixed(2),
                                            recharge_procedure: 'Auto Top-Up',
                                        }                      
                                        EndConsumer.update(endConsumerObj,
                                        { 
                                            returning: true, 
                                            where: {salesforce_id: endConsumerId},
                                            attributes: ['current_balance', 'recharge_procedure']
                                        }).then(data => {
                                            let endConsumerObject = {
                                                UnAssigned_Credit__c: totalBalance.toFixed(2),
                                                Recharge_Procedure__c: 'Auto Top-Up',
                                            }
                                            conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                                console.log(err);
                                            });
                                        });*/
                                                                            
                                    }                                    
                                });
                            }
                            
                        });
                    }
                }
            }
        });       
        
    }
    catch(error){   
        console.log(error);
    } 
}

exports.calculateStripeFee = (fixed, amount, percent) => {
    let r = (100 - percent*100) / 100;
    let total = (amount + fixed) / r;
    let fee = total - amount;
    return fee;
}

exports.getEndconsumerDbData = (req, res) => {
    const endconsumerId  = req.params.id;
    try{ 
        EndConsumer.belongsTo(AutoTopup, {targetKey:'endconsumer_id',foreignKey: 'salesforce_id'});
        EndConsumer.findOne({ 
            where: {
                salesforce_id: endconsumerId
            },
            include:[{
                model: AutoTopup,
                attributes: ['source_id','source_type','auto_recharge_amount','auto_trigger_point','extra_credit_val'],
                required: false                  
            }]
        }).then(data => {
            res.status(200).json(data);
        })
         
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getAutoTopupValues = (req, res) => {
    const endConsumerId  = req.params.econ;
    try{ 
        AutoTopup
        .findOne({ where: { endconsumer_id: endConsumerId } })
        .then(function(data) {
            res.status(200).json(data);
        });
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.isMobileExists = async (req, res) => {
    let mobile = req.body.mobile ? (req.body.mobile).replace(/\D/g, '') : '';
    let associateId = req.body.associateId;
    let whereClause = {
        mobile: mobile, 
    };
    if(associateId){
        whereClause.salesforce_id = associateId; 
    }
    Associate.findOne({ where: whereClause }).then(associate => {
        if(associate)
        {
            res.status(200).json({
                message: "Mobile number already exists.",
                status: false
            });
        }else{
            res.status(200).json({
                message: "",
                status: true,
            });
        }
    });
}

exports.salesforceCallback = (req, res) => {
    //console.log(req.body.objectId, req.body.objectName);
    //let memberController = this;
    let objectId = req.body.objectId;
    let objectName = req.body.objectName;
    console.log(objectName)
    switch(objectName){
        case 'End_Consumer__c':
            this.updateEndConsumer(objectId, this);
            break;
        case 'RFID_Cards__c':
            this.updateRFIDCard(objectId, this);
            break;
        case 'Associates__c':
            this.updateAssociate(objectId);
            break;
        case 'Payment_Record__c':
            this.updatePaymentRecord(objectId);
            break;
        case 'Prepaid_Card_Usage__c':
            this.updateCardUsage(objectId);
            break;
    }
}
exports.updateEndConsumer = (objectId, memberController) => {
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err) {
        if (!err) { 
            conn.sobject("End_Consumer__c")
            .select('*, account_name__r.Stripe_Acc_Id__c')
            .where({
                Id: objectId,
            })
            .execute(function(err, records) {
                if(records){
                    let date_ob = new Date();
                    let date = ("0" + date_ob.getDate()).slice(-2);
                    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                    let year = date_ob.getFullYear();
                    let hours = date_ob.getHours();
                    let minutes = date_ob.getMinutes();
                    let seconds = date_ob.getSeconds(); 
                    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
                    const nameArray = records[0].Consumer_Name__c ? (records[0].Consumer_Name__c).split(" ") : [];
                    let isAutoTopup = (records[0].Recharge_Procedure__c == 'Manual') ? '0' : '1';
                    let obj = {
                        name: records[0].Consumer_Name__c,
                        first_name: nameArray ? nameArray[0] : '',
                        last_name: (nameArray.length > 1) ? nameArray[1] : '',
                        email: records[0].Email_1__c,
                        mobile: records[0].Mobile__c,
                        account_type: records[0].Record_Type__c,
                        business_name: records[0].Business_Name__c,
                        current_balance: parseFloat(records[0].UnAssigned_Credit__c),
                        abn: records[0].ABN__c,
                        company_name: records[0].Company_Name__c,
                        recharge_procedure: records[0].Recharge_Procedure__c,
                        updated_on: totalDate,
                        stripe_customer_id: records[0].Stripe_Customer_Id__c,
                        connected_account: records[0].account_name__r.Stripe_Acc_Id__c,
                        is_auto_topup: isAutoTopup
                    } 
                    EndConsumer.findOne({
                        attributes: ['id'],
                        where: {
                            salesforce_id: objectId, 
                        },
                    }).then(data => {            
                        if(data)
                        {
                            EndConsumer.update(obj,
                            {
                                returning: true, 
                                where: {salesforce_id: objectId}
                            }).then(data => {
                                console.log(data);
                            }); 
                        }else{
                            obj.created_on = totalDate;
                            obj.salesforce_id = objectId;
                            //obj.email = data.Email_1__c;
                            //console.log(obj) 
                            EndConsumer.create(obj)
                            .then(async result => {
                                console.log(result);
                            }); 
                        }                        
                        
                    }); 

                    let autoRechargeAmount = (records[0].Auto_Recharge_Amount__c != null) ? records[0].Auto_Recharge_Amount__c : 0;
                    let autoTriggerPoint = (records[0].Threshold_Amount__c != null) ? records[0].Threshold_Amount__c : 0;

                    //let creditTable = (records[0].Record_Type__c == 'Individual_Consumers') ? 'Operator_Credit_Discounts__r' : 'Consumer_Credit_Discounts__r';

                    conn.query(`select id, account_name__c, (select Min_Limit__c, Max_Limit__c, Extra_Credit__c from End_Consumer_Credit_Discounts__r) from End_Consumer__c where id='${objectId}'`, function(err, sfResult) {
                        //console.log(err, sfResult);
                        if (err) { console.error(err); }
                        try{
                            let extraCreditArr = [];
                            //let creditResult = (records[0].Record_Type__c == 'Individual_Consumers') ? sfResult.records[0].Operator_Credit_Discounts__r : sfResult.records[0].Consumer_Credit_Discounts__r;
                            if(sfResult.records != null && sfResult.records[0].End_Consumer_Credit_Discounts__r != null){
                                extraCreditArr = sfResult.records[0].End_Consumer_Credit_Discounts__r.records;
                            }else{
                                conn.query(`select Min_Limit__c, Max_Limit__c, Extra_Credit__c from Account_Credit_Discount__c where Account__c='${records[0].account_name__c}'`, function(accountErr, accountResult) {
                                    if (accountErr) { console.error(accountErr); }
                                    extraCreditArr = accountResult.records;                  
                                });
                            }
                            //console.log('Extra Credit', extraCreditArr);
                            let extraCred = memberController.getExtraCreditValue(extraCreditArr, autoRechargeAmount);
                            //console.log('Extra Credit', extraCred);
                            const extraCreditVal = parseFloat(autoRechargeAmount) * parseFloat(extraCred) / 100;   
                            let topupObj = {
                                endconsumer_id: objectId,
                                //source_id: sourceItem,
                                //source_type: sourceType,
                                auto_recharge_amount: autoRechargeAmount,
                                auto_trigger_point: autoTriggerPoint,
                                extra_credit_val: extraCreditVal,
                                updated_on: totalDate
                            } 
                            //console.log(topupObj);
                            AutoTopup
                            .findOne({ where: { endconsumer_id: objectId } })
                            .then(function(autoTopupObj) {
                                if(autoTopupObj)
                                    autoTopupObj.update(topupObj);
                                else
                                    AutoTopup.create(topupObj);
                            }); 
                            
                            if(isAutoTopup == '1' && parseFloat(records[0].UnAssigned_Credit__c) < autoTriggerPoint){
                                let params = { 
                                    endConsumerId: objectId,
                                    autoTopupRechargeAmount: autoRechargeAmount,
                                    autoTopupCreditVal: extraCreditVal,
                                    connectedAccount: records[0].account_name__r.Stripe_Acc_Id__c,
                                    stripeCustomerId: records[0].Stripe_Customer_Id__c,
                                    stripeCreds: env.stripeCreds,
                                    tngPercentAmount: env.tngPercentAmount,
                                    currentBalance: parseFloat(records[0].UnAssigned_Credit__c)
                                };
                                if(records[0].Record_Type__c == 'Individual_Consumers'){
                                    Card.findOne({
                                        attributes: ['salesforce_id'], 
                                        where: {
                                            end_consumer_id: objectId, 
                                        }
                                    })
                                    .then(data => {
                                        if(data){
                                            //console.log(data.salesforce_id);
                                            params.cardSalesforceId = data.salesforce_id;
                                            params.endConsumerName = records[0].Consumer_Name__c;
                                            memberController.doIndividualAutoRecharge(params, memberController);  
                                        }                                    
                                    });                                
                                }else{
                                    memberController.doAutoRecharge(params);
                                }
                                
                            }
                        }
                        catch(error){
                            console.log(error.message);
                        }
                        
                    });
                    
                    
                }else{
                    EndConsumer.destroy({ where: { salesforce_id: objectId } });
                }                                    
            });
        }
        
    });
}
exports.getExtraCreditValue = (extraCreditArr, rechargeVal) => {
    let extraCred = 0;
    if(extraCreditArr.length){
      extraCreditArr.forEach(extraCreditObj => {
        let minLimit = (extraCreditObj.Min_Limit__c != null) ? extraCreditObj.Min_Limit__c : 0;
        let maxLimit = (extraCreditObj.Max_Limit__c != null) ? extraCreditObj.Max_Limit__c : 0;
        if(rechargeVal >= minLimit && rechargeVal <= maxLimit){
          extraCred = extraCreditObj.Extra_Credit__c;
          return extraCred;
        }
      });
    }
    return extraCred;
}
exports.updateRFIDCard = (objectId, memberController) => {
    //console.log(objectId);    
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err) {
        if (!err) { 
            conn.sobject("RFID_Cards__c")
            .select('*, End_Consumer__r.Record_Type__c')
            .where({
                Id: objectId,
            })
            .execute(function(err, records) {
                //console.log(err, records);
                if(records.length){
                    if(records[0].End_Consumer__r != null && records[0].End_Consumer__r.Record_Type__c == 'Individual_Consumers'){
                        memberController.updateIndividualCard(objectId, records, memberController);
                    }else{
                        memberController.updateCorporateCard(objectId, records);
                    }
                    //console.log(records)
                    
                }else{
                    Card.destroy({ where: { salesforce_id: objectId } });
                }                                    
            });
        }
        
    });
}
exports.updateCorporateCard = (objectId, records) => {
    
    Card.findOne({
        attributes: ['id', 'auto_topup', 'topup_trigger_val', 'topup_recharge_val'], 
        where: {
            salesforce_id: objectId, 
        },
    })
    .then(async data => {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds(); 
        let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        var status = '2';
        switch(records[0].Status__c){
            case "Not Active": status = '0'; break;
            case "Active": status = '1'; break;
        }
        let obj = {
            unique_id: records[0].Name,
            account_id: records[0].Account__c,
            card_number: records[0].Display_Card_Number__c,
            card_id: records[0].Card_Id__c,
            card_type: records[0].Card_Type__c,
            end_consumer_id: records[0].End_Consumer__c,
            available_credit: records[0].PrePaid_Credit__c,
            assignment_status: (records[0].Assignment__c).toLowerCase(),
            status: status,
            updated_on: totalDate
            //expiration_date: (typeof records[0].Card_Expiration_Date__c === "object" && records[0].Card_Expiration_Date__c === null) ? '0000-00-00' : siteHelper.formatDateForMySql(records[0].Card_Expiration_Date__c),
        }
        if(data){
            if(data.auto_topup == '1' && parseFloat(records[0].PrePaid_Credit__c) < parseFloat(data.topup_trigger_val)){
                console.log('Update for Auto Top-Up');
                EndConsumer.findOne({
                    attributes: ['id', 'current_balance'],
                    where: {
                        salesforce_id: records[0].End_Consumer__c, 
                    },
                }).then(endConsumer => {     
                    if(endConsumer && parseFloat(endConsumer.current_balance) > 0)
                    {
                        let current_balance = (parseFloat(endConsumer.current_balance) > parseFloat(data.topup_recharge_val)) ? parseFloat(endConsumer.current_balance) - parseFloat(data.topup_recharge_val) : 0;
                        let endConsumerObj = {
                            UnAssigned_Credit__c: current_balance,
                        } 
                        conn.sobject("End_Consumer__c")
                        .find({ 'Id' : records[0].End_Consumer__c })
                        .update(endConsumerObj, function(err, ret) {                                            
                            console.error(err, ret);
                            let salesforceCardObj = {PrePaid_Credit__c: (parseFloat(records[0].PrePaid_Credit__c) + parseFloat(data.topup_recharge_val))};
                            conn.sobject("RFID_Cards__c")
                            .find({ 'Id' : objectId })
                            .update(salesforceCardObj, function(err, ret) { 
                                console.error(err, ret);
                            });
                        });
                    }         
                });
            }else{
                Card.update(obj,
                {
                    returning: true, 
                    where: {salesforce_id: objectId}
                }).then(result => {
                    console.log(result);                                
                });
            }                            
        }else{
            obj.created_on = totalDate;
            obj.salesforce_id = objectId;
            Card.create(obj).then(async result => {
                console.log(result);
            });
        } 
    });
}
exports.updateIndividualCard = (objectId, records, memberController) => {  
    //console.log(objectId, records);  
    //let memberController = this;
    Card.belongsTo(EndConsumer, {targetKey:'salesforce_id',foreignKey: 'end_consumer_id'});
    Card.findOne({
        attributes: ['id', 'salesforce_id', 'available_credit'], 
        where: {
            salesforce_id: objectId, 
        },
        include:[{
            model: EndConsumer,
            attributes: ['name', 'salesforce_id', 'is_auto_topup', 'stripe_customer_id', 'connected_account'],
            required: false                  
        }]
    })
    .then(data => {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds(); 
        let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        var status = '2';
        //let currentBalance = data.available_credit;
        switch(records[0].Status__c){
            case "Not Active": status = '0'; break;
            case "Active": status = '1'; break;
        }
        let obj = {
            unique_id: records[0].Name,
            account_id: records[0].Account__c,
            card_number: records[0].Display_Card_Number__c,
            card_id: records[0].Card_Id__c,
            card_type: records[0].Card_Type__c,
            end_consumer_id: records[0].End_Consumer__c,
            available_credit: records[0].PrePaid_Credit__c,
            assignment_status: (records[0].Assignment__c).toLowerCase(),
            status: status,
            updated_on: totalDate
        }
        if(data){
            Card.update(obj,
            {
                returning: true, 
                where: {salesforce_id: objectId}
            }).then(cardResult => {
                //console.log(data); 
                //console.log(data.end_consumer);
                if(data.end_consumer != null && data.end_consumer.is_auto_topup == '1'){
                    AutoTopup.findOne({
                        attributes: ['source_id','source_type','auto_recharge_amount','auto_trigger_point','extra_credit_val'], 
                        where: {
                            endconsumer_id: data.end_consumer.salesforce_id, 
                        }
                    })
                    .then(result => {
                        if(parseFloat(records[0].PrePaid_Credit__c) < parseFloat(result.auto_trigger_point)){
                            let params = { 
                                endConsumerId: data.end_consumer.salesforce_id,
                                autoTopupRechargeAmount: result.auto_recharge_amount,
                                autoTopupCreditVal: result.extra_credit_val,
                                connectedAccount: data.end_consumer.connected_account,
                                stripeCustomerId: data.end_consumer.stripe_customer_id,
                                stripeCreds: env.stripeCreds,
                                tngPercentAmount: env.tngPercentAmount,
                                currentBalance: records[0].PrePaid_Credit__c,
                                endConsumerName: data.end_consumer.name,
                                cardSalesforceId: data.salesforce_id
                            };
                            memberController.doIndividualAutoRecharge(params, memberController);
                        }
                    });
                }                               
            });            
        }else{
            obj.created_on = totalDate;
            obj.salesforce_id = objectId;
            Card.create(obj).then(result => {
                console.log(result);
            });
        }
    });
}
exports.doIndividualAutoRecharge = (data, memberController) => {
    //console.log('data', data);
    //let memberController = this;
    let topupData = JSON.parse(JSON.stringify(data));
    const endConsumerId = topupData.endConsumerId,
    autoTopupRechargeAmount = parseFloat(topupData.autoTopupRechargeAmount),
    autoTopupCreditVal = parseFloat(topupData.autoTopupCreditVal),
    connectedAccount = topupData.connectedAccount,
    stripeCustomerId = topupData.stripeCustomerId,
    stripeCreds = topupData.stripeCreds,
    tngPercentAmount = parseFloat(topupData.tngPercentAmount),
    currentBalance = parseFloat(topupData.currentBalance),
    endConsumerName = topupData.endConsumerName,
    cardSalesforceId = topupData.cardSalesforceId;

    try{ 
        PaymentSource.findOne({
            where: {
                end_consumer_id: endConsumerId, 
                account_type: 'primary',
            },
        }).then(async (data) => {
            if(data){
                const paymentMethodId = data.source_id;
                //console.log('Payment Method Id: ', paymentMethodId);
                const stripe = require('stripe')(env.stripeCreds.secretKey);
                const paymentMethodDetails = await stripe.paymentMethods.retrieve(
                    paymentMethodId
                );
                //console.log('Method details: ', paymentMethodDetails);
                if(paymentMethodDetails){
                    let applicationFee = (tngPercentAmount * autoTopupRechargeAmount) / 100;
                    let stripeFee = 0;
                    switch(paymentMethodDetails.type){
                        case 'card':
                            if(paymentMethodDetails.card.country == 'AU'){
                                stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.domesticPercentAmount);
                            }else{
                                stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.internationalPercentAmount);
                            }
                            break;
                        default:
                            stripeFee = memberController.calculateStripeFee(stripeCreds.fixedAmount, (autoTopupRechargeAmount + applicationFee), stripeCreds.domesticPercentAmount);
                            break;
                    }

                    let surcharge = (autoTopupRechargeAmount > 0) ? (stripeFee + applicationFee) : 0;
                    let grandTotal = autoTopupRechargeAmount + surcharge;

                    const port = env.NODE_ENV == 'development' ? ':'+env.port : '';
                    const returnUrl = `${env.protocol}://${env.prepaidDomain}${port}`+"/dashboard";
                    const paymentIntent = await stripe.paymentIntents.create({
                        payment_method: paymentMethodId,
                        customer: stripeCustomerId, 
                        amount: Math.round(grandTotal * 100),
                        currency: env.stripeCreds.currency,
                        automatic_payment_methods: {enabled: true},
                        return_url: returnUrl,
                        confirm: true,
                        application_fee_amount: Math.round(applicationFee * 100),
                        transfer_data: {
                            destination: connectedAccount,
                        },
                    });
                    
                    if(paymentIntent.id){
                        console.log('Auto recharge');
                        var sf = require('node-salesforce');
                        let username = env.salesforce.username
                        let password = env.salesforce.password + env.salesforce.securityToken
                        var conn = new sf.Connection({
                            oauth2 : {
                                loginUrl : env.salesforce.loginUrl,
                                clientId : env.salesforce.clientId,
                                clientSecret : env.salesforce.clientSecret,
                                redirectUri : env.salesforce.redirectUri
                            }
                        });
                        conn.login(username, password, function(err) {
                            if (!err) { 
                                let paymentObject = {
                                    Name: 'Recharge - $'+autoTopupRechargeAmount.toFixed(2)+' - '+endConsumerName,
                                    End_Consumer__c: endConsumerId,
                                    Date__c: new Date(),
                                    Net_Amount__c: autoTopupRechargeAmount.toFixed(2),
                                    Stripe_Fees__c: stripeFee.toFixed(2),
                                    TNG_Commission__c: applicationFee.toFixed(2),
                                    Recharge_Val__c: grandTotal.toFixed(2),
                                    Recharge_Procedure__c: 'Auto',
                                    Extra_Credit__c: autoTopupCreditVal.toFixed(2),
                                    Previous_Balance__c: currentBalance.toFixed(2),
                                }
                                let projectedTotalVal = parseFloat(currentBalance) + parseFloat(autoTopupRechargeAmount) + autoTopupCreditVal;
                                conn.sobject("Payment_Record__c").create(paymentObject, function(recordErr, recordRet) {
                                    //console.log(recordErr, recordRet);
                                    if (!recordErr) { 
                                        let cardObject = {
                                            PrePaid_Credit__c: projectedTotalVal,
                                        }
                                        conn.sobject("RFID_Cards__c").find({ 'Id' :cardSalesforceId }).update(cardObject, function(cardErr, cardRet) {
                                            //console.log(cardErr, cardRet);
                                            let endConsumerObject = {
                                                Recharge_Procedure__c: 'Auto Top-Up',
                                            }
                                            conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                                console.log(err, ret);
                                            });
                                        });
                                         
                                    }else{
                                        console.log('Error', recordErr);
                                    } 
                                });
                            }
                            
                        });
                    }
                }
            }
        });       
        
    }
    catch(error){   
        console.log(error);
    } 
}
exports.updateAssociate = (objectId) => {
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err) {
        if (!err) { 
            conn.sobject("Associates__c")
            .select('*')
            .where({
                Id: objectId,
            })
            .execute(function(err, records) {
                console.log(records)
                if(records){
                    console.log(records)
                    Associate.findOne({
                        attributes: ['id', 'card_id'], 
                        where: {
                            salesforce_id: objectId, 
                        },
                    })
                    .then(async data => {
                        let date_ob = new Date();
                        let date = ("0" + date_ob.getDate()).slice(-2);
                        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                        let year = date_ob.getFullYear();
                        let hours = date_ob.getHours();
                        let minutes = date_ob.getMinutes();
                        let seconds = date_ob.getSeconds(); 
                        let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
                        const nameArray = records[0].Name ? (records[0].Name).split(" ") : [];
                        var status = records[0].RFID_Card__c ? '1' : '0';
                        let obj = {   
                            name: records[0].Name,
                            first_name: nameArray ? nameArray[0] : '',
                            last_name: (nameArray.length > 1) ? nameArray[1] : '',
                            mobile: records[0].Mobile_Number__c,
                            email:  records[0].Email__c,
                            date_of_birth: records[0].Date_of_Birth__c,
                            car_reg: records[0].Vehicle_Rego__c,
                            card_id: records[0].RFID_Card__c,
                            end_consumer_id: records[0].End_Consumer__c,
                            updated_on: totalDate,
                            status: status
                        }
                        if(data){
                            //var existingCard = data.card_id;
                            Associate.update(obj,
                            {
                                returning: true, 
                                where: {salesforce_id: objectId}
                            }).then(data => {
                                console.log(data);
                                /*if(existingCard && obj.card_id && existingCard != obj.card_id){

                                }*/
                            });
                        }else{
                            obj.created_on = totalDate;
                            obj.salesforce_id = objectId;
                            Associate.create(obj).then(async result => {
                                console.log(result);
                            });
                        } 
                    });
                }else{
                    Associate.destroy({ where: { salesforce_id: objectId } });
                }                                    
            });
        }
        
    });
}
exports.updatePaymentRecord = (objectId) => {
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err) {
        if (!err) { 
            conn.sobject("Payment_Record__c")
            .select('*')
            .where({
                Id: objectId,
            })
            .execute(function(err, records) {
                if(records){
                    //console.log(records)
                    PaymentRecord.findOne({
                        attributes: ['id'], 
                        where: {
                            salesforce_id: objectId, 
                        },
                    })
                    .then(async data => {
                        let date_ob = new Date();
                        let date = ("0" + date_ob.getDate()).slice(-2);
                        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
                        let year = date_ob.getFullYear();
                        let hours = date_ob.getHours();
                        let minutes = date_ob.getMinutes();
                        let seconds = date_ob.getSeconds(); 
                        let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
                        let obj = {
                            name: records[0].Name,
                            end_consumer_id: records[0].End_Consumer__c,
                            net_amount: records[0].Net_Amount__c,
                            total_amount: records[0].Recharge_Val__c,
                            stripe_fees: records[0].Stripe_Fees__c,
                            tng_commission: records[0].TNG_Commission__c,
                            recharge_procedure: records[0].Recharge_Procedure__c,
                            updated_on: totalDate,
                            extra_credit: records[0].Extra_Credit__c,
                            previous_balance: records[0].Previous_Balance__c,
                        }  
                        //console.log('Object Value', obj);
                        if(data){
                            PaymentRecord.update(obj,
                            {
                                returning: true, 
                                where: {salesforce_id: objectId}
                            }).then(data => {
                                console.log(data);
                            });
                        }else{
                            obj.created_on = totalDate;
                            obj.salesforce_id = objectId;
                            PaymentRecord.create(obj).then(async result => {
                                console.log(result);
                            });
                        } 
                    });
                }else{
                    PaymentRecord.destroy({ where: { salesforce_id: objectId } });
                }                                    
            });
        }
        
    });
}
exports.updateCardUsage = (objectId) => {
    console.log(objectId);
    var sf = require('node-salesforce');
    let username = env.salesforce.username
    let password = env.salesforce.password + env.salesforce.securityToken
    var conn = new sf.Connection({
        oauth2 : {
            loginUrl : env.salesforce.loginUrl,
            clientId : env.salesforce.clientId,
            clientSecret : env.salesforce.clientSecret,
            redirectUri : env.salesforce.redirectUri
        }
    });
    conn.login(username, password, function(err) {
        if (!err) { 
            conn.sobject("Prepaid_Card_Usage__c")
            .select('*')
            .where({
                Batch_Job_Id__c: objectId,
            })
            .execute(function(err, records) {
                if(records){
                    //console.log('Total Records', records); 
                    records.forEach(data => {
                        //console.log(data); 
                        let obj = {
                            name: data.Name,
                            salesforce_id: data.Id,
                            end_consumer_id: data.End_Consumer__c,
                            net_amount: data.Net_Amount__c,
                            spent_amount: data.Amount_Charged__c,
                            card_uid: data.Card_Id__c,
                            display_card_number: data.Display_Card__c,
                            settlement_time: siteHelper.formatDateForMySql(data.Settlement_Time__c),
                            rfid_card: data.RFID_Card__c,
                            account_id: data.Account__c,
                            associate_id: data.Associates__c,
                            transaction_id: data.Transaction_Id__c,
                            machine_name: data.Machine_Name__c,
                            batch_job_id: data.Batch_Job_Id__c,
                            created_on: siteHelper.formatDateForMySql(data.CreatedDate),
                            updated_on: siteHelper.formatDateForMySql(data.LastModifiedDate),
                        }
                        //console.log('Record', obj); 
                        CardTransaction.create(obj).then(result => {
                            console.log(result);
                        });
                    }); 
                }                                  
            });
        }
        
    });
}
exports.updateAssociateAutotopup = async (req, res) => {
    const salesforce_id  = req.body.salesforce_id;
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    const data = req.body;
    data.updated_on = totalDate;
    try{                    
        Card.update(data,
        { 
            returning: true, 
            where: {salesforce_id: salesforce_id},
        }).then(data => {
            console.log(data)
            res.status(200).json({
                message: "Auto Top-Up successfully updated.",
                error: 0
            });
        });
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    

}
exports.updateEndconsumerAutotopup = async (req, res) => {
    const endConsumerId  = req.body.salesforce_id;
    /*let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;*/
    const data = req.body;
    //data.updated_on = totalDate;

    let endConsumerObject = {
        Credit_Type__c: 'Prepaid',
        Recharge_Procedure__c: (req.body.is_auto_topup == '1') ? 'Auto Top-Up' : 'Manual',
    }
    //console.log(endConsumerObject);
    try{
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err) {
            if (!err) { 
                if(data.is_auto_topup == '1'){
                    AutoTopup
                    .findOne({ where: { endconsumer_id: endConsumerId } })
                    .then(function(obj) {
                        if(obj && obj.auto_recharge_amount > 0){
                            
                            conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                                console.log(err, ret);
                                if(!err){
                                    res.status(200).json({
                                        message: 'Auto Top-Up successfully enabled',
                                        error: 0
                                    });
                                }
                            });

                            /*EndConsumer.update(data,
                            { 
                                returning: true, 
                                where: {salesforce_id: endConsumerId},
                            }).then(result => {
                                res.status(200).json({
                                    message: 'Auto Top-Up successfully enabled',
                                    error: 0
                                });
                            });*/
                        }else{
                            res.status(200).json({
                                message: "Please add auto top-up values first and try again.",
                                error: 1
                            });
                        }                    
                    }); 
                }else{
                    conn.sobject("End_Consumer__c").find({ 'Id' :endConsumerId }).update(endConsumerObject, function(err, ret) {
                        console.log(err, ret);
                        if(!err){
                            res.status(200).json({
                                message: 'Auto Top-Up successfully disabled',
                                error: 0
                            });
                        }
                    });

                    /*EndConsumer.update(data,
                    { 
                        returning: true, 
                        where: {salesforce_id: endConsumerId},
                    }).then(result => {
                        res.status(200).json({
                            message: 'Auto Top-Up successfully disabled',
                            error: 0
                        });
                    });*/
                }
            }
        });
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    

}
exports.deleteRfidCard = async (req, res) => {
    const sourceId  = req.body.sourceId;
    try{  
        const stripe = require('stripe')(env.stripeCreds.secretKey);
        const paymentMethod = await stripe.paymentMethods.detach(
            sourceId
        );
        //console.log(paymentMethod)
        if(paymentMethod.customer == null){
            PaymentSource.destroy({ where: { source_id: sourceId } });
            res.status(200).json({
                message: "Payment source successfully deleted.",
                error: 0
            });
        } else{
            res.status(200).json({
                message: "Something wrong! Please try again.",
                error: 1
            }); 
        }         
    }
    catch(error){   
        console.log(error)     
        res.status(200).json({
            message: "Something wrong! Please try again.",
            error: 1
        });
    }    

}

exports.getPrepaidCardUsage = (req, res) => {
    //const endconsumerId  = req.params.econ;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }
            conn.sobject("Prepaid_Card_Usage__c")
            .select('*')
            /*.where({
                Id: endconsumerId,
            })*/
            .execute(function(err, records) {
                res.status(200).json(records);
                                
            });
        });         
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getLatestTransactions = (req, res) => {
    const moment = require('moment');
    const cardId  = req.params.id;
    const day  = req.params.day;
    //console.log(cardId, day);
    try{ 
        CardTransaction.findAll({
            where: {
                prepaid_card_id: cardId, 
                settlement_time: {
                    [Op.gte]: moment().subtract(day, 'days').toDate()
                }
            },
            order: [
                ['settlement_time', 'DESC'],
            ],
        }).then(data => {
            res.status(200).json(data);
        })         
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.getMostUsedCards = (req, res) => {
    const allCards  = req.body.allCards;
    const limit  = req.body.limit;
    try{ 
        //console.log(allCards);
        CardTransaction.hasOne(Card, {
            sourceKey: 'prepaid_card_id',
            foreignKey: 'card_id'
        });
        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });
        CardTransaction.findAll({
            attributes: ['prepaid_card_id', 'display_card_number', [Sequelize.fn('SUM', Sequelize.col('spent_amount')), 'total_spent_amount']] ,
            include:[{
                model: Card,
                attributes: ['salesforce_id'],
                required: false,
                include: [{
                    model: Associate,
                    attributes: ['name', 'car_reg'],
                    required: false
                }]                  
            }],
            where: {
                prepaid_card_id: {
                  [Sequelize.Op.in]: allCards
                }
            },
            limit,
            group : ['prepaid_card_id'],
            order: [
                ['total_spent_amount', 'DESC'],
            ],
        }).then(data => {
            //console.log(data);
            res.status(200).json(data);
        })         
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.getUsageStatements = async (req, res) => { 
    const corporateCards = req.body.corporateCards; 
    const monthNo = req.body.monthNo;
    const monthYear = req.body.monthYear;
    try{
        CardTransaction.hasOne(Card, {
            sourceKey: 'prepaid_card_id',
            foreignKey: 'card_id'
        });
        Card.hasOne(Associate, {
            sourceKey: 'salesforce_id',
            foreignKey: 'card_id'
        });
        CardTransaction.findAll({
            include:[{
                model: Card,
                attributes: ['salesforce_id'],
                required: false,
                include: [{
                    model: Associate,
                    attributes: ['name', 'car_reg'],
                    required: false
                }]                  
            }],
            where: {
                prepaid_card_id: {
                    [Sequelize.Op.in]: corporateCards
                },
                [Op.and]: [
                    Sequelize.where(Sequelize.fn('MONTH', Sequelize.col('settlement_time')), (monthNo+1)),
                    Sequelize.where(Sequelize.fn('YEAR', Sequelize.col('settlement_time')), monthYear),
                ],
            },
            //group : ['prepaid_card_id'],
            order: [
                ['settlement_time', 'DESC'],
            ],
        }).then(data => {
            //console.log(data);
            res.status(200).json(data);
        });
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
exports.sendInvoice = async (req, res) => {
    try{ 
        Settings.findOne({
            attributes: ['smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
            where: {
                id: 1, 
            },
        }).then(async data => {
            let transporter = nodemailer.createTransport({
                host: data.smtphost,
                port: data.smtpport,
                auth: {
                    user: data.smtpuser,
                    pass: data.smtppassword
                },
            });
            var attachmentBuffer = Buffer.from(req.body.attachedFile.split("base64,")[1], "base64");
            let info = await transporter.sendMail({
                from: data.smtpfrommail,
                to: `${req.body.full_name}<${req.body.email}>`,
                subject: req.body.subject,
                html: this.nl2br(req.body.context),
                attachments: [
                    {
                        filename: req.body.filename,
                        contentType: 'application/pdf',
                        content: attachmentBuffer,
                    },
                ],
            });
            //console.log(info); 
            res.status(200).json({
                message: "Invoice successfully sent.",
                error: 0
            });
        });        
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
exports.nl2br = (str, is_xhtml) => {
    if (typeof str === 'undefined' || str === null) {
        return '';
    }
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}

exports.getUsageStatementsMonths = async (req, res) => { 
    const corporateCards = req.body.corporateCards; 
    //const count = req.body.count;
    //console.log(count);
    try{
        CardTransaction.findAll({
            attributes: [
                [Sequelize.fn('MONTHNAME', Sequelize.col('settlement_time')), 'month_name'],
                [Sequelize.fn('YEAR', Sequelize.col('settlement_time')), 'year'],
                [Sequelize.fn('MONTH', Sequelize.col('settlement_time')), 'month']
            ],
            group: [Sequelize.fn('MONTH', Sequelize.col('settlement_time')), Sequelize.fn('YEAR', Sequelize.col('settlement_time'))],
            where: {
                prepaid_card_id: {
                    [Sequelize.Op.in]: corporateCards
                },
            },
            order: [
                ['settlement_time', 'DESC'],
            ],
        }).then(data => {
            //console.log(data);
            res.status(200).json(data);
        });
    }catch(error){
        res.status(200).json({
            status: 0,
            error: error.message
        });
    }    
}
exports.saveCompanyInfo = async (req, res) => { 
    const companyInformation = req.body; 
    const endConsumerId = companyInformation.endConsumerId;
    delete companyInformation.endConsumerId;
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    //console.log(companyInformation);
    let i = 0;
    try{
        Object.keys(companyInformation).map((key) => {
            
            let filedValue = (key == 'abn' || key == 'acn') ? companyInformation[key].replace(/\s/g,'') : companyInformation[key];
            var obj = {
                field_value: filedValue,
                updated_on: totalDate
            };
            CompanyInfo.findOne({
                attributes: ['id'], 
                where: {
                    endconsumer_id: endConsumerId, 
                    field_name: key, 
                },
            }).then(data => {                
                if(data){
                    CompanyInfo.update(obj, { 
                        returning: true, 
                        where: {id: data.id}
                    })
                }else{
                    obj.endconsumer_id = endConsumerId;
                    obj.field_name = key;
                    CompanyInfo.create(obj);
                }
                i++;
                if(i == Object.keys(companyInformation).length){
                    res.status(200).json({
                        message: "Company Informations successfully updated.",
                        error: 0
                    });
                } 
            });
        });
    }catch(error){
        res.status(200).json({
            message: error.message,
            error: 1
        });
    }    
}
exports.getCompanyInfo = async (req, res) => { 
    const endConsumerId  = req.params.econ;
    CompanyInfo.findAll({ 
        where: {
            endconsumer_id: endConsumerId,
        },
    }).then(data => {            
        res.status(200).json(data); 
    });
}

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        var uploadPath = env.uploadPath;
        callback(null, path.join(__dirname, uploadPath+'/logo'));
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '_' + file.originalname);
    },
    fileFilter: function(req, file, callback) {
       if(!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
          return callback( new Error('Please upload a valid image file'))
       }

       callback(undefined, true);
    }
});
var upload = multer({ storage : storage}).single('myfile');

exports.uploadCompanyLogo = async (req, res) =>{
    upload(req,res,function(err) {
        var originalFileName = req.file.filename;

        if(err) {
            res.status(400).end("Error uploading file::"+err);
        }

        res.status(200).json(originalFileName);
    });
}
exports.getAccountInfoByEndconsumer = async (req, res) =>{
    const endConsumerId  = req.params.econ;
    try{ 
        var sf = require('node-salesforce');
        let username = env.salesforce.username
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(username, password, function(err, userInfo) {
            if (err) { console.error(err, ret).error(err); }

            conn.sobject("End_consumer__c")
            .select('account_name__c, account_name__r.Name, account_name__r.ABN__c, account_name__r.ACN__c, account_name__r.BillingStreet, account_name__r.BillingCity, account_name__r.BillingState, account_name__r.BillingPostalCode, account_name__r.BillingCountry')
            .where({
                Id: endConsumerId,
            })
            .execute(function(error, records) {
                if (error) { console.error(error); }
                res.status(200).json(records[0]);
                                
            });
            
            /*conn.query(`SELECT Id, account_name__c, account_name__r.Name, account_name__r.ABN__c, account_name__r.ACN__c, account_name__r.Billing_Country__c, account_name__r.Billing_State_Province__c, account_name__r.Billing_Street__c, account_name__r.Billing_Suburb__c, account_name__r.Billing_Zip_Postal_Code__c FROM End_consumer__c where id='${endConsumerId}'`, function(err, result) {
                if (err) { console.error(err, ret).error(err); }
                res.status(200).json(result.records[0]);
            });*/
        });         
    }catch(error) {
        console.log(error);
        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}