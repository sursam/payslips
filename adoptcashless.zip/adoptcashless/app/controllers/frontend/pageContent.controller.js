const { json } = require('body-parser');
const { QueryTypes } = require('sequelize');
const db = require('../../config/db.config.js');
const News = db.News;
const Testimonial = db.Testimonial;
const Whyus = db.Whyus;
const Company = db.Company;
const { Op } = require("sequelize");

exports.pageDetailsBySlug = async (req, res) => {
    const slug          = req.params.slug;
    let responseData    = [];
    let customFiledData    = {};
    try{

        let sql = "select cp.id, cp.pageName, cp.innerBannerImage, cp.slug, cp.pageTitle, cp.pageKeywords, cp.pageContent, cp.metaTitle, cp.metaKeyword, cp.metaDescription from cms_pages cp where cp.slug = '"+slug +"' AND cp.pageStatus=1 LIMIT 0, 1";

        const records = await db.sequelize.query(sql, { type: QueryTypes.SELECT });
        if(Array.isArray(records)) {
            let pageID = records[0]['id'];
            let sql2 = "select cm.title, cm.slug, cm.field_type, cm.meta_value from cms_metadata cm where cm.page_id = '"+pageID +"' AND cm.status='active'";
            const records2 = await db.sequelize.query(sql2, { type: QueryTypes.SELECT });          
            records2.forEach(element => customFiledData[element.slug] = element);
            responseData = records.map(object => {
                return {...object, customData: customFiledData};
            });
            //console.log(responseData)
        }
        res.status(200).json(responseData[0]);
        
    } catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.testimonial = (req, res) => {
    try{
        Testimonial.findAll({
            attributes: ['id', 'title', 'sub_title', 'name', 'slug', 'content', 'author_name', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'meta_og_url', 'order', 'status', 'created_at', 'updated_at', 'deleted_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.whyusList = (req, res) => {
    try{
        Whyus.findAll({
            attributes: ['id', 'title', 'slug', 'content', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_at', 'updated_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.companylist = (req, res) => {
    try{
        Company.findAll({
            attributes: ['id', 'companyTitle', 'slug', 'companyImage'], 
            where: {
                companyStatus: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

const getPagination = (page, size) => {
  const limit = + size;
  const offset = (page==1) ? 0 : (page-1) * limit;

  return { limit, offset };
};

const getPagingData = (data, page, limit) => {
  const { count: totalItems, rows: News } = data;

  const currentPage = page ? + page : 0;
  const totalPages = Math.ceil(totalItems / limit);

  return {totalItems, News, totalPages, currentPage };
};

exports.news = (req, res) => {

    const { page, size } = req.query;
    const { limit, offset } = getPagination(page, size);

    var condition =  {status: 1};  

    try{
        News.findAndCountAll({ where : condition, limit, offset }).then(data => {

            const response = getPagingData(data, page, limit);

            //console.log(response); return false;

            res.status(200).json(response);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.othernews = (req, res) => {
    const { page, size } = req.query;
    const { limit, offset } = getPagination(page, size);

    var condition =  {status: 1, slug: {[Op.ne]:req.query.slug,} };   

    try{
        News.findAndCountAll({ where : condition, limit, offset }).then(data => {

            const response = getPagingData(data, page, limit);

            //console.log(response); return false;

            res.status(200).json(response);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.newsdetails = (req, res) => {
  const slug  = req.params.slug;
    try{
        News.findOne({
            where: {
                slug: slug, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}

exports.listnews = (req, res) => {
    try{
        News.findAll({
            attributes: ['id', 'title', 'slug', 'sub_title', 'tags', 'short_content','content', 'featured_image', 'author', 'author_designation', 'meta_title', 'meta_keywords', 'meta_description', 'order', 'status', 'created_by', 'updated_by', 'deleted_by', 'published_at', 'created_at', 'updated_at', 'deleted_at'], 
            where: {
                status: 1, 
            },
        })
        .then(data => {
            res.status(200).json(data);
        })
    }catch(error) {
        // log on console
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}