const db = require('../../config/db.config.js');
const Contact = db.Enquiry;
const Settings = db.Settings;
const nodemailer = require("nodemailer");
const axios = require("axios");

const env = require('../../config/env.js');

exports.sendEnquiry = async (req, res) => {   

    let enquiryObject = {
        first_name: req.body.firstName,
        last_name: req.body.lastName,
        mobile_no: (req.body.phone).replace(/\s/g,''),
        email: req.body.email,
        best_contactable_time: req.body.contactableTime,
        company_name: req.body.companyName,
        trading_name: req.body.tradingName,
        abn: (req.body.abn).replace(/\s/g,''),
        acn: (req.body.acn).replace(/\s/g,''),
        address: req.body.enquiry_address,
        industry_type: req.body.industryType,
        credit_card: req.body.creditCard,
        message: req.body.message,
        is_view: '0'
    }   

    let leadObject = {
        FirstName: req.body.firstName,
        LastName: req.body.lastName,
        MobilePhone: (req.body.phone).replace(/\s/g,''),
        Email: req.body.email,
        Company: req.body.companyName,
        Name_of_Business__c: req.body.tradingName,
        ABN__c: (req.body.abn).replace(/\s/g,''),
        ACN__c: (req.body.acn).replace(/\s/g,''),
        Business_Category__c: req.body.industryType,
        Credit_Card_Terminals__c: req.body.creditCard,
        Description: req.body.message
    }
    //console.log(leadObject) 

    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    let seconds = date_ob.getSeconds(); 
    let totalDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    enquiryObject['created_on'] = totalDate;   
    try{
        Settings.findOne({
            attributes: ['helpline_email_address', 'smtphost', 'smtpport', 'secure', 'smtpuser', 'smtppassword', 'smtpfrommail'], 
            where: {
                id: 1, 
            },
        })
        .then(data => {

            let transporter = nodemailer.createTransport({
                host: data.smtphost,
                port: data.smtpport,
                auth: {
                   user: data.smtpuser,
                   pass: data.smtppassword
                },
              }); 

            try{
                var sf = require('node-salesforce');
                let password = env.salesforceLive.password + env.salesforceLive.securityToken
                var conn = new sf.Connection({
                    oauth2 : {
                        loginUrl : env.salesforceLive.loginUrl,
                        clientId : env.salesforceLive.clientId,
                        clientSecret : env.salesforceLive.clientSecret,
                        redirectUri : env.salesforceLive.redirectUri
                    }
                });
                conn.login(env.salesforceLive.username, password, function(err, userInfo) {
                    conn.sobject("Lead").create(leadObject, function(err, ret) {
                        if (err || !ret.success) { 
                            console.error(err, ret); 
                        }else{
                            enquiryObject['salesforce_id'] = ret.id;
                        }
                        //console.log("Created record id : " + ret.id);
                        
                        Contact.create(enquiryObject, 
                            {attributes: ['salesforce_id', 'first_name', 'last_name', 'email', 'best_contactable_time', 'company_name', 'trading_name', 'abn', 'acn', 'address', 'industry_type', 'credit_card', 'message', 'is_view', 'created_on']})
                        .then(async result => {  
        
                        let info = await transporter.sendMail({
                                from: data.smtpfrommail,
                                to: data.helpline_email_address,
                                subject: "New Enquiry",
                                html: "<b>Hi, </b><br><p>New Enquiry Submitted Successfully. Please check the follwoing enquiry details:</p><p>First Name : "+req.body.firstName+"</p><p>Last Name : "+req.body.lastName+"</p><p>Mobile No. : "+req.body.phone+"</p><p>Email ID : "+req.body.email+"</p><p>Best Contactable Time : "+req.body.contactableTime+"</p><p>Company Name : "+req.body.companyName+"</p><p>Trading Name : "+req.body.tradingName+"</p><p>ABN : "+req.body.abn+"</p><p>ACN : "+req.body.acn+"</p><p>Enquiry Address : "+req.body.enquiry_address+"</p><p>Industry Type : "+req.body.industryType+"</p><p>Number Of Credit Card Terminals : "+req.body.creditCard+"</p><p>Message : "+req.body.message+"</p><br><p>Thank You</p><p><b>Tap N Go</b></p>",
                              }); 
        
                            res.status(200).json({
                                message: "Your enquiry submitted successfully.",
                                slug: result.slug,
                                success: "Success",
                            });
                        });
                    });
                });
                
            }
            catch(error){
                console.log(error.message)
                res.status(200).json({
                    message: "Something wrong! Please try again.",
                    error: error.message
                });
            }

        });

        }catch(error) {
            res.status(200).json({
                message: "Error!",
                error: error.message
            });
        }
}

exports.testSalesforce = (req, res) => {
    try{ 
        var sf = require('node-salesforce');
        let password = env.salesforce.password + env.salesforce.securityToken
        var conn = new sf.Connection({
            oauth2 : {
                // you can change loginUrl to connect to sandbox or prerelease env.
                loginUrl : env.salesforce.loginUrl,
                clientId : env.salesforce.clientId,
                clientSecret : env.salesforce.clientSecret,
                redirectUri : env.salesforce.redirectUri
            }
        });
        conn.login(env.salesforce.username, password, function(err, userInfo) {
            if (err) { return console.error(err); }
            // Now you can get the access token and instance URL information.
            // Save them to establish connection next time.
            //console.log(conn.accessToken);
            //console.log(conn.instanceUrl);
            // logged in user property
            //console.log("User ID: " + userInfo.id);
            //console.log("Org ID: " + userInfo.organizationId);
            conn.query("SELECT Id, Name FROM Lead", function(err, result) {
                if (err) { return console.error(err); }
                //console.log("fetched : " + result.records.length);
                res.status(200).json(result.records);
            });
        });
         
    }catch(error) {
        console.log(error);

        res.status(500).json({
            message: "Error!",
            error: error
        });
    }
}
