const env = require('./env.js');
const nodemailer = require("nodemailer");
const salesforce= require('node-salesforce');
 
const Sequelize = require('sequelize');
const sequelize = new Sequelize(env.database, env.username, env.password, {
  host: env.host,
  dialect: env.dialect,
  //operatorsAliases: false,
  define: {
    timestamps: false
  },
  pool: {
    max: env.max,
    min: env.pool.min,
    acquire: env.pool.acquire,
    idle: env.pool.idle
  }
});
const db = {};
 
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.User = require('../models/user.model.js')(sequelize, Sequelize);
db.Cms = require('../models/cms.model.js')(sequelize, Sequelize);
db.Settings = require('../models/settings.model.js')(sequelize, Sequelize);
db.Profile = require('../models/profile.model.js')(sequelize, Sequelize);
db.News = require('../models/news.model.js')(sequelize, Sequelize);
db.Testimonial = require('../models/testimonial.model.js')(sequelize, Sequelize);
db.Enquiry = require('../models/enquiry.model.js')(sequelize, Sequelize);
db.CustomField = require('../models/customfield.model.js')(sequelize, Sequelize);
db.Banner = require('../models/banner.model.js')(sequelize, Sequelize);
db.Company = require('../models/company.model.js')(sequelize, Sequelize);
db.Whyus = require('../models/whyus.model.js')(sequelize, Sequelize);
db.Member = require('../models/member.model.js')(sequelize, Sequelize);
db.EndConsumer = require('../models/endconsumer.model.js')(sequelize, Sequelize);
db.Associate = require('../models/associate.model.js')(sequelize, Sequelize);
db.Card = require('../models/card.model.js')(sequelize, Sequelize);
db.SupportCase  = require('../models/supportcase.model.js')(sequelize, Sequelize);
db.chatHistory  = require('../models/chat.model.js')(sequelize, Sequelize);
db.PaymentRecord  = require('../models/paymentrecord.model.js')(sequelize, Sequelize);
db.AutoTopup  = require('../models/autotopup.model.js')(sequelize, Sequelize);
db.CardTransaction  = require('../models/cardTransaction.model.js')(sequelize, Sequelize);
db.PaymentSource  = require('../models/paymentSource.model.js')(sequelize, Sequelize);
db.CompanyInfo  = require('../models/companyInfo.model.js')(sequelize, Sequelize);
 
module.exports = db;