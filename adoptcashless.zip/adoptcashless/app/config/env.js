const env = {
  NODE_ENV: 'development',
  database: 'tapngo',
  /*username: 'suraj',
  password: 'UtISteOpaxm8Ep2j',
  host: '192.168.2.244',*/
  username: 'eclick',
  password: 'uN30vME0AEvq',
  host: '54.79.181.176',
  dialect: 'mysql',
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  port: 3000,
  protocol: 'http',
  siteDomain: 'localhost',
  apiDomain: 'api.localhost',
  adminDomain: 'admin.localhost',
  memberDomain: 'member.localhost',
  prepaidDomain: 'prepaid.localhost',
  mapboxToken: 'pk.eyJ1Ijoic3VyYWpzYW1hbnRhIiwiYSI6ImNsNDN6Z3QyejAwMHUzY3EzaGo2djhvbXAifQ.SThOvFEDr6nTI5cB4UIFUA',
  salesforceLive: {
    username: 'info@tapngosolutions.com.au',
    password: 'TNG@2023_',
    securityToken: 'P1z6hdPrL2ozNYvP0SDzNTtl',
    clientId: '3MVG9n_HvETGhr3CwzTYddiudZFpSj33rWE1ft3KuN9Fk5PqbSS5LcnFZGbZDSKIARK.xqIAMyg5vuS_0ytBE',
    clientSecret: 'D3F472DAD6C8266BDBBE17447E66C2682BAD0DBDE7FB4791A6FB52EFB71DD273',
    redirectUri: 'https://login.salesforce.com/services/oauth2/success',
    loginUrl: 'https://login.salesforce.com/'
  },
  /*salesforce: {
    username: 'dev@tapngosolutions.com.au.devnew',
    password: 'Admin@2022_',
    securityToken: 'vjFwo9W1IeLlXhXx02pOG3ky',
    clientId: '3MVG9mywN3hwYEwmaIC_EFLJF7wj7ZSZNjGRUseACG3DHx0isCW7igLHvSpt6CfdHApDPk7fc9_liiymoR.Mj',
    clientSecret: 'F164A43D105C638D0C85773D1088FE162B3645CEAA783D52997E28E7B440B926',
    redirectUri: 'https://test.salesforce.com/services/oauth2/success',
    loginUrl: 'https://test.salesforce.com/'
  },*/
  salesforce: {
    username: 'dev@tapngosolutions.com.au.devnew',
    password: 'Admin@2022_',
    securityToken: 'HbxlcUtImIwuOGC6WOUo4Nfp',
    clientId: '3MVG9F.30f8SspDrLLp.fOxHI_miRVvSVntk1FupN_ibxeOSdCHEXRb2KXZX9KcYtEazrjy8dmSnFOX2b2KI5',
    clientSecret: '0CADEDF473C515E0EFBAEF4E2B7B2B892AD8AD30AF870C5D256AA3963D84A3E2',
    redirectUri: 'https://test.salesforce.com/services/oauth2/success',
    loginUrl: 'https://test.salesforce.com/'
  },
  aws: {
    region: 'ap-southeast-2',
    accessKeyId: 'AKIAVW35U7K7P2IHYHUN',
    secretAccessKey: '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',
    queueURL: 'https://sqs.ap-southeast-2.amazonaws.com/392716155582/NayaxRFID_Transactions',
  },
  uploadPath: '../../../public/uploads',
  stripeCreds: {
    publishableKey: 'pk_test_51HLR1uJF2PpwlcIZlRCYa64CTq7NMiztA1DQeT117KWnsc1rdPo4W0O3WZ68Zd5XqmaSi3q69cBsl1ttVprMQLDg00lIrt6UhF',
    secretKey: 'sk_test_51HLR1uJF2PpwlcIZg4E35YWm4f06UwBIRMvDWu1P4bgb7Pol5JMkOY2nb12j2A3XOTJsVcMQL1c7wwbmyfMMkA6b00ohLk8oW1',
    currency: 'aud',
    fixedAmount: 0.3,
    domesticPercentAmount: 0.0175,
    internationalPercentAmount: 0.029
  },
  tngPercentAmount: 1.1
};
 
module.exports = env;