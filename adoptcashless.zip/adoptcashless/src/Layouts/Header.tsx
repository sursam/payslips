import React,{useState, useEffect, useContext} from 'react';
//import Link from 'next/link';
import { useRouter } from 'next/router';
import styled, { DefaultTheme } from 'styled-components';
import { LayoutHeader } from '@paljs/ui/Layout';
import { Actions } from '@paljs/ui/Actions';
import User from '@paljs/ui/User';
import { breakpointDown } from '@paljs/ui/breakpoints';
//import GlobalContext from '../components/GlobalContext';
import axios from "axios";
import Link from 'next/link';

import {
  Menu,
  MenuItem
} from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
import '@szhsin/react-menu/dist/transitions/slide.css';

const HeaderStyle = styled.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  ${breakpointDown('sm')`
    .right{
      display: none;
    }
  `}
  .right > div {
    height: auto;
    display: flex;
    align-content: center;
  }
  .logo {
    font-size: 1.25rem;
    white-space: nowrap;
    text-decoration: none;
  }
  .logo img {
    max-height: 40px;
  }
`;

interface HeaderProps {
  toggleSidebar: () => void;
  theme: {
    set: (value: DefaultTheme['name']) => void;
    value: DefaultTheme['name'];
  };
  changeDir: () => void;
  dir: 'rtl' | 'ltr';
}

const Header: React.FC<HeaderProps> = (props) => {
  const router = useRouter();
  const loggingOut = () => {
    localStorage.removeItem("authenticated");
    router.push('/login');
  };

  //const { serverUrl } = useContext(GlobalContext);
  const [logo, setLogo] = useState([]);

useEffect(() => {
  axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
    setLogo(response.data.logo);   
  });
},   

[]) 

  return (
    <LayoutHeader fixed>
      <HeaderStyle>
        <Actions
          size="Medium"
          actions={[
            {
              icon: { name: 'menu-2-outline' },
              url: {
                onClick: props.toggleSidebar,
              },
            },
            {
              content: (
                <Link href="/" target="_blank" className="logo">
                  <img src={`/uploads/logo/${logo}`} height="40" alt="Logo"/>
                </Link>
              ),
            },
          ]}
        />
        <Actions
          size="Small"
          className="right"
          actions={[
            {
              content: (
                <Menu menuButton={<div style={{ cursor: 'pointer' }}><User image="url('/assets/images/eclick-72x72.png')" name="Eclick Softwares" title="Manger" size="Medium" /></div>} transition>
                  <MenuItem href="/profile">Profile</MenuItem>
                  <MenuItem href="/change-password">Change Password</MenuItem>
                  <MenuItem onClick={loggingOut}>Logout</MenuItem>
                </Menu>
              ),
            },
          ]}
        />
      </HeaderStyle>
    </LayoutHeader>
  );
};
export default Header;
