import { MenuItemType } from '@paljs/ui/types';

const items: MenuItemType[] = [
  {
    title: 'Dashboard',
    icon: { name: 'home' },
    link: { href: '/dashboard' },
  },
  {
    title: 'FEATURES',
    group: true,
  },
  {
    title: 'CMS',
    icon: { name: 'keypad-outline' },
    children: [
      {
        title: 'Pages',
        link: { href: '/cms/pages' },
      },
      /*{
        title: 'Accordion',
        link: { href: '/extra-components/accordion' },
      },
      {
        title: 'Actions',
        link: { href: '/extra-components/actions' },
      },
      {
        title: 'Alert',
        link: { href: '/extra-components/alert' },
      },
      {
        title: 'List',
        link: { href: '/extra-components/list' },
      },
      {
        title: 'Spinner',
        link: { href: '/extra-components/spinner' },
      },
      {
        title: 'Progress Bar',
        link: { href: '/extra-components/progress' },
      },
      {
        title: 'Tabs',
        link: { href: '/extra-components/tabs' },
      },
      {
        title: 'Chat',
        link: { href: '/extra-components/chat' },
      },
      {
        title: 'Cards',
        link: { href: '/extra-components/cards' },
      },
      {
        title: 'Flip Card',
        link: { href: '/extra-components/flip-card' },
      },
      {
        title: 'Reveal Card',
        link: { href: '/extra-components/reveal-card' },
      },*/
    ],
  },
  {
    title: 'Banner',
    icon: { name: 'image-outline' },
    link: { href: '/banners' },
  },
  {
    title: 'News',
    icon: { name: 'calendar-outline' },
    link: { href: '/news' },
  },
  {
    title: 'Why Us',
    icon: { name: 'question-mark-circle-outline' },
    link: { href: '/whyus' },
  },
  {
    title: 'Company',
    icon: { name: 'credit-card-outline' },
    link: { href: '/company' },
  },
  {
    title: 'Testimonials',
    icon: { name: 'message-square-outline' },
    link: { href: '/testimonials' },
  },
  {
    title: 'Enquiries',
    icon: { name: 'email-outline' },
    link: { href: '/enquiries' },
  },
  /*{
  //   title: 'SEO',
  //   icon: { name: 'edit-2-outline' },
  //   children: [
  //     {
  //       title: 'Default & Home',
  //       link: { href: '/seo/default-home' },
  //     },
  //     {
  //       title: 'Title & Meta',
  //       link: { href: '/seo/title-meta' },
  //     },
  //   ],
  },*/
  {
    title: 'Custom Fields',
    icon: { name: 'menu-2-outline' },
    link: { href: '/custom-fields' },
  },
  {
    title: 'SITE SETTINGS',
    group: true,
  },
  {
    title: 'Settings',
    icon: { name: 'star-outline' },
    link: { href: '/site-settings' },
  },
];

export default items;
