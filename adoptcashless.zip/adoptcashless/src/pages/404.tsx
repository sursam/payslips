import React from 'react';
//import { ButtonLink } from '@paljs/ui/Button';
//import { useRouter } from 'next/router';
import Header from "../components/Front/Header/Header";
import Footer from "../components/Front/Footer/Footer";
import SEO from '../components/SEO';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import styles from '../styles/About.module.css';

export default function Error(): JSX.Element {
  //const router = useRouter();
  return (
    <section>
      <Header/>

      <SEO title="404 Page Not Found">
        <meta id="meta-description" name="description" content="404 Page Not Found" />
        <meta id="meta-keywords" name="keywords" content="404" />
      </SEO>

      <section className={styles.AboutSection}>
        <Container fluid>
            <Row>
                <Col xl={4} md={4} sm={12}>
                    <figure>
                      <img src={`/assets/images/404.png`} alt="" />
                    </figure>
                </Col>
                <Col xl={8} md={8} sm={12}>
                    <div className={styles.AboutSectioncontent}>
                      <h2>
                        <span>Oops!</span>
                        404 Page Not Found
                      </h2>
                      <div>
                        <p>The page you were looking for doesn&apos;t exist.</p>
                        {/*<ButtonLink fullWidth appearance="hero" onClick={() => router.push('/')} shape="Rectangle">
                          Take me home
                        </ButtonLink>*/}
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                      </div>
                    </div>
                </Col>
            </Row>
        </Container>
      </section>

      {/* ==================design and developers============== */}
      <section className="designDevelopersmain designDevelopersmainbottom contactcontainerbottom">
        <section className="designDevelopers">
        </section>
      </section>
      {/* ==================design and developers end============== */}
      
      <Footer/>
    </section>
  );
}
