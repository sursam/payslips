import React, {useState, useContext, useEffect} from 'react';
import styles from '../../styles/Signup.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import SEO from '../../components/SEO';

//import * as Icon from 'react-bootstrap-icons';
export default function Index() {  

  //const { serverUrl } = useContext(GlobalContext);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const router = useRouter();

  var validationSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    mobile: Yup.string().required('Mobile is required'),
    email: Yup.string().required('Email address is required'),
    // dateofbirth: Yup.string().required('Date of birth is required'),
    // businessName: Yup.string().required('Business name is required'),
    // abn: Yup.string().required('ABN number is required'),
    // companyName: Yup.string().required('Company is required'),
    // referenceNumber: Yup.string().required('Reference number is required'),
    // licenceSerialNumber: Yup.string().required('Licence serial number is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  useEffect(() => {

    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  
  [])

  
  const onSubmit = (formData:any) => {
    setshowLoader(true);
    const data = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        mobile: formData.mobile,
        email: formData.email,
        dateofbirth: formData.dateofbirth,
        businessName: formData.businessName,
        abn: formData.abn,
        companyName: formData.companyName,
        referenceNumber: formData.referenceNumber,
        licenceSerialNumber: formData.licenceSerialNumber
    }; 

    axios.post(`${process.env.serverUrl}member-signup`, data).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  

        //router.push('/otp?data='+encrypted.toString());
        router.push('/otp?data='+response.data.code);

      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.message);
      }        
    });
  };

  return (
    <section className={styles.signupMain}>
      <SEO title="Signup">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
{/* =============sign up form section================== */}
    <section className={styles.signupContainer}>
      <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                <Col xl={12} lg={12} md={6} sm={12}>
                    <div className={styles.signupFormBox}>
                        <h2>
                            <img src={'/assets/images/login-icon.png'} />
                            <span>Sign Up</span>
                        </h2>
                        <ErrorSummary errors={validationErrors} success={successMessage} />
                        <form className='enquiry-form' onSubmit={handleSubmit(onSubmit)}>

                          {/* ================Personal Details================== */}
                            <section className={styles.formGroup}>
                              <h3>Personal Details</h3>
                                    <Row>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                First Name
                                              </label>
                                              <input type="text" {...register('firstName')}  className={`form-control ${errors.firstName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.firstName?.message}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                Last Name
                                              </label>
                                              <input type="text" {...register('lastName')}  className={`form-control ${errors.lastName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.lastName?.message}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                              Mobile
                                              </label>
                                              <input type="text" {...register('mobile')}  className={`form-control ${errors.mobile ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.mobile?.message}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                Email Address
                                              </label>
                                              <input type="email" {...register('email')} className={`form-control ${errors.email ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.email?.message}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                  Date Of Birth
                                              </label>
                                              <input type="date" {...register('dateofbirth')}  className={`form-control ${errors.dateofbirth ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.dateofbirth?.message}</div>
                                          </div>
                                          
                                        </Col>
                                    </Row>
                              </section>
                      {/* ================Personal Details end================== */}

                      {/* ================Company Details================== */}
                          <section className={styles.formGroup}>
                                <h3>Company Details</h3>
                                  <Row>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                Business Name
                                            </label>
                                            <input type="text" {...register('businessName')}  className={`form-control ${errors.businessName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.businessName?.message}</div>
                                        </div>
                                        
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                ABN Number
                                            </label>
                                            <input type="text" {...register('abn')}  className={`form-control ${errors.abn ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.abn?.message}</div>
                                        </div>
                                        
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                Company Name
                                            </label>
                                            <input type="text" {...register('companyName')}  className={`form-control ${errors.companyName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.companyName?.message}</div>
                                        </div>
                                        
                                      </Col>
                                  </Row>
                            </section>
                          {/* ================Company Details================== */}

                          {/* ================Licence Details================== */}
                              <section className={styles.formGroup}>
                                  <h3>Licence Details</h3>
                                  <Row>
                                    <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                Account Reference Number
                                            </label>
                                            <input type="text" {...register('referenceNumber')}  className={`form-control ${errors.referenceNumber ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.referenceNumber?.message}</div>
                                        </div>
                                        
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                            Licence Serial Number
                                            </label>
                                            <input type="text" {...register('licenceSerialNumber')}  className={`form-control ${errors.licenceSerialNumber ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.licenceSerialNumber?.message}</div>
                                        </div>
                                        
                                      </Col>
                                  </Row>
                              </section>
                          {/* ================Licence Details================== */}
                          <Row>
                            <Col sm={12}>
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Sign Up Now </Button>
                                </div>
                            </Col>
                          </Row>

                        </form>
                        <div className={styles.loginAlt}>Already have an account? <Link legacyBehavior href={"/login"}>sign in</Link> </div>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
    </section>
  );
}