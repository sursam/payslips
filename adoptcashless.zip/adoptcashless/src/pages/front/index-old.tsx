import React from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import Link from 'next/link';

export async function getServerSideProps() {
  const pathname = '/home';
  const res = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await res.json()
  const resWhyus = await fetch(`${process.env.serverUrl}all-whyus`);
  const whyus = await resWhyus.json()
  const resCompany = await fetch(`${process.env.serverUrl}company-list`);
  const company = await resCompany.json()
  
  return {
    props: {pageData, whyus, company},
  }
}

const Home = ({pageData, whyus, company}:any) => {

  return (
    <section>
      <Header/>
        <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
          <meta id="meta-description" name="description" content={pageData.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
        </SEO>
      
        <div data-testid="Homebanner">
          <section className="HomeBanner">
                <Container fluid>
                  <Row>
                    <Col className="firstcl" xl={6} md={6} sm={12}>
                        <div className="leftContainer">
                          <h1><div dangerouslySetInnerHTML={{__html: pageData.customData.banner_title.meta_value }} /></h1>
                          <div className="paraContent">
                              <div dangerouslySetInnerHTML={{__html: pageData.customData.banner_content.meta_value }} />
                          </div>
                          <div className="ButtonGroup">
                              <Link href={pageData.customData.button_url_1.meta_value}>{pageData.customData.button_text_1.meta_value} <Icon.ArrowRight /></Link>
                              <Link href={pageData.customData.button_url_2.meta_value} className="active">{pageData.customData.button_text_2.meta_value} <Icon.ArrowRight /></Link>
                          </div>
                        </div>
                    </Col>
                    <Col xl={6} md={6} sm={12}>
                        <figure>
                          <img src={`${pageData.customData.banner_image.meta_value ? `/uploads/pages/${pageData.customData.banner_image.meta_value}` : '/assets/images/no-image.png'}`} alt="" />
                        </figure>
                    </Col>
                  </Row>
                </Container>
              </section>
            
          {/* =====================payment icon=======================   */}

          <section className='paymentIcon'>
              <Container fluid>
                {company.map((getcompany:any) => (
                  <img src={`${getcompany.companyImage ? `/uploads/company/${getcompany.companyImage}` : '/assets/images/no-image.png'}`} alt="" />
                ))}  
              </Container>
          </section>

        </div>
        {/* ==================Contact Sales============== */}
          <section className="contactSales">
              <Container fluid>
                  <Row>
                      <Col xl={6} md={6} sm={12}>
                          <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_1_2.meta_value}</span>
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.sub_title_1_2.meta_value }} />
                              </h2>
                              <div className="paraContent">
                                 <div dangerouslySetInnerHTML={{__html: pageData.customData.content_1_1.meta_value }} />
                              </div>
                              <div className="ButtonGroup">
                                  <Link href={pageData.customData.button_url_2.meta_value}>{pageData.customData.button_text_2.meta_value} <Icon.ArrowRight /></Link>
                              </div>
                          </div>
                      </Col>
                      <Col xl={6} md={6} sm={12}>
                        <figure>
                            <img src={`${pageData.customData.image_1.meta_value ? `/uploads/pages/${pageData.customData.image_1.meta_value}` : '/assets/images/no-image.png'}`} alt="" />
                        </figure>
                      </Col>
                  </Row>
              </Container>
          </section>
        {/* ==================Contact Sales end============== */}
        {/* ==================design and developers============== */}
          <section className="designDevelopersmain">
          <section className="designDevelopers">
            <Container fluid>
                <Row>
                    <Col xl={6} md={6} sm={12}>
                        <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_22.meta_value}</span>
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.sub_title_22.meta_value }} />
                              </h2>
                              <div className="paraContent">
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_2_1.meta_value }} />
                              </div>
                              <div className="ButtonGroup">
                                  <Link href={pageData.customData.button_url_22.meta_value}>{pageData.customData.button_text_22.meta_value} <Icon.ArrowRight /></Link>
                              </div>
                          </div>
                          <div className="leftContentlist">
                              <div className="listservice">
                                  <figure>
                                      <Icon.Gear />
                                  </figure>
                                  <h3>{pageData.customData.section_2_title_1.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.section_2_content_1.meta_value }} />
                                  <Link href={pageData.customData.section_2_button_url_1.meta_value}>{pageData.customData.section_2_button_text_1.meta_value} <Icon.ArrowRight /></Link>
                              </div>
                              <div className="listservice">
                                  <figure>
                                      <Icon.Lock />
                                  </figure>
                                  <h3>{pageData.customData.section_2_title_2.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.section_2_content_2.meta_value }} />
                                  <Link href={pageData.customData.section_2_button_url_2.meta_value}>{pageData.customData.section_2_button_text_2.meta_value} <Icon.ArrowRight /></Link>
                              </div>
                          </div>
                    </Col>
                    <Col xl={6} md={6} sm={12}>
                        <figure className="mapContainer">
                            <img src="/assets/images/map.png" alt="" />
                            {/* <img src="/assets/images/human.png" alt="" className="human" /> */}
                        </figure>
                    </Col>
                </Row>
            </Container>
          </section>
            <img src="/assets/images/human.png" alt="" className="human" />
          </section>
        {/* ==================design and developers end============== */}
        {/* ==================Why Tap N Go section============== */}
          <section className="aboutSection">
              <Container fluid>
                  <Row>
                    <Col xl={7} md={7} sm={12}>
                          <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_3.meta_value}</span>
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.sub_title_3.meta_value }} />
                              </h2>
                          </div>
                          <div className="ourServices">
                              {whyus.map((getwhyus:any) => (
                                <div className="listservice">
                                    <figure>
                                        <Icon.Gear />
                                    </figure>
                                    <h3>{getwhyus.title}</h3>
                                    <div dangerouslySetInnerHTML={{__html: getwhyus.content }} />
                                </div>
                              ))}  
                          </div>
                    </Col>
                    <Col xl={5} md={5} sm={12}>
                        <figure className="aboutImage">
                            <img src="/assets/images/about-img.png" alt="" />
                        </figure>
                    </Col>
                  </Row>
              </Container>
          </section>
        {/* ==================Why Tap N Go section end============== */}

         {/* ==================Contact Sales============== */}
         <section className="contactSales">
              <Container fluid>
                  <Row>
                      <Col xl={6} md={6} sm={12}>
                          <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_4.meta_value}</span>
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.sub_title_4.meta_value }} />
                              </h2>
                              <div className="paraContent">
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_4_1.meta_value }} />
                              </div>
                              <div className="ButtonGroup">
                                  <Link href={pageData.customData.button_url_4.meta_value}>{pageData.customData.button_text_4.meta_value} <Icon.ArrowRight /></Link>
                              </div>
                          </div>
                      </Col>
                      <Col xl={6} md={6} sm={12}>
                        <figure>
                            <img src={`${pageData.customData.image_4.meta_value ? `/uploads/pages/${pageData.customData.image_4.meta_value}` : '/assets/images/no-image.png'}`} alt="" />
                        </figure>
                      </Col>
                  </Row>
              </Container>
          </section>
        {/* ==================Contact Sales end============== */}

        {/* ==================design and developers============== */}
        <section className="designDevelopersmain designDevelopersmainbottom">
          <section className="designDevelopers">
            <Container fluid>
                <Row>
                    <Col xl={6} md={6} sm={12}>
                        <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_5.meta_value}</span>
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.sub_title_5.meta_value }} />
                              </h2>
                              <div className="paraContent">
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_5_1.meta_value }} />
                              </div>
                           </div>
                          <div className="leftContentlist">
                              <div className="listservice">
                                  <h3>{pageData.customData.title_6.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_6_1.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.title_7.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_7_1.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.title_8.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_8_1.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.title_9.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_9.meta_value }} />
                              </div>
                          </div>
                          <div className="paraContent">
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.content_10.meta_value }} />
                            </div>
                    </Col>
                    <Col xl={6} md={6} sm={12}>
                        <figure className="mapContainer">
                            <img src="/assets/images/map-01.png" alt="" />
                        </figure>
                    </Col>
                </Row>
            </Container>
          </section>
        </section>
        {/* ==================design and developers end============== */}
      <Footer/>
    </section>
  );
};
export default Home;