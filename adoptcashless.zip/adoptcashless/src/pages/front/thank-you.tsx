import React, {useState, useEffect, useContext} from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/About.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from "axios";
import SEO from '../../components/SEO';

export default function Index() {
const [content, setContent]:any = useState([]);
const [meta, setMeta]:any = useState([]);

useEffect(() => {
  const pathname = window.location.pathname;
  const getcontent = async() => 
    {
        axios.get(`${process.env.serverUrl}page-content${pathname}`).then((response) => {
          console.log(response.data);
        setContent(response.data); 
        setMeta(response.data);
      });
    }
    getcontent();

    }, 

  [])

  return (
    <section>
      <Header/>
        <SEO title={meta.pageTitle}>
          <meta id="meta-description" name="description" content={meta.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={meta.metaKeyword} />
        </SEO>
          {/* ==================about us section=================== */}
            <section className={styles.AboutSection}>
              <Container fluid>
                  <Row>
                      <Col xl={12} md={12} sm={12}>
                          <figure>
                              {content.innerBannerImage ? <img src={`/uploads/banner/${content.innerBannerImage}`} alt="" /> : ''}
                          </figure>
                      </Col>
                      <Col xl={12} md={12} sm={12}>
                          <div className={styles.AboutSectioncontent}>
                              <div dangerouslySetInnerHTML={{__html:content.pageContent }} />
                          </div>
                      </Col>
                  </Row>
              </Container>
            </section>
          {/* ==================about us section=================== */}
      <Footer/>
    </section>
  );
}




