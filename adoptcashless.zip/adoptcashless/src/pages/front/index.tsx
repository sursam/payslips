import React, {useState, useEffect} from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/Contact.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import SEO from '../../components/SEO';
import { useRouter } from 'next/router';
import PhoneInput from '../../components/PhoneInput';
import AbnInput from '../../components/AbnInput';
import AcnInput from '../../components/AcnInput';
import Link from 'next/link';
//import dynamic from 'next/dynamic'

import * as Icon from 'react-bootstrap-icons';

export async function getServerSideProps() {
  const pathname = '/contact';
  const res = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await res.json()
  return {
    props: {pageData},
  }
}

const Contact = ({pageData}:any) => {
  const router = useRouter();
  //const { serverUrl } = useContext(GlobalContext);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);

  /*const AddressInput = dynamic(() => import('../components/AddressInput'), {
    ssr: false,
  })*/

  const [state, setState] = useState({
    address: '',
    postal_address: '',
    helpline_no: '',
    helpline_email_address: '',
    working_hours: '',
  });

  const {address, postal_address, helpline_no, helpline_email_address, working_hours } = state;  

  var validationSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    phone: Yup.string().required('Mobile No. is required'),
    email: Yup.string().required('Email is required'),
    contactableTime: Yup.string().required('Contactable time is required'),
    companyName: Yup.string().required('Company name is required'),
    tradingName: Yup.string().required('Trading name is required'),
    abn: Yup.string().required('ABN is required'),
    acn: Yup.string().required('ACN is required'),
    enquiry_address: Yup.string().required('Address is required'),
    industryType: Yup.string().required('Industry type is required'),
    creditCard: Yup.string().required('Credit Card Terminals is required'),
    message: Yup.string().required('Message is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const [phone, setPhone] = useState('');
  const handlePhoneInput = ({ target: { value } }:any) => setPhone(value);
  
  const [abn, setAbn] = useState('');
  const handleAbnInput = ({ target: { value } }:any) => setAbn(value);

  const [acn, setAcn] = useState('');
  const handleAcnInput = ({ target: { value } }:any) => setAcn(value);

  //const [addressValue, setAddressValue] = useState('');
  //const handleAddressInput = ({ target: { value } }:any) => setAddressValue(value);

  const submitForm = () => {    
    reset(state)
  }



  
  
  useEffect(() => {

  axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
    setState(prevState => ({
    ...prevState,
    address: response.data.address,
    postal_address: response.data.postal_address,
    helpline_no: response.data.helpline_no,
    helpline_email_address: response.data.helpline_email_address,
    working_hours: response.data.working_hours,
  }));

  });

}, 









  [])

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}send-enquiry`, formData).then((response) => {
      setshowLoader(false)
      reset();
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message); 
        router.push('/thank-you'); 
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.message);
      }        
    });
  };

  
  return (
    <section>
     
        <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
          <meta id="meta-description" name="description" content={pageData.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
        </SEO>



      {/* ================================ 
      under maintenance section container part 
      =========================== */}

      <section className='UnderMaintenance'>
          <Container fluid>
              <Row>
                <Col sm={6}>
                    {/* =================== left form part start ================== */}
                      <div className='LeftFormContainer'>
                        <div>
                              <h2>{pageData.pageTitle}</h2>
                              <ErrorSummary errors={validationErrors} success={successMessage} />
                              <form className='enquiry-form' onSubmit={handleSubmit(onSubmit)}>
                                <h3>Personal Details</h3>
                                <Row>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            First Name
                                          </label>
                                          <input type="text" {...register('firstName')}  className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.firstName?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Last Name
                                          </label>
                                          <input type="text" {...register('lastName')}  className={`form-control ${errors.lastName ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.lastName?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Mobile No.
                                          </label>
                                          <PhoneInput className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                                            value={phone} 
                                            onChange={handlePhoneInput}>
                                          </PhoneInput>
                                          <input type="hidden" {...register('phone')} value={phone}/>
                                          <div className="invalid-feedback">{errors.phone?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Email
                                          </label>
                                          <input type="email" {...register('email')}  className={`form-control ${errors.email ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.email?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Best Contactable Time
                                          </label>
                                          <input type="text" {...register('contactableTime')}  className={`form-control ${errors.contactableTime ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.contactableTime?.message}</div>
                                      </div>
                                      
                                    </Col>
                                </Row>

                                <h3>Business Details</h3>
                                <Row>
                                   <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Company Name
                                          </label>
                                          <input type="text" {...register('companyName')}  className={`form-control ${errors.companyName ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.companyName?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Trading Name
                                          </label>
                                          <input type="text" {...register('tradingName')}  className={`form-control ${errors.tradingName ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.tradingName?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              ABN
                                          </label>
                                          <AbnInput className={`form-control ${errors.abn ? 'is-invalid' : ''}`}
                                            value={abn} 
                                            onChange={handleAbnInput}>
                                          </AbnInput>
                                          <input type="hidden" {...register('abn')} value={abn}/>
                                          <div className="invalid-feedback">{errors.abn?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              ACN
                                          </label>
                                          <AcnInput className={`form-control ${errors.acn ? 'is-invalid' : ''}`}
                                            value={acn} 
                                            onChange={handleAcnInput}>
                                          </AcnInput>
                                          <input type="hidden" {...register('acn')} value={acn}/>
                                          <div className="invalid-feedback">{errors.acn?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Address
                                          </label>
                                          {/*<AddressInput  
                                            {...register('enquiry_address')}                                          
                                            //value={addressValue}
                                            //onChange={handleAddressInput}
                                            className={`form-control ${errors.enquiry_address ? 'is-invalid' : ''}`}
                                          />*/}
                                          <input type="text" {...register('enquiry_address')}  className={`form-control ${errors.enquiry_address ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.enquiry_address?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={4}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Industry Type
                                          </label>
                                          <select {...register('industryType')} className={`form-control ${errors.industryType ? 'is-invalid' : ''}`}>
                                            <option value="">-- Select --</option>
                                            <option value="Car Wash">Car Wash</option>
                                            <option value="Dog Wash">Dog Wash</option>
                                            <option value="Laundromat">Laundromat</option>
                                            <option value="Vending">Vending</option>
                                            <option value="Parking">Parking</option>
                                            <option value="Others">Others</option>
                                          </select>
                                          <div className="invalid-feedback">{errors.industryType?.message}</div>
                                      </div>
                                      
                                    </Col>
                                </Row>

                                <h3>Requirements</h3>
                                <Row>
                                  <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Number Of Credit Card Terminals Required
                                          </label>
                                          <input type="text" {...register('creditCard')}  className={`form-control ${errors.creditCard ? 'is-invalid' : ''}`}  />
                                          <div className="invalid-feedback">{errors.creditCard?.message}</div>
                                      </div>
                                      
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Message
                                          </label>
                                          <textarea {...register('message')}  className={`form-control ${errors.message ? 'is-invalid' : ''}`} ></textarea>
                                          <div className="invalid-feedback">{errors.message?.message}</div>
                                      </div>
                                      
                                    </Col>
                                </Row>
                                <Row>
                                  <Col sm={12}>
                                      <div className='SubmitButton'>
                                      <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Submit </Button>
                                      </div>
                                  </Col>
                                </Row>

                              </form>
                          </div>
                          {/*<div className="cell stripeform_panel form_loader">
                            <div className="success">
                              <div className="icon">
                                <div id="loader-wrapper"><div id="loader"></div></div>
                                <svg width="84px" height="84px" viewBox="0 0 84 84" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                  <circle className="border" cx="42" cy="42" r="40" stroke-linecap="round" stroke-width="4" stroke="#000" fill="none"></circle>
                                  <path className="checkmark" stroke-linecap="round" stroke-linejoin="round" d="M23.375 42.5488281 36.8840688 56.0578969 64.891932 28.0500338" stroke-width="4" stroke="#000" fill="none"></path>
                                </svg>
                              </div>
                              <h3 className="title" data-tid="elements_examples.success.title">Auto Top-Up setup successful.</h3>
                              <Link legacyBehavior href="#"><a >
                                <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" viewBox="0 0 32 32">
                                  <g fill="#61DAFB">
                                    <path fill="#000000" d="M15,7.05492878 C10.5000495,7.55237307 7,11.3674463 7,16 C7,20.9705627 11.0294373,25 16,25 C20.9705627,25 25,20.9705627 25,16 C25,15.3627484 24.4834055,14.8461538 23.8461538,14.8461538 C23.2089022,14.8461538 22.6923077,15.3627484 22.6923077,16 C22.6923077,19.6960595 19.6960595,22.6923077 16,22.6923077 C12.3039405,22.6923077 9.30769231,19.6960595 9.30769231,16 C9.30769231,12.3039405 12.3039405,9.30769231 16,9.30769231 L16,12.0841673 C16,12.1800431 16.0275652,12.2738974 16.0794108,12.354546 C16.2287368,12.5868311 16.5380938,12.6540826 16.7703788,12.5047565 L22.3457501,8.92058924 L22.3457501,8.92058924 C22.4060014,8.88185624 22.4572275,8.83063012 22.4959605,8.7703788 C22.6452866,8.53809377 22.5780351,8.22873685 22.3457501,8.07941076 L22.3457501,8.07941076 L16.7703788,4.49524351 C16.6897301,4.44339794 16.5958758,4.41583275 16.5,4.41583275 C16.2238576,4.41583275 16,4.63969037 16,4.91583275 L16,7 L15,7 L15,7.05492878 Z M16,32 C7.163444,32 0,24.836556 0,16 C0,7.163444 7.163444,0 16,0 C24.836556,0 32,7.163444 32,16 C32,24.836556 24.836556,32 16,32 Z"></path>
                                  </g>
                                </svg>
                              </a></Link>
                            </div>
                          </div>*/}
                      </div>
                    {/* =================== left form part end ================== */}
                </Col>
                <Col sm={6}>
                    {/* =================== right part start ================== */}
                        <div className='RightFormContainer'>
                          <figure>
                              <img src="/assets/images/logo-top.png" alt="" />
                          </figure>  
                          <h1>
                            We are Under <br/> Maintenance
                            <span>Will be Back Soon!</span>
                          </h1>
                              <div className='Coninfo'>
                                  <Row>    
                                      <Col sm={4}>
                                            <aside>
                                              <div>
                                                <Icon.Envelope />
                                              </div> 
                                              <a href={`mailto:${helpline_email_address}}`}>{helpline_email_address}</a>
                                          </aside>
                                      </Col>
                                      <Col sm={4}>
                                          <aside>
                                              <div> <Icon.Telephone /></div>  <a href={`tel:${helpline_no}}`}>{helpline_no}</a>
                                          </aside>
                                      </Col>
                                      <Col sm={4}>
                                        <aside>
                                            <div><Icon.GeoAlt /> </div>  {address}
                                        </aside>
                                      </Col>
                                    </Row> 
                                </div>      
                            {/* <div className={styles.contactContent}>
                              <div>
                                <h3>
                                  <span>{pageData.customData.title_1.meta_value}</span>
                                  We are Under Maintenance
                                </h3>
                                
                                <ul className="contactInfo">
                                  <li><Icon.Envelope /> Email Address : <a href={`mailto:${helpline_email_address}}`}>{helpline_email_address}</a></li>
                                  <li><Icon.Telephone /> Phone Number : <a href={`tel:${helpline_no}}`}>{helpline_no}</a></li>
                                  <li><Icon.GeoAlt /> Office Address : {address}</li>
                                  <li><Icon.GeoAlt /> Postal Address : {postal_address}</li>
                                  <li><Icon.Clock /> Working Hours : {working_hours}</li>
                                </ul>
                            </div>
                          </div>                */}
                            
                        </div>
                    {/* =================== right part end ================== */}
                </Col>
              </Row>
          </Container>
      </section>

      {/* ================================ 
      under maintenance section container part end 
      =========================== */}









     

      
    </section>
  );
};
export default Contact;