import React, {useState, useEffect} from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/Blog.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ReactPaginate from "react-paginate";
import { format, parseISO } from 'date-fns';
import Link from 'next/link';
import SEO from '../../components/SEO';
import { useRouter } from 'next/router'
let limit = 10;

export async function getServerSideProps({ query }:any) {
  const pathname = '/news';
  const resPage = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await resPage.json()
  let currentPage = query.page ? query.page : 1;
  const res = await fetch(`${process.env.serverUrl}all-news/?page=${currentPage}&size=${limit}`);
  const newsData = await res.json()
  //console.log(newsData)
  return {
    props: { pageData, newsData },
  }
}

export default function News({pageData, newsData}:any) { 
  const router = useRouter(); 
  const [pageCount, setpageCount] = useState(0);

  useEffect(() => {
      const total = newsData.totalItems;
      setpageCount(Math.ceil(total / limit));
    }, 
  [])

  const handlePageClick = async (data:any) => {
    let currentPage = data.selected + 1;
    let queryParams = (currentPage > 1) ? `?page=${currentPage}` : '';
    router.push(`/news${queryParams}`)
  };

  return (
    <section>
      <Header/>
        <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
          <meta id="meta-description" name="description" content={pageData.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
        </SEO>
          {/* ==================blog section=================== */}
            <section className={styles.BlogSection}>
              <div className={styles.Blogmain}>
              <div className='containermain'>
                <Row>
                  <Col sm={12}>
                    <h2>
                      {pageData.pageTitle}
                      <span>{pageData.customData.sub_title4.meta_value}</span>
                    </h2>
                  </Col>  
                </Row>
              </div>
                <div>
                    <Row>
                        <Col xl={4} md={4} sm={12}>
                            <figure className='blogimage'>
                                {pageData.customData.image_3.meta_value ?<img src={`/uploads/pages/${pageData.customData.image_3.meta_value}`} alt="" /> : ''}
                            </figure>
                        </Col>
                        <Col xl={8} md={8} sm={12}>
                            <div className={styles.BlogSectionUnder}>
                                <h3>{pageData.customData.content_title.meta_value}</h3>
                                <div dangerouslySetInnerHTML={{__html: pageData.pageContent}} />
                                {/*<div className={styles.Author}>Author's Name | Date</div>*/}
                            </div>
                        </Col>
                    </Row>
                </div>
              </div>
            </section>
          {/* ==================blog us section=================== */}
          {/* ==================blog listing part=================== */}
              <section className={styles.BlogListing}>
                  <Container fluid>
                    {newsData.News.map((getnews:any) => (
                      <article>
                        <Row key={getnews.id}>
                          <Col xl={2} md={2} sm={12}>
                              <div className={styles.dateTime}>{format(parseISO(getnews.published_at), "dd LLLL Y")}</div>
                          </Col>
                          <Col xl={10} md={10} sm={12}>
                              <div className={styles.BlogContent}>
                                  <h2>
                                    {getnews.title}
                                    <span>{getnews.sub_title}</span>
                                  </h2>
                                  <p dangerouslySetInnerHTML={{__html: getnews.short_content }} />
                                  <div className={styles.buttonSec}>
                                    <Link legacyBehavior key={getnews.id} href={`/news-details/${getnews.slug}`}>Read More</Link> 
                                  </div>
                                    
                              </div>
                          </Col>
                        </Row>
                      </article>
                    ))}  
                  </Container>
                  <Container fluid>
                      <div className={styles.pagination}>
                          <ReactPaginate
                          previousLabel={"<< Previous Page "}
                          nextLabel={"Next Page >>"}
                          breakLabel={"..."}
                          pageCount={pageCount}
                          marginPagesDisplayed={2}
                          pageRangeDisplayed={3}
                          onPageChange={handlePageClick}
                          containerClassName={"pagination justify-content-center"}
                          pageClassName={"page-item"}
                          pageLinkClassName={"page-link"}
                          previousClassName={"page-item"}
                          previousLinkClassName={"page-link"}
                          nextClassName={"page-item"}
                          nextLinkClassName={"page-link"}
                          breakClassName={"page-item"}
                          breakLinkClassName={"page-link"}
                          activeClassName={"active"}
                        />
                      </div>
                  </Container>
              </section>
          {/* ==================blog listing part end=================== */}
      <Footer/>
    </section>
  );
}
