import React from 'react';
import Header from "../../../components/Front/Header/Header";
import Footer from "../../../components/Front/Footer/Footer";
import styles from '../../../styles/Blog.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useRouter } from 'next/router'
import ReactPaginate from "react-paginate";
import { format, parseISO } from 'date-fns';
import SEO from '../../../components/SEO';
import Link from 'next/link';

let limit = 10;

export async function getServerSideProps({ query }:any) {
  const resp = await fetch(`${process.env.serverUrl}news-details/${query.slug}`);
  const newsdetails = await resp.json()
  let currentPage = query.page ? query.page : 1;
  const otherRes = await fetch(`${process.env.serverUrl}other-news/?page=${currentPage}&size=${limit}&slug=${newsdetails.slug}`);
  const otherNewsData = await otherRes.json()
  const total = otherNewsData.totalItems;
  const pageCount = Math.ceil(total / limit);
  const otherNews = otherNewsData.News
  return {
    props: {newsdetails, pageCount, otherNews},
  }
}

const NewsDetailsPage = ({newsdetails, pageCount, otherNews}:any) => {
  const router = useRouter();

  const handlePageClick = async (data:any) => {
    let currentPage = data.selected + 1;
    let queryParams = (currentPage > 1) ? `?page=${currentPage}` : '';
    router.push(`/news-details/${router.query.slug}${queryParams}`)
  };

  
  return (
    <section>
      <Header/>
      <SEO title={newsdetails.title}>
          <meta id="meta-description" name="description" content={newsdetails.meta_description} />
          <meta id="meta-keywords" name="keywords" content={newsdetails.meta_keywords} />
        </SEO>
          {/* ==================blog section=================== */}
            <section className={styles.BlogSection}>
              <div className={styles.Blogmain}>
              <div>
                <Row key="11">
                  <Col sm={12} key="111">
                    <h2>
                      {newsdetails.title}
                    </h2>
                  </Col>  
                </Row>
              </div>
                <div>
                    <Row key="12">
                        <Col xl={4} md={4} sm={12} key="121">
                        {newsdetails.featured_image ?
                            <figure className='detailsimage'>
                                <img src={`/uploads/news/${newsdetails.featured_image}`} alt="" />
                            </figure>
                        : ''}    
                        </Col>
                        <Col xl={8} md={8} sm={12} key="122">
                            <div className={styles.BlogSectionUnder}>
                                <h3>{newsdetails.sub_title}</h3>
                                <div className={styles.Author}>{newsdetails.author} | {newsdetails.published_at}</div>
                                <div dangerouslySetInnerHTML={{__html: newsdetails.content}} />
                             </div>
                        </Col>
                    </Row>
                </div>
              </div>
            </section>
          {/* ==================blog us section=================== */}
          {/* ==================blog listing part=================== */}
              <section className={styles.BlogListing}>

                  <Container fluid>
                    {otherNews.map((getnews:any) => (
                      <article>
                        <Row key={getnews.id}>
                          <Col xl={2} md={2} sm={12}>
                              <div className={styles.dateTime}>{format(parseISO(getnews.published_at), "dd LLLL Y")}</div>
                          </Col>
                          <Col xl={10} md={10} sm={12}>
                              <div className={styles.BlogContent}>
                                  <h2>
                                    {getnews.title}
                                    <span>{getnews.sub_title}</span>
                                  </h2>
                                  <p dangerouslySetInnerHTML={{__html: getnews.short_content }} />
                                  <div className={styles.buttonSec}>
                                    <Link legacyBehavior key={getnews.id} href={`/news-details/${getnews.slug}`}>Read More</Link>
                                  </div>
                                    
                              </div>
                          </Col>
                        </Row>
                      </article>
                    ))}  
                  </Container>

                  <Container fluid>
                      <div className={styles.pagination}>
                          <ReactPaginate
                          previousLabel={"<< Previous"}
                          nextLabel={"Next >>"}
                          breakLabel={"..."}
                          pageCount={pageCount}
                          marginPagesDisplayed={2}
                          pageRangeDisplayed={3}
                          onPageChange={handlePageClick}
                          containerClassName={"pagination justify-content-center"}
                          pageClassName={"page-item"}
                          pageLinkClassName={"page-link"}
                          previousClassName={"page-item"}
                          previousLinkClassName={"page-link"}
                          nextClassName={"page-item"}
                          nextLinkClassName={"page-link"}
                          breakClassName={"page-item"}
                          breakLinkClassName={"page-link"}
                          activeClassName={"active"}
                        />
                      </div>
                  </Container>
                  
              </section>
          {/* ==================blog listing part end=================== */}
      <Footer/>
    </section>
  );
};
export default NewsDetailsPage;
