import React, {useState, useEffect} from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/Contact.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import SEO from '../../components/SEO';
import { useRouter } from 'next/router';
import PhoneInput from '../../components/PhoneInput';
import AbnInput from '../../components/AbnInput';
import AcnInput from '../../components/AcnInput';
//import dynamic from 'next/dynamic'

import * as Icon from 'react-bootstrap-icons';

export async function getServerSideProps() {
  const pathname = '/contact';
  const res = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await res.json()
  return {
    props: {pageData},
  }
}

const Contact = ({pageData}:any) => {
  const router = useRouter();
  //const { serverUrl } = useContext(GlobalContext);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);

  /*const AddressInput = dynamic(() => import('../components/AddressInput'), {
    ssr: false,
  })*/

  const [state, setState] = useState({
    address: '',
    postal_address: '',
    helpline_no: '',
    helpline_email_address: '',
    working_hours: '',
  });

  const {address, postal_address, helpline_no, helpline_email_address, working_hours } = state;  

  var validationSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    phone: Yup.string().required('Mobile No. is required'),
    email: Yup.string().required('Email is required'),
    contactableTime: Yup.string().required('Contactable time is required'),
    companyName: Yup.string().required('Company name is required'),
    tradingName: Yup.string().required('Trading name is required'),
    abn: Yup.string().required('ABN is required'),
    acn: Yup.string().required('ACN is required'),
    enquiry_address: Yup.string().required('Address is required'),
    industryType: Yup.string().required('Industry type is required'),
    creditCard: Yup.string().required('Credit Card Terminals is required'),
    message: Yup.string().required('Message is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const [phone, setPhone] = useState('');
  const handlePhoneInput = ({ target: { value } }:any) => setPhone(value);
  
  const [abn, setAbn] = useState('');
  const handleAbnInput = ({ target: { value } }:any) => setAbn(value);

  const [acn, setAcn] = useState('');
  const handleAcnInput = ({ target: { value } }:any) => setAcn(value);

  //const [addressValue, setAddressValue] = useState('');
  //const handleAddressInput = ({ target: { value } }:any) => setAddressValue(value);

  const submitForm = () => {    
    reset(state)
  }

  useEffect(() => {

  axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
    setState(prevState => ({
    ...prevState,
    address: response.data.address,
    postal_address: response.data.postal_address,
    helpline_no: response.data.helpline_no,
    helpline_email_address: response.data.helpline_email_address,
    working_hours: response.data.working_hours,
  }));

  });


    }, 

  [])

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}send-enquiry`, formData).then((response) => {
      setshowLoader(false)
      reset();
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message); 
        router.push('/thank-you'); 
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.message);
      }        
    });
  };

  return (
    <section>
      <Header/>
        <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
          <meta id="meta-description" name="description" content={pageData.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
        </SEO>
      {/* =============contact form section================== */}
          <section className={styles.contactForm}>
              <Container fluid>
                  <Row>
                      <Col xl={6} md={6} sm={12}>
                          <div className={styles.Leftformcontainer}>
                              <h2>{pageData.pageTitle}</h2>
                              <ErrorSummary errors={validationErrors} success={successMessage} />
                              <form className='enquiry-form' onSubmit={handleSubmit(onSubmit)}>
                                <h3>Personal Details</h3>
                                <Row>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            First Name
                                          </label>
                                          <input type="text" {...register('firstName')}  className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.firstName?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Last Name
                                          </label>
                                          <input type="text" {...register('lastName')}  className={`form-control ${errors.lastName ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.lastName?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Mobile No.
                                          </label>
                                          <PhoneInput className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                                            value={phone} 
                                            onChange={handlePhoneInput}>
                                          </PhoneInput>
                                          <input type="hidden" {...register('phone')} value={phone}/>
                                      </div>
                                      <div className="invalid-feedback">{errors.phone?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                            Email
                                          </label>
                                          <input type="email" {...register('email')}  className={`form-control ${errors.email ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.email?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Best Contactable Time
                                          </label>
                                          <input type="text" {...register('contactableTime')}  className={`form-control ${errors.contactableTime ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.contactableTime?.message}</div>
                                    </Col>
                                </Row>

                                <h3>Business Details</h3>
                                <Row>
                                   <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Company Name
                                          </label>
                                          <input type="text" {...register('companyName')}  className={`form-control ${errors.companyName ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.companyName?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Trading Name
                                          </label>
                                          <input type="text" {...register('tradingName')}  className={`form-control ${errors.tradingName ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.tradingName?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              ABN
                                          </label>
                                          <AbnInput className={`form-control ${errors.abn ? 'is-invalid' : ''}`}
                                            value={abn} 
                                            onChange={handleAbnInput}>
                                          </AbnInput>
                                          <input type="hidden" {...register('abn')} value={abn}/>
                                      </div>
                                      <div className="invalid-feedback">{errors.abn?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              ACN
                                          </label>
                                          <AcnInput className={`form-control ${errors.acn ? 'is-invalid' : ''}`}
                                            value={acn} 
                                            onChange={handleAcnInput}>
                                          </AcnInput>
                                          <input type="hidden" {...register('acn')} value={acn}/>
                                      </div>
                                      <div className="invalid-feedback">{errors.acn?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Address
                                          </label>
                                          {/*<AddressInput  
                                            {...register('enquiry_address')}                                          
                                            //value={addressValue}
                                            //onChange={handleAddressInput}
                                            className={`form-control ${errors.enquiry_address ? 'is-invalid' : ''}`}
                                          />*/}
                                          <input type="text" {...register('enquiry_address')}  className={`form-control ${errors.enquiry_address ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.enquiry_address?.message}</div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Industry Type
                                          </label>
                                          <select {...register('industryType')} className={`form-control ${errors.industryType ? 'is-invalid' : ''}`}>
                                            <option value="">-- Select --</option>
                                            <option value="Car Wash">Car Wash</option>
                                            <option value="Dog Wash">Dog Wash</option>
                                            <option value="Laundromat">Laundromat</option>
                                            <option value="Vending">Vending</option>
                                            <option value="Parking">Parking</option>
                                            <option value="Others">Others</option>
                                          </select>
                                      </div>
                                      <div className="invalid-feedback">{errors.industryType?.message}</div>
                                    </Col>
                                </Row>

                                <h3>Requirements</h3>
                                <Row>
                                  <Col sm={12}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Number Of Credit Card Terminals Required
                                          </label>
                                          <input type="text" {...register('creditCard')}  className={`form-control ${errors.creditCard ? 'is-invalid' : ''}`}  />
                                      </div>
                                      <div className="invalid-feedback">{errors.creditCard?.message}</div>
                                    </Col>
                                    <Col sm={12}>
                                      <div className={styles.formgroup}>
                                          <label>
                                              Message
                                          </label>
                                          <textarea {...register('message')}  className={`form-control ${errors.message ? 'is-invalid' : ''}`} ></textarea>
                                      </div>
                                      <div className="invalid-feedback">{errors.message?.message}</div>
                                    </Col>
                                </Row>
                                <Row>
                                  <Col sm={12}>
                                      <div className={styles.SubmitButton}>
                                      <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Submit </Button>
                                      </div>
                                  </Col>
                                </Row>

                              </form>
                          </div>
                      </Col>
                      <Col xl={6} md={6} sm={12}>
                          <div className={styles.contactContent}>
                              <div>
                                <h3>
                                  <span>{pageData.customData.title_1.meta_value}</span>
                                  {pageData.customData.sub_title_1.meta_value}
                                </h3>
                                <div dangerouslySetInnerHTML={{__html: pageData.pageContent }} />
                                <ul className="contactInfo">
                                  <li><Icon.Envelope /> Email Address : <a href={`mailto:${helpline_email_address}}`}>{helpline_email_address}</a></li>
                                  <li><Icon.Telephone /> Phone Number : <a href={`tel:${helpline_no}}`}>{helpline_no}</a></li>
                                  <li><Icon.GeoAlt /> Office Address : {address}</li>
                                  <li><Icon.GeoAlt /> Postal Address : {postal_address}</li>
                                  <li><Icon.Clock /> Working Hours : {working_hours}</li>
                                </ul>
                            </div>
                            
                          </div>
                      </Col>
                  </Row>
              </Container>
          </section>
      {/* =============contact form section end================== */}


       {/* ==================design and developers============== */}
       <section className="designDevelopersmain designDevelopersmainbottom contactcontainerbottom">
          <section className="designDevelopers">
            <Container fluid>
                <Row>
                    <Col xl={6} md={6} sm={12}>
                        <div className="leftContentSales">
                              <h2>
                                <span>{pageData.customData.title_2.meta_value}</span>
                               {pageData.customData.sub_title_2.meta_value}
                              </h2>
                              <div className="paraContent">
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_2.meta_value }} />
                              </div>
                           </div>
                          <div className="leftContentlist">
                              <div className="listservice">
                                  <h3>{pageData.customData.text_1.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_3.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.text_2.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_4.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.text_3.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_5.meta_value }} />
                              </div>
                              <div className="listservice">
                                  <h3>{pageData.customData.text_4.meta_value}</h3>
                                  <div dangerouslySetInnerHTML={{__html: pageData.customData.content_6.meta_value }} />
                              </div>
                          </div>
                          <div className="paraContent">
                                <div dangerouslySetInnerHTML={{__html: pageData.customData.content_7.meta_value }} />
                            </div>
                    </Col>
                    <Col xl={6} md={6} sm={12}>
                        <figure className="mapContainer">
                            <img src="/assets/images/map-01.png" alt="" />
                        </figure>
                    </Col>
                </Row>
            </Container>
          </section>
        </section>
        {/* ==================design and developers end============== */}
      <Footer/>
    </section>
  );
};
export default Contact;
