import React from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/About.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../components/SEO';

export async function getServerSideProps() {
  const pathname = '/about';
  const res = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await res.json()
  
  const resTestimonial = await fetch(`${process.env.serverUrl}all-testimonial`);
  const testimonial = await resTestimonial.json()
  //console.log(pageData)
  return {
    props: {pageData, testimonial},
  }
}

const About = ({pageData, testimonial}:any) => {

  return (
    <section>
      <Header/>
        <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
          <meta id="meta-description" name="description" content={pageData.metaDescription} />
          <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
        </SEO>
          {/* ==================about us section=================== */}
            <section className={styles.AboutSection}>
              <Container fluid>
                  <Row>
                      <Col xl={4} md={4} sm={12}>
                          <figure>
                              {pageData.customData.image.meta_value ?<img src={`/uploads/pages/${pageData.customData.image.meta_value}`} alt="" /> : ''}
                          </figure>
                      </Col>
                      <Col xl={8} md={8} sm={12}>
                          <div className={styles.AboutSectioncontent}>
                          <h2>
                                <span>{pageData.pageTitle}</span>
                                {pageData.customData.sub_title_11.meta_value}
                              </h2>
                              <div dangerouslySetInnerHTML={{__html: pageData.pageContent }} />
                          </div>
                      </Col>
                  </Row>
              </Container>
            </section>
          {/* ==================about us section=================== */}
          {/* ==================Testimonials section============== */}
            <div className="Testimonialsmain">
              <section className={styles.Testimonials}>
                <Container fluid>
                    <Row>
                        <Col>
                          <h2>
                            <span>{pageData.customData.title_21.meta_value}</span>
                            {pageData.customData.sub_title_21.meta_value}
                          </h2>
                      </Col>
                    </Row>
                </Container>
                <Container fluid>
                    <Row>
                    {testimonial.map((gettestimonial:any) => (
                      <Col xl={4} md={4} sm={12} key={gettestimonial.id}>
                          <aside>
                          <div dangerouslySetInnerHTML={{__html: gettestimonial.content }} />
                          </aside>
                      </Col>
                      ))}
                    </Row>
                </Container>
              </section>
            </div>
           
        {/* ==================Testimonials section end============== */}


      <Footer/>
    </section>
  );
};
export default About;

