import React from 'react';
import Header from "../../components/Front/Header/Header";
import Footer from "../../components/Front/Footer/Footer";
import styles from '../../styles/About.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../components/SEO';

export async function getServerSideProps() {
  const pathname = '/shop';
  const res = await fetch(`${process.env.serverUrl}page-content${pathname}`);
  const pageData = await res.json()
  return {
    props: {pageData},
  }
}

const Shop = ({pageData}:any) => {

  return (
    <section>
      <Header/>
          <SEO title={pageData.metaTitle ? pageData.metaTitle : pageData.pageTitle}>
            <meta id="meta-description" name="description" content={pageData.metaDescription} />
            <meta id="meta-keywords" name="keywords" content={pageData.metaKeyword} />
          </SEO>
          {/* ==================product section=================== */}
          <section className={styles.AboutSection}>
              <Container fluid>
                  <Row>
                      <Col xl={12} md={12} sm={12}>
                        <h2>{pageData.pageTitle}</h2>
                        <figure className="comingsoonimage">
                            {pageData.customData.image5.meta_value ?<img src={`/uploads/pages/${pageData.customData.image5.meta_value}`} alt="" /> : ''}
                        </figure>
                      </Col>
                  </Row>
              </Container>
            </section>
          {/* ==================product section=================== */}

          {/* ==================design and developers============== */}
             <section className="designDevelopersmain designDevelopersmainbottom contactcontainerbottom">
                <section className="designDevelopers">
                  <Container fluid>
                      <Row>
                          <Col xl={6} md={6} sm={12}>
                              <div className="leftContentSales">
                                    <h2>
                                      <span>{pageData.customData.section_title.meta_value}</span>
                                     <div dangerouslySetInnerHTML={{__html: pageData.customData.section_sub_title.meta_value }} />
                                    </h2>
                                    <div className="paraContent">
                                        <div dangerouslySetInnerHTML={{__html: pageData.customData.section_content.meta_value }} />
                                    </div>
                                 </div>
                                <div className="leftContentlist">
                                    <div className="listservice">
                                        <h3>{pageData.customData.section_title_1.meta_value}</h3>
                                        <div dangerouslySetInnerHTML={{__html: pageData.customData.section_content_1.meta_value }} />
                                    </div>
                                    <div className="listservice">
                                        <h3>{pageData.customData.section_title_2.meta_value}</h3>
                                        <div dangerouslySetInnerHTML={{__html: pageData.customData.section_content_2.meta_value }} />
                                    </div>
                                    <div className="listservice">
                                        <h3>{pageData.customData.section_title_3.meta_value}</h3>
                                        <div dangerouslySetInnerHTML={{__html: pageData.customData.section_content_3.meta_value }} />
                                    </div>
                                    <div className="listservice">
                                        <h3>{pageData.customData.section_title_4.meta_value}</h3>
                                        <div dangerouslySetInnerHTML={{__html: pageData.customData.section_content_4.meta_value }} />
                                    </div>
                                </div>
                                <div className="paraContent">
                                      <div dangerouslySetInnerHTML={{__html: pageData.customData.section_footer_content.meta_value }} />
                                  </div>
                          </Col>
                          <Col xl={6} md={6} sm={12}>
                              <figure className="mapContainer">
                                  <img src="/assets/images/map-01.png" alt="" />
                              </figure>
                          </Col>
                      </Row>
                  </Container>
                </section>
              </section>
        {/* ==================design and developers end============== */}
      <Footer/>
    </section>
  );
};
export default Shop;