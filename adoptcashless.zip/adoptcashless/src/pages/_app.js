import '../styles/admin-style.css';
import '../styles/custom-style.css';
import { useRouter } from 'next/router';
import { useState,useEffect } from 'react'
import GlobalContext from '../components/GlobalContext';
import LoadingScreen from "../components/loadingScreen";
//import LoadingSpinner from "../components/loadingSpinner";

function Loading() {
  const router = useRouter();
  
  const [loading, setLoading] = useState(false);

  useEffect(() => {
      const handleStart = (url) => (url !== router.asPath) && setLoading(true);
      const handleComplete = (url) => setLoading(false);
      //const handleComplete = (url) => (url === router.asPath) && setTimeout(() =>{setLoading(false)},5000);

      router.events.on('routeChangeStart', handleStart)
      router.events.on('routeChangeComplete', handleComplete)
      router.events.on('routeChangeError',  handleComplete)

      return () => {
          router.events.off('routeChangeStart', handleStart)
          router.events.off('routeChangeComplete', handleComplete)
          router.events.off('routeChangeError', handleComplete)
      }
  })
  
  return loading && (<LoadingScreen />)
}

// This default export is required in a new `pages/_app.js` file.
export default function MyApp({ Component, pageProps }) {
  const env = require('../../app/config/env.js');
  return <GlobalContext.Provider value={{ ...env }}>
          <Loading/>
          <Component {...pageProps} />
        </GlobalContext.Provider>
}

