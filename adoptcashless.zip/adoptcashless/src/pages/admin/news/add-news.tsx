import React from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPlusCircle, FaListAlt } from 'react-icons/fa';
import NewsForm from '../../../components/Admin/NewsForm';

const AddNews = () => { 

  return (
    <Layout title="Add News">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPlusCircle /> Add News 
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/news">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              <NewsForm dataVal="" />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default AddNews;
