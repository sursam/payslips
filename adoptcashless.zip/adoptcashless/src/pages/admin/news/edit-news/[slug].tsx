import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPencilAlt, FaListAlt } from 'react-icons/fa';
import NewsForm from '../../../../components/Admin/NewsForm';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}news-details/${query.slug}`);
  const newsData = await res.json()
  return {
    props: {newsData},
  }
}

const EditNews = ({newsData}:any) => { 
  return (
    <Layout title="Edit News">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPencilAlt /> Edit News: {newsData.title}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/news">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {newsData.id ? <NewsForm dataVal={newsData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditNews;
