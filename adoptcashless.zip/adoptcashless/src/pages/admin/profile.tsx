import React, {useContext, useState, useEffect} from 'react';
import Layout from '../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
/*import Link from 'next/link';*/
import { /*FaPlusCircle, FaListAlt,*/ FaPencilAlt } from 'react-icons/fa';
import { useRouter } from 'next/router';
import ErrorSummary from '../../components/errorSummary';
/*import dynamic from "next/dynamic";*/
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { InputGroup } from '@paljs/ui/Input';
import { Button } from "@material-ui/core";
import axios from "axios";
import Loader from '../../components/loader';

const SiteSettingsForm = () => { 
  const router = useRouter();
  /*const JoditEditor = dynamic(() => import("jodit-react"), { ssr: false });
  const [data, setData]:any = useState({});*/

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, getImageName] = useState(false);

  const [state, setState] = useState({
    id: '',
    username: '',
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    user_profile_pic: '',
  });

  const { id, username, first_name, last_name, phone, email, user_profile_pic} = state;

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    //alert(name);
    setState(prevState => ({
      ...prevState,
      [name] : value,
    }));

  };

  var validationSchema = Yup.object().shape({
    username: Yup.string().required('Site title is required'),
    first_name: Yup.string().required('First name is required'),
    last_name: Yup.string().required('Last is required'),
    phone: Yup.string().required('Phone is required'),
  });

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  useEffect(() => { 
    axios.get(`${process.env.serverUrl}profile/`,{}).then((response) => {
      //setData(response.data);
        //alert(response.data.first_name);
      setState(prevState => ({
      ...prevState,
      id: response.data.id,
      username: response.data.username,
      first_name: response.data.first_name,
      last_name: response.data.last_name,
      phone: response.data.phone,
      email: response.data.email,
      user_profile_pic: response.data.user_profile_pic,
    }));

    });
  }, [])

    const submitForm = () => {    
    reset(state)
  }

    const onUploadHandler = (event:any)=>{
     const data = new FormData();

      data.append('myfile', event.target.files[0]);

    axios.post(`${process.env.serverUrl}upload-profile-image`, data).then((response) => { 
      getImageName(response.data);
   });
  };

    const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-profile`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  return (
    <Layout title="Profile">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 12 }}> 
                  <FaPencilAlt /> Profile
                </Col>
              </Row>
            </header> 
            <CardBody>
              <ErrorSummary errors={validationErrors} success={successMessage} />
              <form className='settings-form' onSubmit={handleSubmit(onSubmit)}>
                <Row>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={username}>Username</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('username')} value={username} onChange={handleChange} placeholder="Site Title" className={`form-control ${errors.username ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.username?.message}</div>
                  </Col>
                   <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}></Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={first_name}>First Name</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('first_name')} value={first_name} onChange={handleChange} placeholder="First Name" className={`form-control ${errors.first_name ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.first_name?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={last_name}>Last Name</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('last_name')} value={last_name} onChange={handleChange} placeholder="Last Name" className={`form-control ${errors.last_name ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.last_name?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={phone}>Phone No.</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('phone')} value={phone} onChange={handleChange} placeholder="Phone No." className={`form-control ${errors.phone ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.phone?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={email}>Email ID</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('email')} value={email} onChange={handleChange} placeholder="Email ID" className={`form-control ${errors.email ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.email?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={user_profile_pic}>Profile Image</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="file" name="myfile" onChange={onUploadHandler} className={`form-control ${errors.setImage ? 'is-invalid' : ''}`} />
                      <input type="hidden" {...register('profile_pic')} id="user_profile_pic" value={`${imageName ? imageName : user_profile_pic}`} />
                    </InputGroup>

                     <img className="prevImg" src = {`${imageName ? `/uploads/profile/${imageName}` : user_profile_pic ? `/uploads/profile/${user_profile_pic}` : '/assets/images/no-image.png' }` } />
                  </Col>  
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
                    <input type="hidden" name="id" value={id} />
                    <Button color="primary"
                      variant="contained"
                      type="submit"
                      onClick={submitForm} 
                      //onClick={() => reset()} 
                      disabled={showLoader} >
                      { showLoader ? <Loader /> : null } Submit
                    </Button>
                  </Col>
                  
                </Row>
              </form>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default SiteSettingsForm;
