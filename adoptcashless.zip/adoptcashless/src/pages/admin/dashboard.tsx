import { Card, CardBody } from '@paljs/ui/Card';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import React from 'react';
import Layout from '../../Layouts';
import Link from 'next/link';
import { FaEnvelope, FaQuoteLeft, FaIndustry, FaInfoCircle, FaQuestionCircle, FaBars } from 'react-icons/fa';

const Dashboard = () => {

  return (
    <Layout title="Dashboard">
      <Row>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="red">
          <Card>
            <header><FaBars /> <span>CMS Pages</span></header>
            <CardBody>
              <Row>
                <Link legacyBehavior href={"/cms/pages/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="blue">
          <Card>
            <header><FaQuestionCircle /> <span>Why Us</span></header>
            <CardBody>
              <Row>
                <Link legacyBehavior href={"/whyus/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="yellow">
          <Card>
            <header><FaInfoCircle /> <span>News</span></header>
            <CardBody>
              <Row>
                <Link legacyBehavior href={"/news/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="green">
          <Card>
            <header><FaIndustry /> <span>Company</span></header>
            <CardBody>
              <Row>
                <Link legacyBehavior href={"/company/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="cyan">
          <Card>
            <header><FaQuoteLeft /> <span>Testimonials</span></header>
            <CardBody>
              <Row>
                <Link legacyBehavior href={"/testimonials/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

        <Col breakPoint={{ xs: 12, lg: 2 }} className="indigo">
          <Card>
            <header><FaEnvelope /> <span>Enquiries</span></header>
            <CardBody>
              <Row>
              <Link legacyBehavior href={"/enquiries/"}><a className='dashboardData'>View More</a></Link>
              </Row>
            </CardBody>
          </Card>
        </Col>

      </Row>
    </Layout>
  );
};
export default Dashboard;
