import { Button } from '@paljs/ui/Button';
import { InputGroup } from '@paljs/ui/Input';
import React, { useEffect, useState, useContext } from 'react';
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import Link from 'next/link';
//import Alert from '@paljs/ui/Alert'
import axios from "axios";
import Auth, { Group } from '../../components/Auth';
//import Socials from '../../components/Auth/Socials';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import Layout from '../../Layouts';

export default function resetPassword() {
  const router = useRouter();
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false)
  const [username, setusername] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberUsername')) || '';
  });

  // useEffect(() => {
  //   const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated')) || 0
  //   if(authenticated){
  //     router.push('/send-password-link');
  //   }  
  // }, [])  
  
  const validationSchema = Yup.object().shape({
      username: Yup.string()
          .required('Email address is required')
          .email('Email is invalid'),
  });
  
  const formOptions = { resolver: yupResolver(validationSchema) };
  const { register, handleSubmit, formState: { errors } } = useForm(formOptions);
  const onSubmit = (formData:any) => {
    setshowLoader(true);
    const data = {
      username: formData.username,
    };

    axios.post(`${process.env.serverUrl}admin-request-password`, data).then((response) => {
      setshowLoader(false);
      setsuccessMessage(null);

      if(!response.data.error){
        localStorage.setItem("authenticated", response.data.status);
        router.push('/send-password-link');
      }else{
        setvalidationErrors(response.data.error);
      }  

    });
  };    


  return (
    <Layout title="Forgot Password">
      <Auth title="" subTitle="Enter your email address and we’ll send a link to reset your password">
        <ErrorSummary errors={validationErrors} success={successMessage}/>
        <form onSubmit={handleSubmit(onSubmit)}>
          <InputGroup className='form-group' fullWidth>
            <input type="email" {...register('username')} value={username} onChange={event => setusername(event.target.value)} placeholder="Email Address" className={`form-control ${errors.username ? 'is-invalid' : ''}`} />
            <div className="invalid-feedback">{errors.username?.message}</div>
          </InputGroup>
          <Group>
            <Link legacyBehavior href="/login">
              <a>Back to Login</a>
            </Link>
          </Group>
          <Button status="Success" type="submit" shape="SemiRound" disabled={showLoader} fullWidth>
            { showLoader ? <Loader /> : null } Submit
          </Button>
        </form>        
      </Auth>
    </Layout>
  );
}
