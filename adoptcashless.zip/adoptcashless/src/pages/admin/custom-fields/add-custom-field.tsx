import React from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPlusCircle, FaListAlt } from 'react-icons/fa';
import CustomFieldForm from '../../../components/Admin/CustomFieldForm';

const AddCustomField = () => { 

  return (
    <Layout title="Add Custom Field">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPlusCircle /> Add Custom Field 
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/custom-fields">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              <CustomFieldForm dataVal="" />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default AddCustomField;
