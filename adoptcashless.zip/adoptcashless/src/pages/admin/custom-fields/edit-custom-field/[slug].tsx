import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPencilAlt, FaListAlt } from 'react-icons/fa';
import CustomFieldForm from '../../../../components/Admin/CustomFieldForm';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}custom-field-details/${query.slug}`);
  const fieldData = await res.json()
  return {
    props: {fieldData},
  }
}

const EditCustomField = ({fieldData}:any) => { 
  return (
    <Layout title="Edit Custom Field">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPencilAlt /> Edit Custom Field: {fieldData.title}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/custom-fields">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {fieldData.id ? <CustomFieldForm dataVal={fieldData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditCustomField;
