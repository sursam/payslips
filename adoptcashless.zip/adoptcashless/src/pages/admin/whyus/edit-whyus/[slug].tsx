import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPencilAlt, FaListAlt } from 'react-icons/fa';
import WhyUsForm from '../../../../components/Admin/WhyUsForm';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}whyus-details/${query.slug}`);
  const whyusData = await res.json()
  return {
    props: {whyusData},
  }
}

const EditWhyUs = ({whyusData}:any) => { 
  return (
    <Layout title="Edit Why Us">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPencilAlt /> Edit Why Us: {whyusData.title}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/whyus">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {whyusData.id ? <WhyUsForm dataVal={whyusData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditWhyUs;
