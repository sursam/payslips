import React from 'react';
/*import { useRouter } from 'next/router';*/
import Link from 'next/link';
//import Alert from '@paljs/ui/Alert'

import Auth, { Group } from '../../components/Auth';
//import Socials from '../../components/Auth/Socials';
import Layout from '../../Layouts';

export default function resetPasswordURL() {
  return (
    <Layout title="Forgot Password">
      <Auth title="" subTitle="Password reset  url send to your email.">
          <Group>
            <Link legacyBehavior href="/login">
              <a>Back to Login</a>
            </Link>
          </Group>       
      </Auth>
    </Layout>
  );
}
