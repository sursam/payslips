import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaEye, FaListAlt } from 'react-icons/fa';
import EnquiryDetailsView from '../../../../components/Admin/EnquiryDetails';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}enquiry-details/${query.id}`);
  const enquiryData = await res.json()
  return {
    props: {enquiryData},
  }
}

const EnquiryDetails = ({enquiryData}:any) => { 
  return (
    <Layout title="Enquiry Details">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaEye /> Enquiry Details: {enquiryData.title}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/enquiries">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {enquiryData.id ? <EnquiryDetailsView dataVal={enquiryData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EnquiryDetails;
