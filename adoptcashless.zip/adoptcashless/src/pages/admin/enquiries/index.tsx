import React, {useState, useContext} from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
//import SmartDataTable from 'react-smart-data-table'
import DataTable from 'react-data-table-component';
import axios from "axios";
import Link from 'next/link';
import Moment from 'moment';
import {FaEye, FaTrashAlt} from 'react-icons/fa';
import ErrorSummary from '../../../components/errorSummary';

const News = () => {
  const columns = [
    {
        name: 'First Name',
        selector: (row:any) => row.first_name,
        sortable: true,
    },
    {
        name: 'Last Name',
        selector: (row:any) => row.last_name,
        sortable: true,
    },
    {
        name: 'Email',
        selector: (row:any) => row.email,
        sortable: true,
    },
    {
        name: 'Added Date',
        selector: (row:any) => Moment(row.created_on).format('DD-MM-YYYY h:mm a'),
        sortable: true,
    },
    {
      name: "Action",
      button: true,
      sortable: false,
      cell: (row:any) => [
        <Link legacyBehavior href={`/enquiries/enquiry-details/${row.id}`}>
          <a className="view-btn"><FaEye /></a>
        </Link>,
        <Link legacyBehavior href="#">
          <a className="delete-btn" data-id={row.id} onClick={e => handleDelete(e)}><FaTrashAlt /></a>
        </Link>             
      ]
    }
  ];
  const [data, setData] = useState([]);
  
  React.useEffect(() => {
    axios.get(`${process.env.serverUrl}enquiry`).then((response) => {
      setData(response.data);      
    });
  }, []);  

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);

  const handleDelete = async (e:any) => {
    let rowId = e.currentTarget.getAttribute("data-id");
    const confirmBox = window.confirm(
      "Do you really want to delete this row?"
    )
    if (confirmBox === true) {
      axios.post(`${process.env.serverUrl}delete-enquiry`, {id: rowId}).then((response) => {
        if(!response.data.error){
          setvalidationErrors(null);
          setsuccessMessage(response.data.message);
          var index = data.findIndex(obj => obj['id'] == rowId);
          setData(data.filter((_v, i) => i !== index));
        }else{
          setsuccessMessage(null);
          setvalidationErrors(response.data.error);
        }        
      });
    }    
  }  

  return (
    <Layout title="Enquiries">
     <ErrorSummary errors={validationErrors} success={successMessage} />
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 12 }}> 
                  Enquiries
                </Col>
              </Row>
            </header> 
            <CardBody>
              <DataTable
                pagination
                columns={columns}
                data={data}
                selectableRows
              />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default News;
