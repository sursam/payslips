import React from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card } from '@paljs/ui/Card';

const EditBanner = () => { 
  /*const router = useRouter();
  const { serverUrl } = useContext(GlobalContext);
  const [data, setData]:any = useState({});
  useEffect(() => {
    if(!router.isReady) return;    
    axios.post(`${serverUrl}api/banner-details/`,{
      slug: router.query.slug
    }).then((response) => {
      setData(response.data);    
    });
  }, [router.isReady])*/
  return (
    <Layout title="Edit Banner">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditBanner;
