import React, {useContext, useState, useEffect} from 'react';
import Layout from '../../Layouts';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Card, CardBody } from '@paljs/ui/Card';
/*import Link from 'next/link';*/
import { /*FaPlusCircle, FaListAlt,*/ FaPencilAlt } from 'react-icons/fa';
import { useRouter } from 'next/router';
import ErrorSummary from '../../components/errorSummary';
/*import dynamic from "next/dynamic";*/
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { InputGroup } from '@paljs/ui/Input';
import { Button, Select } from "@material-ui/core";
import axios from "axios";
import Loader from '../../components/loader';

const SiteSettingsForm = () => { 
  const router = useRouter();
  /*const JoditEditor = dynamic(() => import("jodit-react"), { ssr: false });
  const [data, setData]:any = useState({});*/

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, getImageName] = useState(false);

  const [state, setState] = useState({
    id: '',
    site_title: '',
    address: '',
    postal_address: '',
    helpline_no: '',
    helpline_email_address: '',
    working_hours: '',
    logo: '',
    twitter_link: '',
    facebook_link: '',
    instagram_link : '',
    youtube_link : '',
    smtphost: '',
    smtpport: '',
    secure: '',
    smtpuser: '',
    smtppassword : '',
    smtpfrommail : '',
  });

  const { id, site_title, address, postal_address, helpline_no, helpline_email_address,working_hours, logo, twitter_link, facebook_link,instagram_link, youtube_link, smtphost, smtpport, secure, smtpuser, smtppassword, smtpfrommail } = state;

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    //alert(name);
    setState(prevState => ({
      ...prevState,
      [name] : value,
    }));

  };

  var validationSchema = Yup.object().shape({
    site_title: Yup.string().required('Site title is required'),
    address: Yup.string().required('Site address is required'),
    helpline_no: Yup.string().required('Site contact no. is required'),
    helpline_email_address: Yup.string().required('Site email is required'),
    smtphost: Yup.string().required('SMTP host is required'),
    smtpport: Yup.string().required('SMTP port is required'),
    secure: Yup.string().required('SMTP secure is required'),
    smtpuser: Yup.string().required('SMTP user is required'),
    smtppassword: Yup.string().required('SMTP password is required'),
    smtpfrommail: Yup.string().required('SMTP from mail is required'),
  });

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  useEffect(() => { 
    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
      //setData(response.data);

    setState(prevState => ({
      ...prevState,
      id: response.data.id,
      site_title: response.data.site_title,
      address: response.data.address,
      postal_address: response.data.postal_address,
      helpline_no: response.data.helpline_no,
      working_hours: response.data.working_hours,
      helpline_email_address: response.data.helpline_email_address,
      logo: response.data.logo,
      twitter_link: response.data.twitter_link,
      facebook_link: response.data.facebook_link,
      instagram_link: response.data.instagram_link,
      youtube_link: response.data.youtube_link,
      smtphost: response.data.smtphost,
      smtpport: response.data.smtpport,
      secure: response.data.secure,
      smtpuser: response.data.smtpuser,
      smtppassword: response.data.smtppassword,
      smtpfrommail: response.data.smtpfrommail
    }));

    });
  }, [])

    const submitForm = () => {    
    reset(state)
  }

  const onUploadHandler = (event:any) => {
     const data = new FormData();

      data.append('myfile', event.target.files[0]);

    axios.post(`${process.env.serverUrl}upload-logo`, data).then((response) => { 
      getImageName(response.data);
   });
  };

    const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-settings`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  return (
    <Layout title="Site Settings">
      <Row>
        <Col xs={12} lg={12}>
          <Card>
            <header>
              <Row>
                <Col xs={12} lg={12}> 
                  <FaPencilAlt /> Site Settings
                </Col>
              </Row>
            </header> 
            <CardBody>
              <ErrorSummary errors={validationErrors} success={successMessage} />
              <form className='settings-form' onSubmit={handleSubmit(onSubmit)}>
                <Row>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={site_title}>Site Title</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('site_title')} value={site_title} onChange={handleChange} placeholder="Site Title" className={`form-control ${errors.site_title ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.site_title?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={address}>Site Address</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('address')} value={address} onChange={handleChange} placeholder="Site Address" className={`form-control ${errors.address ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.address?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={postal_address}>Postal Address</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('postal_address')} value={postal_address} onChange={handleChange} placeholder="Postal Address" className={`form-control ${errors.postal_address ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.postal_address?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={working_hours}>Working Hours</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('working_hours')} value={working_hours} onChange={handleChange} placeholder="Working Hours" className={`form-control ${errors.working_hours ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.working_hours?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={helpline_no}>Site Contact No.</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('helpline_no')} value={helpline_no} onChange={handleChange} placeholder="Site Contact No." className={`form-control ${errors.helpline_no ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.helpline_no?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={helpline_email_address}>Site Email</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('helpline_email_address')} value={helpline_email_address} onChange={handleChange} placeholder="Site Email" className={`form-control ${errors.helpline_email_address ? 'is-invalid' : ''}`} autoComplete="off"/>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.helpline_email_address?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                  <label htmlFor={logo}>Logo<span>(.jpg, .jpeg, .png)</span></label>
                  <InputGroup className='form-group' fullWidth>                      
                    <input type="file" name="myfile" onChange={onUploadHandler} className={`form-control ${errors.setImage ? 'is-invalid' : ''}`} />
                    <input type="hidden" {...register('logo_name')} id="hidden-logo" value={`${imageName ? imageName : logo}`} />
                  </InputGroup>
                </Col>
                <Col className='form-col' xs={12} lg={6}>
                  <img className="prevImg" src = {`${imageName ? `/uploads/logo/${imageName}` : logo ? `/uploads/logo/${logo}` : '/assets/images/no-image.png' }` } />
                </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={twitter_link}>Twitter Link</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('twitter_link')} value={twitter_link} onChange={handleChange} placeholder="Twitter Link" className="form-control" autoComplete="off"/>
                    </InputGroup>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={facebook_link}>Facebook Link</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('facebook_link')} value={facebook_link} onChange={handleChange} placeholder="Facebook Link" className="form-control" autoComplete="off"/>
                    </InputGroup>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={instagram_link}>Instagram Link</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('instagram_link')} value={instagram_link} onChange={handleChange} placeholder="Instagram Link" className="form-control" autoComplete="off"/>
                    </InputGroup>
                  </Col> 
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={youtube_link}>Youtube Link</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('youtube_link')} value={youtube_link} onChange={handleChange} placeholder="Youtube Link" className="form-control" autoComplete="off" />
                    </InputGroup>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={smtphost}>SMTP Host</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('smtphost')} value={smtphost} onChange={handleChange} placeholder="SMTP Host" className={`form-control ${errors.smtphost ? 'is-invalid' : ''}`} autoComplete="off" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.smtphost?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={smtpport}>SMTP Port</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('smtpport')} value={smtpport} onChange={handleChange} placeholder="SMTP Port" className={`form-control ${errors.smtpport ? 'is-invalid' : ''}`} autoComplete="off" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.smtpport?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={secure}>Secure</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <Select {...register('secure')} value={secure} className={`form-control ${errors.secure ? 'is-invalid' : ''}`}>
                        <option value="true">True</option>
                        <option value="false">False</option>
                      </Select>
                    </InputGroup>
                    <div className="invalid-feedback">{errors.secure?.message?.toString()}</div>
                  </Col>  
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={smtpuser}>SMTP User</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('smtpuser')} value={smtpuser} onChange={handleChange} placeholder="SMTP User" className={`form-control ${errors.smtpuser ? 'is-invalid' : ''}`} autoComplete="off" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.smtpuser?.message?.toString()}</div>
                  </Col>  
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={smtppassword}>SMTP Password</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('smtppassword')} value={smtppassword} onChange={handleChange} placeholder="SMTP Password" className={`form-control ${errors.smtppassword ? 'is-invalid' : ''}`} autoComplete="off" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.smtppassword?.message?.toString()}</div>
                  </Col>
                  <Col className='form-col' xs={12} lg={6}>
                    <label htmlFor={smtpfrommail}>SMTP From Mail</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('smtpfrommail')} value={smtpfrommail} onChange={handleChange} placeholder="SMTP From Mail" className={`form-control ${errors.smtpfrommail ? 'is-invalid' : ''}`} autoComplete="off" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.smtpfrommail?.message?.toString()}</div>
                  </Col>       
                  <Col className='form-col' xs={12} lg={12}>
                    <input type="hidden" name="id" value={id} />
                    <Button color="primary"
                      variant="contained"
                      type="submit"
                      onClick={submitForm} 
                      //onClick={() => reset()} 
                      disabled={showLoader} >
                      { showLoader ? <Loader /> : null } Submit
                    </Button>
                  </Col>
                  
                </Row>
              </form>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default SiteSettingsForm;
