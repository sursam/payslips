import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPencilAlt, FaListAlt } from 'react-icons/fa';
import BannerForm from '../../../../components/Admin/BannerForm';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}banner-details/${query.slug}`);
  const bannerData = await res.json()
  return {
    props: {bannerData},
  }
}

const EditBanner = ({bannerData}:any) => { 
  return (
    <Layout title="Edit Banner">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPencilAlt /> Edit Banner: {bannerData.title}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/banners">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {bannerData.id ? <BannerForm dataVal={bannerData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditBanner;
