import React, { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Index() {
  const router = useRouter();
  useEffect(() => {
    const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated')) || 0;
    if (!authenticated) {
      router.push('/login');
    } else {
      router.push('/dashboard');
    }
  }, []);
  
  return <div />;
}
