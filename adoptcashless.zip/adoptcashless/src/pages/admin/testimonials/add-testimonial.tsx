import React from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPlusCircle, FaListAlt } from 'react-icons/fa';
import TestimonialForm from '../../../components/Admin/TestimonialForm';

const AddTestimonial = () => { 

  return (
    <Layout title="Add Testimonial">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPlusCircle /> Add Testimonial 
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/testimonials">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              <TestimonialForm dataVal="" />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default AddTestimonial;
