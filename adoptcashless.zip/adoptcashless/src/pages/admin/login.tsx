import { Button } from '@paljs/ui/Button';
import { InputGroup } from '@paljs/ui/Input';
//import { Checkbox } from '@paljs/ui/Checkbox';
import React, { useEffect, useState, useContext } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
//import Alert from '@paljs/ui/Alert'
import axios from "axios";

import Auth, { Group } from '../../components/Auth';
//import Socials from 'components/Auth/Socials';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import Layout from '../../Layouts';
//import GlobalContext from '../../components/GlobalContext';

export default function Login() {
  //const { serverUrl } = useContext(GlobalContext);
  const router = useRouter();
  const [successMessage, setsuccessMessage] = useState(null);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [showLoader, setshowLoader] = useState(false);

  const [checkboxChecked, setcheckboxChecked] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated')) || 0;
    if (authenticated) {
      router.push('/dashboard');
    }
    const checkboxVal:any = (typeof localStorage !== 'undefined' && localStorage.getItem('rememberlogin') && localStorage.getItem('rememberlogin') === 'true') || false;  
    setcheckboxChecked(checkboxVal);

    const usernameVal:any = (typeof localStorage !== 'undefined' && localStorage.getItem('rememberUsername')) || '';    
    setUsername(usernameVal);

    const passwordVal:any = (typeof localStorage !== 'undefined' && localStorage.getItem('rememberPassword')) || '';
    setPassword(passwordVal);

  }, [])  
  
  const validationSchema = Yup.object().shape({
      username: Yup.string().required('Username is required').email('Email is invalid'),
      password: Yup.string().required('Password is required'),
  });

  const formOptions = { resolver: yupResolver(validationSchema) };
  const { register, handleSubmit, formState: { errors } } = useForm(formOptions);
  const onSubmit = (formData:any) => {
    setshowLoader(true);
    if(checkboxChecked){
      localStorage.setItem('rememberUsername', formData.username)
      localStorage.setItem('rememberPassword', formData.password)
    }else{
      localStorage.setItem('rememberUsername', '')
      localStorage.setItem('rememberPassword', '')
    }
    const data = {
      username: formData.username,
      password: formData.password
    };
    axios.post(`${process.env.serverUrl}admin-login`, data).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setsuccessMessage(response.data.message);  
        localStorage.setItem("authenticated", response.data.status);
        localStorage.setItem("userId", response.data.userId);
        router.push('/dashboard');
      }else{
        setvalidationErrors(response.data.error);
      }        
    });
  };    
  
  const onChangeCheckbox = (e:any) => {
    const checkboxVal:any = e.target.checked;
    setcheckboxChecked(checkboxVal)
    localStorage.setItem('rememberlogin', checkboxVal)
  };

  return (
    <Layout title="Login">
      <Auth title="" subTitle="Login with your email">
        <ErrorSummary errors ={validationErrors} success={successMessage}/>
        <form onSubmit={handleSubmit(onSubmit)}>
          <InputGroup className='form-group' fullWidth>
            <input type="email" {...register('username')} value={username} onChange={event => setUsername(event.target.value)} placeholder="Email Address" className={`form-control ${errors.username ? 'is-invalid' : ''}`} />
            <div className="invalid-feedback">{errors.username?.message}</div>
          </InputGroup>
          <InputGroup className='form-group' fullWidth>
            <input type="password" {...register('password')} value={password}  onChange={event => setPassword(event.target.value)} placeholder="Password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} />
            <div className="invalid-feedback">{errors.password?.message}</div>
          </InputGroup>
          <Group>
            <label className="checklabel"><input type="checkbox" checked={checkboxChecked} onChange={(e) => onChangeCheckbox(e)}/>
              Remember me</label>
            <Link legacyBehavior href="/request-password">
              <a>Forgot Password?</a>
            </Link>
          </Group>
          <Button status="Success" type="submit" shape="SemiRound" disabled={showLoader} fullWidth>
            { showLoader ? <Loader /> : null } Login
          </Button>
        </form>        
      </Auth>
    </Layout>
  );
}
