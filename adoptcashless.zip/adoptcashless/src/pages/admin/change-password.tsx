import React, {useContext, useState, useEffect} from 'react';
import Layout from '../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
/*import Link from 'next/link';*/
import { /*FaPlusCircle, FaListAlt,*/ FaPencilAlt } from 'react-icons/fa';
import { useRouter } from 'next/router';
import ErrorSummary from '../../components/errorSummary';
/*import dynamic from "next/dynamic";*/
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { InputGroup } from '@paljs/ui/Input';
import { Button } from "@material-ui/core";
import axios from "axios";
import Loader from '../../components/loader';

const changePasswordForm = () => { 
  const router = useRouter();
  /*const JoditEditor = dynamic(() => import("jodit-react"), { ssr: false });
  const [data, setData]:any = useState({});*/

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);

  /*const [currentpassword, setcurrentpassword] = useState(false);
  const [password, setpassword] = useState(false);
  const [confirmPassword, setconfirmpassword] = useState(false);*/

  const [state, setState] = useState({
    id: '',
    currentpassword:'',
    password:'',
    confirmPassword:'',
  });

  const {id,currentpassword,password,confirmPassword} = state;

const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
 const { name, value } = event.target;
   setState(prevState => ({
 ...prevState,
 [name] : value,
}));

};
  const validationSchema = Yup.object().shape({
      currentPassword: Yup.string().required('Current password is required'),
      password: Yup.string()
          //.min(6, 'Password must be at least 6 characters')
          .required('Password is required'),
      confirmPassword: Yup.string()
          //.min(6, 'Password must be at least 6 characters')
          .oneOf([Yup.ref('password'), null], 'Passwords does not matched'),
  });

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  useEffect(() => {    
    axios.get(`${process.env.serverUrl}change-password/`,{}).then((response) => {

      setState(prevState => ({
      ...prevState,
      id: response.data.id,
    }));

    });
  }, [])

    const submitForm = () => {    
    reset(state)
  }

    const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-password`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  

      sessionStorage.removeItem("authenticated");
      router.push('/login');

      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      } 

    });
  };
  return (
    <Layout title="Change Password">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 12 }}> 
                  <FaPencilAlt /> Change Password
                </Col>
              </Row>
            </header> 
            <CardBody>
              <ErrorSummary errors={validationErrors} success={successMessage} />
              <form className='settings-form' onSubmit={handleSubmit(onSubmit)}>
                <Row>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor= {currentpassword}>Current Password</label>
                    <InputGroup className='form-group' fullWidth>                      
                      <input type="text" {...register('currentpassword')} onChange={handleChange} placeholder="Current Password" className={`form-control ${errors.currentpassword ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.currentpassword?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}></Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={password}>Password</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('password')} onChange={handleChange} placeholder="Password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.password?.message}</div>
                  </Col>
                   <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}></Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
                    <label htmlFor={confirmPassword}>Confirm Password</label>
                    <InputGroup className='form-group' fullWidth>
                      <input type="text" {...register('confirmPassword')} onChange={handleChange} placeholder="Confirm Password" className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`} autoComplete = "false" />
                    </InputGroup>
                    <div className="invalid-feedback">{errors.confirmPassword?.message}</div>
                  </Col>
                  <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
                    <input type="hidden" name="id" value={id} />
                    <Button color="primary"
                      variant="contained"
                      type="submit"
                      onClick={submitForm} 
                      disabled={showLoader} >
                      { showLoader ? <Loader /> : null } Submit
                    </Button>
                  </Col>
                  
                </Row>
              </form>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default changePasswordForm;
