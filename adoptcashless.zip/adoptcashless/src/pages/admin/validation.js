const valueRequired = (value) => {
  console.log('enter into validaton')
  if (!value) {
    return "value is reuqired";
  }
  return true;
};

export default valueRequired;