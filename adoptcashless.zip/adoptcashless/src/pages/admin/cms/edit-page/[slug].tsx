import React from 'react';
import Layout from '../../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPencilAlt, FaListAlt } from 'react-icons/fa';
import PageForm from '../../../../components/Admin/PageForm';

export async function getServerSideProps({ query }:any) {
  const res = await fetch(`${process.env.serverUrl}page-details/${query.slug}`);
  const pageData = await res.json()
  return {
    props: {pageData},
  }
}

const EditPage = ({pageData}:any) => { 
  return (
    <Layout title="Edit Page">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPencilAlt /> Edit Page: {pageData.pageTitle}
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/cms/pages">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              {pageData.id ? <PageForm dataVal={pageData}/> : ''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default EditPage;
