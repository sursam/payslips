import React, {useState, useContext} from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
//import SmartDataTable from 'react-smart-data-table'
import DataTable from 'react-data-table-component';
import axios from "axios";
import Link from 'next/link';
import Moment from 'moment';
import { FaPencilAlt, FaTrashAlt, FaPlusCircle } from 'react-icons/fa';
//import GlobalContext from '../../../components/GlobalContext';
import ErrorSummary from '../../../components/errorSummary';

const Pages = () => {
  //const { serverUrl } = useContext(GlobalContext);
  const columns = [
    {
        name: 'Name',
        selector: (row:any) => row.pageName,
        sortable: true,
    },
    {
        name: 'Slug',
        selector: (row:any) => row.slug,
        sortable: true,
    },
    {
        name: 'Added / Modifield Date',
        selector: (row:any) => Moment((row.modifiedOn) ? row.modifiedOn : row.addedOn).format('DD-MM-YYYY h:mm a'),
        sortable: true,
    },
    {
      name: "Action",
      button: true,
      sortable: false,
      cell: (row:any) => [
        <Link legacyBehavior href={`/cms/edit-page/${row.slug}`}>
          <a className="edit-btn"><FaPencilAlt /></a>
        </Link>, 
        <Link legacyBehavior href="#">
          <a className="delete-btn" data-id={row.id} onClick={e => handleDelete(e)}><FaTrashAlt /></a>
        </Link>       
      ]
    }
  ];
  const [data, setData] = useState([]);
  
  React.useEffect(() => {
    axios.get(`${process.env.serverUrl}pages`).then((response) => {
      setData(response.data);      
    });
  }, []);  

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  
  const handleDelete = async (e:any) => {
    let rowId = e.currentTarget.getAttribute("data-id");
    const confirmBox = window.confirm(
      "Do you really want to delete this row?"
    )
    if (confirmBox === true) {
      axios.post(`${process.env.serverUrl}delete-page`, {id: rowId}).then((response) => {
        if(!response.data.error){
          setvalidationErrors(null);
          setsuccessMessage(response.data.message);
          var index = data.findIndex(obj => obj['id'] == rowId);
          setData(data.filter((_v, i) => i !== index));
        }else{
          setsuccessMessage(null);
          setvalidationErrors(response.data.error);
        }        
      });
    }    
  }

  return (
    <Layout title="Pages">
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  CMS Pages 
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/cms/add-page">
                      <a className="btn primaryBtn addLink">
                        <FaPlusCircle />{" "} Add New Page
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              <DataTable
                pagination
                columns={columns}
                data={data}
                selectableRows
              />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default Pages;
