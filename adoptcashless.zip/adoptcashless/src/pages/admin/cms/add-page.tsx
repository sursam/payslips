import React from 'react';
import Layout from '../../../Layouts';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { Card, CardBody } from '@paljs/ui/Card';
import Link from 'next/link';
import { FaPlusCircle, FaListAlt } from 'react-icons/fa';
import PageForm from '../../../components/Admin/PageForm';

const AddPage = () => { 

  return (
    <Layout title="Add Page">
      <Row>
        <Col breakPoint={{ xs: 12, lg: 12 }}>
          <Card>
            <header>
              <Row>
                <Col breakPoint={{ xs: 12, lg: 4 }}> 
                  <FaPlusCircle /> Add Page 
                </Col>
                <Col breakPoint={{ xs: 12, lg: 8 }}>
                  <div className="displayFlex">
                    <Link legacyBehavior href="/cms/pages">
                      <a className="btn primaryBtn addLink">
                        <FaListAlt />{" "} List
                      </a>
                    </Link>            
                  </div>
                </Col>
              </Row>
            </header> 
            <CardBody>
              <PageForm dataVal="" />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Layout>
  );
};
export default AddPage;
