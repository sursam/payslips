import { Button } from '@paljs/ui/Button';
import { InputGroup } from '@paljs/ui/Input';
import React, { useEffect, useState, useContext } from 'react';
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useParams } from 'react-router-dom';
//import Alert from '@paljs/ui/Alert'
import axios from "axios";

import Auth from '../../components/Auth';
//import Socials from '../../components/Auth/Socials';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import Layout from '../../Layouts';

export default function UpdatePassword() {
  const router = useRouter();
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [code, setCode] = useState("");

  const [password, setpassword] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberPassword')) || '';
  });
  const [confirmPassword, setconfirmpassword] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberConfirmPassword')) || '';
  });
  
   useEffect(() => {

    const search = window.location.search;
    const params = new URLSearchParams(search);
    const activation_code:any = params.get('data');

    const getcode = () => {
      setCode(activation_code);
    };
    getcode();

  },   
  
  [])  
  
  const validationSchema = Yup.object().shape({
      password: Yup.string()
          //.min(6, 'Password must be at least 6 characters')
          .required('Password is required'),
      confirmPassword: Yup.string()
          //.min(6, 'Password must be at least 6 characters')
          .oneOf([Yup.ref('password'), null], 'Passwords does not matched'),
  });
  const formOptions = { resolver: yupResolver(validationSchema) };
  const { register, handleSubmit, formState: { errors } } = useForm(formOptions);
  
  const onSubmit = (formData:any) => {
    setshowLoader(true);
     const [searchParams]:any = useParams();

    const data:any = {
      password: formData.password,
      confirmPassword: formData.confirmPassword,
      code: searchParams.get('code'),
    };

    axios.get(`${process.env.serverUrl}admin-set-password`, data).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        localStorage.setItem("authenticated", response.data.status);
        setsuccessMessage(response.data.message);  
        router.push('/login');
      }else{
        setvalidationErrors(response.data.error);
      }        
    });
  };    

  return (
    <Layout title="Reset Password">
      <Auth title="" subTitle="Login with your email">
        <ErrorSummary errors ={validationErrors} success={successMessage}/>
        <form onSubmit={handleSubmit(onSubmit)}>
          <InputGroup className='form-group' fullWidth>
            <input type="text" {...register('password')} value={password} onChange={event => setpassword(event.target.value)} placeholder="Password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} autoComplete = "off" />
            <div className="invalid-feedback">{errors.password?.message}</div>
          </InputGroup>
          <InputGroup className='form-group' fullWidth>
            <input type="text" {...register('confirmPassword')} value={confirmPassword}  onChange={event => setconfirmpassword(event.target.value)} placeholder="Confirm Password" className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`} autoComplete = "off" />
            <div className="invalid-feedback">{errors.confirmPassword?.message}</div>
          </InputGroup>
          <input type="hidden" {...register('code')} value={code} />
          <Button status="Success" type="submit" shape="SemiRound" disabled={showLoader} fullWidth>
            { showLoader ? <Loader /> : null } Save
          </Button>
        </form>        
      </Auth>
    </Layout>
  );
}
