import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Prepaid.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PhoneInput from '../../components/PhoneInput';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Button } from "@material-ui/core";
import Link from 'next/link';
import { useRouter } from 'next/router';
import * as Icon from 'react-bootstrap-icons';

import Loader from '../../components/loader';
import Header from "../../components/Prepaid/Header";
import Footer from "../../components/Prepaid/Footer";

const Checkout = () => {
  return (
    <section className={styles.mainDash}>
      <SEO title="Checkout">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}> 
        <ToastContainer
          position="top-right"
          autoClose={10000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
        />
        <div className={styles.cardDetails}>
          <div className={styles.DashContainer}>
            <Container className={styles.paymentContainer}>              
              <div className={styles.PaymentLeft}>
                <div className={styles.infoContainer}>
                  <h2>Water Wise Car & Dog Wash</h2>
                  <h4>
                    ABN: 45 375 447 631
                    <br/>
                    5 Peace Avenue, Warragul VIC 3820
                  </h4>              
                </div>
              </div>
            
              <div className={styles.PaymentRight}>            
                  
                <form id="associateForm" className='associate-form form-container-com'>    
                  <Container className={styles.PaymentFormContainer}>  
                    <Row>
                      <Col lg={12} xl={12} xxl={12} xs={12} md={12}>             
                        <h2>
                          Associate Details
                        </h2>
                      </Col>
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}>                    
                        <div className={styles.formCoantainer}>
                            <div className={styles.formgroup}>
                              <label>First Name</label>
                              <input type="text" className="form-control"/>
                            </div>
                            <div className={styles.formgroup}>
                              <label>Mobile Number</label>
                              <PhoneInput className="form-control"></PhoneInput>
                            </div>                              
                        </div>  
                      </Col>
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}>                    
                        <div className={styles.formCoantainer}>
                            <div className={styles.formgroup}>
                                <label>Last Name</label>
                                <input type="text" className="form-control" />
                            </div>
                            <div className={styles.formgroup}>
                                <label>Email Address</label>
                                <input type="text" className="form-control" />
                            </div>
                        </div> 
                      </Col>
                      <Col lg={12} xl={12} xxl={12} xs={12} md={12}>             
                        <h2>
                          Payment Details
                        </h2>
                        <div className={styles.ProceedPay}>                            
                            <ul className={styles.PaymenyList}>
                              <li><h5>Proceed to Pay</h5></li>
                              <li>Recharge Value <strong>$150.00</strong></li>
                              <span>+</span>
                              <li>Surcharge <strong>$3.36</strong></li>
                              <span>=</span>
                              <li>
                                Grand Total <strong>$153.36</strong>
                              </li>
                            </ul>
                        </div>
                      </Col> 
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}>                   
                        <div className={styles.formCoantainer}>
                          <div className={styles.formgroup}>
                              <label>Name of your Debit / Credit Card</label>
                              <input type="text" className="form-control"/>
                          </div>
                          <div className={styles.formgroup}>
                              <label>Expiry Date</label>
                              <input type="text" className="form-control"/>
                          </div>
                        </div> 
                      </Col> 
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}>                      
                        <div className={styles.formCoantainer}>
                          <div className={styles.formgroup}>
                              <label>Card Number</label>
                              <input type="text" className="form-control"/>
                          </div>
                          <div className={styles.formgroup}>
                              <label>CVC</label>
                              <input type="text" className="form-control"/>
                          </div>
                        </div>  
                      </Col>                    
                    </Row>
                  </Container>
                  <div className={styles.submitButton}>
                      <Button color="primary"
                          variant="contained"
                          type="submit">
                          Pay Now
                      </Button>                         
                  </div>
                  <span className={styles.disclaimerText}>By confirming your payment, you allow <strong>Vendor</strong> to charge your card for this payment and save payment information in accordance with their terms.</span> 
                </form>     
                
              </div>
            </Container>
          </div>
        </div>
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Checkout;