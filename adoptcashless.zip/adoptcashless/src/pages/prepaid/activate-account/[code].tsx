import React, {useState, useEffect} from 'react';
import styles from '../../../styles/Prepaid.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from "axios";
import "react-datepicker/dist/react-datepicker.css";
import Link from 'next/link';
import SEO from '../../../components/SEO';
import 'react-toastify/dist/ReactToastify.css';
import Footer from "../../../components/Prepaid/Footer";
import * as Icon from 'react-bootstrap-icons';

export async function getServerSideProps({ query }:any) {
  var activationcode = query.code;  
  console.log(activationcode)
  return {
    props: {activationcode},
  }
}

export default function ActivateAccount({activationcode}:any) {  
  const [logo, setLogo] = useState('');
  const [successStatus, setSuccessStatus] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [returnUrl, setReturnUrl] = useState('');

  useEffect(() => {
    const param = {
      'activationCode': activationcode,
    };
    axios.post(`${process.env.serverUrl}verify-associate-email`, param, { headers: { 'content-type': 'application/json', } }).then((response) => {          
      setSuccessStatus(response.data.status);
      setSuccessMessage(response.data.message); 
      setReturnUrl(response.data.req);
    });
    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
      setLogo(response.data.logo);   
    });
  },   
  []);

  return (
    <section className={styles.mainDash}>
      <SEO title="Account Authentication">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      <section className={styles.topSection}>
          <section className={styles.mainWrap}>
              <div className={styles.LogoAccount}>
                  <figure className={styles.leftLogo}>
                    {logo ? 
                      <img src={`/uploads/logo/${logo}`} alt="" />
                    : ''}
                  </figure>
              </div>
          </section>
      </section>
      <section className={styles.MainContainer}>
        <div className={styles.AuthContainer}>
          <Container fluid>
            <Row>
              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                <div className={styles.AlertBox}>
                  <h2>
                    {(successStatus == 1) ?
                    <Icon.CheckCircle color="green" size={96}/>   
                    :
                    <Icon.XCircle color="red" size={96}/>}                 
                    <span>{successMessage}</span>
                  </h2>  
                  {(successStatus == 1) ?
                  <Link legacyBehavior href={returnUrl}><a className={styles.ButtonActive}>Login Now</a></Link> 
                  : ''}                   
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      </section>
      <Footer/>
    </section>
  );
}