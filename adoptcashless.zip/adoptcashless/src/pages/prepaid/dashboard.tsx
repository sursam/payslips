import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Prepaid.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import axios from "axios";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PhoneInput from '../../components/PhoneInput';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
//import Select from 'react-select';
import { Button } from "@material-ui/core";
import ToggleSwitch from '../../components/ToggleSwitch';
//import WalletManager from 'react-native-wallet-manager';
import Link from 'next/link';
import ReactPaginate from "react-paginate";

import Loader from '../../components/loader';
import Header from "../../components/Prepaid/Header";
import Footer from "../../components/Prepaid/Footer";
import RechargePanel from "../../components/Prepaid/RechargePanel/RechargePanel";
import MaskedInput from "react-maskedinput";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";
import PaymentInvoice from "../../components/PaymentInvoice";
import LoadingScreen from "../../components/loadingScreen";

const Dashboard = () => {
  const associateId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('associateId')) || '';
  const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('endConsumerId')) || '';
  const [showLoader, setshowLoader] = useState(false);
  const [cardError, setCardError] = useState('');
  const [cardDetails, setCardDetails]:any = useState({});
  const [showBarLoader, setShowBarLoader] = useState(true);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [isToggled, setIsToggled]:any = useState(null);
  const [cardStatus, setCardStatus] = useState(false);
  const [autoTopupVal, setAutoTopupVal] = useState('0');
  const [autoTriggerVal, setAutoTriggerVal] = useState(0);
  const [autoRechargeVal, setAutoRechargeVal] = useState(0);
  const [limit, setLimit] = useState(5);
  const [isFetching, setIsFetching] = useState(false);
  const [companyInfo, setCompanyInfo] = useState({});
  const [pageCount, setpageCount] = useState(0);
  const [accountInfo, setAccountInfo]:any = useState({});
  const [billingAddress, setBillingAddress] = useState('');
  
  //const currentPage = 1;
  //var [cards, setCards] = useState<any[]>([]);
  //var [unAssignedCredit, setUnAssignedCredit] = useState(0);
  var [availableCredit, setAvailableCredit] = useState(0);
  useEffect(() => {
    //console.log(associateId)
    getAssociate(associateId);
    
    /*axios.get(`${process.env.serverUrl}get-associate-transactions/${associateId}/?page=${currentPage}&size=${limit}`,{}).then((response) => { 
      setShowBarLoader(false);
      setRecentTransactions(response.data.Transactions);     
    });*/

    /*axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${currentPage}&size=${limit}`,{}).then((response) => { 
      setShowBarLoader(false);
      setRecentTransactions(response.data.Transactions);     
    });*/

    getAllTransactions();

    axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
      //let unAssignedCred = (response.data.current_balance != null) ? response.data.current_balance : 0;
      //setUnAssignedCredit(unAssignedCred);
      let autoTopupCheck = (response.data.is_auto_topup == '1') ? true : false;
      setIsToggled(autoTopupCheck);   
      //console.log(response.data);   
    });
    axios.get(`${process.env.serverUrl}get-company-info/${endConsumerId}`,{}).then((response) => { 
      let companyData = {};
      if(response.data){
        response.data.forEach(infoData => {
          companyData[infoData.field_name] = infoData.field_value;
        });          
      }
      setCompanyInfo(companyData);     
    });
    axios.get(`${process.env.serverUrl}get-account-info-by-endconsumer/${endConsumerId}`,{}).then((response) => {
      setAccountInfo(response.data);
      if(response.data.account_name__r != null){
        let accountData = response.data.account_name__r;
        let billAddress:any = []; 
        Object.keys(accountData).map(key => {
          if(accountData[key] != null && key != 'attributes' && key != 'Name' && key != 'ABN__c' && key != 'ACN__c'){
            billAddress.push(accountData[key]);
          }
        });
        setBillingAddress(billAddress.join(', '));
      }
    });
  }, 
  [])
  const getAssociate = async (associateId) => {
      if(associateId){
          const resp = await fetch(`${process.env.serverUrl}get-associate-details/${associateId}`);
          const associateRecords = await resp.json(); 
          if(associateRecords){
              let dateOfBirth:any = associateRecords.date_of_birth ? new Date(Date.parse(associateRecords.date_of_birth)) : null;
              //let cardSalesforceId = associateRecords.card ? associateRecords.card.salesforce_id : '';
              let cardNumber = associateRecords.card ? associateRecords.card.card_number : '';
              if(associateRecords.card){
                console.log(associateRecords.card)
                setCardDetails(associateRecords.card);
                setAutoTopupVal(associateRecords.card.auto_topup);
                setAvailableCredit(associateRecords.card.available_credit);
                //const autoTopupCheck = (associateRecords.card.auto_topup == '1') ? true : false;
                //setIsToggled(autoTopupCheck);
                let assCardStatus = (associateRecords.card.status == '1') || false;
                setCardStatus(assCardStatus);
                setAutoTriggerVal(associateRecords.card.topup_trigger_val);
                setAutoRechargeVal(associateRecords.card.topup_recharge_val);
              }
              let formattedDate = (dateOfBirth != null) ? `${dateOfBirth.getFullYear()}-${dateOfBirth.getMonth() + 1}-${dateOfBirth.getDate()}` : '';
              setState(prevState => ({
                  ...prevState,
                  first_name: associateRecords.first_name,
                  last_name: associateRecords.last_name,
                  mobile: associateRecords.mobile,
                  email: associateRecords.email,
                  dob: dateOfBirth,
                  formattedBirthDate: formattedDate,
                  //gender: associateRecords.gender,
                  car_reg: associateRecords.car_reg,
                  assigned_card: cardNumber,
              }));
              /*var defaultCardObj:any = {};
              if(cardSalesforceId){
                  defaultCardObj['value'] = cardSalesforceId;
                  defaultCardObj['label'] = cardNumber;
              }
              getAvailableCards(defaultCardObj);*/
              //setIsFetching(false);
        }            
      }
  };
  /*const getAvailableCards = (defaultCard = {}) => {
    axios.get(`${process.env.serverUrl}get-available-corporate-cards`,{}).then((response) => {             
      const cardOptions:any = [];
      if(Object.keys(defaultCard).length){
          cardOptions.push(defaultCard);
      }
      response.data.forEach(card => {
          var obj:any = {};
          obj['value'] = card.salesforce_id;
          obj['label'] = card.card_number;
          cardOptions.push(obj);
      }); 
      setCards(cardOptions); 
      //console.log(defaultCard)
    });
  }*/
  
  /*const genderOptions = [
    { value: 'm', label: 'Male' },
    { value: 'f', label: 'Female' }
  ]*/    

  var [state, setState] = useState({
      first_name: '',
      last_name: '',
      mobile: '',
      email: '',
      dob: null,
      formattedBirthDate: '',
      //gender: '',
      car_reg: '',
      assigned_card: '',
  });

  var { first_name, last_name, mobile, email, dob, formattedBirthDate, /*gender,*/ car_reg, assigned_card } = state;

  const [mobileError, setMobileError] = useState(false);
  const handleMobileInput = ({ target: { value } }:any) => {
      setState(prevState => ({
          ...prevState,
          mobile: value.replace('/\D/g', ' ')
      }));
      if(mobile){
        setMobileError(true)
      }
      if(!value.replace(/\D/g, '').length && mobileError)
        trigger('mobile')
  };
  const [dobError, setDobError] = useState(false);
  const handleDateInput = (dateOfBirth:any) => {
      let formattedDate = `${dateOfBirth.getFullYear()}-${dateOfBirth.getMonth() + 1}-${dateOfBirth.getDate()}`;
      setState(prevState => ({
          ...prevState,
          dob: dateOfBirth,
          formattedBirthDate: formattedDate
      }));
      if(dateOfBirth){
          clearErrors(["dob"])
          setDobError(false)
      }else{
          setDobError(true)
      }
      trigger('dob')
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
    //console.log(value)
  };
  /*const handleCardBlur = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const cardNumber = event.target.value;
    axios.get(`${process.env.serverUrl}get-card-by-number/${cardNumber}`,{}).then((response) => {             
      if(!response.data){
        toast.error("Corporate card is not valid");
      } 
    });
    //console.log(value)
  };*/

var validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .required('First name is required'),
    last_name: Yup.string()
      .required('Last name is required'),
    mobile: Yup.string()
      .required('Mobile number is required')
      .min(10, 'Mobile number must be of 10 characters'),
    email: Yup.string()
      .required('Email is required')
      .email('Email is invalid'),
    dob: Yup.string()
      .required('Date of birth is required').nullable(),
    assigned_card: Yup.string()
      .required('Corporate card is required')
      /*.test("card-validate", "Corporate card is not valid", (value) => {
        axios.get(`${process.env.serverUrl}get-card-by-number/${value}`,{}).then((response) => {             
          if(!response.data){
            return false
          } 
        })
        return true
      }),*/
});
var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

const submitForm = () => { 
    clearErrors()   
    reset(state)
    if(!dob){
        setDobError(true)
    }
}
const onSubmit = (formData:any) => {
  setshowLoader(true); 
  setCardError('');
  axios.post(`${process.env.serverUrl}update-associate-data`, formData).then((response) => {
    setshowLoader(false)
    if(response.data.error){
      toast.error(response.data.message);
    }else if(response.data.cardError){
      setCardError(response.data.message);
    }else{
      toast.success(response.data.message); 
    }  
  });
};

/*const resetForm = () => {
  clearErrors();
  getAssociate(associateId); 
}*/

/*const onGenderChange = (
  newValue
) => {
  setState(prevState => ({
    ...prevState,
    gender: newValue.value,
  }));
};*/


const addToAppleWallet = async () => {
  /*try {
    const result = await WalletManager.addPassFromUrl(
      'https://github.com/dev-family/react-native-wallet-manager/blob/main/example/resources/test.pkpass?raw=true'
    );
    console.log(result);
    // true
  } catch (e) {
    console.log(e);
  }*/
};

/*const onCardChange = (
  newValue
) => {
  setState(prevState => ({
    ...prevState,
    assigned_card: newValue.value,
  }));
};*/

const customFormatDate = (date, format = 'y-m-d') => {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
      day = '0' + day;

  let retDate = '';
  switch(format){
      case 'd/m/y': retDate = [day, month, year].join('/');
          break;
      case 'y-m-d': 
      default:
          retDate = [year, month, day].join('-');
          break;
  }
  return retDate;
}
const generateInvoicePdf = async (transactionId) => {
  setIsFetching(true);
  const settingsResponse = await fetch(`${process.env.serverUrl}site-settings/`);
  const settingsInfo = await settingsResponse.json();
  const endConsumerResponse = await fetch(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`);
  const endConsumerInfo = await endConsumerResponse.json();
  const transactionResponse = await fetch(`${process.env.serverUrl}get-transaction-details/${transactionId}`);
  const transactionInfo = await transactionResponse.json();
  if(Object.keys(transactionInfo).length && Object.keys(endConsumerInfo).length){
      const blob = await pdf(
          <PaymentInvoice siteLogo={settingsInfo.logo} accountInfo={accountInfo} billingAddress={billingAddress} companyInfo={companyInfo} endConsumerInfo={endConsumerInfo} transactionInfo={transactionInfo} />
      ).toBlob();
      saveAs(blob, `invoice-${String(transactionId).padStart(6, '0')}.pdf`);
      setIsFetching(false);
  }
}


/*const showAutoTopUp = (state) => {
  setIsToggled(state);
  let auto_topup = state ? '1' : '0';
  setAutoTopupVal(auto_topup);
  let formData = {
      salesforce_id: cardDetails.salesforce_id,
      auto_topup: auto_topup,
  };
  updateAutoTopupValues(formData);
};
const handleAutoTriggerVal = (event) => { 
  let triggerVal = event.target.value;
  setAutoTriggerVal(triggerVal);
};
const handleAutoRechargeVal = (event) => { 
  let rechargeVal = event.target.value;    
  setAutoRechargeVal(rechargeVal);
};
const handleAutoTopupVal = () => { 
  if(autoTriggerVal != parseFloat(cardDetails.topup_trigger_val) || autoRechargeVal != parseFloat(cardDetails.topup_recharge_val)){
      let formData = {
          salesforce_id: cardDetails.salesforce_id,
          auto_topup: autoTopupVal,
          topup_trigger_val: autoTriggerVal,
          topup_recharge_val: autoRechargeVal
      };
      updateAutoTopupValues(formData);
  }
};
const updateAutoTopupValues = (formData) => {
  console.log(formData)
  if(formData.auto_topup == '0'){
    axios.post(`${process.env.serverUrl}update-associate-autotopup`, formData).then(async (response) => {
      if(!response.data.error){
        cardDetails.topup_trigger_val = parseFloat(formData.topup_trigger_val);
        cardDetails.topup_recharge_val = parseFloat(formData.topup_recharge_val);
        toast.success(response.data.message);  
      }else{  
        toast.error(response.data.message);
      }    
    });
  }else{
    if(formData.topup_recharge_val){
      if(parseFloat(formData.topup_recharge_val) < parseFloat(formData.topup_trigger_val)){
        toast.error('Recharge amount should be greater than trigger amount');
      }else{
        axios.post(`${process.env.serverUrl}update-associate-autotopup`, formData).then(async (response) => {
          if(!response.data.error){
            cardDetails.topup_trigger_val = parseFloat(formData.topup_trigger_val);
            cardDetails.topup_recharge_val = parseFloat(formData.topup_recharge_val);
            toast.success(response.data.message);  
          }else{  
            toast.error(response.data.message);
          }    
        });
      }
    }
  }
};*/

const showAutoTopUp = (state) => {
  setIsFetching(true);
  let formData = {
      salesforce_id: endConsumerId,
      is_auto_topup: state ? '1' : '0',
  };
  axios.post(`${process.env.serverUrl}update-endconsumer-autotopup`, formData).then(async (response) => {
    setIsFetching(false);
    if(!response.data.error){
      setIsToggled(state);
      toast.success(response.data.message); 
    }else{ 
      toast.error(response.data.message);
    }    
  });
};

const handlePageClick = async (data:any) => {
  let currentPage = data.selected + 1;
  getAllTransactions(currentPage);
};
const getAllTransactions = (pCount = 1) => {
  axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${pCount}&size=${limit}`,{}).then((response) => { 
      setShowBarLoader(false);
      setRecentTransactions(response.data.Transactions);
      const total = response.data.totalItems;
      setpageCount(Math.ceil(total / limit));       
  });
};

  return (
    <section className={styles.mainDash}>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      <SEO title="Prepaid Dashboard">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}>
        {/* ================dashboard container================== */}
        <section className={styles.DashboardContainer}>
          {/* ============ card details section ============= */}
          <div className={styles.cardDetails}>
            <Container className={styles.DashContainer}>
              <Row>
                  <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                    <section className={styles.AssocForm}>
                      <h3>
                          <Icon.PersonCircle/>
                          <span>Associate's Details</span>
                      </h3>
                      <form id="associateForm" className='associate-form form-container-com dashbord-form-new' onSubmit={handleSubmit(onSubmit)}>
                        <div className={styles.formCoantainer}>
                            <div className={styles.formgroup}>
                                <label>First Name</label>
                                <input type="text" {...register('first_name', {onChange: handleChange})} value={first_name}  className={`form-control ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`}/>
                                <div className={`invalid-feedback ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`}>{errors.first_name?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Last Name</label>
                                <input type="text" {...register('last_name', {onChange: handleChange})} value={last_name} className={`form-control ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`} />
                                <div className={`invalid-feedback ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`}>{errors.last_name?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Mobile Number</label>
                                <PhoneInput className={`form-control ${((mobileError && isNaN(parseInt(mobile))) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( !isNaN(parseInt(mobile)) && mobile.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`}
                                    value={mobile} 
                                    {...register('mobile', {onChange: handleMobileInput})} />
                                <div  className={`invalid-feedback ${(isNaN(parseInt(mobile)) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobile.length == 10 ? 'is-valid' : '')}`}>{(errors.mobile && !mobile || mobile.replace(/\D/g, '').length < 10 || isNaN(parseInt(mobile))) ? errors.mobile?.message?.toString() : ''}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Email Address</label>
                                <input type="text" {...register('email', {onChange: handleChange})} value={email} className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`} />
                                <div className={`invalid-feedback ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`}>{errors.email?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Date of Birth</label>
                                <DatePicker {...register('dob')} className={`form-control ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={handleDateInput} value={dob} customInput={ <MaskedInput mask="11/11/1111" placeholder="dd/mm/yyyy" /> } />
                                <input type='hidden' value={formattedBirthDate} {...register('formattedBirthDate')} />
                                <div className={`invalid-feedback ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`}>{dobError ? errors.dob?.message?.toString() : ''}</div>
                            </div>
                            {/*<div className={styles.formgroup}>
                                <label>Gender</label>
                                <Select options={genderOptions} value={genderOptions.find(item => item.value === gender) || ''} {...register('gender')} onChange={onGenderChange} className={`form-control form-select ${gender ? 'is-valid' : ''}`}/>  
                            </div>*/}
                            <div className={styles.formgroup}>
                                <label>Car Registration</label>
                                <input type="text" {...register('car_reg', {onChange: handleChange})} value={car_reg} className={`form-control ${car_reg ? 'is-valid' : ''}`} />
                            </div>
                            <div className={styles.formgroup}>
                                <label>Corporate Card</label>
                                <input type="text" {...register('assigned_card', {onChange: handleChange})} value={assigned_card} className={`form-control ${errors.assigned_card ? 'is-invalid' : (assigned_card ? 'is-valid' : '')}`} />
                                
                                {/*<Select options={cards} value={cards.find(item => item.value === assigned_card) || ''} {...register('assigned_card')} onChange={onCardChange} className={`form-control form-select ${assigned_card ? 'is-valid' : ''}`}/>*/}
                                <div className={`invalid-feedback ${(errors.assigned_card || (cardError != '')) ? 'is-invalid' : (assigned_card ? 'is-valid' : '')}`}>{(cardError != '') ? cardError : errors.assigned_card?.message?.toString()}</div>
                            </div>
                            <div className={styles.submitButton}>
                                <input type="hidden" {...register('associateId')} value={associateId} />
                                <Button color="primary"
                                    variant="contained"
                                    type="submit"
                                    onClick={submitForm} 
                                    disabled={showLoader} >
                                    { showLoader ? <Loader /> : null } Update
                                </Button>                                
                            </div>
                        </div>
                        
                    </form>                                          
                  </section>
                  </Col>
                  
                  <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                    <RechargePanel
                      currentCreditBalance={availableCredit}
                    />
                  </Col>

                  <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                    <section  className={styles.CorporateCard}>
                      <Row>
                          <Col sm={12}>

                              <Row>
                                  <Col sm={6}>

                                    <div className={styles.CardAllDetails}>
                                      <div className={styles.CardInfo}>
                                          <ul>
                                              <li><span>Card Number</span>  {cardDetails.card_number ? cardDetails.card_number : ''}</li>
                                          </ul>
                                      </div>
                                    </div>
                                    <div className={styles.AvailableBalance}>
                                      <span>Current Balance</span>
                                        ${availableCredit ? (availableCredit).toFixed(2) : '0.00'}
                                    </div>

                                  </Col>
                                  <Col sm={6}>
                                    {(isToggled != null) ? 
                                      <div className={styles.AutoTopUpMain}>
                                        <ToggleSwitch label="Auto Top-Up" toggled={isToggled} onClick={showAutoTopUp} />
                                      </div>
                                    : ''}  
                                    {/*cardStatus ? 
                                    <div className={styles.AutoTopUpMain}>
                                        <ToggleSwitch label="Auto Top-Up" toggled={isToggled} onClick={showAutoTopUp} />
                                    </div>
                                    : ''}
                                    {isToggled ?
                                      <div className={`topupPrice ${styles.PriceValue}`}>
                                        <aside>
                                            <div className="currencyDiv">
                                                <input type="text" name="autoTriggerVal" className="form-control" value={autoTriggerVal} onChange={handleAutoTriggerVal} onBlur={handleAutoTopupVal} />
                                            </div>
                                            Trigger Value
                                        </aside>
                                        <aside>
                                            <div className="currencyDiv">
                                                <input type="text" name="autoRechargeVal" className="form-control" value={autoRechargeVal} onChange={handleAutoRechargeVal} onBlur={handleAutoTopupVal} />
                                            </div>
                                            Recharge Value
                                        </aside>
                                      </div>
                                    : ''*/}
                                  </Col>
                                  
                              </Row>                                          
                              
                          </Col>
                          <Col sm={12}>
                              <div className={styles.WalletGroup}>
                                  <Link legacyBehavior href="#">
                                    <a onClick={addToAppleWallet} className={styles.WalletButton}>
                                      <div><Icon.Wallet2 /></div>
                                      <div>
                                          <span>Add to</span>
                                          Apple Wallet
                                      </div> 
                                    </a>
                                  </Link>
                                  <a href="#" className={styles.WalletButton}>
                                      <Icon.Wallet2 /> Add to Google Wallet
                                  </a>
                              </div>
                          </Col>
                          
                      </Row>
                  </section>
                      <div className={styles.Transactions}>
                          <h3>Recent Recharge Transactions</h3>
                          {showBarLoader ?
                            (<div className="bar_loader">
                              <div className="bar"></div>
                              <div className="bar2"></div>
                              <div className="bar3"></div>
                              <div className="bar4"></div>
                            </div>)
                          : 
                            <div>
                              { (recentTransactions.length > 0) ? 
                                  <div>
                                    <ul>
                                        { recentTransactions.map((transaction:any, k) => (
                                          <li>
                                              <div className={styles.Tdetails}>
                                                {'$'+transaction.total_amount}
                                                <span>{customFormatDate(transaction.created_on, 'd/m/y')}</span>
                                                <div className={(transaction.recharge_procedure == 'Auto') ? styles.NotiFication +' '+ styles.AutoTopUp : styles.NotiFication}>
                                                  {(transaction.recharge_procedure == 'Auto') ? 'Auto Top-Up' : 'Manual Recharge'}
                                                </div>
                                              </div>
                                              <div className={styles.TImage}>
                                                <Link legacyBehavior href="#"><a onClick={() => generateInvoicePdf(transaction.salesforce_id)}><Icon.FilePdfFill/></a></Link>
                                              </div>
                                          </li>
                                        )) }
                                    </ul>
                                    <div className={styles.paginationContainer}>
                                        <ReactPaginate
                                            previousLabel={"<<"}
                                            nextLabel={">>"}
                                            breakLabel={"..."}
                                            pageCount={pageCount}
                                            marginPagesDisplayed={2}
                                            pageRangeDisplayed={3}
                                            onPageChange={handlePageClick}
                                            containerClassName={"pagination justify-content-right"}
                                            pageClassName={"page-item"}
                                            pageLinkClassName={"page-link"}
                                            previousClassName={"page-item"}
                                            previousLinkClassName={"page-link"}
                                            nextClassName={"page-item"}
                                            nextLinkClassName={"page-link"}
                                            breakClassName={"page-item"}
                                            breakLinkClassName={"page-link"}
                                            activeClassName={"active"}
                                        />
                                    </div>
                                  </div>
                                  : <label>No transactions are available.</label>
                                }
                            </div>
                          }
                      </div>
                  </Col>
              </Row>
            </Container>
              
          </div>
          {/* ============ card details section end============= */}
        </section>
        {/* ================dashboard container end================== */}
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Dashboard;