import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Prepaid.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PhoneInput from '../../components/PhoneInput';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Button } from "@material-ui/core";
import Link from 'next/link';
import { useRouter } from 'next/router';
import * as Icon from 'react-bootstrap-icons';

import Loader from '../../components/loader';
import Header from "../../components/Prepaid/Header";
import Footer from "../../components/Prepaid/Footer";

const Checkout = () => {
  return (
    <section className={styles.mainDash}>
      <SEO title="Checkout">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}> 
        <div className={styles.cardDetails}>
          <div className={styles.DashContainer}>
            <Container className={styles.paymentContainer}>              
              <div className={styles.PaymentLeft}>
                <div className={styles.infoContainer}>
                  <h2>Water Wise Car & Dog Wash</h2>
                  <h4>
                    ABN: 45 375 447 631
                    <br/>
                    5 Peace Avenue, Warragul VIC 3820
                  </h4>              
                </div>
              </div>
            
              <div className={styles.PaymentRight}>            
                  
                   
                  <Container className={styles.PaymentFormContainer}>  
                    <Row>
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}>           
                        <h2>
                          Transaction Successful
                        </h2>                   
                        <div className={styles.paymentDetCoantainer}>
                                                          
                        </div>  
                      </Col>
                      <Col lg={6} xl={6} xxl={6} xs={12} md={12}> 
                        <h2>
                          Share this Invoice
                        </h2>                   
                        <div className={styles.formCoantainer}>
                          <form id="associateForm" className='associate-form form-container-com'> 
                              <div className={styles.formgroup}>
                                  <label>Full Name</label>
                                  <input type="text" className="form-control" />
                              </div>
                              <div className={styles.formgroup}>
                                  <label>Email Address</label>
                                  <input type="text" className="form-control" />
                              </div>
                              <div className={styles.formgroup}>
                                  <label>Subject</label>
                                  <input type="text" className="form-control" />
                              </div>
                              <div className={styles.formgroup}>
                                  <label>Context</label>
                                  <textarea className="form-control"/>
                              </div>
                              <div className={styles.submitButton}>
                                <Button color="primary"
                                    variant="contained"
                                    type="submit">
                                    Send Via Email
                                </Button> 
                                                       
                            </div>
                          </form>
                          <span className={styles.disclaimerText}>
                            <Link legacyBehavior href={`/dashboard`}><a className={styles.linkButton}>Back to Dashboard</a></Link>
                          </span>
                          
                        </div> 
                      </Col>                  
                    </Row>
                  </Container>                    
                
              </div>
            </Container>
          </div>
        </div>
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Checkout;