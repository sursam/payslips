import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../../components/SEO';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";
import { Button } from "@material-ui/core";
import Link from 'next/link';
import * as Icon from 'react-bootstrap-icons';
import Header from "../../../components/Prepaid/Header";
import Footer from "../../../components/Prepaid/Footer";
import axios from "axios";
import Loader from '../../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import PaymentInvoice from "../../../components/PaymentInvoice";
import { pdf } from "@react-pdf/renderer";
import Moment from 'moment';

export async function getServerSideProps({ query }:any) {
  const resp = await fetch(`${process.env.serverUrl}get-transaction-details/${query.id}`);
  const transactionInfo = await resp.json()
  return {
    props: {transactionInfo},
  }
}

export default function PaymentSuccess({transactionInfo}:any) {
  const [endConsumerInfo, setEndConsumerInfo]:any = useState({});
  const [showLoader, setshowLoader] = useState(false);
  const [companyInfo, setCompanyInfo]:any = useState({});
  const [siteLogo, setSiteLogo] = useState('');
  const [accountInfo, setAccountInfo]:any = useState({});
  const [billingAddress, setBillingAddress] = useState('');
  //console.log(transactionInfo)
  useEffect(() => {
    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => { 
      if(typeof response.data.logo !== 'undefined'){
          setSiteLogo(response.data.logo);
      }      
    });
    axios.get(`${process.env.serverUrl}get-company-info/${transactionInfo.end_consumer_id}`,{}).then((response) => { 
      let companyData = {};
      if(response.data){
        response.data.forEach(infoData => {
          companyData[infoData.field_name] = infoData.field_value;
        });
        setCompanyInfo(companyData);          
      }      
    });
    axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${transactionInfo.end_consumer_id}`,{}).then((response) => {
      //console.log(response.data);
      setEndConsumerInfo(response.data);
    });
    axios.get(`${process.env.serverUrl}get-account-info-by-endconsumer/${transactionInfo.end_consumer_id}`,{}).then((response) => {
      setAccountInfo(response.data);
      if(response.data.account_name__r != null){
        let accountData = response.data.account_name__r;
        let billAddress:any = []; 
        Object.keys(accountData).map(key => {
          if(accountData[key] != null && key != 'attributes' && key != 'Name' && key != 'ABN__c' && key != 'ACN__c'){
            billAddress.push(accountData[key]);
          }
        });
        setBillingAddress(billAddress.join(', '));
        //console.log(response.data.account_name__r);
        //console.log(billAddress);
      }
    });
    
  }, 
  [])

  var [state, setState] = useState({
    full_name: '',
    email: '',
    subject: 'Tax Invoice',
    context: 'Hi,\n\nPlease find attached Tax Invoice.',
  });

  var { full_name, email, subject, context } = state;

  var validationSchema = Yup.object().shape({
    full_name: Yup.string()
        .required('Full name is required'),
    email: Yup.string()
        .required('Email is required')
        .email('Email is invalid'),
    subject: Yup.string()
        .required('Subject is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);
  
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
    //console.log(value)
  };

  const onSubmit = async (formData:any) => {
    setshowLoader(true);
    const blob = await pdf(
      <PaymentInvoice siteLogo={siteLogo} accountInfo={accountInfo} billingAddress={billingAddress} companyInfo={companyInfo} endConsumerInfo={endConsumerInfo} transactionInfo={transactionInfo} />
    ).toBlob();
    const filename = `invoice-${String(transactionInfo.salesforce_id).padStart(6, '0')}.pdf`;
    //const fileURL = URL.createObjectURL(blob);
    const fd = new FormData();
    //fd.append("blob", blob);
    fd.append('filename', filename);
    fd.append('full_name', formData.full_name);
    fd.append('email', formData.email);
    fd.append('subject', formData.subject);
    fd.append('context', formData.context);
    const config = {     
      headers: { 'content-type': 'application/json' }
    }
    //console.log(fd)
    var reader = new FileReader();
    reader.readAsDataURL(blob); 
    reader.onloadend = function() {
      var base64data:any = reader.result;                
      fd.append("attachedFile", base64data);
      axios.post(`${process.env.serverUrl}send-invoice`, fd, config).then((response) => {
        setshowLoader(false)
        if(!response.data.error){   
          toast.success(response.data.message); 
        }else{
          toast.error(response.data.message);
        }     
      });
    }
    
  }

  const submitForm = () => { 
    clearErrors()   
    reset(state)
  }
  
  return (
    <section className={styles.mainDash}>
      <SEO title="Payment Success">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}

      <section className={styles.MainContainer}> 
        <div className={styles.paymentSussess}>
          <div className={styles.CheckOutPart}>
            <div className={styles.cardDetails}>
                <div className={styles.DashContainer}>
                  <Container className={styles.paymentContainer}>              
                    <Row className={styles.paymentRow}>
                      <Col sm={4}>
                        <div className={styles.PaymentLeft}>
                          <div className={styles.infoContainer}>
                            <span className={styles.BackLink}><Link legacyBehavior href={"/dashboard"}><a className={styles.BackBtn}><Icon.ArrowLeft/></a></Link></span>                  
                            <h2>Recharge</h2>
                            <h4>
                              Type: {transactionInfo.recharge_procedure}
                              <br/>
                              Recharge Value: ${parseFloat(transactionInfo.net_amount).toFixed(2)}
                              <br/>
                              Surcharge: ${parseFloat(transactionInfo.stripe_fees + transactionInfo.tng_commission).toFixed(2)}
                            </h4> 
                            <div className={styles.totalAmountText}>${parseFloat(transactionInfo.total_amount).toFixed(2)}</div>
                          </div>
                        </div>
                      </Col>
                      <Col sm={4}>
                        <div className={styles.PaymentRight}>
                          <h2 className={styles.TitleContainer}>Transaction Successful <Icon.CheckCircleFill /></h2>
                          <div className={styles.invoiceDiv}> 
                            <div className={styles.headerPanel}>
                              <h3>Tax Invoice</h3>
                            </div>
                            <Container className={styles.invoiceContainer}>
                              <Row>
                                <Col sm={8}>
                                  <div>
                                    <div className={styles.InvoicedName}>Invoiced From:</div>
                                    {(accountInfo.account_name__r != null) ?
                                      <>
                                        {accountInfo.account_name__r.Name ? accountInfo.account_name__r.Name : ''} <br/>
                                        {accountInfo.account_name__r.ABN__c ? <>ABN: {accountInfo.account_name__r.ABN__c} <br/></> : ''}
                                        {billingAddress}
                                      </>
                                     : ''
                                    } 
                                     
                                  </div>
                                  <div>
                                    <div className={styles.InvoicedName}>Invoiced To:</div>
                                    {endConsumerInfo.name} <br/>
                                    {(endConsumerInfo.abn) ? <>ABN: {endConsumerInfo.abn} <br/></> : ''}
                                    {endConsumerInfo.mobile}
                                  </div>
                                </Col> 
                                <Col sm={4}>
                                  <div className={styles.InvoicedRight}>
                                    <div className={styles.InvoicedName}>Tax Invoice Number</div>
                                    INV-{String(transactionInfo.id).padStart(6, '0')}
                                    <div className={styles.InvoicedName}>Date</div>
                                    {Moment(transactionInfo.created_on).format('DD/MM/YYYY')}
                                  </div>
                                </Col>
                              </Row>
                              <Row>
                                <Col sm={8}>
                                  <div>
                                    {/*<div>Card Number: 1291209801</div>*/}
                                  </div>
                                </Col> 
                                <Col sm={4}>
                                  <div className={styles.ButtonAction}>
                                      <a href="#" className={(transactionInfo.recharge_procedure == 'Auto') ? '' : styles.TopUp}>{(transactionInfo.recharge_procedure == 'Auto') ? 'Auto Top-Up' : 'Manual Recharge'}</a>
                                  </div>
                                </Col>
                              </Row>
                              <div className={styles.invoiceTable}>
                                <table>
                                  <thead>
                                    <tr>
                                      <th>Description</th>
                                      <th>Charges</th>
                                      <th>Total Paid</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Corporate Card Credit</td>
                                      <td>${parseFloat(transactionInfo.net_amount).toFixed(2)}</td>
                                      <td>${parseFloat(transactionInfo.net_amount).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                      <td>Surcharge</td>
                                      <td>${parseFloat(transactionInfo.stripe_fees+transactionInfo.tng_commission).toFixed(2)}</td>
                                      <td>${parseFloat(transactionInfo.stripe_fees+transactionInfo.tng_commission).toFixed(2)}</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              <div className={styles.toFixed}>
                                <table>
                                  <tbody>
                                    <tr>
                                      <td>Total Paid</td>
                                      <td>${parseFloat(transactionInfo.total_amount).toFixed(2)}</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              <div className={styles.ExtraCredit}>
                                <table>
                                  <tbody>
                                    <tr>
                                      <td>Previous Balance</td>
                                      <td>${transactionInfo.previous_balance ? parseFloat(transactionInfo.previous_balance).toFixed(2) : (0).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                      <td>Extra Credit</td>
                                      <td>${transactionInfo.extra_credit ? parseFloat(transactionInfo.extra_credit).toFixed(2) : (0).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                      <td>Balance Received</td>
                                      <td>${parseFloat(transactionInfo.net_amount + transactionInfo.extra_credit).toFixed(2)}</td>
                                    </tr>
                                    <tr>
                                      <td>New Balance</td>
                                      <td>${parseFloat(transactionInfo.previous_balance + transactionInfo.net_amount + transactionInfo.extra_credit).toFixed(2)}</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              <div className={styles.footerPanel}>
                                <div className={styles.CopyRight}>&copy; {(new Date().getFullYear())} All Rights Reserved by Tap N Go Pty Ltd</div>
                                {siteLogo ? 
                                    <img src={`/uploads/logo/${siteLogo}`} alt="" />
                                  : ''}
                              </div>
                            </Container>
                          </div>  
                        </div>
                      </Col>
                      <Col sm={4}>
                        <div className={styles.PaymentRight}>   
                          <h2 className={styles.TitleContainer}>Share this Invoice</h2> 
                          <div className={styles.invoiceFormSection}>  
                            <div className={styles.shareInvoiceDiv}> 
                              <form id="invoiceForm" className='invoice-form member-invoice-form form-container-com' onSubmit={handleSubmit(onSubmit)}>
                                <div className={styles.formCoantainer}>
                                    <div className={styles.formgroup}>
                                        <label>Full Name</label>
                                        <input type="text" {...register('full_name', {onChange: handleChange})} value={full_name}  className={`form-control ${errors.full_name ? 'is-invalid' : (full_name ? 'is-valid' : '')}`}/>
                                        <div className="invalid-feedback">{errors.full_name?.message?.toString()}</div>
                                    </div>
                                    <div className={styles.formgroup}>
                                        <label>Email Address</label>
                                        <input type="text" {...register('email', {onChange: handleChange})} value={email} className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`} />
                                        <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                    </div>
                                    <div className={styles.formgroup}>
                                        <label>Subject</label>
                                        <input type="text" {...register('subject', {onChange: handleChange})} value={subject} className={`form-control ${errors.subject ? 'is-invalid' : (subject ? 'is-valid' : '')}`} />
                                        <div className="invalid-feedback">{errors.subject?.message?.toString()}</div>
                                    </div>
                                    <div className={styles.formgroup}>
                                        <label>Context</label>
                                        <textarea {...register('context', {onChange: handleChange})} className={`form-control ${context ? 'is-valid' : ''}`} >{context}</textarea>
                                    </div>
                                    <div className={styles.submitButton}>
                                        <input type="hidden" {...register('id')} value={transactionInfo.salesforce_id} />
                                        <Button color="primary"
                                            variant="contained"
                                            type="submit"
                                            onClick={submitForm} 
                                            disabled={showLoader} >
                                            { showLoader ? <Loader /> : null } Send Via Email
                                        </Button>
                                    </div>
                                    <div className={styles.submitButton}>
                                      <Link legacyBehavior href={"/dashboard"}><a className={styles.backToDashboard}>Back to Dashboard</a></Link>
                                    </div>
                                </div>                          
                              </form>
                            </div> 
                          </div>      

                        </div>
                      </Col>
                    </Row>
                  </Container>
                </div>
              </div>    
          </div>
        </div>
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}