import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Prepaid.module.css';
//import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PhoneInput from '../../components/PhoneInput';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
//import Select from 'react-select';
import { Button } from "@material-ui/core";
import Link from 'next/link';
import { useRouter } from 'next/router';
import MaskedInput from "react-maskedinput";

import Loader from '../../components/loader';
import Header from "../../components/Prepaid/Header";
import Footer from "../../components/Prepaid/Footer";

const Dashboard = () => {
  const [showLoader, setshowLoader] = useState(false);
  const [showLoginLoader, setShowLoginLoader] = useState(false);
  const [cardError, setCardError] = useState('');
  //var [cards, setCards] = useState<any[]>([]);
  const router = useRouter();
  useEffect(() => {
    const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated'))
    if(authenticated)
    {
      router.push('/dashboard');
    }
    getAvailableCards()
  }, 
  [])
  const getAvailableCards = (defaultCard = {}) => {
    axios.get(`${process.env.serverUrl}get-available-corporate-cards`,{}).then((response) => {             
        const cardOptions:any = [];
        if(Object.keys(defaultCard).length){
            cardOptions.push(defaultCard);
        }
        response.data.forEach(card => {
            var obj:any = {};
            obj['value'] = card.salesforce_id;
            obj['label'] = card.card_number;
            cardOptions.push(obj);
        }); 
        //setCards(cardOptions); 
        //console.log(defaultCard)
    });
  }

  /*const genderOptions = [
    { value: 'm', label: 'Male' },
    { value: 'f', label: 'Female' }
  ]*/    

  var [state, setState] = useState({
      first_name: '',
      last_name: '',
      mobile: '',
      email: '',
      dob: null,
      formattedBirthDate: '',
      //gender: '',
      car_reg: '',
      assigned_card: '',
  });

  var { first_name, last_name, mobile, email, dob, formattedBirthDate, /*gender,*/ car_reg, assigned_card } = state;
  
  const [mobileError, setMobileError] = useState(false);
  const handleMobileInput = ({ target: { value } }:any) => {
      setState(prevState => ({
          ...prevState,
          mobile: value.replace(/\D/g, '')
      }));
      
      if(mobile){
        setMobileError(true)
      }      
      if(!value.replace(/\D/g, '').length && mobileError)
        trigger('mobile')
  };
  const [dobError, setDobError] = useState(false);
  const handleDateInput = (dateOfBirth:any) => {
      let formattedDate = `${dateOfBirth.getFullYear()}-${
        dateOfBirth.getMonth() + 1
      }-${dateOfBirth.getDate()}`;
      setState(prevState => ({
          ...prevState,
          dob: dateOfBirth,
          formattedBirthDate: formattedDate
      }));
      if(dateOfBirth){
          clearErrors(["dob"])
          setDobError(false)
      }else{
          setDobError(true)
      }
      trigger('dob')
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    trigger(name);
    //console.log(value)
  };

  var validationSchema = Yup.object().shape({
      first_name: Yup.string()
        .required('First name is required'),
      last_name: Yup.string()
        .required('Last name is required'),
      mobile: Yup.string()
        .required('Mobile number is required')
        .min(10, 'Mobile number must be of 10 characters'),
      email: Yup.string()
        .required('Email is required')
        .email('Email is invalid'),
      dob: Yup.string()
        .required('Date of birth is required').nullable(),
      assigned_card: Yup.string()
        .required('Corporate card is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => { 
      clearErrors()   
      reset(state)
      if(!dob){
          setDobError(true)
      }
  }
  const onSubmit = (formData:any) => {
    setshowLoader(true);
    setCardError(''); 
    axios.post(`${process.env.serverUrl}register-indivisual-consumer`, formData).then((response) => {
      setshowLoader(false)
      if(response.data.error){
        toast.error(response.data.message);
      }else if(response.data.cardError){
        setCardError(response.data.message);
      }else{
        toast.success(response.data.message);
        resetForm();
        //getAvailableCards(); 
        localStorage.setItem("authenticated", '1');
        localStorage.setItem("associateId", response.data.associateId);
        localStorage.setItem("endConsumerId", response.data.endConsumerId);
        router.push('/dashboard');
      }   
    });
  };

  const resetForm = () => {
    clearErrors();
    getAvailableCards();    
    setState(prevState => ({
        ...prevState,
        first_name: '',
        last_name: '',
        mobile: '',
        email: '',
        dob: null,
        formattedBirthDate: '',
        //gender: '',
        car_reg: '',
        assigned_card: '',
    }));
  }

  /*const onGenderChange = (
    newValue
  ) => {
    setState(prevState => ({
      ...prevState,
      gender: newValue.value,
    }));
  };*/

  var [loginState, setLoginState] = useState({
    corporateCard: '',
    mobileNumber: '',
    dateOfBirth: null,
    formattedDob: '',
  });

  var { corporateCard, mobileNumber, dateOfBirth, formattedDob } = loginState;

  const [mobileNumberError, setMobileNumberError] = useState(false);
  const handlemobileNumberInput = ({ target: { value } }:any) => {
      setLoginState(prevState => ({
          ...prevState,
          mobileNumber: value.replace(/\D/g, '')
      }));
      if(mobileNumber){
        setMobileNumberError(true)
      }      
      if(!value.replace(/\D/g, '').length && mobileNumberError)
        triggerLogin('mobileNumber')
  };
  const [dateOfBirthError, setDateOfBirthError] = useState(false);
  const handleDateOfBirthInput = (dateOfBirth:any) => {
      let formattedDate = `${dateOfBirth.getFullYear()}-${
        dateOfBirth.getMonth() + 1
      }-${dateOfBirth.getDate()}`;

      setLoginState(prevState => ({
          ...prevState,
          dateOfBirth: dateOfBirth,
          formattedDob: formattedDate
      }));
      if(dateOfBirth){
        clearLoginErrors(["dob"])
        setDateOfBirthError(false)
      }else{
        setDateOfBirthError(true)
      }
      triggerLogin('dateOfBirth')
  };

  const handleCorporateCardChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setLoginState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    triggerLogin(name);
    //console.log(value)
  };

  var loginValidationSchema = Yup.object().shape({
      corporateCard: Yup.string()
        .required('Corporate Card is required'),
      mobileNumber: Yup.string()
        .required('Mobile number is required')
        .min(10, 'Mobile number must be of 10 characters'),
      dateOfBirth: Yup.string()
        .required('Date of birth is required').nullable(),
  });
  var loginFormOptions = { defaultValues: loginState, resolver: yupResolver(loginValidationSchema), };
  var { register: registerLogin, handleSubmit: handleLoginSubmit, reset: resetLogin, formState: { errors: loginErrors }, clearErrors: clearLoginErrors, trigger: triggerLogin } = useForm(loginFormOptions);

  const submitLoginForm = () => { 
    clearLoginErrors()   
    resetLogin(loginState)
    if(!dateOfBirth){
        setDateOfBirthError(true)
    }
  }
  const onSubmitLogin = (formData:any) => {
    /****Card No: 00232323001, Mobile No: 4545454545, Dob: 17/04/2000 ****/
    setShowLoginLoader(true); 
    axios.post(`${process.env.serverUrl}login-associate`, formData).then((response) => {
      setShowLoginLoader(false)
      if(!response.data.error){   
        toast.success(response.data.message); 
        resetLoginForm();
        localStorage.setItem("authenticated", '1');
        localStorage.setItem("userId", response.data.userId);
        localStorage.setItem("associateId", response.data.associateId);
        localStorage.setItem("endConsumerId", response.data.endConsumerId);
        router.push('/dashboard');
      }else{
        toast.error(response.data.message);
      }     
    });
  };

  const resetLoginForm = () => {
    clearLoginErrors(); 
    setLoginState(prevState => ({
        ...prevState,
        corporateCard: '',
        mobileNumber: '',
        dateOfBirth: null,
        formattedDob: '',
    }));
  }

  return (
    <section className={styles.mainDash}>
      <SEO title="Prepaid Authentication">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}> 
        <ToastContainer
          position="top-right"
          autoClose={10000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
        />
        <div className={styles.AuthContainer}>
          <div className={styles.DashboardLeft}>
            <div className={styles.signupContainer}>
              <h2>
                <span>New user? Register now?</span>
              </h2>
              <div className={styles.signupFormBox}>              
                <form id="associateRegForm" className='associate-reg-form form-container-com register-form-new' onSubmit={handleSubmit(onSubmit)}>
                  <div className={styles.formCoantainer}>
                      <div className={styles.formgroup}>
                          <label>First Name</label>
                          <input type="text" {...register('first_name', {onChange: handleChange})} value={first_name}  className={`form-control ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`}/>
                          <div  className={`invalid-feedback ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`}>{errors.first_name?.message?.toString()}</div>
                      </div>
                      <div className={styles.formgroup}>
                          <label>Last Name</label>
                          <input type="text" {...register('last_name', {onChange: handleChange})} value={last_name} className={`form-control ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`} />
                          <div  className={`invalid-feedback ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`}>{errors.last_name?.message?.toString()}</div>
                      </div>
                      <div className={styles.formgroup}>
                          <label>Mobile Number</label>
                          <PhoneInput className={`form-control ${((errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobile.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`}
                              {...register('mobile', {onChange: handleMobileInput})}>
                          </PhoneInput>
                          <div className={`invalid-feedback ${((errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobile.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`}>{(errors.mobile && !mobile || mobile.replace(/\D/g, '').length < 10) ? errors.mobile?.message?.toString() : ''}</div>
                      </div>
                      <div className={styles.formgroup}>
                          <label>Email Address</label>
                          <input type="text" {...register('email', {onChange: handleChange})} value={email} className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`} />
                          <div className={`invalid-feedback ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`}>{errors.email?.message?.toString()}</div>
                      </div>
                      <div className={styles.formgroup}>
                          <label>Date of Birth</label>
                          <DatePicker {...register('dob')} className={`form-control ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={handleDateInput} value={dob}  customInput={ <MaskedInput mask="11/11/1111" placeholder="dd/mm/yyyy" /> }/>
                          <input type='hidden' value={formattedBirthDate} {...register('formattedBirthDate')} />
                          <div className={`invalid-feedback ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`}>{dobError ? errors.dob?.message?.toString() : ''}</div>
                      </div>
                      {/*<div className={styles.formgroup}>
                          <label>Gender</label>
                          <Select options={genderOptions} value={genderOptions.find(item => item.value === gender) || ''} {...register('gender')} onChange={onGenderChange} className={`form-control form-select ${gender ? 'is-valid' : ''}`}/>  
                      </div>*/}
                      <div className={styles.formgroup}>
                          <label>Car Registration</label>
                          <input type="text" {...register('car_reg', {onChange: handleChange})} value={car_reg} className={`form-control ${car_reg ? 'is-valid' : ''}`} />

                      </div>
                      <div className={styles.formgroup}>
                          <label>Corporate Card</label>
                          <input type="text" {...register('assigned_card', {onChange: handleChange})} value={assigned_card} className={`form-control ${(errors.assigned_card || (cardError != '')) ? 'is-invalid' : (assigned_card ? 'is-valid' : '')}`} />
                          <div  className={`invalid-feedback ${(errors.assigned_card || (cardError != '')) ? 'is-invalid' : (assigned_card ? 'is-valid' : '')}`}>{(cardError != '') ? cardError : errors.assigned_card?.message?.toString()}</div>
                      </div>
                      <div className={styles.submitButton}>
                          <Button color="primary"
                              variant="contained"
                              type="submit"
                              onClick={submitForm} 
                              disabled={showLoader} >
                              { showLoader ? <Loader /> : null } Register Now
                          </Button>                          
                      </div>
                  </div>                  
                </form>
              </div>
            </div>
          </div>
          <div className={styles.DashboardRight}>
            <div className={styles.loginContainer}>
              <h2>
                  <span>Existing user? Login now</span>
              </h2>
              <div className={styles.LoginForm}>
                <div className={styles.LoginFormBox}>
                  <h2>
                    <img src={'/assets/images/login-icon.png'} />
                    <span>Associate's Details</span>
                  </h2>
                  <form className='loginForm loginFormNew' onSubmit={handleLoginSubmit(onSubmitLogin)}>
                    <Row>
                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                          <div className={styles.formgroup}>
                              <label>Corporate Card</label>
                              <input type="text" {...registerLogin('corporateCard', {onChange: handleCorporateCardChange})} className={`form-control ${loginErrors.corporateCard ? 'is-invalid' : (corporateCard ? 'is-valid' : '')}`} value={corporateCard}/>
                              <div className={`invalid-feedback ${loginErrors.corporateCard ? 'is-invalid' : (corporateCard ? 'is-valid' : '')}`}>{loginErrors.corporateCard?.message?.toString()}</div>
                          </div>
                        </Col>
                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                          <div className={styles.formgroup}>
                            <label>Mobile Number</label>
                            {/*<MaskedInput mask="1111 111 111" {...registerLogin('mobileNumber', {onChange: handlemobileNumberInput})} className={`form-control ${((loginErrors.mobileNumber && !mobileNumber) || (loginErrors.mobileNumber && mobileNumber && mobileNumber.length < 10)) ? 'is-invalid' : ( mobileNumber.length == 10 ? 'is-valid' : '')}`}  />
                            <div className={`invalid-feedback ${((loginErrors.mobileNumber && !mobileNumber) || (loginErrors.mobileNumber && mobileNumber && mobileNumber.length < 10)) ? 'is-invalid' : ( mobileNumber.length == 10 ? 'is-valid' : '')}`}>{(loginErrors.mobileNumber && !mobileNumber || mobileNumber.length < 10) ? loginErrors.mobileNumber?.message?.toString() : ''}</div>*/}

                            <PhoneInput className={`form-control ${((loginErrors.mobileNumber && !mobileNumber) || (loginErrors.mobileNumber && mobileNumber && mobileNumber.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobileNumber.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`}
                                {...registerLogin('mobileNumber', {onChange: handlemobileNumberInput})}>
                            </PhoneInput>
                            <div className={`invalid-feedback ${((loginErrors.mobileNumber && !mobileNumber) || (loginErrors.mobileNumber && mobileNumber && mobileNumber.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobileNumber.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`}>{(loginErrors.mobileNumber && !mobileNumber || mobileNumber.replace(/\D/g, '').length < 10) ? loginErrors.mobileNumber?.message?.toString() : ''}</div>
                          </div>
                        </Col> 
                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                          <div className={styles.formgroup}>
                            <label>Date of Birth</label>
                            <DatePicker {...registerLogin('dateOfBirth')} className={`form-control ${dateOfBirthError ? 'is-invalid' : (dateOfBirth ? 'is-valid' : '')}`} dateFormat="dd/MM/yyyy" selected={dateOfBirth} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={handleDateOfBirthInput} value={dateOfBirth}  customInput={ <MaskedInput mask="11/11/1111" placeholder="dd/mm/yyyy" /> }/>
                            <input type='hidden' value={formattedDob} {...registerLogin('formattedDob')} />
                            <div className={`invalid-feedback ${dateOfBirthError ? 'is-invalid' : (dateOfBirth ? 'is-valid' : '')}`}>{dateOfBirthError ? loginErrors.dateOfBirth?.message?.toString() : ''}</div>
                          </div>
                        </Col>
                        {/*<Col xs={6} sm={6} md={6} xl={6} lg={6}></Col>
                        <Col xs={6} sm={6} md={6} xl={6} lg={6}>
                          <div className={styles.rememberForget}>
                            <Link legacyBehavior href={"/forgot-password"}>Forgot your details?</Link> 
                          </div> 
                        </Col>*/}
                      <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                          <div className={styles.SubmitButton}>
                              <Button color="primary" variant="contained" type="submit" onClick={submitLoginForm} disabled={showLoginLoader} >{ showLoginLoader ? <Loader /> : null } Login Now </Button>
                          </div>
                      </Col>
                    </Row>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Dashboard;