import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../components/SEO';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";
import Link from 'next/link';
import * as Icon from 'react-bootstrap-icons';
import Header from "../../components/Prepaid/Header";
import Footer from "../../components/Prepaid/Footer";
import axios from "axios";
import GlobalContext from '../../components/GlobalContext';
import { loadStripe } from "@stripe/stripe-js";
import 'react-confirm-alert/src/react-confirm-alert.css';
import LoadingScreen from "../../components/loadingScreen";
import PaymentSource from "../../components/Prepaid/PaymentSource";

export default function PaymentMethods(props) {
  const [listPaymentSources, setListPaymentSources] = useState({});
  const [showAccountLoader, setShowAccountLoader] = useState(true);
  const { stripeCreds } = useContext(GlobalContext);
  const stripePromise = loadStripe(stripeCreds.publishableKey);
  const [cardOptions, setCardOptions] = useState({});
  const [bankOptions, setBankOptions] = useState({});
  //const [clientSecret, setClientSecret] = useState('');
  const [isFetching, setIsFetching] = useState(false);
  
  const [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('endConsumerId')) || '',
    backupItem: Array(),
    primaryItem: ''
  });
  const { endConsumerId, backupItem, primaryItem} = state;

  useEffect(() => {    
    listSources();  
    axios.get(`${process.env.serverUrl}get-endconsumer-selected-sources/${endConsumerId}`,{}).then((response) => {
      const bckItem:any = [];
      response.data.forEach((paymentSource, k):any => {
          switch(paymentSource.account_type){
            case 'primary':
              setState(prevState => ({
                ...prevState,
                primaryItem: paymentSource.source_id
              }));
              break;
            case 'backup':
              bckItem.push(paymentSource.source_id);
              break;
          }
      });
      setState(prevState => ({
        ...prevState,
        backupItem: bckItem
      }));
    });  
    loadPaymentForm(endConsumerId, 'card'); 
    loadPaymentForm(endConsumerId, 'bank'); 
  }, 
  [])


  const loadPaymentForm = (endConsumerId, type) => {
    axios.get(`${process.env.serverUrl}get-stripe-client-secret/${endConsumerId}/?type=${type}`,{}).then((response) => {
      //setClientSecret(response.data.client_secret);
      const appearance = {
        theme: 'stripe',
      };
      switch(type){
        case 'card': 
          setCardOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
        case 'bank': 
          setBankOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
      }      
    });
  }
  const listSources = () => {
    axios.get(`${process.env.serverUrl}get-endconsumer-account-sources/${endConsumerId}`,{}).then((response) => {
      setListPaymentSources(response.data);
      setShowAccountLoader(false);
    });
  }

  
  return (
    <section className={styles.mainDash}>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      <SEO title="Payment Methods">
        <meta id="meta-description" name="description" content="Payment Methods" />
        <meta id="meta-keywords" name="keywords" content="Payment Methods" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <Header/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}> 
        <div className='paymentContainerPart'>
          <div className={styles.paymentMethods}>
            <div className={styles.CheckOutPart}>
              <div className={styles.cardDetails}>
                <div className={styles.DashContainer}>
                  <Container className={styles.paymentContainer}>
                    
                    <Row className={styles.paymentRow}>
                      <Col sm={6}>
                        <div className={styles.PaymentLeft}>
                          <div className={styles.infoContainer}>
                            <span className={styles.BackLink}><Link legacyBehavior href={"/dashboard"}><a className={styles.BackBtn}><Icon.ArrowLeft/></a></Link></span>                  
                            <h2>Payment Details</h2>      
                          </div>
                        </div>
                      </Col>
                      <Col sm={6}>
                        <div className={styles.PaymentRight}>
                          <div className={`cardSection auto_recharge_card ${styles.SourcePanel}`}>            
                            <div className='sourceListHead'>
                                <h2>Preferred Payment Method</h2>
                            </div>
                            <PaymentSource />
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Container>
                </div>
              </div>
            </div> 
          </div> 
        </div>           
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <Footer/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}