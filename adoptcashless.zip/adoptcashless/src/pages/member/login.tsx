import React, {useState, useContext, useEffect} from 'react';
/*import Header from "components/Front/Header/Header";
import Footer from "components/Front/Footer/Footer";*/
//import { Checkbox } from '@paljs/ui/Checkbox';
import styles from '../../styles/Login.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Link from 'next/link';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import { useRouter } from 'next/router';
import SEO from '../../components/SEO';
import bcrypt from 'bcryptjs';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

//import * as Icon from 'react-bootstrap-icons';
export default function Index() {  

  //const { serverUrl } = useContext(GlobalContext);
  const router = useRouter();
  //const [successMessage, setsuccessMessage] = useState(null);
  //const [validationErrors, setvalidationErrors] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});

  const [checkboxChecked, setcheckboxChecked] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberlogin') && localStorage.getItem('rememberlogin') === 'true') || false;
  });
  const [username, setusername] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberUsername')) || '';
  });
  const [password, setpassword] = useState(() => {
    return (typeof localStorage !== 'undefined' && localStorage.getItem('rememberPassword')) || '';
  });

  useEffect(() => {
    const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated'))

    //console.log(authenticated);

    if(authenticated)
    {
      router.push('/dashboard');
    }  

    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
      setLogo(response.data.logo);   
    });

  }, [])  
  
  const validationSchema = Yup.object().shape({
      username: Yup.string().required('Username is required'),
      password: Yup.string().required('Password is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);
    //setsuccessMessage(null);
    //setvalidationErrors(null);  

    if(checkboxChecked){
      localStorage.setItem('rememberUsername', formData.username)
      localStorage.setItem('rememberPassword', formData.password)
    }else{
      localStorage.setItem('rememberUsername', '')
      localStorage.setItem('rememberPassword', '')
    }

    const hashedPassword = bcrypt.hashSync(formData.password, process.env.hashedkey)

    const data = {
      username: formData.username,
      password: hashedPassword
    };
    axios.post(`${process.env.serverUrl}member-login`, data).then((response) => {
      //router.push('/dashboard');
      setshowLoader(false)
      //console.log(response.data);
      if(response.data.status){
        localStorage.setItem("authenticated", '1');
        localStorage.setItem("userId", response.data.userId);
        localStorage.setItem("salesforce_id", response.data.salesforce_id);
        router.push('/dashboard');
        toast.success(response.data.message); 
      }else{
        toast.error(response.data.message);
      }        
    });
  };    
  

  const onChangeCheckbox = (e: any) => {
    const checkboxVal:any = e.target.checked;
    setcheckboxChecked(checkboxVal)
    localStorage.setItem('rememberlogin', checkboxVal)
  };


  return (
    <section className={styles.LoginMainContainer}>
      <SEO title="Login">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
{/* =============sign up form section================== */}
    <section className={styles.LoginForm}>
    <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                    <div className={styles.LoginFormBox}>
                        <h2>
                          <img src={'/assets/images/login-icon.png'} />
                          <span>Login Now</span>
                        </h2>
                        <div className={styles.ErrorSummary}>
                            {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                            <ToastContainer
                                position="top-right"
                                autoClose={10000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable
                                pauseOnHover
                                theme="light"
                            />
                        </div>
                        <form className='loginForm' onSubmit={handleSubmit(onSubmit)}>
                          <Row>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                    Username
                                    </label>
                                    <input type="text" {...register('username')} value={username} onChange={event => setusername(event.target.value)} placeholder="Username" className={`form-control ${errors.username ? 'is-invalid' : ''}`} autoComplete="off"/>
                                    <div className="invalid-feedback">{errors.username?.message?.toString()}</div>
                                </div>
                              </Col>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                      Password
                                    </label>
                                     <input type="password" {...register('password')} value={password}  onChange={event => setpassword(event.target.value)} placeholder="Password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} autoComplete="off" />
                                    <div className="invalid-feedback">{errors.password?.message?.toString()}</div>
                                </div>
                              </Col> 
                               <Col xs={6} sm={6} md={6} xl={6} lg={6}>
                                <label className="checklabel"><input type="checkbox" onChange={(e) => onChangeCheckbox(e)}/>Remember me</label>
                              </Col> 
                              <Col xs={6} sm={6} md={6} xl={6} lg={6}>
                                <div className={styles.rememberForget}>
                                  <div className={styles.rememberLogin}>
                                      {/* <input type="checkbox" id="remember" name="remember" onChange={(value) => onChangeCheckbox(value)} /> Remember My Login Details */}
                                  </div>
                                  <Link legacyBehavior href={"/forgot-password"}>Forgot Password?</Link> 
                                </div> 
                              </Col>
                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Login Now </Button>
                                </div>
                            </Col>
                          </Row>

                        </form>
                        {/* <div className={styles.loginAlt}> New Here? <Link legacyBehavior href={"/signup"}>Create an Account Now!</Link> </div> */}
                        {/*<div className={styles.loginAlt}> New Here? <a href="#">Create an Account Now!</a> </div>*/}
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
  <div className="footerContainer">
        © {new Date().getFullYear()} All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}