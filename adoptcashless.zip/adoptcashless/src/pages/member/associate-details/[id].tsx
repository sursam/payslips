import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import Link from 'next/link';
import SEO from '../../../components/SEO';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

import MemberHeader from "../../../components/Front/Header/MemberHeader";
import MemberMenu from "../../../components/Front/Header/MemberMenu";
import MemberFooter from "../../../components/Front/Footer/MemberFooter";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import axios from "axios";
import Loader from '../../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import Select from 'react-select';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import PhoneInput from '../../../components/PhoneInput';
import LoadingScreen from '../../../components/loadingScreen';
import ToggleSwitch from '../../../components/ToggleSwitch';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import moment from 'moment';

import GlobalContext from '../../../components/GlobalContext';

export async function getServerSideProps({ query }:any) {
    const resp = await fetch(`${process.env.serverUrl}get-associate-details/${query.id}`);
    const associateInfo = await resp.json()
    return {
      props: {associateInfo},
    }
}

const AssociateDetails = ({associateInfo}:any) => {
    //const [associateDetails, setAssociateDetails] = useState([]);
    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    
    let autoTriggerValue = (associateInfo.card !== null) ? associateInfo.card.topup_trigger_val : 0;
    const [autoTriggerVal, setAutoTriggerVal] = useState(autoTriggerValue);
    let autoRechargeValue = (associateInfo.card !== null) ? associateInfo.card.topup_recharge_val : 0;
    const [autoRechargeVal, setAutoRechargeVal] = useState(autoRechargeValue);
    const [isFetching, setIsFetching] = useState(false);
    let assCard = (associateInfo.card !== null) ? associateInfo.card : {};
    const [associateCard, setAssociateCard] = useState(assCard);
    const [isShowEditForm, setIsShowEditForm] = useState(false);
    var [availableCards, setAvailableCards] = useState<any[]>([]);
    var [latestTransactions, setLatestTransactions] = useState({});
    const [isShowLinkCard, setIsShowLinkCard] = useState(false);
    let assCardStatus = (associateInfo.card !== null && associateInfo.card.status == '1') || false;
    //console.log(associateInfo)
    const [cardStatus, setCardStatus] = useState(assCardStatus);

    let available_credit = (associateInfo.card !== null) ? associateInfo.card.available_credit : 0;
    const [availableCredit, setAvailableCredit] = useState(available_credit.toFixed(2));

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => {
        var defaultCardObj:any = {};
        if(associateInfo.card.salesforce_id){
            defaultCardObj['value'] = assCard.salesforce_id;
            defaultCardObj['label'] = assCard.card_number;
        }
        getAvailableCards(defaultCardObj);
        getAssociates();
        setShow(true);
    };
    var [transferState, setTransferState] = useState({
        transferAssociateId: '',
        transferCard: (associateInfo.card !== null) ? associateInfo.card.salesforce_id : ''
    });
    var { transferAssociateId, transferCard } = transferState;
    var [associates, setAssociates] = useState<any[]>([]);

    const daysToShow = 30;

    useEffect(() => {
        //setAssociateDetails(associateInfo)
        //console.log(associateInfo)
        getAssociates();
        getAvailableCards();
        /*axios.get(`${process.env.serverUrl}get-endconsumer-details/${endConsumerId}`,{}).then((response) => {
            setStateCredit(prevState => ({
              ...prevState,
              unAssignedCredit: response.data.UnAssigned_Credit__c,
            }));
        });*/
        axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
            let autoTopup = 0;
            let autoTopupSourceId = '';
            let autoTopupSourceType = '';
            let autoTopupRechargeAmount = '';
            let autoTopupTriggerPoint = '';
            let autoTopupCreditVal = '';
            if(response.data.is_auto_topup == "1"){
                autoTopup = 1;
                autoTopupSourceId = response.data.auto_topup.source_id;
                autoTopupSourceType = response.data.auto_topup.source_type;
                autoTopupRechargeAmount = response.data.auto_topup.auto_recharge_amount;
                autoTopupTriggerPoint = response.data.auto_topup.auto_trigger_point;
                autoTopupCreditVal = response.data.auto_topup.extra_credit_val;
            }
            let unAssignedCred= (response.data.current_balance != null) ? response.data.current_balance : 0;
            setStateCredit(prevState => ({
                ...prevState,
                unAssignedCredit: unAssignedCred,
                autoTopup: autoTopup,
                autoTopupSourceId: autoTopupSourceId,
                autoTopupSourceType: autoTopupSourceType,
                autoTopupRechargeAmount: autoTopupRechargeAmount,
                autoTopupTriggerPoint: autoTopupTriggerPoint,
                autoTopupCreditVal: autoTopupCreditVal,
            }));
        });
        axios.get(`${process.env.serverUrl}get-stripe-account/${endConsumerId}`,{}).then((response) => {
            if(typeof response.data.records != 'undefined' && response.data.records.length > 0){ 
                setStateCredit(prevState => ({
                    ...prevState,
                    connectedAccount: response.data.records[0].account_name__r.Stripe_Acc_Id__c,
                    stripeCustomerId: response.data.records[0].Stripe_Customer_Id__c,
                }));
            }
        });
        if(associateInfo.card !== null){
            axios.get(`${process.env.serverUrl}get-latest-transactions/${associateInfo.card.card_id}/${daysToShow}`,{}).then((response) => {
                //console.log(response.data);
                var latestTxns = {};
                response.data.forEach( function( obj ){
                    var settlement_date = customFormatDate(obj.settlement_time, 'd/m/y');
                    if( latestTxns[ settlement_date ] === undefined ) 
                        latestTxns[ settlement_date ] = []
                    latestTxns[ settlement_date ].push( obj)
                })                
                setLatestTransactions(latestTxns);
            });
        }
    }, 
    [])
    const getAssociates = () => {
        axios.get(`${process.env.serverUrl}get-available-associate/${endConsumerId}`,{}).then((response) => {             
            const associateOptions:any = [];
            response.data.forEach(ass => {
                var obj:any = {};
                obj['value'] = ass.salesforce_id;
                obj['label'] = ass.name;
                associateOptions.push(obj);
            }); 
            setAssociates(associateOptions);     
        });
    }
    const getAvailableCards = (defaultCard = {}) => {
        axios.get(`${process.env.serverUrl}get-available-cards/${endConsumerId}`,{}).then((response) => {             
            const cardOptions:any = [];
            if(Object.keys(defaultCard).length){
                cardOptions.push(defaultCard);
            }
            response.data.forEach(card => {
                var obj:any = {};
                obj['value'] = card.salesforce_id;
                obj['label'] = card.card_number;
                cardOptions.push(obj);
            }); 
            setAvailableCards(cardOptions); 
            //console.log(defaultCard)
        });
    }

    const customFormatDate = (date, format = 'y-m-d') => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
        let retDate = '';
        switch(format){
            case 'd/m/y': retDate = [day, month, year].join('/');
                break;
            case 'y-m-d': 
            default:
                retDate = [year, month, day].join('-');
                break;
        }
        return retDate;
    }
    const formatAMPM = (d) => {
        var date = new Date(d)
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        var strMinutes = (minutes < 10) ? '0'+minutes : minutes;
        var strTime = hours + ':' + strMinutes + ' ' + ampm;
        return strTime;
    }

    const unlinkCard = (e) => {
        e.preventDefault();
        let salesforceId = e.target.dataset.id;
        confirmAlert({
            title: 'Confirm to unlink',
            message: 'Are you sure to do this?',
            buttons: [
            {
                label: 'Yes',
                onClick: () => {
                    if(salesforceId){
                        setIsFetching(true);
                        axios.get(`${process.env.serverUrl}unlink-corporate-card/${salesforceId}`,{}).then((response) => {  
                            if(response.data.status)
                            {
                                setAssociateCard({});
                                setIsFetching(false);
                                getAvailableCards();
                            } 
                        });
                    }
                }
            },
            {
                label: 'No',
            }
            ]
        });
    }
    const linkCard = (e) => {
        e.preventDefault();
        setIsShowLinkCard(true);
    }
    const cancelLinkForm = (e) => {
        e.preventDefault();
        setIsShowLinkCard(false);
    }

    const [showLoader, setshowLoader] = useState(false);
    const genderOptions = [
        { value: 'm', label: 'Male' },
        { value: 'f', label: 'Female' }
    ]
    var [state, setState] = useState({
        first_name: associateInfo.first_name,
        last_name: associateInfo.last_name,
        mobile: associateInfo.mobile,
        email: associateInfo.email,
        dob: new Date(Date.parse(associateInfo.date_of_birth)),
        gender: associateInfo.gender,
        car_reg: associateInfo.car_reg,
        //assigned_card: (associateInfo.card !== null) ? associateInfo.card.salesforce_id : '',
        status: '1',
    });
    var { first_name, last_name, mobile, email, dob, gender, car_reg } = state;

    const [mobileError, setMobileError] = useState(false);
    const handleMobileInput = ({ target: { value } }:any) => {
        let mobileVal = value.replace('/\D/g', '');
        //console.log(mobileVal);
        setState(prevState => ({
            ...prevState,
            mobile: mobileVal
        }));
        if(mobileVal){
          setMobileError(true)
        }
        if(!mobileVal.length && mobileError)
          trigger('mobile')
    };
    /*const handleMobileInput = ({ target: { value } }:any) => setState(prevState => ({
        ...prevState,
        mobile: value.replace(/\s/g,'')
    }));*/

    const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
    var validationSchema = Yup.object().shape({
        first_name: Yup.string()
            .required('First name is required'),
        last_name: Yup.string()
            .required('Last name is required'),
        mobile: Yup.string()
            .matches(phoneRegExp, 'Mobile number is not valid')
            .required('Mobile number is required'),
        email: Yup.string()
            .email('Email is invalid')
            .required('Email is required'),
        dob: Yup.string()
            .required('Date of birth is required').nullable(),
    });
    var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

    const submitForm = () => { 
        clearErrors();
        reset(state);
        if(!dob){
            setDobError(true)
        }
    }

    const onUpdateSubmit = (formData:any) => {
        setshowLoader(true);  
        axios.post(`${process.env.serverUrl}save-associate`, formData).then((response) => {
          setshowLoader(false)
          //console.log(response.data)
          if(!response.data.error){
            setIsShowEditForm(false);    
            toast.success(response.data.message);  
          }else{
            toast.error(response.data.message);
          }       
        });
    };
    
    const resetForm = () => {
        clearErrors();
        setIsShowEditForm(false);
        setDobError(false);
    }
    const onGenderChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          gender: newValue.value,
        }));
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
        const { name, value } = event.target;
        setState(prevState => ({
          ...prevState,
          [name]: value,
        }));
        //console.log(value)
    };

    const showEditForm = (e) => {
        e.preventDefault();
        setIsShowEditForm(true);
    }

    var [linkState, setLinkState] = useState({
        assigned_card: (associateInfo.card !== null) ? associateInfo.card.salesforce_id : ''
    });
    var { assigned_card } = linkState;
    var validationLinkSchema = Yup.object().shape({
        assigned_card: Yup.string().required('Select a Corporate Card'),
    });
    var linkFormOptions = { defaultValues: linkState, resolver: yupResolver(validationLinkSchema) };
    var { register: registerLink, handleSubmit: handleSubmitLink, reset: resetLink, formState: { errors: errorsLink } } = useForm(linkFormOptions);

    const submitLinkForm = () => {    
        resetLink(linkState)
    }

    const onLinkCardSubmit = (formData:any) => {
        setshowLoader(true);  
        axios.post(`${process.env.serverUrl}link-corporate-cards`, formData).then((response) => {
          setshowLoader(false)

          if(response.data.status == '1'){
            setIsShowLinkCard(false);    
            toast.success(response.data.message);
            axios.get(`${process.env.serverUrl}get-card-details/${assigned_card}`,{}).then((response) => {             
                var obj:any = {};
                obj['id'] = response.data.id;
                obj['unique_id'] = response.data.unique_id;
                obj['salesforce_id'] = response.data.salesforce_id;
                obj['card_number'] = response.data.card_number;
                obj['card_type'] = response.data.card_type;
                setAssociateCard(obj);
                setAvailableCredit((response.data.available_credit).toFixed(2));
                setCardStatus(true);
                //getAvailableCards();
            });
          }else{  
            toast.error(response.data.message);
          }      
        });
    };

    const onCardChange = (
        newValue
      ) => {
        setLinkState(prevState => ({
          ...prevState,
          assigned_card: newValue.value,
        }));
    };

    const changeCardStatus = (e) => {
        e.preventDefault();
        let associateId = e.target.dataset.assid;
        let salesforceId = e.target.dataset.id;
        let status = cardStatus ? '0' : '1';
        let statusText = cardStatus ? 'In-Active' : 'Active';
        let cardData = {
            'associate_id': associateId,
            'salesforce_id': salesforceId,
            'status': status
        };
        confirmAlert({
            title: `Confirm to ${statusText}`,
            message: 'Are you sure to do this?',
            buttons: [
            {
                label: 'Yes',
                onClick: () => {
                    if(salesforceId){
                        setIsFetching(true);
                        axios.post(`${process.env.serverUrl}update-card-status-details`, cardData).then((response) => {
                            setIsFetching(false);
                            if(!response.data.error){
                                setCardStatus(!cardStatus)
                                //setAssociateCard({});
                                setIsFetching(false);
                                toast.success(response.data.message);
                            }else{
                                toast.error(response.data.message);
                            }       
                        });
                    }
                }
            },
            {
                label: 'No',
            }
            ]
        });
        
    }

    var validationTransferSchema = Yup.object().shape({
        transferAssociateId: Yup.string().required('Select an Associate'),
    });
    var transferFormOptions = { defaultValues: transferState, resolver: yupResolver(validationTransferSchema) };
    var { register: registerTransfer, handleSubmit: handleSubmitTransfer, reset: resetTransfer, formState: { errors: errorsTransfer } } = useForm(transferFormOptions);

    const submitTransferForm = () => {    
        resetTransfer(transferState)
    }

    const onTransferAssociateChange = (
        newValue
      ) => {
        setTransferState(prevState => ({
          ...prevState,
          transferAssociateId: newValue.value,
        }));
    };
    const cancelTransferForm = (e) => {
        e.preventDefault();
        setTransferState(prevState => ({
            ...prevState,
            transferAssociateId: '',
            transferCard: (associateInfo.card !== null) ? associateInfo.card.salesforce_id : '',
        }));
        setShow(false);
    }

    const onTransferCardChange = (
        newValue
      ) => {
        setTransferState(prevState => ({
          ...prevState,
          transferCard: newValue.value,
        }));
    };

    const onTransferAssociateSubmit = (formData:any) => {
        setshowLoader(true);  
        axios.post(`${process.env.serverUrl}transfer-corporate-card-associate`, formData).then((response) => {
          setshowLoader(false);
          setShow(false);
          if(response.data.status == '1'){
            toast.success(response.data.message);
            getAssociates();   
            getAvailableCards(); 
            if(transferCard == assigned_card){
                setAssociateCard({});
                setCardStatus(false);
            }    
          }else{  
            toast.error(response.data.message);
          }   
        });
    };

    const autoTopupCheck = (associateInfo.card !== null && associateInfo.card.auto_topup == '1') ? true : false;
    const [isToggled, setIsToggled] = useState(autoTopupCheck);
    const showAutoTopUp = (state) => {
        setIsToggled(state);
        let formData = {
            salesforce_id: associateInfo.card.salesforce_id,
            auto_topup: state ? '1' : '0',
        };
        updateAutoTopupValues(formData);
    };

    const [showCredit, setShowCredit] = useState(false);
    const handleCloseCredit = () => setShowCredit(false);
    const handleShowCredit = () => {
        setShowCredit(true);
    };
    const { stripeCreds } = useContext(GlobalContext);
    const { tngPercentAmount } = useContext(GlobalContext);
    const [showCreditLoader, setshowCreditLoader] = useState(false);

    var [stateCredit, setStateCredit] = useState({
        endConsId: endConsumerId,
        unAssignedCredit: 0,
        cardAssociate: associateCard.salesforce_id,
        desiredAmount: '',
        autoTopup: 0,
        autoTopupSourceId: '',
        autoTopupSourceType: '',
        autoTopupRechargeAmount: '',
        autoTopupTriggerPoint: '',
        autoTopupCreditVal: '',
        connectedAccount: '',
        stripeCustomerId: '',
        stripeCredentials: stripeCreds,
        tngPercentAmnt: tngPercentAmount,
    });
    var { endConsId, unAssignedCredit, cardAssociate, desiredAmount, endConsId, autoTopup, autoTopupSourceId, autoTopupSourceType, autoTopupRechargeAmount, autoTopupTriggerPoint, autoTopupCreditVal, connectedAccount, stripeCustomerId, stripeCredentials, tngPercentAmnt } = stateCredit;

    var validationCreditSchema = Yup.object().shape({
        desiredAmount: Yup.string().required('Desired Amount is required'),
    });

    var formCreditOptions = { resolver: yupResolver(validationCreditSchema) };
    var { register: registerCredit, handleSubmit: handleCreditSubmit, reset: resetCredit, formState: { errors: errorsCredit } } = useForm(formCreditOptions);

    const submitCreditForm = () => {    
        resetCredit(stateCredit)
    }

    const onCreditSubmit = (formData:any) => {
        setshowCreditLoader(true); 
        axios.post(`${process.env.serverUrl}allocate-unassigned-credit`, formData).then((response) => {
            setshowCreditLoader(false)
            if(response.data.error == 0){  
            /*var currentBalanceView = document.querySelector('#currentBalanceView');
            if(currentBalanceView)
                currentBalanceView.innerHTML = unAssignedCredit.toFixed(2);*/
            toast.success(response.data.message);
            setAvailableCredit((parseFloat(availableCredit) + parseFloat(desiredAmount)).toFixed(2));
            resetCreditForm();
            handleCloseCredit();
            }else{
            toast.error(response.data.message);
            }        
        });
    };

    const resetCreditForm = () => { 
        let currentBalance = (unAssignedCredit - parseFloat(desiredAmount)).toFixed(2);       
        setStateCredit(prevState => ({
            ...prevState,
            unAssignedCredit: parseFloat(currentBalance),
            desiredAmount: '',
            autoTopup: 0,
            autoTopupSourceId: '',
            autoTopupSourceType: '',
            autoTopupRechargeAmount: '',
            autoTopupTriggerPoint: '',
            autoTopupCreditVal: '',
        }));
    }
    const handleCreditFieldChange = (event) => {    
        const { name, value } = event.target;
        setStateCredit(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const [dobError, setDobError] = useState(false);
    const handleDateInput = (dateOfBirth:any) => {
        let dobValue = moment(dateOfBirth).isValid() ? dateOfBirth : '';
        setState(prevState => ({
            ...prevState,
            dob: dobValue
        }));
        if(dobValue){
            clearErrors(["dob"])
            setDobError(false)
        }else{
            setDobError(true)
        }
        trigger('dob')
    };

    const handleAutoTriggerVal = (event) => { 
        let triggerVal = event.target.value;
        setAutoTriggerVal(triggerVal);
    };
    const handleAutoRechargeVal = (event) => { 
        let rechargeVal = event.target.value;
        setAutoRechargeVal(rechargeVal);
    };
    const handleAutoTopupVal = () => { 
        if(parseFloat(autoTriggerVal) != parseFloat(associateInfo.card.topup_trigger_val) || parseFloat(autoRechargeVal) != parseFloat(associateInfo.card.topup_recharge_val)){
            let formData = {
                salesforce_id: associateInfo.card.salesforce_id,
                topup_trigger_val: parseFloat(autoTriggerVal).toFixed(2),
                topup_recharge_val: parseFloat(autoRechargeVal).toFixed(2)
            };
            updateAutoTopupValues(formData);
        }
    };
    const updateAutoTopupValues = (formData) => {
        axios.post(`${process.env.serverUrl}update-associate-autotopup`, formData).then(async (response) => {
            if(!response.data.error){
                associateInfo.card.topup_trigger_val = formData.topup_trigger_val;
                associateInfo.card.topup_recharge_val = formData.topup_recharge_val;
                toast.success(response.data.message);  
            }else{  
                toast.error(response.data.message);
            }    
        });
    };

  return (
    <section className={styles.mainDash}>
        {
            isFetching ? <LoadingScreen /> : ''
        }
        <SEO title="Associate Details">
            <meta id="meta-description" name="description" content="" />
            <meta id="meta-keywords" name="keywords" content="" />
        </SEO>
      {/* ====================== top section start ======================= */}
      <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
            <MemberMenu/>
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                         <Col sm={12}>
                          <h2>Prepaid Card Portal</h2>
                         </Col> 
                    </Row>
                  </Container>
                  {/* ===================Create New Associates================= */}
                      <section className={styles.CommonContainer}>
                            
                          <Container className={styles.DashContainer}>
                              <Row>
                                  <Col sm={8}>
                                      <section className={styles.CardDetails}>
                                          <h3>Associate's Details {Object.keys(associateCard).length ? <Link legacyBehavior href="#"><a onClick={unlinkCard} data-id={associateInfo.salesforce_id}> <Icon.Link45deg /> Unlink The Card</a></Link> : <Link legacyBehavior href="#"><a onClick={linkCard}> <Icon.Link45deg /> Link Card</a></Link>}</h3>
                                        {!isShowEditForm ? 
                                            <div>
                                                <div className={styles.OnerName}><Icon.PersonFill/>{first_name + " " + last_name} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></div>
                                                <Row>
                                                    <Col>
                                                        <dl>
                                                            <dt><span>Gender</span> {(gender == 'm') ? 'Male' : ((gender == 'f') ? 'Female' : '')} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></dt>
                                                            <dt><span>DOB</span> {customFormatDate(dob, 'd/m/y')} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></dt>
                                                            <dt><span>Mobile</span> {mobile} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></dt>
                                                            <dt><span>Email</span> {email} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></dt>
                                                        </dl>
                                                    </Col>
                                                    <Col>
                                                        <dl>
                                                            <dt><span>Car Rego</span> {car_reg} <Link legacyBehavior href="#"><a onClick={showEditForm}><Icon.Pencil/></a></Link></dt>
                                                        </dl>
                                                        <div className={styles.AddMoreFilds}>
                                                            {/*<Link legacyBehavior href="#"><a><Icon.PlusLg/> Add More Fields</a></Link>*/}
                                                        </div>
                                                    </Col>
                                                </Row>
                                            </div>
                                        :
                                            <form id="associateForm" className='associate-form associate-form-part form-container-com' onSubmit={handleSubmit(onUpdateSubmit)}>                                                
                                                <div className={styles.formCoantainer}>
                                                    <Row>
                                                        <Col sm={12}>
                                                            <div className={styles.topFormContainer}>
                                                                <Icon.PersonFill/>
                                                                <div className={styles.formgroup}>
                                                                    <input type="text" {...register('first_name', {onChange: handleChange})} value={first_name} className={`form-control ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`} placeholder="First Name"/>
                                                                    <div className="invalid-feedback">{errors.first_name?.message?.toString()}</div>
                                                                </div>
                                                                <div className={styles.formgroup}>
                                                                    <input type="text" {...register('last_name', {onChange: handleChange})} value={last_name} className={`form-control ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`} placeholder="Last Name"/>
                                                                    <div className="invalid-feedback">{errors.last_name?.message?.toString()}</div>
                                                                </div>  
                                                            </div>
                                                        </Col>
                                                       
                                                        <Col sm={6}>
                                                            <div className={styles.formgroup}>
                                                                <label>Gender</label>
                                                                <Select options={genderOptions} value={genderOptions.find(item => item.value === gender)} {...register('gender')} onChange={onGenderChange} className={`form-control form-select ${gender ? 'is-valid' : ''}`} />
                                                            </div>
                                                            <div className={styles.formgroup}>
                                                                <label>DOB</label>
                                                                <DatePicker {...register('dob')} className={`form-control ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={handleDateInput} value={dob}  />
                                                                <div className="invalid-feedback">{dobError ? errors.dob?.message?.toString() : ''}</div>
                                                            </div>
                                                            <div className={styles.formgroup}>
                                                                <label>Mobile</label>
                                                                <PhoneInput className={`form-control ${(mobile && isNaN(parseInt(mobile)) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( !isNaN(parseInt(mobile)) && mobile.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`} value={mobile} {...register('mobile', {onChange: handleMobileInput})}>
                                                                </PhoneInput>                                                                
                                                                <div  className={`invalid-feedback ${(mobile && isNaN(parseInt(mobile)) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobile.length == 10 ? 'is-valid' : '')}`}>{(errors.mobile && !mobile || mobile.replace(/\D/g, '').length < 10 || isNaN(parseInt(mobile))) ? errors.mobile?.message?.toString() : ''}</div>
                                                                {/*<PhoneInput className={`${errors.mobile ? 'is-invalid' : ''}`}
                                                                    value={mobile} 
                                                                    onChange={handleMobileInput}>
                                                                </PhoneInput>
                                                                <input type="hidden" {...register('mobile')} value={mobile}/>*/}
                                                                {/*<input type="text" {...register('mobile')} value={mobile} onChange={handleChange} className={`${errors.mobile ? 'is-invalid' : ''}`} />*/}
                                                            </div>
                                                            <div className={styles.formgroup}>
                                                                <label>Email</label>
                                                                <input type="text" {...register('email', {onChange: handleChange})} value={email} className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`} />
                                                                <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                                            </div>
                                                        </Col>
                                                        
                                                        <Col sm={6}>
                                                            <div className={styles.formgroup}>
                                                                <label>Car Rego</label>
                                                                <input type="text" {...register('car_reg', {onChange: handleChange})} value={car_reg} className={`form-control ${car_reg ? 'is-valid' : ''}`} />
                                                            </div>
                                                        </Col>
                                                        
                                                        
                                                        

                                                    </Row>



                                                    {/* <div className={styles.OnerName}>
                                                        <Icon.PersonFill/>
                                                        <div className={styles.formgroup}>
                                                            <input type="text" {...register('first_name')} value={first_name} onChange={handleChange} className={`${errors.first_name ? 'is-invalid' : ''}`} placeholder="First Name"/>
                                                            <div className="invalid-feedback">{errors.first_name?.message?.toString()}</div>
                                                        </div>
                                                        <div className={styles.formgroup}>
                                                            <input type="text" {...register('last_name')} value={last_name} onChange={handleChange} className={`${errors.last_name ? 'is-invalid' : ''}`} placeholder="Last Name"/>
                                                            <div className="invalid-feedback">{errors.last_name?.message?.toString()}</div>
                                                        </div>  
                                                    </div> */}
                                                    {/* <Row>
                                                        <Col>
                                                            <dl>
                                                                <dt><span>Gender</span> <Select options={genderOptions} value={genderOptions.find(item => item.value === gender)} {...register('gender')} onChange={onGenderChange} /></dt>
                                                                <dt><span>DOB</span> <DatePicker {...register('dob')} className={`form-control ${errors.dob ? 'is-invalid' : ''}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={dob => setState(prevState => ({ ...prevState, ['dob']: dob, }))} value={dob}  />
                                                                <div className="invalid-feedback">{errors.dob?.message?.toString()}</div></dt>
                                                                <dt><span>Mobile</span> <input type="text" {...register('mobile')} value={mobile} onChange={handleChange} className={`${errors.mobile ? 'is-invalid' : ''}`} />
                                                                <div className="invalid-feedback">{errors.mobile?.message?.toString()}</div></dt>
                                                                <dt><span>Email</span> <input type="text" {...register('email')} value={email} onChange={handleChange} className={`${errors.email ? 'is-invalid' : ''}`} />
                                                            <div className="invalid-feedback">{errors.email?.message?.toString()}</div></dt>
                                                            </dl>
                                                        </Col>
                                                        <Col>
                                                            <dl>
                                                                <dt><span>Car Rego</span> <input type="text" {...register('car_reg')} value={car_reg} onChange={handleChange} className={`${errors.car_reg ? 'is-invalid' : ''}`} /></dt>
                                                            </dl>
                                                        </Col>
                                                    </Row> */}
                                                    <div className={styles.submitButton}>
                                                        <input type="hidden" {...register('associateId')} value={associateInfo.salesforce_id} />
                                                        <input type="hidden" {...register('assigned_card')} value={assigned_card} />
                                                        <input type="hidden" {...register('end_consumer_id')} value={endConsumerId} />
                                                        <Button color="primary"
                                                            variant="contained"
                                                            type="submit"
                                                            onClick={submitForm} 
                                                            disabled={showLoader} >
                                                            { showLoader ? <Loader /> : null } Update
                                                        </Button>
                                                        <Button
                                                            variant="contained"
                                                            type="button"
                                                            onClick={resetForm} >
                                                                Cancel
                                                        </Button>
                                                    </div>
                                                </div>
                                            </form>
                                        }
                                      </section>
                                      
                                      {Object.keys(associateCard).length ? 
                                        <section  className={styles.CorporateCard}>
                                            <Row>
                                                <Col sm={12}>

                                                    <Row>
                                                        <Col sm={6}>
                                                            <h4>Linked Corporate Card</h4>

                                                            <div className={styles.CardAllDetails}>
                                                            <div className={styles.CardImage}>
                                                                <Icon.CreditCard2Front/>
                                                            </div>
                                                            <div className={styles.CardInfo}>
                                                                <ul>
                                                                    <li><span>Card Display Number</span> {associateCard.card_number}</li>
                                                                    <li><span>Card UID</span> {associateCard.unique_id}</li>
                                                                    <li><span>Last Used</span> {/*14 / 09 / 2022*/}</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div className={styles.AvailableBalance}>
                                                            ${availableCredit}
                                                        <span>Available Balance</span>
                                                        </div>

                                                        </Col>
                                                        <Col sm={4}>
                                                            {cardStatus ? 
                                                            <div className={styles.AutoTopUpMain}>
                                                                <ToggleSwitch label="Auto Top-Up" toggled={isToggled} onClick={showAutoTopUp} />
                                                            </div>
                                                            : ''}
                                                            {isToggled ?
                                                            <div className={`topupPrice ${styles.PriceValue}`}>
                                                                <aside>
                                                                    <div className="currencyDiv">
                                                                        <input type="text" name="autoTriggerVal" className="form-control" value={autoTriggerVal} onChange={handleAutoTriggerVal} onBlur={handleAutoTopupVal} />
                                                                    </div>
                                                                    Trigger Value
                                                                </aside>
                                                                <aside>
                                                                    <div className="currencyDiv">
                                                                        <input type="text" name="autoRechargeVal" className="form-control" value={autoRechargeVal} onChange={handleAutoRechargeVal} onBlur={handleAutoTopupVal} />
                                                                    </div>
                                                                    Recharge Value
                                                                </aside>
                                                            </div>
                                                            : ''}
                                                        </Col>
                                                        <Col sm={2}>
                                                            <div className={styles.ActionWarap}>
                                                                <Link legacyBehavior href="#"><a className={cardStatus ? styles.ActiveButton : styles.InActiveButton} onClick={changeCardStatus} data-id={associateCard.salesforce_id} data-assid={associateInfo.salesforce_id}>{cardStatus ? 'Active' : 'In-Active'}</a></Link>
                                                                {/*<h6>Make it {cardStatus ? 'In-Active' : 'Active'}</h6> */}
                                                                {cardStatus ? 
                                                                <>
                                                                    {(unAssignedCredit > 0) ?
                                                                        <Link legacyBehavior href="#"><a onClick={handleShowCredit} className={styles.ActiveButton}><Icon.CurrencyDollar /> Add Credit</a></Link>
                                                                    : '' }
                                                                
                                                                    <Button onClick={handleShow} className={styles.Transfer}> <Icon.ArrowLeftRight /> Transfer</Button>

                                                                    {/* ================Modal Container================ */}

                                                                    <Modal show={show} onHide={handleClose} className={styles.commonModal}>
                                                                        <Modal.Header closeButton className={styles.topModal}>
                                                                            <Modal.Title className={styles.ModelTitle}><div><Icon.ArrowLeftRight /></div><div>Transfer<span>Corporate Card</span></div></Modal.Title>
                                                                        </Modal.Header>
                                                                        <Modal.Body>
                                                                            <form id="transferForm" onSubmit={handleSubmitTransfer(onTransferAssociateSubmit)}>
                                                                                <section className={styles.CorporateCardForm}>
                                                                                    <div className={styles.formGroup}>
                                                                                        <label>Selected Source Corporate Card</label>
                                                                                        <Select options={availableCards} value={availableCards.find(item => item.value === transferCard) || ''} {...registerTransfer('transferCard')} onChange={onTransferCardChange}/>
                                                                                        <div className="invalid-feedback">{errorsTransfer.TransferCard?.message?.toString()}</div>
                                                                                    </div>
                                                                                    <div className={styles.formGroup}>
                                                                                        <label>Select the Receiving Associate</label>
                                                                                        <Select options={associates} {...registerTransfer('transferAssociateId')} onChange={onTransferAssociateChange} />
                                                                                        <div className="invalid-feedback">{errorsTransfer.transferAssociateId?.message?.toString()}</div>
                                                                                    </div>
                                                                                    <div className={styles.ButtonGroup}>
                                                                                        <input type="hidden" {...registerTransfer('assignedCard')} value={assCard.salesforce_id} />
                                                                                        <input type="hidden" {...registerTransfer('currentAssociateId')} value={associateInfo.salesforce_id} />
                                                                                        <Button color="primary"
                                                                                            variant="contained"
                                                                                            type="submit"
                                                                                            onClick={submitTransferForm}
                                                                                            className={styles.Transfer} 
                                                                                            disabled={showLoader} >
                                                                                            { showLoader ? <Loader /> : null } <Icon.ArrowLeftRight /> Transfer
                                                                                        </Button>
                                                                                        <Button
                                                                                            variant="contained"
                                                                                            type="button"
                                                                                            onClick={cancelTransferForm}>
                                                                                                Cancel
                                                                                        </Button>
                                                                                    </div>
                                                                                </section>
                                                                            </form>
                                                                        </Modal.Body>
                                                                    </Modal>

                                                                    {/* ================Modal Container end================ */}
                                                                    </>
                                                                : ''}
                                                            </div>
                                                        </Col>
                                                    </Row>                                                    
                                                </Col>
                                                <Col sm={12}>
                                                    {cardStatus ? 
                                                    <div className={styles.WalletGroup}>
                                                        <a href="#" className={styles.WalletButton}>
                                                            <div><Icon.Wallet2 /></div>
                                                            <div>
                                                                <span>Add to</span>
                                                                Apple Wallet
                                                            </div> 
                                                        </a>
                                                        <a href="#" className={styles.WalletButton}>
                                                            <Icon.Wallet2 /> Add to Google Wallet
                                                        </a>
                                                    </div>
                                                    : ''}
                                                </Col>
                                            </Row>
                                        </section>
                                      : '' }
                                  </Col>
                                  <Col sm={4}>
                                    <section className={styles.CorporateRight}>
                                        {isShowLinkCard ?
                                            <article className={styles.LinkCardSection}>
                                                <div className={styles.CorporateCardFormTitle}>
                                                    <div className={styles.leftIcon}>
                                                        <Icon.Link/>
                                                    </div>
                                                    <div className={styles.leftContentCard}>
                                                        Link Corporate Card
                                                    </div>
                                                </div>
                                                <form id="linkForm" className='link-form' onSubmit={handleSubmitLink(onLinkCardSubmit)}>
                                                    <div className={styles.CardSectionForm}>
                                                        <div className={styles.formGroup}>
                                                            <label>Select a Unassigned Corporate Card</label>
                                                            <Select options={availableCards} {...registerLink('assigned_card')} onChange={onCardChange}/>
                                                            <div className="invalid-feedback">{errorsLink.assigned_card?.message?.toString()}</div>
                                                        </div>
                                                        <div className={styles.ButtonGroup}>
                                                            <input type="hidden" {...registerLink('associateId')} value={associateInfo.salesforce_id} />
                                                            <Button color="primary"
                                                                variant="contained"
                                                                type="submit"
                                                                onClick={submitLinkForm}
                                                                className={styles.Transfer} 
                                                                disabled={showLoader} >
                                                                { showLoader ? <Loader /> : null } <Icon.Link/> Link
                                                            </Button>
                                                            <Button
                                                                variant="contained"
                                                                type="button"
                                                                onClick={cancelLinkForm}>
                                                                    Cancel
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </article>
                                        : '' }
                                        {Object.keys(associateCard).length ?
                                        <article className={styles.CardLatestTransactions}>
                                        <div className={styles.LatestTransactions}>
                                            <h3>Latest Transactions</h3>
                                            <div className={styles.TransactionsTop}>
                                                <span>Description</span>
                                                <span>Spent</span>
                                                <span>Time</span>
                                            </div>
                                            { (latestTransactions) ? 
                                                <div className={styles.listTransactions}>                                          
                                                    <dl>
                                                        { Object.keys(latestTransactions).map((key) => (                                                         
                                                            <dt>                                                      
                                                                <div className={styles.ShowDate}>{key}</div>
                                                                {latestTransactions[key].map((transaction:any) => (
                                                                    <div className={styles.TransactionsList}>
                                                                        <div className={styles.timePost}>
                                                                            {transaction.machine_name}                                                                            
                                                                        </div>
                                                                        <div className={styles.lesPrice}>
                                                                            - ${transaction.spent_amount.toFixed(2)}
                                                                        </div>
                                                                        <div className={styles.rePrice}>
                                                                            <span>{formatAMPM(transaction.settlement_time)}</span>
                                                                        </div>
                                                                    </div> 
                                                                ))}
                                                            </dt>
                                                        )) }
                                                    </dl>
                                                </div> 
                                                : ''                                                
                                            }
                                        </div>
                                      </article>
                                      : ''}
                                    </section>
                                  </Col>
                              </Row>
                            </Container>
                      </section>
                  {/* ===================Create New Associates end================= */}
               </section>
            {/* ================dashboard right container end================== */}
            <Modal show={showCredit} onHide={handleCloseCredit} className={styles.commonModal}>
                <Modal.Header closeButton className={styles.topModal}>
                    <Modal.Title className={styles.ModelTitle}>
                    <div className="AssignedCreditFormTitle">
                        <div className={styles.leftIcon}>
                            <Icon.ArrowLeftRight/>
                        </div>
                        <div className={styles.leftContentCard}>
                            Allocate Un-Assigned Credit 
                            to a Corporate Card 
                        </div>
                    </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <section className="AssignedCredit">
                    <form id="creditForm" className='credit-form' onSubmit={handleCreditSubmit(onCreditSubmit)}>
                        <div className={styles.AssignedSectionForm}>
                            <div className={styles.formGroup}>
                                <div className={styles.Creditlabel}>
                                    <label>Un-Assigned Credit</label>
                                    <div className="currencyDiv">
                                        <input type="text" {...registerCredit('unAssignedCredit')} value={unAssignedCredit.toFixed(2)} readOnly />
                                    </div>                                    
                                </div>
                            </div>
                            <div className={styles.formGroup}>
                                <label>Enter the Desired Amount</label>
                                <div className="currencyDiv">
                                    <input type="number" max={unAssignedCredit.toFixed(2)} min="1" {...registerCredit('desiredAmount')} onChange={handleCreditFieldChange} className={`${errorsCredit.desiredAmount ? 'is-invalid' : ''}`} value={desiredAmount}  />
                                </div>                                
                                <div className="invalid-feedback">{errorsCredit.desiredAmount?.message?.toString()}</div>
                            </div>
                            <div className={styles.ButtonGroup}>
                                <Button color="primary"
                                    variant="contained"
                                    type="submit"
                                    onClick={submitCreditForm}
                                    className={styles.Transfer} 
                                    disabled={showCreditLoader} >
                                    { showCreditLoader ? <Loader /> : null } <Icon.Link/> Transfer
                                </Button>
                            </div>
                        </div>
                    </form>    
                    </section>
                </Modal.Body>
            </Modal>
        </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default AssociateDetails;