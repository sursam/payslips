import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import SEO from '../../components/SEO';
import axios from "axios";
import Link from 'next/link';
import Modal from 'react-bootstrap/Modal';
import GlobalContext from '../../components/GlobalContext';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useForm } from 'react-hook-form';
import Select from 'react-select';
import { Button } from "@material-ui/core";
import Loader from '../../components/loader';
import ToggleSwitch from '../../components/ToggleSwitch';
import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import RechargePanel from "../../components/RechargePanel/RechargePanel";
import LoadingScreen from "../../components/loadingScreen";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";
import PaymentInvoice from "../../components/PaymentInvoice";

const Dashboard = () => {
  const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
  const [totalCards, setTotalCards] = useState(0);
  const [activeCards, setActiveCards] = useState(0);
  //const [unAssignedCredit, setUnAssignedCredit] = useState(0);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [mostUsedCards, setMostUsedCards] = useState([]);
  const [showCardLoader, setShowCardLoader] = useState(true);
  const [showBarLoader, setShowBarLoader] = useState(true);
  const [isToggled, setIsToggled] = useState(false);
  const [showToggled, setShowToggled] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [limit, setLimit] = useState(7);
  const currentPage = 1;
  const [companyInfo, setCompanyInfo] = useState({});
  const [accountInfo, setAccountInfo]:any = useState({});
  const [billingAddress, setBillingAddress] = useState('');

  useEffect(() => {
    axios.get(`${process.env.serverUrl}get-card-counts/${endConsumerId}`,{}).then((response) => {            
      setTotalCards(response.data.totalCards);            
      setActiveCards(response.data.activeCards);
    });
    /*axios.get(`${process.env.serverUrl}get-endconsumer-details/${endConsumerId}`,{}).then((response) => {
      //setUnAssignedCredit(response.data.UnAssigned_Credit__c);  
      setStateCredit(prevState => ({
        ...prevState,
        unAssignedCredit: response.data.UnAssigned_Credit__c,
      }));
    });*/
    //let barLoader = document.querySelector('.bar_loader');
    axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${currentPage}&size=${limit}`,{}).then((response) => { 
      setShowBarLoader(false);
      setRecentTransactions(response.data.Transactions);     
    });
    axios.get(`${process.env.serverUrl}get-card-associates/${endConsumerId}`,{}).then((response:any) => {   
      //console.log(response);
      const cardAssociateOptions:any = [];
      response.data.records.forEach(card => {
          var obj:any = {};
          /*obj['value'] = card.RFID_Card__r.Id;
          obj['label'] = card.Name + ' - ' + card.RFID_Card__r.Display_Card_Number__c;*/
          obj['value'] = card.salesforce_id;
          obj['label'] = card.associate ? card.associate.name + ' - ' + card.card_number : card.card_number;
          cardAssociateOptions.push(obj);
      }); 
      setCardAssociates(cardAssociateOptions); 
    });
    axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
      let autoTopup = 0;
      let autoTopupSourceId = '';
      let autoTopupSourceType = '';
      let autoTopupRechargeAmount = '';
      let autoTopupTriggerPoint = '';
      let autoTopupCreditVal = '';
      if(response.data.is_auto_topup == "1" && response.data.auto_topup){
          autoTopup = 1;
          autoTopupSourceId = response.data.auto_topup.source_id;
          autoTopupSourceType = response.data.auto_topup.source_type;
          autoTopupRechargeAmount = response.data.auto_topup.auto_recharge_amount;
          autoTopupTriggerPoint = response.data.auto_topup.auto_trigger_point;
          autoTopupCreditVal = response.data.auto_topup.extra_credit_val;
      }
      let unAssignedCred = (response.data.current_balance != null) ? response.data.current_balance : 0;
      setStateCredit(prevState => ({
          ...prevState,
          unAssignedCredit: unAssignedCred,
          autoTopup: autoTopup,
          autoTopupSourceId: autoTopupSourceId,
          autoTopupSourceType: autoTopupSourceType,
          autoTopupRechargeAmount: autoTopupRechargeAmount,
          autoTopupTriggerPoint: autoTopupTriggerPoint,
          autoTopupCreditVal: autoTopupCreditVal,
      }));
      let autoTopupCheck = (response.data.is_auto_topup == '1') ? true : false;
      setIsToggled(autoTopupCheck);
      setShowToggled(true);
    });
    axios.get(`${process.env.serverUrl}get-stripe-account/${endConsumerId}`,{}).then((response) => {
      if(typeof response.data.records != 'undefined' && response.data.records.length > 0){ 
          setStateCredit(prevState => ({
              ...prevState,
              connectedAccount: response.data.records[0].account_name__r.Stripe_Acc_Id__c,
              stripeCustomerId: response.data.records[0].Stripe_Customer_Id__c,
          }));
      }
    });
    axios.get(`${process.env.serverUrl}get-corporate-cards/${endConsumerId}`,{}).then((response) => {
      let corpCards = response.data;
      let allCards = Array();
      if(corpCards){
        corpCards.forEach((card:any) => {
          let cardId = card.card_id;
          allCards.push(cardId);
        });
        var data = {
          allCards: allCards,
          limit: (limit - 1),
        };
        axios.post(`${process.env.serverUrl}get-most-used-cards`, data).then((response) => {
          setMostUsedCards(response.data);
          setShowCardLoader(false);
        });
      }
    });
    axios.get(`${process.env.serverUrl}get-company-info/${endConsumerId}`,{}).then((response) => { 
      let companyData = {};
      if(response.data){
        response.data.forEach(infoData => {
          companyData[infoData.field_name] = infoData.field_value;
        });          
      }
      setCompanyInfo(companyData);     
    });
    axios.get(`${process.env.serverUrl}get-account-info-by-endconsumer/${endConsumerId}`,{}).then((response) => {
      setAccountInfo(response.data);
      if(response.data.account_name__r != null){
        let accountData = response.data.account_name__r;
        let billAddress:any = []; 
        Object.keys(accountData).map(key => {
          if(accountData[key] != null && key != 'attributes' && key != 'Name' && key != 'ABN__c' && key != 'ACN__c'){
            billAddress.push(accountData[key]);
          }
        });
        setBillingAddress(billAddress.join(', '));
      }
    });
  }, 
  [])

  /*const loadRechargePanel = (unAssignedCredit) => {
    console.log(unAssignedCredit);
    return (<RechargePanel currentCreditBalance={unAssignedCredit} />);
  }*/

  const customFormatDate = (date, format = 'y-m-d') => {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    let retDate = '';
    switch(format){
        case 'd/m/y': retDate = [day, month, year].join('/');
            break;
        case 'y-m-d': 
        default:
            retDate = [year, month, day].join('-');
            break;
    }
    return retDate;
  }

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
      setShow(true);
  };
  const { stripeCreds } = useContext(GlobalContext);
  const { tngPercentAmount } = useContext(GlobalContext);
  const [showCreditLoader, setshowCreditLoader] = useState(false);
  const [cardAssociates, setCardAssociates] = useState<any[]>([]);

  var [stateCredit, setStateCredit] = useState({
    endConsId: endConsumerId,
    unAssignedCredit: 0,
    cardAssociate: '',
    desiredAmount: '',
    autoTopup: 0,
    autoTopupSourceId: '',
    autoTopupSourceType: '',
    autoTopupRechargeAmount: '',
    autoTopupTriggerPoint: '',
    autoTopupCreditVal: '',
    connectedAccount: '',
    stripeCustomerId: '',
    stripeCredentials: stripeCreds,
    tngPercentAmnt: tngPercentAmount,
  });
  var { endConsId, unAssignedCredit, cardAssociate, desiredAmount, endConsId, autoTopup, autoTopupSourceId, autoTopupSourceType, autoTopupRechargeAmount, autoTopupTriggerPoint, autoTopupCreditVal, connectedAccount, stripeCustomerId, stripeCredentials, tngPercentAmnt } = stateCredit;

  var validationCreditSchema = Yup.object().shape({
      cardAssociate: Yup.string().required('Associate / Corporate Card is required'),
      desiredAmount: Yup.string().required('Desired Amount is required'),
  });

  var formCreditOptions = { resolver: yupResolver(validationCreditSchema) };
  var { register: registerCredit, handleSubmit: handleCreditSubmit, reset: resetCredit, formState: { errors: errorsCredit } } = useForm(formCreditOptions);

  const submitCreditForm = () => {    
      resetCredit(stateCredit)
  }

  const onCreditSubmit = (formData:any) => {
    setshowCreditLoader(true); 
    axios.post(`${process.env.serverUrl}allocate-unassigned-credit`, formData).then((response) => {
      setshowCreditLoader(false)
      if(response.data.error == 0){  
        toast.success(response.data.message);
        resetCreditForm();
        handleClose();
        setTimeout(() => {
          axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
            let unAssignedCred = (response.data.current_balance != null) ? response.data.current_balance : 0;
            setStateCredit(prevState => ({
                ...prevState,
                unAssignedCredit: unAssignedCred,
            }));
            //loadRechargePanel(unAssignedCred);
            /*console.log(unAssignedCred);
            var currentBalanceView = document.querySelector('#currentBalanceView');
            if(currentBalanceView){
              currentBalanceView.innerHTML = `$${unAssignedCred.toFixed(2)}`;
            }
            var projectedTotalView = document.querySelector('#projectedTotalView');
            if(projectedTotalView){
              projectedTotalView.innerHTML = `$${unAssignedCred.toFixed(2)}`;
            }*/              
          });
          axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${currentPage}&size=${limit}`,{}).then((response) => { 
            setRecentTransactions(response.data.Transactions);     
          });
        }, 10000);        
      }else{
        toast.error(response.data.message);
      }        
    });
  };

  const resetCreditForm = () => { 
      let currentBalance = (unAssignedCredit - parseFloat(desiredAmount)).toFixed(2);       
      setStateCredit(prevState => ({
          ...prevState,
          unAssignedCredit: parseFloat(currentBalance),
          cardAssociate: '',
          desiredAmount: '',
          autoTopup: 0,
          autoTopupSourceId: '',
          autoTopupSourceType: '',
          autoTopupRechargeAmount: '',
          autoTopupTriggerPoint: '',
          autoTopupCreditVal: '',
      }));
  }
  const handleCreditFieldChange = (event) => {    
      const { name, value } = event.target;
      setStateCredit(prevState => ({
        ...prevState,
        [name]: value,
      }));
  };

  const onCardAssociateChange = (
      newValue
    ) => {
      setStateCredit(prevState => ({
        ...prevState,
        cardAssociate: newValue.value,
      }));
  };

  const showAutoTopUp = (state) => {
      setIsFetching(true);
      setIsToggled(state);
      let formData = {
          salesforce_id: endConsumerId,
          is_auto_topup: state ? '1' : '0',
      };
      axios.post(`${process.env.serverUrl}update-endconsumer-autotopup`, formData).then(async (response) => {
        setIsFetching(false);
        if(!response.data.error){
            toast.success(response.data.message);  
        }else{  
            toast.error(response.data.message);
        }    
      });
  };

  const generateInvoicePdf = async (transactionId) => {
    setIsFetching(true);
    const settingsResponse = await fetch(`${process.env.serverUrl}site-settings/`);
    const settingsInfo = await settingsResponse.json();
    const endConsumerResponse = await fetch(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`);
    const endConsumerInfo = await endConsumerResponse.json();
    const transactionResponse = await fetch(`${process.env.serverUrl}get-transaction-details/${transactionId}`);
    const transactionInfo = await transactionResponse.json();
    if(Object.keys(transactionInfo).length && Object.keys(endConsumerInfo).length){
        const blob = await pdf(
            <PaymentInvoice siteLogo={settingsInfo.logo} accountInfo={accountInfo} billingAddress={billingAddress} companyInfo={companyInfo} endConsumerInfo={endConsumerInfo} transactionInfo={transactionInfo} />
        ).toBlob();
        saveAs(blob, `invoice-${String(transactionId).padStart(6, '0')}.pdf`);
        setIsFetching(false);
    }
  }

  return (
    <section className={styles.mainDash}>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      <SEO title="Member Dashboard">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <MemberHeader/>
      
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
              <MemberMenu/>
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                      <Col sm={10}>
                          <h2>Prepaid Card Portal</h2>
                      </Col> 
                      <Col sm={2}>
                        {showToggled ?
                          <div className={styles.AutoTopUpMain}>
                              <ToggleSwitch label="Auto Top-Up" toggled={isToggled} onClick={showAutoTopUp} />
                          </div>
                        : ''}
                      </Col>
                    </Row>
                  </Container>
                 
                 {/* ============ cart details section ============= */}
                    <div className={styles.cardDetails}>
                        <Container className={styles.DashContainer}>
                          <Row>
                              <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                                  <div className={styles.CardSection}>
                                      <div className={styles.TitalAmount}>Total Corporate Cards <span>{totalCards}</span></div>
                                      <div className={styles.ActiveAmount}>Active Cards <strong>{activeCards}</strong></div>
                                  </div>
                                  <div className={styles.mostUsed}>
                                      <h3>Most Used Corporate Card</h3>
                                      {showCardLoader ?
                                        (<div className="bar_loader">
                                          <div className="bar"></div>
                                          <div className="bar2"></div>
                                          <div className="bar3"></div>
                                          <div className="bar4"></div>
                                        </div>)
                                      :
                                        <ul>
                                          { mostUsedCards.map((cardData:any) => (
                                            <li>                                              
                                              <div className={styles.Cdetails}>
                                                {cardData?.card?.associate?.name}
                                                <span>{cardData?.card?.associate?.car_reg}</span>
                                              </div>
                                              <div className={styles.CImage}>
                                                <Link legacyBehavior href={`/card-deatils/${cardData?.card?.salesforce_id}`}><a><Icon.CreditCard/></a></Link>
                                                <span>{cardData.display_card_number}</span>
                                              </div>                                              
                                            </li>
                                          )) }
                                          {/*<div className={styles.viewAll}><a href="#">View All</a></div>*/}
                                        </ul>
                                      }
                                  </div>
                              </Col>
                              <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                                  <div className={styles.CardSectionMidel}>
                                      <div className={styles.Assigned}>Un-Assigned Credit</div>
                                      <div className={styles.AssignedAmount} id="unAssignedCredit">${unAssignedCredit.toFixed(2)}</div>
                                      <div className={styles.AssignCredit}><Link legacyBehavior href="#"><a onClick={handleShow}>Assign Credit</a></Link></div>
                                  </div>
                                  <div className={styles.Transactions}>
                                      <h3>Recent Recharge Transactions</h3>
                                      
                                      {showBarLoader ?
                                        (<div className="bar_loader">
                                          <div className="bar"></div>
                                          <div className="bar2"></div>
                                          <div className="bar3"></div>
                                          <div className="bar4"></div>
                                        </div>)
                                      : 
                                        <ul>
                                          { recentTransactions.map((transaction:any, k) => (
                                            (k < (limit-1)) ? 
                                            <li>
                                                <div className={styles.Tdetails}>
                                                  {'$'+transaction.total_amount}
                                                  <span>{customFormatDate(transaction.created_on, 'd/m/y')}</span>
                                                  <div className={(transaction.recharge_procedure == 'Auto') ? styles.NotiFication +' '+ styles.AutoTopUp : styles.NotiFication}>
                                                    {(transaction.recharge_procedure == 'Auto') ? 'Auto Top-Up' : 'Manual Recharge'}
                                                  </div>
                                                </div>
                                                <div className={styles.TImage}>
                                                  <Link legacyBehavior href="#"><a onClick={() => generateInvoicePdf(transaction.salesforce_id)}><Icon.FilePdfFill/></a></Link>
                                                </div>
                                            </li>
                                            : ''
                                          )) }
                                          {(recentTransactions.length > 5) ? 
                                            <div className={styles.viewAll}><Link legacyBehavior href={"/recharge-history"}><a>View All</a></Link></div>
                                          : ''}
                                        </ul>
                                      }
                                  </div>
                             </Col>
                              <Col lg={4} xl={4} xxl={4} xs={12} md={12}>
                                {/*loadRechargePanel(unAssignedCredit)*/}
                                <RechargePanel
                                  currentCreditBalance={unAssignedCredit}
                                />
                              </Col>
                          </Row>
                        </Container>
                        
                    </div>
                 {/* ============ cart details section end============= */}
                 <Modal show={show} onHide={handleClose} className={styles.commonModal}>
                      <Modal.Header closeButton className={styles.topModal}>
                          <Modal.Title className={styles.ModelTitle}>
                            <div className="AssignedCreditFormTitle">
                                <div className={styles.leftIcon}>
                                    <Icon.ArrowLeftRight/>
                                </div>
                                <div className={styles.leftContentCard}>
                                    Allocate Un-Assigned Credit 
                                    to a Corporate Card 
                                </div>
                            </div>
                          </Modal.Title>
                      </Modal.Header>
                      <Modal.Body>
                          <section className="AssignedCredit">
                            <form id="creditForm" className='credit-form' onSubmit={handleCreditSubmit(onCreditSubmit)}>
                                <div className={styles.AssignedSectionForm}>
                                    <div className={styles.formGroup}>
                                        <div className={styles.Creditlabel}>
                                            <label>Un-Assigned Credit</label>
                                            <div className="currencyDiv">
                                              <input type="text" {...registerCredit('unAssignedCredit')} value={`${unAssignedCredit.toFixed(2)}`} readOnly />
                                            </div>
                                        </div>
                                    </div>
                                    <div className={styles.formGroup}>
                                        <label>Select an Associate / Corporate Card</label>
                                        <Select options={cardAssociates} {...registerCredit('cardAssociate')} onChange={onCardAssociateChange} className={`${errorsCredit.cardAssociate ? 'is-invalid' : ''}`} value={cardAssociates.find(item => item.value === cardAssociate) || ''} />
                                        <div className="invalid-feedback">{errorsCredit.cardAssociate?.message?.toString()}</div>
                                    </div>
                                    <div className={styles.formGroup}>
                                        <label>Enter the Desired Amount</label>
                                        <div className="currencyDiv">
                                          <input type="number" max={unAssignedCredit.toFixed(2)} min="0" {...registerCredit('desiredAmount')} onChange={handleCreditFieldChange} className={`${errorsCredit.desiredAmount ? 'is-invalid' : ''}`} value={desiredAmount}  />
                                        </div>                                        
                                        <div className="invalid-feedback">{errorsCredit.desiredAmount?.message?.toString()}</div>
                                    </div>
                                    <div className={styles.ButtonGroup}>
                                        <Button color="primary"
                                            variant="contained"
                                            type="submit"
                                            onClick={submitCreditForm}
                                            className={styles.Transfer} 
                                            disabled={showCreditLoader} >
                                            { showCreditLoader ? <Loader /> : null } <Icon.Link/> Transfer
                                        </Button>
                                    </div>
                                </div>
                            </form>    
                          </section>
                      </Modal.Body>
                  </Modal>
              </section>
            {/* ================dashboard right container end================== */}
        </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
        <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Dashboard;