import React, {useState, useContext, useEffect} from 'react';
import styles from '../../styles/Signup.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import SEO from '../../components/SEO';
import AbnInput from '../../components/AbnInput';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Index() {  

  //const [validationErrors, setvalidationErrors] = useState(null);
  //const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const router = useRouter();
  const [dob, setDob] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [referenceNumberValidationError, setreferenceNumberValidationError] = useState('');
  // const [ConsumerReferenceNumber, setConsumerReferenceNumber] = useState('');

  const [abn, setAbn] = useState('');
  const handleAbnInput = ({ target: { value } }:any) => setAbn(value);

  var validationSchema = Yup.object().shape({
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    mobile: Yup.string().required('Mobile is required'),
    email: Yup.string().required('Email address is required'),
    dateofbirth: Yup.string().required('Date of birth is required'),
    accountType: Yup.string().required('Account type is required'),
    businessName: Yup.string().required('Business name is required'),
    abn: Yup.string().required('ABN number is required'),
    companyName: Yup.string().required('Company is required'),
    referenceNumber: Yup.string().required('End consumer reference number is required'),
    licenceSerialNumber: Yup.string().required('Licence serial number is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  useEffect(() => {

    const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated'))

    //console.log(authenticated);

    if(authenticated)
    {
      router.push('/dashboard');
    } 

    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  
  [])

  const handleBlur  = (event:any) => {
    setshowLoader(true);
    const params = {
      'endConsumerNumber': event.target.value,
    };
    
    axios.post(`${process.env.serverUrl}end-consumer-reference`, params, { headers: { 'content-type': 'application/json',
      } }).then((response) => {
        setshowLoader(false)

        if(response.data.status === 0)
        {
          setReferenceNumber('')
          setreferenceNumberValidationError(response.data.message);
        }
        else
        {
          setReferenceNumber(event.target.value);
          setreferenceNumberValidationError('');
        }

    });

  };

  const onSubmit = (formData:any) => {
    setshowLoader(true);
    //setsuccessMessage(null);
    //setvalidationErrors(null);  
    axios.post(`${process.env.serverUrl}member-signup`, formData).then((response) => {
      setshowLoader(false)

      if(response.data.status !="0"){
        toast.success(response.data.message);  
        //setvalidationErrors(null);
        //setsuccessMessage(response.data.message);        
        reset();
        setTimeout(() => router.push('/login'), 5000);

      }else{
        toast.error(response.data.message);
        //setsuccessMessage(null);
        //setvalidationErrors(response.data.message);
      }

    });
  };

  return (
    <section className={styles.signupMain}>
      <SEO title="Signup">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
{/* =============sign up form section================== */}
    <section className={styles.signupContainer}>
      <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                    <div className={styles.signupFormBox}>
                        <h2>
                            <img src={'/assets/images/login-icon.png'} />
                            <span>Sign Up</span>
                        </h2>

                        <div className={styles.ErrorSummary}>
                            {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                            <ToastContainer
                                position="top-right"
                                autoClose={10000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable
                                pauseOnHover
                                theme="light"
                            />
                        </div>

                        <form className='enquiry-form-signup' onSubmit={handleSubmit(onSubmit)}>

                          {/* ================Personal Details================== */}
                            <section className={styles.formGroup}>
                              <h3>Personal Details</h3>
                                    <Row>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                First Name
                                              </label>
                                              <input type="text" {...register('firstName')}  className={`form-control ${errors.firstName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.firstName?.message?.toString()}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                Last Name
                                              </label>
                                              <input type="text" {...register('lastName')}  className={`form-control ${errors.lastName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.lastName?.message?.toString()}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                              Mobile
                                              </label>
                                              <input type="text" {...register('mobile')}  className={`form-control ${errors.mobile ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.mobile?.message?.toString()}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                Email Address
                                              </label>
                                              <input type="email" {...register('email')} className={`form-control ${errors.email ? 'is-invalid' : ''}`} autoComplete ="off" />
                                              <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                          </div>
                                          
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                                  Date Of Birth
                                              </label>
                                              <DatePicker className={`form-control ${errors.dateofbirth ? 'is-invalid' : ''}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown dropdownMode="select" onChange={dob => setDob(dob)} value={dob}  />
                                              <input type="hidden" {...register('dateofbirth')} value={dob}/>
                                              <div className="invalid-feedback">{errors.dateofbirth?.message?.toString()}</div>
                                          </div>
                                        </Col>
                                        <Col sm={6}>
                                          <div className={styles.formgroup}>
                                              <label>
                                              Account Type
                                              </label>
                                              <select {...register('accountType')} className={`form-control ${errors.accountType ? 'is-invalid' : ''}`}>
                                                <option value="">Select Account Type</option>
                                                <option value="Individual Consumers">Individual Consumer</option>
                                                <option value="Corporate Consumers">Corporate Consumer</option>
                                              </select>
                                              <div className="invalid-feedback">{errors.accountType?.message?.toString()}</div>
                                          </div>
                                        </Col>
                                    </Row>
                              </section>
                      {/* ================Personal Details end================== */}

                      {/* ================Company Details================== */}
                          <section className={styles.formGroup}>
                                <h3>Company Details</h3>
                                  <Row>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                Business Name
                                            </label>
                                            <input type="text" {...register('businessName')}  className={`form-control ${errors.businessName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.businessName?.message?.toString()}</div>
                                        </div>
                                        
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                ABN Number
                                            </label>
                                              <AbnInput className={`form-control ${errors.abn ? 'is-invalid' : ''}`}
                                                value={abn} 
                                                onChange={handleAbnInput}>
                                              </AbnInput>
                                          <input type="hidden" {...register('abn')} value={abn}/>

                                            <div className="invalid-feedback">{errors.abn?.message?.toString()}</div>
                                        </div>
                                        
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                                Company Name
                                            </label>
                                            <input type="text" {...register('companyName')}  className={`form-control ${errors.companyName ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.companyName?.message?.toString()}</div>
                                        </div>
                                        
                                      </Col>
                                  </Row>
                            </section>
                          {/* ================Company Details================== */}

                          {/* ================Licence Details================== */}
                              <section className={styles.formGroup}>
                                  <h3>Licence Details</h3>
                                  <Row>
                                    <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                              End Consumer Reference Number
                                            </label>
                                            <input type="text" className={`form-control ${errors.referenceNumber ? 'is-invalid' : ''}`} autoComplete ="off" onBlur={handleBlur}/>
                                            <input type="hidden" {...register('referenceNumber')} value={referenceNumber}/>
                                            <div className="invalid-feedback">{errors.referenceNumber?.message?.toString()}</div>
                                            <div id="referenceNumberValidationError">{referenceNumberValidationError}</div>
                                        </div>
                                      </Col>
                                      <Col sm={6}>
                                        <div className={styles.formgroup}>
                                            <label>
                                            Licence Serial Number
                                            </label>
                                            <input type="text" {...register('licenceSerialNumber')}  className={`form-control ${errors.licenceSerialNumber ? 'is-invalid' : ''}`} autoComplete ="off" />
                                            <div className="invalid-feedback">{errors.licenceSerialNumber?.message?.toString()}</div>
                                        </div>
                                        
                                      </Col>
                                  </Row>
                              </section>
                          {/* ================Licence Details================== */}
                          <Row>
                            <Col sm={12}>
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Sign Up Now </Button>
                                </div>
                            </Col>
                          </Row>

                        </form>
                        <div className={styles.loginAlt}>Already have an account? <Link legacyBehavior href={"/login"}>sign in</Link> </div>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
<div className="footerContainer">
        © {new Date().getFullYear()} All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}