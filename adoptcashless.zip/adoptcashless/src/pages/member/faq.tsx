import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import Datetime from 'react-datetime';
import { Button } from "@material-ui/core";
import SEO from '../../components/SEO';
//import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
import Select from 'react-select';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import {
Accordion,
AccordionItem,
AccordionItemHeading,
AccordionItemButton,
AccordionItemPanel,
} from 'react-accessible-accordion';
// Demo styles, see 'Styles' section below for some notes on use.

import 'react-accessible-accordion/dist/fancy-example.css';
import "react-datetime/css/react-datetime.css";

export default function FAQ() { 
    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    
    //const [validationErrors, setvalidationErrors] = useState(null);
    //const [successMessage, setsuccessMessage] = useState(null);
    const [showLoader, setshowLoader] = useState(false);
    var [corporateCard, setCorporateCard] = useState<any[]>([]);
    var [associate, setAssociate] = useState<any[]>([]);
    const [datetime, setDateTime] = useState();

    useEffect(() => {

        axios.get(`${process.env.serverUrl}get-associates/${endConsumerId}`,{}).then((response) => {             
            const associateOptions:any = [];
            //console.log(response.data);
            response.data.forEach(ass => {
                var obj:any = {};
                obj['value'] = ass.salesforce_id;
                obj['label'] = ass.name;
                associateOptions.push(obj);
            }); 
            setAssociate(associateOptions); 
        });
    }, 
    [])

    const getCorporateCard = (associateId) => {
        axios.get(`${process.env.serverUrl}get-associate-corporate-cards/${associateId}`,{}).then((response) => {             
            const cardOptions:any = [];

            if(response.data.card)
            {
                var obj:any = {};
                obj['value'] = response.data.card.salesforce_id;
                obj['label'] = response.data.card.card_number;
                cardOptions.push(obj);

                setCorporateCard(cardOptions); 
            }
            
        });
    }

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
        const { name, value } = event.target;
        setState(prevState => ({
          ...prevState,
          [name]: value,
        }));
    };

    const handleTextAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {    
        const { name, value } = event.target;
        setState(prevState => ({
          ...prevState,
          [name]: value,
        }));
      };

      var [state, setState] = useState({
        related_to: '',
        associateId: '',
        assigned_card: '',
        added_date_time: new Date(),
        message: ''
    });

    var { related_to, associateId, assigned_card, added_date_time, message} = state;

    const onAssociateChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          associateId: newValue.value,
        }));

        getCorporateCard(newValue.value);
    };

    function onChangeDate(event:any) {
        console.log(event._d.Date);
      }

    const onCardChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          assigned_card: newValue.value,
        }));
    };
    
    var validationSchema = Yup.object().shape({
        related_to: Yup.string().required('Related to is required'),
        associateId: Yup.string().required('Associate to is required'),
        assigned_card: Yup.string().required('Corporate card is required'),
        message: Yup.string().required('Message is required'),
    });
    var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

    const submitForm = () => {    
        reset(state)
    }

    const onSubmit = (formData:any) => {
        setshowLoader(true);  
        axios.post(`${process.env.serverUrl}save-support-case`, formData).then((response) => {
          setshowLoader(false)

          if(response.data.status == 1)
          {
            resetForm();     
            //setvalidationErrors(null);
            //setsuccessMessage(response.data.message); 
            toast.success(response.data.message);  
          }else{
            //setsuccessMessage(null);
            //setvalidationErrors(response.data.message);
            toast.error(response.data.message); 
          }        
        });
    };

    const resetForm = () => {
        setState(prevState => ({
            ...prevState,
            related_to: '',
            associateId: '',
            assigned_card: '',
            datetime: null,
            message: ''
        }));
    }

return (
<section className={styles.mainDash}>
<SEO title="FAQ">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
</SEO>
{/* ====================== top section start ======================= */}
<MemberHeader/>
{/* ====================== top section end ======================= */}
{/* ====================== main container part ======================= */}
<section className={styles.MainContainer}>
{/* ================left dashboard menu list================== */}
<MemberMenu/>   
{/* ================left dashboard menu list end================== */}
{/* ================dashboard right container================== */}
<section className={styles.DashboardRight}>
<Container className={styles.DashContainer}>
<Row>
<Col sm={12}>
    <h2>Prepaid Card Portal</h2>
</Col> 
</Row>
</Container>

{/* ===================Create New Associates================= */}
<section className={styles.CommonContainer}>
    <Container className={styles.DashContainer}>
        <Row>
            <Col xs={12} sm={6} md={7} lg={7} xl={8} xxl={8}>
                <section className="faqListContainer">
                    <h3>FAQ</h3>
                    {/* ==================== faq section part ============== */}
                        <section className="faqSection">
                            <div className="sectionList">
                                <Accordion preExpanded={['a']}>
                                        <AccordionItem uuid="a">
                                            <AccordionItemHeading>
                                                <AccordionItemButton>
                                                    Section
                                                </AccordionItemButton>
                                            </AccordionItemHeading>
                                            <AccordionItemPanel>
                                            <Accordion preExpanded={['d-1']}>
                                                <AccordionItem>
                                                    <AccordionItemHeading>
                                                        <AccordionItemButton>
                                                            Question 1
                                                        </AccordionItemButton>
                                                    </AccordionItemHeading>
                                                    <AccordionItemPanel>
                                                        <p>
                                                            Exercitation in fugiat est ut ad ea cupidatat ut in
                                                            cupidatat occaecat ut occaecat consequat est minim minim
                                                            esse tempor laborum consequat esse adipisicing eu
                                                            reprehenderit enim.
                                                        </p>
                                                    </AccordionItemPanel>
                                                </AccordionItem>
                                                <AccordionItem>
                                                    <AccordionItemHeading>
                                                        <AccordionItemButton>
                                                        Question 2
                                                        </AccordionItemButton>
                                                    </AccordionItemHeading>
                                                    <AccordionItemPanel>
                                                        <p>
                                                            In ad velit in ex nostrud dolore cupidatat consectetur
                                                            ea in ut nostrud velit in irure cillum tempor laboris
                                                            sed adipisicing eu esse duis nulla non.
                                                        </p>
                                                    </AccordionItemPanel>
                                                </AccordionItem>
                                                <AccordionItem>
                                                    <AccordionItemHeading>
                                                        <AccordionItemButton>
                                                        Question 3
                                                        </AccordionItemButton>
                                                    </AccordionItemHeading>
                                                    <AccordionItemPanel>
                                                        <p>
                                                            In ad velit in ex nostrud dolore cupidatat consectetur
                                                            ea in ut nostrud velit in irure cillum tempor laboris
                                                            sed adipisicing eu esse duis nulla non.
                                                        </p>
                                                    </AccordionItemPanel>
                                                </AccordionItem>
                                                <AccordionItem uuid="d-1">
                                                    <AccordionItemHeading>
                                                        <AccordionItemButton>
                                                        Question 4
                                                        </AccordionItemButton>
                                                    </AccordionItemHeading>
                                                    <AccordionItemPanel>
                                                        <p>
                                                        It is a long established fact that a reader will be distracted by the readable content of a page when 
                                                        looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, 
                                                        as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing 
                                                        packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' 
                                                        will uncover many web sites still in their infancy.
                                                        </p>
                                                    </AccordionItemPanel>
                                                </AccordionItem>
                                            </Accordion>
                                            </AccordionItemPanel>
                                        </AccordionItem>
                                        <AccordionItem>
                                            <AccordionItemHeading>
                                                <AccordionItemButton>
                                                    Section
                                                </AccordionItemButton>
                                            </AccordionItemHeading>
                                            <AccordionItemPanel>
                                                <p>
                                                    In ad velit in ex nostrud dolore cupidatat consectetur
                                                    ea in ut nostrud velit in irure cillum tempor laboris
                                                    sed adipisicing eu esse duis nulla non.
                                                </p>
                                            </AccordionItemPanel>
                                        </AccordionItem>
                                        <AccordionItem>
                                            <AccordionItemHeading>
                                                <AccordionItemButton>
                                                    Section
                                                </AccordionItemButton>
                                            </AccordionItemHeading>
                                            <AccordionItemPanel>
                                                <p>
                                                    In ad velit in ex nostrud dolore cupidatat consectetur
                                                    ea in ut nostrud velit in irure cillum tempor laboris
                                                    sed adipisicing eu esse duis nulla non.
                                                </p>
                                            </AccordionItemPanel>
                                        </AccordionItem>

                                    </Accordion>


                            </div>
                        </section>
                    {/* ==================== faq section part end============== */}
                </section>
            </Col>
            <Col xs={12} sm={6} md={5} lg={5} xl={4} xxl={4}>
            <section className={styles.AssocForm}>
                    <h3>
                        <Icon.PersonCircle/>
                        <span>Create a Support Case</span>
                    </h3>
                    <div className={styles.ErrorSummary}>
                        {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                    </div>
                    <form id="associateForm" className='associate-form associate-form-faq' onSubmit={handleSubmit(onSubmit)}>
                        <div className={styles.formCoantainer}>
                            <div className={styles.formgroup}>
                                <label>Related to</label>
                                <input type="text" {...register('related_to')} onChange={handleChange} className={`${errors.related_to ? 'is-invalid' : ''}`} autoComplete="off" />
                                <div className="invalid-feedback">{errors.related_to?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Associate</label>
                                <Select options={associate} {...register('associateId')} onChange={onAssociateChange} className={`${errors.associate ? 'is-invalid' : ''}`} value={associate.find(item => item.value === associateId) || ''}/>
                                <div className="invalid-feedback">{errors.associate?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Corporate Card Number</label>
                                <Select options={corporateCard} {...register('assigned_card')} onChange={onCardChange} value={corporateCard.find(item => item.value === assigned_card) || ''} />
                                <div className="invalid-feedback">{errors.corporate_card?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Date & Time</label>
                                <Datetime className={`${errors.added_date_time ? 'is-invalid' : ''}`} value={datetime}  dateFormat="DD/MM/YYYY" timeFormat='hh:mm:ss A' onChange={onChangeDate} />
                                <input type="hidden" {...register('added_date_time')} value={datetime}/>
                                <div className="invalid-feedback">{errors.added_date_time?.message?.toString()}</div>
                            </div>
                            <div className={styles.formgroup}>
                                <label>Message</label>
                                <textarea {...register('message')} onChange={handleTextAreaChange} className={`${errors.related_to ? 'is-invalid' : ''}`}/>
                                <div className="invalid-feedback">{errors.message?.message?.toString()}</div>
                            </div>
                            <div className={styles.submitButton}>
                            <input type="hidden" {...register('end_consumer_id')} value={endConsumerId} />   
                            <Button color="primary"
                                variant="contained"
                                type="submit"
                                onClick={submitForm}
                                 >
                                { showLoader ? <Loader /> : null } Create
                            </Button>
                            </div>
                        </div>
                    </form>
                </section>
            </Col>
        </Row>
    </Container>
</section>
{/* ===================Create New Associates end================= */}

</section>
{/* ================dashboard right container end================== */}

</section>
{/* ====================== main container part end======================= */}
{/* ===============footer frontend admin==================== */}
<MemberFooter/>
{/* ===============footer frontend admin end==================== */}
</section>
);
}




