import React, {useState, useContext, useEffect} from 'react';
/*import Header from "components/Front/Header/Header";
import Footer from "components/Front/Footer/Footer";*/
import styles from '../../styles/Login.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
//import CryptoJS from "crypto-js";

//import * as Icon from 'react-bootstrap-icons';
export default function Index() {  

  //const { serverUrl } = useContext(GlobalContext);
  //const [validationErrors, setvalidationErrors] = useState(null);
  //const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const router = useRouter();

  const [decrptedData, setDecrptedData] = useState("");

  var validationSchema = Yup.object().shape({
    otpcode: Yup.string().required('OTP is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  useEffect(() => {

    const search = window.location.search;
    const params = new URLSearchParams(search);
    const emaildata:any = params.get('data');

    const decryptData = () => {
      setDecrptedData(emaildata);
    };

    decryptData();

    //console.log(object.abc);

    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  
  []) 

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}validate-otp`, formData).then((response) => {
      setshowLoader(false)
      if(response.data.status == 0){
        //setvalidationErrors(null);
        //setsuccessMessage(response.data.message);  
        toast.success(response.data.message);
        router.push('/login');
      }else{
        //setsuccessMessage(null);
        //setvalidationErrors(response.data.message);
        toast.error(response.data.message);
      }        
    });
  };

  return (
    <section className={styles.LoginMainContainer}>
{/* =============sign up form section================== */}
    <section className={styles.LoginForm}>
    <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                  <Col xl={12} lg={12} md={6} sm={12}>
                   <div className={styles.LoginFormBox}>
                        <h2><img src={'/assets/images/tick-icon.png'} /><span>Verification</span></h2>
                        {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                        <ToastContainer
                            position="top-right"
                            autoClose={10000}
                            hideProgressBar={false}
                            newestOnTop={false}
                            closeOnClick
                            rtl={false}
                            pauseOnFocusLoss
                            draggable
                            pauseOnHover
                            theme="light"
                        />
                        <form className='enquiry-form' onSubmit={handleSubmit(onSubmit)}>
                          <Row>
                              <Col sm={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                      Email OTP
                                    </label>
                                    <input type="text" {...register('otpcode')}  className={`form-control ${errors.otp ? 'is-invalid' : ''}`} autoComplete ="off" />
                                    <div className="invalid-feedback">{errors.otp?.message}</div>
                                    <div className="invalid-feedback">{errors.otpcode?.message}</div>
                                    <p className="verifynote">* To verify your registreed email address, please enter the one time password send to your registered email.</p>
                                </div>
                              </Col>
                          </Row>  
                          <Row>
                            <Col sm={12}>
                              <input type="hidden" value={decrptedData} {...register('code')} />
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Verify Now </Button>
                                </div>
                            </Col>
                          </Row>
                        </form>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
<div className="footerContainer">
        © 2022 All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}