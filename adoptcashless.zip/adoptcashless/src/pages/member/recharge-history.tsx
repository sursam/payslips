import React, {useState, useEffect, Fragment} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
//import SidebarMenu from 'react-bootstrap-sidebar-menu';
import Link from 'next/link';
import axios from "axios";

import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import PaymentInvoice from "../../components/PaymentInvoice";
import UsageStatement from "../../components/UsageStatement";
import { saveAs } from "file-saver";
import { pdf } from "@react-pdf/renderer";
import ReactPaginate from "react-paginate";
import LoadingScreen from "../../components/loadingScreen";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
//import Moment from 'moment';
import { Button } from "@material-ui/core";

export default function RechargeHistory() { 
    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    const [showBarLoader, setShowBarLoader] = useState(true);
    const [showUsageBarLoader, setShowUsageBarLoader] = useState(true);
    const [allTransactions, setAllTransactions] = useState([]);
    const [pageCount, setpageCount] = useState(0);
    const [isFetching, setIsFetching] = useState(false);
    const [allUsageMonths, setAllUsageMonths] = useState<string[]>([]);
    const [filteredUsageMonths, setFilteredUsageMonths] = useState<string[]>([]);
    const [usageStatementsCount, setUsageStatementsCount] = useState(0);
    const [usageMonths, setUsageMonths] = useState<string[]>([]);
    const [corporateCards, setCorporateCards] = useState<string[]>([]);
    const [companyInfo, setCompanyInfo] = useState({});
    //const [currentPage, setCurrentPage] = useState(1);
    //const [monthNames, setMonthNames] = useState<string[]>(["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]);
    const [statementSearchText, setStatementSearchText] = useState('');
    const [historySearchText, setHistorySearchText] = useState('');
    const [siteLogo, setSiteLogo] = useState('');
    const [accountInfo, setAccountInfo]:any = useState({});
    const [billingAddress, setBillingAddress] = useState('');
    const [endConsumerInfo, setEndConsumerInfo] = useState('');
    //let currentPage = 1;
    let limit = 9;
    let usageLimit = 8;

    useEffect(() => {
        axios.get(`${process.env.serverUrl}get-company-info/${endConsumerId}`,{}).then((response) => { 
            let companyData = {};
            if(response.data){
              response.data.forEach(infoData => {
                companyData[infoData.field_name] = infoData.field_value;
              });          
            }
            setCompanyInfo(companyData);   
        });
        getAllTransactions();
        //getPastMonths(47);
        axios.get(`${process.env.serverUrl}get-corporate-cards/${endConsumerId}`,{}).then((response) => {
            let allCards = Array();
            if(typeof response.data !== 'undefined'){
                response.data.forEach((card:any) => {
                    let cardId = card.card_id;
                    allCards.push(cardId);
              });
            }
            setCorporateCards(allCards);
            getUsageMonths(allCards);
        });

        axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
            setSiteLogo(response.data.logo);   
        });

        //generateInvoicePdf('a619n000000cekPAAQ');

        axios.get(`${process.env.serverUrl}get-account-info-by-endconsumer/${endConsumerId}`,{}).then((response) => {
            setAccountInfo(response.data);
            if(response.data.account_name__r != null){
              let accountData = response.data.account_name__r;
              let billAddress:any = []; 
              Object.keys(accountData).map(key => {
                if(accountData[key] != null && key != 'attributes' && key != 'Name' && key != 'ABN__c' && key != 'ACN__c'){
                  billAddress.push(accountData[key]);
                }
              });
              setBillingAddress(billAddress.join(', '));
            }
        });
        
        axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
            setEndConsumerInfo(response.data);   
        });
    }, 
    [])

    const getAllTransactions = (keywords = '', pCount = 1) => {
        axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${pCount}&size=${limit}&s=${keywords}`,{}).then((response) => { 
            setShowBarLoader(false);
            setAllTransactions(response.data.Transactions);
            const total = response.data.totalItems;
            setpageCount(Math.ceil(total / limit));       
        });
    };

    const handlePageClick = async (data:any) => {
        let currentPage = data.selected + 1;
        //setCurrentPage(data.selected + 1);
        getAllTransactions(historySearchText, currentPage);
        /*axios.get(`${process.env.serverUrl}get-all-transactions/${endConsumerId}/?page=${currentPage}&size=${limit}`,{}).then((response) => {
            setAllTransactions(response.data.Transactions);
        });*/
    };

    const customFormatDate = (date, format = 'y-m-d') => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
    
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
    
        let retDate = '';
        switch(format){
            case 'd/m/y': retDate = [day, month, year].join('/');
                break;
            case 'y-m-d': 
            default:
                retDate = [year, month, day].join('-');
                break;
        }
        return retDate;
    }

    const generateInvoicePdf = async (transactionId) => {
        setIsFetching(true);
        //const endConsumerResponse = await fetch(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`);
        //const endConsumerInfo = await endConsumerResponse.json();
        const transactionResponse = await fetch(`${process.env.serverUrl}get-transaction-details/${transactionId}`);
        const transactionInfo = await transactionResponse.json();
        if(Object.keys(transactionInfo).length && Object.keys(endConsumerInfo).length){
            const blob = await pdf(
                <PaymentInvoice siteLogo={siteLogo} accountInfo={accountInfo} billingAddress={billingAddress} companyInfo={companyInfo} endConsumerInfo={endConsumerInfo} transactionInfo={transactionInfo} />
            ).toBlob();   
            
            /*var file:any = window.URL.createObjectURL(blob);
            var iframe:any = document.querySelector("#iframe");
            if(typeof iframe !== 'undefined'){
                iframe.src = file;
            }*/
                        
            saveAs(blob, `invoice-${String(transactionId).padStart(6, '0')}.pdf`);
            setIsFetching(false);
        }
    }
    
    /*const getPastMonths = (count) => {
        var monthName:string[] = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        var months = Array();
        //var d = new Date();
        var d = Moment(new Date()).subtract(1, 'months').toDate();
        //d.setDate(1);
        //console.log(d)
        for (let i = 0; i <= count; i++) {
            let monthYearName = monthName[d.getMonth()] + ' ' + d.getFullYear();
            let obj:any = {};
            obj.monthNo = d.getMonth();
            obj.monthYear = d.getFullYear();
            obj.monthLabel = monthYearName;
            months.push(obj);
            d.setMonth(d.getMonth() - 1);
        }
        setUsageMonths(months); 
    }*/
    const getUsageMonths = (allCards) => {
        const data = {
            corporateCards: allCards,
        };
        axios.post(`${process.env.serverUrl}get-usage-statements-months`, data).then((response) => {
            setShowUsageBarLoader(false);
            let allUsgMonths = response.data;
            setAllUsageMonths(allUsgMonths);
            //setUsageMonths(allUsgMonths);
            paginateUsageMonths(allUsgMonths, 0);
        });
    }
    const handleUsagePageClick = async (data:any) => {
        let monthsData = (statementSearchText != '') ? filteredUsageMonths : allUsageMonths;
        paginateUsageMonths(monthsData, data.selected);
    };
    const paginateUsageMonths = async (data, page) => {
        const total = data.length;
        setUsageStatementsCount(Math.ceil(total / usageLimit)); 
        const usageOffset = page * usageLimit;
        setUsageMonths(data.slice(usageOffset, (usageOffset + usageLimit)));
    };
    const generateStatementPdf = async (monthNo, monthYear) => {
        setIsFetching(true);
        const usageResponse = await fetch(`${process.env.serverUrl}get-usage-statements`, {
            method: 'post',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({
                monthNo: monthNo,
                monthYear: monthYear,
                corporateCards: corporateCards,
            })
        });
        const usageInfo = await usageResponse.json();
        const date = new Date();
        date.setMonth(monthNo);
        console.log(corporateCards)
        console.log(usageInfo)
        var firstDay = new Date(monthYear, monthNo, 1);
        var lastDay = new Date(monthYear, monthNo + 1, 0);
        //console.log(firstDay, lastDay)
        setIsFetching(false);
        if(Object.keys(usageInfo).length){
            const blob = await pdf(
                <UsageStatement siteLogo={siteLogo} accountInfo={accountInfo} billingAddress={billingAddress} endConsumerInfo={endConsumerInfo} companyInfo={companyInfo} usageInfo={usageInfo} monthYear={`${english_ordinal_suffix(firstDay)} ${date.toLocaleString('en-US', { month: 'long' })} ${monthYear} to ${english_ordinal_suffix(lastDay)} ${date.toLocaleString('en-US', { month: 'long' })} ${monthYear}`} />
            ).toBlob();

            var file:any = window.URL.createObjectURL(blob);
            var iframe:any = document.querySelector("#iframe");
            if(typeof iframe !== 'undefined'){
                iframe.src = file;
            }

            //saveAs(blob, `statement-${(monthNo + 1)}-${monthYear}-${String(endConsumerId).padStart(6, '0')}.pdf`);
        }else{
            toast.error('No records are available.');
        }
    }
    const english_ordinal_suffix = (dt) =>
    {
        return dt.getDate()+(dt.getDate() % 10 == 1 && dt.getDate() != 11 ? 'st' : (dt.getDate() % 10 == 2 && dt.getDate() != 12 ? 'nd' : (dt.getDate() % 10 == 3 && dt.getDate() != 13 ? 'rd' : 'th'))); 
    }

    const handleStatementSearch = event => {
        setStatementSearchText(event.target.value);
        searchStatementKeyword(event.target.value);
    };
    const searchStatementKeyword = (text = '') => {
        //console.log(usageMonths);
        const filtered = allUsageMonths.filter(entry => 
            Object.values(entry).some(val => 
                (val.toString().toLowerCase()).includes(text.toLowerCase()) || (Object.values(entry).join(' ').toLowerCase()).includes(text.toLowerCase())
            )
        );
        //setUsageMonths(filtered);
        setFilteredUsageMonths(filtered);
        paginateUsageMonths(filtered, 0);
    };
    const handleStatementSearchEnter = event => {
        event.preventDefault();
        if (event.key === 'Enter' || event.keyCode === 13) {
            searchStatementKeyword(statementSearchText);
        }
    };
    const handleStatementSearchClick = event => {
        event.preventDefault();
        searchStatementKeyword(statementSearchText);
    };
    const handleStatementClearClick = event =>{
        event.preventDefault();
        setStatementSearchText('');
        //setUsageMonths(allUsageMonths);
        paginateUsageMonths(allUsageMonths, 0);
    }
    
    const handleHistorySearch = event => {
        setHistorySearchText(event.target.value);
        setShowBarLoader(true);
        getAllTransactions(event.target.value);
    };
    const handleHistorySearchEnter = event => {
        event.preventDefault();
        if (event.key === 'Enter' || event.keyCode === 13) {
            setShowBarLoader(true);
            getAllTransactions(historySearchText);
        }
    };
    const handleHistorySearchClick = event => {
        event.preventDefault();
        setShowBarLoader(true);
        getAllTransactions(historySearchText);
    };
    const handleHistoryClearClick = event =>{
        event.preventDefault();
        setHistorySearchText('');
        setShowBarLoader(true);
        getAllTransactions();
    }
    
  return (
    <section className={styles.mainDash}>
        {
            isFetching ? <LoadingScreen /> : ''
        }
      {/* ====================== top section start ======================= */}
        <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
              <MemberMenu/>   
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                        <Col sm={12}>
                          <h2>Prepaid Card Portal {/*<Link legacyBehavior href={"/associates"}><a>Add New Associate</a></Link>*/}</h2>
                        </Col> 
                    </Row>
                  </Container>

                  {/* ===================Create New Associates================= */}
                      <section className={styles.CommonContainer}>
                          <Container className={styles.DashContainer}>
                              <Row>
                                    <Col sm={12}>
                                        <div className='pdfViewer'> 
                                            <iframe src="" id="iframe" width="100%" height="100%"></iframe>
                                        </div>
                                    </Col>
                                    <Col sm={6}>
                                      <div className={styles.Associates}>
                                          <h2>Recharge History</h2>
                                            <div className={styles.searchBox}>
                                                <input type="text" name="historySearchText" onChange={handleHistorySearch} value={historySearchText} onKeyUp={handleHistorySearchEnter} />
                                                {historySearchText && <a onClick={handleHistoryClearClick} className={styles.searchClearBtn}><Icon.XCircle/></a> }                                              
                                                <Button color="primary"
                                                    variant="contained"
                                                    type="button"
                                                    onClick={handleHistorySearchClick} >
                                                    Search
                                                </Button>
                                            </div>
                                          {/* ============ Recharge History ================= */}
                                          <div className={styles.RechargeHistoryList}>                                                
                                            {showBarLoader ?
                                                (<div className="bar_loader">
                                                <div className="bar"></div>
                                                <div className="bar2"></div>
                                                <div className="bar3"></div>
                                                <div className="bar4"></div>
                                                </div>)
                                            :
                                                <div>
                                                    <dl>
                                                        { allTransactions.map((transaction:any) => (
                                                            <dt>
                                                                <div className={styles.ImgPriceGroup}>
                                                                    <figure><Icon.FilePdfFill/></figure>
                                                                    <div className={styles.PriceGroup}>
                                                                        {'$'+transaction.total_amount}
                                                                        <span>{customFormatDate(transaction.created_on, 'd/m/y')}</span>
                                                                    </div>
                                                                </div>
                                                                <div className={styles.ButtonAction}>
                                                                    <a href="#" className={(transaction.recharge_procedure == 'Auto') ? '' : styles.TopUp}>{(transaction.recharge_procedure == 'Auto') ? 'Auto Top-Up' : 'Manual Recharge'}</a>
                                                                </div>
                                                                
                                                                <div className={styles.ButtonGroupPart}>
                                                                    {/*<PaymentInvoice salesforceId={transaction.salesforce_id} />*/}
                                                                    <Link legacyBehavior href="#"><a onClick={() => generateInvoicePdf(transaction.salesforce_id)}>Download</a></Link>
                                                                    {/*<PDFDownloadLink document={<PaymentInvoice salesforceId={transaction.salesforce_id} />} fileName={`invoice-${String(transaction.id).padStart(6, '0')}.pdf`}>
                                                                        {({ blob, url, loading, error }) => (loading ? 'Loading document...' : 'Download')}
                                                                    </PDFDownloadLink>*/}  
                                                                    {/*<a href="#">Dispute</a>*/}
                                                                </div>
                                                            </dt>
                                                        )) }
                                                    </dl>
                                                    <div className={styles.paginationContainer}>
                                                        <ReactPaginate
                                                            previousLabel={"<<"}
                                                            nextLabel={">>"}
                                                            breakLabel={"..."}
                                                            pageCount={pageCount}
                                                            marginPagesDisplayed={2}
                                                            pageRangeDisplayed={3}
                                                            onPageChange={handlePageClick}
                                                            containerClassName={"pagination justify-content-right"}
                                                            pageClassName={"page-item"}
                                                            pageLinkClassName={"page-link"}
                                                            previousClassName={"page-item"}
                                                            previousLinkClassName={"page-link"}
                                                            nextClassName={"page-item"}
                                                            nextLinkClassName={"page-link"}
                                                            breakClassName={"page-item"}
                                                            breakLinkClassName={"page-link"}
                                                            activeClassName={"active"}
                                                        />
                                                    </div> 
                                                </div> 
                                            }
                                          </div>
                                         {/* ============ Recharge History end================= */}
                                        
                                       </div>
                                    </Col>
                                    <Col sm={6}>
                                        <div className={styles.Associates}>

                                            <h2>Usage Statements</h2>
                                            <div className={styles.searchBox}>
                                                <input type="text" name="statementSearchText" onChange={handleStatementSearch} value={statementSearchText} onKeyUp={handleStatementSearchEnter} />
                                                {statementSearchText && <a onClick={handleStatementClearClick} className={styles.searchClearBtn}><Icon.XCircle/></a> }                                              
                                                <Button color="primary"
                                                    variant="contained"
                                                    type="button"
                                                    onClick={handleStatementSearchClick} >
                                                    Search
                                                </Button>
                                            </div>
                                            {/* ================= Usage Statements ================== */}
                                            <div className={styles.UsageStatements}>
                                                {showUsageBarLoader ? 
                                                    <div className="bar_loader">
                                                        <div className="bar"></div>
                                                        <div className="bar2"></div>
                                                        <div className="bar3"></div>
                                                        <div className="bar4"></div>
                                                    </div>
                                                : 
                                                    <div>
                                                        <dl>
                                                            { usageMonths ?
                                                                usageMonths.map((usageMonth:any) => (
                                                                    <dt>
                                                                        <div className={styles.ImgPriceGroup}>
                                                                            <figure><Icon.FilePdfFill/></figure>
                                                                            <div className={styles.PriceGroup}>
                                                                                {`${usageMonth.month_name} ${usageMonth.year}`}
                                                                            </div>
                                                                        </div>
                                                                        <div className={styles.ButtonGroupPart}>
                                                                            <Link legacyBehavior href="#"><a onClick={() => generateStatementPdf((usageMonth.month - 1), usageMonth.year)}>Download</a></Link>
                                                                        </div>
                                                                    </dt>
                                                                )) 
                                                            : ''
                                                            }
                                                        </dl>
                                                        <div className={styles.paginationContainer}>
                                                            <ReactPaginate
                                                                previousLabel={"<<"}
                                                                nextLabel={">>"}
                                                                breakLabel={"..."}
                                                                pageCount={usageStatementsCount}
                                                                marginPagesDisplayed={2}
                                                                pageRangeDisplayed={3}
                                                                onPageChange={handleUsagePageClick}
                                                                containerClassName={"pagination justify-content-right"}
                                                                pageClassName={"page-item"}
                                                                pageLinkClassName={"page-link"}
                                                                previousClassName={"page-item"}
                                                                previousLinkClassName={"page-link"}
                                                                nextClassName={"page-item"}
                                                                nextLinkClassName={"page-link"}
                                                                breakClassName={"page-item"}
                                                                breakLinkClassName={"page-link"}
                                                                activeClassName={"active"}
                                                            />
                                                        </div>
                                                    </div>
                                                }
                                            </div>
                                            {/* ================= Usage Statements end================== */}
                                        </div>
                                    </Col>
                              </Row>
                            </Container>
                      </section>
                  {/* ===================Create New Associates end================= */}
                 
              </section>
            {/* ================dashboard right container end================== */}
                                                
        </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
        <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}




