import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import PaymentSource from "../../components/PaymentSource";
import SEO from '../../components/SEO';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import GeneralSettings from "../../components/Front/Member/GeneralSettings";

export default function Settings() { 
    const [selectedTab, setSelectedTab] = useState('company_info');
    const onChangeSettingsType = (e) => {
        e.preventDefault();
        setSelectedTab(e.target.value);
    }
return (
<section className={styles.mainDash}>
<SEO title="Settings">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
</SEO>
{/* ====================== top section start ======================= */}
<MemberHeader/>
{/* ====================== top section end ======================= */}
{/* ====================== main container part ======================= */}
<section className={styles.MainContainer}>
{/* ================left dashboard menu list================== */}
    <MemberMenu/>   
{/* ================left dashboard menu list end================== */}
{/* ================dashboard right container================== */}
    <section className={styles.DashboardRight}>
        <Container className={styles.DashContainer}>
            <Row>
                <Col sm={10}>
                    <h2>Prepaid Card Portal</h2>
                </Col> 
                <Col sm={2}>
                </Col>
            </Row>
        </Container>
        <div className={styles.CommonContainer}>
            <Container className={styles.DashContainer}>
                <Row>
                    <Col sm={12}>
                        <div className={styles.SettingsPanel}>
                            <h2>Settings</h2>
                            <Container className={styles.DashContainer}>
                                <Row>
                                    <Col sm={3}>
                                        <aside>
                                            <ul>
                                                <li className={(selectedTab == 'company_info') ? styles.show : styles.hide}>
                                                    General <Icon.Gear/>
                                                </li>
                                                <li className={(selectedTab == 'manage_users') ? styles.show : styles.hide}>
                                                    Users <Icon.People/>
                                                </li>
                                                <li className={(selectedTab == 'preferred_payment') ? styles.show : styles.hide}>
                                                    Payment Details <Icon.House/>
                                                </li>
                                                <li className={(selectedTab == 'login_security') ? styles.show : styles.hide}>
                                                    Login & Security <Icon.Lock/>
                                                </li>    
                                            </ul>
                                        </aside>
                                    </Col>
                                    <Col sm={9}>
                                        <article>
                                            <ul className={styles.SettingsType}>
                                                <li>
                                                    <input type="radio" className={styles.SettingsRadioType} name="settingsType" value="company_info" onChange={onChangeSettingsType} id="type_company_info" />
                                                    <label className={styles.segmentButton + ' ' + ((selectedTab == 'company_info') ? styles.active : '')} htmlFor="settingsType">Company Information</label>
                                                </li>
                                                <li>
                                                    <input type="radio" className={styles.SettingsRadioType} name="settingsType" value="manage_users" onChange={onChangeSettingsType} id="type_manage_users" />
                                                    <label className={styles.segmentButton + ' ' + ((selectedTab == 'manage_users') ? styles.active : '')} htmlFor="settingsType">Manage Users</label>
                                                </li>
                                                <li>
                                                    <input type="radio" className={styles.SettingsRadioType} name="settingsType" value="preferred_payment" onChange={onChangeSettingsType} id="type_preferred_payment" />
                                                    <label className={styles.segmentButton + ' ' + ((selectedTab == 'preferred_payment') ? styles.active : '')} htmlFor="settingsType">Preferred Payment</label>
                                                </li>
                                                <li>
                                                    <input type="radio" className={styles.SettingsRadioType} name="settingsType" value="login_security" onChange={onChangeSettingsType} id="type_login_security" />
                                                    <label className={styles.segmentButton + ' ' + ((selectedTab == 'login_security') ? styles.active : '')} htmlFor="settingsType">Login & Security</label>
                                                </li>
                                            </ul>
                                        
                                            <div className={(selectedTab == 'company_info') ? styles.show : styles.hide}>
                                                <GeneralSettings />
                                            </div>
                                            <div className={(selectedTab == 'manage_users') ? styles.show : styles.hide}>
                                                Coming Soon
                                            </div>
                                            <div className={(selectedTab == 'preferred_payment') ? styles.show : styles.hide}>
                                                <div className='paymentContainerPart02'> 
                                                    <div className='paymentContainerPart'>
                                                        <div className={styles.paymentMethods}>
                                                            <div className={styles.CheckOutPart}>
                                                                <div className={styles.cardDetails}>
                                                                    <div className={styles.PaymentRight}>
                                                                        <h6><strong>Preferred Payment Method</strong></h6>
                                                                        <PaymentSource />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className={(selectedTab == 'login_security') ? styles.show : styles.hide}>
                                                Coming Soon
                                            </div>
                                        </article>
                                    </Col>
                                </Row>
                            </Container>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
        
        
    </section>
{/* ================dashboard right container end================== */}

</section>
{/* ====================== main container part end======================= */}
{/* ===============footer frontend admin==================== */}
<MemberFooter/>
{/* ===============footer frontend admin end==================== */}
</section>
);
}




