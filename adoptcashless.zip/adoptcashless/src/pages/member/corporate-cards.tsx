import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import Link from 'next/link';
import axios from "axios";
import Select from 'react-select';
import SEO from '../../components/SEO';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import GlobalContext from '../../components/GlobalContext';

import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import LoadingScreen from '../../components/loadingScreen';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function CorporateCards() { 

    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    var [cards, setCards] = useState([]);
    var [availableCards, setAvailableCards] = useState<any[]>([]);
    var [associates, setAssociates] = useState<any[]>([]);
    // var [linkSelectedCardValue, setLinkSelectedCardValue] = useState(false);
    // var [linkSelectedCardLabel, setLinkSelectedCardLabel] = useState(false);
    
    const [searchText, setsearchText] = useState('');
    const [showLoader, setshowLoader] = useState(false);
    const [showCreditLoader, setshowCreditLoader] = useState(false);
    const [activeChecked, setActiveChecked] = useState(false);
    const [inactiveChecked, setInactiveChecked] = useState(false);
    const [isFetching, setIsFetching] = useState(false);
    const [showSearchLoader, setShowSearchLoader] = useState(false);
    const [cardAssociates, setCardAssociates] = useState<any[]>([]);
    const { stripeCreds } = useContext(GlobalContext);
    const { tngPercentAmount } = useContext(GlobalContext);
    
    useEffect(() => {
        getAllCorporateCards();
        getAvailableCards();
        getAssociate();
        axios.get(`${process.env.serverUrl}get-stripe-account/${endConsumerId}`,{}).then((response) => { 
            console.log(response.data) 
            if(typeof response.data.records != 'undefined' && response.data.records.length > 0){ 
                setStateCredit(prevState => ({
                    ...prevState,
                    connectedAccount: response.data.records[0].account_name__r.Stripe_Acc_Id__c,
                    stripeCustomerId: response.data.records[0].Stripe_Customer_Id__c,
                }));
            }
        });
        axios.get(`${process.env.serverUrl}get-card-associates/${endConsumerId}`,{}).then((response:any) => {  
            const cardAssociateOptions:any = [];
            response.data.records.forEach(card => {
                var obj:any = {};
                /*obj['value'] = card.RFID_Card__r.Id;
                obj['label'] = card.Name + ' - ' + card.RFID_Card__r.Display_Card_Number__c;*/
                obj['value'] = card.salesforce_id;
                obj['label'] = card.associate ? card.associate.name + ' - ' + card.card_number : card.card_number;
                cardAssociateOptions.push(obj);  
                //console.log(card);
            });
            setCardAssociates(cardAssociateOptions); 
        });
        axios.get(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`,{}).then((response) => {
            let autoTopup = 0;
            let autoTopupSourceId = '';
            let autoTopupSourceType = '';
            let autoTopupRechargeAmount = '';
            let autoTopupTriggerPoint = '';
            let autoTopupCreditVal = '';
            if(response.data.is_auto_topup == "1"){
                autoTopup = 1;
                autoTopupSourceId = response.data.auto_topup.source_id;
                autoTopupSourceType = response.data.auto_topup.source_type;
                autoTopupRechargeAmount = response.data.auto_topup.auto_recharge_amount;
                autoTopupTriggerPoint = response.data.auto_topup.auto_trigger_point;
                autoTopupCreditVal = response.data.auto_topup.extra_credit_val;
            }
            let unAssignedCred= (response.data.current_balance != null) ? response.data.current_balance : 0;
            setStateCredit(prevState => ({
                ...prevState,
                unAssignedCredit: parseFloat(unAssignedCred).toFixed(2),
                autoTopup: autoTopup,
                autoTopupSourceId: autoTopupSourceId,
                autoTopupSourceType: autoTopupSourceType,
                autoTopupRechargeAmount: autoTopupRechargeAmount,
                autoTopupTriggerPoint: autoTopupTriggerPoint,
                autoTopupCreditVal: autoTopupCreditVal,
            }));
        });
    }, 
    [])
    
    const getAvailableCards = (defaultCard = {}) => {
        axios.get(`${process.env.serverUrl}get-available-cards/${endConsumerId}`,{}).then((response) => {             
            const cardOptions:any = [];
            if(Object.keys(defaultCard).length){
                cardOptions.push(defaultCard);
            }
            response.data.forEach(card => {
                var obj:any = {};
                obj['value'] = card.salesforce_id;
                obj['label'] = card.card_number;
                cardOptions.push(obj);
            }); 
            setAvailableCards(cardOptions); 
        });
    }

    const getAssociate = (defaultAssociate = {}) => {
        axios.get(`${process.env.serverUrl}get-available-associate/${endConsumerId}`,{}).then((response) => {             
            const associateOptions:any = [];
            if(Object.keys(defaultAssociate).length){
                associateOptions.push(defaultAssociate);
            }
            response.data.forEach(ass => {
                var obj:any = {};
                obj['value'] = ass.salesforce_id;
                obj['label'] = ass.name;
                associateOptions.push(obj);
            }); 
            setAssociates(associateOptions); 
        });
    }

    var [state, setState] = useState({
        associateId: '',
        assigned_card: '',
    });
    var { associateId, assigned_card } = state;

    const onAssociateChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          associateId: newValue.value,
        }));
    };

    const onCardChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          assigned_card: newValue.value,
        }));
    };
    
    const unlinkAssociate = (e) => {
        e.preventDefault();
        let salesforceId = e.target.dataset.id;
        confirmAlert({
            title: 'Confirm to unlink',
            message: 'Are you sure to do this?',
            buttons: [
            {
                label: 'Yes',
                onClick: () => {
                    if(salesforceId){
                        setIsFetching(true);
                        axios.get(`${process.env.serverUrl}unlink-corporate-card/${salesforceId}`,{}).then((response) => {  
                            if(response.data.status)
                            {
                                toast.success(response.data.message);
                                getAllCorporateCards();
                                getAvailableCards();
                                getAssociate();  
                                setIsFetching(false); 
                            } else{ 
                                toast.error(response.data.message); 
                            }
                        });
                    }
                }
            },
            {
                label: 'No',
            }
            ]
        });
    }
    const linkAssociate = (e) => {
        e.preventDefault();
        let cardId = e.target.dataset.card_id;
        setState(prevState => ({
            ...prevState,
            assigned_card: cardId,
        }));
    }

    const getAllCorporateCards = async (queryString = '') => { 
        const res = await fetch(`${process.env.serverUrl}get-corporate-cards/${endConsumerId + queryString}`);
        let cardList = await res.json();
        setCards(cardList);
        setShowSearchLoader(false); 
        
        /*axios.get(`${process.env.serverUrl}get-corporate-cards/${endConsumerId + queryString}`,{}).then((response) => {            
            setCards(response.data);
            //getAvailableCards();
            //getAssociate(); 
            //setIsFetching(false); 
            setShowSearchLoader(false);     
        });*/
    }

    const handleSearch = event => {
        setsearchText(event.target.value);
        searchKeyword(event.target.value);
    };

    const handleClearClick = event =>{
        event.preventDefault();
        setsearchText('');
        setShowSearchLoader(true);
        getAllCorporateCards();
    }

    const handleSearchEnter = event => {
        event.preventDefault();
        if (event.key === 'Enter' || event.keyCode === 13) {
            searchKeyword(searchText);
        }
    };

    const handleClick = event => {
        event.preventDefault();
        searchKeyword(searchText);
    };

    const searchKeyword = (text) => {
        //setShowSearchLoader(true);
        const params = {
            'search': text,
            'endConsumerId': endConsumerId
        };
        axios.post(`${process.env.serverUrl}search-corporate-cards`, params, { headers: { 'content-type': 'application/json',
        } }).then((response) => {
            setCards(response.data); 
            //setShowSearchLoader(false);
        });
    };

    const filterStatus = (e) => {
        e.preventDefault();
        //setIsFetching(true);
        let status = e.target.dataset.status;
        let queryString = '';
        if(status == "active"){
            setInactiveChecked(false);
            if(activeChecked){
                setActiveChecked(false);
            }else{
                queryString = `?status=${status}`;
                setActiveChecked(true);        
            }
        }else{
            setActiveChecked(false);
            if(inactiveChecked){
                setInactiveChecked(false);
            }else{
                queryString = `?status=${status}`;  
                setInactiveChecked(true);      
            }
        } 
        getAllCorporateCards(queryString);              
    };

    // const linkAssociateCard = (e) => {
    //     e.preventDefault();
    //     let salesforce_id = e.target.dataset.salesforce_id;

    //     const selectedCardOptions = { label: 11304224, value: 'a7W9p0000000FOrEAM' };

    //     const cardOptions:any = [];
    //     var obj:any = {};

    //     let cardValue = 'a7W9p0000000FOrEAM';
    //     let cardLabel = 11304224;
    //     cardOptions.push(obj);

    //     setLinkSelectedCardValue(cardValue);
    //     setLinkSelectedCardLabel(cardLabel);
    // };

    var validationSchema = Yup.object().shape({
        associateId: Yup.string().required('Associate is required'),
        assigned_card: Yup.string().required('Assigned card is required'),
    });

    var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
    var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);
    
    const submitForm = () => {    
        reset(state)
    }

    const onSubmit = (formData:any) => {
        setshowLoader(true);  
        axios.post(`${process.env.serverUrl}link-corporate-cards`, formData).then((response) => {
            setshowLoader(false)
            if(response.data.status == 1){
                getAllCorporateCards();
                getAvailableCards();
                getAssociate();
                resetForm(); 
                toast.success(response.data.message);
            }else{ 
                toast.error(response.data.message);
            }   
        });
    };

    const resetForm = () => {
        getAllCorporateCards();
        
        setState(prevState => ({
            ...prevState,
            associateId: '',
            assigned_card: '',
        }));
    }

    const changeCardStatus = (e) => {
        e.preventDefault();
        let associateId = e.target.dataset.assid;
        let salesforceId = e.target.dataset.card_id;
        let cardStatus = e.target.dataset.status;
        let status = (cardStatus == '1') ? '0' : '1';
        let statusText = (cardStatus == '1') ? 'In-Active' : 'Active';
        let cardData = {
            'associate_id': associateId,
            'salesforce_id': salesforceId,
            'status': status
        };
        confirmAlert({
            title: `Confirm to ${statusText}`,
            message: 'Are you sure to do this?',
            buttons: [
                {
                    label: 'Yes',
                    onClick: () => {
                        if(salesforceId){
                            setIsFetching(true);
                            axios.post(`${process.env.serverUrl}update-card-status-details`, cardData).then((resp) => {
                                setIsFetching(false);
                                if(!resp.data.error){
                                    getAllCorporateCards();
                                    toast.success(resp.data.message);  
                                }else{
                                    toast.error(resp.data.message);
                                } 
                            });
                        }
                    }
                },
                {
                    label: 'No',
                }
            ]
        });
    }

    var [stateCredit, setStateCredit] = useState({
        endConsId: endConsumerId,
        unAssignedCredit: '',
        cardAssociate: '',
        desiredAmount: '',
        autoTopup: 0,
        autoTopupSourceId: '',
        autoTopupSourceType: '',
        autoTopupRechargeAmount: '',
        autoTopupTriggerPoint: '',
        autoTopupCreditVal: '',
        connectedAccount: '',
        stripeCustomerId: '',
        stripeCredentials: stripeCreds,
        tngPercentAmnt: tngPercentAmount,
    });
    var { endConsId, unAssignedCredit, cardAssociate, desiredAmount, endConsId, autoTopup, autoTopupSourceId, autoTopupSourceType, autoTopupRechargeAmount, autoTopupTriggerPoint, autoTopupCreditVal, connectedAccount, stripeCustomerId, stripeCredentials, tngPercentAmnt } = stateCredit;

    var validationCreditSchema = Yup.object().shape({
        cardAssociate: Yup.string().required('Associate / Corporate Card is required'),
        desiredAmount: Yup.string().required('Desired Amount is required'),
    });

    var formCreditOptions = { resolver: yupResolver(validationCreditSchema) };
    var { register: registerCredit, handleSubmit: handleCreditSubmit, reset: resetCredit, formState: { errors: errorsCredit } } = useForm(formCreditOptions);

    const submitCreditForm = () => {    
        resetCredit(stateCredit)
    }

    const onCreditSubmit = (formData:any) => {
        setshowCreditLoader(true); 
        axios.post(`${process.env.serverUrl}allocate-unassigned-credit`, formData).then((response) => {
          setshowCreditLoader(false)
          if(response.data.error == 0){  
            toast.success(response.data.message);
            resetCreditForm();
          }else{
            toast.error(response.data.message);
          }        
        });
    };

    const resetCreditForm = () => { 
        let currentBalance = (parseFloat(unAssignedCredit) - parseFloat(desiredAmount)).toFixed(2);       
        setStateCredit(prevState => ({
            ...prevState,
            unAssignedCredit: currentBalance,
            cardAssociate: '',
            desiredAmount: '',
            autoTopup: 0,
            autoTopupSourceId: '',
            autoTopupSourceType: '',
            autoTopupRechargeAmount: '',
            autoTopupTriggerPoint: '',
            autoTopupCreditVal: '',
        }));
    }
    const handleCreditFieldChange = (event) => {    
        const { name, value } = event.target;
        setStateCredit(prevState => ({
          ...prevState,
          [name]: value,
        }));
    };

    const onCardAssociateChange = (
        newValue
      ) => {
        setStateCredit(prevState => ({
          ...prevState,
          cardAssociate: newValue.value,
        }));
    };

  return (
    <section className={styles.mainDash}>
        {
            isFetching ? <LoadingScreen /> : ''
        }
        <SEO title="Corporate Cards">
            <meta id="meta-description" name="description" content="" />
            <meta id="meta-keywords" name="keywords" content="" />
        </SEO>

      {/* ====================== top section start ======================= */}
          <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
                <MemberMenu/>
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                      <Col sm={12}>
                          <h2>Prepaid Card Portal <Link legacyBehavior href={"/associates"}><a>Add New Associate</a></Link></h2>
                         </Col> 
                    </Row>
                  </Container>

                  {/* ===================Create New Associates================= */}
                      <section className={styles.CommonContainer}>
                          <Container className={styles.DashContainer}>
                              <Row>
                                  <Col sm={8}>
                                      <div className={styles.Associates}>
                                            <h2>Corporate Cards</h2>
                                          <div className={styles.searchBox}>
                                              <input type="text" name="searchText" onChange={handleSearch} value={searchText} onKeyUp={handleSearchEnter}/>
                                              {searchText && <a onClick={handleClearClick} className={styles.searchClearBtn}><Icon.XCircle/></a> }
                                             
                                                <Button color="primary"
                                                    variant="contained"
                                                    type="button"
                                                    onClick={handleClick} 
                                                    disabled={showSearchLoader} >
                                                    { showSearchLoader ? <Loader /> : null } Search
                                                </Button>
                                          </div>
                                          <div className={styles.filTerby}>
                                              <label>Filter By</label>
                                              <button className={activeChecked ? styles.ButtonActive +' '+ styles.selected : styles.ButtonActive} onClick={filterStatus} data-status="active">Active</button>
                                              <button className={inactiveChecked ? styles.ButtonInActive +' '+ styles.selected : styles.ButtonInActive} onClick={filterStatus} data-status="inactive">In-Active</button>
                                          </div>
                                          <div className={styles.AssociatesList}>
                                              <dl>
                                              {cards.length ? (cards.map((card:any) => (
                                                <dt>
                                                    <div className={styles.AssocId}><Icon.CardHeading/><Link legacyBehavior href={`/card-deatils/${card.salesforce_id}`}><a> {card.card_number} </a></Link></div>
                                                    
                                                    <div className={(card.status == '1') ? styles.AssocButton : styles.AssocButtonIn}><Link legacyBehavior href="#"><a onClick={(card.status == '0' && !card.associate) ? linkAssociate : changeCardStatus} data-card_id={card.salesforce_id} data-assid={card.associate ? card.associate.salesforce_id : ''} data-status={card.status}>{(card.status == '1') ? 'Active' : 'In-Active'}</a></Link></div>

                                                    <div className={styles.AssocName}>
                                                    {card.associate && <span><Icon.PersonFill/><Link legacyBehavior href={`/associate-details/${card.associate.salesforce_id}`}><a> {card.associate.name} </a></Link></span> }
                                                    </div>
                                                    {card.associate ?
                                                        <><div className={styles.UnlinkButton}><Link legacyBehavior href="#"><a onClick={unlinkAssociate} data-id={card.associate.salesforce_id}><Icon.Link45deg />Unlink Associate</a></Link></div>
                                                        <div className={styles.AvailableCredit}><Link legacyBehavior href={`/card-deatils/${card.salesforce_id}`}><a>Available Credit <strong>${card.available_credit ? parseFloat(card.available_credit).toFixed(2) : (0).toFixed(2)}</strong></a></Link></div></>
                                                    :
                                                        <><div className={styles.linkAssociate}><Link legacyBehavior href="#"><a onClick={linkAssociate} data-card_id={card.salesforce_id}><Icon.Link45deg />Link Associate</a></Link></div>
                                                        <div className={styles.AvailableCredit}></div></>
                                                    }
                                                    
                                                </dt>
                                                )) ) : ( 

                                                    <p>No corporate cards found</p>
                                               )}  
                                             </dl>
                                          </div>
                                      </div>
                                  </Col>
                                  <Col sm={4}>
                                     <section className={styles.CorporateRight}>
                                        <article className={styles.CorporateCardSection}>
                                            <div className={styles.CorporateCardFormTitle}>
                                                <div className={styles.leftIcon}>
                                                    <Icon.Link/>
                                                </div>
                                                <div className={styles.leftContentCard}>
                                                    Link Corporate Card <br/>
                                                    To an Associate
                                                </div>
                                            </div>
                                            
                                            <form id="associateForm" className='associate-form' onSubmit={handleSubmit(onSubmit)}>
                                                <div className={styles.CardSectionForm}>
                                                    <div className={styles.formGroup}>
                                                        <label>Select a Unassigned Corporate Card</label>
                                                        <Select options={availableCards} value={availableCards.find(item => item.value === assigned_card) || ''} {...register('assigned_card')} onChange={onCardChange} />
                                                        <div className="invalid-feedback">{errors.assigned_card?.message?.toString()}</div>
                                                    </div>
                                                    <div className={styles.formGroup}>
                                                        <label>Select an Associate</label>
                                                        <Select options={associates} value={associates.find(item => item.value === associateId) || ''} {...register('associateId')} onChange={onAssociateChange} />
                                                        <div className="invalid-feedback">{errors.associateId?.message?.toString()}</div>
                                                    </div>
                                                    <div className={styles.ButtonGroup}>
                                                        <Button color="primary"
                                                            variant="contained"
                                                            type="submit"
                                                            onClick={submitForm}
                                                            className={styles.Transfer} 
                                                            disabled={showLoader} >
                                                            { showLoader ? <Loader /> : null } <Icon.Link/> Link
                                                        </Button>
                                                        {
                                                            assigned_card ?
                                                            <Button
                                                            variant="contained"
                                                            type="button"
                                                            onClick={resetForm} >
                                                                Cancel
                                                            </Button>
                                                            : ''
                                                        }
                                                    </div>
                                                </div>
                                            </form>
                                        </article>
                                        {(parseFloat(unAssignedCredit) > 0) ? 
                                            <article className={styles.AssignedCredit}>
                                                <div className={styles.AssignedCreditFormTitle}>
                                                    <div className={styles.leftIcon}>
                                                        <Icon.ArrowLeftRight/>
                                                    </div>
                                                    <div className={styles.leftContentCard}>
                                                        Allocate Un-Assigned Credit 
                                                        to a Corporate Card 
                                                    </div>
                                                </div>
                                                <form id="creditForm" className='credit-form' onSubmit={handleCreditSubmit(onCreditSubmit)}>
                                                    <div className={styles.AssignedSectionForm}>
                                                        <div className={styles.formGroup}>
                                                            <div className={styles.Creditlabel}>
                                                                <label>Un-Assigned Credit</label>
                                                                <div className="currencyDiv">
                                                                    <input type="text" {...registerCredit('unAssignedCredit')} value={parseFloat(unAssignedCredit).toFixed(2)} readOnly />
                                                                </div>                                                            
                                                            </div>
                                                        </div>
                                                        <div className={styles.formGroup}>
                                                            <label>Select an Associate / Corporate Card</label>
                                                            <Select options={cardAssociates} {...registerCredit('cardAssociate')} onChange={onCardAssociateChange} className={`${errorsCredit.cardAssociate ? 'is-invalid' : ''}`} value={cardAssociates.find(item => item.value === cardAssociate) || ''} />
                                                            <div className="invalid-feedback">{errorsCredit.cardAssociate?.message?.toString()}</div>
                                                        </div>
                                                        <div className={styles.formGroup}>
                                                            <label>Enter the Desired Amount</label>
                                                            <div className="currencyDiv">
                                                                <input type="number" max={parseFloat(unAssignedCredit).toFixed(2)} min="1" {...registerCredit('desiredAmount')} onChange={handleCreditFieldChange} className={`${errorsCredit.desiredAmount ? 'is-invalid' : ''}`} value={desiredAmount}  />
                                                            </div>                                                        
                                                            <div className="invalid-feedback">{errorsCredit.desiredAmount?.message?.toString()}</div>
                                                        </div>
                                                        <div className={styles.ButtonGroup}>
                                                            <Button color="primary"
                                                                variant="contained"
                                                                type="submit"
                                                                onClick={submitCreditForm}
                                                                className={styles.Transfer} 
                                                                disabled={showCreditLoader} >
                                                                { showCreditLoader ? <Loader /> : null } <Icon.Link/> Transfer
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </article>
                                        : ''}
                                     </section>
                                  </Col>
                              </Row>
                            </Container>
                      </section>
                  {/* ===================Create New Associates end================= */}
               </section>
            {/* ================dashboard right container end================== */}
    </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
          <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}




