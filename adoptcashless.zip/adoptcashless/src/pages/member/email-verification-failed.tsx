import React, {useState, useContext, useEffect} from 'react';
import styles from '../../styles/Login.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import SEO from '../../components/SEO';

export default function Index() {  

  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const router = useRouter();
  const [authenticationStatus, setAuthenticationStatus] = useState("");

  useEffect(() => {

    const search = window.location.search;
    const params = new URLSearchParams(search);

    const param = {
      'verificationcode': params.get('data'),
    };

      const authenticationStatus = async() => 
      {
        axios.post(`${process.env.serverUrl}verification-email-code`, param, { headers: { 'content-type': 'application/json',
      } }).then((response) => {
          
        if(response.data.status == 1)
        {
          setvalidationErrors(null);
          setsuccessMessage(response.data.message);
          setTimeout(() => router.push(response.data.req), 3000);
        }
        else
        {
          setsuccessMessage(null);
          setvalidationErrors(response.data.message);
        }

        });
      } 
      authenticationStatus();

      const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  [])

  return (
    <section className={styles.LoginMainContainer}>
      <SEO title="Reset Password">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
{/* =============sign up form section================== */}
  <section className={styles.LoginForm}>
      <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                    <div className={styles.LoginFormBox}>
                        <h2>
                            <img src={'/assets/images/reset-password-icon.png'} />
                            <span>Email Verification</span>
                        </h2>

                        <div className={styles.ErrorSummary}>
                            <ErrorSummary errors={validationErrors} success ={successMessage} />
                        </div>

                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
<div className="footerContainer">
        © 2023 All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}