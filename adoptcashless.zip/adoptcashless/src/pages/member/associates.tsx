import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import Link from 'next/link';
import SEO from '../../components/SEO';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import axios from "axios";
import Select from 'react-select';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Modal from 'react-bootstrap/Modal';
import InputMask from 'react-input-mask';

import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberMenu from "../../components/Front/Header/MemberMenu";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import PhoneInput from '../../components/PhoneInput';
import LoadingScreen from "../../components/loadingScreen";
import moment from 'moment';
//import { useRouter } from 'next/router'

const Associates = () => {
    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    const [show, setShow] = useState(false);
    var [associates, setAssociates] = useState([]);
    var [cards, setCards] = useState<any[]>([]);
    const [isFetching, setIsFetching] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => {
        resetForm();
        getAvailableCards();
        setShow(true);
    };
    var [associate, setAssociate] = useState([]);
    
    /*let limit = 10;
    const router = useRouter()  
    let currentPage = router.query.page ? router.query.page : 1;
    let queryString = `?page=${currentPage}&size=${limit}&status=1`;
    console.log(queryString);*/
    useEffect(() => {
        axios.get(`${process.env.serverUrl}get-associates/${endConsumerId}`,{}).then((response) => {            
            setAssociates(response.data);  
            //console.log(response.data); 
        });
        getAvailableCards();
    }, 
    [])
    

    const getAvailableCards = (defaultCard = {}) => {
        axios.get(`${process.env.serverUrl}get-available-cards/${endConsumerId}`,{}).then((response) => {             
            const cardOptions:any = [];
            if(Object.keys(defaultCard).length){
                cardOptions.push(defaultCard);
            }
            response.data.forEach(card => {
                var obj:any = {};
                obj['value'] = card.salesforce_id;
                obj['label'] = card.card_number;
                cardOptions.push(obj);
            }); 
            setCards(cardOptions); 
            //console.log(defaultCard)
        });
    }
    const [searchText, setsearchText] = useState('');
    //const [validationErrors, setvalidationErrors] = useState(null);
    //const [successMessage, setsuccessMessage] = useState(null);
    const [showLoader, setshowLoader] = useState(false);
    const [showSearchLoader, setShowSearchLoader] = useState(false);
    const genderOptions = [
        { value: 'm', label: 'Male' },
        { value: 'f', label: 'Female' }
    ]    

    var [state, setState] = useState({
        associateId: '',
        first_name: '',
        last_name: '',
        mobile: '',
        email: '',
        dob: null,
        gender: '',
        car_reg: '',
        assigned_card: '',
    });
    
    var { associateId, first_name, last_name, mobile, email, dob, gender, car_reg, assigned_card } = state;

    const [mobileError, setMobileError] = useState(false);
    const handleMobileInput = ({ target: { value } }:any) => {
        let mobileVal = value.replace('/\D/g', '');
        //console.log(mobileVal);
        setState(prevState => ({
            ...prevState,
            mobile: mobileVal
        }));
        if(mobileVal){
          setMobileError(true)
        }
        if(!mobileVal.length && mobileError)
          trigger('mobile')
    };
    const [dobError, setDobError] = useState(false);
    const handleDateInput = (dateOfBirth:any) => {
        let dobValue = moment(dateOfBirth).isValid() ? dateOfBirth : '';
        setState(prevState => ({
            ...prevState,
            dob: dobValue
        }));
        if(dobValue){
            clearErrors(["dob"])
            setDobError(false)
        }else{
            setDobError(true)
        }
        trigger('dob')
    };

    const editAssociate = async (e) => {
        e.preventDefault();
        clearErrors();
        setDobError(false);
        //setIsFetching(true);
        let associateId = e.target.dataset.id;
        if(associateId){
            const resp = await fetch(`${process.env.serverUrl}get-associate-details/${associateId}`);
            const associateRecords = await resp.json(); 
            if(associateRecords){
                let dateOfBirth:any = associateRecords.date_of_birth ? new Date(Date.parse(associateRecords.date_of_birth)) : null;
                let cardSalesforceId = associateRecords.card ? associateRecords.card.salesforce_id : '';
                let cardNumber = associateRecords.card ? associateRecords.card.card_number : '';
                setState(prevState => ({
                    ...prevState,
                    associateId: associateRecords.salesforce_id,
                    first_name: associateRecords.first_name,
                    last_name: associateRecords.last_name,
                    mobile: associateRecords.mobile,
                    email: associateRecords.email,
                    dob: dateOfBirth,
                    gender: associateRecords.gender,
                    car_reg: associateRecords.car_reg,
                    assigned_card: cardSalesforceId,
                }));
                var defaultCardObj:any = {};
                if(cardSalesforceId){
                    defaultCardObj['value'] = cardSalesforceId;
                    defaultCardObj['label'] = cardNumber;
                }
                getAvailableCards(defaultCardObj);
                //setIsFetching(false);
            }            
        }
    };
    
    const deleteAssociate = async (e) => {
        e.preventDefault();
        let associateId = e.target.dataset.id;
        confirmAlert({
            title: 'Confirm to delete',
            message: 'Are you sure to do this?',
            buttons: [
              {
                label: 'Yes',
                onClick: () => {
                    setIsFetching(true);       
                    if(associateId){
                        axios.post(`${process.env.serverUrl}delete-associate`, {associateId: associateId}).then((response) => {
                            setIsFetching(false);
                            resetForm();  
                            //console.log(response.data)
                            if(!response.data.error){
                                toast.success(response.data.message);
                                updateAssociatesList();       
                                //setvalidationErrors(null);
                                //setsuccessMessage(response.data.message); 
                            }else{
                                toast.error(response.data.message);
                                //setsuccessMessage(null);
                                //setvalidationErrors(response.data.message);
                            }   
                        });
                    }
                }
              },
              {
                label: 'No',
              }
            ]
        });
        
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
        const { name, value } = event.target;
        setState(prevState => ({
          ...prevState,
          [name]: value,
        }));
        trigger(name);
        //console.log(value)
    };
    
    const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
    var validationSchema = Yup.object().shape({
        first_name: Yup.string()
            .required('First name is required'),
        last_name: Yup.string()
            .required('Last name is required'),
        mobile: Yup.string()
            .matches(phoneRegExp, 'Mobile number is not valid')
            .required('Mobile number is required')
            /*.test('unique-mobile', function (value) {
                axios.post(`${process.env.serverUrl}is-mobile-exists`, {'mobile': value, 'associateId': associateId})
                .then(res => {
                    return this.createError({
                        path: this.path,
                        message: res.data.message,
                    });
                })
                return true
            })*/,
            //.min(10, 'Mobile number must be of 10 characters')
            //.test("is-mobile-valid", 'Mobile number is not valid', value => typeof value == 'number'),
        email: Yup.string()
            .required('Email is required')
            .email('Email is invalid'),
        dob: Yup.string()
            .required('Date of birth is required').nullable(),
    });
    var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema), };
    var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);
    
    const submitForm = () => { 
        clearErrors()   
        reset(state)
        if(!dob){
            setDobError(true)
        }
    }

    const formatDate = (date) => {    
        let dateArr = date.split('-')
        return dateArr[2]+'/'+dateArr[1]+'/'+dateArr[0];
    }

    var [linkState, setLinkState] = useState({
        assignedCard:  ''
    });

    var { assignedCard } = linkState;
    var validationLinkSchema = Yup.object().shape({
        assignedCard: Yup.string().required('Select a Corporate Card'),
    });
    var linkFormOptions = { defaultValues: linkState, resolver: yupResolver(validationLinkSchema) };
    var { register: registerLink, handleSubmit: handleSubmitLink, reset: resetLink, formState: { errors: errorsLink } } = useForm(linkFormOptions);
    
    const onSubmit = (formData:any) => {
        console.log(formData)
        setshowLoader(true); 
        axios.post(`${process.env.serverUrl}save-associate`, formData).then((response) => {
          setshowLoader(false)
          if(!response.data.error){   
            toast.success(response.data.message); 
            resetForm();     
            updateAssociatesList();       
            //setvalidationErrors(null);
            //setsuccessMessage(response.data.message);  
            getAvailableCards();
          }else{
            toast.error(response.data.message);
            //setsuccessMessage(null);
            //setvalidationErrors(response.data.message);
          }     
        });
    };
    
    const resetForm = () => {
        clearErrors();
        setDobError(false)
        getAvailableCards();    
        setState(prevState => ({
            ...prevState,
            associateId: '',
            first_name: '',
            last_name: '',
            mobile: '',
            email: '',
            dob: null,
            gender: '',
            car_reg: '',
            assigned_card: '',
        }));
    }
    
    const updateAssociatesList = async () => {    
        const res = await fetch(`${process.env.serverUrl}get-associates/${endConsumerId}`);
        let associatesList = await res.json();
        setAssociates(associatesList);
    }
    
    const onGenderChange = (
        newValue
      ) => {
        setState(prevState => ({
          ...prevState,
          gender: newValue.value,
        }));
    };
    const onCardChange = (
        newValue
      ) => {
        //console.log(newValue.value)
        setState(prevState => ({
          ...prevState,
          assigned_card: newValue.value,
        }));
    };

    const handleSearch = event => {
        setsearchText(event.target.value);
        searchKeyword(event.target.value);
    };

    const handleClearClick = event =>{
        event.preventDefault();
        setShowSearchLoader(true);
        setsearchText('');
        axios.get(`${process.env.serverUrl}get-associates/${endConsumerId}`,{}).then((response) => {            
            setAssociates(response.data);  
            setShowSearchLoader(false); 
        });
      }

    const handleSearchEnter = event => {
        event.preventDefault();
        if (event.key === 'Enter' || event.keyCode === 13) {
            searchKeyword(searchText);
        }
    };

    const onAvailableCardChange = (
        newValue
      ) => {
        //console.log(newValue.value);
        setLinkState(prevState => ({
          ...prevState,
          assignedCard: newValue.value,
        }));

        //console.log(assignedCard);
    };

    const handleClick = event => {
        event.preventDefault();
        searchKeyword(searchText);
    };

    const searchKeyword = (text) => {
        //setShowSearchLoader(true);
        const params = {
            'search': text,
            'endConsumerId': endConsumerId
        };

        axios.post(`${process.env.serverUrl}search-associates`, params, { headers: { 'content-type': 'application/json',
        } }).then((response) => {
            setAssociates(response.data); 
            //setShowSearchLoader(false);
        });
    };

    const [activeChecked, setActiveChecked] = useState(false);
    const [inactiveChecked, setInactiveChecked] = useState(false);
    const filterStatus = (e) => {
        e.preventDefault();
        //setIsFetching(true);
        let status = e.target.dataset.status;
        let queryString = '';
        if(status == "active"){
            setInactiveChecked(false);
            if(activeChecked){
                setActiveChecked(false);
            }else{
                queryString = `?status=${status}`;
                setActiveChecked(true);        
            }
        }else{
            setActiveChecked(false);
            if(inactiveChecked){
                setInactiveChecked(false);
            }else{
                queryString = `?status=${status}`;  
                setInactiveChecked(true);      
            }
        } 
        axios.get(`${process.env.serverUrl}get-associates/${endConsumerId + queryString}`,{}).then((response) => {              
            setAssociates(response.data);     
            //setIsFetching(false);
        });              
    };

    const submitLinkForm = () => {    
        resetLink(linkState)
    }

    const changeAssociateStatus = (e) => {
        e.preventDefault();
        let salesforceId = e.target.dataset.id;
        let cardId = e.target.dataset.cardid;
        let status = (e.target.dataset.status == '1') ? '0' : '1' ;
        let statusText = (e.target.dataset.status == '1') ? 'In-Active' : 'Active';
        let cardData = {
            'salesforce_id': salesforceId,
            'card_id': cardId,
            'status': status
        };

        if(e.target.dataset.status == '1')
        {
        confirmAlert({
            title: `Confirm to ${statusText}`,
            message: 'Are you sure to do this?',
            buttons: [
            {
                label: 'Yes',
                onClick: () => {
                    if(salesforceId){
                        setIsFetching(true);
                        axios.post(`${process.env.serverUrl}update-associate-status-details`, cardData).then(async (response) => {
                            setIsFetching(false);
                            if(!response.data.error){
                                toast.success(response.data.message);
                                setIsFetching(false);
                                //setsuccessMessage(response.data.message); 
                                const resp = await fetch(`${process.env.serverUrl}get-associates/${endConsumerId}`);
                                const associateInfo = await resp.json() 
                                setAssociates(associateInfo);  
                            }else{
                                toast.error(response.data.message);
                                //setsuccessMessage(null);
                            } 
                            /*axios.get(`${process.env.serverUrl}get-associates/${endConsumerId}`,{}).then((response) => {            
                                setAssociates(response.data);  
                                setShowSearchLoader(false); 
                            });*/
                        });
                    }
                }
            },
            {
                label: 'No',
            }
            ]
        });

        }
        else
        {   
            //console.log(salesforceId);
            setAssociate(salesforceId);
            handleShow(); 
        }
    }

    const cancelLinkForm = (e) => {
        e.preventDefault();
        setShow(false);
        setLinkState(prevState => ({
            ...prevState,
            assignedCard: '',
        }));
    }

    const onLinkCardSubmit = (formData:any) => {
        setshowLoader(true);
        formData.assigned_card = formData.assignedCard;  
        axios.post(`${process.env.serverUrl}link-corporate-cards`, formData).then( async (response) => {
          
          setshowLoader(false)
          if(response.data.status == '1'){
            const resp = await fetch(`${process.env.serverUrl}get-associates/${endConsumerId}`);
            const associateInfo = await resp.json()  
            //console.log(associateInfo)
            setAssociates(associateInfo);  
            //setShowSearchLoader(false); 
            toast.success(response.data.message);
            //setsuccessMessage(response.data.message);
            handleClose(); 
            //setvalidationErrors(null);
            /*axios.get(`${process.env.serverUrl}get-associates/${endConsumerId}`,{}).then((response) => {
                console.log(response.data)
                setAssociates(response.data);  
                //setShowSearchLoader(false); 
                setsuccessMessage(response.data.message);
                handleClose(); 
                setvalidationErrors(null);
            });*/
          }else{ 
            toast.error(response.data.message);  
            //setsuccessMessage(null);
            //setvalidationErrors(response.data.message);
          }        
        });
    };

  return (
    <section className={styles.mainDash}>
        {
            isFetching ? <LoadingScreen /> : ''
        }
        <SEO title="Associates">
            <meta id="meta-description" name="description" content="" />
            <meta id="meta-keywords" name="keywords" content="" />
        </SEO>
      {/* ====================== top section start ======================= */}
          <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
                <MemberMenu/>
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                      <Col sm={12}>
                          <h2>Associate Portal { associateId ? <Link legacyBehavior href="#"><a onClick={resetForm}>Add New Associate</a></Link> : '' }</h2>
                         </Col> 
                    </Row>
                  </Container>
                  {/* ===================Create New Associates================= */}
                      <section className={styles.CommonContainer}>
                          <Container className={styles.DashContainer}>
                              <Row>
                                  <Col sm={8}>
                                      <div className={styles.Associates}>
                                            {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                                            
                                          <h2>Associates</h2>
                                          <div className={styles.searchBox}>
                                              <input type="text" name="searchText" onChange={handleSearch} value={searchText} onKeyUp={handleSearchEnter} />
                                              {searchText && <a onClick={handleClearClick} className={styles.searchClearBtn}><Icon.XCircle/></a> }
                                              
                                                <Button color="primary"
                                                    variant="contained"
                                                    type="button"
                                                    onClick={handleClick} 
                                                    disabled={showSearchLoader} >
                                                    { showSearchLoader ? <Loader /> : null } Search
                                                </Button>
                                          </div>
                                          <div className={styles.filTerby}>
                                              <label>Filter By</label>
                                              <button className={activeChecked ? styles.ButtonActive +' '+ styles.selected : styles.ButtonActive} onClick={filterStatus} data-status="active">Active</button>
                                              <button className={inactiveChecked ? styles.ButtonInActive +' '+ styles.selected : styles.ButtonInActive} onClick={filterStatus} data-status="inactive">In-Active</button>
                                          </div>
                                          <div className={styles.AssociatesList}>
                                            <dl>
                                                {associates.length ? (associates.map((associate:any) => (
                                                    <dt key={associate.id}>
                                                        <div className={styles.AssocName}>
                                                            <Link legacyBehavior href={`/associate-details/${associate.salesforce_id}`}><a>{associate.name}</a></Link>
                                                        </div>
                                                        <div className={styles.AssocPhone}>
                                                            <Link legacyBehavior href={`/associate-details/${associate.salesforce_id}`}><a><Icon.TelephoneFill/> {associate.mobile}</a></Link>
                                                        </div>
                                                        <div className={styles.AssocDate}>
                                                            <Link legacyBehavior href={`/associate-details/${associate.salesforce_id}`}><a><Icon.Calendar3/>{formatDate(associate.date_of_birth)}</a></Link>
                                                        </div>
                                                        <div className={styles.AssocId}>
                                                            {associate.card ? 
                                                            <><Link legacyBehavior href={`/associate-details/${associate.salesforce_id}`}><a><Icon.CardHeading/>{associate.card.card_number}</a></Link></> 
                                                            : ''}
                                                        </div>
                                                        <div className={styles.AvailableCredit}>
                                                            <Link legacyBehavior href={`/associate-details/${associate.salesforce_id}`}><a>Available Credit <strong>${associate.card ? parseFloat(associate.card.available_credit).toFixed(2) : (0).toFixed(2)}</strong></a></Link>
                                                        </div>
                                                        <div className={(associate.status == '1') ? styles.AssocButton : styles.AssocButtonIn}>

                                                            <Link legacyBehavior href="#"><a className={associate.status == '1' ? styles.ActiveButton : styles.InActiveButton} onClick={changeAssociateStatus} data-id={associate.salesforce_id} data-cardid={associate.card_id} data-status={associate.status}>{associate.status == '1' ? 'Active' : 'In-Active'}</a></Link>
                                                        </div>
                                                        <div className={styles.EditRemove}>
                                                            <Link legacyBehavior href="#"><a onClick={editAssociate} data-id={associate.salesforce_id}>Edit</a></Link> /<Link legacyBehavior href="#"><a onClick={deleteAssociate} data-id={associate.salesforce_id}>Delete</a></Link>
                                                        </div>
                                                    </dt>
                                                ))) : ( 
                                                    <p>No associates found</p>
                                               )}                                                
                                            </dl>

                                            <Modal show={show} onHide={handleClose} className={styles.commonModal}>
                                                <Modal.Header closeButton className={styles.topModal}>
                                                    <Modal.Title className={styles.ModelTitle}><div>Assign <span>Corporate Card</span></div></Modal.Title>
                                                </Modal.Header>
                                                <Modal.Body>
                                                    <section className={styles.CorporateCardForm}>
                                                    <form id="linkForm" className='link-form' onSubmit={handleSubmitLink(onLinkCardSubmit)}>
                                                        <div className={styles.formGroup}>
                                                            <label>Selected Source Corporate Card</label>
                                                            <Select options={cards} {...registerLink('assigned_card')} onChange={onAvailableCardChange} value={cards.find(item => item.value === assignedCard) || ''}/>
                                                            <div className="invalid-feedback">{errorsLink.assigned_card?.message?.toString()}</div>
                                                        </div>
                                                        <div className={styles.submitButton}>
                                                            <input type="hidden" {...registerLink('associateId')} value={associate} />
                                                            <Button color="primary"
                                                                variant="contained"
                                                                type="submit"
                                                                onClick={submitLinkForm}
                                                                className={styles.Transfer} 
                                                                disabled={showLoader} >
                                                                { showLoader ? <Loader /> : null } <Icon.Link/> Link
                                                            </Button>
                                                            <Button
                                                                variant="contained"
                                                                type="button"
                                                                onClick={cancelLinkForm}>
                                                                    Cancel
                                                            </Button>
                                                        </div>
                                                    </form>    
                                                    </section>
                                                </Modal.Body>
                                            </Modal>

                                          </div>
                                      </div>
                                  </Col>
                                  <Col sm={4}>
                                      <section className={styles.AssocForm}>
                                          <h3>
                                              <Icon.PersonCircle/>
                                              <span>{ associateId ? 'Update' : 'Create a New'} Associate</span>
                                          </h3>
                                          {/*<AssociateForm dataVal={state}/>*/}
                                          <form id="associateForm" className='associate-form member-associate-form form-container-com' onSubmit={handleSubmit(onSubmit)}>
                                            <div className={styles.formCoantainer}>
                                                <div className={styles.formgroup}>
                                                    <label>First Name</label>
                                                    <input type="text" {...register('first_name', {onChange: handleChange})} value={first_name}  className={`form-control ${errors.first_name ? 'is-invalid' : (first_name ? 'is-valid' : '')}`}/>
                                                    <div className="invalid-feedback">{errors.first_name?.message?.toString()}</div>
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Last Name</label>
                                                    <input type="text" {...register('last_name', {onChange: handleChange})} value={last_name} className={`form-control ${errors.last_name ? 'is-invalid' : (last_name ? 'is-valid' : '')}`} />
                                                    <div className="invalid-feedback">{errors.last_name?.message?.toString()}</div>
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Mobile Number</label>
                                                    <PhoneInput className={`form-control ${(mobile && isNaN(parseInt(mobile)) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( !isNaN(parseInt(mobile)) && mobile.replace(/\D/g, '').length == 10 ? 'is-valid' : '')}`} value={mobile} {...register('mobile', {onChange: handleMobileInput})}>
                                                    </PhoneInput>
                                                    <div  className={`invalid-feedback ${(mobile && isNaN(parseInt(mobile)) || (errors.mobile && !mobile) || (errors.mobile && mobile && mobile.replace(/\D/g, '').length < 10)) ? 'is-invalid' : ( mobile.length == 10 ? 'is-valid' : '')}`}>{(errors.mobile && !mobile || mobile.replace(/\D/g, '').length < 10 || isNaN(parseInt(mobile))) ? errors.mobile?.message?.toString() : ''}</div>
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Email Address</label>
                                                    <input type="text" {...register('email', {onChange: handleChange})} value={email} className={`form-control ${errors.email ? 'is-invalid' : (email ? 'is-valid' : '')}`} />
                                                    <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Date of Birth</label>
                                                    <DatePicker {...register('dob')} className={`form-control ${dobError ? 'is-invalid' : (dob ? 'is-valid' : '')}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={handleDateInput} value={dob}  />
                                                    {/*customInput={<InputMask mask="99/99/9999" placeholder="dd/mm/yyyy" />}*/}
                                                    <div className="invalid-feedback">{dobError ? errors.dob?.message?.toString() : ''}</div>
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Gender</label>
                                                    <Select options={genderOptions} value={genderOptions.find(item => item.value === gender) || ''} {...register('gender')} onChange={onGenderChange} className={`form-control form-select ${gender ? 'is-valid' : ''}`}/>  
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Car Registration</label>
                                                    <input type="text" {...register('car_reg', {onChange: handleChange})} value={car_reg} className={`form-control ${car_reg ? 'is-valid' : ''}`} />
                                                </div>
                                                <div className={styles.formgroup}>
                                                    <label>Assign a Corporate Card</label>
                                                    <Select options={cards} value={cards.find(item => item.value === assigned_card) || ''} {...register('assigned_card')} onChange={onCardChange} className={`form-control form-select ${assigned_card ? 'is-valid' : ''}`}/>
                                                    
                                                    {/*<select {...register('assigned_card')} value={`${assigned_card ? assigned_card : ''}`} onChange={handleStatusChange} >
                                                        <option value="">Select</option>
                                                        {dataCards.map((card:any) => (
                                                        <option value={card.id}>{card.Display_Card_Number__c}</option>
                                                        ))}
                                                        </select>*/}
                                                </div>
                                                <div className={styles.formgroup}>
                                                    {/*<div className={styles.AddMoreFields}> <input type="checkbox" /> Add More Fields</div>*/}
                                                </div>
                                                <div className={styles.submitButton}>
                                                    <input type="hidden" {...register('id')} value={associateId} />
                                                    <input type="hidden" {...register('end_consumer_id')} value={endConsumerId} />
                                                    <Button color="primary"
                                                        variant="contained"
                                                        type="submit"
                                                        onClick={submitForm} 
                                                        disabled={showLoader} >
                                                        { showLoader ? <Loader /> : null } { associateId ? 'Update' : 'Create'}
                                                    </Button>
                                                    {
                                                        associateId ?
                                                        <Button
                                                        variant="contained"
                                                        type="button"
                                                        onClick={resetForm} >
                                                            Cancel
                                                        </Button>
                                                        : ''
                                                    }
                                                </div>
                                            </div>
                                            
                                        </form>                                          
                                      </section>
                                  </Col>
                              </Row>
                            </Container>
                      </section>
                  {/* ===================Create New Associates end================= */}
                 
                 
              </section>
            {/* ================dashboard right container end================== */}


           

        </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
          <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
};
export default Associates;

