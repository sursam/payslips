import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import PaymentInvoice from "../../components/PaymentInvoice";

export default function Test() { 
  const [endConsumerId, setEndConsumerId] = useState('a5x9n0000000UXZAA2');
  const [transactionId, setTransactionId] = useState('a619n000000ahb7AAA');
  const [logoInfo, setLogoInfo] = useState('');
  const [endConsumerInfo, setEndConsumerInfo] = useState({});
  const [transactionInfo, setTransactionInfo] = useState({});
  useEffect(() => {
    generateInvoicePdf(endConsumerId, transactionId);
  }, 
  [])
  const generateInvoicePdf = async (endConsumerId, transactionId) => {
    const settingsResponse = await fetch(`${process.env.serverUrl}site-settings/`);
    const settingsData = await settingsResponse.json();
    setLogoInfo(settingsData.logo);
    const endConsumerResponse = await fetch(`${process.env.serverUrl}get-endconsumer-db-data/${endConsumerId}`);
    const endConsumerData = await endConsumerResponse.json();
    setEndConsumerInfo(endConsumerData);
    const transactionResponse = await fetch(`${process.env.serverUrl}get-transaction-details/${transactionId}`);
    const transactionData = await transactionResponse.json();
    setTransactionInfo(transactionData);    
  }
  return (
    <section className={styles.mainDash}>
        <section className={styles.MainContainer}>
          {(Object.keys(transactionInfo).length && Object.keys(endConsumerInfo).length && logoInfo) ?
            <PaymentInvoice logoInfo={logoInfo} endConsumerInfo={endConsumerInfo} transactionInfo={transactionInfo} />    
          : ''}                                            
        </section>
    </section>
  );
}




