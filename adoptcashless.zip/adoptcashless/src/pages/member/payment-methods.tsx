import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../components/SEO';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";
import Link from 'next/link';
import * as Icon from 'react-bootstrap-icons';
import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberFooter from "../../components/Front/Footer/MemberFooter";
import axios from "axios";
import GlobalContext from '../../components/GlobalContext';
import { Elements, useStripe, useElements, PaymentElement } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import PaymentForm from "../../components/RechargePanel/PaymentForm";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import LoadingScreen from "../../components/loadingScreen";
import PaymentSource from "../../components/PaymentSource";
//import Col from '@paljs/ui/Col';

export default function PaymentMethods(props) {
  const [showAddCard, setShowAddCard] = useState(false);
  const [showAddBank, setShowAddBank] = useState(false);
  const [listPaymentSources, setListPaymentSources] = useState({});
  const [showAccountLoader, setShowAccountLoader] = useState(true);
  const { stripeCreds } = useContext(GlobalContext);
  const stripePromise = loadStripe(stripeCreds.publishableKey);
  const [cardOptions, setCardOptions] = useState({});
  const [bankOptions, setBankOptions] = useState({});
  //const [clientSecret, setClientSecret] = useState('');
  const [isFetching, setIsFetching] = useState(false);
  
  const [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '',
    backupItem: Array(),
    primaryItem: ''
  });
  const { endConsumerId, backupItem, primaryItem} = state;

  useEffect(() => {    
    listSources();  
    axios.get(`${process.env.serverUrl}get-endconsumer-selected-sources/${endConsumerId}`,{}).then((response) => {
      const bckItem:any = [];
      response.data.forEach((paymentSource, k):any => {
          switch(paymentSource.account_type){
            case 'primary':
              setState(prevState => ({
                ...prevState,
                primaryItem: paymentSource.source_id
              }));
              break;
            case 'backup':
              bckItem.push(paymentSource.source_id);
              break;
          }
      });
      setState(prevState => ({
        ...prevState,
        backupItem: bckItem
      }));
    });  
    loadPaymentForm(endConsumerId, 'card'); 
    loadPaymentForm(endConsumerId, 'bank'); 
  }, 
  [])


  const loadPaymentForm = (endConsumerId, type) => {
    axios.get(`${process.env.serverUrl}get-stripe-client-secret/${endConsumerId}/?type=${type}`,{}).then((response) => {
      //setClientSecret(response.data.client_secret);
      const appearance = {
        theme: 'stripe',
      };
      switch(type){
        case 'card': 
          setCardOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
        case 'bank': 
          setBankOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
      }      
    });
  }
  const listSources = () => {
    axios.get(`${process.env.serverUrl}get-endconsumer-account-sources/${endConsumerId}`,{}).then((response) => {
      setListPaymentSources(response.data);
      setShowAccountLoader(false);
    });
  }

  const onClickAddCard = (e) => {
    e.preventDefault();
    setShowAddBank(false);
    setShowAddCard(true);
  }
  const onClickAddBankAccount = (e) => {
    e.preventDefault();
    setShowAddCard(false);
    setShowAddBank(true);
  }
  const onViewSourceList = (e) => {
    e.preventDefault();
    setShowAddCard(false);
    setShowAddBank(false);
  }

  var validationSchema = Yup.object().shape({});

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData) => {
    console.log(formData)
    setIsFetching(true);
    axios.post(`${process.env.serverUrl}setup-payment-methods`, formData).then((response) => {
      if(!response.data.error){
        setIsFetching(false);
        toast.success(response.data.message);
        console.log(response.data);
      }else{
        toast.error(response.data.message);
      }        
    });
  };

  /*const viewSource = (itemId:any) => { 
    [].forEach.call(document.querySelectorAll('.source_details'), function (el:any) {
      el.classList.remove("show");
    });
    var popup:any = document.querySelector('#source_details_'+itemId);
    popup.classList.toggle("show");
  }
  const closeSource = () => { 
    [].forEach.call(document.querySelectorAll('.source_details'), function (el:any) {
      el.classList.remove("show");
    });
  }*/

  const deletePaymentSource = (sourceId) => {
    confirmAlert({
        title: 'Confirm to delete',
        message: 'Are you sure to do this?',
        buttons: [
          {
            label: 'Yes',
            onClick: () => {
                setIsFetching(true);       
                if(sourceId){
                    axios.post(`${process.env.serverUrl}delete-rfid-card`, {sourceId: sourceId}).then((response) => {
                        setIsFetching(false);
                        //console.log(response.data)
                        if(!response.data.error){
                            toast.success(response.data.message);
                            listSources();  
                        }else{
                            toast.error(response.data.message);
                        }   
                    });
                }
            }
          },
          {
            label: 'No',
          }
        ]
    });    
  };

  const setSourceItem = (e) => {
    e.preventDefault();
    const sourceId = e.currentTarget.getAttribute("data-source");
    const sourceType = e.currentTarget.getAttribute("data-type");
    //const sourceItem:any = document.querySelector('#sourceItem_'+sourceId);
    const bckItem:any = backupItem;
    const bckIndex = bckItem.indexOf(sourceId);
    if(sourceType == 'primary'){
      if (bckIndex > -1) {
        bckItem.splice(bckIndex, 1); 
      }
      setState(prevState => ({
        ...prevState,
        primaryItem: sourceId
      }));
    }
    if(sourceType == 'backup'){
      if (bckIndex == -1) {
        bckItem.push(sourceId);
        setState(prevState => ({
          ...prevState,
          backupItem: bckItem
        }));
      }
    }
  }

  /*const unsetSourceItem = (e) => {
    e.preventDefault();
    const sourceId = e.currentTarget.getAttribute("data-source");
    const bckItem:any = backupItem;
    const bckIndex = bckItem.indexOf(sourceId);
    bckItem.splice(bckIndex, 1); 
    setState(prevState => ({
      ...prevState,
      backupItem: bckItem
    }));
  }*/
  
  return (
    <section className={styles.mainDash}>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      <SEO title="Payment Methods">
        <meta id="meta-description" name="description" content="Payment Methods" />
        <meta id="meta-keywords" name="keywords" content="Payment Methods" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}> 
        <div className='paymentContainerPart'>
          <div className={styles.paymentMethods}>
            <div className={styles.CheckOutPart}>
              <div className={styles.cardDetails}>
                <div className={styles.DashContainer}>
                  <Container className={styles.paymentContainer}>
                    
                    <Row className={styles.paymentRow}>
                      <Col sm={6}>
                        <div className={styles.PaymentLeft}>
                          <div className={styles.infoContainer}>
                            <span className={styles.BackLink}><Link legacyBehavior href={"/dashboard"}><a className={styles.BackBtn}><Icon.ArrowLeft/></a></Link></span>                  
                            <h2>Payment Details</h2>      
                          </div>
                        </div>
                      </Col>
                      <Col sm={6}>
                        <div className={styles.PaymentRight}>
                          <div className={`cardSection auto_recharge_card ${styles.SourcePanel}`}>            
                            <div className='sourceListHead'>
                                <h2>Preferred Payment Method</h2>
                            </div>
                            <PaymentSource />
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Container>
                </div>
              </div>
            </div> 
          </div> 
        </div>           
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}