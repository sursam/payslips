import React, {useState, useContext, useEffect} from 'react';
import styles from '../../styles/Login.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import SEO from '../../components/SEO';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Index() {  

  //const [validationErrors, setvalidationErrors] = useState(null);
  //const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const router = useRouter();
  const [code, setCode] = useState("");

  var validationSchema = Yup.object().shape({
    password: Yup.string().required('Password is required'),
    confirmpassword: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords does not matched'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  useEffect(() => {

    const search = window.location.search;
    const params = new URLSearchParams(search);
    const activation_code:any = params.get('data');

    const getcode = () => {
      setCode(activation_code);
    };

    getcode();

    const param = {
      'verificationcode': params.get('data'),
    };

      const authenticationStatus = async() => 
      {
        axios.post(`${process.env.serverUrl}verification-email-code`, param, { headers: { 'content-type': 'application/json',
      } }).then((response) => {
          
        if(response.data.status == 1)
        {
          //setvalidationErrors(null);
          //setsuccessMessage(response.data.message);
          toast.success(response.data.message);
        }
        else
        {
          toast.error(response.data.message);
          //setsuccessMessage(null);
          //setvalidationErrors(response.data.message);
          setTimeout(() => router.push(response.data.req));
        }

        });
      } 
      authenticationStatus();

    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  
  [])

  const onSubmit = (formData:any) => {
    setshowLoader(true); 
    axios.post(`${process.env.serverUrl}member-reset-password`, formData).then((response) => {
      setshowLoader(false)
      if(response.data.status == 1){
        toast.success(response.data.message);
        //setvalidationErrors(null);
        //setsuccessMessage(response.data.message);  
        reset();
        setTimeout(() => router.push('/login'), 4000);
      }else{
        toast.error(response.data.message);
        //setsuccessMessage(null);
        //setvalidationErrors(response.data.message);
      }        
    });
  };

  return (
    <section className={styles.LoginMainContainer}>
      <SEO title="Reset Password">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
{/* =============sign up form section================== */}
  <section className={styles.LoginForm}>
      <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                    <div className={styles.LoginFormBox}>
                        <h2>
                            <img src={'/assets/images/reset-password-icon.png'} />
                            <span>Set New Password</span>
                        </h2>
                        <div className={styles.ErrorSummary}>
                            {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                            <ToastContainer
                                position="top-right"
                                autoClose={10000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable
                                pauseOnHover
                                theme="light"
                            />
                        </div>
                        <form className='enquiry-form' onSubmit={handleSubmit(onSubmit)}>
                          <Row>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                      New Password
                                    </label>
                                    <input type="password" {...register('password')} className={`form-control ${errors.password ? 'is-invalid' : ''}`} autoComplete ="off" />
                                    <div className="invalid-feedback">{errors.password?.message}</div>
                                </div>
                              </Col>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                      Re-Enter the New Password
                                    </label>
                                    <input type="password" {...register('confirmpassword')}  className={`form-control ${errors.confirmpassword ? 'is-invalid' : ''}`} autoComplete ="off" />
                                    <div className="invalid-feedback">{errors.confirmpassword?.message}</div>
                                </div>
                              </Col>
                              </Row> 
                          <Row>
                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                              <input type="hidden" {...register('code')} value={code} />
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Change Password </Button>
                                </div>
                            </Col>
                          </Row>
                        </form>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
<div className="footerContainer">
        © 2022 All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}