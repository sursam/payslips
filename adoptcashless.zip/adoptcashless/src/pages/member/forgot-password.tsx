import React, {useState, useContext, useEffect} from 'react';
/*import Header from "components/Front/Header/Header";
import Footer from "components/Front/Footer/Footer";*/
import styles from '../../styles/Login.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
//import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import "react-datepicker/dist/react-datepicker.css";
import { useRouter } from 'next/router';
import Link from 'next/link';
import SEO from '../../components/SEO';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import PhoneInput from '../../components/PhoneInput';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

//import * as Icon from 'react-bootstrap-icons';
export default function Index() {  

  //const { serverUrl } = useContext(GlobalContext);
  //const [validationErrors, setvalidationErrors] = useState(null);
  //const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [logo, setLogo] = useState([]);
  const [state] = useState({});
  const [dob, setDob] = useState('');
  const router = useRouter();

  var validationSchema = Yup.object().shape({
    email: Yup.string().required('Email address is required'),
    mobile: Yup.string().required('Mobile number is required'),
    dateofbirth: Yup.string().required('Date of birth is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const [mobile, setMobile] = useState('');
  const handleMobileInput = ({ target: { value } }:any) => setMobile(value);

  useEffect(() => {
    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
        });
      } 
      getlogo();
  },   
  
  [])

  const onSubmit = (formData:any) => {
    setshowLoader(true); 
    axios.post(`${process.env.serverUrl}member-forgot-password`, formData).then((response) => {
      setshowLoader(false)
      if(response.data.status == 1){
        //setvalidationErrors(null);
        //setsuccessMessage(response.data.message);  
        toast.success(response.data.message);
        reset();
        setTimeout(() => router.push('/login'), 4000);

      }else{
        //setsuccessMessage(null);
        //setvalidationErrors(response.data.message);
        toast.error(response.data.message);
      }        
    });
  };

  return (
    <section className={styles.LoginMainContainer}> 
      <SEO title="Forgot Password">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
    {/* =============sign up form section================== */}
    <section className={styles.LoginForm}>
    <div className={styles.pageLogo}><Link legacyBehavior href={"/"}><a><img src={`/uploads/logo/${logo}`} alt="" /></a></Link></div>
        <Container fluid>
            <Row>
              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                  <div className={styles.LoginFormBox}>
                        <h2>
                            <img src={'/assets/images/login-icon.png'} />
                            <span>Reset Your Password</span>
                        </h2>

                        <div className={styles.ErrorSummary}>
                            {/*<ErrorSummary errors={validationErrors} success={successMessage} />*/}
                            <ToastContainer
                                position="top-right"
                                autoClose={10000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable
                                pauseOnHover
                                theme="light"
                            />
                        </div>

                        <form className='enquiry-form forgot-password' onSubmit={handleSubmit(onSubmit)}>
                          <Row>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                      Registered Email Address
                                    </label>
                                    <input type="email" {...register('email')} className={`form-control ${errors.email ? 'is-invalid' : ''}`} autoComplete ="off" />
                                    <div className="invalid-feedback">{errors.email?.message}</div>
                                </div>
                              </Col>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                    Registered Mobile Number
                                    </label>
                                    <PhoneInput className={`form-control ${errors.mobile ? 'is-invalid' : ''}`}
                                                value={mobile} 
                                                onChange={handleMobileInput}>
                                    </PhoneInput>
                                    <input type="hidden" {...register('mobile')} value={mobile}/>
                                    <div className="invalid-feedback">{errors.mobile?.message}</div>
                                </div>
                              </Col>
                              <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.formgroup}>
                                    <label>
                                        Date Of Birth of the Registered User
                                    </label>
                                    <DatePicker className={`form-control ${errors.dateofbirth ? 'is-invalid' : ''}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown dropdownMode="select" onChange={dob => setDob(dob)} value={dob}  />
                                    <input type="hidden" {...register('dateofbirth')} value={dob}/>
                                    <div className="invalid-feedback">{errors.dateofbirth?.message}</div>
                                </div>
                              </Col>
                              </Row> 
                          <Row>
                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div className={styles.SubmitButton}>
                                <Button color="primary" variant="contained" type="submit" onClick={submitForm} disabled={showLoader} >{ showLoader ? <Loader /> : null } Retrieve Your Password Now </Button>
                                </div>
                            </Col>
                          </Row>

                        </form>
                        <div className={styles.loginAlt}>Already have an account? <Link legacyBehavior href={"/login"}>sign in</Link> </div>
                    </div>
                </Col>
            </Row>
        </Container>
    </section>
{/* =============sign up form section end================== */}
{/* ================ footer container part ==================== */}
<div className="footerContainer">
        © 2022 All Rights Reserved by Tap N Go Pty Ltd
  </div>
{/* ================ footer container part end==================== */}
    </section>
  );
}