import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
//import io from 'socket.io-client';
import SEO from '../../../components/SEO';
import { useRouter } from 'next/router';
import Button from 'react-bootstrap/Button';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import Loader from '../../../components/loader';
import { useForm } from 'react-hook-form';
import MemberHeader from "../../../components/Front/Header/MemberHeader";
import MemberMenu from "../../../components/Front/Header/MemberMenu";
import MemberFooter from "../../../components/Front/Footer/MemberFooter";

export async function getServerSideProps({ query }:any) {
  const resp = await fetch(`${process.env.serverUrl}get-support-case-details/${query.id}`);
  const caseInfo = await resp.json()
  return {
    props: {caseInfo},
  }
}

const SupportCase = ({caseInfo}:any) => {

  const router = useRouter();
  const [showLoader, setshowLoader] = useState(false);
  var [chatHistory, setChatHistory] = useState([]);
  
  const markAsResolved = (e) => {
      let caseId = e.target.dataset.id;

      axios.get(`${process.env.serverUrl}support-case-status/${caseId}`,{}).then((response) => {  
        router.replace(router.asPath)
    });
  }

  useEffect(() => {
    axios.get(`${process.env.serverUrl}get-support-chat-history/${caseInfo.case_id}`,{}).then((response) => { 
      //console.log(response.data);
        setChatHistory(response.data);
      }); 
  }, 
[])

  var [state, setState] = useState({
    message: ''
  });

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
};

  var validationSchema = Yup.object().shape({
    message: Yup.string().required('Message is required'),
  });

var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

const submitForm = () => {    
  reset(state)
}

  const sendMessage = (formData:any) => {
    setshowLoader(true); 
    console.log(formData); 
    axios.post(`${process.env.serverUrl}save-associate`, formData).then((response) => {
      setshowLoader(false)
      console.log(1);     
    });
};


  return (
    <section className={styles.mainDash}>
      <SEO title="Support Case">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
        <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
        <section className={styles.MainContainer}>
            {/* ================left dashboard menu list================== */}
              <MemberMenu/>   
            {/* ================left dashboard menu list end================== */}
            {/* ================dashboard right container================== */}
              <section className={styles.DashboardRight}>
                  <Container className={styles.DashContainer}>
                    <Row>
                        <Col sm={12}>
                            <h2>Support Case</h2>
                        </Col> 
                    </Row>
                  </Container>

                  {/* ===================Create New Associates================= */}
                      <section className={styles.CommonContainer}>
                          <Container className={styles.DashContainer}>
                              <Row>
                                {caseInfo.status !=0 &&   
                                  <Col xs={12} sm={6} md={5} lg={5} xl={4} xxl={4}>
                                  <section className={styles.AssocForm}>
                                          <h3>
                                              <Icon.PersonCircle/>
                                              <span>Add Comments</span>
                                          </h3>

                                          <div className={styles.formCoantainer}>
                                             <div className="formComments">
                                                <div className={styles.formgroup}>
                                                    <label>Message</label>
                                                    <textarea name="" id="" ></textarea>
                                                </div>
                                                <div className={styles.formgroup}>
                                                   <div className="AttachFiles">
                                                      <input type="file" />
                                                      <Icon.Link45deg />  Attach Files
                                                   </div>
                                                </div>
                                                <div className={styles.submitButton}>
                                                    <input type="submit" value="Comment" />
                                                </div>
                                            </div>
                                          </div>
                                      </section>
                                  </Col>
                                  }
                                  <Col xs={12} sm={6} md={7} lg={7} xl={8} xxl={8}>
                                      <section className="supportCases">
                                        <div className='supportCasesTop'>
                                          <h3>Support Case {caseInfo.status !=0 && <a href="#" data-id={caseInfo.case_id} onClick={markAsResolved} className="MarkResolved">Mark as Resolved</a>} </h3>
                                          <div className="CaseId">
                                              Case {caseInfo.case_id}
                                          </div>
                                         </div>
                                         {/* ============ support list ============= */}
                                            <div className="chatBoxMain">

                                              <div className="supportList">
                                                
                                                {chatHistory.map((history:any) => (
                                                  <ul>
                                                    <li className="dateBox"><span>December 22, 2022</span></li>
                                                    <li>
                                                      <div className="CommentBox ClientEnd">
                                                      <figure>
                                                          <a href="#">
                                                              <img src='/assets/images/user-image.jpg' alt="" />
                                                          </a>
                                                      </figure>
                                                        <div className="chatContent">
                                                            <p>Good Morning Sir.</p>
                                                            <div className="messTime">12:15</div>
                                                        </div>
                                                      </div>
                                                    </li>

                                                    <li>
                                                      <div className="CommentBox">
                                                      <figure>
                                                          <a href="#">
                                                              <img src='/assets/images/chat-client.jpg' alt="" />
                                                          </a>
                                                      </figure>
                                                        <div className="chatContent">
                                                            <p>We specialise in providing businesses with a complete cashless solution accepting payments from majority of payment providers in Australia. Our goal is to assist businesses.</p>
                                                            <div className="messTime">12:20</div>
                                                        </div>
                                                      </div>
                                                    </li>
                                                    </ul>
                                                  ))}
                                                 
                                              </div>

                                              {caseInfo.status !=0 &&
                                              <form className='enquiry-form' onSubmit={handleSubmit(sendMessage)}>
                                                <div className="commentForm">
                                                    <input type="text" {...register('message')} placeholder='Type your message...' onChange={handleChange} className={`${errors.first_name ? 'is-invalid' : ''}`} autoComplete="off"/>
                                                    <div className="invalid-feedback">{errors.message?.message}</div>
                                                    <div className="buttonActionContainer">
                                                        <div className="emojionearea">
                                                            <Icon.EmojiSmile />
                                                            <div className="sendMess">
                                                            <Button color="primary"
                                                            variant="contained"
                                                            type="submit"
                                                            onClick={submitForm} 
                                                            disabled={showLoader} >
                                                            { showLoader ? <Loader /> : null } <Icon.CursorFill />
                                                            </Button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>
                                              }
                                            </div>

                                         {/* ============ support list end============= */}
                                      </section>
                                  </Col>
                              </Row>
                            </Container>
                      </section>
                  {/* ===================Create New Associates end================= */}
            
              </section>
            {/* ================dashboard right container end================== */}

        </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
        <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}
export default SupportCase;