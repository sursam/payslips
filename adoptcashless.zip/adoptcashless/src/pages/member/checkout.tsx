import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Dashboard.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import SEO from '../../components/SEO';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PhoneInput from '../../components/PhoneInput';
import "react-datepicker/dist/react-datepicker.css";
import { Button } from "@material-ui/core";
import Link from 'next/link';
import * as Icon from 'react-bootstrap-icons';
import MemberHeader from "../../components/Front/Header/MemberHeader";
import MemberFooter from "../../components/Front/Footer/MemberFooter";

import { Elements, useStripe, useElements, PaymentElement } from "@stripe/react-stripe-js";
import GlobalContext from '../../components/GlobalContext';
import { loadStripe } from "@stripe/stripe-js";
import RechargeForm from "../../components/RechargePanel/RechargeForm";
import axios from "axios";
import { useRouter } from 'next/router';

export default function Checkout() {
  const router = useRouter();
  let endConsumerId = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
  const [paymentObj, setPaymentObj]:any = useState({});  
  const [paymentOptions, setPaymentOptions] = useState({});
  const { stripeCreds } = useContext(GlobalContext);
  const stripePromise = loadStripe(stripeCreds.publishableKey);
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    loadPaymentForm(endConsumerId, 'all');
    let storageObj = (typeof localStorage !== 'undefined' && localStorage.getItem(`checkout_${endConsumerId}`)) || '';
    if(storageObj){
      setPaymentObj(JSON.parse(storageObj));
    }
  }, 
  [])
  
  const loadPaymentForm = (endConsumerId, type) => {
    axios.get(`${process.env.serverUrl}get-stripe-client-secret/${endConsumerId}/?type=${type}`,{}).then((response) => {
      setClientSecret(response.data.client_secret);
      const appearance = {
        theme: 'stripe',
      };
      setPaymentOptions({
        clientSecret: response.data.client_secret,
        appearance: appearance,
      });     
    });
  }
  const redirectToUrl = (url) => {
    router.push(url);
  }
  
  return (
    <section className={styles.mainDash}>
      <SEO title="Checkout">
        <meta id="meta-description" name="description" content="" />
        <meta id="meta-keywords" name="keywords" content="" />
      </SEO>
      {/* ====================== top section start ======================= */}
      <MemberHeader/>
      {/* ====================== top section end ======================= */}
      {/* ====================== main container part ======================= */}
      <section className={styles.MainContainer}>
        <div className={styles.CheckOutPart}>
          <div className={styles.cardDetails}>
            <div className={styles.DashContainer}>
              <Container className={styles.paymentContainer}>              
                <Row className={styles.paymentRow}>
                  <Col sm={6}>
                    <div className={styles.PaymentLeft}>
                      <div className={styles.infoContainer}>
                        <span className={styles.BackLink}><Link legacyBehavior href={"/dashboard"}><a className={styles.BackBtn}><Icon.ArrowLeft/></a></Link></span>                  
                        <h2>Recharge</h2>
                        <h4>
                          Type: {paymentObj.rechargeProcedure}
                          <br/>
                          Recharge Value: ${parseFloat(paymentObj.rechargeVal).toFixed(2)}
                          <br/>
                          Surcharge: ${parseFloat(paymentObj.surchargeVal).toFixed(2)}
                        </h4> 
                        <div className={styles.totalAmountText}>${parseFloat(paymentObj.grandTotal).toFixed(2)}</div>
                        <div className={styles.disclaimerText}>( For international cards, Surcharge: ${parseFloat(paymentObj.surchargeInternational).toFixed(2)}, Grand Total: ${parseFloat(paymentObj.grandTotalInternational).toFixed(2)} )</div>             
                      </div>
                    </div>
                  </Col>
                  <Col sm={6}>
                    <div className={styles.PaymentRight}>            
                      {clientSecret ? 
                        <div className='payment_div'> 
                          <div className={styles.WalletGroup}>
                            <Link legacyBehavior href="#">
                              <a className={styles.WalletButton}>
                                <Icon.Apple />Pay
                              </a>
                            </Link>
                          </div>
                          <h5><span>or pay another way</span></h5>
                        
                          <Elements options={paymentOptions} stripe={stripePromise}>
                            <RechargeForm 
                              endConsumerId={endConsumerId}
                              redirectToUrl={redirectToUrl}
                            />                      
                          </Elements>  
                        </div>  
                      : 
                      <div className='loading_div'>
                        <div className="bar_loader">
                          <div className="bar"></div>
                          <div className="bar2"></div>
                          <div className="bar3"></div>
                          <div className="bar4"></div>
                        </div>
                      </div>}
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>
          </div>
        </div>
      </section>
      {/* ====================== main container part end======================= */}
      {/* ===============footer frontend admin==================== */}
      <MemberFooter/>
      {/* ===============footer frontend admin end==================== */}
    </section>
  );
}