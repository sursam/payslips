import React, { Fragment } from 'react';
import { Page, Text, Image, View, Document, StyleSheet} from '@react-pdf/renderer';
// Create styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Helvetica',
    fontSize: 11,
    paddingTop: 40,
    paddingLeft:60,
    paddingRight:60,
    paddingBottom:80,
    lineHeight: 1.5,
    flexDirection: 'column',
  }, 
  headerSection: {
    display: 'flex',
    textAlign: 'center',
  },
  footerSection: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: "60px",
    display: 'block',
    textAlign: 'left',
  }, 
  logo: {
    width: '8%',
    height: 'auto',
    display: 'block',
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  copyRightText: {
    fontFamily: "Helvetica",
    fontSize: 7,
    paddingBottom: 6,
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  headerText: {
    fontFamily: 'Helvetica-Bold',
    fontSize: 20,
    textTransform: 'uppercase'
  },
  headerSubText: {
    fontFamily: 'Helvetica-Bold',
    fontSize: 16,
  },
  tableContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 10,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#10253e',
    overflowWrap: "break-word",
    wordBreak: "break-all", 
    whiteSpace: "wrap",
  },
  container: {
      flexDirection: 'row',
      borderBottomColor: '#10253e',
      backgroundColor: '#10253e',
      borderBottomWidth: 1,
      alignItems: 'center',
      height: 24,
      textAlign: 'center',
      fontStyle: 'bold',
      flexGrow: 1,
      color: '#ffffff',
      fontFamily: 'Helvetica-Bold',
      fontSize: 9,
  },
  labelTextHead: {
    width: '16%',
    borderRightColor: '#707070',
    borderRightWidth: 1,
    textAlign: 'left',
    paddingLeft: 5,
    paddingTop: 6,
    display: 'block'
  },
  labelText: {
    width: '16%',
    textAlign: 'left',
    paddingLeft: 5,
    paddingTop: 6,
    display: 'block'
  },
  labelTextLast: {
    width: '20%',
    borderRight: 'none',
    textAlign: 'left',
    paddingLeft: 5,
    paddingTop: 6,
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    fontStyle: 'bold',
    borderBottomColor: '#10253e',
    borderBottomWidth: 1,
    fontSize: 9,
    overflowWrap: "break-word",
    wordBreak: "break-all", 
    whiteSpace: "wrap",
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    fontStyle: 'bold',
    fontSize: 9,
    overflowWrap: "break-word",
    wordBreak: "break-all", 
    whiteSpace: "wrap",
  },
  rightContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },

})

export default function UsageStatement(props) {
  const formatDate = (d) => {
    var date = new Date(d);
    date = ('00' + date.getUTCDate()).slice(-2) + '/' +
    ('00' + (date.getUTCMonth()+1)).slice(-2) + '/' +
    date.getUTCFullYear() + ' ' + 
    ('00' + date.getUTCHours()).slice(-2) + ':' + 
    ('00' + date.getUTCMinutes()).slice(-2) + ':' + 
    ('00' + date.getUTCSeconds()).slice(-2);
    return date;
  }
  //console.log(props)
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.headerSection}>
          <Text style={styles.headerText}>USAGE STATEMENT</Text>
          <Text style={styles.headerSubText}>{props.monthYear}</Text>
        </View>
        
        <Fragment>
          <View style={styles.row}>
            <View style={styles.leftContainer}>
              <Text style={styles.billFrom}>Statement From:</Text>
              <Text style={styles.billFromText}>{props.accountInfo.account_name__r.Name ? props.accountInfo.account_name__r.Name : ''}</Text>
              <Text style={styles.billFromText}>
                  {(props.accountInfo.account_name__r.ABN__c) ?
                      <>ABN: {props.accountInfo.account_name__r.ABN__c}</>
                  : ''}
              </Text>
              <Text style={styles.billFromText}>{props.billingAddress}</Text>
            </View>
            <View style={styles.rightContainer}>
              <Text style={styles.billTo}>Statement To:</Text>
              <Text style={styles.billToText}>{props.endConsumerInfo.name ? props.endConsumerInfo.name : ''} </Text>
              <Text style={styles.billToText}>{props.endConsumerInfo.abn ? <>ABN: {props.endConsumerInfo.abn}</> : ''}</Text>
              <Text style={styles.billToText}>{props.endConsumerInfo.mobile ? props.endConsumerInfo.mobile : ''}</Text>
            </View>
          </View>

          <View style={styles.row}>
            <View style={styles.leftContainer}>
              <Text style={styles.totalRecharge}>Total Recharge:</Text>
            </View>
            <View style={styles.rightContainer}>
              <Text style={styles.totalCreditUsed}>Total Credit Used:</Text>
            </View>
          </View>

          <View style={styles.tableContainer}>
            <View style={styles.container}>
                <Text style={styles.labelTextHead}>Date</Text>
                <Text style={styles.labelTextHead}>Transaction Id</Text>
                <Text style={styles.labelTextHead}>Card Number</Text>
                <Text style={styles.labelTextHead}>Machine Name</Text>
                <Text style={styles.labelTextHead}>Debit</Text>
                <Text style={styles.labelTextLast}>Associate Name</Text>
            </View>
            <Fragment>
              {props.usageInfo ? 
                props.usageInfo.map((usageData) => (
                  <View style={styles.tableRow} key={`row-${usageData.id}`}>
                    <Text style={styles.labelText}>{formatDate(usageData.settlement_time)}</Text>
                    <Text style={styles.labelText}>{usageData.transaction_id}</Text>
                    <Text style={styles.labelText}>{usageData.display_card_number}</Text>
                    <Text style={styles.labelText}>{usageData.machine_name}</Text>
                    <Text style={styles.labelText}>${parseFloat(usageData.spent_amount).toFixed(2)}</Text>
                    <Text style={styles.labelTextLast}>
                      {(typeof usageData.card.associate !== 'undefined') ?
                        usageData.card.associate.name
                      : ''}
                    </Text>
                  </View>
                ))   
                : ''
              }  
            </Fragment>
          </View>
        </Fragment>        

        <View style={styles.footerSection} fixed>
          <Text style={styles.copyRightText}>© {(new Date().getFullYear())} All Rights Reserved by Tap N Go Pty Ltd</Text>
          {props.siteLogo ? 
            <Image src={`/uploads/logo/${props.siteLogo}`} alt="" style={styles.logo}></Image>
          : ''}
        </View>

      </Page>
    </Document>
  );
}