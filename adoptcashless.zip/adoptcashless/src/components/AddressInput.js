import React, { useState, useCallback, useEffect } from 'react';
import { AddressAutofill, config } from '@mapbox/search-js-react';
 
export default function AddressInput(props) {
  const [showFormExpanded, setShowFormExpanded] = useState(false);
  const [showMinimap, setShowMinimap] = useState(false);
  const [feature, setFeature] = useState();
  const [showValidationText, setShowValidationText] = useState(false);
  const [token, setToken] = useState('');
  const [fullAddress, setFullAddress] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [region, setRegion] = useState('');
  const [postcode, setPostcode] = useState('');
  const [country, setCountry] = useState('');
  const [value, setValue] = useState('');
  const env = require('../../../app/config/env.js');
 
  useEffect(() => {
    const accessToken = env.mapboxToken;
    setToken(accessToken)
    config.accessToken = accessToken;
  }, [])
   
  const handleRetrieve = useCallback(
    (res) => {
      const feature = res.features[0];
      setFeature(feature);
      setFullAddress(feature.properties.full_address);
      setStreet(feature.properties.street);
      setCity(feature.properties.locality);
      setRegion(feature.properties.region);
      setPostcode(feature.properties.postcode);
      setCountry(feature.properties.country);
      //console.log(setFullAddress);
    },
    [setFeature, setFullAddress]
  );

  const handleAddressInput = ({ target: { value } }) => {
      setFullAddress(value);
      /*setStreet('');
      setCity('');
      setState('');
      setPostcode('');
      setCountry('');*/
  };
 
  return (
    <>
    <AddressAutofill accessToken={token} onRetrieve={handleRetrieve}>
      <input
        type="text"
        className={props.className}
        autoComplete="off"
        value={fullAddress}
        onChange={handleAddressInput}
        name="enquiry_address"
      />
    </AddressAutofill>
    <input type="hidden" name="street" value={street} />
    <input type="hidden" name="city" value={city} />
    <input type="hidden" name="region" value={region} />
    <input type="hidden" name="postcode" value={postcode} />
    <input type="hidden" name="country" value={country} />    
    </>
  );
};