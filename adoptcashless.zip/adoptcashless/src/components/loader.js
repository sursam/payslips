const loaderStyle = {
  "margin": "0 5px",
  "verticalAlign": "middle"
};
export default function Loader({  }) {
  return (
    <img
      src="/assets/images/loading.gif"
      width="19" 
      height="18"
      alt="Loading"
      style={loaderStyle}
    />
  );
}
