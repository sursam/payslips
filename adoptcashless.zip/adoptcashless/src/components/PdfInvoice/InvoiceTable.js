import React, { Fragment } from 'react';
import {Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
    tableContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderColor: '#10253e',
    },
    container: {
        flexDirection: 'row',
        borderBottomColor: '#10253e',
        backgroundColor: '#10253e',
        borderBottomWidth: 1,
        alignItems: 'center',
        height: 24,
        textAlign: 'center',
        fontStyle: 'bold',
        flexGrow: 1,
        color: '#ffffff',
        fontFamily: 'Helvetica-Bold'
    },
    description: {
        width: '50%',
        borderRightColor: '#707070',
        borderRightWidth: 1,
        textAlign: 'left',
        paddingLeft: 10,
        paddingTop: 6
    },
    charges: {
        width: '25%',
        borderRightColor: '#707070',
        borderRightWidth: 1,
        paddingTop: 6,
        textAlign: 'center',
    },
    amount: {
        width: '25%',
        paddingTop: 6,
        textAlign: 'center',
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 24,
        fontStyle: 'bold',
        borderBottomColor: '#10253e',
        borderBottomWidth: 1,
    },
    totalContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20,
        height: 24,
    },
    blankCell: {
        height: 24,
        width: '50%',
    },
    totalPaid: {
        borderWidth: 1,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        backgroundColor: '#10253e',
        color: '#ffffff',
        textAlign: 'center',
        paddingTop: 6,
        fontFamily: 'Helvetica-Bold'
    },
    totalAmount: {
        borderWidth: 1,
        borderLeftWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
    },
    balanceContainerTop: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        height: 24,
        marginTop: 20,
    },
    balanceContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        height: 24,
    },
    balanceTextTop: {
        borderWidth: 1,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
    },
    balanceText: {
        borderWidth: 1,
        borderTopWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
    },
    balanceTextBottom: {
        borderWidth: 1,
        borderTopWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
        backgroundColor: '#10253e',
        color: '#ffffff',
        fontFamily: 'Helvetica-Bold'
    },
    balanceAmountTop: {
        borderWidth: 1,
        borderLeftWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
    },
    balanceAmount: {
        borderWidth: 1,
        borderTopWidth: 0,
        borderLeftWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
    },
    balanceAmountBottom: {
        borderWidth: 1,
        borderTopWidth: 0,
        borderLeftWidth: 0,
        borderColor: '#10253e',
        height: 24,
        width: '25%',
        textAlign: 'center',
        paddingTop: 6,
        backgroundColor: '#10253e',
        color: '#ffffff',
        fontFamily: 'Helvetica-Bold'
    },
  });


  const InvoiceTable = (props) => (
        <Fragment>
            <View style={styles.tableContainer}>
                <View style={styles.container}>
                    <Text style={styles.description}>Description</Text>
                    <Text style={styles.charges}>Charges</Text>
                    <Text style={styles.amount}>Total Paid</Text>
                </View>
                <Fragment>
                    <View style={styles.row} key='creditRow'>
                        <Text style={styles.description}>Corporate Card Credit</Text>
                        <Text style={styles.charges}>${parseFloat(props.transactionInfo.net_amount).toFixed(2)}</Text>
                        <Text style={styles.amount}>${parseFloat(props.transactionInfo.net_amount).toFixed(2)}</Text>
                    </View> 
                    <View style={styles.row} key='surchargeRow'>
                        <Text style={styles.description}>Surcharge</Text>
                        <Text style={styles.charges}>${parseFloat(props.transactionInfo.stripe_fees+props.transactionInfo.tng_commission).toFixed(2)}</Text>
                        <Text style={styles.amount}>${parseFloat(props.transactionInfo.stripe_fees+props.transactionInfo.tng_commission).toFixed(2)}</Text>
                    </View>   
                </Fragment>
            </View>
            <View style={styles.totalContainer}>
                <Text style={styles.blankCell}></Text>
                <Text style={styles.totalPaid}>Total Paid</Text>
                <Text style={styles.totalAmount}>${parseFloat(props.transactionInfo.total_amount).toFixed(2)}</Text>
            </View>
            <Fragment>
                <View style={styles.balanceContainerTop} key='pbRow'>
                    <Text style={styles.blankCell}></Text>
                    <Text style={styles.balanceTextTop}>Previous Balance</Text>
                    <Text style={styles.balanceAmountTop}>${props.transactionInfo.previous_balance ? parseFloat(props.transactionInfo.previous_balance).toFixed(2) : (0).toFixed(2)}</Text>
                </View>
                <View style={styles.balanceContainer} key='ecRow'>
                    <Text style={styles.blankCell}></Text>
                    <Text style={styles.balanceText}>Extra Credit</Text>
                    <Text style={styles.balanceAmount}>${props.transactionInfo.extra_credit ? parseFloat(props.transactionInfo.extra_credit).toFixed(2) : (0).toFixed(2)}</Text>
                </View>
                <View style={styles.balanceContainer} key='brRow'>
                    <Text style={styles.blankCell}></Text>
                    <Text style={styles.balanceText}>Balance Received</Text>
                    <Text style={styles.balanceAmount}>${parseFloat(props.transactionInfo.net_amount + props.transactionInfo.extra_credit).toFixed(2)}</Text>
                </View>
                <View style={styles.balanceContainer} key='nbRow'>
                    <Text style={styles.blankCell}></Text>
                    <Text style={styles.balanceTextBottom}>New Balance</Text>
                    <Text style={styles.balanceAmountBottom}>${parseFloat(props.transactionInfo.previous_balance + props.transactionInfo.net_amount + props.transactionInfo.extra_credit).toFixed(2)}</Text>
                </View>
            </Fragment>
        </Fragment>
  );
  
  export default InvoiceTable