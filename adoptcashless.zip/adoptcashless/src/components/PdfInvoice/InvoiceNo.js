import React, { Fragment } from 'react';
import {Text, View, StyleSheet } from '@react-pdf/renderer';
import Moment from 'moment';

const styles = StyleSheet.create({
    invoiceNoContainer: {
        flexDirection: 'row',
        marginTop: 36,
        justifyContent: 'flex-end'
    },
    invoiceDateContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    invoiceDate: {
        fontFamily: 'Helvetica-Bold'
    },
    label: {
        width: 60,
    }
    
  });


  const InvoiceNo = (props) => (
        <Fragment>
            <View style={styles.invoiceNoContainer}>
                <Text style={styles.label}>Invoice No: </Text>
                <Text style={styles.invoiceDate}> INV-{String(props.transactionInfo.id).padStart(6, '0')}</Text>
            </View >
            <View style={styles.invoiceDateContainer}>
                <Text style={styles.label}>Date: </Text>
                <Text style={styles.invoiceDate}> {Moment(props.transactionInfo.created_on).format('DD/MM/YYYY')}</Text>
            </View >
        </Fragment>
  );
  
  export default InvoiceNo