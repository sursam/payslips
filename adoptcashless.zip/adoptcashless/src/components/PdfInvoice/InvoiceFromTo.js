import React from 'react';
import {Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
    headerContainer: {
        marginTop: 36
    },
    billFrom: {
        paddingBottom: 3,
        fontFamily: 'Helvetica'
    },
    billFromText: {
        fontFamily: 'Helvetica-Bold'
    },
    billTo: {
        marginTop: 10,
        paddingBottom: 3,
        fontFamily: 'Helvetica'
    },
    billToText: {
        fontFamily: 'Helvetica-Bold'
    },
  });


  const InvoiceFromTo = (props) => (
    <View style={styles.headerContainer}>
        <Text style={styles.billFrom}>Invoiced From:</Text>
        <Text style={styles.billFromText}>{props.accountInfo.account_name__r.Name ? props.accountInfo.account_name__r.Name : ''}</Text>
        <Text style={styles.billFromText}>
            {(props.accountInfo.account_name__r.ABN__c) ?
                <>ABN: {props.accountInfo.account_name__r.ABN__c}</>
            : ''}
        </Text>
        <Text style={styles.billFromText}>{props.billingAddress}</Text>        
       
        <Text style={styles.billTo}>Invoiced To:</Text>
        <Text style={styles.billToText}>{props.endConsumerInfo.name ? props.endConsumerInfo.name : ''} </Text>
        <Text style={styles.billToText}>{props.endConsumerInfo.abn ? <>ABN: {props.endConsumerInfo.abn}</> : ''}</Text>
        <Text style={styles.billToText}>{props.endConsumerInfo.mobile ? props.endConsumerInfo.mobile : ''}</Text>
    </View>
  );
  
  export default InvoiceFromTo