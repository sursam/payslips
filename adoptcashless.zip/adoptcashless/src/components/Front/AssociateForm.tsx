import React, {useState, useEffect} from 'react';
import styles from '../../styles/Dashboard.module.css';
import ErrorSummary from '../errorSummary';
import Loader from '../loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import axios from "axios";
import Select from 'react-select';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const AssociateForm = ({dataVal}:any) => {
  
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  
  var [state, setState] = useState({
    endConsumerId: dataVal.endConsumerId,
    cards: dataVal.cards,
    id: dataVal.id,
    first_name: dataVal.first_name,
    last_name: dataVal.last_name,
    mobile: dataVal.mobile,
    email: dataVal.email,
    dob: dataVal.dob,
    gender: dataVal.gender,
    car_reg: dataVal.car_reg,
    assigned_card: dataVal.assigned_card,
  });
  if(dataVal.id){
    setState(prevState => ({
      ...prevState,
      //id: dataVal.id,
      //first_name: dataVal.first_name,
      //last_name: dataVal.last_name,
      mobile: dataVal.mobile,
      //email: dataVal.email,
      //dob: dataVal.dob,
      //gender: dataVal.gender,
      //car_reg: dataVal.car_reg,
      //assigned_card: dataVal.assigned_card,
    }));
    //console.log(dataVal.email)
  }  
  
  var { endConsumerId, cards, id, first_name, last_name, mobile, email, dob, gender, car_reg, assigned_card } = state;
   
  const genderOptions = [
    { value: 'm', label: 'Male' },
    { value: 'f', label: 'Female' }
  ]
  
  const cardOptions:any = [];
  cards.forEach(card => {
    var obj:any = {};
    obj['value'] = card.Id;
    obj['label'] = card.Display_Card_Number__c;
    cardOptions.push(obj);
  });  

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };
  /*const handleStatusChange =(event:any) => {
    const { name, value } = event.target;
      setState(prevState => ({
        ...prevState,
        [name]: value,
      }));
  }*/

  var validationSchema = Yup.object().shape({
    first_name: Yup.string()
      .required('First name is required'),
    last_name: Yup.string()
      .required('Last name is required'),
    mobile: Yup.string()
      .required('Mobile number is required'),
    email: Yup.string()
      .required('Email is required'),
    dob: Yup.string()
      .required('Date of birth is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-associate`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setState(prevState => ({
          ...prevState,
          id: '',
          first_name: '',
          last_name: '',
          mobile: '',
          email: '',
          dob: '',
          gender: null,
          car_reg: '',
          assigned_card: null,
        }));
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };

  const onGenderChange = (
    newValue
  ) => {
    setState(prevState => ({
      ...prevState,
      gender: newValue.value,
    }));
  };
  const onCardChange = (
    newValue
  ) => {
    //console.log(newValue.value)
    setState(prevState => ({
      ...prevState,
      assigned_card: newValue.value,
    }));
  };
  
  return (
    <>      
      <form id="associateForm" className='associate-form' onSubmit={handleSubmit(onSubmit)}>
        <div className={styles.formCoantainer}>
          <div className={styles.formgroup}>
              <label>First Name</label>
              <input type="text" {...register('first_name')} value={first_name} onChange={handleChange} className={`${errors.first_name ? 'is-invalid' : ''}`} />
              <div className="invalid-feedback">{errors.first_name?.message}</div>
          </div>
          <div className={styles.formgroup}>
              <label>Last Name</label>
              <input type="text" {...register('last_name')} value={last_name} onChange={handleChange} className={`${errors.last_name ? 'is-invalid' : ''}`} />
              <div className="invalid-feedback">{errors.last_name?.message}</div>
          </div>
          <div className={styles.formgroup}>
              <label>Mobile Number</label>
              <input type="text" {...register('mobile')} value={mobile} onChange={handleChange} className={`${errors.mobile ? 'is-invalid' : ''}`} />
              <div className="invalid-feedback">{errors.mobile?.message}</div>
          </div>
          <div className={styles.formgroup}>
              <label>Email Address</label>
              <input type="text" {...register('email')} value={email} onChange={handleChange} className={`${errors.email ? 'is-invalid' : ''}`} />
              <div className="invalid-feedback">{errors.email?.message}</div>
          </div>
          <div className={styles.formgroup}>
              <label>Date of Birth</label>
              <DatePicker {...register('dob')} className={`form-control ${errors.dob ? 'is-invalid' : ''}`} dateFormat="dd/MM/yyyy" selected={dob} maxDate={(new Date())} showYearDropdown showMonthDropdown dropdownMode="select" onChange={dob => setState(prevState => ({ ...prevState, ['dob']: dob, }))} value={dob}  />
              <div className="invalid-feedback">{errors.dob?.message}</div>
          </div>
          <div className={styles.formgroup}>
              <label>Gender</label>
              <Select options={genderOptions} defaultValue={gender} {...register('gender')} onChange={onGenderChange} />              
          </div>
          <div className={styles.formgroup}>
              <label>Car Registration</label>
              <input type="text" {...register('car_reg')} value={car_reg} onChange={handleChange} className={`${errors.car_reg ? 'is-invalid' : ''}`} />
          </div>
          <div className={styles.formgroup}>
              <label>Assign a Corporate Card</label>
              <Select options={cardOptions} defaultValue={assigned_card} {...register('assigned_card')} onChange={onCardChange} />
              
              {/*<select {...register('assigned_card')} value={`${assigned_card ? assigned_card : ''}`} onChange={handleStatusChange} >
                <option value="">Select</option>
                {dataCards.map((card:any) => (
                  <option value={card.id}>{card.Display_Card_Number__c}</option>
                ))}
                </select>*/}
          </div>
          <div className={styles.formgroup}>
              <div className={styles.AddMoreFields}> <input type="checkbox" /> Add More Fields</div>
          </div>
          <div className={styles.submitButton}>
              <input type="hidden" {...register('id')} value={id} />
              <input type="hidden" {...register('end_consumer_id')} value={endConsumerId} />
              <Button color="primary"
                variant="contained"
                type="submit"
                onClick={submitForm} 
                disabled={showLoader} >
                { showLoader ? <Loader /> : null } Create
              </Button>
          </div>
        </div>
        <ErrorSummary errors={validationErrors} success={successMessage} />
      </form>
    </>
  );
};
export default AssociateForm;
