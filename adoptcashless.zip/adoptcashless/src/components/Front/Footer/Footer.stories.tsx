/* eslint-disable */
import Footer from './Footer';

export default {
  title: "Footer",
};

export const Default = () => <Footer />;

Default.story = {
  name: 'default',
};
