import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import axios from "axios";

export default function MemberFooter() { 
    const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
    const [accountName, setAccountName]:any = useState('');
    useEffect(() => {
        if(endConsumerId){
            axios.get(`${process.env.serverUrl}get-account-info-by-endconsumer/${endConsumerId}`,{}).then((response) => {
                if(response.data.account_name__r != null){
                    setAccountName(response.data.account_name__r.Name);
                }
            });
        }
    }, 
    [])
    return (
        <footer className={styles.FooterBottom}>
            <div className={styles.CopyRight}>&copy; {(new Date().getFullYear())} All Rights Reserved by Tap N Go Pty Ltd</div>
            {accountName ?
                <div className={styles.LicenceNumber}>
                    {accountName} has the licence to use this application until 30th June {(new Date().getFullYear() + 1)}
                </div>
            : ''}
        </footer>
    );
}
