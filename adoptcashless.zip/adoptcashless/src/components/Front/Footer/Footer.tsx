import React, {useContext, useState, useEffect} from 'react';
import styles from './Footer.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
//import GlobalContext from '../../../components/GlobalContext';
import axios from "axios";

interface FooterProps {}

const Footer: React.FC<FooterProps> = () => {

//const { serverUrl } = useContext(GlobalContext);

const [state, setState] = useState({
    address: '',
    helpline_no: '',
    helpline_email_address: '',
    logo: '',
    });

  const {address, helpline_no, helpline_email_address, logo } = state;

useEffect(() => {

    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
        setState(prevState => ({
        ...prevState,
        id: response.data.id,
        site_title: response.data.site_title,
        address: response.data.address,
        helpline_no: response.data.helpline_no,
        helpline_email_address: response.data.helpline_email_address,
        logo: response.data.logo,
        twitter_link: response.data.twitter_link,
        facebook_link: response.data.facebook_link,
        instagram_link: response.data.instagram_link,
        youtube_link: response.data.youtube_link,
    }));

    });
},   

[]) 

  return (    
<div className="FooterMain">
  <section className={styles.Footer} data-testid="Footer">
    
      <Container fluid>
         <Row>
            <Col sm={3} key="22">
                <div className={styles.Footerleft}>
                    <figure>
                    {(logo != '') ?
                        <img src={`/uploads/logo/${logo}`} alt="" />
                    : ''}
                    </figure>
                    <div className={styles.Address}>
                        <aside>
                            <Icon.TelephonePlus />
                            <a href={`tel:${helpline_no}`}>{helpline_no}</a>
                        </aside>
                        <aside>
                            <Icon.Envelope />
                            <a href={`mailto:${helpline_email_address}}`}>{helpline_email_address}</a>
                         </aside>
                        <aside>
                            <Icon.House />
                            {address}
                        </aside>
                    </div>

                </div>
            </Col>
            <Col sm={7} key="23">
                <div className={styles.Footerlink}>

                    <aside>
                        <h2>Product</h2>
                        <ul>
                            <li><a href="/contact">VPOS Touch</a></li>
                            <li><a href="/contact">Onyx Touch</a></li>
                            <li><a href="/contact">VPOS Fusion</a></li>
                            <li><a href="/contact">Monyx Wallet</a></li>
                            <li><a href="/contact">Prepaid Card</a></li>
                            <li><a href="/contact">Other</a></li>
                        </ul>
                    </aside>
                    <aside>
                          <h2>About Us</h2>
                          <ul>
                              <li><a href="/about">About Us</a></li>
                              <li><a href="/contact">Testimonials</a></li>
                              <li><a href="/news">News</a></li>
                              <li><a href="/contact">FAQ</a></li>
                              <li><a href="/contact">Contact Us</a></li>
                              <li><a href="/contact">Enquire Now</a></li>
                          </ul>
                    </aside>
                    <aside>
                        <h2>Services</h2>
                        <ul>
                            <li><a href="/contact">Sales</a></li>
                            <li><a href="/contact">Repairs</a></li>
                            <li><a href="/contact">Installation</a></li>
                            <li><a href="/contact">Tech Support</a></li>
                            <li><a href="/contact">Online Training</a></li>
                            <li><a href="/contact">Existing Client Login</a></li>
                        </ul>
                    </aside>
                    <aside>
                        <h2>Services</h2>
                        <ul>
                            <li><a href="/contact">Sales</a></li>
                            <li><a href="/contact">Repairs</a></li>
                            <li><a href="/contact">Installation</a></li>
                            <li><a href="/contact">Tech Support</a></li>
                            <li><a href="/contact">Online Training</a></li>
                            <li><a href="/contact">Existing Client Login</a></li>
                        </ul>
                    </aside>
                    <aside>
                       <h2>Services</h2>
                        <ul>
                            <li><a href="/contact">Sales</a></li>
                            <li><a href="/contact">Repairs</a></li>
                            <li><a href="/contact">Installation</a></li>
                            <li><a href="/contact">Tech Support</a></li>
                            <li><a href="/contact">Online Training</a></li>
                            <li><a href="/contact">Existing Client Login</a></li>
                        </ul>
                    </aside>
                </div>
            </Col>
            <Col sm={2} key="24">
                <figure className={styles.Batch}>
                    <img src="/assets/images/batch.jpg" alt="" />
                </figure>
            </Col>
         </Row>
      </Container>
      <Container fluid>
          <Row>
              <Col key="25">
                  <div className={styles.FooterBottom}>
                      © Tap N Go Pty Ltd {(new Date().getFullYear())}
                  </div>
              </Col>
          </Row>
      </Container>

  </section>
  </div>
  );
};

export default Footer;
