/* eslint-disable */
import Header from './Header';

export default {
  title: "Header",
};

export const Default = () => <Header />;

Default.story = {
  name: 'default',
};
