import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
import Link from 'next/link';
import { useRouter } from 'next/router';
import { ToastContainer } from 'react-toastify';

export default function MemberHeader() { 
  const endConsumerId:any = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
  var [supportCases, setSupportCases] = useState<any[]>([]);

    const accountClick = () => {
        document.body.classList.toggle('SlideToggle');
        document.body.classList.remove('SupportCasesToggle');
    };

    const SupportCasesClick  = () => {
      document.body.classList.toggle('SupportCasesToggle');
      document.body.classList.remove('SlideToggle');
    };

    const [logo, setLogo] = useState('');

    const router = useRouter();
    const loggingOut = () => {
      localStorage.removeItem("authenticated");
      router.push('/login');
    };
    
    useEffect(() => {
      const authenticated:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated')) || 0;
      //console.log(authenticated);
      if(!authenticated)
      {
        router.push('/login');
      }

      axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
        setLogo(response.data.logo);   
      });

      getSupportCase();

    }, 
    [])

    const getSupportCase = () => {
      axios.get(`${process.env.serverUrl}get-active-support-cases/${endConsumerId}`,{}).then((response) => {  
          //console.log(response.data); 
          setSupportCases(response.data);   
      });
  }  

  return (
        <section className={styles.topSection}>
          <ToastContainer
              position="top-right"
              autoClose={10000}
              hideProgressBar={false}
              newestOnTop={false}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme="light"
          />
            <section className={styles.mainWrap}>
                <div className={styles.LogoAccount}>
                    <figure className={styles.leftLogo}>
                      {logo ? 
                        <img src={`/uploads/logo/${logo}`} alt="" />
                      : ''}
                    </figure>
                    <div className={styles.Authsection}>
                        <button onClick={SupportCasesClick}>Support Cases <Icon.ChatDots /></button>
                        {/* ================== Support Cases =============== */}
                            <div className="SupportCases">
                                <ul>
                                  {supportCases.length ? (supportCases.map((supportCase:any) => (
                                    <li>
                                     <figure>
                                        <Icon.ChatDots />
                                     </figure>
                                     <aside>
                                       <span><Link legacyBehavior href={`/support/${supportCase.case_id}`}><a>{supportCase.case_id}</a></Link></span>
                                       We specialise in providing businesses with a 
                                       complete cashless solution
                                     </aside>
                                     </li>
                                )) ) : ( 
                                    <li>
                                      <aside>
                                        No record found
                                      </aside>
                                      </li>
                                  )} 
                                </ul>
                            </div>
                        {/* ================== Support Cases end=============== */}
                        <div className={styles.userImage}>
                            <figure>
                                <a href="#" onClick={accountClick}>
                                    <img src='/assets/images/user-image.jpg' alt="" />
                                </a>
                            </figure>
                            {/* =============== My account section ================= */}
                                <div className="MyAccountPopUp" onClick={accountClick}>
                                    <ul>
                                        <li><Link legacyBehavior href="#"><a><Icon.PersonFill/> My Account</a></Link></li>
                                        <li><Link legacyBehavior href={"/recharge-history"}><a><Icon.Printer/> Recharge History</a></Link></li>
                                        <li><Link legacyBehavior href={"/settings"}><a><Icon.Gear/> Settings</a></Link></li>
                                        <li><Link legacyBehavior href="#"><a onClick={loggingOut}><Icon.LockFill/> Logout</a></Link></li>
                                    </ul>
                                </div>
                            {/* =============== My account section end ================= */}
                         </div>
                     </div>
                </div>
            </section>
        </section>
    );
}