import React, {useState, useEffect, useContext} from 'react';
import styles from './Header.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
//import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
import Link from 'next/link';
import { useRouter } from 'next/router';
import GlobalContext from '../../GlobalContext';

interface HeaderProps {}

const Header: React.FC<HeaderProps> = () => {
  const [logo, setLogo] = useState('');
  const router = useRouter();
  const { NODE_ENV, protocol, port, memberDomain } = useContext(GlobalContext)
  const memberUrl = (NODE_ENV != 'development') ? `${protocol}://${memberDomain}` : `${protocol}://${memberDomain}:${port}`;
 
  useEffect(() => {

    axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
      setLogo(response.data.logo);   
    });
  },   

  []) 

  return (
    <div className={styles.Header} data-testid="Header">
      <Navbar expand="lg" key="1">
      <Container fluid key="55">
        <Navbar.Brand href={"/"} key="2">
        {(logo != '') ?
          <img src={`/uploads/logo/${logo}`} alt="" />
         : ''}
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" key="3"/>
        <Navbar.Collapse id="basic-navbar-nav" key="4">   
           <div className="me-auto navbar-nav">
            <Link legacyBehavior href={"/"}><a className={router.pathname === '/front' ? 'active' : ''}>Home</a></Link> 
            <Link legacyBehavior href={"/about"}><a className={router.pathname === '/front/about' ? 'active' : ''}>About Us</a></Link> 
            <Link legacyBehavior href={"/product"}><a className={router.pathname === '/front/product' ? 'active' : ''}>Products</a></Link> 
            <Link legacyBehavior href={"/news"}><a className={router.pathname === '/front/news' ? 'active' : ''}>News & Articles</a></Link> 
            <Link legacyBehavior href={"/shop"}><a className={router.pathname === '/front/shop' ? 'active' : ''}>Shop</a></Link> 
            <Link legacyBehavior href={"/contact"}><a className={router.pathname === '/front/contact' ? 'active' : ''}>Contact us</a></Link> 
            <Link legacyBehavior href={`${memberUrl}`}><a className='MyAccount' target="_blank"><Icon.Person /> My Account</a></Link>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  </div>
  );
};
export default Header;
