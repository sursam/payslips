import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../../styles/Dashboard.module.css';
import * as Icon from 'react-bootstrap-icons';
import Navbar from 'react-bootstrap/Navbar';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function MemberMenu() { 
    const handleClick = (event:any) => {
        // toggle class on click
        event.currentTarget.classList.toggle('DashboardLeftshow');
        document.body.classList.toggle('openActiveMenu'); 
        document.body.classList.remove('SupportCasesToggle');
        document.body.classList.remove('SlideToggle');
    };
    // const slideClick = event => {
    //    event.currentTarget.classList.toggle('slideRightButton');
    // };

    const router = useRouter();
    const routerPath = router.asPath;
    //console.log(router.asPath)
  return (
        <div className={styles.DashboardLeft} id="DashboardLeftshow" onClick={handleClick}>
            <button className={styles.toggleButton} id="slideRightButton">
                <Icon.FilterLeft/>
            </button>
            <Navbar>
                <Link legacyBehavior href={"/dashboard"}><a className={routerPath.match('/dashboard') ? styles.active : ''}>My Dashboard <Icon.Display/></a></Link> 
                <Link legacyBehavior href={"/associates"}><a className={(routerPath.match('/associates') ||routerPath.match('/associate-details')) ? styles.active : ''}>Associates <Icon.PeopleFill/></a></Link> 
                <Link legacyBehavior href={"/corporate-cards"}><a className={(routerPath.match('/corporate-cards') || routerPath.match('/card-deatils')) ? styles.active : ''}>Corporate Cards <Icon.CreditCard/></a></Link> 
                <Link legacyBehavior href={"/recharge-history"}><a className={routerPath.match('/recharge-history') ? styles.active : ''}>Recharge History  <Icon.Printer/></a></Link> 
                <Link legacyBehavior href={"/faq"}><a className={routerPath.match('/faq') ? styles.active : ''}>FAQ <Icon.QuestionCircle/></a></Link> 
                <Link legacyBehavior href={"/settings"}><a className={routerPath.match('/settings') ? styles.active : ''}>Settings <Icon.Gear/></a></Link> 
            </Navbar>
        </div>
    );
}
