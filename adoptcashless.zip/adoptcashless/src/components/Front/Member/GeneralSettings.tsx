import React, {useState, useEffect} from 'react';
import styles from '../../../styles/Dashboard.module.css';
import ErrorSummary from '../../errorSummary';
import Loader from '../../loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import axios from "axios";
import "react-datepicker/dist/react-datepicker.css";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import AbnInput from '../../AbnInput';
import AcnInput from '../../AcnInput';
import { InputGroup } from '@paljs/ui/Input';

const GeneralSettings = () => {
  
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);

  useEffect(() => {
    axios.get(`${process.env.serverUrl}get-company-info/${endConsumerId}`,{}).then((response) => { 
      if(response.data){
        response.data.forEach(infoData => {
          setState(prevState => ({
            ...prevState,
            [infoData.field_name]: infoData.field_value,
          }));
        });
      }
    });
  }, 
  [])
  
  var [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '',
    company_name: '',
    business_name: '',
    abn: '',
    acn: '',
    primary_contact_name: '',
    primary_contact_email: '',
    billing_address: '',
    mailing_address: '',
  });
  
  var { endConsumerId, company_name, business_name, abn, acn, primary_contact_name, primary_contact_email, billing_address, mailing_address } = state;
  
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };
  
  const [abnError, setAbnError] = useState(false);
  const handleAbnInput = ({ target: { value } }:any) => {
      let inputVal = value.replace('/\D/g', '');
      //console.log(inputVal);
      setState(prevState => ({
          ...prevState,
          abn: inputVal
      }));
      if(inputVal){
        setAbnError(true)
      }
      if(!inputVal.length && abnError)
        trigger('abn')
  }
  const [acnError, setAcnError] = useState(false);
  const handleAcnInput = ({ target: { value } }:any) => {
      let inputVal = value.replace('/\D/g', '');
      //console.log(inputVal);
      setState(prevState => ({
          ...prevState,
          acn: inputVal
      }));
      if(inputVal){
        setAcnError(true)
      }
      if(!inputVal.length && acnError)
        trigger('acn')
  }

  var validationSchema = Yup.object().shape({
    company_name: Yup.string()
      .required('Company name is required'),
    business_name: Yup.string()
      .required('Business name is required'),
    abn: Yup.string()
      .required('ABN is required'),
    acn: Yup.string()
      .required('ACN is required'),
    primary_contact_name: Yup.string()
      .required('Primary Contact Name is required'),
    primary_contact_email: Yup.string()
      .required('Primary Contact Email is required')
      .email('Primary Contact Email is invalid'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors }, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {    
    clearErrors()   
    reset(state)
    if(!abn){
        setAbnError(true)
    }
    if(!acn){
        setAcnError(true)
    }
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-company-info`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.message);
      }        
    });
  };

  /*const onUploadHandler = (event:any) => {
    const data = new FormData();
    data.append('myfile', event.target.files[0]);
    axios.post(`${process.env.serverUrl}upload-company-logo`, data).then((response) => { 
      setState(prevState => ({
        ...prevState,
        logo: response.data,
      }));
    });
  };*/
  
  return (
    <div className={styles.GeneralSettings}>      
      <form id="companyInfoForm" className='company-info-form' onSubmit={handleSubmit(onSubmit)}>
        <div className={styles.formCoantainer}>
          <Container>
              <Row>
                  <Col sm={6}>
                    <div className={styles.formgroup}>
                      <label>Company Name</label>
                      <input type="text" {...register('company_name', {onChange: handleChange})} value={company_name} className={`form-control ${errors.company_name ? 'is-invalid' : (company_name ? 'is-valid' : '')}`} />
                      <div className="invalid-feedback">{errors.company_name?.message?.toString()}</div>
                    </div>
                  </Col>
                  <Col sm={6}>
                    <div className={styles.formgroup}>
                      <label>Business Name</label>
                      <input type="text" {...register('business_name', {onChange: handleChange})} value={business_name} className={`form-control ${errors.business_name ? 'is-invalid' : (business_name ? 'is-valid' : '')}`} />
                      <div className="invalid-feedback">{errors.business_name?.message?.toString()}</div>
                    </div>
                  </Col>
                  <Col sm={6}>  
                    <div className={styles.formgroup}>
                      <label>ABN</label>
                      <AbnInput className={`form-control ${(abn && isNaN(parseInt(abn)) || (errors.abn && !abn) || (abn && abn.replace(/\D/g, '').length < 11)) ? 'is-invalid' : ( !isNaN(parseInt(abn)) && abn.replace(/\D/g, '').length == 11 ? 'is-valid' : '')}`} value={abn} {...register('abn')} onChange={handleAbnInput} />
                      <div  className={`invalid-feedback ${(abn && isNaN(parseInt(abn)) || (errors.abn && !abn) || (abn && abn.replace(/\D/g, '').length < 11)) ? 'is-invalid' : ( abn.length == 11 ? 'is-valid' : '')}`}>{(errors.abn && !abn || abn.replace(/\D/g, '').length < 11 || isNaN(parseInt(abn))) ? errors.abn?.message?.toString() : ''}</div>
                    </div>
                  </Col>
                  <Col sm={6}>  
                    <div className={styles.formgroup}>
                      <label>ACN</label>
                      <AcnInput className={`form-control ${(acn && isNaN(parseInt(acn)) || (errors.acn && !acn) || (acn && acn.replace(/\D/g, '').length < 9)) ? 'is-invalid' : ( !isNaN(parseInt(acn)) && acn.replace(/\D/g, '').length == 9 ? 'is-valid' : '')}`} value={acn} {...register('acn')} onChange={handleAcnInput} />
                      <div  className={`invalid-feedback ${(acn && isNaN(parseInt(acn)) || (errors.acn && !acn) || (acn && acn.replace(/\D/g, '').length < 9)) ? 'is-invalid' : ( acn.length == 9 ? 'is-valid' : '')}`}>{(errors.acn && !acn || acn.replace(/\D/g, '').length < 9 || isNaN(parseInt(acn))) ? errors.acn?.message?.toString() : ''}</div>
                    </div>
                  </Col>
                  <Col sm={6}>    
                    <div className={styles.formgroup}>
                      <label>Primary Contact Name</label>
                      <input type="text" {...register('primary_contact_name', {onChange: handleChange})} value={primary_contact_name} className={`form-control ${errors.primary_contact_name ? 'is-invalid' : (primary_contact_name ? 'is-valid' : '')}`} />
                      <div className="invalid-feedback">{errors.primary_contact_name?.message?.toString()}</div>
                    </div> 
                  </Col>
                  <Col sm={6}>    
                    <div className={styles.formgroup}>
                      <label>Primary Contact Email</label>
                      <input type="text" {...register('primary_contact_email', {onChange: handleChange})} value={primary_contact_email} className={`form-control ${errors.primary_contact_email ? 'is-invalid' : (primary_contact_email ? 'is-valid' : '')}`} />
                      <div className="invalid-feedback">{errors.primary_contact_email?.message?.toString()}</div>
                    </div> 
                  </Col>
                  <Col sm={6}>   
                    <div className={styles.formgroup}>
                      <label>Billing Address</label>
                      <input type="text" {...register('billing_address', {onChange: handleChange})} value={billing_address} className={`form-control ${billing_address ? 'is-valid' : ''}`} />
                    </div> 
                  </Col> 
                  <Col sm={6}>    
                    <div className={styles.formgroup}>
                      <label>Mailing Address</label>
                      <input type="text" {...register('mailing_address', {onChange: handleChange})} value={mailing_address} className={`form-control ${mailing_address ? 'is-valid' : ''}`} />
                    </div>
                  </Col>
                  {/*<Col sm={6}>
                    <Row>
                      <Col className='form-col' sm={6}>
                        <label htmlFor={logo}>Logo <span>(.jpg, .jpeg, .png)</span></label>
                        <InputGroup className='form-group' fullWidth>                      
                          <input type="file" name="myfile" onChange={onUploadHandler} className={`form-control ${errors.setImage ? 'is-invalid' : ''}`} />
                          <input type="hidden" {...register('logo')} id="hidden-logo" value={logo} />
                        </InputGroup>
                      </Col>
                      <Col className='form-col' sm={6}>
                        <img className="prevImg" src = {`${logo ? `/uploads/logo/${logo}` : '/assets/images/no-image.png' }` } />
                      </Col>
                    </Row>
                  </Col>*/}
              </Row>
          </Container>
          <div className={styles.submitButton}>
              <Button color="primary"
                variant="contained"
                type="submit"
                onClick={submitForm} 
                disabled={showLoader} >
                { showLoader ? <Loader /> : null } Update
              </Button>
          </div>
        </div>
        <ErrorSummary errors={validationErrors} success={successMessage} />
      </form>
    </div>
  );
};
export default GeneralSettings;
