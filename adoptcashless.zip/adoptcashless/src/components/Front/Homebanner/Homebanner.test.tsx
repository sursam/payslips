import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Homebanner from './Homebanner';

describe('<Homebanner />', () => {
  test('it should mount', () => {
    render(<Homebanner />);
    
    const homebanner = screen.getByTestId('Homebanner');

    expect(homebanner).toBeInTheDocument();
  });
});