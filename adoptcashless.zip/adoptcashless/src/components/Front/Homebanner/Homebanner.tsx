import React, {FC,useState, useEffect, useContext} from 'react';
import styles from './Homebanner.module.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as Icon from 'react-bootstrap-icons';
//import GlobalContext from '../../../components/GlobalContext';
import axios from "axios";

interface HomebannerProps {}

const Homebanner: FC<HomebannerProps> = () => {  

  //const { serverUrl } = useContext(GlobalContext);
  const [company, setCompany] = useState([]);
  const [content, setContent]:any = useState([]);

  useEffect(() => {

    const getcontent = async() => 
    {
        axios.get(`${process.env.serverUrl}page-content/home`).then((response) => {
        setContent(response.data.metaData); 
      });
    }

    getcontent();

  const getcompany = async() => 
    {
        axios.post(`${process.env.serverUrl}company-list/`,{}).then((response) => {
        setCompany(response.data);   
      });
    } 
    getcompany();
},   

[]) 

return (
  <div className={styles.Homebanner} data-testid="Homebanner">
    <section className="HomeBanner">
          <Container fluid>
            <Row>
              <Col className="firstcl" xl={6} md={6} sm={12}>
                  <div className="leftContainer">
                    <h1><div dangerouslySetInnerHTML={{__html: content[0]?.meta_value }} /></h1>
                    <div className="paraContent">
                        <div dangerouslySetInnerHTML={{__html: content[1]?.meta_value }} />
                    </div>
                    <div className="ButtonGroup">
                        <a href={content[4]?.meta_value}>{content[3]?.meta_value} <Icon.ArrowRight /></a>
                        <a href={content[6]?.meta_value} className="active">{content[5]?.meta_value} <Icon.ArrowRight /></a>
                    </div>
                  </div>
              </Col>
              <Col xl={6} md={6} sm={12}>
                  <figure>
                    <img src={`${content[2]?.meta_value ? `/uploads/pages/${content[2]?.meta_value}` : '/assets/images/no-image.png'}`} alt="" />
                  </figure>
              </Col>
            </Row>
          </Container>
        </section>
       
    {/* =====================payment icon=======================   */}

    <section className='paymentIcon'>
        <Container fluid>
          {company.map((getcompany:any) => (
            <img src={`${getcompany.companyImage ? `/uploads/company/${getcompany.companyImage}` : '/assets/images/no-image.png'}`} alt="" />
          ))}  
        </Container>
    </section>

  </div>
  );
};
export default Homebanner;
