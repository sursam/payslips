/* eslint-disable */
import Homebanner from './Homebanner';

export default {
  title: "Homebanner",
};

export const Default = () => <Homebanner />;

Default.story = {
  name: 'default',
};
