import React, { lazy, Suspense } from 'react';

const LazyHomebanner = lazy(() => import('./Homebanner'));

const Homebanner = (props: JSX.IntrinsicAttributes & { children?: React.ReactNode; }) => (
  <Suspense fallback={null}>
    <LazyHomebanner {...props} />
  </Suspense>
);

export default Homebanner;
