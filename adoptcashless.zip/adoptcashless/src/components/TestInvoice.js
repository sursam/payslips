import React from 'react';
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const invoiceStyles = StyleSheet.create({
	page: {
		flexDirection: 'row',
	},
	section: {
		flexGrow: 1,
	},
});

export default function TestInvoice(props) {
  return (
    <Document>
      <Page size="A4" style={invoiceStyles.page}>
        <View style={invoiceStyles.section}>
          <Text>Hello World!</Text>
        </View>
        <View style={invoiceStyles.section}>
          <Text>We're inside a PDF!</Text>
        </View>
      </Page>
    </Document>
  );
}