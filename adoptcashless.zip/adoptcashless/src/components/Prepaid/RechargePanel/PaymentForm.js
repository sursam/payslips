import React from "react";
import { ElementsConsumer } from "@stripe/react-stripe-js";
import Loader from '../../loader';
import axios from "axios";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Button } from "@material-ui/core";
import PaymentSection from "./PaymentSection";

class PaymentForm extends React.Component {
  handleSubmit = async event => {
    event.preventDefault();
    this.props.setIsFetching(true);
    try {
      const { stripe, elements } = this.props;
      if (!stripe || !elements) {
        return;
      }
      const result = await stripe.confirmSetup({
        elements,
        redirect: 'if_required'
      });
      //console.log('Result', result)    
      //this.props.formOptions.router.push('/dashboard');
      if (!result.error) {
        const formData = {};
        formData.endConsumerId = this.props.endConsumerId;
        formData.paymentMethodId = result.setupIntent.payment_method;
        //console.log(result.setupIntent.payment_method);
        axios.post(`${process.env.serverUrl}create-stripe-source`, formData).then((response) => {
          this.props.setIsFetching(false);
          if(!response.data.error){
            toast.success(response.data.message);
            this.props.listSources();
            this.props.setShowSourceList();
          }else{        
            toast.error(response.data.error);
            //setvalidationErrorsBankAccount(response.data.error);
          }        
        });
        
      }
    } catch(e) {
        console.log('Error', e);
    }
   
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <div className="cell stripeform_panel stripeform">
            <PaymentSection />
          </div>
          <Button color="primary" variant="contained" type="submit" disabled={(!this.props.stripe)}>{ (!this.props.stripe) ? <Loader /> : null } Add</Button>
          <Button variant="contained" type="button" onClick={this.props.setShowSourceList} className="cancelBtn">Cancel</Button>
        </form>
        
      </div>
    );
  }
}

export default function InjectedCheckoutForm(props) {
  return (
    <ElementsConsumer>
      {({ stripe, elements }) => (
        <PaymentForm 
          stripe={stripe} 
          elements={elements} 
          setShowSourceList={props.setShowSourceList} 
          endConsumerId={props.endConsumerId}
          listSources={props.listSources}
          setIsFetching={props.setIsFetching} />
      )}
    </ElementsConsumer>
  );
}
