import React from "react";
import { ElementsConsumer } from "@stripe/react-stripe-js";
import Loader from '../../loader';
import axios from "axios";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Button } from "@material-ui/core";
import PaymentSection from "./PaymentSection";
import Link from 'next/link';

class RechargeForm extends React.Component {
  handleSubmit = async event => {
    event.preventDefault();    
    try {
      const { stripe, elements } = this.props;
      if (!stripe || !elements) {
        return;
      }
      const result = await stripe.confirmSetup({
        elements,
        redirect: 'if_required'
      });
      //console.log('Result', result)  
      if (!result.error) {
        var btnPay = document.querySelector('.btn-pay');
        var successBlock = document.querySelector('.success');
        var stripeformPanel = document.querySelector('.stripeform-panel');
        stripeformPanel.style.display = "none";
        btnPay.style.display = "none";
        var stripeform = document.querySelector('.stripeform');
        successBlock.style.position = "relative";
        stripeform.classList.add('submitting');

        let endConsumerId = this.props.endConsumerId;
        let associateId = this.props.associateId;
        let rfidCardId = this.props.rfidCardId;
        
        const formData = {};
        formData.endConsumerId = endConsumerId;
        formData.associateId = associateId;
        formData.rfidCardId = rfidCardId;
        formData.paymentMethod = result.setupIntent.payment_method;
        if(typeof localStorage !== 'undefined' && localStorage.getItem(`checkout_${endConsumerId}`)){
          let storageObj = JSON.parse(localStorage.getItem(`checkout_${endConsumerId}`));
          formData.grandTotal = storageObj.grandTotal;
          formData.grandTotalInternational = storageObj.grandTotalInternational;
          formData.stripeCustomerId = storageObj.stripeCustomerId;
          formData.applicationFee = storageObj.applicationFee;
          formData.stripeFee = storageObj.stripeFee;
          formData.stripeFeeInternational = storageObj.stripeFeeInternational;
          formData.connectedAccount = storageObj.connectedAccount;
          formData.rechargeVal = storageObj.rechargeVal;
          formData.rechargeProcedure = storageObj.rechargeProcedure;
          formData.projectedTotalVal = storageObj.projectedTotalVal;
          formData.extraCredit = storageObj.extraCredit;
          formData.currentBalance = storageObj.currentBalance;
        }
        axios.post(`${process.env.serverUrl}do-prepaid-stripe-recharge`, formData).then((response) => {
          stripeform.classList.remove('submitting');   
          if(response.data.error == '1'){
            toast.error(response.data.message);
            stripeformPanel.style.display = "block";
            btnPay.style.display = "block";
          }else{
            //stripeform.classList.add('submitted');
            this.props.redirectToUrl(`/payment-success/${response.data.recordId}`);
          }  
        });        
      }
    } catch(e) {
        console.log('Error', e);
    }
   
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <div className="cell stripeform_panel stripeform">
            <div className="stripeform-panel">
              <PaymentSection />
            </div>
            <div className="success">
              <div className="icon">
                <div id="loader-wrapper"><div id="loader"></div></div>
                <svg width="84px" height="84px" viewBox="0 0 84 84" version="1.1" xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink">
                  <circle className="border" cx="42" cy="42" r="40" stroke-linecap="round" stroke-width="4" stroke="#000" fill="none"></circle>
                  <path className="checkmark" stroke-linecap="round" stroke-linejoin="round" d="M23.375 42.5488281 36.8840688 56.0578969 64.891932 28.0500338" stroke-width="4" stroke="#000" fill="none"></path>
                </svg>
              </div>
              <h3 className="title" data-tid="elements_examples.success.title">Payment successful</h3>
              <p className="message"><span data-tid="elements_examples.success.message">Thanks for recharging on Tapngo.</span></p>              
              <Link legacyBehavior href="/dashboard">
                <a>&lt;&lt; Back</a>
              </Link>
            </div>
          </div>
          <Button className="btn-pay" color="primary" variant="contained" type="submit" disabled={(!this.props.stripe)}>{ (!this.props.stripe) ? <Loader /> : null } Pay</Button>
        </form>
        
      </div>
    );
  }
}

export default function InjectedCheckoutForm(props) {
  console.log(props)
  return (
    <ElementsConsumer>
      {({ stripe, elements }) => (
        <RechargeForm 
          stripe={stripe} 
          elements={elements}  
          associateId={props.associateId} 
          endConsumerId={props.endConsumerId}
          rfidCardId={props.rfidCardId}
          redirectToUrl={props.redirectToUrl} />
      )}
    </ElementsConsumer>
  );
}
