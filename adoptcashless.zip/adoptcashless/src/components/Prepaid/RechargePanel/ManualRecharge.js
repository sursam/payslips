import React, {useState, useEffect, useContext} from 'react';
import styles from './RechargePanel.module.css';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import axios from "axios";
import Loader from '../../loader';
import GlobalContext from '../../GlobalContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import { useRouter } from 'next/router';

export default function ManualRecharge(props) {
  const [showOtherVal, setShowOtherVal] = useState(false);
  const [showLoader, setshowLoader] = useState(false);
  const [extraCredit, setExtraCredit] = useState(0);
  const [extraCreditVal, setExtraCreditVal] = useState(0);
  const [stripeFee, setStripeFee] = useState(0);
  const [stripeFeeInternational, setStripeFeeInternational] = useState(0);
  const [applicationFee, setApplicationFee] = useState(0);
  const manualRechargeAmounts = [100,200,500,1000,0];
  const [currentBalance, setCurrentBalance] = useState(props.currentCreditBalance);
  const [projectedTotalVal, setProjectedTotalVal] = useState(props.currentCreditBalance);
  const [receivedVal, setReceivedVal] = useState(0);
  const [surchargeVal, setSurchargeVal] = useState(0);
  const [grandTotalVal, setGrandTotalVal] = useState(0);
  const [surchargeValInternational, setSurchargeValInternational] = useState(0);
  const [grandTotalValInternational, setGrandTotalValInternational] = useState(0);
  const [connectedAccount, setConnectedAccount] = useState('');
  const [stripeCustomerId, setStripeCustomerId] = useState('');
  const router = useRouter();
  var [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('endConsumerId')) || '',
    rechargeType: 'manual',
    rechargeVal: -1
  });
  var { endConsumerId, rechargeType, rechargeVal } = state;
  const { stripeCreds } = useContext(GlobalContext);
  const { tngPercentAmount } = useContext(GlobalContext);
  
  useEffect(() => {
    axios.get(`${process.env.serverUrl}get-stripe-account/${endConsumerId}`,{}).then((response) => { 
      if(typeof response.data.records != 'undefined' && response.data.records.length > 0){ 
        let connectedAccount = (response.data.records[0].account_name__r != null) ? response.data.records[0].account_name__r.Stripe_Acc_Id__c : '';
        let stripeCustomeID = (response.data.records[0].Stripe_Customer_Id__c != null) ? response.data.records[0].Stripe_Customer_Id__c : '';
        setConnectedAccount(connectedAccount);
        setStripeCustomerId(stripeCustomeID);
      }
    }); 
    setManualRechargeValues({
      currentBalance: currentBalance, 
      rechargeVal: rechargeVal, 
    });
     
  }, 
  [])

  const onChangeRechargeVal = (e) => {
    e.preventDefault();
    setState(prevState => ({
      ...prevState,
      rechargeVal: e.target.value
    }));
    setManualRechargeValues({
        currentBalance: currentBalance, 
        //extraCredit: extraCredit, 
        rechargeVal: e.target.value,
    });
    if(e.target.value == 0){
      setShowOtherVal(true);
    }else{
      setShowOtherVal(false);
    }
  }

  const handleOtherRechargeVal = ({ target: { value } }) => {
    const re = /^[0-9\b]+$/;
    if (value === '' || re.test(value)) {
      setState(prevState => ({
        ...prevState,
        rechargeVal: value
      }));
      setManualRechargeValues({
        currentBalance: currentBalance, 
        //extraCredit: extraCredit, 
        rechargeVal: value ? value : 0,
      });
    }
  }

  var validationSchema = Yup.object().shape({});
  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const setManualRechargeValues = (...params) => {
    let rechargeVal = (parseFloat(params[0].rechargeVal) >= 0) ? parseFloat(params[0].rechargeVal) : 0;
    let extraCred = 0;
    if(props.extraCreditArr.length){
      props.extraCreditArr.forEach(extraCreditObj => {
        let minLimit = (extraCreditObj.Min_Limit__c != null) ? extraCreditObj.Min_Limit__c : 0;
        let maxLimit = (extraCreditObj.Max_Limit__c != null) ? extraCreditObj.Max_Limit__c : 0;
        if(between(rechargeVal, minLimit, maxLimit)){
          extraCred = extraCreditObj.Extra_Credit__c;
          setExtraCredit(extraCred);
          return;
        }
      });
    }
    //console.log(extraCred);

    let extraCreditVal = parseFloat(rechargeVal) * parseFloat(extraCred) / 100;
    let projectedTotalVal = parseFloat(params[0].currentBalance) + parseFloat(rechargeVal) + extraCreditVal;
    let receivedVal = parseFloat(rechargeVal) + extraCreditVal;
    let applicationFee = (tngPercentAmount * parseFloat(rechargeVal)) / 100;
    let stripeFee = calculateDomesticStripeFee((parseFloat(rechargeVal) + applicationFee));
    let surchargeVal = (rechargeVal > 0) ? (stripeFee + applicationFee) : 0;
    let grandTotalVal = parseFloat(rechargeVal) + surchargeVal;
    let stripeFeeInternational = calculateInternationsalStripeFee((parseFloat(rechargeVal) + applicationFee));
    let surchargeValInternational = (rechargeVal > 0) ? (stripeFeeInternational + applicationFee) : 0;
    let grandTotalValInternational = parseFloat(rechargeVal) + surchargeValInternational;    
    setExtraCreditVal(extraCreditVal);
    setProjectedTotalVal(projectedTotalVal);
    setReceivedVal(receivedVal);
    setStripeFee(stripeFee);
    setStripeFeeInternational(stripeFeeInternational);
    setApplicationFee(applicationFee);
    setSurchargeVal(surchargeVal);
    setGrandTotalVal(grandTotalVal);
    setSurchargeValInternational(surchargeValInternational);
    setGrandTotalValInternational(grandTotalValInternational);
  }

  const between = (x, min, max) => {
    return x >= min && x <= max;
  }

  const calculateDomesticStripeFee = (amount) => {
    let fixed = stripeCreds.fixedAmount;
    let percent = stripeCreds.domesticPercentAmount;
    let r = (100 - percent*100) / 100;
    let total = (amount + fixed) / r;
    let fee = total - amount;
    return fee;
  }
  const calculateInternationsalStripeFee = (amount) => {
    let fixed = stripeCreds.fixedAmount;
    let percent = stripeCreds.internationalPercentAmount;
    let r = (100 - percent*100) / 100;
    let total = (amount + fixed) / r;
    let fee = total - amount;
    return fee;
  }


  const [tabIndex, setTabIndex] = useState(0);

  const submitPay = () => {
    setshowLoader(true);
    if(!grandTotalVal){
      toast.error('Recharge amount is required');
    }else{
      let checkoutObj = {
        rechargeType: rechargeType,
        rechargeVal: rechargeVal,
        surchargeVal: surchargeVal,
        stripeFee: stripeFee,
        stripeFeeInternational: stripeFeeInternational,
        applicationFee: applicationFee,
        grandTotal: grandTotalVal,
        grandTotalInternational: grandTotalValInternational,
        surchargeInternational: surchargeValInternational,
        connectedAccount: connectedAccount,
        stripeCustomerId: stripeCustomerId,
        currentBalance: currentBalance,
        projectedTotalVal: projectedTotalVal,
        rechargeProcedure: 'Manual',
        extraCredit: extraCreditVal
      };
      localStorage.setItem(`checkout_${endConsumerId}`, JSON.stringify(checkoutObj));
      router.push('/checkout');
    }
    setshowLoader(false);
  };
  
  return (



    <div>
          
      
      <div className='priceRangeDiv'>
        <h4>Please choose the desired amount to recharge your card</h4>
        <dl className={styles.PriceRange} onChange={onChangeRechargeVal}>
          { manualRechargeAmounts.map((manualRechargeAmount) => (
            <dt>
              <input type="radio" className="rechargeVal" {...register('rechargeVal')} value={manualRechargeAmount} id={`val${manualRechargeAmount}`} />
              <label className={((rechargeVal == manualRechargeAmount) || (manualRechargeAmount == 0 && showOtherVal)) ? 'active' : ''} htmlFor="rechargeVal">{(manualRechargeAmount != 0) ? '$'+manualRechargeAmount : 'Other'}</label>
            </dt>
          )) }                                      
        </dl>
        <div className={`currencyDiv ${showOtherVal ? 'show' : 'hide'}`}>
          <input type="text" {...register('rechargeOtherVal')} value={(rechargeVal > 0) ? rechargeVal : ''} onChange={handleOtherRechargeVal} className={`form-control rechargeOtherVal ${errors.rechargeOtherVal ? 'is-invalid' : ''}`} />
        </div>
        <div className="invalid-feedback">{errors.rechargeOtherVal?.message}</div>
        {
          (rechargeVal > 0 && extraCredit > 0) ? 
            <div className={styles.ExtraCredit}><span>{extraCredit}% Extra Credit</span></div>
          : ''
        }
        
        <div className={styles.BalanceList}>
            <ul className={styles.ShowingBalance}>
              <li>Current Balance <span id='currentBalanceView'>${parseFloat(currentBalance).toFixed(2)}</span></li>
              <li className={styles.extraCredit}>Recharge Value <span>${(rechargeVal > 0) ? parseFloat(rechargeVal).toFixed(2) : (0).toFixed(2)}</span></li>
              <li>Extra Credit ({extraCredit}%) <span>${extraCreditVal.toFixed(2)}</span></li>
              <li className={styles.TotalPrice}>Projected Total (After Recharge)<span id='projectedTotalView'>${projectedTotalVal.toFixed(2)}</span></li>
            </ul> 
        </div>
        <div className={styles.ProceedPay}>
            <h5>Proceed to Pay</h5>
            <ul className={styles.PaymenyList}>
              <li>Recharge Value <strong>${(rechargeVal > 0) ? parseFloat(rechargeVal).toFixed(2) : 0}</strong></li>
              <span className={styles.PaymentSpan}>+</span>
              <li>

                  {/* =============== tab container start ============ */}
                    <div className='TabContainer'>
                      <Tabs selectedIndex={tabIndex} onSelect={(index) => setTabIndex(index)}>
                        {surchargeVal ?
                        <TabList>
                          <Tab>Domestic</Tab>
                          <Tab>International</Tab>
                        </TabList>
                        : ''}
                        <TabPanel>Surcharge <strong>${surchargeVal.toFixed(2)}</strong></TabPanel>
                        <TabPanel>Surcharge <strong>${surchargeValInternational.toFixed(2)}</strong></TabPanel>
                      </Tabs>
                    </div>
                {/* =============== tab container end ============ */}
                
                {/*<div className={styles.ReceiveInternationalPayment}>For international cards<br/> Surcharge: ${surchargeValInternational.toFixed(2)}<br/> Grand Total: ${grandTotalValInternational.toFixed(2)}</div>*/}
              </li>
              <span className={styles.PaymentSpan}>=</span>
              <li>
                Grand Total <strong>${(tabIndex == 0) ? grandTotalVal.toFixed(2) : grandTotalValInternational.toFixed(2)}</strong>
                <div className={styles.ReceivePayment}>You will receive: ${receivedVal.toFixed(2)}</div>
              </li>
              <input type="hidden" {...register('endConsumerId')} value={endConsumerId}/>
              <Button color="primary" variant="contained" type="button" onClick={submitPay} disabled={showLoader} >{ showLoader ? <Loader /> : null } Pay Now </Button>
            </ul>                
        </div>
      </div>

      


    </div>

        


  );
}
