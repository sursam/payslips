import React from "react";
import { PaymentElement } from "@stripe/react-stripe-js";

const PAYMENT_ELEMENT_OPTIONS = {
  style: {
    base: {
      color: "#303238",
      fontSize: "16px",
      fontFamily: "sans-serif",
      fontSmoothing: "antialiased",
      "::placeholder": {
        color: "#CFD7DF"
      }
    },
    invalid: {
      color: "#e5424d",
      ":focus": {
        color: "#303238"
      }
    }
  }
};

function PaymentSection() {
  return (
    <PaymentElement options={PAYMENT_ELEMENT_OPTIONS} />
  );
}
export default PaymentSection;