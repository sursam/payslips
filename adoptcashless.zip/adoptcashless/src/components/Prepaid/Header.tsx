import React, {useState, useEffect} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../../styles/Prepaid.module.css';
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
import Link from 'next/link';
import { useRouter } from 'next/router';
import { ToastContainer } from 'react-toastify';

export default function Header() { 
  //var [supportCases, setSupportCases] = useState<any[]>([]);
    const [authenticated, setAuthenticated] = useState(0);    
    const accountClick = () => {
        document.body.classList.toggle('SlideToggle');
        document.body.classList.remove('SupportCasesToggle');
    };

    /*const SupportCasesClick  = () => {
      document.body.classList.toggle('SupportCasesToggle');
      document.body.classList.remove('SlideToggle');
    };*/

    const [logo, setLogo] = useState('');

    const router = useRouter();
    const loggingOut = () => {
      localStorage.removeItem("authenticated");
      localStorage.removeItem("associateId");
      localStorage.removeItem("endConsumerId");
      localStorage.removeItem("userId");
      router.push('/auth');
    };
    
    useEffect(() => {  
      const auth:any = (typeof localStorage !== 'undefined' && localStorage.getItem('authenticated')) || 0;
      setAuthenticated(auth);    
      if(!auth)
      {
        router.push('/auth');
      }

      axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
        setLogo(response.data.logo);   
      });

      //getSupportCase();

    }, 
    [])

    /*const getSupportCase = () => {
      axios.get(`${process.env.serverUrl}get-active-support-cases/${endConsumerId}`,{}).then((response) => {  
          //console.log(response.data); 
          setSupportCases(response.data);   
      });
    }*/

  return (
    <section className={styles.topSection}>
      <ToastContainer
          position="top-right"
          autoClose={10000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
      />
      <section className={styles.mainWrap}>
          <div className={styles.LogoAccount}>
              <figure className={styles.leftLogo}>
                {logo ? 
                  <img src={`/uploads/logo/${logo}`} alt="" />
                : ''}
              </figure>
              {authenticated ? 
                <div className={styles.Authsection}>
                  <button >Support Cases <Icon.ChatDots /></button>
                  {/* ================== Support Cases =============== */}
                  <div className="SupportCases">
                    <ul>
                      <li>
                        <aside>
                          No record found
                        </aside>
                      </li>
                    </ul>
                  </div>
                  {/* ================== Support Cases end=============== */}
                  <div className={styles.userImage}>
                    <figure>
                      <Link legacyBehavior href="#">
                        <a onClick={accountClick}>
                          <img src='/assets/images/user-image.jpg' alt="" />
                        </a>
                      </Link>
                    </figure>
                    {/* =============== My account section ================= */}
                    <div className="MyAccountPopUp" onClick={accountClick}>
                      <ul>
                        <li><Link legacyBehavior href="#"><a><Icon.PersonFill/> My Account</a></Link></li>
                        <li><Link legacyBehavior href="#"><a><Icon.Printer/> Recharge History</a></Link></li>
                        <li><Link legacyBehavior href="#"><a><Icon.Gear/> Settings</a></Link></li>
                        <li><Link legacyBehavior href="#"><a onClick={loggingOut}><Icon.LockFill/> Logout</a></Link></li>
                      </ul>
                    </div>
                    {/* =============== My account section end ================= */}
                  </div>
                </div>
              : ''}
          </div>
      </section>
    </section>
    );
}