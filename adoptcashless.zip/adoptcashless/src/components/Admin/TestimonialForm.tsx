import React, {useState, useEffect, useContext} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../errorSummary';
import Loader from '../loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
import dynamic from "next/dynamic";
import { Button } from "@material-ui/core";
//import { Button } from '@paljs/ui/Button';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
//import { useRouter } from 'next/router';

const TestimonialForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  //const router = useRouter();
  const JoditEditor:any = dynamic(() => import("jodit-react"), { ssr: false });
  const config:any = 
		{
			readonly: false, // all options from https://xdsoft.net/jodit/doc/,
			placeholder: 'Start typings...',
      width: '100%',
      height: 400,
      askBeforePasteFromWord: false, 
      askBeforePasteHTML: false
		};
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false)
  const [state, setState] = useState({
    id: '',
    title: '',
    sub_title: '',
    name: '',
    content: '',
    author_name: '',
    author_designation: '',
    meta_title: '',
    meta_keywords: '',
    meta_description: '',
  });
  const { id, title, sub_title, name, content, author_name, author_designation, meta_title, meta_keywords, meta_description } = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      title: dataVal.title,
      sub_title: dataVal.sub_title,
      name: dataVal.name,
      content: dataVal.content,
      author_name: dataVal.author_name,
      author_designation: dataVal.author_designation,
      meta_title: dataVal.meta_title,
      meta_keywords: dataVal.meta_keywords,
      meta_description: dataVal.meta_description,
    }));
  }, [])
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };
  const handleTextAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };
  const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }

  var validationSchema = Yup.object().shape({
    name: Yup.string()
        .required('Name is required'),
    content: Yup.string()
        .required('Content is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-testimonial`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        //localStorage.setItem("authenticated", response.data.status);
        //router.push('/dashboard');
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='testimonial-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={title}>Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('title')} value={title} onChange={handleChange} placeholder="Title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={sub_title}>Sub Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('sub_title')} value={sub_title} onChange={handleChange} placeholder="Sub Title" className={`form-control ${errors.sub_title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.sub_title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={name}>Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('name')} value={name} onChange={handleChange} placeholder="Name" className={`form-control ${errors.name ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.name?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={content}>Content</label>
            <InputGroup className='form-group editor-group' fullWidth>
              
              <JoditEditor          
                value={content} 
                config={config}
                onBlur={handleContent}
                //tabIndex={1} // tabIndex of textarea
                //onBlur={newContent => setcontent(newContent)} // preferred to use only this option to update the content for performance reasons
                //onChange={newContent => {}}
              />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={author_name}>Author Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('author_name')} value={author_name} onChange={handleChange} placeholder="Author Name" className={`form-control ${errors.author_name ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.author_name?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={author_designation}>Author Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('author_designation')} value={author_designation} onChange={handleChange} placeholder="Author Designation" className={`form-control ${errors.author_designation ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.author_designation?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_title}>Meta Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_title')} value={meta_title} onChange={handleChange} placeholder="Meta Title" className={`form-control ${errors.meta_title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_keywords}>Meta Keywords</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_keywords')} value={meta_keywords} onChange={handleChange} placeholder="Meta Keywords" className={`form-control ${errors.meta_keywords ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_keywords?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_description}>Meta Description</label>
            <InputGroup className='form-group' fullWidth>  
              <textarea
                {...register('meta_description')}
                value={meta_description}
                onChange={handleTextAreaChange}
                placeholder="Meta Description"
                className={`form-control ${errors.meta_description ? 'is-invalid' : ''}`}
              />  
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_description?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
          <input type="hidden" {...register('id')} value={id} onChange={handleChange} className={`form-control ${errors.id ? 'is-invalid' : ''}`} />
        </Row>
      </form>
    </>
  );
};
export default TestimonialForm;
