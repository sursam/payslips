import React, {useState, useEffect} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
/*import dynamic from "next/dynamic";*/
import { Button } from "@material-ui/core";
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';

const BannerForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, getImageName] = useState(false);
  const [state, setState] = useState({
    id: '',
    bannerTitle: '',
    bannerImage: '',
    bannerStatus: '',
  });
  const { id, bannerTitle, bannerImage, bannerStatus} = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      bannerTitle: dataVal.bannerTitle,
      bannerImage: dataVal.bannerImage,
      bannerStatus: dataVal.bannerStatus,
    }));
  }, [])

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));

  };

  /*const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }*/

const handleStatusChange =(event:any) => {
  const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
}

const onUploadHandler  = (event:any) => {
     const data = new FormData();
      data.append('myfile', event.target.files[0]);
    axios.post(`${process.env.serverUrl}upload-banner-image`, data).then((response) => { 
      getImageName(response.data);
   });
  };

  var validationSchema = Yup.object().shape({
    bannerTitle: Yup.string()
        .required('Banner title is required'),
  });

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-banner`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='banner-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={bannerTitle}>Banner Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('bannerTitle')} value={bannerTitle} onChange={handleChange} placeholder="Title" className={`form-control ${errors.bannerTitle ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.bannerTitle?.message?.toString()}</div>
          </Col>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={bannerImage}>Banner Image <span>(.jpg, .jpeg, .png)</span></label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="file" name="myfile" onChange={onUploadHandler} className="form-control" />
              <input type="hidden" {...register('bannerImageName')} id="hidden-img" value={`${imageName ? imageName : bannerImage}`} />
            </InputGroup>

            <img className="prevImg" src = {`${imageName ? `/uploads/banner/${imageName}` : bannerImage ? `/uploads/banner/${bannerImage}` : '/assets/images/no-image.png' }` } />
          </Col>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={bannerStatus}>Status</label>
            <InputGroup className='form-group' fullWidth>                      
              <select {...register('bannerStatus')} value={`${bannerStatus ? bannerStatus : 'active'}`} className={`form-control ${errors.bannerStatus ? 'is-invalid' : ''}`} onChange={handleStatusChange} >
                <option value = "1">Active</option>
                <option value = "0">Inactive</option>
              </select>
            </InputGroup>
          </Col>
          
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
        </Row>
      </form>
    </>
  );
};
export default BannerForm;
