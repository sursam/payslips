import React, {useState, useEffect} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../errorSummary';
import Loader from '../loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
import dynamic from "next/dynamic";
import { Button } from "@material-ui/core";
//import { Button } from '@paljs/ui/Button';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
import { useRouter } from 'next/router';

const PageForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  const router = useRouter();
  const JoditEditor:any = dynamic(() => import("jodit-react"), { ssr: false });
  const config:any = 
  {
    readonly: false, // all options from https://xdsoft.net/jodit/doc/,
    placeholder: 'Start typings...',
    width: '100%',
    height: 400,
    askBeforePasteFromWord: false, 
    askBeforePasteHTML: false
  }
  const [fields, setFields] = useState([]);  
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, setImageName] = useState(false);
  //const [content, setContent] = useState("");
  const [customData, setCustomData]:any = useState([]);
  const [state, setState] = useState({
    id: '',
    pageName: '',
    slug: '',
    innerBannerImage: '',
    pageTitle: '',
    pageContent: '',
    metaTitle: '',
    metaKeyword: '',
    metaDescription: ''
  });

  const { id, pageName, slug, pageTitle, innerBannerImage, pageContent, metaTitle, metaKeyword, metaDescription } = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      slug: dataVal.slug,
      pageName: dataVal.pageName,
      innerBannerImage: dataVal.innerBannerImage,
      pageTitle: dataVal.pageTitle,
      pageContent: dataVal.pageContent,
      metaTitle: dataVal.metaTitle,
      metaKeyword: dataVal.metaKeyword,
      metaDescription: dataVal.metaDescription,
    }));

        const getfields = async() => 
        {
            axios.post(`${process.env.serverUrl}get-page-field/`,{id: dataVal.id}).then((response) => {
                const customVal:any = [];
                for (var data of response.data) {
                  customVal[data.slug] = data.meta_value;
                  setState(prevState => ({
                    ...prevState,
                    [data.slug]: data.meta_value,
                  }));
                }
                setCustomData(customVal);
                console.log(customVal);
                setFields(response.data); 
            });
        }
        getfields();
        
  }, [])

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };

  const handleTextAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    //console.log(value)
  };
  const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      pageContent: newValue,
    }));
  }  

  let handleEditorChange = (key:any, newContent:any)=>{
    customData[key] = newContent
    setState(prevState => ({
      ...prevState,
      [key]: newContent,
    }));
  }
  const editorConfig = (name:any)=>{
    const edconfig:any = 
    {
      readonly: false, // all options from https://xdsoft.net/jodit/doc/,
      placeholder: 'Start typings...',
      width: '100%',
      height: 400,
      id: name,
      name: name
    }
    return edconfig;
  }

    const onUploadHandler=(event:any)=>{
     const data = new FormData();
      data.append('myfile', event.target.files[0]);
    axios.post(`${process.env.serverUrl}upload-page-banner-image`, data).then((response) => { 
      setImageName(response.data);
   });
  };    

  const onImageUploadHandler=(event:any)=>{
        //console.log(event.target.name); return false;
        const fieldName = event.target.getAttribute('data-name');
     const data = new FormData();
    data.append('myfile', event.target.files[0]);

    axios.post(`${process.env.serverUrl}upload-page-field-image`, data).then((response) => { 
       
      //setImageName(response.data);
      setState(prevState => ({
        ...prevState,
        [fieldName]: response.data,
      }));
      customData[fieldName] = response.data
      console.log(fieldName);
      console.log(response.data);
    });
  };

  var validationSchema = Yup.object().shape({
    pageName: Yup.string()
        .required('Page name is required'),
    pageTitle: Yup.string()
        .required('Page title is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);
    axios.post(`${process.env.serverUrl}save-page`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
        router.push('/cms/edit-page/'+response.data.slug);
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='cms-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={pageName}>Page Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('pageName')} value={pageName} onChange={handleChange} placeholder="Page Name" className={`form-control ${errors.pageName ? 'is-invalid' : ''}`}  autoComplete="off" />
            </InputGroup>
            <div className="invalid-feedback">{errors.pageName?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={pageTitle}>Page Title</label>
            <InputGroup className='form-group' fullWidth>
              <input type="text" {...register('pageTitle')} value={pageTitle} onChange={handleChange} placeholder="Page Title" className={`form-control ${errors.pageTitle ? 'is-invalid' : ''}`} autoComplete="off" />
            </InputGroup>
            <div className="invalid-feedback">{errors.pageTitle?.message}</div>
          </Col>
          {(slug != "home") ?
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={innerBannerImage}>Banner Image <span>(.jpg, .jpeg, .png)</span></label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="file" name="myfile" onChange={onUploadHandler} className="form-control" />
              <input type="hidden" {...register('bannerImageName')} id="hidden-img" value={`${imageName ? imageName : innerBannerImage}`} />
            </InputGroup>

            <img className="prevImg" src = {`${imageName ? `/uploads/banner/${imageName}` : innerBannerImage ? `/uploads/banner/${innerBannerImage}` : '/assets/images/no-image.png' }` } />

          </Col>
          : '' }
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={pageContent}>Page Content</label>
            <InputGroup className='form-group editor-group' fullWidth>
              
              <JoditEditor          
                value={pageContent} 
                config={config}
                onBlur={handleContent}
                //tabIndex={1} // tabIndex of textarea
                //onBlur={newContent => setPageContent(newContent)} // preferred to use only this option to update the content for performance reasons
                //onChange={newContent => {}}
              />
            </InputGroup>
          </Col>

          {fields.map((getfields:any) => ( 
            <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={getfields.slug}>{getfields.title}</label>
            <InputGroup className={(getfields.field_type == "textarea") ? 'form-group editor-group' : 'form-group'} fullWidth>                      
              {(getfields.field_type == "textinput") ?
                <input type="text" {...register(getfields.slug)} defaultValue={getfields.meta_value}  placeholder={getfields.title} className='form-control' autoComplete="off"/>
               : '' }
                 
              {(getfields.field_type == "textarea") ? 

                <JoditEditor 
                  key = {getfields.slug}
                  data-name = {getfields.slug}        
                  value={customData[getfields.slug]} 
                  config={editorConfig(getfields.slug)}
                  onBlur={(newContent:any) => handleEditorChange(getfields.slug, newContent)}
                />
               /*<textarea {...register(getfields.slug)} defaultValue={getfields.meta_value}  placeholder={getfields.title} className='form-control' autoComplete="off"/>*/

               : '' }
            </InputGroup>

            {(getfields.field_type == "image") ? 
            <InputGroup className='form-group' key={getfields.slug} fullWidth>                          
              <p><input type="file" name={`file_${getfields.slug}`} data-name={getfields.slug} onChange={onImageUploadHandler} className="form-control" />
               <input type="hidden" {...register(getfields.slug)} id={`hidden-img-${getfields.slug}`} value={customData[getfields.slug]} /></p>
               <p><img className="prevImg" src = {customData[getfields.slug] ? `/uploads/pages/${customData[getfields.slug]}` : '/assets/images/no-image.png' } /></p>
            </InputGroup>
               : '' }

          </Col>
          ))}  

          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={metaTitle}>Meta Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('metaTitle')} value={metaTitle} onChange={handleChange} placeholder="Meta Title" className={`form-control ${errors.metaTitle ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.metaTitle?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={metaKeyword}>Meta Keywords</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('metaKeyword')} value={metaKeyword} onChange={handleChange} placeholder="Meta Keywords" className={`form-control ${errors.metaKeyword ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.metaKeyword?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={metaDescription}>Meta Description</label>
            <InputGroup className='form-group' fullWidth>  
              <textarea
                {...register('metaDescription')}
                value={metaDescription}
                onChange={handleTextAreaChange}
                placeholder="Meta Description"
                className={`form-control ${errors.metaDescription ? 'is-invalid' : ''}`}
              />  
            </InputGroup>
            <div className="invalid-feedback">{errors.metaDescription?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
          <input type="hidden" {...register('id')} value={id} onChange={handleChange} className={`form-control ${errors.id ? 'is-invalid' : ''}`} />
        </Row>
      </form>
    </>
  );
};
export default PageForm;
