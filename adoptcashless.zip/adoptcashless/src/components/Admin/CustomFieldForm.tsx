import React, {useState, useEffect, useContext} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
/*import dynamic from "next/dynamic";*/
import { Button } from "@material-ui/core";
//import { Button } from '@paljs/ui/Button';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';
/*import { useRouter } from 'next/router';*/

const CustomFieldForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  /*const router = useRouter();*/
  const [pages, setPages] = useState([]);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false)
  const [state, setState] = useState({
    id: '',
    page_id: '',
    title: '',
    field_type: '',
    meta_value: '',
    added_on: '',
    status: '',
  });
  const { id, page_id, title, field_type, status } = state;

  useEffect(() => {

     const getpages = async() => 
    {
        axios.post(`${process.env.serverUrl}get-all-page`).then((response) => {
        setPages(response.data);   
      });
    }

    getpages();

    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      page_id: dataVal.page_id,
      title: dataVal.title,
      field_type: dataVal.field_type,
      meta_value: dataVal.meta_value,
      added_on: dataVal.added_on,
      status: dataVal.status,
    }));
  }, 

  [])

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  /*const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }*/

  const handleStatusChange =(event:any) => {
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  }

  var validationSchema = Yup.object().shape({
    title: Yup.string().required('Title is required'),
    field_type: Yup.string().required('Field type is required'),
    page_id: Yup.string().required('Page is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-custom-field`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='custom-field-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
              <label htmlFor={page_id}>Select Page</label>
              <InputGroup className='form-group' fullWidth>                      
                <select {...register('page_id')} value={`${page_id ? page_id : ''}`} className={`form-control ${errors.page_id ? 'is-invalid' : ''}`} onChange={handleStatusChange}>
                 <option value = "">Select Page</option>
                 {pages.map((getpages:any) => (
                  <option value = {getpages.id}>{getpages.pageName}</option>
                  ))}
                </select>

              </InputGroup>
              <div className="invalid-feedback">{errors.page_id?.message}</div>
            </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={title}>Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('title')} value={title} onChange={handleChange} placeholder="Title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} autoComplete ="off" />
            </InputGroup>
            <div className="invalid-feedback">{errors.title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={field_type}>Field Type</label>
            <InputGroup className='form-group' fullWidth>                      
              <select {...register('field_type')} value={`${field_type ? field_type : ''}`} className={`form-control ${errors.field_type ? 'is-invalid' : ''}`} onChange={handleStatusChange}>
                <option value = "">Select Field Type</option>
                <option value = "textinput">Text</option>
                <option value = "textarea">Textarea</option>
                <option value = "image">Image</option>
              </select>
            </InputGroup>
            <div className="invalid-feedback">{errors.field_type?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={status}>Status</label>
            <InputGroup className='form-group' fullWidth>                      
              <select {...register('status')} value={`${status ? status : 'active'}`} className={`form-control ${errors.status ? 'is-invalid' : ''}`} onChange={handleStatusChange}>
                <option value = "active">Active</option>
                <option value = "inactive">Inactive</option>
              </select>
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
        </Row>
      </form>
    </>
  );
};
export default CustomFieldForm;
