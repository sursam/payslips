import React, {useState, useEffect, useContext} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
import dynamic from "next/dynamic";
import { Button } from "@material-ui/core";
//import { Button } from '@paljs/ui/Button';
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';

const NewsForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  const JoditEditor:any = dynamic(() => import("jodit-react"), { ssr: false });
  const config:any = 
		{
			readonly: false, // all options from https://xdsoft.net/jodit/doc/,
			placeholder: 'Start typings...',
      width: '100%',
      height: 400,
      askBeforePasteFromWord: false, 
      askBeforePasteHTML: false
		};
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, getImageName] = useState(false);
  const [state, setState] = useState({
    id: '',
    title: '',
    sub_title: '',
    short_content: '',
    content: '',
    featured_image: '',
    author: '',
    author_designation: '',
    published_at: '',
    meta_title: '',
    meta_keywords: '',
    meta_description: '',
  });
  const { id, title, sub_title, short_content, content,featured_image, author, author_designation, published_at, meta_title, meta_keywords, meta_description } = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      title: dataVal.title,
      sub_title: dataVal.sub_title,
      short_content: dataVal.short_content,
      content: dataVal.content,
      featured_image: dataVal.featured_image,
      author: dataVal.author,
      author_designation: dataVal.author_designation,
      published_at: dataVal.published_at,
      meta_title: dataVal.meta_title,
      meta_keywords: dataVal.meta_keywords,
      meta_description: dataVal.meta_description,
    }));
  }, [])
  
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleTextAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const onUploadHandler  = (event:any) => {
    //console.log(event.target.files[0])

     const data = new FormData();

      data.append('myfile', event.target.files[0]);

    axios.post(`${process.env.serverUrl}upload-news-image`, data).then((response) => { 
      getImageName(response.data);
   });
  };

  const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }

  var validationSchema = Yup.object().shape({
    title: Yup.string()
        .required('Name is required'),
    short_content: Yup.string()
        .required('Short content is required'),
    content: Yup.string()
        .required('Content is required'),
    published_at: Yup.string()
        .required('publish date is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);
       axios.post(`${process.env.serverUrl}save-news`, formData).then((response) => {  
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='news-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={title}>Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('title')} value={title} onChange={handleChange} placeholder="Title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={sub_title}>Sub Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('sub_title')} value={sub_title} onChange={handleChange} placeholder="Sub Title" className={`form-control ${errors.sub_title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.sub_title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={content}>Short Content</label>
            <InputGroup className='form-group' fullWidth>
              <textarea {...register('short_content')} value={short_content} onChange={handleTextAreaChange} placeholder="Short Content" className={`form-control ${errors.short_content ? 'is-invalid' : ''}`} />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={content}>Content</label>
            <InputGroup className='form-group editor-group' fullWidth>
              
              <JoditEditor          
                value={content} 
                config={config}
                onBlur={handleContent}
              />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={featured_image}>Featured Image <span>(.jpg, .jpeg, .png)</span></label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="file" name="myfile" onChange={onUploadHandler} className="form-control" />
              <input type="hidden" {...register('featured_image_name')} id="hidden-img" value={`${imageName ? imageName : featured_image ? featured_image : ''}`} />
            </InputGroup>
            <img className="prevImg" src = {`${imageName ? `/uploads/news/${imageName}` : featured_image ? `/uploads/news/${featured_image}` : '/assets/images/no-image.png' }` } />
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={author}>Author Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('author')} value={author} onChange={handleChange} placeholder="Author Name" className="form-control" />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={author_designation}>Author Designation</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('author_designation')} value={author_designation} onChange={handleChange} placeholder="Author Designation" className="form-control" />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={published_at}>Published At</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="date" {...register('published_at')} value={published_at} onChange={handleChange} placeholder="Published At" className="form-control" />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_title}>Meta Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_title')} value={meta_title} onChange={handleChange} placeholder="Meta Title" className="form-control" />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_keywords}>Meta Keywords</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_keywords')} value={meta_keywords} onChange={handleChange} placeholder="Meta Keywords" className="form-control" />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_description}>Meta Description</label>
            <InputGroup className='form-group' fullWidth>  
              <textarea
                {...register('meta_description')}
                value={meta_description}
                onChange={handleTextAreaChange}
                placeholder="Meta Description"
                className={`form-control ${errors.meta_description ? 'is-invalid' : ''}`}
              />  
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_description?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
          <input type="hidden" {...register('id')} value={id} onChange={handleChange} className={`form-control ${errors.id ? 'is-invalid' : ''}`} />
        </Row>
      </form>
    </>
  );
};
export default NewsForm;
