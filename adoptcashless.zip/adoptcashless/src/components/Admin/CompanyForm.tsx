import React, {useState, useEffect, useContext} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
/*import dynamic from "next/dynamic";*/
import { Button } from "@material-ui/core";
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';

const CompanyForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false);
  const [imageName, getImageName] = useState(false);
  const [state, setState] = useState({
    id: '',
    companyTitle: '',
    companyImage: '',
    companyStatus: '',
  });
  const { id, companyTitle, companyImage, companyStatus} = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      companyTitle: dataVal.companyTitle,
      companyImage: dataVal.companyImage,
      companyStatus: dataVal.companyStatus,
    }));
  }, [])
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));

  };
  /*const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }*/

  const handleStatusChange =(event:any) => {
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  }

  const onUploadHandler  = (event:any) => {
     const data = new FormData();
      data.append('myfile', event.target.files[0]);
    axios.post(`${process.env.serverUrl}upload-company-image`, data).then((response) => { 
      getImageName(response.data);
   });
  };

  var validationSchema = Yup.object().shape({
    companyTitle: Yup.string()
        .required('Company title is required'),
  });

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-company`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='company-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={companyTitle}>company Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('companyTitle')} value={companyTitle} onChange={handleChange} placeholder="Title" className={`form-control ${errors.companyTitle ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.companyTitle?.message}</div>
          </Col>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={companyImage}>company Image <span>(.jpg, .jpeg, .png)</span></label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="file" name="myfile" onChange={onUploadHandler} className="form-control" />
              <input type="hidden" {...register('companyImageName')} id="hidden-img" value={`${imageName ? imageName : companyImage}`} />
            </InputGroup>

            <img className="prevImg" src = {`${imageName ? `/uploads/company/${imageName}` : companyImage ? `/uploads/company/${companyImage}` : '/assets/images/no-image.png' }` } />
          </Col>

          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={companyStatus}>Status</label>
            <InputGroup className='form-group' fullWidth>                      
              <select {...register('companyStatus')} value={`${companyStatus ? companyStatus : 'active'}`} className={`form-control ${errors.companyStatus ? 'is-invalid' : ''}`} onChange={handleStatusChange}>
                <option value = "1">Active</option>
                <option value = "0">Inactive</option>
              </select>
            </InputGroup>
          </Col>
          
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
        </Row>
      </form>
    </>
  );
};
export default CompanyForm;
