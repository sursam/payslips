import React, {useState, useEffect} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import { InputGroup } from '@paljs/ui/Input';

const enquiryDetails = ({dataVal}:any) => {
  const [state, setState] = useState({
    first_name: '',
    last_name: '',
    mobile_no: '',
    email: '',
    best_contactable_time: '',
    company_name: '',
    trading_name: '',
    abn: '',
    acn: '',
    address: '',
    industry_type: '',
    credit_card: '',
    message: '',
  });
  const {first_name, last_name, mobile_no, email, best_contactable_time, company_name, trading_name, abn, acn, address, industry_type, credit_card, message} = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      first_name: dataVal.first_name,
      last_name: dataVal.last_name,
      mobile_no: dataVal.mobile_no,
      email: dataVal.email,
      best_contactable_time: dataVal.best_contactable_time,
      company_name: dataVal.company_name,
      trading_name: dataVal.trading_name,
      abn: dataVal.abn,
      acn: dataVal.acn,
      address: dataVal.address,
      industry_type: dataVal.industry_type,
      credit_card: dataVal.credit_card,
      message: dataVal.message,
    }));
  }, [])

  return (
    <>
      <form className='enquiry-form'>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={first_name}>First Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={first_name} placeholder="First Name" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={last_name}>Last Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={last_name} placeholder="Last Name" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={mobile_no}>Mobile No</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={mobile_no} placeholder="Mobile No" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={email}>Email ID</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={email} placeholder="Email ID" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={best_contactable_time}>Best Contactable Time</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={best_contactable_time} placeholder="Best Contactable Time" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={company_name}>Company Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={company_name} placeholder="Company Name" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={trading_name}>Trading Name</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={trading_name} placeholder="Trading Name" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={abn}>ABN</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={abn} placeholder="ABN" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={acn}>ACN</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={acn} placeholder="ACN" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={address}>Address</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={address} placeholder="Address" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={industry_type}>Industry Type</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={industry_type} placeholder="Industry Type" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 6 }}>
            <label htmlFor={credit_card}>Credit Card</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" value={credit_card} placeholder="Credit Card" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={message}>Message</label>
            <InputGroup className='form-group' fullWidth>                      
              <textarea value={message} placeholder="Message" className={`form-control`} readOnly />
            </InputGroup>
          </Col>
        </Row>
      </form>
    </>
  );
};
export default enquiryDetails;
