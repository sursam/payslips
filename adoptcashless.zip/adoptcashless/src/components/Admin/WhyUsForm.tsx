import React, {useState, useEffect, useContext} from 'react';
import Row from '@paljs/ui/Row';
import Col from '@paljs/ui/Col';
import ErrorSummary from '../../components/errorSummary';
import Loader from '../../components/loader';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { InputGroup } from '@paljs/ui/Input';
import dynamic from "next/dynamic";
import { Button } from "@material-ui/core";
import axios from "axios";
//import GlobalContext from '../../components/GlobalContext';

const WhyUsForm = ({dataVal}:any) => {
  //const { serverUrl } = useContext(GlobalContext);
  const JoditEditor:any = dynamic(() => import("jodit-react"), { ssr: false });
  const config:any = 
		{
			readonly: false,
			placeholder: 'Start typings...',
      width: '100%',
      height: 400,
      askBeforePasteFromWord: false, 
      askBeforePasteHTML: false
		};
  const [validationErrors, setvalidationErrors] = useState(null);
  const [successMessage, setsuccessMessage] = useState(null);
  const [showLoader, setshowLoader] = useState(false)
  const [state, setState] = useState({
    id: '',
    title: '',
    content: '',
    meta_title: '',
    meta_keywords: '',
    meta_description: '',
  });
  const { id, title, content, meta_title, meta_keywords, meta_description } = state;

  useEffect(() => {
    setState(prevState => ({
      ...prevState,
      id: dataVal.id,
      title: dataVal.title,
      content: dataVal.content,
      meta_title: dataVal.meta_title,
      meta_keywords: dataVal.meta_keywords,
      meta_description: dataVal.meta_description,
    }));
  }, [])
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleTextAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleContent = (newValue:any) => {    
    setState(prevState => ({
      ...prevState,
      content: newValue,
    }));
  }

  var validationSchema = Yup.object().shape({
    title: Yup.string()
        .required('Title is required'),
    content: Yup.string()
        .required('Content is required'),
  });
  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData:any) => {
    setshowLoader(true);  
    axios.post(`${process.env.serverUrl}save-whyus`, formData).then((response) => {
      setshowLoader(false)
      if(!response.data.error){
        setvalidationErrors(null);
        setsuccessMessage(response.data.message);  
      }else{
        setsuccessMessage(null);
        setvalidationErrors(response.data.error);
      }        
    });
  };
  
  return (
    <>
      <ErrorSummary errors={validationErrors} success={successMessage} />
      <form className='whyus-form' onSubmit={handleSubmit(onSubmit)}>
        <Row>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={title}>Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('title')} value={title} onChange={handleChange} placeholder="Title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={content}>Content</label>
            <InputGroup className='form-group editor-group' fullWidth>
              
              <JoditEditor          
                value={content} 
                config={config}
                onBlur={handleContent}
                //tabIndex={1} // tabIndex of textarea
                //onBlur={newContent => setcontent(newContent)} // preferred to use only this option to update the content for performance reasons
                //onChange={newContent => {}}
              />
            </InputGroup>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_title}>Meta Title</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_title')} value={meta_title} onChange={handleChange} placeholder="Meta Title" className={`form-control ${errors.meta_title ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_title?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_keywords}>Meta Keywords</label>
            <InputGroup className='form-group' fullWidth>                      
              <input type="text" {...register('meta_keywords')} value={meta_keywords} onChange={handleChange} placeholder="Meta Keywords" className={`form-control ${errors.meta_keywords ? 'is-invalid' : ''}`} />
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_keywords?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <label htmlFor={meta_description}>Meta Description</label>
            <InputGroup className='form-group' fullWidth>  
              <textarea
                {...register('meta_description')}
                value={meta_description}
                onChange={handleTextAreaChange}
                placeholder="Meta Description"
                className={`form-control ${errors.meta_description ? 'is-invalid' : ''}`}
              />  
            </InputGroup>
            <div className="invalid-feedback">{errors.meta_description?.message}</div>
          </Col>
          <Col className='form-col' breakPoint={{ xs: 12, lg: 12 }}>
            <input type="hidden" name="id" value={id} />
            <Button color="primary"
              variant="contained"
              type="submit"
              onClick={submitForm} 
              //onClick={() => reset()} 
              disabled={showLoader} >
              { showLoader ? <Loader /> : null } Submit
            </Button>
          </Col>
          <input type="hidden" {...register('id')} value={id} onChange={handleChange} className={`form-control ${errors.id ? 'is-invalid' : ''}`} />
        </Row>
      </form>
    </>
  );
};
export default WhyUsForm;
