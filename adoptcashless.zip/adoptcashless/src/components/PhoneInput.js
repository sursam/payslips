import InputMask from 'react-input-mask';
export default function PhoneInput(props) {

  return (
    <InputMask 
      mask='9999 999 999' 
      value={props.value} 
      name={props.name} 
      className={props.className}
      onChange={props.onChange}
      onBlur={props.onBlur}
      type="text">
    </InputMask>
  );
}
