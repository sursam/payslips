import * as Icon from 'react-bootstrap-icons';
import { useState } from "react";
export default function ToggleSwitch({ label, toggled, onClick }) { 
  const [isToggled, toggle] = useState(toggled);
  const callback = () => {
    toggle(!isToggled);
    onClick(!isToggled);
  };
  return (
    <div className="toggle-switch">
      <label>
        <input type="checkbox" defaultChecked={isToggled} onClick={callback}/>
        <span></span>
        <strong><Icon.ArrowClockwise/>{label}</strong>
      </label>
    </div>
  );
}
