import styled from 'styled-components';
import { Card, CardBody } from '@paljs/ui/Card';
import { breakpointDown } from '@paljs/ui/breakpoints';
import React, {useState, useEffect} from 'react';
import axios from "axios";

const AuthStyle = styled.div<{ subTitle?: string }>`
  margin: auto;
  display: block;
  width: 100%;
  max-width: 35rem;
  a {
    font-weight: 600;
  }
  & > h1 {
    margin-bottom: ${({ subTitle }) => (subTitle ? '0.75' : '2')}rem;
    margin-top: 0;
    text-align: center;
  }
  & > img {
    margin: 0 auto 2rem;
    display:block;
  }
  & > p {
    margin-bottom: 1rem;
    text-align: center;
  }
  form {
    width: 100%;
    & > *:not(:last-child) {
      margin-bottom: 2rem;
    }
  }
  .form-group{
    display: block;
  }
`;
export const Group = styled.div`
  margin: 2rem 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const CardAuth = styled(Card)`
  margin-bottom: 0;
  height: calc(100vh - 5rem);
  ${breakpointDown('sm')`
    height: 100vh;
  `}
  ${CardBody} {
    display: flex;
  }
`;
interface AuthProps {
  title: string;
  subTitle?: string;
}
const Auth: React.FC<AuthProps> = ({ subTitle, title, children }) => {

  //const { serverUrl } = useContext(GlobalContext);
  const [logo, setLogo] = useState([]);

  useEffect(() => {

    const getlogo = async() => 
      {
          axios.get(`${process.env.serverUrl}site-settings/`,{}).then((response) => {
          setLogo(response.data.logo);   
          
        });
      } 
      getlogo();
  },   
  
  []) 

  return (
    <CardAuth>
      <CardBody>
        <AuthStyle subTitle={subTitle}>
        <img src={`/uploads/logo/${logo}`} alt="" />
          <h1>{title}</h1>
          {subTitle && <p>{subTitle}</p>}
          {children}
        </AuthStyle>
      </CardBody>
    </CardAuth>
  );
};
export default Auth;
