import Alert from 'react-bootstrap/Alert';
export default function ErrorSummary({ errors, success }) {
  let status = '';
  if(errors)
    status = 'danger';
  if(success)
    status = 'success';
    
  return (
    <Alert key={status} variant={status}>
      { errors }
      { success }
    </Alert>
  );
}
