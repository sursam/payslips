import React, {useState, useEffect} from 'react';
import styles from './RechargePanel.module.css';
import ManualRecharge from "./ManualRecharge";
import AutoRecharge from "./AutoRecharge";
import axios from "axios";

export default function RechargePanel(props) {
  const [showManual, setShowManual] = useState(true);  
  const [extraCreditArr, setExtraCreditArr] = useState([]);
  const [pageLoaded, setPageLoaded] = useState(false);

  useEffect(() => {
    const onPageLoad = () => {
      let endConsumerId = (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '';
      if(endConsumerId){
        axios.get(`${process.env.serverUrl}get-extra-credit/${endConsumerId}`,{}).then((response) => {
          if(response.data != null){
            setExtraCreditArr(response.data);
          }
          setPageLoaded(true);      
        }); 
      }
    };

    // Check if the page has already loaded
    if (document.readyState === 'complete') {
      onPageLoad();
    } else {
      window.addEventListener('load', onPageLoad);
      // Remove the event listener when component unmounts
      return () => window.removeEventListener('load', onPageLoad);
    }
  }, []);
  
  const onChangeRechargeType = (e) => {
    e.preventDefault();
    if(e.target.value == 'manual'){
      setShowManual(true);
    }else{
      setShowManual(false);
    }
  }
  return (
    <div className={styles.RechargePanel}>      
      <h3>Recharge</h3>
      {pageLoaded ?  
        <div>
          <div>
            <ul className={styles.RechargeType}>
              <li>
                <input type="radio" className={styles.RechargeRadioType} name="rechargeType" value="manual" onChange={onChangeRechargeType} id="type_manual" />
                <label className={styles.segmentButton + ' ' + (showManual ? styles.active : '')} htmlFor="rechargeType">Manual</label>
              </li>
              <li>
                <input type="radio" className={styles.RechargeRadioType} name="rechargeType" value="auto" onChange={onChangeRechargeType} id="type_auto" />
                <label className={styles.segmentButton + ' ' + (!showManual ? styles.active : '')} htmlFor="rechargeType">Auto</label>
              </li>
            </ul>
          </div>
          <div className={showManual ? styles.show : styles.hide}>
            <ManualRecharge 
              extraCreditArr={extraCreditArr}
              currentCreditBalance={props.currentCreditBalance}
              setShowRechargeBarLoader={props.setShowRechargeBarLoader}
            />
            </div>
          <div className={showManual ? styles.hide : styles.show}><AutoRecharge extraCreditArr={extraCreditArr}/></div>
        </div>  
      : 
        (<div className="bar_loader">
          <div className="bar"></div>
          <div className="bar2"></div>
          <div className="bar3"></div>
          <div className="bar4"></div>
        </div>)
      }   
    </div>
  );
}
