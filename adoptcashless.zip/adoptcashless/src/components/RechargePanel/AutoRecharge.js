import React, {useState, useEffect, useContext} from 'react';
import styles from './RechargePanel.module.css';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button} from "@material-ui/core";
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
import ErrorSummary from '../errorSummary';
import Link from 'next/link';
import GlobalContext from '../GlobalContext';
import { Elements, useStripe, useElements, PaymentElement } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import CardSection from "./CardSection";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Loader from '../loader';
import PaymentForm from "./PaymentForm";
import LoadingScreen from "../loadingScreen";

export default function AutoRecharge(props) {
  const [showOtherAutoAmount, setShowOtherAutoAmount] = useState(false);
  const [showOtherTriggerAutoAmount, setShowOtherTriggerAutoAmount] = useState(false);
  const autoRechargeAmounts = [100,200,500,1000,0];
  const autoRechargeTriggerPoints = [50,100,200,300,0];
  const [showAutoForm, setShowAutoForm] = useState(true);
  const [showCardForm, setShowCardForm] = useState(false);
  const [showCard, setShowCard] = useState(true);
  const [showCardList, setShowCardList] = useState(true);
  const [showBankList, setShowBankList] = useState(true);
  const [validationErrors, setvalidationErrors] = useState(null);
  const [validationErrorsBankAccount, setvalidationErrorsBankAccount] = useState(null);  
  const [listAccountSources, setListAccountSources] = useState({});
  const [listBankAccounts, setListBankAccounts] = useState({});
  const [showSubmit, setShowSubmit] = useState(false);
  const [showBankAccountLoader, setshowBankAccountLoader] = useState(false);
  const { stripeCreds } = useContext(GlobalContext);
  const stripePromise = loadStripe(stripeCreds.publishableKey);
  const [cardOptions, setCardOptions] = useState({});
  const [bankOptions, setBankOptions] = useState({});
  const [clientSecret, setClientSecret] = useState('');
  const [isFetching, setIsFetching] = useState(false);
  const [autoDefaultAmount, setAutoDefaultAmount] = useState(0);
  const [brandIcons, setBrandIcons] = useState({
    visa: 'visa-3-icon.svg',
    mastercard: 'mastercard-3-icon.svg',
    amex: 'amex-3-icon.svg',
    discover: 'discover-3-icon.svg',
    unionpay: 'unionpay-3-icon.svg',
    jcb: 'jcb-3-icon.svg',
    diners: 'diners-3-icon.svg',
  });
  
  const [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '',
    rechargeType: 'Auto Top-Up',
    autoRechargeVal: 100,
    triggerRechargeVal: 50,
    extraCredit: 0,
    sourceItem: '',
    sourceType: '',
  });
  const { endConsumerId, rechargeType, autoRechargeVal, triggerRechargeVal, extraCredit, sourceItem, sourceType} = state;

  useEffect(() => { 
    loadPaymentForm(endConsumerId, 'card'); 
    loadPaymentForm(endConsumerId, 'bank');    
    listSources();
    setAutoTopUpDefaultValues();    
  }, 
  [])

  const setAutoTopUpDefaultValues = () => {
    axios.get(`${process.env.serverUrl}get-auto-topup-values/${endConsumerId}`,{}).then((response) => {
      let auto_recharge_amount = -1;
      let auto_trigger_point = -1;
      if(response.data){
        auto_recharge_amount = response.data.auto_recharge_amount;
        auto_trigger_point = response.data.auto_trigger_point;
        setState(prevState => ({
          ...prevState,
          extraCredit: getExtraCredit(auto_recharge_amount),
        }));
        setAutoDefaultAmount(auto_recharge_amount);
      }
      setState(prevState => ({
        ...prevState,
        autoRechargeVal: parseFloat(auto_recharge_amount),
        triggerRechargeVal: parseFloat(auto_trigger_point),
      }));
      if(auto_recharge_amount > 0 && autoRechargeAmounts.indexOf(auto_recharge_amount) == -1){
        setShowOtherAutoAmount(true);
      }
      if(auto_trigger_point > 0 && autoRechargeTriggerPoints.indexOf(auto_trigger_point) == -1){
        setShowOtherTriggerAutoAmount(true);
      }
    });
  }

  const getExtraCredit = (rechargeVal) => {
    let extraCred = 0;
    if(props.extraCreditArr.length){
      props.extraCreditArr.forEach(extraCreditObj => {
        let minLimit = (extraCreditObj.Min_Limit__c != null) ? extraCreditObj.Min_Limit__c : 0;
        let maxLimit = (extraCreditObj.Max_Limit__c != null) ? extraCreditObj.Max_Limit__c : 0;
        if(between(rechargeVal, minLimit, maxLimit)){
          extraCred = extraCreditObj.Extra_Credit__c;
          return extraCred;
        }
      });
    }
    return extraCred;
  }
  const between = (x, min, max) => {
    return x >= min && x <= max;
  }

  const loadPaymentForm = (endConsumerId, type) => {
    axios.get(`${process.env.serverUrl}get-stripe-client-secret/${endConsumerId}/?type=${type}`,{}).then((response) => {
      setClientSecret(response.data.client_secret);
      const appearance = {
        theme: 'stripe',
      };
      switch(type){
        case 'card': 
          setCardOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
        case 'bank': 
          setBankOptions({
            clientSecret: response.data.client_secret,
            appearance: appearance,
          });
          break;
      }      
    });
  }
  const listSources = () => {
    /*axios.get(`${process.env.serverUrl}get-endconsumer-account-sources/${endConsumerId}`,{}).then((response) => {
      setListCards(response.data.cards.data);
      setListBankAccounts(response.data.bankAccounts.data);
      //console.log(response.data.cards.data);
    });*/
    axios.get(`${process.env.serverUrl}get-endconsumer-selected-sources/${endConsumerId}`,{}).then((response) => {
      setListAccountSources(response.data);
      console.log(response.data);
    });
  }

  const onChangeAutoRechargeVal = (e) => {
    e.preventDefault();
    setState(prevState => ({
      ...prevState,
      autoRechargeVal: e.target.value,
    }));
    if(e.target.value == 0){
      setShowOtherAutoAmount(true);
    }else{
      setShowOtherAutoAmount(false);
    }
    setState(prevState => ({
      ...prevState,
      extraCredit: getExtraCredit(e.target.value),
    }));
  }
  const onChangeAutoTriggerRechargeVal = (e) => {
    e.preventDefault();
    setState(prevState => ({
      ...prevState,
      triggerRechargeVal: e.target.value,
    }));
    if(e.target.value == 0){
      setShowOtherTriggerAutoAmount(true);
    }else{
      setShowOtherTriggerAutoAmount(false);
    }
  }

  const handleAutoOtherRechargeVal = ({ target: { value } }) => {
    const re = /^[0-9\b]+$/;
    if (value === '' || re.test(value)) {
      setState(prevState => ({
        ...prevState,
        autoRechargeVal: value,
      }));
      setState(prevState => ({
        ...prevState,
        extraCredit: getExtraCredit(value),
      }));
    }
  }
  const handleTriggerOtherRechargeVal = ({ target: { value } }) => {
    const re = /^[0-9\b]+$/;
    if (value === '' || re.test(value)) {
      setState(prevState => ({
        ...prevState,
        triggerRechargeVal: value,
      }));
    }
  }

  const onChangeSourceType = (e) => {
    e.preventDefault();
    if(e.target.value == 'card'){
      setShowCard(true);
      setShowCardList(true);
    }else{
      setShowCard(false);
      setShowBankList(true);
    }
  }
  const onChangeSourceItem = (e) => {
    e.preventDefault();
    let itemId = e.target.value;
    //console.log(itemId)
    setState(prevState => ({
      ...prevState,
      sourceItem: itemId,
    }));
    setState(prevState => ({
      ...prevState,
      sourceType: e.target.getAttribute("data-source_type"),
    }));
    var sourceItemDetails = document.querySelector('#source_details_'+itemId);
    var sourceListItem = document.querySelector('#source_item_'+itemId);
    [].forEach.call(document.querySelectorAll('.source_details'), function (el) {
      el.style.display = 'none';
    });
    sourceItemDetails.style.display = "block";
    [].forEach.call(document.querySelectorAll('.source_item'), function (el) {
      el.classList.remove("active");
    });
    sourceListItem.classList.add("active");

    //document.querySelector('#'+itemId).checked = true;
    setShowSubmit(true);
    
  }

  const onClickAddCard = (e) => {
    e.preventDefault();
    setShowCardList(false);
  }
  const onClickCloseAddCard = (e) => {
    e.preventDefault();
    setShowCardList(true);
  }
  const onClickAddBankAccount = (e) => {
    e.preventDefault();
    setShowBankList(false);
  }
  const onClickCloseBankAccount = (e) => {
    e.preventDefault();
    setShowBankList(true);
  }
  const onClickBackToAutoForm = (e) => {
    e.preventDefault();
    setShowAutoForm(true);
    setShowCardForm(false);
  }

  const submitAutoValues = (e) => {
    e.preventDefault();
    if(!autoRechargeVal || parseFloat(autoRechargeVal) <= 0){
      //setvalidationErrors('Recharge amount is required');
      toast.error('Recharge amount is required');
    }else if(autoRechargeVal && (parseFloat(autoRechargeVal) < parseFloat(triggerRechargeVal))){
      toast.error('Recharge amount should be greater than trigger amount');
    }else{
      setShowAutoForm(false); 
      setShowCardForm(true);
    }    
  }

  var validationSchema = Yup.object().shape();

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData) => {
    if(!autoRechargeVal || parseFloat(autoRechargeVal) <= 0){
      //setvalidationErrors('Recharge amount is required');
      toast.error('Recharge amount is required');
    }else if(autoRechargeVal && (parseFloat(autoRechargeVal) < parseFloat(triggerRechargeVal))){
      //setvalidationErrors('Recharge amount should be greater than trigger amount');
      toast.error('Recharge amount should be greater than trigger amount');
    }else{
      setIsFetching(true);
      axios.post(`${process.env.serverUrl}setup-auto-topup`, formData).then((response) => {
        setIsFetching(false);
        if(!response.data.error){
          toast.success(response.data.message);
        }else{
          //setvalidationErrors(response.data.error);
          toast.error(response.data.error);
        }        
      });
    }   
  };

  const resetAutoTopupForm = (e) => {
    e.preventDefault();
    const formLoader = document.querySelector('.form_loader');
    formLoader.classList.remove('submitting');
    formLoader.classList.remove('submitted');
    setShowAutoForm(true);
    setShowOtherAutoAmount(false);
    setShowOtherTriggerAutoAmount(false);
    setAutoTopUpDefaultValues();
  }

  const [stateBankAccount, setStateBankAccount] = useState({
    end_consumer_id: (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '',
    account_holder_name: '',
    routing_number: '',
    account_number: '',
    confirm_account_number: '',
  });
  const { end_consumer_id, account_holder_name, routing_number, account_number, confirm_account_number} = stateBankAccount;

  const handleBankAccountChange = (event) => {    
    const { name, value } = event.target;
    setStateBankAccount(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  var validationSchemaBankAccount = Yup.object().shape();

  var formOptionsBankAccount = { defaultValues: stateBankAccount, resolver: yupResolver(validationSchemaBankAccount) };
  var { register: registerBankAccount, handleSubmit: handleBankAccountSubmit, reset: resetBankAccount, formState: { errors: errorsBankAccount } } = useForm(formOptionsBankAccount);

  const submitBankAccountForm = () => {    
    resetBankAccount(stateBankAccount)
  }

  const onBankAccountSubmit = async () => {
    //setshowBankAccountLoader(true);
    console.log(props);
    const { stripe, elements } = props;
    if (!stripe || !elements) {
      return;
    }
    const card = elements.getElement(PaymentElement);
    const result = await stripe.createToken(card);
    /*axios.post(`${process.env.serverUrl}add-stripe-bank-account`, formData).then((response) => {
      setshowBankAccountLoader(false);
      if(!response.data.error){
        toast.success(response.data.message);
        listSources();
        setShowBankList(true);
      }else{        
        setvalidationErrorsBankAccount(response.data.error);
      }        
    });*/        
  };

  return (
    <div>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      
      {showAutoForm ? 
        <div className='priceRangeDiv'>                        
          <h4>With auto recharge, we will recharge your card / fob when your balance fails below the selected threshold.</h4>
          <label className={styles.rechargeLabel}>Select the recharge amount</label>
          <dl className={styles.PriceRange}> 
            { autoRechargeAmounts.map((autoRechargeAmount) => (
              <dt>
                <input type="radio" className="rechargeVal" {...register('autoRechargeVal')} value={autoRechargeAmount} onChange={onChangeAutoRechargeVal} />
                <label className={((autoRechargeVal == autoRechargeAmount) || (autoRechargeAmount == 0 && showOtherAutoAmount)) ? 'active' : ''}>{(autoRechargeAmount != 0) ? '$'+autoRechargeAmount : 'Other'}</label>
              </dt>
            )) }                                  
          </dl>
          <div className={`currencyDiv ${showOtherAutoAmount ? 'show' : 'hide'}`}>
            <input type="text" name="rechargeAutoOtherVal" className={`form-control rechargeOtherVal ${errors.rechargeAutoOtherVal ? 'is-invalid' : ''}`} value={autoRechargeVal} onChange={handleAutoOtherRechargeVal} />
          </div>          
          <div className="invalid-feedback">{errors.rechargeAutoOtherVal?.message}</div>

          <label className={styles.rechargeLabel}>Recharge trigger point</label>
          <h4>When your balance drops below the selected amount, we recharge your corporate card / fob.</h4>
          <dl className={styles.PriceRange} onChange={onChangeAutoTriggerRechargeVal}>    
            { autoRechargeTriggerPoints.map((autoRechargeTriggerPoint) => (
              <dt>
                <input type="radio" className="rechargeVal" {...register('triggerRechargeVal')} value={autoRechargeTriggerPoint} />
                <label className={((triggerRechargeVal == autoRechargeTriggerPoint) || (autoRechargeTriggerPoint == 0 && showOtherTriggerAutoAmount)) ? 'active' : ''}>{(autoRechargeTriggerPoint != 0) ? '$'+autoRechargeTriggerPoint : 'Other'}</label>
              </dt>
            )) }                                         
          </dl>
          <div className={`currencyDiv ${showOtherTriggerAutoAmount ? 'show' : 'hide'}`}>
            <input type="text" name="rechargeTriggerOtherVal" className={`form-control rechargeOtherVal ${errors.rechargeTriggerOtherVal ? 'is-invalid' : ''}`} value={triggerRechargeVal} onChange={handleTriggerOtherRechargeVal} />
          </div>
          <div className="invalid-feedback">{errors.rechargeTriggerOtherVal?.message}</div>

          {
            (autoRechargeVal > 0 && extraCredit > 0) ? 
              <div className={styles.ExtraCredit}><span>{extraCredit}% Extra Credit</span></div>
            : ''
          }

          <div className='preferred_method'>
            {(listAccountSources.length > 0) ? 
              <>
                <ul>
                  { Object.values(listAccountSources).map((accountSource) => (
                  <li>
                    <label>
                      {(accountSource.source_type == 'card') ?
                        <div className='all-home'>
                          {accountSource.brand ? 
                            <img src={`/assets/images/svg/${brandIcons[accountSource.brand]}`} alt="Card Brand" className='brand_icon' />
                          : ''}
                          {/*<Icon.CreditCard />*/}
                          {String(accountSource.last_four_digits).padStart(16, 'X').replace(/^(.{4})(.{4})(.{4})(.*)$/, "$1 $2 $3 $4")} <span className={accountSource.account_type}>{accountSource.account_type}</span>
                        </div>
                        :
                        <div className='first-home'>
                          <Icon.House />
                          {String(accountSource.last_four_digits).padStart(9, 'X').replace(/^(.{4})(.*)$/, "$1 $2")} <span className={accountSource.account_type}>{accountSource.account_type}</span>
                        </div>
                      }
                    </label>
                  </li>
                  )) }
                </ul>
                <Link legacyBehavior href="/payment-methods"><a>Manage</a></Link>
              </>
            : <><label>No payment methods are available.</label><Link legacyBehavior href="/payment-methods"><a>Add</a></Link></>
            }
          </div>
          <form onSubmit={handleSubmit(onSubmit)}> 
            <div className={styles.ProceedPay}>
              <Button color="primary"
                variant="contained"
                className={styles.mt40}
                type="submit" 
                onClick={submitForm}>
                  {(autoDefaultAmount > 0) ? 'Update Auto Top-Up' : 'Setup Auto Top-Up Now'}
              </Button>              
            </div>
            <ErrorSummary errors={validationErrors} />   
          </form>
          
        </div>
      : ''}
      {showCardForm ?
        <div className="cardSection auto_recharge_card">
          {/*<Elements stripe={stripePromise}>
              <CardSection />
            </Elements>*/}    
            <ul className={styles.SourceType}>
              <li>
                <input type="radio" className={styles.SourceRadioType} name="SourceType" value="card" onChange={onChangeSourceType} id="type_card" />
                <label className={styles.segmentButton + ' ' + (showCard ? styles.active : '')} htmlFor="SourceType">Card</label>
              </li>
              <li>
                <input type="radio" className={styles.SourceRadioType} name="SourceType" value="bank" onChange={onChangeSourceType} id="type_bank" />
                <label className={styles.segmentButton + ' ' + (!showCard ? styles.active : '')} htmlFor="SourceType">Bank Account</label>
              </li>
            </ul>
            {showCard ? 
              <div id="cardList">
                {showCardList ?
                  <div>
                    <div className='sourceListHead'>
                      <h5>Credit Cards</h5>
                      <button className="btn-pay" onClick={onClickAddCard}>Add Card</button>
                    </div>                    
                    {(listCards.length) > 0 ?
                      <dl>    
                        { listCards.map((card) => (
                          <dt id={`source_item_${card.id}`} className="source_item">
                            <input type="radio" className="sourceItem" {...register('sourceItem')} id={card.id} value={card.id} data-source_type="card" onChange={onChangeSourceItem}/>
                            <label>{card.brand} ...{card.last4}</label>
                            <ul className="source_details" id={`source_details_${card.id}`}>
                              <li><strong>Brand: </strong>{card.brand}</li>
                              <li><strong>Country: </strong>{card.country}</li>
                              <li><strong>Card Last 4 digits: </strong>{card.last4}</li>
                              <li><strong>Exp date: </strong>{card.exp_month}/{card.exp_year}</li>
                              {card.address_zip ? <li><strong>Zip: </strong>{card.address_zip}</li> : ''}
                            </ul>
                          </dt>
                        )) }                                         
                      </dl>
                    : 
                      <p>No Crads are available.</p>
                    }
                     
                  </div>
                :
                  <div>
                    <h5>Add Credit Card</h5>
                    <Elements options={cardOptions} stripe={stripePromise}>
                      <PaymentForm 
                        cancelForm={onClickCloseAddCard}
                        endConsumerId={endConsumerId}
                      />                      
                    </Elements>
                  </div>
                }    
              </div> 
            :     
              <div id="bankAccountList">
                {showBankList ?
                  <div>
                    <div className='sourceListHead'>
                      <h5>Bank Accounts</h5>
                      <button className="btn-pay" onClick={onClickAddBankAccount}>Add Bank Account</button>
                    </div>
                    
                    {(listBankAccounts.length) > 0 ?
                      <dl>    
                        { listBankAccounts.map((bankAccount) => (
                          <dt id={`source_item_${bankAccount.id}`} className="source_item">
                            <input type="radio" className="sourceItem" {...register('sourceItem')} id={bankAccount.id} value={bankAccount.id} data-source_type="bank" onChange={onChangeSourceItem} />
                            <label>{bankAccount.bank_name} ...{bankAccount.last4}</label>
                            <ul className="source_details" id={`source_details_${bankAccount.id}`}>
                              <li><strong>Account Holder: </strong>{bankAccount.account_holder_name}</li>
                              <li><strong>Bank: </strong>{bankAccount.bank_name}</li>
                              <li><strong>Country: </strong>{bankAccount.country}</li>
                              <li><strong>Account Last 4 digits: </strong>{bankAccount.last4}</li>
                              <li><strong>Routing Number: </strong>{bankAccount.routing_number}</li>
                            </ul>
                          </dt>
                        )) }                                         
                      </dl>
                    : 
                      <p>No Bank Accounts are available.</p>
                    }
                    
                  </div>
                :
                  
                    <div>
                      {/*<ErrorSummary errors={validationErrorsBankAccount} />*/}
                      <h5>Add Bank Account</h5>
                      <Elements options={bankOptions} stripe={stripePromise}>
                        <PaymentForm 
                          cancelForm={onClickCloseBankAccount}
                          endConsumerId={endConsumerId}
                        />
                      </Elements> 
                      {validationErrorsBankAccount && <div>{validationErrorsBankAccount}</div>}
                    </div>
                  
                }
              </div> 
            } 
            {((showCard && showCardList) || (!showCard && showBankList)) ?
            <form onSubmit={handleSubmit(onSubmit)}> 
              <div>
                <Button variant="contained" type="button" onClick={onClickBackToAutoForm}>Back</Button>
                {showSubmit ? 
                  <Button color="primary"
                    variant="contained"
                    className={styles.mt40}
                    type="submit" 
                    onClick={submitForm}>
                      Submit
                  </Button>
                : ''}
              </div>
            </form>
            : ''}
                    
        </div>
      : ''}
      <div className="cell stripeform_panel stripeform form_loader">
        <div className="success">
          <div className="icon">
            <div id="loader-wrapper"><div id="loader"></div></div>
            <svg width="84px" height="84px" viewBox="0 0 84 84" version="1.1" xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink">
              <circle className="border" cx="42" cy="42" r="40" stroke-linecap="round" stroke-width="4" stroke="#000" fill="none"></circle>
              <path className="checkmark" stroke-linecap="round" stroke-linejoin="round" d="M23.375 42.5488281 36.8840688 56.0578969 64.891932 28.0500338" stroke-width="4" stroke="#000" fill="none"></path>
            </svg>
          </div>
          <h3 className="title" data-tid="elements_examples.success.title">Auto Top-Up setup successful.</h3>
          {/*<p className="message"><span data-tid="elements_examples.success.message">Auto Top-Up successfully set.</span></p>*/}              
          <Link legacyBehavior href="#"><a  onClick={resetAutoTopupForm}>
            <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" viewBox="0 0 32 32">
              <g fill="#61DAFB">
                <path fill="#000000" d="M15,7.05492878 C10.5000495,7.55237307 7,11.3674463 7,16 C7,20.9705627 11.0294373,25 16,25 C20.9705627,25 25,20.9705627 25,16 C25,15.3627484 24.4834055,14.8461538 23.8461538,14.8461538 C23.2089022,14.8461538 22.6923077,15.3627484 22.6923077,16 C22.6923077,19.6960595 19.6960595,22.6923077 16,22.6923077 C12.3039405,22.6923077 9.30769231,19.6960595 9.30769231,16 C9.30769231,12.3039405 12.3039405,9.30769231 16,9.30769231 L16,12.0841673 C16,12.1800431 16.0275652,12.2738974 16.0794108,12.354546 C16.2287368,12.5868311 16.5380938,12.6540826 16.7703788,12.5047565 L22.3457501,8.92058924 L22.3457501,8.92058924 C22.4060014,8.88185624 22.4572275,8.83063012 22.4959605,8.7703788 C22.6452866,8.53809377 22.5780351,8.22873685 22.3457501,8.07941076 L22.3457501,8.07941076 L16.7703788,4.49524351 C16.6897301,4.44339794 16.5958758,4.41583275 16.5,4.41583275 C16.2238576,4.41583275 16,4.63969037 16,4.91583275 L16,7 L15,7 L15,7.05492878 Z M16,32 C7.163444,32 0,24.836556 0,16 C0,7.163444 7.163444,0 16,0 C24.836556,0 32,7.163444 32,16 C32,24.836556 24.836556,32 16,32 Z"></path>
              </g>
            </svg>
          </a></Link>
        </div>
      </div>
    </div>
  );
}
