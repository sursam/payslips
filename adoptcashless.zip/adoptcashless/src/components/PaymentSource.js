import React, {useState, useEffect, useContext} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from '../styles/Dashboard.module.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";
import Link from 'next/link';
import * as Icon from 'react-bootstrap-icons';
import axios from "axios";
import GlobalContext from './GlobalContext';
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { Button } from "@material-ui/core";
import PaymentForm from "./RechargePanel/PaymentForm";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import LoadingScreen from "./loadingScreen";

export default function PaymentSource() {
  const [showAddCard, setShowAddCard] = useState(false);
  const [showAddBank, setShowAddBank] = useState(false);
  const [listPaymentSources, setListPaymentSources] = useState({});
  const [showAccountLoader, setShowAccountLoader] = useState(true);
  const { stripeCreds } = useContext(GlobalContext);
  const stripePromise = loadStripe(stripeCreds.publishableKey);
  const [cardOptions, setCardOptions] = useState({});
  const [bankOptions, setBankOptions] = useState({});
  //const [clientSecret, setClientSecret] = useState('');
  const [isFetching, setIsFetching] = useState(false);
  const [errorMessage, setErrorMessage] = useState('No payment methods are available.');
  const [stripeError, setStripeError] = useState(false);
  const [brandIcons, setBrandIcons] = useState({
    visa: 'visa-3-icon.svg',
    mastercard: 'mastercard-3-icon.svg',
    amex: 'amex-3-icon.svg',
    discover: 'discover-3-icon.svg',
    unionpay: 'unionpay-3-icon.svg',
    jcb: 'jcb-3-icon.svg',
    diners: 'diners-3-icon.svg',
  });
  
  const [state, setState] = useState({
    endConsumerId: (typeof localStorage !== 'undefined' && localStorage.getItem('salesforce_id')) || '',
    backupItem: Array(),
    primaryItem: ''
  });
  const { endConsumerId, backupItem, primaryItem} = state;

  useEffect(() => {    
    listSources();  
    axios.get(`${process.env.serverUrl}get-endconsumer-selected-sources/${endConsumerId}`,{}).then((response) => {
      const bckItem = [];
      response.data.forEach((paymentSource, k) => {
          switch(paymentSource.account_type){
            case 'primary':
              setState(prevState => ({
                ...prevState,
                primaryItem: paymentSource.source_id
              }));
              break;
            case 'backup':
              bckItem.push(paymentSource.source_id);
              break;
          }
      });
      setState(prevState => ({
        ...prevState,
        backupItem: bckItem
      }));
    });  
    loadPaymentForm(endConsumerId, 'card'); 
    loadPaymentForm(endConsumerId, 'bank'); 
  }, 
  [])


  const loadPaymentForm = (endConsumerId, type) => {
    axios.get(`${process.env.serverUrl}get-stripe-client-secret/${endConsumerId}/?type=${type}`,{}).then((response) => {
      if(!response.data.error){
        //setClientSecret(response.data.client_secret);
        const appearance = {
          theme: 'stripe',
        };
        switch(type){
          case 'card': 
            setCardOptions({
              clientSecret: response.data.client_secret,
              appearance: appearance,
            });
            break;
          case 'bank': 
            setBankOptions({
              clientSecret: response.data.client_secret,
              appearance: appearance,
            });
            break;
        }    
      }else{
        setErrorMessage(response.data.message);
        setStripeError(true);
      }  
    });
  }
  const listSources = () => {
    axios.get(`${process.env.serverUrl}get-endconsumer-account-sources/${endConsumerId}`,{}).then((response) => {
      setListPaymentSources(response.data);
      setShowAccountLoader(false);
    });
  }

  const onClickAddCard = (e) => {
    e.preventDefault();
    setShowAddBank(false);
    setShowAddCard(true);
  }
  const onClickAddBankAccount = (e) => {
    e.preventDefault();
    setShowAddCard(false);
    setShowAddBank(true);
  }
  const onViewSourceList = () => {
    setShowAddCard(false);
    setShowAddBank(false);
  }

  var validationSchema = Yup.object().shape({});

  var formOptions = { defaultValues: state, resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors } } = useForm(formOptions);

  const submitForm = () => {    
    reset(state)
  }

  const onSubmit = (formData) => {
    console.log(formData)
    setIsFetching(true);
    axios.post(`${process.env.serverUrl}setup-payment-methods`, formData).then((response) => {
      if(!response.data.error){
        setIsFetching(false);
        toast.success(response.data.message);
        //console.log(response.data);
      }else{
        toast.error(response.data.message);
      }        
    });
  };

  const deletePaymentSource = (sourceId) => {
    confirmAlert({
        title: 'Confirm to delete',
        message: 'Are you sure to do this?',
        buttons: [
          {
            label: 'Yes',
            onClick: () => {
                setIsFetching(true);       
                if(sourceId){
                    axios.post(`${process.env.serverUrl}delete-rfid-card`, {sourceId: sourceId}).then((response) => {
                        setIsFetching(false);
                        //console.log(response.data)
                        if(!response.data.error){
                            toast.success(response.data.message);
                            listSources();  
                        }else{
                            toast.error(response.data.message);
                        }   
                    });
                }
            }
          },
          {
            label: 'No',
          }
        ]
    });    
  };

  const setSourceItem = (e) => {
    e.preventDefault();
    const sourceId = e.currentTarget.getAttribute("data-source");
    const sourceType = e.currentTarget.getAttribute("data-type");
    //const sourceItem = document.querySelector('#sourceItem_'+sourceId);
    const bckItem = backupItem;
    const bckIndex = bckItem.indexOf(sourceId);
    if(sourceType == 'primary'){
      if (bckIndex > -1) {
        bckItem.splice(bckIndex, 1); 
      }
      setState(prevState => ({
        ...prevState,
        primaryItem: sourceId
      }));
    }
    if(sourceType == 'backup'){
      if (bckIndex == -1) {
        bckItem.push(sourceId);
        setState(prevState => ({
          ...prevState,
          backupItem: bckItem
        }));
      }
    }
  }

  const unsetSourceItem = (e) => {
    e.preventDefault();
    const sourceId = e.currentTarget.getAttribute("data-source");
    const bckItem = backupItem;
    const bckIndex = bckItem.indexOf(sourceId);
    bckItem.splice(bckIndex, 1); 
    setState(prevState => ({
      ...prevState,
      backupItem: bckItem
    }));
  }
  return (
    <div>
      {
          isFetching ? <LoadingScreen /> : ''
      }
      {!showAccountLoader ?         
          <div>               
            {/* ============= button container ============== */}
              <div className='buttoContainer'>
                {!stripeError ?
                  <>
                    <button className="btn-pay" onClick={onClickAddBankAccount}> <Icon.Plus />  Add Bank Account</button>
                    <button className="btn-pay" onClick={onClickAddCard}><Icon.Plus /> Add Card</button>
                  </>
                : '' }
              </div>
            {/* ============= button container end============== */}
            {(showAddCard || showAddBank) ?
                <div>
                {showAddCard ? 
                    <div className='BankAccount'>
                    <h5><span>Add Credit Card</span></h5>
                    <Elements options={cardOptions} stripe={stripePromise}>
                        <PaymentForm 
                        setShowSourceList={onViewSourceList}
                        endConsumerId={endConsumerId}
                        listSources={listSources}
                        setIsFetching={setIsFetching}
                        />                      
                    </Elements>
                    </div>
                : ''}
                {showAddBank ?
                    <div className='BankAccount'>
                    <h5><span>Add Bank Account</span></h5>
                    <Elements options={bankOptions} stripe={stripePromise}>
                        <PaymentForm 
                        setShowSourceList={onViewSourceList}
                        endConsumerId={endConsumerId}
                        listSources={listSources}
                        setIsFetching={setIsFetching}
                        />
                    </Elements> 
                    </div>
                    : ''}
                </div>
              :
              <div className='paymentMethods'>
                <dl>  
                  {(Object.keys(listPaymentSources).length > 0) ?
                    Object.values(listPaymentSources).map((paymentSource) => (
                        <dt id={`source_item_${paymentSource.source_id}`} className="source_item">                        
                            {
                              (paymentSource.source_type == 'bank') ?
                              <label><Icon.House/> {String(paymentSource.last_four_digits).padStart(9, 'X').replace(/^(.{4})(.*)$/, "$1 $2")}</label>
                              :
                              <label><Icon.CreditCard/>{String(paymentSource.last_four_digits).padStart(16, 'X').replace(/^(.{4})(.{4})(.{4})(.*)$/, "$1 $2 $3 $4")}</label>
                            }
                            
                            <span className='sourceBrand'>
                              {paymentSource.brand ? 
                              <img src={`/assets/images/svg/${brandIcons[paymentSource.brand]}`} alt="Card Brand" />
                              : ''}
                            </span>

                            <div className='rightP'>
                                <span id={`sourceItem_${paymentSource.source_id}`} className={`sourceItem ${(primaryItem == paymentSource.source_id) ? 'primary' : ''} ${(backupItem.indexOf(paymentSource.source_id) > -1) ? 'backup' : ''}`}>
                                {(primaryItem == paymentSource.source_id) ? 'Primary' : ''}
                                {(backupItem.indexOf(paymentSource.source_id) > -1) ? 'Backup' : ''}
                                </span>

                                { (primaryItem != paymentSource.source_id) ?
                                <span>
                                    {(backupItem.indexOf(paymentSource.source_id) == -1) ?
                                    <Button color="primary" variant="contained" className={styles.mt40} type="button" onClick={setSourceItem} data-source={paymentSource.source_id} data-type="backup">Backup</Button>
                                    : 
                                    <Button color="primary" variant="contained" className={styles.mt40} type="button" onClick={unsetSourceItem} data-source={paymentSource.source_id} data-type="unset">Remove</Button>
                                    }
                                    <Button color="primary" variant="contained" className={styles.mt40} type="button" onClick={setSourceItem} data-source={paymentSource.source_id} data-type="primary">Make this Primary</Button>                                      
                                </span>
                                : '' }
                            
                                {/*<Link legacyBehavior href="#"><a onClick={() => viewSource(paymentSource.source_id)}><Icon.Eye/></a></Link>*/}

                                {(primaryItem != paymentSource.source_id) ?
                                <Link legacyBehavior href="#"><a onClick={() => deletePaymentSource(paymentSource.source_id)}><Icon.Trash/></a></Link>
                                : ''}

                            </div>
                        </dt>
                    )) 
                    : <label>{errorMessage}</label>
                  } 
                                
                </dl>
                <form onSubmit={handleSubmit(onSubmit)}> 
                    <div className={styles.submitContainer}>
                      <Button color="primary"
                          variant="contained"
                          className={styles.mt40}
                          type="submit" 
                          onClick={submitForm}>
                          Update
                      </Button>
                    </div>
                </form>  
              </div>  
            }                        
          
          </div>
      : 
        <div className='loading_div'>
            <div className="bar_loader">
                <div className="bar"></div>
                <div className="bar2"></div>
                <div className="bar3"></div>
                <div className="bar4"></div>
            </div>
        </div>
      } 
    </div>
  );
}