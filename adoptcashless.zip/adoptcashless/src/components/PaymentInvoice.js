import React from 'react';
import { Page, Text, Image, View, Document, StyleSheet, Font} from '@react-pdf/renderer';
import InvoiceNo from './PdfInvoice/InvoiceNo'
import InvoiceFromTo from './PdfInvoice/InvoiceFromTo'
import InvoiceTable from './PdfInvoice/InvoiceTable'

/*Font.register({
  family: "Roboto",
  src:
    "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-light-webfont.ttf"
});*/
// Create styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Helvetica',
    fontSize: 11,
    paddingTop: 40,
    paddingLeft: 60,
    paddingRight: 60,
    paddingBottom: 80,
    lineHeight: 1.5,
    flexDirection: 'column',
  },
  row: {
    width: '100%',
    flexDirection: 'row',
  },
  headerSection: {
    display: 'flex',
    textAlign: 'center',
  },
  footerSection: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: "60px",
    display: 'block',
    textAlign: 'left',
  }, 
  logo: {
    width: '8%',
    height: 'auto',
    display: 'block',
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  copyRightText: {
    fontFamily: "Helvetica",
    fontSize: 7,
    paddingBottom: 6,
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  headerText: {
    fontFamily: 'Helvetica-Bold',
    fontSize: 20,
    textTransform: 'uppercase'
  },
  invoiceFromTo: {
    width: '60%',
    textAlign: 'left',
  },
  invoiceNo: {
    width: '40%',
    textAlign: 'right',
  },
  cardNo: {
    width: '78%',
    textAlign: 'left',
  },
  rechargeType: {
    width: '22%',
    textAlign: 'center',
  },
  typeText: {
    backgroundColor: '#6160f6',
    color: '#ffffff',
    fontFamily: 'Helvetica', 
    paddingTop: 6,
    paddingBottom: 3,
    borderRadius: 20
  },
  typeTextAuto: {
    backgroundColor: '#71b960',
    color: '#ffffff',
    fontFamily: 'Helvetica', 
    paddingTop: 6,
    paddingBottom: 3,
    borderRadius: 20
  },
  
})

export default function PaymentInvoice(props) {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.headerSection}><Text style={styles.headerText}>Tax Invoice</Text></View>
        <View style={styles.row}>
          <View style={styles.invoiceFromTo}>
            <InvoiceFromTo accountInfo={props.accountInfo} billingAddress={props.billingAddress} endConsumerInfo={props.endConsumerInfo} companyInfo={props.companyInfo}/>
          </View>
          <View style={styles.invoiceNo}>
            <InvoiceNo transactionInfo={props.transactionInfo}/>
          </View>
        </View>
        <View style={styles.row}>
          <View style={styles.cardNo}></View>
          <View style={styles.rechargeType}>
            <Text style={(props.transactionInfo.recharge_procedure == 'Auto') ? styles.typeTextAuto : styles.typeText}>{(props.transactionInfo.recharge_procedure == 'Auto') ? 'Auto Top-Up' : 'Manual Recharge'}</Text>
          </View>
        </View>
        <InvoiceTable transactionInfo={props.transactionInfo}/>
        <View style={styles.footerSection} fixed>
          <Text style={styles.copyRightText}>© {(new Date().getFullYear())} All Rights Reserved by Tap N Go Pty Ltd</Text>
          {props.siteLogo ? 
            <Image src={`/uploads/logo/${props.siteLogo}`} alt="" style={styles.logo} fixed></Image>
          : ''}
        </View>
      </Page>
    </Document>
  );
}