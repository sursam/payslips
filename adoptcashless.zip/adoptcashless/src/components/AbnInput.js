import InputMask from 'react-input-mask';
export default function AbnInput(props) {
  return (
    <InputMask 
      mask='99 999 999 999' 
      value={props.value} 
      className={props.className}
      onChange={props.onChange}
      type="text">
    </InputMask>
  );
}
