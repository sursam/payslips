import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

const secret = process.env.NEXTAUTH_SECRET;

export async function proxy(req: NextRequest) {
  const token = await getToken({ req, secret });
  const { pathname } = req.nextUrl;
  // console.log('token ====> ', token);
  // If the user is authenticated and trying to access a login or register page, redirect to the dashboard
  if (token && (pathname === '/sign-in' || pathname === '/forgot-password' || pathname === '/')) {
    return NextResponse.redirect(new URL('/dashboard', req.url));
  }else if(!token && pathname !== '/sign-in' && pathname !== '/forgot-password'){
    return NextResponse.redirect(new URL('/sign-in', req.url));
  }

  // If the user is not authenticated and trying to access a protected page (e.g., /dashboard), 
  // you might want to redirect them to the login page.
  // Next-auth's default middleware behavior often handles this for defined protected routes.

  return NextResponse.next();
}

// Define which paths the middleware should run on
export const config = {
  matcher: [
    '/',
    '/sign-in',
    '/forgot-password',
    '/reset-password',
    '/access-denied',
    '/dashboard/:path*',
    '/ecommerce/:path*',
    '/settings/:path*',
  ],
};