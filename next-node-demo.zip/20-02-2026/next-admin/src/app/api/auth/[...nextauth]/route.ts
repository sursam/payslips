// auth.js
import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import type { NextAuthOptions } from "next-auth";

export const authOptions: NextAuthOptions = {
  providers: [
    Credentials({
      name: 'Credentials',
      credentials: {
        email: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
        device_type: { label: 'Device Type', type: 'number' },
      },
      async authorize(credentials) {      
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}login`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email_id: credentials?.email,
            password: credentials?.password,
            device_type: credentials?.device_type,
          }),
        });
        const response = await res.json();
        // console.log('response ====> ', response);  

        // if (!res.ok) {
        //   throw new Error(response?.message)
        // }
        if (response?.status === 200) {
            const user = response.data.user;
            return user;
        }
        return response;
      },
    }),
  ],
  pages: {
    signIn: '/sign-in', // Custom sign-in page path
  },
  callbacks: {
    async redirect({ url, baseUrl }) {
      // If baseUrl is 127.0.0.1, force it to localhost
      const targetBase = baseUrl.includes('127.0.0.1') 
        ? baseUrl.replace('127.0.0.1', 'localhost') 
        : baseUrl;

      return url.startsWith(targetBase) ? url : targetBase;
    },
    async signIn({ user }: any) {
      // console.log(user);
      if (user?.status) {
        let errorString = JSON.stringify({ message: user?.message, status: user?.status });
        throw new Error(errorString);
      }
      return true
    },
    async jwt({ token, user } : any) {
      // console.log('token', token);
      /*if(token){
        if(!token.needToLogout){
          const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}fetch-user-details/${token?.uuid}`, {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
              'Authorization': `Bearer ${token?.accessToken}`,
            },
          });
          const response = await res.json();
          token.needToLogout = response?.data?.user?.needToLogout;
        }else{

        }        
      }*/
      if (user) {
        token.accessToken = user.accessToken;
        token.uuid = user.uuid;
        token.isVerified = user.isVerified;
        token.needToLogout = user.needToLogout;
      }
      return token
    },
    async session({ session, token, user } : any) {
      // console.log('session, token, user', session, token, user);
      session.accessToken = token.accessToken;
      session.user.uuid = token.uuid;
      session.user.isVerified = token.isVerified;
      session.user.needToLogout = token.needToLogout;
      return session
    }
  },
  session: {
    strategy: 'jwt',
  },
};
const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }