import SignInForm from "@/components/Authentication/SignInForm";
export const metadata = {
  title: "Sign In",
  description: "Sign In",
};
export default function Page() {
  return (
    <SignInForm />
  );
}
