export default function Loading() { 
  return (
    <>
      <div className="preloader" id="preloader">
        <div className="preloader">
          <div className="waviy position-relative">
            <span className="d-inline-block">E</span>
            <span className="d-inline-block">C</span>
            <span className="d-inline-block">L</span>
            <span className="d-inline-block">I</span>
            <span className="d-inline-block">C</span>
            <span className="d-inline-block">K</span>
          </div>
        </div>
      </div>
    </>
  )
}