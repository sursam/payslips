'use client';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'remixicon/fonts/remixicon.css'; 
import 'react-calendar/dist/Calendar.css';
import "swiper/css";
import "swiper/css/bundle";
import 'react-datetime-picker/dist/DateTimePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-clock/dist/Clock.css';
import 'react-tabs/style/react-tabs.css';
 
// Styles
import "../../styles/style.css";
import "../../styles/left-sidebar-menu.css";

import LayoutProvider from '@/providers/LayoutProvider';
import SessionSync from '@/providers/SessionSync';
import { Inter } from "next/font/google";

import { store } from '@/redux/store';
import { Provider } from 'react-redux';
import { SessionProvider } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { jwtDecode } from 'jwt-decode';
import { getSession } from 'next-auth/react';
import {can} from "@/utils/helper";
import { Card } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { MetadataProvider } from '@/context/MetadataContext';

// import type { Metadata, ResolvingMetadata } from 'next';
// import InternalError from "@/components/InternalError";

const inter = Inter({ subsets: ["latin"] });
// export const metadata = {
//   title: "Eclick",
//   description: "Eclick",
// };

export default function RootLayout({ children }) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const pathname = usePathname();
  
  useEffect(() => {
    checkAccess(pathname);
  }, [pathname]);
  const checkAccess = async (pathname) => {
    const session:any = await getSession();
    console.log('pathname => ', pathname);
    const accessToken = session ? session?.accessToken : null;
    const userInfo:any = accessToken ? jwtDecode(accessToken) : null;
    const menus = userInfo && userInfo.menus ? userInfo.menus : [];
    // console.log('Can View', !session || userInfo?.roleSlug == "super-admin" || (menus[`${pathname}/`] && can([`view-${menus[`${pathname}/`]}`], accessToken)))
    setHasAccess(!session || userInfo?.roleSlug == "super-admin" || (accessToken && menus[`${pathname}/`] && can([`view-${menus[`${pathname}/`]}`], accessToken)));
    setIsLoading(false);
  };
  
  return (
    <html lang="en">
      <body className={inter.className}>
        <SessionProvider>
          <Provider store={store}>
            <MetadataProvider>
              <LayoutProvider>
                <SessionSync />
                { 
                  !isLoading ? 
                    (hasAccess ? 
                      children
                    :
                    <Card className="bg-white border-0 rounded-3 mb-4">
                      <Card.Body className="p-4">
                        <div className="text-center">
                          <Image
                            src="/images/internal-error.png"
                            className="mb-5"
                            alt="error"
                            width={400}
                            height={437}
                          />

                          <h3 className="fs-24 mb-3">
                            Looks like we did not find this page, please try again later.
                          </h3>

                          <p className="mb-4">
                            But no worries! Our team is looking ever where while you wait
                            safely.
                          </p>

                          <Link
                            href="/dashboard/"
                            className="btn btn-primary py-2 px-4 fs-16 fw-medium"
                          >
                            <span className="d-inline-block py-1">Back To Dashboard</span>
                          </Link>
                        </div>
                      </Card.Body>
                    </Card>)
                  : ''
                }
              </LayoutProvider>
            </MetadataProvider>
          </Provider>
        </SessionProvider>
      </body>
    </html>
  );
}
