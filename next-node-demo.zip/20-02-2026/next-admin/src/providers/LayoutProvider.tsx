"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import LeftSidebar from "@/components/Layout/LeftSidebar";
import TopNavbar from "@/components/Layout/TopNavbar";
import Footer from "@/components/Layout/Footer";
import ControlPanel from "@/components/Layout/ControlPanel";
// import { SessionProvider } from 'next-auth/react';
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useSession } from "next-auth/react";
import { useMetadata } from '@/context/MetadataContext';
import { useAppDispatch } from '@/redux/hooks';
import {
  getMenuDetails
} from "@/redux/features/dataSlice";

const LayoutProvider = ({ children }) => {
  const [active, setActive] = useState(false);
  const pathname = usePathname();
  const { setMetadata } = useMetadata();
  const dispatch = useAppDispatch();
  const { data: session } = useSession();
  // console.log('Session Value => ', session);
  const toggleActive = () => {
    setActive(!active);
  };

  // Routes where sidebar, navbar, footer should NOT appear
  const excludedRoutes = [
    "/sign-in",
    "/sign-up",
    "/forgot-password",
    "/reset-password",
    "/lock-screen",
    "/confirm-email",
    "/logout",
    "/",
    "/front-pages/features",
    "/front-pages/team",
    "/front-pages/faq",
    "/front-pages/contact"
  ];

const showLayout = !excludedRoutes.includes(pathname);

  useEffect(() => {
    if(session){
      getMenuData();
    }    
  }, []);

  const getMenuData = async () => {
    try {
      const link = `${pathname}/`;
      const params:any = {link};
      const menuData = await dispatch(getMenuDetails(params)).unwrap();
      if(menuData.data){
        setMetadata({
          title: menuData.data.name,
          description: menuData.data.name,
        });
      }
      // console.log('menuData', menuData);
    } catch (err) {
      console.error(err?.message || "Failed to load data");
    }
  };

  return (
    <>    
      <div className={`main-wrapper-content ${active ? "active" : ""}`}>  
        <ToastContainer position="top-right" autoClose={3000} />
        {showLayout && <LeftSidebar toggleActive={toggleActive} />}

        <div className="main-content d-flex flex-column">
          {showLayout && <TopNavbar toggleActive={toggleActive} />}
          {children}
          {showLayout && <Footer />}
        </div>
      </div>

      <div
        style={{
          position: "fixed",
          bottom: "0",
          right: "0",
          opacity: "0",
          visibility: "hidden"
        }}
      >
        <ControlPanel />
      </div>
    </>
  );
};

export default LayoutProvider;
