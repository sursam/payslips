// components/SessionSync.js
'use client';

import { useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useAppDispatch } from '@/redux/hooks';
import { setSession } from '@/redux/features/authSlice'; // Your Redux slice action
// import { signOut } from "next-auth/react";

export default function SessionSync() {
  const { data: session } = useSession();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (session) {
      // if(session.user?.needToLogout){
      //   signOut({ callbackUrl: "/sign-in" });
      // }
      dispatch(setSession(session)); // Dispatch the session data to Redux
    }
  }, [session, dispatch]);

  return null; // This component doesn't render anything visually
}