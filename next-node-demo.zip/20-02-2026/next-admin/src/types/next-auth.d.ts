import NextAuth, { type DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      uuid: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
      isVerified?: boolean;
      needToLogout?: boolean;
      accessToken?: string; // Add your custom properties here
    } & DefaultSession["user"];
  }

  interface JWT {
    accessToken?: string; // Add your custom properties here
  }
}