"use client";

import React, { useEffect, useState } from "react";
import { Row, Col, Card } from "react-bootstrap";
import { ApexOptions } from "apexcharts";
import dynamic from "next/dynamic";

// Dynamically import react-apexcharts with Next.js dynamic import
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

const PropertiesForSale = () => {
  const [isChartLoaded, setChartLoaded] = useState(false);

  useEffect(() => {
    setChartLoaded(true);
  }, []);

  const series = [75];

  const options:ApexOptions = {
    colors: ["#37D80A"],
    plotOptions: {
      radialBar: {
        hollow: {
          size: "35%",
          background: "#F5F7F8",
          margin: 10,
        },
        track: {
          background: "#F5F7F8",
        },
        dataLabels: {
          name: {
            offsetY: -10,
            color: "#4b9bfa",
            fontSize: ".625rem",
            show: false,
          },
          value: {
            show: true,
            offsetY: 5,
            color: "#3A4252",
            fontSize: "14px",
            fontWeight: 700,
            fontFamily: "Inter",
          },
        },
      },
    },
    stroke: {
      lineCap: "butt",
    },
    labels: ["Status"],
  };

  return (
    <>
      <Card className="bg-white rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <span className="d-inline-block border-success border bg-success bg-opacity-10 text-success rounded-pill fs-12 fw-medium px-2">
              + 75%
            </span>
            <span className="fs-12">Last 30 days</span>
          </div>
          <Row className="align-items-end">
            <Col sm={6}>
              <span className="d-block mb-2">Properties for Sale</span>
              <h3 className="mb-0 fs-20 mb-0">5,458</h3>
            </Col>

            <Col sm={6}>
              <div style={{ margin: "-36px 0 -36px 0" }}>
                {isChartLoaded && (
                  <Chart
                    options={options}
                    series={series}
                    type="radialBar"
                    height={170}
                    className="mt-4 mt-sm-0"
                  />
                )}
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </>
  );
};

export default PropertiesForSale;
