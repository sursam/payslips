"use client";

import { useState } from "react";
import { Row, Col, Form, Card, Spinner, InputGroup } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { forgotPassword } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import OTPInput from "../../Apps/FormFields/OTPInput";
import { Eye, EyeSlash } from 'react-bootstrap-icons';

interface ForgotForm {
    email: string;
    newPassword: string;
    confirmPassword: string;
    otp: string;
    uuid: string;
}

const ForgotPasswordForm = () => {
  const [loading, setLoading] = useState(false);
  const dispatch = useAppDispatch();
  const router = useRouter();
  var [state, setState] = useState<ForgotForm>({
    email: '',  
    newPassword: '',
    confirmPassword: '',
    otp: '',
    uuid: ''
  });
  var { email, newPassword, confirmPassword } = state;
  const [showVerification, setShowVerification] = useState<boolean>(false);
  const [apiOtp, setApiOtp] = useState('');
  const [showResetPassword, setShowResetPassword] = useState<boolean>(false); // State to control reset password section visibility
  const [showNewPassword, setShowNewPassword] = useState<boolean>(false); // State for new password visibility
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
  const [forgotOtpTimer, setForgotOtpTimer] = useState(0);

  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    // trigger(name);
  };

  var validationObject: any;
  if (!showVerification && !showResetPassword) {
      validationObject = {
          email: Yup.string()
              .required('Email is required')
              .email('Invalid email format'),
      };
  }
  if (showResetPassword) {
      validationObject = {
          newPassword: Yup.string()
              .required('New password is required')
              .matches(
                  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                  "Password must Contain minimum of 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
              ),
          confirmPassword: Yup.string()
              .required('Confirm password is required')
              .oneOf([Yup.ref('newPassword')], "Confirm password doesn't match")
      };
  }
  if (showVerification) {
      validationObject = {
          otp: Yup.string()
              .required('OTP is required')
              .matches(/^[0-9]+$/, "OTP must contain only digits")
              .min(4, 'OTP must be exactly 4 digits')
              .max(4, 'OTP must be exactly 4 digits'),
      };
  }
  const validationSchema = Yup.object().shape(validationObject);

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors }, setError, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {    
    clearErrors() 
    reset(state)
  }

  const onSubmit = async (formData) => {
    setLoading(true);
    try {
      var response:any;
      if (!showVerification && !showResetPassword) {
          const payload: any = {
              "email_id": formData.email,
          }
          response = await dispatch(forgotPassword(payload)).unwrap();
          if (response?.status === true) {
              const { message, otp } = response;
              // resetForm();
              setApiOtp(otp);
              setShowVerification(true);
              setForgotOtpTimer(60);
              // if (forgotOtpIntervalRef.current) clearInterval(forgotOtpIntervalRef.current);
              setInterval(() => {
                setForgotOtpTimer((t) => (t <= 1 ? 0 : t - 1));
              }, 1000);
              toast.success(message);
          } else {
              // toast.error(response?.message);
              setError("email", { type: "manual", message: response?.message });
          }
      }
      if (showVerification) {
          const payload: any = {
              "email_id": formData.email,
              "otp": formData.otp,
          }
          response = await dispatch(forgotPassword(payload)).unwrap();
          if (response?.status === true) {
              const { message, uuid } = response;
              setState(prevState => ({
                ...prevState,
                uuid
              }));
              setShowVerification(false);
              setShowResetPassword(true);
              toast.success(message);
              // resetForm();
          } else {
            setError("otp", { type: "manual", message: response?.message });
          }
      }
      if (showResetPassword) {
          const payload: any = {
              "email_id": formData.email,
              "uuid": formData.uuid,
              "password": formData.newPassword,
              "confirm_password": formData.confirmPassword,
          }
          response = await dispatch(forgotPassword(payload)).unwrap();
          if (response?.status === true) {
              const { message } = response;
              resetForm();
              const signInResponse = await signIn("credentials", { 
                email: formData.email, 
                password: formData.newPassword, 
                device_type: 1, 
                redirect: false, 
              });
              if (signInResponse.error) {
                let errorObj = JSON.parse(signInResponse.error);
                switch (errorObj.status) {
                  case 401:
                  case 403:
                  case 404:
                    setError("password", { type: "manual", message: errorObj.message });
                    break;
                }
                setLoading(false);
              } else {
                toast.success(message);
                router.push('/dashboard');
              }


          } else {
              toast.error(response?.message);
          }
      }

    } catch (error) {
        setError("email", { type: "manual", message: error?.message || "Send failed" });
        console.error("Error sending change password otp:", error);
    } finally {
        setLoading(false);
    }
  };
  const resetForm = () => {
      clearErrors();
      setState(prevState => ({
          ...prevState,
          email: '',
          newPassword: '',
          confirmPassword: '',
          otp: '',
      }));
      setLoading(false);
  } 
  const resendOtp = async () => {
        setLoading(true);
        clearErrors();
        const payload: any = {
            "email_id": email,
        }
        const response = await dispatch(forgotPassword(payload)).unwrap();
        if (response?.status === true) {
            const { otp } = response;
            setApiOtp(otp);
            setForgotOtpTimer(60);
            // if (forgotOtpIntervalRef.current) clearInterval(forgotOtpIntervalRef.current);
            setInterval(() => {
              setForgotOtpTimer((t) => (t <= 1 ? 0 : t - 1));
            }, 1000);
            toast.success("OTP sent again to your email Id");
        } else {
            setError("otp", { type: "manual", message: response?.message });
        }
        setLoading(false);
  };
  const handleOTPComplete = (otpValue) => {
    // console.log('OTP Entered:', otpValue);
    clearErrors();
    setState(prevState => ({
        ...prevState,
        otp: otpValue
    }));
  };
  return (
    <>
      <div className="auth-main-content m-auto m-1230 px-3">
        <Row className="align-items-center">
          <Col lg={12}>
            <div className="min-vw-25 mw-480 ms-lg-auto">
              <div className="mb-4 text-center">
                <Image
                  src="/images/logo/logo.png"
                  className="for-light-logo"
                  alt="Logo"
                  width={177}
                  height={86}
                />
                <Image
                  src="/images/logo/logo_dark.png"
                  className="rounded-3 for-dark-logo"
                  alt="Logo"
                  width={177}
                  height={86}
                />
              </div>

              <Card className="bg-white border-0 rounded-3 mb-4 shadow-lg">
                <Card.Body className="p-5">
                  <h3 className="fs-28 mb-2">{showResetPassword ? 'Reset Password' : showVerification ? 'Verify OTP' : 'Forgot Password?'}</h3>

                  <Form onSubmit={handleSubmit(onSubmit)}>
                    {!showVerification && !showResetPassword && (
                      <>
                        <p className="fw-medium fs-16 mb-4">
                          Enter your Registred Email.
                        </p>
                        <Form.Group className="mb-3">
                          <label className="label text-secondary">Email Address</label>
                          <Form.Control
                            type="email"
                            className={`h-55 ${errors.email ? 'is-invalid' : ''}`}
                            placeholder="example@eclicksoftwares.in"
                            {...register('email', {onChange: handleChange})}
                            value={email}
                            autoComplete="off"
                          />
                          <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                        </Form.Group>
                        <Form.Group>
                          <button
                            type="submit"
                            className="btn btn-primary btn-green fw-medium py-2 px-3 w-100"
                            onClick={submitForm}
                            disabled={loading}
                          >
                            <div className="d-flex align-items-center justify-content-center py-1">
                              {loading ? (
                                <>
                                  <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                                  <span className="ms-2">Please Wait...</span>
                                </>
                              ) : (
                                <>
                                  <span className="material-symbols-outlined fs-20 text-white me-2">
                                    autorenew
                                  </span>
                                  <span>Send</span>
                                </>
                              )}
                            </div>
                          </button>
                        </Form.Group>
                        <Form.Group className="d-flex justify-content-between align-items-end flex-wrap">
                          <p>&nbsp;</p>
                          <p>
                            Back to{" "}
                            <Link href='/sign-in/' className="fw-medium text-primary text-decoration-none text-green">
                              Sign In
                            </Link>
                          </p>                      
                        </Form.Group>
                      </>
                    )}

                    {showVerification && (
                      <>
                          <Form.Group>
                              <p>
                                  We sent a 4-digit OTP to your email Id <br /> <strong>{email}</strong> (OTP: {apiOtp})
                              </p>
                              <Form.Group>
                                  <OTPInput className={errors.otp ? 'is-invalid' : ''} length={4} onComplete={handleOTPComplete} />
                                  <div className="invalid-feedback">{errors.otp?.message?.toString()}</div> 
                              </Form.Group>

                          </Form.Group>
                          <Form.Group className="py-3">
                              <button type='submit' className={`${loading ? 'loading disabled' : ''} btn btn-primary btn-green fw-medium py-2 px-3 w-100`} onClick={submitForm}>Validate</button>
                          </Form.Group>
                          <Form.Group className="d-flex justify-content-between align-items-end flex-wrap">
                              <Form.Group>
                                  <p>
                                    {forgotOtpTimer > 0 ? (
                                      <span className="text-muted">
                                        Resend OTP in <span className="text-danger fw-bold">{forgotOtpTimer}s</span>
                                      </span>
                                    ) : (
                                      <>
                                        Didn’t receive OTP?{' '}
                                        <Link href="#" className="fw-medium text-primary text-decoration-none text-green" onClick={resendOtp}>
                                          Resend
                                        </Link>
                                      </>
                                    )}
                                  </p>
                              </Form.Group>
                              <Form.Group className="d-flex justify-content-between align-items-end flex-wrap">
                                <p>
                                  Back to{" "}
                                  <Link href='/sign-in/' className="fw-medium text-primary text-decoration-none text-green">
                                    Sign In
                                  </Link>
                                </p>                      
                              </Form.Group>
                          </Form.Group>
                      </>
                    )}

                    {/* New Password Section */}
                    {showResetPassword && (
                      <>
                          <Form.Group>
                              <p>
                                  Type your new password and repeat for confirming your password
                              </p>
                              <Form.Group className="mb-3">
                                <label className="label text-secondary">Password</label>
                                <InputGroup className={errors.newPassword ? 'is-invalid' : ''}>
                                  <Form.Control
                                      {...register('newPassword', { onChange: handleChange })}
                                      value={newPassword}
                                      type={showNewPassword ? 'text' : 'password'}
                                      placeholder="*********"
                                  />
                                  <InputGroup.Text onClick={() => setShowNewPassword(!showNewPassword)}>
                                    {!showNewPassword ? <EyeSlash /> : <Eye />}
                                  </InputGroup.Text>
                                </InputGroup>                                
                                <div className="invalid-feedback">{errors.newPassword?.message?.toString()}</div>
                              </Form.Group>
                              <Form.Group className="mb-3">
                                <label className="label text-secondary">Confirm Password</label>
                                <InputGroup className={errors.confirmPassword ? 'is-invalid' : ''}>
                                  <Form.Control
                                      {...register('confirmPassword', { onChange: handleChange })}
                                      value={confirmPassword}
                                      type={showConfirmPassword ? 'text' : 'password'}
                                      placeholder="*********"
                                  />
                                  <InputGroup.Text onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                                    {!showConfirmPassword ? <EyeSlash /> : <Eye />}
                                  </InputGroup.Text>
                                </InputGroup>
                                <div className="invalid-feedback">{errors.confirmPassword?.message?.toString()}</div>
                              </Form.Group>
                              <Form.Group>
                                  <button type='submit' className={`btn btn-primary btn-green fw-medium py-2 px-3 w-100 ${loading ? 'loading disabled' : ''}`} onClick={submitForm}>Reset Password</button>
                              </Form.Group>
                          </Form.Group>
                          <Form.Group className="d-flex justify-content-between align-items-end flex-wrap">
                            <p>&nbsp;</p>
                            <p>
                              Back to{" "}
                              <Link href='/sign-in/' className="fw-medium text-primary text-decoration-none text-green">
                                Sign In
                              </Link>
                            </p>                      
                          </Form.Group>
                      </>
                    )}

                  </Form>
                </Card.Body>
              </Card>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default ForgotPasswordForm;
