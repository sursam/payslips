"use client";

import { useState } from "react";
import { Row, Col, Form, Spinner, Card, InputGroup } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { signIn } from "next-auth/react";
// import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { Eye, EyeSlash } from 'react-bootstrap-icons';

const SignInForm = () => {
  // const { data: session, status } = useSession();
  // console.log('session => ', session);
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  var [state, setState] = useState({
    email: '',
    password: '',    
  });
  var { email, password } = state;
  const handleChange = (event) => {    
    const { name, value } = event.target;
    setState(prevState => ({
      ...prevState,
      [name]: value,
    }));
    // trigger(name);
  };

  const validationSchema = Yup.object().shape({
    email: Yup.string()
        .required('Email is required')
        .email('Invalid email format'),
    password: Yup.string().required('Password is required'),
  });

  var formOptions = { resolver: yupResolver(validationSchema) };
  var { register, handleSubmit, reset, formState: { errors }, setError, clearErrors, trigger } = useForm(formOptions);

  const submitForm = () => {    
    clearErrors() 
    reset(state)
  }

  const onSubmit = async (formData) => {
    setLoading(true);
    const email = formData.email;
    const password = formData.password;
    const device_type = 1;
    try {
      const response = await signIn("credentials", { email, password, device_type, redirect: false, });
      if (response.error) {
        let errorObj = JSON.parse(response.error);
        switch (errorObj.status) {
          case 401:
          case 403:
          case 404:
            setError("password", { type: "manual", message: errorObj.message });
            break;
        }
        setLoading(false);
      } else {
        toast.success('Successfully logged in');
        router.push('/dashboard');
      }
    } catch (error) {
      console.error("Authentication error:", error);
      setLoading(false);
    }
  }; 
  return (
    <>
      <div className="auth-main-content m-auto m-1230 px-3">
        <Row className="align-items-center">
          <Col lg={12}>
            <div className="min-vw-25 mw-480 ms-lg-auto">
              <div className="mb-4 text-center">
                <Image
                  src="/images/logo/logo.png"
                  className="for-light-logo"
                  alt="Logo"
                  width={177}
                  height={86}
                />
                <Image
                  src="/images/logo/logo_dark.png"
                  className="for-dark-logo"
                  alt="Logo"
                  width={177}
                  height={86}
                />
              </div>

              <Card className="bg-white border-0 rounded-3 mb-4 shadow-lg">
                <Card.Body className="p-5">

                  <h3 className="fs-24 mb-2">Welcome to Eclick!</h3>
                  <p className="fw-medium fs-14 mb-4">
                    Sign In with your login credentials
                  </p>

                  <Form onSubmit={handleSubmit(onSubmit)}>
                    <Form.Group className="mb-3">
                      <label className="label text-secondary">Email Address</label>
                      <Form.Control
                        type="email"
                        className={`h-55 ${errors.email ? 'is-invalid' : ''}`}
                        placeholder="example@eclicksoftwares.in"
                        {...register('email', {onChange: handleChange})}
                        value={email}
                        autoComplete="off"
                      />
                      <div className="invalid-feedback">{errors.email?.message?.toString()}</div>
                    </Form.Group>

                    <Form.Group>
                      <label className="label text-secondary">Password</label>
                      <InputGroup className={errors.password ? 'is-invalid' : ''}>
                        <Form.Control
                            {...register('password', { onChange: handleChange })}
                            value={password}
                            type={showPassword ? 'text' : 'password'}
                            placeholder="*********"
                            autoComplete="off"
                        />
                        <InputGroup.Text onClick={() => setShowPassword(!showPassword)}>
                          {!showPassword ? <EyeSlash /> : <Eye />}
                        </InputGroup.Text>
                      </InputGroup>
                      <div className="invalid-feedback">{errors.password?.message?.toString()}</div>
                    </Form.Group>

                    <Form.Group className="mb-3 d-flex justify-content-between align-items-end flex-wrap">
                      <p>&nbsp;</p>
                      <Link href='/forgot-password/' className="fw-medium text-primary text-decoration-none text-green">
                        Forgot Password?
                      </Link>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <button
                        type="submit"
                        className="btn btn-primary btn-green fw-medium py-2 px-3 w-100"
                        onClick={submitForm}
                        disabled={loading}
                      >
                        <div className="d-flex align-items-center justify-content-center py-1">
                          {loading ? (
                            <>
                              <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                              <span className="ms-2">Please Wait...</span>
                            </>
                          ) : (
                            <>
                              <span className="material-symbols-outlined fs-20 text-white me-2">
                                login
                              </span>
                              <span>Sign In</span>
                            </>
                          )}
                        </div>
                      </button>
                    </Form.Group>
                  </Form>
                </Card.Body>
              </Card>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default SignInForm;
