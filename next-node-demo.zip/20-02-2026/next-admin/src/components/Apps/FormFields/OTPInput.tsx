import React, { useRef, useState } from 'react';
import { Form } from "react-bootstrap";

const OTPInput = ({ length = 4, onComplete, className }) => {
  const [otp, setOtp] = useState(new Array(length).fill(''));
  // Create a ref array to store references to all input elements
  const inputRefs = useRef([]);

  const handleChange = (value, index) => {
    // Basic validation: only allow digits (optional, you can customize pattern)
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    // Update the current input field's value
    newOtp[index] = value;
    setOtp(newOtp);

    // Autofocus on the next input field if the current one has a value and it's not the last field
    if (value && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
    
    // Optional: Focus on the previous input field if the current one is cleared (backspace handling)
    if (!value && index > 0) {
        inputRefs.current[index - 1]?.focus();
    }
    onComplete(newOtp.join(''));
    // Check if all fields are filled and call the onComplete handler
    // if (newOtp.every(digit => digit !== '')) {
    //   onComplete(newOtp.join(''));
    // }
  };

  // Focus on the first input field when the component mounts
  React.useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  return (
    <div style={{ display: 'flex', gap: '10px' }} className={className}>
      {otp.map((digit, index) => (
        <Form.Control
          key={index}
          maxLength={1}
          value={digit}
          onChange={(e) => handleChange(e.target.value, index)}
          ref={(ref) => (inputRefs.current[index] = ref)}
          className="otpField"
        />
      ))}
    </div>
  );
};
export default OTPInput;