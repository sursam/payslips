"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Card, Form, Table, Button, InputGroup } from "react-bootstrap";
import Image from "next/image";
import { useSession } from "next-auth/react";
import { useSelector } from "react-redux";
import Select from "react-select";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useAppDispatch } from '@/redux/hooks';
// import Link from "next/link";
import {
  fetchRoleData,
  fetchAdminUserList,
  alterAdminUser,
  detailAdminUser,
  deleteAdminUserData,
} from "@/redux/features/dataSlice";
import { toast } from "react-toastify";
import SearchForm from "./SearchForm";
import {can} from "@/utils/helper";
import InternalError from "@/components/InternalError";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?[0-9]{7,15}$/;

const AdminUsers = () => {
  const accessToken = useSelector((state:any) => state.auth?.session?.accessToken);
  console.log('Error', can(['view-admin-users'], accessToken));
  if(!can(['view-admin-users'], accessToken)){
    return (
      <InternalError />
    )
  }
  const dispatch = useAppDispatch();
  const { data: session } = useSession();

  const [roles, setRoles] = useState([]);
  const [adminUsersData, setAdminUsersData] = useState([]);

  const [searchQuery, setSearchQuery] = useState("");

  // pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  // modal state
  const [isShowModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState("create");

  const [form, setForm] = useState({
    id: null,
    roleId: "",
    name: "",
    email_id: "",
    phone_number: "",
    password: "",
    confirmPassword: "",
    status: "",
  });
  const [selectedRole, setSelectedRole] = useState(null);

  // validation errors
  const [errors, setErrors]:any = useState({});

  // fetch roles and users on mount
  useEffect(() => {
    const load = async () => {
      try {
        const rolesData = await dispatch(fetchRoleData()).unwrap();
        const roleList = rolesData?.data || rolesData || [];
        setRoles(roleList);

        loadAdminUserList();
        // const usersData = await dispatch(fetchAdminUserList()).unwrap();
        // const list = usersData?.data || usersData || [];
        // setAdminUsersData(list);
      } catch (err) {
        toast.error(err?.message || "Failed to load data");
      }
    };
    load();
  }, [dispatch]);

  const loadAdminUserList = async (searchText = '') => {
    try {
      const params:any = { searchText };
      const usersData = await dispatch(fetchAdminUserList(params)).unwrap();
      const list = usersData?.data || usersData || [];
      console.log(list);
      setAdminUsersData(list);
    } catch (err) {
      toast.error(err?.message || "Failed to load admin data");
    }
  };

  const roleOptions = roles.map((r) => ({ value: r.id ?? r.roleId ?? r.value, label: r.roleName ?? r.name ?? r.label }));

  // filtered users based on searchQuery
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return adminUsersData;
    const q = searchQuery.toLowerCase();
    return adminUsersData.filter((entry) => {
      const user = entry?.user || {};
      return (
        String(entry.id).toLowerCase().includes(q) ||
        String(user.name || "").toLowerCase().includes(q) ||
        String(user.email_id || "").toLowerCase().includes(q) ||
        String(user.phone_number || "").toLowerCase().includes(q)
      );
    });
  }, [adminUsersData, searchQuery]);

  // pagination
  const pageCount = Math.max(1, Math.ceil(filteredUsers.length / pageSize));
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, currentPage]);

  useEffect(() => {
    if (currentPage > pageCount) setCurrentPage(1);
  }, [pageCount, currentPage]);

  const toggleModal = () => {
    setShowModal((s) => !s);
    if (!isShowModal) {
    } else {
      resetForm();
    }
  };

  const resetForm = () => {
    setForm({
      id: null,
      roleId: "",
      name: "",
      email_id: "",
      phone_number: "",
      password: "",
      confirmPassword: "",
      status: "",
    });
    setSelectedRole(null);
    setErrors({});
    setModalMode("create");
  };

  // open modal for create
  const handleOpenCreate = () => {
    resetForm();
    setModalMode("create");
    setShowModal(true);
  };

  const openModalWithUser = async (userId, mode = "view") => {
    try {
      const params:any = { id: userId };
      const res = await dispatch(detailAdminUser(params)).unwrap();
      const data = res?.data || res || {};
      const user = data?.user || data;
      const roleId = data?.roleId ?? user?.roleId ?? data?.role?.id ?? user?.role?.id ?? "";
      const statusVal = (user?.status !== undefined && user?.status !== null) ? String(user.status) : (data?.status !== undefined ? String(data.status) : "");
      setForm({
        id: user?.id ?? data?.id ?? null,
        roleId: roleId,
        name: user?.name ?? user?.fullName ?? "",
        email_id: user?.email_id ?? user?.email ?? "",
        phone_number: user?.phone_number ?? user?.phone ?? "",
        password: "",
        confirmPassword: "",
        status: statusVal,
      });
      const foundRole = roleOptions.find((r) => String(r.value) === String(roleId));
      setSelectedRole(foundRole || null);
      setModalMode(mode);
      setErrors({});
      setShowModal(true);
    } catch (err) {
      toast.error(err?.message || "Failed to load user details");
    }
  };

  const handleViewClick = (user) => {
    const userId = user?.user?.id ?? user?.id ?? user?.userId;
    if (!userId) return;
    openModalWithUser(userId, "view");
  };

  const handleEditClick = (user) => {
    const userId = user?.user?.id ?? user?.id ?? user?.userId;
    if (!userId) return;
    openModalWithUser(userId, "edit");
  };

  const handleDelete = (id) => {
    const userId = id;
    if (!userId) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>Do you want to delete this admin user?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                (async () => {
                  try {
                    const params:any = { id: userId };
                    const response = await dispatch(deleteAdminUserData(params)).unwrap();
                    if (response.status == true || response.status === "true") {
                      toast.success(response.message ?? "Admin user deleted successfully");
                    } else {
                      toast.error(response.message || "Failed to delete admin user.");
                    }
                    const usersData = await dispatch(fetchAdminUserList()).unwrap();
                    setAdminUsersData(usersData?.data || usersData || []);
                  } catch (error) {
                    toast.error(error?.message || "Failed to delete admin user.");
                  } finally {
                    onClose();
                  }
                })();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  // handle controlled form changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((s) => ({ ...s, [name]: value }));
    setErrors((err) => ({ ...err, [name]: undefined }));
  };

  const validate = () => {
    const e:any = {};
    if (!form.name || String(form.name).trim().length < 2) e.name = "Name must be at least 2 characters.";
    if (!form.email_id || !EMAIL_REGEX.test(String(form.email_id).trim())) e.email_id = "Please provide a valid email.";
    if (!form.phone_number || !PHONE_REGEX.test(String(form.phone_number).trim())) e.phone_number = "Please provide a valid phone number.";
    if (modalMode === "create") {
      if (!form.password || String(form.password).length < 6) e.password = "Password must be at least 6 characters.";
      if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match.";
    } else if (modalMode === "edit") {
      if (form.password) {
        if (String(form.password).length < 6) e.password = "Password must be at least 6 characters.";
        if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match.";
      }
    }
    if (!selectedRole || !selectedRole.value) e.roleId = "Please select a role.";
    if (form.status === "" || form.status === null) e.status = "Please select status.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      const fd:any = new FormData();
      if (form.id) fd.append("id", form.id);
      fd.append("roleId", selectedRole.value);
      fd.append("name", form.name);
      fd.append("email_id", form.email_id);
      fd.append("phone_number", form.phone_number);
      if (form.password) fd.append("password", form.password);
      fd.append("confirmPassword", form.confirmPassword);
      fd.append("status", form.status);

      const response = await dispatch(alterAdminUser(fd)).unwrap();
      if(response.status == true || response.status === 'true'){
        toast.success(response.message);
      }else{
        toast.error(response.message || "Failed to save admin user.");
      }
      const usersData = await dispatch(fetchAdminUserList()).unwrap();
      setAdminUsersData(usersData?.data || usersData || []);
      setShowModal(false);
      resetForm();
    } catch (err) {
      toast.error(err?.message || "Failed to save admin user");
    }
  };

  // UI helpers
  const isViewMode = modalMode === "view";
  const isEditMode = modalMode === "edit";
  const isCreateMode = modalMode === "create";

  return (
    <>
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
            <SearchForm loadAdminUserList={loadAdminUserList} />
            {/* <InputGroup style={{ maxWidth: 300 }}>
              <Form.Control
                placeholder="Search by name, email or phone..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </InputGroup> */}

            <div className="text-end">
              {can(['add-admin-users'], accessToken) ?
                <button
                  className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                  onClick={handleOpenCreate}
                >
                  <span className="py-sm-1 d-block">
                    <i className="ri-add-line"></i>
                    <span>Add New Admin User</span>
                  </span>
                </button>
              : ''}
            </div>
          </div>
          <div className="default-table-area">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th scope="col">Sl No.</th>
                    <th scope="col">Admin User</th>
                    <th scope="col">Role</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedUsers.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-4">
                        No results
                      </td>
                    </tr>
                  )}
                  {paginatedUsers.map((entry, i) => (
                      <tr key={entry.id}>
                        <td>{i+1}</td>
                        <td>
                          <div className="d-flex align-items-center">
                            {entry?.profileImage && (
                              <Image
                                src={entry.profileImage}
                                className="wh-34 rounded-circle"
                                alt="user"
                                width={34}
                                height={34}
                              />
                            )}
                            <h6 className="mb-0 fs-14 fw-medium ms-2">{entry?.name}</h6>
                          </div>
                        </td>
                        <td>{entry?.userRole[0].roleName}</td>
                        <td>{entry?.email_id}</td>
                        <td>{entry?.phone_number}</td>
                        <td>
                          <span
                            className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${
                              String(entry?.status) === "0" ? "bg-success text-success" : "bg-danger text-danger"
                            }`}
                          >
                            {String(entry?.status) === "0" ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            <button
                              className="border-0 bg-transparent"
                              onClick={() => handleViewClick(entry)}
                              title="View"
                            >
                              <span className="material-symbols-outlined fs-16 text-primary">visibility</span>
                            </button>
                            {can(['edit-admin-users'], accessToken) ?
                              <button
                                className="border-0 bg-transparent"
                                onClick={() => handleEditClick(entry)}
                                title="Edit"
                              >
                                <span className="material-symbols-outlined fs-16 text-body">edit</span>
                              </button>
                            : ''} 
                            {can(['delete-admin-users'], accessToken) ?
                              <button
                                className="border-0 bg-transparent"
                                onClick={() => handleDelete(entry?.id)}
                                title="Delete"
                              >
                                <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                              </button>
                            : ''} 
                          </div>
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </Table>

              <div className="p-0">
                <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                  <span className="fs-12 fw-medium">
                    Showing {Math.min(filteredUsers.length, (currentPage - 1) * pageSize + 1)}-
                    {Math.min(filteredUsers.length, currentPage * pageSize)} of {filteredUsers.length} Results
                  </span>

                  <nav aria-label="Page navigation example">
                    <ul className="pagination mb-0 justify-content-center">
                      <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                        <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                          <span className="material-symbols-outlined">keyboard_arrow_left</span>
                        </button>
                      </li>

                      {Array.from({ length: pageCount }).map((_, idx) => {
                        const page = idx + 1;
                        return (
                          <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                            <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                              {page}
                            </button>
                          </li>
                        );
                      })}

                      <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                        <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                          <span className="material-symbols-outlined">keyboard_arrow_right</span>
                        </button>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>

      {/* Modal */}
      <div className={`custom-modal right ${isShowModal ? "show" : ""}`}>
        <div className="custom-modal-content position-relative z-3">
          <div className="border-bottom py-3 px-4 d-flex align-items-center justify-content-between">
            <h3 className="fs-18 mb-0">
              {isViewMode ? "Admin User Details" : isEditMode ? "Edit Admin User" : "Add New Admin User"}
            </h3>
            <div className="close-link" onClick={() => { setShowModal(false); resetForm(); }}>
              <span className="material-symbols-outlined">close</span>
            </div>
          </div>
          <div className="p-4">
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-4">
                <label className="label text-secondary">Role</label>
                <Select
                  instanceId="role"
                  id="role"
                  options={roleOptions}
                  value={selectedRole}
                  onChange={(val) => {
                    setSelectedRole(val);
                    setForm((s) => ({ ...s, roleId: val?.value }));
                    setErrors((err) => ({ ...err, roleId: undefined }));
                  }}
                  placeholder="Select role"
                  isDisabled={isViewMode}
                />
                {errors.roleId && <div className="text-danger small mt-1">{errors.roleId}</div>}
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Admin User Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  className="text-dark"
                  placeholder="Admin User Name"
                  value={form.name}
                  onChange={handleChange}
                  isInvalid={!!errors.name}
                  disabled={isViewMode}
                  required
                />
                <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email_id"
                  className="text-dark"
                  placeholder="Email"
                  value={form.email_id}
                  onChange={handleChange}
                  isInvalid={!!errors.email_id}
                  disabled={isViewMode}
                  required
                />
                <Form.Control.Feedback type="invalid">{errors.email_id}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Phone</Form.Label>
                <Form.Control
                  type="text"
                  name="phone_number"
                  className="text-dark"
                  placeholder="Phone"
                  value={form.phone_number}
                  onChange={handleChange}
                  isInvalid={!!errors.phone_number}
                  disabled={isViewMode}
                  required
                />
                <Form.Control.Feedback type="invalid">{errors.phone_number}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Password</Form.Label>
                <Form.Control
                  type="password"
                  name="password"
                  className="text-dark"
                  placeholder={isEditMode ? "Leave blank to keep current password" : "Password"}
                  value={form.password}
                  onChange={handleChange}
                  isInvalid={!!errors.password}
                  disabled={isViewMode}
                  required={isCreateMode}
                />
                <Form.Control.Feedback type="invalid">{errors.password}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Confirm Password</Form.Label>
                <Form.Control
                  type="password"
                  name="confirmPassword"
                  className="text-dark"
                  placeholder="Confirm Password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  isInvalid={!!errors.confirmPassword}
                  disabled={isViewMode}
                  required={isCreateMode}
                />
                <Form.Control.Feedback type="invalid">{errors.confirmPassword}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Status</Form.Label>
                <Form.Select
                  name="status"
                  className="form-control text-dark"
                  value={form.status}
                  onChange={handleChange}
                  disabled={isViewMode}
                  isInvalid={!!errors.status}
                  required
                >
                  <option value="">Select</option>
                  <option value="0">Active</option>
                  <option value="1">Inactive</option>
                </Form.Select>
                {errors.status && <div className="text-danger small mt-1">{errors.status}</div>}
              </Form.Group>

              {!isViewMode && (
                <Form.Group className="d-flex gap-3">
                  <Button variant="primary" type="submit" className="text-white fw-semibold py-2 px-2 px-sm-3">
                    <span className="py-sm-1 d-block">
                      <i className="ri-add-line text-white"></i>{" "}
                      <span>{isCreateMode ? "Create New Admin User" : "Update Admin User"}</span>
                    </span>
                  </Button>
                  {/* <Button variant="secondary" onClick={() => { setShowModal(false); resetForm(); }}>
                    Cancel
                  </Button> */}
                </Form.Group>
              )}
            </Form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminUsers;
