"use client";

import React, { useEffect, useMemo, useState, useRef } from "react";
import { Card, Table, Form, Button } from "react-bootstrap";
import Link from "next/link";
import { useSelector } from "react-redux";
import { useAppDispatch } from '@/redux/hooks';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import {
    fetchBookingServiceList,
    deleteBookingService,
} from "@/redux/features/dataSlice";
import SearchForm from "./SearchForm";

const pageSizeDefault = 5;

const ServiceRequestList = () => {
    const dispatch = useAppDispatch();
    const accessToken = useSelector((s:any) => s.auth?.session?.accessToken);

    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(false);

    const [search, setSearch] = useState("");
    const searchRef = useRef(null);

    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(pageSizeDefault);

    // load all requests once (client-side search + pagination per request)
    const loadRequests = async () => {
        try {
            setLoading(true);
            const res = await dispatch(fetchBookingServiceList()).unwrap();
            const list = res?.data || res || [];
            setRequests(list);
        } catch (err) {
            toast.error(err?.message || "Failed to load service requests");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadRequests();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dispatch, accessToken]);

    // debounce search input
    const handleSearchChange = (e) => {
        const q = e.target.value;
        setSearch(q);
        if (searchRef.current) clearTimeout(searchRef.current);
        searchRef.current = setTimeout(() => {
            setCurrentPage(1);
        }, 300);
    };

    // filtered list
    const filtered = useMemo(() => {
        if (!search?.trim()) return requests;
        const q = search.toLowerCase();
        return requests.filter((r) => {
            const svcName = r?.service?.name ?? "";
            const addrName = r?.address?.fullName ?? r?.address?.forWhom ?? "";
            const uuid = r?.uuid ?? "";
            const packageName = r?.service_package?.packageName ?? "";
            return (
                String(svcName).toLowerCase().includes(q) ||
                String(addrName).toLowerCase().includes(q) ||
                String(uuid).toLowerCase().includes(q) ||
                String(packageName).toLowerCase().includes(q)
            );
        });
    }, [requests, search]);

    // pagination helpers
    const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
    useEffect(() => {
        if (currentPage > pageCount) setCurrentPage(1);
    }, [pageCount, currentPage]);

    const paginated = useMemo(() => {
        const start = (currentPage - 1) * pageSize;
        return filtered.slice(start, start + pageSize);
    }, [filtered, currentPage, pageSize]);

    const formatDate = (d) => {
        if (!d) return "-";
        try {
            const dt = new Date(d);
            return dt.toLocaleDateString() + " " + dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        } catch {
            return d;
        }
    };

    const mapStatus = (s) => {
        // adjust mapping as needed; example mapping:
        switch (Number(s)) {
            case 0:
                return { text: "Pending", className: "bg-warning text-dark" };
            case 1:
                return { text: "Approved", className: "bg-success text-white" };
            case 2:
                return { text: "Rejected", className: "bg-danger text-white" };
            case 3:
                return { text: "Completed", className: "bg-primary text-white" };
            default:
                return { text: "Unknown", className: "bg-secondary text-white" };
        }
    };

    const handleClickDeleteService = async (uuid) => {
        if (!uuid) return;
        try {
            const params:any = { uuid };
            const res = await dispatch(deleteBookingService(params)).unwrap();
            if (res?.status === true || res?.status === "true") {
            toast.success(res.message || "Booking service request deleted");
            await loadRequests();
            } else {
            toast.error(res.message || "Failed to delete");
            }
        } catch (err) {
            toast.error(err?.message || "Unexpected error deleting service");
        }
    };

      const handleDelete = (uuid) => {
        if (!uuid) return;
        confirmAlert({
          customUI: ({ onClose }) => {
            return (
              <div className='custom-ui'>
                <h1>Are you sure?</h1>
                <p>You want to delete this service?</p>
                <button onClick={onClose}>No</button>
                <button
                  onClick={() => {
                    handleClickDeleteService(uuid);
                    onClose();
                  }}
                >
                  Yes, Delete it!
                </button>
              </div>
            );
          }
        });
      };

    return (
        <>
            <ToastContainer position="top-right" />
            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="p-0">
                        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
                            <SearchForm handleSearchChange={handleSearchChange} />
                        </div>
                    </div>

                    <div className="default-table-area p-0">
                        <div className="table-responsive">
                            <Table className="align-middle">
                                <thead>
                                    <tr>
                                        <th>Sl No.</th>
                                        <th>Service Name</th>
                                        <th>Package Name</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginated.length ? (
                                        paginated.map((r, idx) => {
                                            console.log("Rendering service request:", r);
                                            const globalIndex = (currentPage - 1) * pageSize + idx + 1;
                                            const svcName = r?.service?.name ?? "—";
                                            const dateText = r?.date ? `${r.date} ${r.startTime ?? ""}` : formatDate(r?.createdAt);
                                            const status = mapStatus(r?.status);
                                            return (
                                                <tr key={r.id ?? r.uuid ?? idx}>
                                                    <td className="text-body">{globalIndex}</td>
                                                    <td>
                                                        <div className="d-flex align-items-center">
                                                            <h6 className="mb-0 fs-14 fw-medium ms-2">{svcName}</h6>
                                                        </div>
                                                    </td>
                                                     <td>
                                                        <div className="d-flex align-items-center">
                                                            <h6 className="mb-0 fs-14 fw-medium ms-2">{r?.service_package?.packageName ?? "—"}</h6>
                                                        </div>
                                                    </td>
                                                    <td className="text-body">{dateText}</td>
                                                    <td>
                                                        <span className={`badge p-2 fs-12 fw-normal ${status.className}`}>{status.text}</span>
                                                    </td>
                                                    <td>
                                                        <div className="d-flex align-items-center gap-1">
                                                            <Link href={`/modules/service-requests/view/${r.id}`} className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1" title="Edit">
                                                                <i className="material-symbols-outlined fs-16 text-body">visibility</i>
                                                            </Link>
                                                            <button
                                                                className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                                                                onClick={() => handleDelete(r.uuid)}
                                                                title="Delete"
                                                            >
                                                                <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })
                                    ) : (
                                        <tr>
                                            <td colSpan={6} className="text-center py-4">
                                                {loading ? "Loading..." : "No service requests found"}
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </div>

                        <div>
                            <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                                <span className="fs-12 fw-medium">
                                    Showing {requests.length === 0 ? 0 : Math.min(requests.length, (currentPage - 1) * pageSize + 1)}-
                                    {Math.min(requests.length, currentPage * pageSize)} of {requests.length} Results
                                </span>

                                <nav aria-label="Page navigation example">
                                    <ul className="pagination mb-0 justify-content-center">
                                        <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                                                <span className="material-symbols-outlined">keyboard_arrow_left</span>
                                            </button>
                                        </li>

                                        {Array.from({ length: pageCount }).map((_, idx) => {
                                            const page = idx + 1;
                                            return (
                                                <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                                                    <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                                                        {page}
                                                    </button>
                                                </li>
                                            );
                                        })}

                                        <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                                                <span className="material-symbols-outlined">keyboard_arrow_right</span>
                                            </button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default ServiceRequestList;
