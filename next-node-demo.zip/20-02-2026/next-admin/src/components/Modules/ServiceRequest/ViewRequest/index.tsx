"use client";

import React, { useEffect, useState } from "react";
import { Row, Col, Card, Form, Button } from "react-bootstrap";
import { useAppDispatch } from '@/redux/hooks';
import { useRouter } from "next/navigation";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getBookingServiceList, updateBookingServiceRequest } from "@/redux/features/dataSlice";

const statusOptions = [
    { value: 0, label: "Pending" },
    { value: 1, label: "Approved" },
    { value: 2, label: "Rejected" },
    { value: 3, label: "Completed" },
];

const ViewRequest = ({ id, requestData }) => {
    const dispatch = useAppDispatch();
    const router = useRouter();

    const [loading, setLoading] = useState(false);
    const [pageLoading, setPageLoading] = useState(Boolean(id && !requestData));
    const [request, setRequest] = useState(requestData || null);
    // keep status as string so <select> matches option values exactly
    const [status, setStatus] = useState(requestData && requestData.status !== undefined && requestData.status !== null ? String(requestData.status) : "0");
    const [comment, setComment] = useState("");

    useEffect(() => {
        if (requestData) {
            setRequest(requestData);
            setStatus(requestData.status !== undefined && requestData.status !== null ? String(requestData.status) : "0");
        } else if (id) {
            fetchRequest();
        }
    }, [id, requestData]);

    const fetchRequest = async () => {
        setPageLoading(true);
        try {
            const params:any = { id };
            const resp = await dispatch(getBookingServiceList(params)).unwrap();
            // support different shapes: resp.data or resp
            const data = resp?.data ?? resp;
            if (data) {
                setRequest(data);
                setStatus(data.status !== undefined && data.status !== null ? String(data.status) : "0");
                setComment(data.comment !== undefined && data.comment !== null ? data?.comment : '')
            } else {
                toast.error("Unable to load request details");
            }
        } catch (err) {
            console.error("fetchRequest error:", err);
            toast.error(err?.message || "Failed to load request");
        } finally {
            setPageLoading(false);
        }
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        if (!request?.id && !id) {
            toast.error("Missing request id");
            return;
        }
        setLoading(true);
        try {
            const payload:any = {
                id: request?.id ?? id,
                status: Number(status), // convert back to number for API
                comment,
            };

            let resp = await dispatch(updateBookingServiceRequest(payload)).unwrap();
            if (resp?.status) {
                toast.success(resp.message || "Request updated");
                router.push("/modules/service-requests/list");
            } else {
                toast.error(resp?.message || "Update failed");
            }
        } catch (err) {
            console.error("update error:", err);
            toast.error(err?.message || "Error updating request");
        } finally {
            setLoading(false);
        }
    };

    if (pageLoading) {
        return <div className="text-center p-5">Loading...</div>;
    }

    if (!request) {
        return <div className="text-center p-5">No request found.</div>;
    }

    const { service, service_package, petdetail, address, date, startTime, endTime, option, type, createdAt, updatedAt } = request;

    const isEdit = Boolean(request?.id ?? id);
    const cancelForm = () => router.back();

        console.log(request, "request dataaa")

    return (
        <>
            <ToastContainer position="top-right" />
            <Form onSubmit={onSubmit}>
                <Row>
                    <Col lg={12}>
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <Row>
                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Request ID</Form.Label>
                                            <Form.Control readOnly value={request.id ?? ""} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Service</Form.Label>
                                            <Form.Control readOnly value={service?.name ?? ""} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Package</Form.Label>
                                            <Form.Control readOnly value={service_package?.packageName ?? ""} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Pet</Form.Label>
                                            <Form.Control
                                                readOnly
                                                value={petdetail ? `${petdetail.name} (${petdetail.type || petdetail.breed || ""})` : ""}
                                            />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Date & Time</Form.Label>
                                            <Form.Control readOnly value={`${date ?? ""} ${startTime ?? ""} - ${endTime ?? ""}`} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Customer</Form.Label>
                                            <Form.Control readOnly value={address?.fullName ?? `${address?.firstName ?? ""} ${address?.lastName ?? ""}`} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={12}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Address</Form.Label>
                                            <Form.Control readOnly as="textarea" rows={2} value={address?.address ?? ""} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Type / Option</Form.Label>
                                            <Form.Control readOnly value={`${type ?? ""} / ${option ?? ""}`} />
                                        </Form.Group>
                                    </Col>

                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Requested At</Form.Label>
                                            <Form.Control readOnly value={createdAt ? new Date(createdAt).toLocaleString() : ""} />
                                        </Form.Group>
                                    </Col>

                                    {/* Status (editable) */}
                                    <Col md={6}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Update Status</Form.Label>
                                            <Form.Select value={status} onChange={(e) => setStatus(e.target.value)}>
                                                {statusOptions.map((s) => (
                                                    <option key={s.value} value={String(s.value)}>
                                                        {s.label}
                                                    </option>
                                                ))}
                                            </Form.Select>
                                        </Form.Group>
                                    </Col>

                                    {/* Comment box (editable) */}
                                    
                                    <Col md={12}>
                                        <Form.Group className="mb-3">
                                            <Form.Label className="text-secondary">Comment</Form.Label>
                                            <Form.Control
                                                as="textarea"
                                                rows={4}
                                                placeholder="Add comment about this service request"
                                                value={comment}
                                                onChange={(e) => setComment(e.target.value)}
                                            />
                                        </Form.Group>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <div className="d-flex flex-wrap gap-3">
                                            <button
                                                className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white"
                                                type="button"
                                                onClick={cancelForm}
                                                disabled={loading}
                                            >
                                                Cancel
                                            </button>
                                            <button
                                                className="btn btn-primary py-2 px-4 fw-medium fs-16"
                                                type="submit"
                                                disabled={loading}
                                            >
                                                {loading ? 'Please wait...' : (
                                                    <>
                                                        <i className="ri-edit-line text-white fw-medium"></i>
                                                        Update Status
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Form>
        </>
    );
};

export default ViewRequest;
