"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, { useState, useEffect } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { toast, ToastContainer} from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addUpdateService, getServiceList, getPetTypeList, getServiceTypeList } from "@/redux/features/dataSlice";
import Select from 'react-select';
import { useAppDispatch } from '@/redux/hooks';

const AddService = ({ id }) => {
    const dispatch = useAppDispatch();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [pageLoading, setPageLoading] = useState(id ? true : false);
    const [profileImage, setProfileImage] = useState(null);
    const [petTypes, setPetTypes] = useState([]);
    const [serviceTypes, setServiceTypes] = useState([]);
    const [servicePetTypes, setServicePetTypes] = useState([]);
    const [servicePetTypeError, setServicePetTypeError] = useState('');

    const initialState = {
        id: null,
        name: '',
        description: '',
        accessoriesPageShown: false,
        serviceImage: '',
        service_packages: [
            { packageName: '', description: '', price: '' }
        ],
        serviceTypeId: null
    };

    const [state, setState] = useState(initialState);

    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Name is required'),
        serviceTypeId: Yup.string().required('Service type is required'),
        // servicePetTypes: Yup.array().min(1).of(Yup.string().required()).required('Pet type is required'),
        description: Yup.string().required('Description is required'),
        accessoriesPageShown: Yup.boolean(),
        service_packages: Yup.array().of(
            Yup.object().shape({
                packageName: Yup.string().required('Package name required'),
                // description: Yup.string().required('Description required'),
                price: Yup.number().typeError('Price must be a number').required('Price required').min(0, 'Price must be >= 0'),
            })
        ).min(1, 'At least one package is required'),
    });

    const formOptions:any = { 
        defaultValues: {
            name: state.name,
            serviceTypeId: state.serviceTypeId,
            description: state.description,
            accessoriesPageShown: state.accessoriesPageShown,
            service_packages: state.service_packages,
        },
        resolver: yupResolver(validationSchema) 
    };

    const { register, handleSubmit, reset, formState: { errors }, setError, clearErrors, trigger } = useForm(formOptions);

    useEffect(() => {
        if (id) {
            fetchServiceDetails();
        }
        fetchPetTypes();
        fetchServiceTypes();
    }, [id]);

    const fetchServiceDetails = async () => {
        try {
            const params:any = { id };
            const response = await dispatch(getServiceList(params)).unwrap();
            if (response?.status && response?.data) {
                const serviceData = response.data;
                setState({
                    id: serviceData.id,
                    name: serviceData.name || '',
                    serviceTypeId: serviceData.serviceTypeId || null,
                    description: serviceData.description || '',
                    accessoriesPageShown: serviceData.accessoriesPageShown || false,
                    serviceImage: serviceData.profileImage || '',
                    service_packages: serviceData.service_packages && serviceData.service_packages.length > 0
                        ? serviceData.service_packages
                        : [{ packageName: '', description: '', price: '' }],
                });
                setServicePetTypes(serviceData.servicePetTypes.map((data) => data.id));
                setIsEdit(true);
            }
        } catch (error) {
            toast.error(error?.message || 'Failed to load service details');
            console.error('Error fetching service details:', error);
        } finally {
            setPageLoading(false);
        }
    };

    const fetchPetTypes = async () => {
        try {
            const params:any = { id };
            const response = await dispatch(getPetTypeList(params)).unwrap();
            if (response?.status && response?.data) {
                setPetTypes(response.data);
            }
        } catch (error) {
            toast.error(error?.message || 'Failed to load pet types');
            console.error('Error fetching pet types:', error);
        } finally {
            setPageLoading(false);
        }
    };
    const fetchServiceTypes = async () => {
        try {
            const params:any = { id };
            const response = await dispatch(getServiceTypeList(params)).unwrap();
            if (response?.status && response?.data) {
                // console.log(response?.data);
                const serviceTypeOptions = response?.data.map((serviceType) => ({ value: serviceType.id, label: serviceType.name }));
                setServiceTypes(serviceTypeOptions);
            }
        } catch (error) {
            toast.error(error?.message || 'Failed to load service types');
            console.error('Error fetching service types:', error);
        } finally {
            setPageLoading(false);
        }
    };

    useEffect(() => {
        reset({
            name: state.name,
            serviceTypeId: state.serviceTypeId,
            description: state.description,
            accessoriesPageShown: state.accessoriesPageShown,
            serviceImage: state.serviceImage,
            service_packages: state.service_packages,
        });
    }, [state.name, state.serviceTypeId, state.description, state.accessoriesPageShown, state.service_packages, reset]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        if (type === 'checkbox') {
            setState(prev => ({ ...prev, [name]: checked }));
        } else {
            setState(prev => ({ ...prev, [name]: value }));
        }
        trigger(name);
    };

    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            setProfileImage(file);
        }
    };

    const handlePackageChange = (index, field, value) => {
        setState(prev => {
            const packages = prev.service_packages.map((p, i) => 
                i === index ? { ...p, [field]: value } : p
            );
            return { ...prev, service_packages: packages };
        });
        trigger(`service_packages.${index}.${field}`);
    };

    const addPackage = () => {
        setState(prev => ({ 
            ...prev, 
            service_packages: [...prev.service_packages, { packageName: '', description: '', price: '' }] 
        }));
    };

    const removePackage = (index) => {
        setState(prev => {
            const packages = prev.service_packages.filter((_, i) => i !== index);
            return { 
                ...prev, 
                service_packages: packages.length ? packages : [{ packageName: '', description: '', price: '' }] 
            };
        });
    };

    const cancelForm = () => {
        router.push('/modules/service/list');
    };

    const resetForm = () => {
        clearErrors();
        setServicePetTypeError('');
        setState(initialState);
        setProfileImage(null);
        reset(initialState);
    };

    const onSubmit = async () => {
        clearErrors();
        setServicePetTypeError('');
        // Validate pet types
        // console.log('servicePetTypes', servicePetTypes)
        if (!servicePetTypes || servicePetTypes.length === 0) {
            setServicePetTypeError('Pet type not selected');
            return;
        }

        const formData:any = new FormData();
        formData.append('id', state.id || '');
        formData.append('name', state.name);
        formData.append('serviceTypeId', state.serviceTypeId);
        formData.append('description', state.description);
        formData.append('accessoriesPageShown', state.accessoriesPageShown ? 'true' : 'false');
        formData.append('packages', JSON.stringify(state.service_packages));
        formData.append('servicePetTypes', JSON.stringify(servicePetTypes));

        if (profileImage) {
            formData.append('profileImage', profileImage);
        }

        setLoading(true);
        try {
            const response = await dispatch(addUpdateService(formData)).unwrap();
            console.log('Service save response:', response);
            console.log(isEdit, 'isEdit value');
            if (response?.status) {
                toast.success(response.message || (isEdit ? 'Service updated successfully' : 'Service created successfully'));
                resetForm();
                setIsEdit(false);
                router.push('/modules/service/list');
            } else {
                toast.error(response?.message || 'Failed to save service');
            }
        } catch (error) {
            toast.error(error?.message || 'Error saving service');
            console.error('Error submitting service details:', error);
        } finally {
            setLoading(false);
        }
    };

    if (pageLoading) {
        return <div className="text-center p-5">Loading...</div>;
    }

    return (
        <>
            <ToastContainer position="top-right" />
            <Form onSubmit={handleSubmit(onSubmit)} encType="multipart/form-data">
                <Row>
                    <Col lg={12}>
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <Row>
                                    <Col sm={8} lg={8}>
                                        <Form.Group className="mb-4">
                                            <label className="label text-secondary">Service Name</label>
                                            <Form.Control
                                                type="text"
                                                {...register('name')}
                                                value={state.name}
                                                onChange={handleChange}
                                                className={`form-control ${errors.name ? 'is-invalid' : (state.name ? 'is-valid' : '')}`}
                                                placeholder="Enter Service Name"
                                            />
                                            <div className="invalid-feedback d-block">{errors.name?.message?.toString()}</div>
                                        </Form.Group>
                                        <Row>
                                            <Col sm={6} lg={6}>
                                                <Form.Group className="mb-4">
                                                    <label className="label text-secondary">Service Image</label>
                                                    <Form.Control
                                                        type="file"
                                                        accept="image/*"
                                                        onChange={handleFileChange}
                                                        className={`form-control ${profileImage ? 'is-valid' : ''}`}
                                                    />
                                                    <p>{state.serviceImage}</p>
                                                </Form.Group>
                                            </Col>
                                            <Col sm={6} lg={6}>
                                                <Form.Group className="mb-4">
                                                    <label className="label text-secondary">Service Type</label>
                                                    <Select
                                                        instanceId="service_type_id"
                                                        id="serviceTypeId"
                                                        {...register('serviceTypeId')}
                                                        className={`select-input ${errors?.serviceTypeId ? 'is-invalid' : (state.serviceTypeId ? 'is-valid' : '')}`}
                                                        options={serviceTypes}
                                                        isClearable={true}
                                                        value={serviceTypes.find((serviceType) => String(serviceType.value) === String(state.serviceTypeId))}
                                                        onChange={(val) => {
                                                            setState(prev => ({ ...prev, serviceTypeId: val?.value ?? null }));
                                                        }}
                                                        placeholder="Select service type"
                                                    />
                                                    <div className="invalid-feedback">{errors.serviceTypeId?.message?.toString()}</div>
                                                </Form.Group>
                                            </Col>
                                        </Row>
                                    </Col>

                                    <Col sm={4} lg={4}>
                                        <Form.Group className="mb-4">
                                            <label className="label text-secondary">Pet Types</label>
                                            <div className="check-div">
                                                {petTypes ?
                                                    petTypes.map((petTypeData, i) => (
                                                        <Form.Check
                                                            {...register(`servicePetTypes.${i}`)}
                                                            type="checkbox"
                                                            key={`service-type-${i+1}`}
                                                            id={`servicePetType${i+1}`}
                                                            label={petTypeData.petType}
                                                            value={petTypeData.id}
                                                            onChange={(e) => {
                                                                if (e.target.checked) {
                                                                    setServicePetTypes([
                                                                        ...servicePetTypes,
                                                                        petTypeData.id
                                                                    ]);
                                                                    setServicePetTypeError('');
                                                                } else {
                                                                    setServicePetTypes(
                                                                        servicePetTypes.filter((item) => item !== petTypeData.id),
                                                                    );
                                                                }
                                                            }} 
                                                            checked={servicePetTypes.length && servicePetTypes.find((item) => item === petTypeData.id) || false}
                                                        />
                                                    ))
                                                    : ''
                                                }
                                            </div>
                                            {/* {errors.servicePetTypes && <div className="invalid-feedback d-block text-danger">{errors.servicePetTypes?.message?.toString()}</div>} */}
                                            {servicePetTypeError && <div className="invalid-feedback d-block text-danger">{servicePetTypeError}</div>}
                                        </Form.Group>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <Form.Group className="mb-4">
                                            <label className="label text-secondary">Description</label>
                                            <Form.Control
                                                as="textarea"
                                                rows={4}
                                                {...register('description')}
                                                value={state.description}
                                                onChange={handleChange}
                                                className={`form-control ${errors.description ? 'is-invalid' : (state.description ? 'is-valid' : '')}`}
                                                placeholder="Enter Description"
                                            />
                                            <div className="invalid-feedback d-block">{errors.description?.message?.toString()}</div>
                                        </Form.Group>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <Form.Group className="mb-4">
                                            <Form.Check
                                                type="checkbox"
                                                id="accessoriesPageShown"
                                                label="Show on Accessories Page"
                                                {...register('accessoriesPageShown')}
                                                checked={state.accessoriesPageShown}
                                                onChange={handleChange}
                                            />
                                        </Form.Group>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <Card className="mb-3">
                                            <Card.Body>
                                                <div className="d-flex justify-content-between align-items-center mb-3">
                                                    <h6 className="mb-0">Packages</h6>
                                                    <button type="button" className="btn btn-sm btn-outline-primary" onClick={addPackage}>
                                                        Add Package
                                                    </button>
                                                </div>

                                                {state.service_packages.map((pkg, idx) => (
                                                    <Row key={idx} className="align-items-end mb-3">
                                                        <Col sm={12} md={4}>
                                                            <Form.Group>
                                                                <label className="label text-secondary">Package Name</label>
                                                                <Form.Control
                                                                    type="text"
                                                                    {...register(`service_packages.${idx}.packageName`)}
                                                                    value={pkg.packageName}
                                                                    onChange={(e) => handlePackageChange(idx, 'packageName', e.target.value)}
                                                                    className={`form-control ${errors?.service_packages?.[idx]?.packageName ? 'is-invalid' : (pkg.packageName ? 'is-valid' : '')}`}
                                                                    placeholder="Package name"
                                                                />
                                                                {errors?.service_packages?.[idx]?.packageName && <div className="invalid-feedback d-block">{errors?.service_packages?.[idx]?.packageName?.message}</div>}
                                                            </Form.Group>
                                                        </Col>
                                                        <Col sm={12} md={3}>
                                                            <Form.Group>
                                                                <label className="label text-secondary">Description</label>
                                                                <Form.Control
                                                                    type="text"
                                                                    {...register(`service_packages.${idx}.description`)}
                                                                    value={pkg.description}
                                                                    onChange={(e) => handlePackageChange(idx, 'description', e.target.value)}
                                                                    className={`form-control ${errors?.service_packages?.[idx]?.description ? 'is-invalid' : (pkg.description ? 'is-valid' : '')}`}
                                                                    placeholder="Add description for package"
                                                                />
                                                                {errors?.service_packages?.[idx]?.description && <div className="invalid-feedback d-block">{errors?.service_packages?.[idx]?.description?.message}</div>}
                                                            </Form.Group>
                                                        </Col>
                                                        <Col sm={12} md={3}>
                                                            <Form.Group>
                                                                <label className="label text-secondary">Price</label>
                                                                <Form.Control
                                                                    type="number"
                                                                    step="0.01"
                                                                    {...register(`service_packages.${idx}.price`)}
                                                                    value={pkg.price}
                                                                    onChange={(e) => handlePackageChange(idx, 'price', e.target.value)}
                                                                    className={`form-control ${errors?.service_packages?.[idx]?.price ? 'is-invalid' : (pkg.price ? 'is-valid' : '')}`}
                                                                    placeholder="Price"
                                                                />
                                                                {errors?.service_packages?.[idx]?.price && <div className="invalid-feedback d-block">{errors?.service_packages?.[idx]?.price?.message}</div>}
                                                            </Form.Group>
                                                        </Col>
                                                        <Col sm={12} md={2} className="text-end">
                                                            <button type="button" className="btn btn-outline-danger" onClick={() => removePackage(idx)}>
                                                                Remove
                                                            </button>
                                                        </Col>
                                                    </Row>
                                                ))}
                                            </Card.Body>
                                        </Card>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <div className="d-flex flex-wrap gap-3">
                                            <button className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white" type="button" onClick={cancelForm} disabled={loading}>
                                                Cancel
                                            </button>
                                            <button className="btn btn-primary py-2 px-4 fw-medium fs-16" type="submit" disabled={loading}>
                                                {loading ? 'Please wait...' : (
                                                    <>
                                                        <i className={`${isEdit ? 'ri-edit-line' : 'ri-add-line'} text-white fw-medium`}></i>
                                                        {isEdit ? ' Update Service' : ' Add Service'}
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Form>
        </>
    );
};

export default AddService;
