"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Card, Form, Table, Button } from "react-bootstrap";
import Image from "next/image";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAppDispatch } from '@/redux/hooks';
import { confirmAlert } from "react-confirm-alert";
import Link from "next/link";
import {
  addUpdateService,
  fetchServiceList,
  getServiceList,
  deleteService,
} from "@/redux/features/dataSlice";

const Service = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(false);
  const dispatch = useAppDispatch();

  // pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  // Modal & mode state
  const [showModal, setShowModal] = useState(false);
  const [isViewMode, setIsViewMode] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // Form state
  const [form, setForm]:any = useState({
    id: "",
    name: "",
    description: "",
    profileImage: null,
    accessoriesPageShown: false,
    service_packages: [],
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const res = await dispatch(fetchServiceList()).unwrap();
      const serviceList = res?.data || [];
      setServices(serviceList);
      if (res?.status) {
        setServices(res.data || []);
      } else {
        toast.error(res.message || "Failed to fetch services");
      }
    } catch (err) {
      toast.error("Unable to fetch services");
    } finally {
      setLoading(false);
    }
  };

  // Derived pagination data
  const pageCount = Math.max(1, Math.ceil(services.length / pageSize));
  const paginatedServices = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return services.slice(start, start + pageSize);
  }, [services, currentPage]);

  useEffect(() => {
    if (currentPage > pageCount) setCurrentPage(1);
  }, [pageCount, currentPage]);

  const resetForm = () => {
    setForm({
      id: "",
      name: "",
      description: "",
      profileImage: null,
      accessoriesPageShown: false,
      service_packages: [],
    });
    setErrors({});
    setIsEditMode(false);
    setIsViewMode(false);
  };

  const openCreate = () => {
    resetForm();
    setShowModal(true);
  };

  const openView = (service) => {
    setForm({
      id: service.id,
      name: service.name || "",
      description: service.description || "",
      profileImage: null,
      accessoriesPageShown: service.accessoriesPageShown || false,
      service_packages: service.service_packages || [],
    });
    setIsViewMode(true);
    setIsEditMode(false);
    setShowModal(true);
  };

  const openEdit = (service) => {
    setForm({
      id: service.id,
      name: service.name || "",
      description: service.description || "",
      profileImage: null,
      accessoriesPageShown: service.accessoriesPageShown || false,
      service_packages: service.service_packages || [],
    });
    setIsEditMode(true);
    setIsViewMode(false);
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (name === "profileImage") {
      setForm((f) => ({ ...f, profileImage: files[0] }));
    } else if (name === "accessoriesPageShown") {
      setForm((f) => ({ ...f, accessoriesPageShown: checked }));
    } else {
      setForm((f) => ({ ...f, [name]: value }));
    }
  };

  const validate = () => {
    const err:any = {};
    if (!form.name || !form.name.trim()) err.name = "Service name is required";
    if (!form.description || !form.description.trim()) err.description = "Description is required";
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const submitForm = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      setLoading(true);
      const formData:any = new FormData();
      if (form.id) formData.append("id", form.id);
      formData.append("name", form.name);
      formData.append("description", form.description);
      formData.append("accessoriesPageShown", form.accessoriesPageShown);
      if (form.profileImage) formData.append("profileImage", form.profileImage);

      const res = await dispatch(addUpdateService(formData)).unwrap();
      if (res?.status) {
        toast.success(res.message || "Service saved.");
        setShowModal(false);
        resetForm();
        fetchServices();
      } else {
        toast.error(res.message || "Failed to save service");
      }
    } catch (err) {
      toast.error("Unexpected error saving service");
    } finally {
      setLoading(false);
    }
  };

  const handleClickDeleteService = async (serviceId) => {
    try {
      const params:any = { id: serviceId };
      const res = await dispatch(deleteService(params)).unwrap();
      if (res?.status) {
        toast.success(res.message || "Service deleted");
        await fetchServices();
      } else {
        toast.error(res.message || "Failed to delete");
      }
    } catch (err) {
      toast.error(err?.message || "Unexpected error deleting service");
    }
  };

  const handleDelete = (id) => {
    if (!id) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h1>Are you sure?</h1>
            <p>You want to delete this service?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                handleClickDeleteService(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      }
    });
  };

  return (
    <>
      <ToastContainer position="top-right" />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
            <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
              <div>

              <Form className="position-relative table-src-form">
                <Form.Control 
                type="text" 
                placeholder="Search here" 
                onChange={(e) => {
                      const q = e.target.value;
                      const el:any = e.target;
                      if (el._searchTimer) clearTimeout(el._searchTimer);
                      el._searchTimer = setTimeout(async () => {
                        try {
                          setLoading(true);
                          const formData:any = new FormData();
                          formData.append("searchText", q);
                          const res = await dispatch(fetchServiceList(formData)).unwrap();
                          if (res?.status) setServices(res.data || []); else toast.error(res.message || "Search failed");
                        } catch (err) {
                          toast.error("Search failed");
                        } finally {
                          setLoading(false);
                        }
                      }, 400);
                  }}
                />
                  <span className="material-symbols-outlined position-absolute top-50 start-0 translate-middle-y">
                    search
                  </span>
              </Form>
              </div>

              <div className="text-end">
                <Link
                    href="/modules/service/add"
                    className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                >
                    <span className="py-sm-1 d-block">
                        <i className="ri-add-line d-none d-sm-inline-block"></i>{" "}
                        <span>Add New Service</span>
                    </span>
                </Link>
              </div>
            </div>

          <div className="default-table-area">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th>Sl No.</th>
                    <th>Service Name</th>
                    <th>Description</th>
                    <th>Show Accessories</th>
                    <th>Packages</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {paginatedServices?.length ? (
                    paginatedServices.map((service) => (
                      <tr key={service.id}>
                        <td className="text-body">{service.id}</td>
                        <td>
                          <div className="d-flex align-items-center">
                            {service.profileImage && (
                              <Image
                                src={service.profileImage}
                                className="wh-34 rounded-circle"
                                alt="user"
                                width={34}
                                height={34}
                              />
                            )}
                            <h6 className="mb-0 fs-14 fw-medium ms-2">{service.name}</h6>
                          </div>
                        </td>
                        {/* <td>
                          <div className="d-flex align-items-center">
                            <div className="flex-grow-1 ms-2 position-relative top-1">
                              <h6 className="mb-0 fs-14 fw-medium">{service.name}</h6>
                            </div>
                          </div>
                        </td> */}
                        <td className="text-body">{service.description}</td>
                        <td>
                          <span
                            className={`badge bg-opacity-10 p-2 fs-12 fw-normal ${service.accessoriesPageShown ? "bg-success text-success" : "bg-danger text-danger"}`}
                          >
                            {service.accessoriesPageShown ? "Yes" : "No"}
                          </span>
                        </td>
                        <td>
                          <span className="badge bg-info text-white">
                            {service.service_packages?.length || 0}
                          </span>
                        </td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            {/* <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => openView(service)}
                              title="View"
                            >
                              <span className="material-symbols-outlined fs-16 text-primary">visibility</span>
                            </button> */}
                            <Link
                                href={`/modules/service/edit/${service.id}`}
                                className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                title="Edit Role"
                            >
                                <i className="material-symbols-outlined fs-16 text-body">
                                    edit
                                </i>
                            </Link>
                            {/* <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => openEdit(service)}
                              title="Edit"
                            >
                              <span className="material-symbols-outlined fs-16 text-body">edit</span>
                            </button> */}
                            <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => handleDelete(service.id)}
                              title="Delete"
                            >
                              <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="text-center py-4">
                        {loading ? "Loading..." : "No services found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>

            <div className="p-0">
              <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                <span className="fs-12 fw-medium">
                  Showing {services.length === 0 ? 0 : Math.min(services.length, (currentPage - 1) * pageSize + 1)}-
                  {Math.min(services.length, currentPage * pageSize)} of {services.length} Results
                </span>

                <nav aria-label="Page navigation example">
                  <ul className="pagination mb-0 justify-content-center">
                    <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                      <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                        <span className="material-symbols-outlined">keyboard_arrow_left</span>
                      </button>
                    </li>

                    {Array.from({ length: pageCount }).map((_, idx) => {
                      const page = idx + 1;
                      return (
                        <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                          <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                            {page}
                          </button>
                        </li>
                      );
                    })}

                    <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                      <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                        <span className="material-symbols-outlined">keyboard_arrow_right</span>
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default Service;