"use client";

import React, { useEffect, useState } from "react";
import { Accordion } from "react-bootstrap";
import { usePathname } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
// import { signOut } from "next-auth/react";
import { can } from "../../utils/helper";
import { useSelector } from "react-redux";
import { jwtDecode } from 'jwt-decode';
import { useAppDispatch } from '@/redux/hooks';
import {
  fetchMenuPermissions
} from "@/redux/features/dataSlice";

const LeftSidebar = ({ toggleActive }) => {
  const pathname = usePathname();
  const dispatch = useAppDispatch();
  const [menuGroups, setMenuGroups] = useState([]);
  const accessToken = useSelector((state:any) => state.auth?.session?.accessToken); 
  const userInfo:any = accessToken ? jwtDecode(accessToken) : null;
  const roleSlug = userInfo?.roleSlug; 
  const loadMenus = async (roleSlug) => {
    try {
      const menuData = await dispatch(fetchMenuPermissions(roleSlug)).unwrap();
      setMenuGroups(menuData?.data);
      // console.log('menuGroups', menuData?.data)
    } catch (err) {
      console.error(err?.message || "Failed to load data");
    }
  };
  // const can = (accessPermissions) => {
  //   // console.log('userInfo', userInfo)
  //   const permissions = userInfo ? userInfo.permissions : [];  
  //   return (userInfo?.roleSlug == "super-admin" || (permissions.length && permissions.filter(x => accessPermissions.includes(x)).length));
  // }
  const populateMenus = (menus) => {
    return (
      menus.map((menu, i) => (
        (menu.menus && menu.menus.length && can(menu.menus.map((menuItem) => `view-${menuItem.slug}`), accessToken)) ? 
          <Accordion.Item eventKey={menu.id} key={`menu-${i}`} className="group-menu-item">
            <Accordion.Header>
              <i className="material-symbols-outlined">{menu.icon ? menu.icon : 'dashboard'}</i>
              <span className="title">{menu.name}</span>
            </Accordion.Header>
            <Accordion.Body>
              <ul className="sub-menu">
                {menu.menus.map((subMenu, j) => (
                  can([`view-${subMenu.slug}`], accessToken) ?
                    <li className="menu-item" key={`sub-menu-${j}`}>
                      <Link
                        href={subMenu.link ? subMenu.link : "#"}
                        className={`menu-link ${
                          `${pathname}/` == subMenu.link ? "active" : ""
                        }`}
                      >
                        {subMenu.name}
                      </Link>
                      {
                        (subMenu.menus && subMenu.menus.length) ? populateMenus(subMenu.menus) : ''
                      }
                    </li>
                  : ''
                ))}
              </ul>
            </Accordion.Body>
          </Accordion.Item>
        :
          can([`view-${menu.slug}`], accessToken) ?
            <div className="menu-item group-menu-item" key={i}>
                <Link
                  href={menu.link ? menu.link : '#'}
                  className={`menu-link ${
                    `${pathname}/` == menu.link ? "active" : ""
                  }`}
                >
                  <i className="material-symbols-outlined">{menu.icon ? menu.icon : 'dashboard'}</i>
                  <span className="title">{menu.name}</span>
                </Link>
            </div>
          : ''
      ))
    )
  };
  const hideBlankGroupMenus = () => {
    const groupItems = document.getElementsByClassName('group-item');
    Array.from(groupItems).forEach((groupItem:any) => {
      const childElements = groupItem.getElementsByClassName('group-menu-item');
      if(!childElements.length){
        groupItem.style.display = 'none'; 
      }
    });
  };
  useEffect(() => {
    if(roleSlug){
      loadMenus(roleSlug);
    }
    setTimeout(() => {
        hideBlankGroupMenus();
    }, 1000)    
  }, [roleSlug]);

  return (
    <>
      <div className="left-sidebar-menu sidebar-area">
        <div className="logo position-relative text-center">
          <Link
            href="/dashboard/"
            className="d-block text-decoration-none position-relative"
          >
            <Image
              src="/images/logo/logo.png"
              alt="logo-icon"
              width={88}
              height={50}
            />
          </Link>
          <button
            className="sidebar-burger-menu bg-transparent p-0 border-0 opacity-0 z-n1 position-absolute top-50 end-0 translate-middle-y"
            onClick={toggleActive}
          >
            <i className="material-symbols-outlined fs-24">close</i>
          </button>
        </div>
        <div className="sidebar-inner">
          <div className="sidebar-menu">
            {menuGroups.length ? 
              <Accordion defaultActiveKey="0" flush>
                {menuGroups.map((menuGroup, index) => (
                  <div key={`menu-item-${index}`} className="group-item">
                    <div className="sub-title menu-title small text-uppercase" key={index}>
                      <span className="menu-title-text">{menuGroup.name}</span>
                    </div>
                    {(menuGroup.menus && menuGroup.menus.length) ? populateMenus(menuGroup.menus) : ''}
                  </div>
                ))}
              </Accordion>
            : ''}
          </div>
        </div>
      </div>
    </>
  );
};

export default LeftSidebar;
