"use client";

import { Dropdown } from "react-bootstrap";
import Image from "next/image"; 
import { signOut } from "next-auth/react";
import { useSelector } from 'react-redux';
import { jwtDecode } from 'jwt-decode';

const Profile = () => {
  const sessionVal = useSelector((state:any) => state.auth?.session);
  const userInfo:any = sessionVal?.accessToken ? jwtDecode(sessionVal?.accessToken) : {};
  // console.log(userInfo);
  return (
    <>
      <Dropdown className="admin-profile">
        <Dropdown.Toggle className="d-xxl-flex align-items-center bg-transparent border-0 text-start p-0 cursor">
          <div className="flex-shrink-0">
            <Image
              className="rounded-circle wh-40 administrator"
              src="/images/administrator.jpg"
              alt="admin"
              width={40}
              height={40}
            />
          </div>

          <div className="flex-grow-1 ms-2">
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-none d-xxl-block">
                <div className="d-flex align-content-center">
                  <h3>{userInfo?.name}</h3>
                </div>
              </div>
            </div>
          </div>
        </Dropdown.Toggle>

        <Dropdown.Menu className="border-0 bg-white dropdown-menu-end">
          <div className="d-flex align-items-center info">
            <div className="flex-shrink-0">
              <Image
                className="rounded-circle wh-30 administrator"
                src="/images/administrator.jpg"
                alt="admin"
                width={30}
                height={30}
              />
            </div>
            <div className="flex-grow-1 ms-2">
              <h3 className="fw-medium">{userInfo?.name}</h3>
              <span className="fs-12">{userInfo?.roleName}</span>
            </div>
          </div>

          <ul className="admin-link ps-0 mb-0 list-unstyled">
            {/* <li>
              <a
                className="dropdown-item d-flex align-items-center text-body"
                href="/my-profile/"
              >
                <i className="material-symbols-outlined">account_circle</i>
                <span className="ms-2">My Profile</span>
              </a>
            </li> */}

            <li>
              <a
                className="dropdown-item d-flex align-items-center text-body"
                href="/ecommerce/orders/"
              >
                <i className="material-symbols-outlined">shopping_cart</i>
                <span className="ms-2">Orders</span>
              </a>
            </li>

            <li>
              <a
                className="dropdown-item d-flex align-items-center text-body"
                href="/ecommerce/wishlists/"
              >
                <i className="material-symbols-outlined">
                  format_list_bulleted
                </i>
                <span className="ms-2">Wishlists</span>
              </a>
            </li>

          </ul>

          <ul className="admin-link ps-0 mb-0 list-unstyled">
            <li>
              <a
                className="dropdown-item d-flex align-items-center text-body"
                href="/settings/account-settings/"
              >
                <i className="material-symbols-outlined">settings</i>
                <span className="ms-2">Settings</span>
              </a>
            </li>

            <li>
              <a
                className="dropdown-item d-flex align-items-center text-body"
                href="#"
                onClick={() => signOut({ callbackUrl: "/sign-in" })}
              >
                <i className="material-symbols-outlined">logout</i>
                <span className="ms-2">Logout</span>
              </a>
            </li>
          </ul>
        </Dropdown.Menu>
      </Dropdown>
    </>
  );
};

export default Profile;
