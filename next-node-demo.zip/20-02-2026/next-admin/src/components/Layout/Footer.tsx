"use client";

const Footer = () => {
  return (
    <>
      <div className="flex-grow-1"></div>

      <footer className="footer-area bg-white text-center rounded-top-7">
        <footer className="footer-area bg-white text-center rounded-top-7">
        <p className="fs-14">
          All rights reserved &copy; <a href="#" target="_blank" className="text-decoration-none text-primary" >Eclick</a>
        </p>
      </footer>
      </footer>
    </>
  );
};

export default Footer;
