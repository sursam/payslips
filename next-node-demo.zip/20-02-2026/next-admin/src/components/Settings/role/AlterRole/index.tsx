"use client";

import React, { useEffect, useState } from "react";
import { Row, Col, Card, Form } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { useAppDispatch } from '@/redux/hooks';
import { saveRoleData, deatilsRoleData } from "@/redux/features/dataSlice";

interface RoleFileds {
    id: number;
    roleName: string;
}
const AlterRole = ({ slug }) => {
    const dispatch = useAppDispatch();
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    const validationSchema = Yup.object().shape({
        roleName: Yup.string().required("Role name is required"),
    });
    var roleValues:RoleFileds = { id: null, roleName: "" };
    const {
        register,
        handleSubmit,
        reset,
        setValue,
        setError,
        clearErrors,
        formState: { errors },
        trigger,
    } = useForm({
        resolver: yupResolver(validationSchema),
        defaultValues: roleValues,
    });

    useEffect(() => {
        if (!slug) return;
        const getRoleDetails = async () => {
            setLoading(true);
            try {
                const roleResponse = await dispatch(deatilsRoleData(slug)).unwrap();
                if (roleResponse?.status) {
                    const roleData = roleResponse.data || {};
                    roleValues = {
                        id: roleData.id ?? null,
                        roleName: roleData.roleName ?? "",
                    };
                    reset(roleValues);
                }
            } catch (err) {
                console.error("Error fetching role details:", err);
            } finally {
                setLoading(false);
            }
        };
        getRoleDetails();
    }, [slug, dispatch, reset]);

    const onFieldChange = async (e) => {
        const { name, value } = e.target;
        setValue(name, value);
        await trigger(name);
    };

    const onSubmit = async (formData) => {
        clearErrors();
        const normalized = (formData.roleName || "").trim().toLowerCase();
        if (!slug && normalized.includes("customer")) {
            setError("roleName", {
                type: "manual",
                message: "customer role does not allowed.",
            });
            return;
        }

        setLoading(true);
        try {
            const response = await dispatch(saveRoleData(formData)).unwrap();
            if (response?.status) {
                toast.success(response.message);
                reset(roleValues);
                router.push("/settings/role/list");
            } else {
                setError("roleName", { type: "manual", message: response?.message || "Save failed" });
            }
        } catch (error) {
            setError("roleName", { type: "manual", message: error?.message || "Save failed" });
            console.error("Error submitting role details:", error);
        } finally {
            setLoading(false);
        }
    };

    const cancelForm = () => {
        router.push("/settings/role/list");
    };

    return (
        <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
                <Col lg={12}>
                    <Card className="bg-white border-0 rounded-3 mb-4">
                        <Card.Body className="p-4">
                            <Row>
                                <Col sm={12} lg={12}>
                                    <Form.Group className="mb-4">
                                        <label className="label text-secondary">Role Name</label>
                                        <Form.Control
                                            type="text"
                                            {...register("roleName")}
                                            onChange={onFieldChange}
                                            className={`form-control ${errors.roleName ? "is-invalid" : ""}`}
                                            placeholder="Enter Role Name"
                                        />
                                        <div className="invalid-feedback">{errors.roleName?.message?.toString()}</div>
                                    </Form.Group>
                                </Col>

                                <Col sm={12} lg={12}>
                                    <div className="d-flex flex-wrap gap-3">
                                        <button
                                            className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white"
                                            type="button"
                                            onClick={cancelForm}
                                            disabled={loading}
                                        >
                                            Cancel
                                        </button>

                                        <button
                                            className="btn btn-primary py-2 px-4 fw-medium fs-16"
                                            type="submit"
                                            disabled={loading}
                                        >
                                            {loading ? (
                                                "Please wait..."
                                            ) : (
                                                <>
                                                    <i className="ri-add-line text-white fw-medium"></i>{" "}
                                                    {slug ? "Update " : "Add "} Role
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Form>
    );
};

export default AlterRole;
