"use client";

import { Card, Table } from "react-bootstrap";
import Link from "next/link";
import SearchForm from "./SearchForm";
import { useState, useEffect } from "react";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { ToastContainer, toast } from "react-toastify";
import { fetchRoleData, updateRoleStatus, deleteRoleData } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';
import Switch from "react-switch";

const RoleListTable = () => {
    const [roleList, setRoleList] = useState([]);
    const dispatch = useAppDispatch();

    useEffect(() => {
        fetchRoleList();
    }, []);

    const fetchRoleList = async (searchText = '') => {
        try {
            const params:any = {searchText};
            const roleData = await dispatch(fetchRoleData(params)).unwrap(); 
            if(roleData.status){
                // console.log('roleData', roleData.data);
                setRoleList(roleData.data);
            }                
        } catch (error) {
            console.error('Error fetching role details:', error);
        }
    };
    const handleClickDeleteRole = async (roleSlug) => {
        // console.log(roleSlug)
        try {
            const params:any = {roleSlug};
            const response = await dispatch(deleteRoleData(params)).unwrap(); 
            if(response.status){
                toast.success("Role deleted successfully")
                const updatedRoleList = roleList.filter((item) => item.roleSlug !== roleSlug);
                setRoleList(updatedRoleList);
            }
        } catch (error) {
            console.error('Error deleting role data:', error);
        }
    };

    const handleClickSaveRole = async (roleData) => {
        // console.log(roleData)
        try {
            const response = await dispatch(updateRoleStatus(roleData)).unwrap(); 
            if(response.status){
                toast.success("Role status changed successfully");
                fetchRoleList();
            }
        } catch (error) {
            console.error('Error changing role status:', error);
        }
    };

    const handleStatusChange = (status, roleSlug) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                <div className='custom-ui'>
                    <h1>Are you sure?</h1>
                    <p>You want to change the status?</p>
                    <button onClick={onClose}>No</button>
                    <button
                    onClick={() => {
                        handleClickSaveRole({status, roleSlug});
                        onClose();
                    }}
                    >
                    Yes, Change it!
                    </button>
                </div>
                );
            }
        });
    }

    const handleDelete = (e, roleSlug) => {
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                <div className='custom-ui'>
                    <h1>Are you sure?</h1>
                    <p>You want to delete this role?</p>
                    <button onClick={onClose}>No</button>
                    <button
                    onClick={() => {
                        handleClickDeleteRole(roleSlug);
                        onClose();
                    }}
                    >
                    Yes, Delete it!
                    </button>
                </div>
                );
            }
        });
    };

    return (
        <>
            <ToastContainer position="top-right" autoClose={3000} />
            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
                        <SearchForm fetchRoleList={fetchRoleList} />
                        <Link
                            href="/settings/role/add"
                            className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                        >
                            <span className="py-sm-1 d-block">
                                <i className="ri-add-line d-none d-sm-inline-block"></i>{" "}
                                <span>Add Role</span>
                            </span>
                        </Link>
                    </div>

                    <div className="default-table-area ">
                        <div className="table-responsive">
                            <Table className="table align-middle">
                                <thead>
                                    <tr>
                                        <th scope="col">Sl No.</th>
                                        <th scope="col">Role Name</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {roleList.length ? (
                                        roleList.map((value, i) => (
                                            <tr key={value.id}>
                                                <td>{i + 1}</td>
                                                <td>{value.roleName}</td>
                                                <td>
                                                    <Switch 
                                                        onChange={e => handleStatusChange(e, value?.roleSlug)} 
                                                        checked={value?.status} 
                                                        uncheckedIcon={<span></span>}
                                                        checkedIcon={<span></span>}
                                                    />
                                                </td>
                                                <td>
                                                    <div className="d-flex align-items-center gap-1">
                                                        <Link
                                                            href={`/settings/role/edit/${value.roleSlug}`}
                                                            className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                                            title="Edit Role"
                                                        >
                                                            <i className="material-symbols-outlined fs-16 text-body">
                                                                edit
                                                            </i>
                                                        </Link>

                                                        <Link
                                                            href={`/settings/role/permissions/${value.roleSlug}`}
                                                            className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1"
                                                            title="Edit Permissions"
                                                        >
                                                            <i className="material-symbols-outlined fs-16 text-body">
                                                                key
                                                            </i>
                                                        </Link>

                                                        <button
                                                            className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                                                            onClick={(e) => handleDelete(e, value.roleSlug)}
                                                            title="Delete Role"
                                                        >
                                                            <span className="material-symbols-outlined fs-16 text-danger">
                                                                delete
                                                            </span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr key="0">
                                            <td colSpan={4} className="text-center">
                                                No roles are available
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default RoleListTable;
