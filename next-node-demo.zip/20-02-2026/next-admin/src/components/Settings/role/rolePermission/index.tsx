"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import React, {useState, useEffect} from 'react';
// import apiConnection from "../../../utils/apiConnection";
import { useRouter } from 'next/navigation';
import { ToastContainer, toast } from "react-toastify";

import { deatilsRoleData, fetchMenuPermissions, fetchRolePermissions, updateRolePermissions } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';

const RolePermissions = ({slug}) => {
  const router = useRouter();
  const [roleDetails, setRoleDetails]:any = useState();
  const [roleWisePermissions, setRoleWisePermissions] = useState([]);
  const dispatch = useAppDispatch();
  const [loading, setLoading] = useState(false);
  const [menuPermissions, setMenuPermissions] = useState([]);

  const cancelForm = () => { 
      router.push('/settings/role/list')
  }

  const handlePermissions = async () => {
    setLoading(true);
    const uniqueRoleWisePermissions = roleWisePermissions.filter((currentObject, index, self) => {
      return index === self.findIndex((otherObject) => {
          return otherObject.roleId === currentObject.roleId && otherObject.permissionId === currentObject.permissionId;
      });
    });
    const payload:any = {
        "roleId": roleDetails?.id,
        "rolePermissions": uniqueRoleWisePermissions
    }
    const response = await dispatch(updateRolePermissions(payload)).unwrap(); 
    try{
        if(response.status){
          toast.success(response.message);
        }else{
          toast.error(response.message);
        }
        setLoading(false);
    } catch (error) {
        toast.error(`Error submitting role permissions: ${error}`);
        setLoading(false);
    }
  }
  const getRoleDetails = async ()=>{
    setLoading(true);
    try {
        const roleResponse = await dispatch(deatilsRoleData(slug)).unwrap(); 
        // console.log('Role details:', roleResponse);
        if(roleResponse.status){
          setRoleDetails(roleResponse?.data);
          const rolePermissionsResponse = await dispatch(fetchRolePermissions(roleResponse?.data?.id)).unwrap(); 
          // console.log('Role Permissions:', rolePermissionsResponse);
          if(rolePermissionsResponse.status){
              setRoleWisePermissions(rolePermissionsResponse?.data);
          }
        }   
        setLoading(false);             
    } catch (error) {
        console.error('Error fetching role details:', error);
        setLoading(false);
    }
  }
  const getMenuPermissions = async ()=>{
    setLoading(true);
    try {
        const response = await dispatch(fetchMenuPermissions(slug)).unwrap(); 
        if(response.status){
            setMenuPermissions(response?.data);
        }   
        setLoading(false);             
    } catch (error) {
        console.error('Error fetching menu permissions:', error);
        setLoading(false);
    }
  }
  const handleCheckAll = (e) => { 
    let allValues = e.target.value.split(','); 
    let allNumValues = allValues.map(function(item) {
      return Number(item); 
    }); 
    let allSelectedValues = allNumValues.map(function(item) {
      return {
        roleId: roleDetails?.id,
        permissionId: item
      }; 
    });
    setRoleWisePermissions(
      roleWisePermissions.filter(rp => !allNumValues.includes(rp.permissionId)),
    )
    if (e.target.checked) {
      setRoleWisePermissions([
        ...roleWisePermissions,
        ...allSelectedValues,
      ]);
    }
  };
  const loadMenuPermissions = (menus)=>{
    return (
      <Row className="mt-2">
        {menus.map((menu, index) => (
          (menu.menus && menu.menus.length) ? 
            <div key={`row-${index}`}>
              <strong>{`${menu.name} =>`}</strong>
              {loadMenuPermissions(menu.menus)} 
            </div>            
            : 
            <Col key={index} xxl={3} lg={4} md={4} sm={12}>
              <div className="mb-3">
                <div className="d-flex justify-content-between align-items-center">
                  <h5>{menu.name}</h5>
                  <label htmlFor={menu.slug}>
                    <input
                      id={menu.slug}
                      type="checkbox"
                      value={menu.permissions && menu.permissions.length ? menu.permissions.map(obj => obj.id) : []}
                      onChange={handleCheckAll}
                      checked={ (menu.permissions && menu.permissions.length ? menu.permissions.map(obj => obj.id) : []).every(element => { return roleWisePermissions.find((rolePermission) => rolePermission.permissionId === element) }) }
                    /> <span className="mx-1">All</span> 
                  </label>
                </div>               
                  
                {menu.permissions ?
                  <ul className="list-group mt-2">
                    {menu.permissions.map((permission, i) => (
                      <li className="list-group-item" key={i}>
                          <label htmlFor={permission.slug}>
                            <input type="checkbox" id={permission.slug} 
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setRoleWisePermissions([
                                    ...roleWisePermissions,
                                    {
                                      roleId: roleDetails?.id,
                                      permissionId: permission.id
                                    },
                                  ]);
                                } else {
                                  setRoleWisePermissions(
                                    roleWisePermissions.filter((rolePermission) => rolePermission.permissionId !== permission.id),
                                  );
                                }
                              }} 
                              checked={roleWisePermissions.length && roleWisePermissions.find((rolePermission) => rolePermission.permissionId === permission.id) || false}
                              value={permission.id} 
                              /> <span className="mx-1">{permission.name}</span>
                          </label>                            
                      </li>
                    ))}
                  </ul>
                : ''}
              </div>
            </Col>          
        ))}
      </Row>
    );
  }
  useEffect(() => {
    if(slug){
      getRoleDetails()
    }    
    getMenuPermissions();
  }, 
  [])

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Form>
        <Row>
          <Col lg={12}>            
            <div className="text-end"><h5>Role Name: <strong>{roleDetails?.roleName}</strong></h5></div>
            <div className="mt-2">
              {(menuPermissions && menuPermissions.length) ? 
                <>
                  {menuPermissions.map((group, i) => (
                    <Card className="bg-white border-0 rounded-3 mb-4" key={i}>
                      <Card.Body className="p-4">
                        <h3>{group.name}</h3>
                        <Row className="mt-2">
                          {group.menus && group.menus.length ? 
                            <>
                              {loadMenuPermissions(group.menus)}
                            </>
                          : ''}
                        </Row>
                      </Card.Body>
                    </Card>
                  ))}
                  
                </>
              : <Col sm={12} lg={12}>Menus are not available.</Col>}
            </div>
            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <Row>
                  <Col sm={12} lg={12}>
                    <div className="d-flex flex-wrap gap-3 mt-3">
                      <button className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white" type="button" onClick={cancelForm} disabled={loading}>
                        Cancel
                      </button>
                      <button className="btn btn-primary py-2 px-4 fw-medium fs-16" type="button" onClick={handlePermissions} disabled={loading}>
                        {loading ? 'Please wait...' :  'SUBMIT'}
                      </button>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default RolePermissions;
