"use client";
import React from 'react';
import { Row, Col, Card, Table } from "react-bootstrap";
import SearchForm from "./SearchForm";
import Link from "next/link";
import { ToastContainer } from "react-toastify";

const ModuleList = () => {
    const modules = 
    [
    {
        "id": 16,
        "uuid": "c7315597-29a7-47c2-a80c-0e90bf5fdb8a",
        "parentModuleId": null,
        "moduleName": "Job Category",
        "moduleSlug": "job-category",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T06:56:58.000Z",
        "updatedAt": "2025-02-05T06:56:58.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 61,
                "name": "View Job Category",
                "slug": "view-job-category"
            },
            {
                "id": 62,
                "name": "Add Job Category",
                "slug": "add-job-category"
            },
            {
                "id": 63,
                "name": "Edit Job Category",
                "slug": "edit-job-category"
            },
            {
                "id": 64,
                "name": "Delete Job Category",
                "slug": "delete-job-category"
            }
        ]
    },
    {
        "id": 24,
        "uuid": "9009b151-2e31-4996-b5e3-46136d0cc30f",
        "parentModuleId": null,
        "moduleName": "Graphic Designer",
        "moduleSlug": "graphic-designer",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-07-01T04:47:38.000Z",
        "updatedAt": "2025-07-01T04:47:38.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 93,
                "name": "View Graphic Designer",
                "slug": "view-graphic-designer"
            },
            {
                "id": 94,
                "name": "Add Graphic Designer",
                "slug": "add-graphic-designer"
            },
            {
                "id": 95,
                "name": "Edit Graphic Designer",
                "slug": "edit-graphic-designer"
            },
            {
                "id": 96,
                "name": "Delete Graphic Designer",
                "slug": "delete-graphic-designer"
            }
        ]
    },
    {
        "id": 23,
        "uuid": "f07b2473-f9cd-46ce-b6b2-dc12374f01ec",
        "parentModuleId": null,
        "moduleName": "Newsletter Subscription ",
        "moduleSlug": "newsletter-subscription",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-04-07T07:13:55.000Z",
        "updatedAt": "2025-04-07T07:13:55.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 89,
                "name": "View Newsletter Subscription ",
                "slug": "view-newsletter-subscription"
            },
            {
                "id": 90,
                "name": "Add Newsletter Subscription ",
                "slug": "add-newsletter-subscription"
            },
            {
                "id": 91,
                "name": "Edit Newsletter Subscription ",
                "slug": "edit-newsletter-subscription"
            },
            {
                "id": 92,
                "name": "Delete Newsletter Subscription ",
                "slug": "delete-newsletter-subscription"
            }
        ]
    },
    {
        "id": 22,
        "uuid": "7799c0ec-1f23-4f51-874e-184e21943bff",
        "parentModuleId": null,
        "moduleName": "Enquiry",
        "moduleSlug": "enquiry",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-06T07:01:10.000Z",
        "updatedAt": "2025-02-06T07:01:10.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 85,
                "name": "View Enquiry",
                "slug": "view-enquiry"
            },
            {
                "id": 86,
                "name": "Add Enquiry",
                "slug": "add-enquiry"
            },
            {
                "id": 87,
                "name": "Edit Enquiry",
                "slug": "edit-enquiry"
            },
            {
                "id": 88,
                "name": "Delete Enquiry",
                "slug": "delete-enquiry"
            }
        ]
    },
    {
        "id": 21,
        "uuid": "ca51e6e1-1f8e-4c49-8743-6484ee70731e",
        "parentModuleId": null,
        "moduleName": "Permission",
        "moduleSlug": "permission",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T07:20:44.000Z",
        "updatedAt": "2025-02-05T07:20:44.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 81,
                "name": "View Permission",
                "slug": "view-permission"
            },
            {
                "id": 82,
                "name": "Add Permission",
                "slug": "add-permission"
            },
            {
                "id": 83,
                "name": "Edit Permission",
                "slug": "edit-permission"
            },
            {
                "id": 84,
                "name": "Delete Permission",
                "slug": "delete-permission"
            }
        ]
    },
    {
        "id": 20,
        "uuid": "f34d1999-8781-4a47-9c23-b384a38dd5a2",
        "parentModuleId": null,
        "moduleName": "Role",
        "moduleSlug": "role",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T07:20:25.000Z",
        "updatedAt": "2025-02-05T07:20:25.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 77,
                "name": "View Role",
                "slug": "view-role"
            },
            {
                "id": 78,
                "name": "Add Role",
                "slug": "add-role"
            },
            {
                "id": 79,
                "name": "Edit Role",
                "slug": "edit-role"
            },
            {
                "id": 80,
                "name": "Delete Role",
                "slug": "delete-role"
            }
        ]
    },
    {
        "id": 19,
        "uuid": "131298c9-f3c8-4e78-b449-81ef6986e674",
        "parentModuleId": null,
        "moduleName": "Block",
        "moduleSlug": "block",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T07:05:31.000Z",
        "updatedAt": "2025-02-05T07:05:31.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 73,
                "name": "View Block",
                "slug": "view-block"
            },
            {
                "id": 74,
                "name": "Add Block",
                "slug": "add-block"
            },
            {
                "id": 75,
                "name": "Edit Block",
                "slug": "edit-block"
            },
            {
                "id": 76,
                "name": "Delete Block",
                "slug": "delete-block"
            }
        ]
    },
    {
        "id": 18,
        "uuid": "03df3a33-e761-4f43-b6bb-4bcf875979fd",
        "parentModuleId": null,
        "moduleName": "Page",
        "moduleSlug": "page",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T07:05:20.000Z",
        "updatedAt": "2025-02-05T07:05:20.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 69,
                "name": "View Page",
                "slug": "view-page"
            },
            {
                "id": 70,
                "name": "Add Page",
                "slug": "add-page"
            },
            {
                "id": 71,
                "name": "Edit Page",
                "slug": "edit-page"
            },
            {
                "id": 72,
                "name": "Delete Page",
                "slug": "delete-page"
            }
        ]
    },
    {
        "id": 17,
        "uuid": "04ece603-856f-47e0-9104-6c49f1a2d1de",
        "parentModuleId": null,
        "moduleName": "Job",
        "moduleSlug": "job",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T06:57:06.000Z",
        "updatedAt": "2025-02-05T06:57:06.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 65,
                "name": "View Job",
                "slug": "view-job"
            },
            {
                "id": 66,
                "name": "Add Job",
                "slug": "add-job"
            },
            {
                "id": 67,
                "name": "Edit Job",
                "slug": "edit-job"
            },
            {
                "id": 68,
                "name": "Delete Job",
                "slug": "delete-job"
            }
        ]
    },
    {
        "id": 5,
        "uuid": "70550ce7-1165-4836-9c88-12f4d743da10",
        "parentModuleId": null,
        "moduleName": "Pricing Plan",
        "moduleSlug": "pricing-plan",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-01-27T10:45:33.000Z",
        "updatedAt": "2025-01-27T10:47:03.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 17,
                "name": "View Pricing Plan",
                "slug": "view-pricing-plan"
            },
            {
                "id": 18,
                "name": "Add Pricing Plan",
                "slug": "add-pricing-plan"
            },
            {
                "id": 19,
                "name": "Edit Pricing Plan",
                "slug": "edit-pricing-plan"
            },
            {
                "id": 20,
                "name": "Delete Pricing Plan",
                "slug": "delete-pricing-plan"
            }
        ]
    },
    {
        "id": 15,
        "uuid": "b8b5277d-7c0c-49e1-b2fb-cee764cacfae",
        "parentModuleId": null,
        "moduleName": "FAQ Category",
        "moduleSlug": "faq-category",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T06:53:27.000Z",
        "updatedAt": "2025-02-05T06:53:27.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 57,
                "name": "View FAQ Category",
                "slug": "view-faq-category"
            },
            {
                "id": 58,
                "name": "Add FAQ Category",
                "slug": "add-faq-category"
            },
            {
                "id": 59,
                "name": "Edit FAQ Category",
                "slug": "edit-faq-category"
            },
            {
                "id": 60,
                "name": "Delete FAQ Category",
                "slug": "delete-faq-category"
            }
        ]
    },
    {
        "id": 14,
        "uuid": "ebdccf41-74b2-429f-8d8a-47e8dd83d6fc",
        "parentModuleId": null,
        "moduleName": "Client User",
        "moduleSlug": "client-user",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T06:29:59.000Z",
        "updatedAt": "2025-02-05T06:29:59.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 53,
                "name": "View Client User",
                "slug": "view-client-user"
            },
            {
                "id": 54,
                "name": "Add Client User",
                "slug": "add-client-user"
            },
            {
                "id": 55,
                "name": "Edit Client User",
                "slug": "edit-client-user"
            },
            {
                "id": 56,
                "name": "Delete Client User",
                "slug": "delete-client-user"
            }
        ]
    },
    {
        "id": 13,
        "uuid": "32676628-d36f-480f-b816-c3ddf1020127",
        "parentModuleId": null,
        "moduleName": "Admin User",
        "moduleSlug": "admin-user",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-02-05T06:29:50.000Z",
        "updatedAt": "2025-02-05T06:29:50.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 49,
                "name": "View Admin User",
                "slug": "view-admin-user"
            },
            {
                "id": 50,
                "name": "Add Admin User",
                "slug": "add-admin-user"
            },
            {
                "id": 51,
                "name": "Edit Admin User",
                "slug": "edit-admin-user"
            },
            {
                "id": 52,
                "name": "Delete Admin User",
                "slug": "delete-admin-user"
            }
        ]
    },
    {
        "id": 12,
        "uuid": "8bf502aa-2354-4b3b-bb54-48de2531721e",
        "parentModuleId": null,
        "moduleName": "Nav Menu",
        "moduleSlug": "nav-menu",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-01-27T10:48:52.000Z",
        "updatedAt": "2025-01-27T10:48:52.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 45,
                "name": "View Nav Menu",
                "slug": "view-nav-menu"
            },
            {
                "id": 46,
                "name": "Add Nav Menu",
                "slug": "add-nav-menu"
            },
            {
                "id": 47,
                "name": "Edit Nav Menu",
                "slug": "edit-nav-menu"
            },
            {
                "id": 48,
                "name": "Delete Nav Menu",
                "slug": "delete-nav-menu"
            }
        ]
    },
    {
        "id": 9,
        "uuid": "791989d8-55b9-4438-b884-ce55f99c33c8",
        "parentModuleId": null,
        "moduleName": "Our Team",
        "moduleSlug": "our-team",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-01-27T10:48:10.000Z",
        "updatedAt": "2025-01-27T10:48:10.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 33,
                "name": "View Our Team",
                "slug": "view-our-team"
            },
            {
                "id": 34,
                "name": "Add Our Team",
                "slug": "add-our-team"
            },
            {
                "id": 35,
                "name": "Edit Our Team",
                "slug": "edit-our-team"
            },
            {
                "id": 36,
                "name": "Delete Our Team",
                "slug": "delete-our-team"
            }
        ]
    },
    {
        "id": 8,
        "uuid": "f616dada-0f0b-4fa1-9840-131db79db848",
        "parentModuleId": null,
        "moduleName": "Testimonial",
        "moduleSlug": "testimonial",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-01-27T10:48:00.000Z",
        "updatedAt": "2025-01-27T10:48:00.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 29,
                "name": "View Testimonial",
                "slug": "view-testimonial"
            },
            {
                "id": 30,
                "name": "Add Testimonial",
                "slug": "add-testimonial"
            },
            {
                "id": 31,
                "name": "Edit Testimonial",
                "slug": "edit-testimonial"
            },
            {
                "id": 32,
                "name": "Delete Testimonial",
                "slug": "delete-testimonial"
            }
        ]
    },
    {
        "id": 6,
        "uuid": "8f7217df-7662-475f-9340-412da84c41dd",
        "parentModuleId": null,
        "moduleName": "FAQ",
        "moduleSlug": "faq",
        "moduleIcon": null,
        "status": 1,
        "order": 0,
        "createdAt": "2025-01-27T10:47:42.000Z",
        "updatedAt": "2025-01-27T10:47:42.000Z",
        "deletedAt": null,
        "permissions": [
            {
                "id": 21,
                "name": "View FAQ",
                "slug": "view-faq"
            },
            {
                "id": 22,
                "name": "Add FAQ",
                "slug": "add-faq"
            },
            {
                "id": 23,
                "name": "Edit FAQ",
                "slug": "edit-faq"
            },
            {
                "id": 24,
                "name": "Delete FAQ",
                "slug": "delete-faq"
            }
        ]
    }
]

    return (
        <>
            <ToastContainer position="top-right" autoClose={3000} />
            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
                        <SearchForm />
                        <Link href="/settings/role/add" className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg">
                            <span className="py-sm-1 d-block">
                                <i className="ri-add-line d-none d-sm-inline-block"></i>
                                <span>Add Module</span>
                            </span>
                        </Link>
                    </div>
                    <div className="default-table-area">
                        <div className="table-responsive">
                            <Table className="table align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Module Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {modules.length ? (
                                        modules.map((module, index) => (
                                            <tr key={index}>
                                                <td>{module.id}</td>
                                                <td>{module.moduleName}</td>
                                            
                                                <td>
                                                    <span className={`badge ${module.status ? 'bg-success' : 'bg-danger'}`}>
                                                        {module.status ? 'Active' : 'Inactive'}
                                                    </span>
                                                </td>
                                                
                                                <td>
                                                    <div className="d-flex align-items-center gap-1">
                                                        <Link href={`/settings/role/edit/${module.uuid}`} className="ps-0 border-0 bg-transparent lh-1 position-relative top-2 pe-1" title="Edit Module">
                                                            <i className="material-symbols-outlined fs-16 text-body">edit</i>
                                                        </Link>
                                                        <button className="ps-0 border-0 bg-transparent lh-1 position-relative top-2" title="Delete Module">
                                                            <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan={4} className="text-center">No modules are available</td>
                                        </tr>
                                    )}
                                </tbody>
                            </Table>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default ModuleList;
