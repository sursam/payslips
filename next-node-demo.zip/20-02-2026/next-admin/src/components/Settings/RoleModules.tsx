"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const RoleModules = () => {
  const pathname = usePathname();

  return (
    <>
      <ul className="ps-0 mb-4 list-unstyled d-flex flex-wrap gap-2 gap-lg-3">
        <li>
          <Link
            href="/settings/role/list/"
            className={`btn border border-primary text-primary py-2 px-3 fw-semibold ${
              pathname === "/settings/role/list/"
                ? "btn-primary text-white"
                : "bg-transparent"
            }`}
          >
            Roles and Permissions
          </Link>
        </li>

        <li>
          <Link
            href="/settings/modules/"
            className={`btn border border-primary text-primary py-2 px-3 fw-semibold ${
              pathname === "/settings/modules/"
                ? "btn-primary text-white"
                : "bg-transparent"
            }`}
          >
            Modules
          </Link>
        </li>
      </ul>
    </>
  );
};

export default RoleModules;
