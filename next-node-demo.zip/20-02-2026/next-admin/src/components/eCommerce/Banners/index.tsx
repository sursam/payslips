"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Card, Table, Button, Spinner } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import SearchForm from "./SearchForm";
import { useAppDispatch } from '@/redux/hooks';

import {
    fetchBannerList,
    deleteBanner,
} from "@/redux/features/dataSlice";

const BannerList = () => {
    const dispatch = useAppDispatch();
    const [banners, setBanners] = useState([]);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const pageSize = 10;

    useEffect(() => {
        fetchBanners();
    }, []);

    const fetchBanners = async () => {
        try {
            setLoading(true);
            const res = await dispatch(fetchBannerList()).unwrap();
            const data = res?.data || [];
            if (res?.status) {
                setBanners(data || []);
            } else {
                toast.error(res.message || "Failed to fetch banners");
            }
        } catch (err) {
            toast.error("Unable to fetch banners");
        } finally {
            setLoading(false);
        }
    };

    const loadBannerList = async (searchText:string = '') => {
        try {
            const params:any = { searchText };
            const bannerData = await dispatch(fetchBannerList(params)).unwrap();
            const list = bannerData?.data || bannerData || [];
            setBanners(list);
            setCurrentPage(1);
        } catch (err) {
            toast.error(err?.message || "Failed to load banner data");
        }
    };

    const handleClickDeleteBanner = async (id) => {
        try {
            const params:any = { id };
            const res = await dispatch(deleteBanner(params)).unwrap();
            if (res?.status) {
                toast.success("Banner deleted");
                fetchBanners();
            } else {
                toast.error(res?.message || "Failed to delete banner");
            }
        } catch (err) {
            toast.error(err?.message || "Failed to delete banner");
        }
    };

    const handleDelete = (id) => {
        if (!id) return;
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this banner?</p>
                        <button onClick={onClose}>No</button>
                        <button
                            onClick={() => {
                                handleClickDeleteBanner(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    };

    const pageCount = Math.max(1, Math.ceil(banners.length / pageSize));
    const paginatedBanners = useMemo(() => {
        const start = (currentPage - 1) * pageSize;
        return banners.slice(start, start + pageSize);
    }, [banners, currentPage]);

    useEffect(() => {
        if (currentPage > pageCount) setCurrentPage(1);
    }, [pageCount, currentPage]);

    return (
        <>
            <ToastContainer position="top-right" />

            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-lg-4 mb-3">
                        <SearchForm loadBannerList={loadBannerList} />

                        <Link href="/ecommerce/banners/create"
                            className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                        >
                            <span className="py-sm-1 d-block">
                                <i className="ri-add-line d-none d-sm-inline-block fs-18"></i>
                                <span>Add New Banner</span>
                            </span>
                        </Link>
                    </div>

                    <div className="default-table-area banner-list">
                        <div className="table-responsive">
                            <Table className="align-middle">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">URL</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {loading && (
                                        <tr>
                                            <td colSpan={7} className="text-center py-4">
                                                <Spinner animation="border" size="sm" /> Loading...
                                            </td>
                                        </tr>
                                    )}

                                    {!loading && paginatedBanners.length === 0 && (
                                        <tr>
                                            <td colSpan={7} className="text-center py-4">
                                                No banners found.
                                            </td>
                                        </tr>
                                    )}

                                    {!loading && paginatedBanners.map((banner, i) => (
                                        <tr key={banner.id ?? i}>
                                            <td>{banner.id}</td>
                                            <td>
                                                {banner.bannerImage ? (
                                                    <Image
                                                        src={banner.bannerImage}
                                                        className="wh-40 rounded-3"
                                                        alt={banner.title || "banner"}
                                                        width={40}
                                                        height={40}
                                                    />
                                                ) : (
                                                    <div className="wh-40 rounded-3 bg-light" style={{ width: 40, height: 40 }} />
                                                )}
                                            </td>
                                            <td>{banner.title}</td>
                                            <td>{banner.description}</td>
                                            <td>{banner.URL}</td>
                                            <td>
                                                <span
                                                    className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${banner.status == 1 ? 'text-success bg-success' : 'text-danger bg-danger'}`}
                                                >
                                                    {banner.status == 1 ? 'active' : 'inactive'}
                                                </span>
                                            </td>
                                            <td>
                                                <div className="d-flex align-items-center gap-1">
                                                    <Link href={`/ecommerce/banners/edit/${banner.id}`} className="ps-0 border-0 bg-transparent lh-1 position-relative top-2">
                                                        <span className="material-symbols-outlined fs-16 text-body">edit</span>
                                                    </Link>

                                                    <Button
                                                        variant="link"
                                                        className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                                                        onClick={() => handleDelete(banner.id)}
                                                    >
                                                        <span className="material-symbols-outlined text-danger fs-16">delete</span>
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </div>

                        <div className="p-0">
                            <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                                <span className="fs-12 fw-medium">
                                    Showing {banners.length === 0 ? 0 : Math.min(banners.length, (currentPage - 1) * pageSize + 1)}-
                                    {Math.min(banners.length, currentPage * pageSize)} of {banners.length} Results
                                </span>

                                <nav aria-label="Page navigation">
                                    <ul className="pagination mb-0 justify-content-center">
                                        <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                                                <span className="material-symbols-outlined">keyboard_arrow_left</span>
                                            </button>
                                        </li>

                                        {Array.from({ length: pageCount }).map((_, idx) => {
                                            const page = idx + 1;
                                            return (
                                                <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                                                    <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                                                        {page}
                                                    </button>
                                                </li>
                                            );
                                        })}

                                        <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                                                <span className="material-symbols-outlined">keyboard_arrow_right</span>
                                            </button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default BannerList;
