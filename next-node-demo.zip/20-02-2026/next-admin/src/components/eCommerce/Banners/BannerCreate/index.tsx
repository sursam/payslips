"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import Image from "next/image";
import Link from "next/link";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addUpdateBanner, getBanner } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';

const BannerCreate = ({ id }) => {
    const dispatch = useAppDispatch();
    const router = useRouter();
    
    const [loading, setLoading] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [errors, setErrors]:any = useState({});
    const [formData, setFormData]:any = useState({
        title: "",
        description: "",
        URL: "",
        status: 1,
        image: null,
        imagePreview: null,
    });

    useEffect(() => {
        if (id) {
            setIsEdit(true);
            fetchBanner(id);
        }
    }, [id]);

    const fetchBanner = async (id) => {
        setLoading(true);
        try {
            if (!id) return;
            const params:any = { id };
            const response = await dispatch(getBanner(params)).unwrap();
            setFormData({
                title: response.title || "",
                description: response.description || "",
                URL: response.URL || "",
                status: parseInt(response.status) || 1,
                image: null,
                imagePreview: response.bannerImage || null,
            });
        } catch (error) {
            console.log(error);
            toast.error("Failed to fetch banner details");
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: name === 'status' ? parseInt(value) : value,
        }));
        // Clear error for this field when user starts typing
        if (errors[name]) {
            setErrors((prev) => ({
                ...prev,
                [name]: "",
            }));
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFormData((prev) => ({
                ...prev,
                image: file,
                imagePreview: URL.createObjectURL(file),
            }));
            if (errors.image) {
                setErrors((prev) => ({
                    ...prev,
                    image: "",
                }));
            }
        }
    };

    const validateForm = () => {
        const newErrors:any = {};

        if (!formData.title.trim()) {
            newErrors.title = "Banner title is required";
        }

        if (!formData.URL.trim()) {
            newErrors.URL = "URL is required";
        } 
        // else if (!/^(https?:\/\/)/.test(formData.URL)) {
        //     newErrors.URL = "Please enter a valid URL (starting with http:// or https://)";
        // }

        if (!isEdit && !formData.image) {
            newErrors.image = "Please upload a banner image";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            // toast.error("Please fix all errors before submitting");
            return;
        }

        setLoading(true);
        try {
            const payload:any = new FormData();
            payload.append("title", formData.title);
            payload.append("description", formData.description);
            payload.append("URL", formData.URL);
            payload.append("status", formData.status);
            
            if (formData.image) {
                payload.append("bannerImage", formData.image);
            }
            
            if (isEdit) {
                payload.append("id", id);
            }

            await dispatch(addUpdateBanner(payload)).unwrap();
            toast.success(isEdit ? "Banner updated successfully" : "Banner created successfully");
            router.push("/ecommerce/banners");
        } catch (error) {
            toast.error(error?.message || "Failed to save banner");
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = () => {
        router.push("/ecommerce/banners");
    };

    return (
        <>
            <ToastContainer />
            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="container-fluid">
                        <div className="d-flex justify-content-between align-items-center mb-4">
                            <h4 className="fw-bold mb-0">
                                {isEdit ? "Edit Banner" : "Create New Banner"}
                            </h4>
                            <Link
                                href="/ecommerce/banners"
                                className="btn btn-outline-secondary py-1 px-4 fs-14 fw-medium"
                            >
                                Back to List
                            </Link>
                        </div>

                        {loading && !isEdit ? (
                            <div className="text-center py-5">
                                <div className="spinner-border" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : (
                            <Form onSubmit={handleSubmit} className="max-width-800">
                                <Form.Group className="mb-4">
                                    <Form.Label>Banner Title</Form.Label>
                                    <Form.Control
                                        type="text"
                                        name="title"
                                        value={formData.title}
                                        onChange={handleInputChange}
                                        placeholder="Enter banner title"
                                        isInvalid={!!errors.title}
                                    />
                                    {errors.title && (
                                        <div className="text-danger mt-2 fs-14">
                                            {errors.title}
                                        </div>
                                    )}
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>Description</Form.Label>
                                    <Form.Control
                                        as="textarea"
                                        name="description"
                                        value={formData.description}
                                        onChange={handleInputChange}
                                        rows={3}
                                        placeholder="Enter banner description"
                                    />
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>URL</Form.Label>
                                    <Form.Control
                                        type="text"
                                        name="URL"
                                        value={formData.URL}
                                        onChange={handleInputChange}
                                        placeholder="Enter banner URL"
                                        isInvalid={!!errors.URL}
                                    />
                                    {errors.URL && (
                                        <div className="text-danger mt-2 fs-14">
                                            {errors.URL}
                                        </div>
                                    )}
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>Status</Form.Label>
                                    <Form.Select
                                        name="status"
                                        value={formData.status}
                                        onChange={handleInputChange}
                                    >
                                        <option value={1}>Active</option>
                                        <option value={0}>Inactive</option>
                                    </Form.Select>
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>Banner Image</Form.Label>
                                    <Form.Control
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageChange}
                                        isInvalid={!!errors.image}
                                    />
                                    {errors.image && (
                                        <div className="text-danger mt-2 fs-14">
                                            {errors.image}
                                        </div>
                                    )}
                                    {formData.imagePreview && (
                                        <div className="mt-3">
                                            <Image
                                                src={formData.imagePreview}
                                                alt="Banner Preview"
                                                width={200}
                                                height={100}
                                                className="rounded-3"
                                            />
                                        </div>
                                    )}
                                </Form.Group>

                                <div className="d-flex flex-wrap gap-3 mb-4">
                                    <button
                                        type="button"
                                        className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white"
                                        onClick={handleCancel}
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary py-2 px-4 fw-medium fs-16"
                                        disabled={loading}
                                    >
                                        <i className="ri-add-line text-white fw-medium"></i>{" "}
                                        {loading ? "Saving..." : isEdit ? "Update Banner" : "Create Banner"}
                                    </button>
                                </div>
                            </Form>
                        )}
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default BannerCreate;