"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import Image from "next/image";
import Link from "next/link";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addUpdateOffer, getOffers } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';

const AddOffer = ({ uuid }) => {
    const dispatch = useAppDispatch();
    const router = useRouter();

    const [loading, setLoading] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [errors, setErrors]:any = useState({});
    const [formData, setFormData]:any = useState({
        status: 1,
        publish_date: "",
        expiry_date: "",
        discount_type: "Percentage",
        discount_value: "",
        title: "",
        code: "",
        limits: "",
        min_order_value: "",
        description: "",
        banner_image: null,
        imagePreview: null,
    });

  const [activeCondition, setActiveCondition] = useState("Category Wise");
  const handleConditionChange = (e) => {
    setActiveCondition(e.target.value);
  };

    useEffect(() => {
        if (uuid) {
            setIsEdit(true);
            fetchOffer(uuid);
        }
    }, [uuid]);

    const fetchOffer = async (uuid) => {
        setLoading(true);
        try {
            if (!uuid) return;
            const params:any = { uuid };
            const response = await dispatch(getOffers(params)).unwrap();
            console.log("Fetched offer details:", response);
            setFormData({
                status: response.status,
                publish_date: response.publish_date || "",
                expiry_date: response.expiry_date || "",
                discount_type: response.discount_type || "Percentage",
                discount_value: response.discount_value || "",
                title: response.title || "",
                code: response.code || "",
                limits: response.limits || "",
                min_order_value: response.min_order_value || "",
                description: response.description || "",
                banner_image: response.banner_image || null,
                imagePreview: response.banner_image || null,
            });
        } catch (error) {
            console.log(error);
            toast.error("Failed to fetch offer details");
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
        if (errors[name]) {
            setErrors((prev) => ({
                ...prev,
                [name]: "",
            }));
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFormData((prev) => ({
                ...prev,
                banner_image: file,
                imagePreview: URL.createObjectURL(file),
            }));
            if (errors.banner_image) {
                setErrors((prev) => ({
                    ...prev,
                    banner_image: "",
                }));
            }
        }
    };

    const validateForm = () => {
        const newErrors:any = {};

        if (!formData.title.trim()) {
            newErrors.title = "Offer title is required";
        }

        if (!formData.code.trim()) {
            newErrors.code = "Offer code is required";
        }

        if (!formData.discount_value.trim()) {
            newErrors.discount_value = "Discount value is required";
        }

        if (!formData.publish_date) {
            newErrors.publish_date = "Publish date is required";
        }

        // if (!formData.expiry_date) {
        //     newErrors.expiry_date = "Expiry date is required";
        // }

        // if (!isEdit && !formData.banner_image) {
        //     newErrors.banner_image = "Please upload a banner image";
        // }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setLoading(true);
        try {
            const payload:any = new FormData();
            payload.append("status", formData.status);
            payload.append("publish_date", formData.publish_date);
            payload.append("expiry_date", formData.expiry_date ?? null);
            payload.append("discount_type", formData.discount_type);
            payload.append("discount_value", formData.discount_value);
            payload.append("title", formData.title);
            payload.append("code", formData.code);
            payload.append("limits", formData.limits);
            payload.append("min_order_value", formData.min_order_value);
            payload.append("description", formData.description);
            payload.append("type", "offer");
            
            if (formData.banner_image) {
                payload.append("banner_image", formData.banner_image);
            }
            
            if (isEdit) {
                payload.append("uuid", uuid);
            }

            await dispatch(addUpdateOffer(payload)).unwrap();
            toast.success(isEdit ? "Offer updated successfully" : "Offer created successfully");
            router.push("/ecommerce/offers");
        } catch (error) {
            toast.error(error?.message || "Failed to save offer");
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = () => {
        router.push("/ecommerce/offers");
    };


    return (
        <>
            <ToastContainer />
            <Form onSubmit={handleSubmit}>
                <Row>
                    <Col lg={5} xxl={4}>
                        {/* Offer Status */}
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <h3 className="mb-3 mb-lg-4">Offer Status</h3>  
                                <Row>
                                    {["Active", "In Active"].map((s) => (
                                        <Col sm={6} className="mb-3 mb-sm-0" key={s}>
                                            <label htmlFor={`status-${s == 'Active' ? 1 : 0}`}>
                                                <input
                                                    type="radio"
                                                    className="form-check-input mx-2"
                                                    name="status"
                                                    id={`status-${s == 'Active' ? 1 : 0}`}
                                                    value={s == 'Active' ? 1 : 0}
                                                    checked={formData.status == (s == 'Active' ? 1 : 0)}
                                                    onChange={handleInputChange}
                                                />
                                                <span className="radio-content">
                                                    <span className="fw-medium text-secondary">{s}</span>
                                                </span>
                                            </label>
                                        </Col>
                                    ))} 
                                </Row> 
                            </Card.Body>
                        </Card>

                        {/* Offer Expiry */}
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <h3 className="mb-3 mb-lg-4">Offer Expiry</h3>  
                                <Row>
                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label">Publish Date</Form.Label>
                                            <Form.Control 
                                                type="date" 
                                                name="publish_date"
                                                value={formData.publish_date ? formData.publish_date.split('T')[0] : ""}
                                                onChange={handleInputChange}
                                                isInvalid={!!errors.publish_date}
                                            />
                                            {errors.publish_date && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.publish_date}
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>
                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label">Expiry Date</Form.Label>
                                            <Form.Control 
                                                type="date" 
                                                name="expiry_date"
                                                value={formData.expiry_date ? formData.expiry_date.split('T')[0] : ""}
                                                onChange={handleInputChange}
                                                isInvalid={!!errors.expiry_date}
                                            />
                                            {errors.expiry_date && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.expiry_date}
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>
                                </Row> 
                            </Card.Body>
                        </Card>

                        {/* Offer Types */}
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <h3 className="mb-3 mb-lg-4">Offer Types</h3>
                                <Row>
                                    {["Percentage", "Fixed Value"].map((t) => (
                                        <Col sm={6} className="mb-3 mb-sm-0" key={t}>
                                            <Form.Group className="mb-4">
                                                <label htmlFor={`type-${t}`}>
                                                    <input
                                                        type="radio"
                                                        className="form-check-input mx-2"
                                                        name="discount_type"
                                                        id={`type-${t}`}
                                                        value={t}
                                                        checked={formData.discount_type === t}
                                                        onChange={handleInputChange}
                                                    />
                                                    <span className="radio-content">
                                                        <span className="fw-medium text-secondary">{t}</span>
                                                    </span>
                                                </label>
                                            </Form.Group>
                                        </Col>
                                    ))}

                                    <Col sm={6} lg={12}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Discount Value</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="discount_value"
                                                className="h-55"
                                                placeholder="Enter Discount Value"
                                                value={formData.discount_value}
                                                onChange={handleInputChange}
                                                isInvalid={!!errors.discount_value}
                                            />
                                            {errors.discount_value && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.discount_value}
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col lg={7} xxl={8}>
                        {/* Offer Information */}
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                                <h3 className="mb-3 mb-lg-4">Offer Information</h3>
    
                                <Row>
                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Title</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="title"
                                                className="h-55"
                                                placeholder="Enter Offer Title"
                                                value={formData.title}
                                                onChange={handleInputChange}
                                                isInvalid={!!errors.title}
                                            />
                                            {errors.title && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.title}
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>
                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Code</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="code"
                                                className="h-55"
                                                placeholder="Enter Offer Code"
                                                value={formData.code}
                                                onChange={handleInputChange}
                                                isInvalid={!!errors.code}
                                            />
                                            {errors.code && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.code}
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>

                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Limits</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="limits"
                                                className="h-55"
                                                placeholder="Enter Offer Limits"
                                                value={formData.limits}
                                                onChange={handleInputChange}
                                            />
                                        </Form.Group>
                                    </Col>

                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Minimum Order Value</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="min_order_value"
                                                className="h-55"
                                                placeholder="Enter Minimum Order Value"
                                                value={formData.min_order_value}
                                                onChange={handleInputChange}
                                            />
                                        </Form.Group>
                                    </Col>

                                    <Col sm={6} lg={6}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Banner Image</Form.Label>
                                            <Form.Control
                                                type="file"
                                                accept="image/*"
                                                onChange={handleImageChange}
                                                isInvalid={!!errors.banner_image}
                                            />
                                            {errors.banner_image && (
                                                <div className="text-danger mt-2 fs-14">
                                                    {errors.banner_image}
                                                </div>
                                            )}
                                            {formData.imagePreview && (
                                                <div className="mt-3">
                                                    <Image
                                                        src={formData.imagePreview}
                                                        alt="Banner Preview"
                                                        width={200}
                                                        height={100}
                                                        className="rounded-3"
                                                        unoptimized={formData.imagePreview.startsWith('http')}
                                                    />
                                                </div>
                                            )}
                                        </Form.Group>
                                    </Col>

                                    <Col sm={12} lg={12}>
                                        <Form.Group className="mb-4">
                                            <Form.Label className="label text-secondary">Description</Form.Label>
                                            <Form.Control
                                                as="textarea"
                                                name="description"
                                                rows={3}
                                                placeholder="Enter offer description"
                                                value={formData.description}
                                                onChange={handleInputChange}
                                            />
                                        </Form.Group>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>

                        {/* Offer Conditions - Static */}
                        <Card className="bg-white border-0 rounded-3 mb-4">
                            <Card.Body className="p-4">
                            <h3 className="mb-3 mb-lg-4">Coupon Conditions</h3>
            
                            <Row>
                                {["Category Wise", "Product Wise", "User Wise"].map((c, i) => (
                                <Col sm={4} className="mb-3 mb-sm-0" key={c}>
                                    <Form.Group className="mb-4">
                                    <label htmlFor={`condition${i}`}>
                                        <input
                                        type="radio"
                                        className="form-check-input mx-2"
                                        name="couponCondition"
                                        id={`condition${i}`}
                                        value={c}
                                        checked={activeCondition === c}
                                        onChange={handleConditionChange}
                                        />
                                        <span className="radio-content">
                                        <span className="fw-medium text-secondary">{c}</span>
                                        </span>
                                    </label>
                                    </Form.Group>
                                </Col>
                                ))}
            
                                {activeCondition == "Category Wise" ? 
                                <Col sm={12} lg={12}>
                                    <Form.Group className="mb-4">
                                    <Form.Label className="label text-secondary">Category</Form.Label>
                                    <Form.Select
                                        className="form-control h-55"
                                        aria-label="Default select example"
                                    >
                                        <option defaultValue="0">Select</option>
                                        <option defaultValue="1">Food</option>
                                        <option defaultValue="2">Toys</option>
                                        <option defaultValue="3">Accesories</option>
                                        <option defaultValue="4">Health Care</option>
                                        <option defaultValue="5">Grooming</option>
                                    </Form.Select>
                                    </Form.Group>
                                </Col>
                                : ""
                                }
            
                                {activeCondition == "Product Wise" ? 
                                <Col sm={12} lg={12}>
                                    <Form.Group className="mb-4">
                                    <Form.Label className="label text-secondary">Product</Form.Label>
                                    <Form.Select
                                        className="form-control h-55"
                                        aria-label="Default select example"
                                    >
                                        <option defaultValue="0">Select</option>
                                        <option defaultValue="1">Pedigree Adult Wet Dog Food, Chicken & Liver Chunks in Gravy, 70 g</option>
                                        <option defaultValue="2">Petstages Dog Chew Toy ORKA Bone - Mini</option>
                                        <option defaultValue="3">PetWale Raincoats with Reflective Strips for Dogs - Navy Blue</option>
                                        <option defaultValue="4">Himalaya Himpyrin Anti-inflammatory Liquid for Dogs and Cats (30ml)</option>
                                        <option defaultValue="5">Biogroom Waterless Bath Puppy/Dog Shampoo - 473 ml</option>
                                        <option defaultValue="6">FOFOS Diapers for Male Dogs</option>
                                    </Form.Select>
                                    </Form.Group>
                                </Col>
                                : ""
                                }
            
                                {activeCondition == "User Wise" ? 
                                <Col sm={12} lg={12}>
                                    <Form.Group className="mb-4">
                                    <Form.Label className="label text-secondary">User</Form.Label>
                                    <Form.Select
                                        className="form-control h-55"
                                        aria-label="Default select example"
                                    >
                                        <option defaultValue="0">Select</option>
                                        <option defaultValue="1">Oliver Khan</option>
                                        <option defaultValue="2">Carolyn Barnes</option>
                                        <option defaultValue="3">Donna Miller</option>
                                        <option defaultValue="4">Barbara Cross</option>
                                        <option defaultValue="5">Rebecca Block</option>
                                        <option defaultValue="6">Ramiro McCarty</option>
                                    </Form.Select>
                                    </Form.Group>
                                </Col>
                                : ""
                                }
            
                            </Row>
            
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>

                <div className="d-flex flex-wrap gap-3 mb-4">
                    <button
                        type="button"
                        className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white"
                        onClick={handleCancel}
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit" 
                        className="btn btn-primary py-2 px-4 fw-medium fs-16"
                        disabled={loading}
                    >
                        <i className="ri-add-line text-white fw-medium"></i>{" "}
                        {loading ? "Saving..." : isEdit ? "Update Offer" : "Add Offer"}
                    </button>
                </div>
            </Form>
        </>
    );
};

export default AddOffer;
