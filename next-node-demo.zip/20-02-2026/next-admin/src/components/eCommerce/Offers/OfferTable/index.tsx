"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Card, Table, Button, Spinner, Form } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import SearchForm from "./SearchForm";
import { useAppDispatch } from '@/redux/hooks';

import {
    fetchOffers,
    deleteOffers
} from "@/redux/features/dataSlice";

const OfferTable = () => {
    const dispatch = useAppDispatch();
    const [offers, setOffers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const pageSize = 10;

    useEffect(() => {
        fetchOffersData();
    }, []);

    const fetchOffersData = async () => {
        try {
            setLoading(true);
            const params:any = { type: "offer" };
            const res = await dispatch(fetchOffers(params)).unwrap();
            const data = res?.data || [];
            if (res?.status) {
                setOffers(data || []);
            } else {
                toast.error(res.message || "Failed to fetch offers");
            }
        } catch (err) {
            toast.error("Unable to fetch offers");
        } finally {
            setLoading(false);
        }
    };

    const loadOfferList = async (searchText = '') => {
        try {
            const params:any = { searchText , type: "offer" };
            const offerData = await dispatch(fetchOffers(params)).unwrap();
            console.log("offerData:", offerData);
            const list = offerData?.data || offerData || [];
            setOffers(list);
            setCurrentPage(1);
        } catch (err) {
            toast.error(err?.message || "Failed to load offer data");
        }
    };

    const handleClickDeleteOffer = async (uuid) => {
        try {
            const params:any = { uuid };
            const res = await dispatch(deleteOffers(params)).unwrap();
            if (res?.status) {
                toast.success("Offer deleted");
                fetchOffersData();
            } else {
                toast.error(res?.message || "Failed to delete offer");
            }
        } catch (err) {
            toast.error(err?.message || "Failed to delete offer");
        }
    };

    const handleDelete = (uuid) => {
        if (!uuid) return;
        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this offer?</p>
                        <button onClick={onClose}>No</button>
                        <button
                            onClick={() => {
                                handleClickDeleteOffer(uuid);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    };

    const pageCount = Math.max(1, Math.ceil(offers.length / pageSize));
    const paginatedOffers = useMemo(() => {
        const start = (currentPage - 1) * pageSize;
        return offers.slice(start, start + pageSize);
    }, [offers, currentPage]);

    useEffect(() => {
        if (currentPage > pageCount) setCurrentPage(1);
    }, [pageCount, currentPage]);

    return (
        <>
            <ToastContainer position="top-right" />

            <Card className="bg-white border-0 rounded-3 mb-4">
                <Card.Body className="p-4">
                    <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-lg-4 mb-3">
                        <SearchForm loadOfferList={loadOfferList} />

                        <Link
                            href="/ecommerce/offers/add"
                            className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                        >
                            <span className="py-sm-1 d-block">
                                <i className="ri-add-line d-none d-sm-inline-block fs-18"></i>
                                <span>Add New Offer</span>
                            </span>
                        </Link>
                    </div>

                    <div className="default-table-area ec-recent-orders">
                        <div className="table-responsive">
                            <Table className="align-middle">
                                <thead>
                                    <tr>
                                        <th scope="col">
                                            Sl No.
                                        </th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Code</th>
                                        <th scope="col">Discount</th>
                                        <th scope="col">Start Date</th>
                                        <th scope="col">End Date</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {loading && (
                                        <tr>
                                            <td colSpan={8} className="text-center py-4">
                                                <Spinner animation="border" size="sm" /> Loading...
                                            </td>
                                        </tr>
                                    )}

                                    {!loading && paginatedOffers.length === 0 && (
                                        <tr>
                                            <td colSpan={8} className="text-center py-4">
                                                No offers found.
                                            </td>
                                        </tr>
                                    )}

                                    {!loading && paginatedOffers.map((offer, i) => (
                                        <tr key={offer.uuid ?? i}>
                                            <td>
                                                {offer.id}
                                            </td>

                                            <td>{offer.title}</td>

                                            <td>{offer.code}</td>

                                            <td>
                                                {offer.discount_type === 'Fixed Value' 
                                                    ? `$${offer.discount_value}` 
                                                    : `${offer.discount_value}%`
                                                }
                                            </td>

                                            <td>{new Date(offer.publish_date).toLocaleDateString()}</td>

                                            <td>{offer.expiry_date ? new Date(offer.expiry_date).toLocaleDateString() : 'N/A'}</td>

                                            <td>
                                                <span
                                                    className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${
                                                        offer.status == 1 
                                                            ? 'text-success bg-success' 
                                                            : 'text-danger bg-danger'
                                                    }`}
                                                >
                                                    {offer.status == 1 ? 'active' : 'inactive'}
                                                </span>
                                            </td>

                                            <td>
                                                <div className="d-flex align-items-center gap-1">
                                                    <Link 
                                                        href={`/ecommerce/offers/edit/${offer.uuid}`} 
                                                        className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                                                    >
                                                        <span className="material-symbols-outlined fs-16 text-body">
                                                            edit
                                                        </span>
                                                    </Link>

                                                    <Button
                                                        variant="link"
                                                        className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                                                        onClick={() => handleDelete(offer.uuid)}
                                                    >
                                                        <span className="material-symbols-outlined fs-16 text-danger">
                                                            delete
                                                        </span>
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </div>

                        <div className="p-0">
                            <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                                <span className="fs-12 fw-medium">
                                    Showing {offers.length === 0 ? 0 : Math.min(offers.length, (currentPage - 1) * pageSize + 1)}-
                                    {Math.min(offers.length, currentPage * pageSize)} of {offers.length} Results
                                </span>

                                <nav aria-label="Page navigation">
                                    <ul className="pagination mb-0 justify-content-center">
                                        <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                                                <span className="material-symbols-outlined">keyboard_arrow_left</span>
                                            </button>
                                        </li>

                                        {Array.from({ length: pageCount }).map((_, idx) => {
                                            const page = idx + 1;
                                            return (
                                                <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                                                    <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                                                        {page}
                                                    </button>
                                                </li>
                                            );
                                        })}

                                        <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                                            <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                                                <span className="material-symbols-outlined">keyboard_arrow_right</span>
                                            </button>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default OfferTable;
