"use client";

import { Card, Tab, Tabs } from "react-bootstrap";
import OrdersTable from './OrdersTable';

const ProductsList = () => {
  return (
    <>
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <Tabs
            defaultActiveKey="ordersTable"
            id="uncontrolled-tab-example"
            className="border-0 gap-3 mb-lg-4 mb-3 products-list-tabs"
          >
            <Tab eventKey="ordersTable" title="All Orders">
              <OrdersTable />
            </Tab>

            <Tab eventKey="completedOrders" title="Delivered / Completed">
              <OrdersTable />
            </Tab>

            <Tab eventKey="cancelledOrders" title="Cancelled Orders">
              <OrdersTable />
            </Tab>

            <Tab eventKey="returnedOrders" title="Returned / Refund Requests">
              <OrdersTable />
            </Tab>
          </Tabs>
        </Card.Body>
      </Card>
    </>
  )
}

export default ProductsList;