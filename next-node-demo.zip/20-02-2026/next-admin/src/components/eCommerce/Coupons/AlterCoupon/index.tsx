"use client";

import { Row, Col, Card, Form } from "react-bootstrap";
import Link from "next/link";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addUpdateOffer, getOffers } from "@/redux/features/dataSlice";
import { useAppDispatch } from '@/redux/hooks';

const AddCoupon = ({ uuid }) => {
  const dispatch = useAppDispatch();
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [errors, setErrors]:any = useState({});
  const [formData, setFormData]:any = useState({
    status: 1,
    publish_date: "",
    expiry_date: "",
    discount_type: "Percentage",
    discount_value: "",
    title: "",
    code: "",
    limits: "",
    min_order_value: "",
  });

  const [activeCondition, setActiveCondition] = useState("Category Wise");
  const handleConditionChange = (e) => {
    setActiveCondition(e.target.value);
  };

  useEffect(() => {
    if (uuid) {
      setIsEdit(true);
      fetchCoupon(uuid);
    }
  }, [uuid]);

  const fetchCoupon = async (uuid) => {
    setLoading(true);
    try {
      if (!uuid) return;
      const params:any = { uuid };
      const response = await dispatch(getOffers(params)).unwrap();
      setFormData({
        status: response.status,
        publish_date: response.publish_date || "",
        expiry_date: response.expiry_date || "",
        discount_type: response.discount_type || "Percentage",
        discount_value: response.discount_value || "",
        title: response.title || "",
        code: response.code || "",
        limits: response.limits || "",
        min_order_value: response.min_order_value || "",
      });
    } catch (error) {
      console.log(error);
      toast.error("Failed to fetch coupon details");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    console.log(name, value);
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const validateForm = () => {
    const newErrors:any = {};

    if (!formData.title.trim()) {
      newErrors.title = "Coupon title is required";
    }

    if (!formData.code.trim()) {
      newErrors.code = "Coupon code is required";
    }

    if (!String(formData.discount_value).trim()) {
      newErrors.discount_value = "Discount value is required";
    }

    if (!formData.publish_date) {
      newErrors.publish_date = "Publish date is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const payload:any = new FormData();
      payload.append("status", formData.status);
      payload.append("publish_date", formData.publish_date);
      payload.append("expiry_date", formData.expiry_date ?? null);
      payload.append("discount_type", formData.discount_type);
      payload.append("discount_value", formData.discount_value);
      payload.append("title", formData.title);
      payload.append("code", formData.code);
      payload.append("limits", formData.limits);
      payload.append("min_order_value", formData.min_order_value);
      // Do NOT append description or banner_image for coupons
      payload.append("type", "coupon");

      if (isEdit) {
        payload.append("uuid", uuid);
      }

      await dispatch(addUpdateOffer(payload)).unwrap();
      toast.success(isEdit ? "Coupon updated successfully" : "Coupon created successfully");
      router.push("/ecommerce/coupons");
    } catch (error) {
      toast.error(error?.message || "Failed to save coupon");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.push("/ecommerce/coupons");
  };

  return (
    <>
      <ToastContainer />
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col lg={5} xxl={4}>
            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <h3 className="mb-3 mb-lg-4">Coupon Status</h3>
                <Row>
                  {["Active", "In Active"].map((s) => (
                    <Col sm={6} className="mb-3 mb-sm-0" key={s}>
                      <label htmlFor={`status-${s == 'Active' ? 1 : 0}`}>
                        <input
                          type="radio"
                          className="form-check-input mx-2"
                          name="status"
                          id={`status-${s == 'Active' ? 1 : 0}`}
                          value={s == 'Active' ? 1 : 0}
                          checked={formData.status == (s == 'Active' ? 1 : 0)}
                          onChange={handleInputChange}
                        />
                        <span className="radio-content">
                          <span className="fw-medium text-secondary">{s}</span>
                        </span>
                      </label>
                    </Col>
                  ))}
                </Row>
              </Card.Body>
            </Card>

            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <h3 className="mb-3 mb-lg-4">Coupon Expiry</h3>
                <Row>
                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label">Publish Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="publish_date"
                        value={formData.publish_date ? formData.publish_date.split('T')[0] : ""}
                        onChange={handleInputChange}
                        isInvalid={!!errors.publish_date}
                      />
                      {errors.publish_date && (
                        <div className="text-danger mt-2 fs-14">
                          {errors.publish_date}
                        </div>
                      )}
                    </Form.Group>
                  </Col>
                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label">Expiry Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="expiry_date"
                        value={formData.expiry_date ? formData.expiry_date.split('T')[0] : ""}
                        onChange={handleInputChange}
                        isInvalid={!!errors.expiry_date}
                      />
                      {errors.expiry_date && (
                        <div className="text-danger mt-2 fs-14">
                          {errors.expiry_date}
                        </div>
                      )}
                    </Form.Group>
                  </Col>
                </Row>
              </Card.Body>
            </Card>

            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <h3 className="mb-3 mb-lg-4">Coupon Types</h3>
                <Row>
                  {["Percentage", "Fixed Value"].map((t) => (
                    <Col sm={6} className="mb-3 mb-sm-0" key={t}>
                      <Form.Group className="mb-4">
                        <label htmlFor={`type-${t}`}>
                          <input
                            type="radio"
                            className="form-check-input mx-2"
                            name="discount_type"
                            id={`type-${t}`}
                            value={t}
                            checked={formData.discount_type === t}
                            onChange={handleInputChange}
                          />
                          <span className="radio-content">
                            <span className="fw-medium text-secondary">{t}</span>
                          </span>
                        </label>
                      </Form.Group>
                    </Col>
                  ))}

                  <Col sm={6} lg={12}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label text-secondary">Discount Value</Form.Label>
                      <Form.Control
                        type="text"
                        name="discount_value"
                        className="h-55"
                        placeholder="Enter Discount Value"
                        value={formData.discount_value}
                        onChange={handleInputChange}
                        isInvalid={!!errors.discount_value}
                      />
                      {errors.discount_value && (
                        <div className="text-danger mt-2 fs-14">
                          {errors.discount_value}
                        </div>
                      )}
                    </Form.Group>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={7} xxl={8}>
            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <h3 className="mb-3 mb-lg-4">Coupon Information</h3>

                <Row>
                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label text-secondary">Title</Form.Label>
                      <Form.Control
                        type="text"
                        name="title"
                        className="h-55"
                        placeholder="Enter Coupon Title"
                        value={formData.title}
                        onChange={handleInputChange}
                        isInvalid={!!errors.title}
                      />
                      {errors.title && (
                        <div className="text-danger mt-2 fs-14">
                          {errors.title}
                        </div>
                      )}
                    </Form.Group>
                  </Col>
                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label text-secondary">Code</Form.Label>
                      <Form.Control
                        type="text"
                        name="code"
                        className="h-55"
                        placeholder="Enter Coupon Code"
                        value={formData.code}
                        onChange={handleInputChange}
                        isInvalid={!!errors.code}
                      />
                      {errors.code && (
                        <div className="text-danger mt-2 fs-14">
                          {errors.code}
                        </div>
                      )}
                    </Form.Group>
                  </Col>

                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label text-secondary">Limits</Form.Label>
                      <Form.Control
                        type="text"
                        name="limits"
                        className="h-55"
                        placeholder="Enter Coupon Limits"
                        value={formData.limits}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>

                  <Col sm={6} lg={6}>
                    <Form.Group className="mb-4">
                      <Form.Label className="label text-secondary">Minimum Order Value</Form.Label>
                      <Form.Control
                        type="text"
                        name="min_order_value"
                        className="h-55"
                        placeholder="Enter Minimum Order Value"
                        value={formData.min_order_value}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>
              </Card.Body>
            </Card>

            <Card className="bg-white border-0 rounded-3 mb-4">
              <Card.Body className="p-4">
                <h3 className="mb-3 mb-lg-4">Coupon Conditions</h3>

                <Row>
                  {["Category Wise", "Product Wise", "User Wise"].map((c, i) => (
                    <Col sm={4} className="mb-3 mb-sm-0" key={c}>
                      <Form.Group className="mb-4">
                        <label htmlFor={`condition${i}`}>
                          <input
                            type="radio"
                            className="form-check-input mx-2"
                            name="couponCondition"
                            id={`condition${i}`}
                            value={c}
                            checked={activeCondition === c}
                            onChange={handleConditionChange}
                          />
                          <span className="radio-content">
                            <span className="fw-medium text-secondary">{c}</span>
                          </span>
                        </label>
                      </Form.Group>
                    </Col>
                  ))}

                  {activeCondition == "Category Wise" ? (
                    <Col sm={12} lg={12}>
                      <Form.Group className="mb-4">
                        <Form.Label className="label text-secondary">Category</Form.Label>
                        <Form.Select className="form-control h-55" aria-label="Default select example">
                          <option defaultValue="0">Select</option>
                          <option defaultValue="1">Food</option>
                          <option defaultValue="2">Toys</option>
                          <option defaultValue="3">Accesories</option>
                          <option defaultValue="4">Health Care</option>
                          <option defaultValue="5">Grooming</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  ) : null}

                  {activeCondition == "Product Wise" ? (
                    <Col sm={12} lg={12}>
                      <Form.Group className="mb-4">
                        <Form.Label className="label text-secondary">Product</Form.Label>
                        <Form.Select className="form-control h-55" aria-label="Default select example">
                          <option defaultValue="0">Select</option>
                          <option defaultValue="1">Pedigree Adult Wet Dog Food, Chicken & Liver Chunks in Gravy, 70 g</option>
                          <option defaultValue="2">Petstages Dog Chew Toy ORKA Bone - Mini</option>
                          <option defaultValue="3">PetWale Raincoats with Reflective Strips for Dogs - Navy Blue</option>
                          <option defaultValue="4">Himalaya Himpyrin Anti-inflammatory Liquid for Dogs and Cats (30ml)</option>
                          <option defaultValue="5">Biogroom Waterless Bath Puppy/Dog Shampoo - 473 ml</option>
                          <option defaultValue="6">FOFOS Diapers for Male Dogs</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  ) : null}

                  {activeCondition == "User Wise" ? (
                    <Col sm={12} lg={12}>
                      <Form.Group className="mb-4">
                        <Form.Label className="label text-secondary">User</Form.Label>
                        <Form.Select className="form-control h-55" aria-label="Default select example">
                          <option defaultValue="0">Select</option>
                          <option defaultValue="1">Oliver Khan</option>
                          <option defaultValue="2">Carolyn Barnes</option>
                          <option defaultValue="3">Donna Miller</option>
                          <option defaultValue="4">Barbara Cross</option>
                          <option defaultValue="5">Rebecca Block</option>
                          <option defaultValue="6">Ramiro McCarty</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  ) : null}
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <div className="d-flex flex-wrap gap-3 mb-4">
          <button
            type="button"
            className="btn btn-danger py-2 px-4 fw-medium fs-16 text-white"
            onClick={handleCancel}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn btn-primary py-2 px-4 fw-medium fs-16"
            disabled={loading}
          >
            <i className="ri-add-line text-white fw-medium"></i>{" "}
            {loading ? "Saving..." : isEdit ? "Update Coupon" : "Add Coupon"}
          </button>
        </div>
      </Form>
    </>
  );
};

export default AddCoupon;
