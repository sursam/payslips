"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card, Table, Button, Spinner } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import SearchForm from "./SearchForm";
import { useAppDispatch } from '@/redux/hooks';

import {
  fetchOffers,
  deleteOffers,
} from "@/redux/features/dataSlice";

const CouponsTable = () => {
  const dispatch = useAppDispatch();
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  useEffect(() => {
    fetchCouponsData();
  }, []);

  const fetchCouponsData = async () => {
    try {
      setLoading(true);
      const params:any = { type: "coupon" };
      const res = await dispatch(fetchOffers(params)).unwrap();
      const data = res?.data || [];
      if (res?.status) {
        setCoupons(data || []);
      } else {
        toast.error(res?.message || "Failed to fetch coupons");
      }
    } catch (err) {
      toast.error("Unable to fetch coupons");
    } finally {
      setLoading(false);
    }
  };

  const loadCouponList = async (searchText = "") => {
    try {
      const params:any = { searchText, type: "coupon" };
      const res = await dispatch(fetchOffers(params)).unwrap();
      const list = res?.data || res || [];
      setCoupons(list);
      setCurrentPage(1);
    } catch (err) {
      toast.error(err?.message || "Failed to load coupon data");
    }
  };

  const handleClickDeleteCoupon = async (uuid) => {
    try {
      const params:any = { uuid };
      const res = await dispatch(deleteOffers(params)).unwrap();
      if (res?.status) {
        toast.success("Coupon deleted");
        fetchCouponsData();
      } else {
        toast.error(res?.message || "Failed to delete coupon");
      }
    } catch (err) {
      toast.error(err?.message || "Failed to delete coupon");
    }
  };

  const handleDelete = (uuid) => {
    if (!uuid) return;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this coupon?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                handleClickDeleteCoupon(uuid);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  const pageCount = Math.max(1, Math.ceil(coupons.length / pageSize));
  const paginatedCoupons = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return coupons.slice(start, start + pageSize);
  }, [coupons, currentPage]);

  useEffect(() => {
    if (currentPage > pageCount) setCurrentPage(1);
  }, [pageCount, currentPage]);

  return (
    <>
      <ToastContainer position="top-right" />

      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-lg-4 mb-3">
            <SearchForm loadCouponList={loadCouponList} />

            <Link
              href="/ecommerce/coupons/add"
              className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
            >
              <span className="py-sm-1 d-block">
                <i className="ri-add-line d-none d-sm-inline-block fs-18"></i>
                <span>Add New Coupon</span>
              </span>
            </Link>
          </div>

          <div className="default-table-area ec-recent-orders">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th scope="col">Sl No.</th>
                    <th scope="col">Title</th>
                    <th scope="col">Code</th>
                    <th scope="col">Discount</th>
                    <th scope="col">Start Date</th>
                    <th scope="col">End Date</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {loading && (
                    <tr>
                      <td colSpan={8} className="text-center py-4">
                        <Spinner animation="border" size="sm" /> Loading...
                      </td>
                    </tr>
                  )}

                  {!loading && paginatedCoupons.length === 0 && (
                    <tr>
                      <td colSpan={8} className="text-center py-4">
                        No coupons found.
                      </td>
                    </tr>
                  )}

                  {!loading &&
                    paginatedCoupons.map((coupon, i) => (
                      <tr key={coupon.uuid ?? i}>
                        <td>{coupon.id ?? (i + 1 + (currentPage - 1) * pageSize)}</td>

                        <td>{coupon.title ?? coupon.name}</td>

                        <td>{coupon.code}</td>

                        <td>
                          {coupon.discount_type === "Fixed Value"
                            ? `$${coupon.discount_value}`
                            : `${coupon.discount_value}%`}
                        </td>

                        <td>
                          {coupon.publish_date
                            ? new Date(coupon.publish_date).toLocaleDateString()
                            : coupon.startDate ?? "N/A"}
                        </td>

                        <td>
                          {coupon.expiry_date
                            ? new Date(coupon.expiry_date).toLocaleDateString()
                            : coupon.endDate ?? "N/A"}
                        </td>

                        <td>
                          <span
                            className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${
                              coupon.status == 1 ? "text-success bg-success" : "text-danger bg-danger"
                            }`}
                          >
                            {coupon.status == 1 ? "active" : "inactive"}
                          </span>
                        </td>

                        <td>
                          <div className="d-flex align-items-center gap-1">
                            <Link
                              href={`/ecommerce/coupons/edit/${coupon.uuid}`}
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                            >
                              <span className="material-symbols-outlined fs-16 text-body">edit</span>
                            </Link>

                            <Button
                              variant="link"
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => handleDelete(coupon.uuid)}
                            >
                              <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>

            <div className="p-0">
              <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                <span className="fs-12 fw-medium">
                  Showing {coupons.length === 0 ? 0 : Math.min(coupons.length, (currentPage - 1) * pageSize + 1)}-
                  {Math.min(coupons.length, currentPage * pageSize)} of {coupons.length} Results
                </span>

                <nav aria-label="Page navigation">
                  <ul className="pagination mb-0 justify-content-center">
                    <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                      <button
                        className="page-link icon"
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        aria-label="Previous"
                      >
                        <span className="material-symbols-outlined">keyboard_arrow_left</span>
                      </button>
                    </li>

                    {Array.from({ length: pageCount }).map((_, idx) => {
                      const page = idx + 1;
                      return (
                        <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                          <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                            {page}
                          </button>
                        </li>
                      );
                    })}

                    <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                      <button
                        className="page-link icon"
                        onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))}
                        aria-label="Next"
                      >
                        <span className="material-symbols-outlined">keyboard_arrow_right</span>
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>
    </>
  );
};

export default CouponsTable;
