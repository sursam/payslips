"use client";

import { Form } from "react-bootstrap";
interface SearchFormProps {
  loadCouponList: (searchText?: string) => Promise<void>; // Add this line
}
const SearchForm: React.FC<SearchFormProps> = ({loadCouponList}) => {
  return (
    <>
      <Form className="position-relative table-src-form">
        <Form.Control type="text" placeholder="Search here" onChange={(e) => loadCouponList(e.target.value)}/>
          <span className="material-symbols-outlined position-absolute top-50 start-0 translate-middle-y">
            search
          </span>
      </Form>
    </>
  );
};

export default SearchForm;
