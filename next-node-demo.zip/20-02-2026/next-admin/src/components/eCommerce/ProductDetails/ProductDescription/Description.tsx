"use client";

import { Card } from "react-bootstrap";

const Description = () => {
  return (
    <>
      <Card className="bg-white border-0 rounded-3 mb-4 rounded-top-0">
        <Card.Body className="p-4">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean semper porta ligula eget semper. Sed arcu ante, bibendum quis tellus porta, iaculis ullamcorper est. Suspendisse at venenatis dolor, blandit ultricies risus. Phasellus magna sem, fringilla quis ornare sodales, iaculis eget ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed sed nisi facilisis, egestas purus vel, pulvinar lacus. Ut aliquam convallis lectus, quis hendrerit quam ultrices et. Nunc nisl risus, eleifend a sodales sit amet, consectetur at augue. Maecenas varius sed massa vel eleifend. Mauris nec auctor nibh, a vestibulum nisl. Ut tincidunt congue euismod.
          </p>
          <p>
            Fusce molestie sem vitae molestie fermentum. Duis venenatis elit elit, eu gravida magna dignissim vestibulum. Quisque a iaculis magna. Mauris eget dictum urna. Curabitur sagittis, nibh ac suscipit pulvinar, neque sem interdum dui, sit amet convallis justo nisi sed lorem. Fusce a nisi in odio auctor iaculis eget vel lacus. Integer quis nisi sed metus gravida semper. Praesent pellentesque, nisi sit amet gravida fermentum, risus ipsum vestibulum lectus, ac aliquet mi nulla vel nisl. Suspendisse potenti. Cras id rutrum leo. Vivamus pharetra ipsum posuere, accumsan mi eu, ullamcorper massa. Aliquam interdum diam eu erat feugiat, egestas suscipit diam rhoncus. Vivamus hendrerit nec ipsum non facilisis. Aenean elementum molestie enim in blandit. Aenean ac blandit lectus. Nam sed magna ante.
          </p>
          <p>
            Proin a risus ac purus placerat elementum ut vel diam. Donec in lorem elementum, auctor ipsum a, viverra purus. Nullam eu tellus vitae libero viverra elementum. Nulla facilisi. Nulla sapien velit, eleifend sed finibus vitae, commodo nec turpis. Nam interdum non nisi id ornare. Ut in aliquam neque.
          </p>
        </Card.Body>
      </Card>
    </>
  );
};

export default Description;
