"use client";

import React, { useState } from 'react';

function StyleSelector() {
  const [style, setStyle] = useState('Dry Food'); // Default value

  const handleChange = (event) => {
    setStyle(event.target.value); // Update style based on selected radio button
  };

  return (
    <>
      <div className="d-flex style-select mb-2 align-items-center">
        <span>Category:</span>
        <h5 className="mb-0 fw-medium fs-14 position-relative top-2 ms-1">
          {style}
        </h5>
      </div>

      <div className="select-style mb-4 d-flex flex-wrap gap-3">
        <div>
          <input
            type="radio"
            className="btn-check"
            name="options-base"
            id="option5"
            autoComplete="off"
            value="Dry Food"
            checked={style === 'Dry Food'}
            onChange={handleChange}
          />
          <label className="btn mb-2 mb-sm-0 border" htmlFor="option5">
            Dry Food
          </label>
        </div>
        <div>
          <input
            type="radio"
            className="btn-check"
            name="options-base"
            id="option6"
            autoComplete="off"
            value="Vegetarian Food"
            checked={style === 'Vegetarian Food'}
            onChange={handleChange}
          />
          <label className="btn mb-2 mb-sm-0 border" htmlFor="option6">
            Vegetarian Food
          </label>
        </div>
      </div>
    </>
  );
}

export default StyleSelector;
