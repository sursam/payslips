"use client";

import React, { useState } from 'react';

function CapacitySelector() {
  const [capacity, setCapacity] = useState('70 g'); // Default value

  const handleChange = (event) => {
    setCapacity(event.target.value); // Update capacity based on selected radio button
  };

  return (
    <>
      <div className="d-flex style-select mb-2 align-items-center">
        <span>Weight:</span>
        <h5 className="mb-0 fw-medium fs-14 position-relative top-2 ms-1">
          {capacity}
        </h5>
      </div>

      <div className="select-style mb-4 d-flex flex-wrap gap-3">
        <div>
          <input
            type="radio"
            className="btn-check"
            name="options-outlined"
            id="success-outlined"
            autoComplete="off"
            value="70 g"
            checked={capacity === '70 g'}
            onChange={handleChange}
          />
          <label
            className="btn mb-2 mb-sm-0 border"
            htmlFor="success-outlined"
          >
            70 g
          </label>
        </div>

        <div>
          <input
            type="radio"
            className="btn-check"
            name="options-outlined"
            id="danger-outlined"
            autoComplete="off"
            value="100 g"
            checked={capacity === '100 g'}
            onChange={handleChange}
          />
          <label
            className="btn mb-2 mb-sm-0 border"
            htmlFor="danger-outlined"
          >
            100 g
          </label>
        </div>
      </div>
    </>
  );
}

export default CapacitySelector;
