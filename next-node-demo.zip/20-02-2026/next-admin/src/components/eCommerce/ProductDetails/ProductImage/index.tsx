"use client";

import Image from "next/image";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';

const ProductImage = () => { 
  return (
    <>
      <Tabs className='product-image'>
        <TabPanel>
          <Image src="/images/dry-food.jpg" alt="product" width={370} height={365} />
        </TabPanel>
        
        <TabPanel>
          <Image src="/images/vegetarian-food.jpg" alt="product" width={370} height={365} />
        </TabPanel>

        <TabPanel>
          <Image src="/images/health-care-aids.jpg" alt="product" width={370} height={365} />
        </TabPanel>

        <TabList>
          <Tab>
            <Image src="/images/dry-food.jpg" alt="product" width={370} height={365} />
          </Tab>
          <Tab>
            <Image src="/images/vegetarian-food.jpg" alt="product" width={370} height={365} />
          </Tab>
          <Tab>
            <Image src="/images/health-care-aids.jpg" alt="product" width={370} height={365} />
          </Tab>
        </TabList> 
      </Tabs>
    </>
  )
}

export default ProductImage;