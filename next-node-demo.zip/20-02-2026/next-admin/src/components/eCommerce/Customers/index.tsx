"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Card, Form, Table, Button } from "react-bootstrap";
import Image from "next/image";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAppDispatch } from '@/redux/hooks';
import { confirmAlert } from "react-confirm-alert";
import {
  addUpdateCustomer,
  fetchCustomerList,
  getCustomerList,
  deleteCustomer,
} from "@/redux/features/dataSlice";

const Customers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const dispatch = useAppDispatch();

  // pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  // Modal & mode state
  const [showModal, setShowModal] = useState(false);
  const [isViewMode, setIsViewMode] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // Form state
  const [form, setForm] = useState({
    id: "",
    name: "",
    email_id: "",
    phone_number: "",
    password: "",
    confirmPassword: "",
    status: 1,
    profileImage: null,
  });
  const [errors, setErrors]:any = useState({});

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const res = await dispatch(fetchCustomerList()).unwrap();
      const cusList = res?.data || [];
      setCustomers(cusList);
      console.log("Fetched customers:", res);
      if (res?.status) {
        setCustomers(res.data || []);
      } else {
        toast.error(res.message || "Failed to fetch customers");
      }
    } catch (err) {
      toast.error("Unable to fetch customers");
    } finally {
      setLoading(false);
    }
  };

  // Derived pagination data
  const pageCount = Math.max(1, Math.ceil(customers.length / pageSize));
  const paginatedCustomers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return customers.slice(start, start + pageSize);
  }, [customers, currentPage]);

  useEffect(() => {
    if (currentPage > pageCount) setCurrentPage(1);
  }, [pageCount, currentPage]);

  const resetForm = () => {
    setForm({
      id: "",
      name: "",
      email_id: "",
      phone_number: "",
      password: "",
      confirmPassword: "",
      status: 1,
      profileImage: null,
    });
    setErrors({});
    setIsEditMode(false);
    setIsViewMode(false);
  };

  const openCreate = () => {
    resetForm();
    setShowModal(true);
  };

  const openView = (customer) => {
    setForm({
      id: customer.id,
      name: customer.name || "",
      email_id: customer.email_id || "",
      phone_number: customer.phone_number || "",
      password: "",
      confirmPassword: "",
      status: customer.status ?? 1,
      profileImage: null,
    });
    setIsViewMode(true);
    setIsEditMode(false);
    setShowModal(true);
  };

  const openEdit = (customer) => {
    setForm({
      id: customer.id,
      name: customer.name || "",
      email_id: customer.email_id || "",
      phone_number: customer.phone_number || "",
      password: "",
      confirmPassword: "",
      status: customer.status ?? 1,
      profileImage: null,
    });
    setIsEditMode(true);
    setIsViewMode(false);
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "profileImage") {
      console.log("Selected profile image file:", files[0]);
      setForm((f) => ({ ...f, profileImage: files[0] }));
    } else {
      console.log(`Changed field ${name} to value:`, value);
      setForm((f) => ({ ...f, [name]: value }));
    }
  };

  const validate = () => {
    const err:any = {};
    if (!form.name || !form.name.trim()) err.name = "Name is required";
    if (!form.email_id || !/^\S+@\S+\.\S+$/.test(form.email_id)) err.email_id = "Valid email is required";
    if (!form.phone_number || !/^[\d+\-\s()]{7,20}$/.test(form.phone_number))
      err.phone_number = "Valid phone required";
    // password required on create
    const isCreate = !form.id;
    if (isCreate && !form.password) err.password = "Password is required";
    if (form.password && form.password.length > 0 && form.password.length < 6)
      err.password = "Password must be at least 6 characters";
    if (form.password !== form.confirmPassword) err.confirmPassword = "Passwords must match";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const submitForm = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      setLoading(true);
      const formData:any = new FormData();
      if (form.id) formData.append("id", form.id);
      formData.append("name", form.name);
      formData.append("email_id", form.email_id);
      formData.append("phone_number", form.phone_number);
      formData.append("status", form.status);
      if (form.password) formData.append("password", form.password);
      if (form.profileImage) formData.append("profileImage", form.profileImage);

      console.log("Submitting form data:", formData);

      const res = await dispatch(addUpdateCustomer(formData)).unwrap();
      console.log("Add/Update customer response:", res);
      if (res?.status) {
        toast.success(res.message || "Customer saved.");
        setShowModal(false);
        resetForm();
        fetchCustomers();
      } else {
        setShowModal(false);
        toast.error(res.message || "Failed to save customer");
      }
    } catch (err) {
      console.error(err);
      toast.error("Unexpected error saving customer");
    } finally {
      setLoading(false);
    }
  };

  const handleClickDeleteCustomer = async (userId) => {
    try {
      const params:any = { id: userId };
      const res = await dispatch(deleteCustomer(params)).unwrap();
      if (res?.status) {
        toast.success(res.message || "Customer deleted");
        await fetchCustomers();
      } else {
        toast.error(res.message || "Failed to delete");
      }
    } catch (err) {
      toast.error(err?.message || "Unexpected error deleting customer");
    }
  };

  const handleDelete = (id) => {
    const userId = id;
    if (!userId) return;

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h1>Are you sure?</h1>
            <p>You want to delete this role?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                handleClickDeleteCustomer(userId);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      }
    });
  };

  return (
    <>
      <ToastContainer position="top-right" />
      <Card className="bg-white border-0 rounded-3 mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-3 mb-lg-4">
            <div>
              {/* <Form.Control
                type="text"
                placeholder="🔍︎ Search here..."
                onChange={(e) => {
                    const q = e.target.value;
                    const el = e.target;
                    if (el._searchTimer) clearTimeout(el._searchTimer);
                    el._searchTimer = setTimeout(async () => {
                      try {
                        setLoading(true);
                        const formData = new FormData();
                        formData.append("searchText", q);
                        const res = await dispatch(fetchCustomerList(formData)).unwrap();
                        if (res?.status) setCustomers(res.data || []); else toast.error(res.message || "Search failed");
                      } catch (err) {
                        toast.error("Search failed");
                      } finally {
                        setLoading(false);
                      }
                    }, 400);
                }}
              /> */}

              <Form className="position-relative table-src-form">
                <Form.Control 
                type="text" 
                placeholder="Search here" 
                onChange={(e) => {
                    const q = e.target.value;
                    const el:any = e.target;
                    if (el._searchTimer) clearTimeout(el._searchTimer);
                    el._searchTimer = setTimeout(async () => {
                      try {
                        setLoading(true);
                        const formData:any = new FormData();
                        formData.append("searchText", q);
                        const res = await dispatch(fetchCustomerList(formData)).unwrap();
                        if (res?.status) setCustomers(res.data || []); else toast.error(res.message || "Search failed");
                      } catch (err) {
                        toast.error("Search failed");
                      } finally {
                        setLoading(false);
                      }
                    }, 400);
                }}
                />
                  <span className="material-symbols-outlined position-absolute top-50 start-0 translate-middle-y">
                    search
                  </span>
              </Form>
            </div>

            <div className="text-end">
              <button
                className="btn btn-outline-primary py-1 px-2 px-sm-4 fs-14 fw-medium rounded-3 hover-bg"
                onClick={openCreate}
              >
                <span className="py-sm-1 d-block">
                  <i className="ri-add-line"></i>
                  <span>Add New Customer</span>
                </span>
              </button>
            </div>
          </div>

          <div className="default-table-area">
            <div className="table-responsive">
              <Table className="align-middle">
                <thead>
                  <tr>
                    <th>Sl No.</th>
                    <th>Customer</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {paginatedCustomers?.length ? (
                    paginatedCustomers.map((c) => (
                      <tr key={c.id}>
                        <td className="text-body">{c.id}</td>

                        <td>
                          <div className="d-flex align-items-center">
                            <div className="flex-grow-1 ms-2 position-relative top-1">
                              <h6 className="mb-0 fs-14 fw-medium">{c.name}</h6>
                            </div>
                          </div>
                        </td>

                        <td className="text-body">{c.email_id}</td>

                        <td>{c.phone_number}</td>

                        <td>
                          <span
                            className={`badge bg-opacity-10 p-2 fs-12 fw-normal text-capitalize ${c.status == 1 ? "bg-success text-success" : "bg-danger text-danger"}`}
                          >
                            {c.status == 1 ? "active" : "deactive"}
                          </span>
                        </td>

                        <td>
                          <div className="d-flex align-items-center gap-1">
                            <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => openView(c)}
                              title="View"
                            >
                              <span className="material-symbols-outlined fs-16 text-primary">visibility</span>
                            </button>

                            <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => openEdit(c)}
                              title="Edit"
                            >
                              <span className="material-symbols-outlined fs-16 text-body">edit</span>
                            </button>

                            <button
                              className="ps-0 border-0 bg-transparent lh-1 position-relative top-2"
                              onClick={() => handleDelete(c.id)}
                              title="Delete"
                            >
                              <span className="material-symbols-outlined fs-16 text-danger">delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={9} className="text-center py-4">
                        {loading ? "Loading..." : "No customers found"}
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>

            <div className="p-0">
              <div className="d-flex justify-content-center justify-content-sm-between align-items-center text-center flex-wrap gap-2 showing-wrap">
                <span className="fs-12 fw-medium">
                  Showing {customers.length === 0 ? 0 : Math.min(customers.length, (currentPage - 1) * pageSize + 1)}-
                  {Math.min(customers.length, currentPage * pageSize)} of {customers.length} Results
                </span>

                <nav aria-label="Page navigation example">
                  <ul className="pagination mb-0 justify-content-center">
                    <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                      <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} aria-label="Previous">
                        <span className="material-symbols-outlined">keyboard_arrow_left</span>
                      </button>
                    </li>

                    {Array.from({ length: pageCount }).map((_, idx) => {
                      const page = idx + 1;
                      return (
                        <li key={page} className={`page-item ${currentPage === page ? "active" : ""}`}>
                          <button className={`page-link ${currentPage === page ? "active" : ""}`} onClick={() => setCurrentPage(page)}>
                            {page}
                          </button>
                        </li>
                      );
                    })}

                    <li className={`page-item ${currentPage === pageCount ? "disabled" : ""}`}>
                      <button className="page-link icon" onClick={() => setCurrentPage((p) => Math.min(pageCount, p + 1))} aria-label="Next">
                        <span className="material-symbols-outlined">keyboard_arrow_right</span>
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>

          </div>
        </Card.Body>
      </Card>

      {/* Modal */}
      <div className={`custom-modal right ${showModal ? "show" : ""}`}>
        <div className="custom-modal-content position-relative z-3">
          <div className="border-bottom py-3 px-4 d-flex align-items-center justify-content-between">
            <h3 className="fs-18 mb-0">{isViewMode ? "View Customer" : isEditMode ? "Edit Customer" : "Add New Customer"}</h3>

            <div className="close-link" onClick={() => { setShowModal(false); resetForm(); }}>
              <span className="material-symbols-outlined">close</span>
            </div>
          </div>

          <div className="p-4">
            <Form onSubmit={submitForm}>
              <Form.Group className="mb-4">
                <Form.Label className="label">Customer Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  className="text-dark"
                  placeholder="Customer Name"
                  value={form.name}
                  onChange={handleChange}
                  isInvalid={!!errors.name}
                  disabled={isViewMode}
                />
                <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email_id"
                  className="text-dark"
                  placeholder="Email"
                  value={form.email_id}
                  onChange={handleChange}
                  isInvalid={!!errors.email_id}
                  disabled={isViewMode}
                />
                <Form.Control.Feedback type="invalid">{errors.email_id}</Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label className="label">Phone</Form.Label>
                <Form.Control type="text" name="phone_number" className="text-dark" value={form.phone_number} onChange={handleChange} isInvalid={!!errors.phone_number} disabled={isViewMode} />
                <Form.Control.Feedback type="invalid">{errors.phone_number}</Form.Control.Feedback>
              </Form.Group>

              {!isViewMode && (
                <>
                  <Form.Group className="mb-4">
                    <Form.Label className="label">Password {isEditMode ? "(Leave blank to keep current)" : ""}</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={form.password}
                      onChange={handleChange}
                      isInvalid={!!errors.password}
                      disabled={isViewMode}
                    />
                    <Form.Control.Feedback type="invalid">{errors.password}</Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Form.Label className="label">Confirm Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="confirmPassword"
                      value={form.confirmPassword}
                      onChange={handleChange}
                      isInvalid={!!errors.confirmPassword}
                      disabled={isViewMode}
                    />
                    <Form.Control.Feedback type="invalid">{errors.confirmPassword}</Form.Control.Feedback>
                  </Form.Group>
                </>
              )}

              <Form.Group className="mb-4">
                <Form.Label className="label">Status</Form.Label>
                <Form.Select
                  name="status"
                  className="form-control text-dark"
                  value={String(form.status)}
                  onChange={handleChange}
                  disabled={isViewMode}
                >
                  <option value="1">Active</option>
                  <option value="0">Deactive</option>
                </Form.Select>
              </Form.Group>

              <Form.Group className="d-flex gap-3">
                {!isViewMode && (
                  <Button variant="primary" type="submit" className="text-white fw-semibold py-2 px-2 px-sm-3" disabled={loading}>
                    <span className="py-sm-1 d-block">{isEditMode ? "Update Customer" : "Create New Customer"}</span>
                  </Button>
                )}
              </Form.Group>
            </Form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Customers;
