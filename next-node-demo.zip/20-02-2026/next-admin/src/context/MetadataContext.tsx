// context/MetadataContext.tsx
'use client'
import { createContext, useContext, useState, ReactNode } from 'react'

type Metadata = { title?: string; description?: string }
type MetadataContextType = {
  metadata: Metadata
  setMetadata: (data: Metadata) => void
}

const MetadataContext = createContext<MetadataContextType | undefined>(undefined)

export function MetadataProvider({ children }: { children: ReactNode }) {
  const [metadata, setMetadata] = useState<Metadata>({
    title: 'Eclick',
    description: 'Eclick',
  })

  return (
    <MetadataContext.Provider value={{ metadata, setMetadata }}>
      {/* React 19 hoists these tags to the <head> automatically */}
      {metadata.title && <title>{metadata.title}</title>}
      {metadata.description && <meta name="description" content={metadata.description} />}
      {children}
    </MetadataContext.Provider>
  )
}

export const useMetadata = () => {
  const context = useContext(MetadataContext)
  if (!context) throw new Error('useMetadata must be used within MetadataProvider')
  return context
}
