'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { jwtDecode } from 'jwt-decode';
import AccessDenied from '@/components/Layout/AccessDenied';
import { useSelector } from 'react-redux';

// Define the shape of the context state
type AuthContextType = {
  permissions: string[];
  setPermissions: (data: string[]) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [permissions, setPermissions] = useState<string[]>([]);
  const [hasAccess, setHasAccess] = useState(false);  
  const [isLoading, setIsLoading] = useState(true);
  const accessToken = useSelector((state:any) => state.auth?.session?.accessToken);
  
  useEffect(() => {
    const checkAccess = () => {
      if(permissions){
        const userInfo:any = accessToken ? jwtDecode(accessToken) : null;
        const userPermissions = userInfo && userInfo.permissions ? userInfo.permissions : [];
        setHasAccess(!accessToken || (userInfo && (userInfo?.roleSlug == "super-admin" || userPermissions.filter(x => permissions.includes(x)).length > 0)));
        setIsLoading(false);
      }else{
        setHasAccess(true);
        setIsLoading(false);
      }
    };
    checkAccess();
  }, [permissions, accessToken]);

  return (
    <AuthContext.Provider value={{ permissions, setPermissions }}>
      {
        !isLoading ?
          hasAccess ?
            children
          :
            <AccessDenied/>
        :
          ''
      }
    </AuthContext.Provider>
  );
}

// Custom hook to use the AuthContext
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
