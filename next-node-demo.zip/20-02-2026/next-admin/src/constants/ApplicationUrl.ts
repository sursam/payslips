export const API_URL = process.env.NEXT_PUBLIC_API_URL;

export const FORGOT_PASSWORD = `${API_URL}forgot-password`;
export const CHANGE_PASSWORD = `${API_URL}change-password`;

export const GET_ROLE_LIST = `${API_URL}get-role-list`;
export const SAVE_ROLE_DATA = `${API_URL}save-role`;
export const GET_ROLE_DETAILS = `${API_URL}get-role-details`;
export const UPDATE_ROLE_STATUS = `${API_URL}update-role-status`;
export const DELETE_ROLE = `${API_URL}role-delete`;

export const ALTER_ADMIN_USER = `${API_URL}alter-admin-user`;
export const LIST_ADMIN_USER = `${API_URL}list-admin-user`;
export const GET_ADMIN_USER = `${API_URL}get-admin-user`;
export const DELETE_ADMIN_USER = `${API_URL}delete-admin-user`;
export const FETCH_MENU_PERMISSIONS = `${API_URL}fetch-menu-permissions`;
export const GET_MENU_DETAILS = `${API_URL}get-menu-details`;
export const FETCH_ROLE_PERMISSIONS = `${API_URL}fetch-role-permissions`;
export const UPDATE_ROLE_PERMISSIONS = `${API_URL}update-role-permissions`;
