import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  FORGOT_PASSWORD,
  GET_ROLE_LIST,
  SAVE_ROLE_DATA,
  GET_ROLE_DETAILS,
  DELETE_ROLE,
  UPDATE_ROLE_STATUS,
  ALTER_ADMIN_USER,
  LIST_ADMIN_USER,
  GET_ADMIN_USER,
  DELETE_ADMIN_USER,
  FETCH_MENU_PERMISSIONS,
  GET_MENU_DETAILS,
  FETCH_ROLE_PERMISSIONS,
  UPDATE_ROLE_PERMISSIONS,
} from "@/constants/ApplicationUrl";
import Api from "@/utils/Api";
// import { useSelector } from 'react-redux';

// import { getServerSession } from "next-auth";
// import { authOptions } from "@/app/api/auth/[...nextauth]/route";
// const session = await getServerSession(authOptions);
// const token =
//   typeof localStorage !== "undefined"
//     ? localStorage.getItem("web-auth-token")
//     : null;
// export const saveProjectFiles = createAsyncThunk(
//   "data/saveProjectFiles",
//   async (userData, { rejectWithValue }) => {
//     try {
//       const response = await Api.POST(SAVE_PROJECT_FILE, userData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//           Authorization: `Bearer ${token}`,
//         },
//       });
//       return response.data;
//     } catch (error) {
//       return rejectWithValue({
//         message:
//           error.response?.data?.message ||
//           "Failed to save project files. Please try again later.",
//       });
//     }
//   }
// );

// Fetch role data
export const forgotPassword = createAsyncThunk(
  "data/fetchRoleData",
  async (data, { rejectWithValue }) => {
    try {
      const response = await Api.POST(FORGOT_PASSWORD, data);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to send chnage password otp. Please try again later.",
      });
    }
  }
);

export const fetchRoleData = createAsyncThunk(
  "data/fetchRoleData",
  async (data, { rejectWithValue }) => {
    try {
      // const token = useSelector((state) => state.auth.token);
      // console.log('token', token);
      const response = await Api.POST(GET_ROLE_LIST, data);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch role data. Please try again later.",
      });
    }
  }
);

// Create / Update role data
export const saveRoleData = createAsyncThunk(
  "data/saveRoleData",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(SAVE_ROLE_DATA, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Role save failed. Please try again later.",
      });
    }
  }
);
// Fetch role details
export const deatilsRoleData = createAsyncThunk(
  "data/deatilsRoleData",
  async (slug, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_ROLE_DETAILS, { slug });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch role data. Please try again later.",
      });
    }
  }
);
// Fetch role details
export const fetchRolePermissions = createAsyncThunk(
  "data/fetchRolePermissions",
  async (roleId, { rejectWithValue }) => {
    try {
      const response = await Api.POST(FETCH_ROLE_PERMISSIONS, { roleId });
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch role permissions. Please try again later.",
      });
    }
  }
);
// Update role data
export const updateRoleData = createAsyncThunk(
  "data/updateRoleData",
  async ({ roleId, roleData }, { rejectWithValue }) => {
    try {
      const response = await Api.PUTDATA(
        `${GET_ROLE_DETAILS}/${roleId}`,
        roleData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update role data. Please try again later.",
      });
    }
  }
);
// Update role status
export const updateRoleStatus = createAsyncThunk(
  "data/updateRoleStatus",
  async (roleData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(`${UPDATE_ROLE_STATUS}`, roleData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update role status. Please try again later.",
      });
    }
  }
);
// Delete role data
export const deleteRoleData = createAsyncThunk(
  "data/deleteRoleData",
  async ({ roleSlug }, { rejectWithValue }) => {
    try {
      const response = await Api.POST(`${DELETE_ROLE}`, {roleSlug});
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete role data. Please try again later.",
      });
    }
  }
);

export const alterAdminUser = createAsyncThunk(
  "data/alterAdminUser",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(ALTER_ADMIN_USER, formData);
      console.log("Alter Admin User response:", response);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Role save failed. Please try again later.",
      });
    }
  }
);

export const fetchAdminUserList = createAsyncThunk(
  "data/fetchAdminUserList",
  async (data, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_ADMIN_USER, data);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch admin user list. Please try again later.",
      });
    }
  }
);
// Fetch menu permissions details
export const fetchMenuPermissions = createAsyncThunk(
  "data/fetchMenuPermissions",
  async ({ rejectWithValue }) => {
    try {
      const response = await Api.GET(FETCH_MENU_PERMISSIONS);
      return response;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.message ||
          "Failed to fetch menu groups data. Please try again later.",
      });
    }
  }
);
export const getMenuDetails = createAsyncThunk(
  "data/getMenuDetails",
  async ({link}, { rejectWithValue }) => {
    try {
      const response = await Api.POST(GET_MENU_DETAILS, {link});
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to get menu details. Please try again later.",
      });
    }
  }
);


export const detailAdminUser = createAsyncThunk(
  "data/detailAdminUser",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_ADMIN_USER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to fetch adimn data. Please try again later.",
      });
    }
  }
);
// Update role permissions
export const updateRolePermissions = createAsyncThunk(
  "data/updateRolePermissions",
  async ({ roleId, rolePermissions }, { rejectWithValue }) => {
    try {
      const response = await Api.POST(
        UPDATE_ROLE_PERMISSIONS,
        { roleId, rolePermissions }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to update role permissions. Please try again later.",
      });
    }
  }
);

// Delete admin user data
export const deleteAdminUserData = createAsyncThunk(
  "data/deleteAdminUserData",
  async ({ id }, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_ADMIN_USER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Failed to delete role data. Please try again later.",
      });
    }
  }
);

//Customer APIs
export const addUpdateCustomer = createAsyncThunk(
  "data/addUpdateCustomer",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(ADD_UPDATE_CUSTOMER, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const fetchCustomerList = createAsyncThunk(
    "data/fetchCustomerList",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_CUSTOMER, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const getCustomerList = createAsyncThunk(
    "data/getCustomerList",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_CUSTOMER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const deleteCustomer = createAsyncThunk(
    "data/deleteCustomer",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_CUSTOMER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);


// Services APIs
export const addUpdateService = createAsyncThunk(
  "data/addUpdateService",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(ADD_UPDATE_SERVICE, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const fetchServiceList = createAsyncThunk(
    "data/fetchServiceList",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_SERVICE, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const getServiceList = createAsyncThunk(
    "data/getServiceList",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_SERVICE}/${id}`);
      return response;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);
export const getPetTypeList = createAsyncThunk(
    "data/getPetTypeList",
  async ({}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${LIST_PET_TYPES}`);
      return response;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Fetch failed. Please try again later.",
      });
    }
  }
);
export const getServiceTypeList = createAsyncThunk(
    "data/getServiceTypeList",
  async ({}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${LIST_SERVICE_TYPES}`);
      return response;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Fetch failed. Please try again later.",
      });
    }
  }
);

export const deleteService = createAsyncThunk(
    "data/deleteService",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_SERVICE}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);


export const addUpdateBookingService = createAsyncThunk(
  "data/addUpdateBookingService",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(ADD_UPDATE_BOOKING_SERVICE, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const fetchBookingServiceList = createAsyncThunk(
    "data/fetchBookingServiceList",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_BOOKING_SERVICE, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const getBookingServiceList = createAsyncThunk(
    "data/getBookingServiceList",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_BOOKING_SERVICE}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const deleteBookingService = createAsyncThunk(
    "data/deleteBookingService",
  async ({uuid}, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_BOOKING_SERVICE}/${uuid}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Customer save failed. Please try again later.",
      });
    }
  }
);

export const updateBookingServiceRequest = createAsyncThunk(
    "data/updateBookingServiceRequest",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(UPDATE_SERVICE_REQUEST_STATUS, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Service Request fetch failed. Please try again later.",
      });
    }
  }
);

export const addUpdateBanner = createAsyncThunk(
  "data/addUpdateBanner",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(ADD_UPDATE_BANNER, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Banner save failed. Please try again later.",
      });
    }
  }
);

export const fetchBannerList = createAsyncThunk(
    "data/fetchBannerList",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_BANNERS, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Banner Fetch failed. Please try again later.",
      });
    }
  }
);

export const getBanner = createAsyncThunk(
    "data/getBookingServiceList",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_BANNER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Banner fetch failed. Please try again later.",
      });
    }
  }
);

export const deleteBanner = createAsyncThunk(
    "data/deleteBookingService",
  async ({id}, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_BANNER}/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Banner delete failed. Please try again later.",
      });
    }
  }
);

export const addUpdateOffer = createAsyncThunk(
  "data/addUpdateOffer",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POSTDATA(ADD_UPDATE_OFFER, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Offers save failed. Please try again later.",
      });
    }
  }
);

export const fetchOffers = createAsyncThunk(
    "data/fetchOffers",
  async (formData, { rejectWithValue }) => {
    try {
      const response = await Api.POST(LIST_OFFERS, formData);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Offers Fetch failed. Please try again later.",
      });
    }
  }
);

export const getOffers = createAsyncThunk(
    "data/getOffers",
  async ({uuid}, { rejectWithValue }) => {
    try {
      const response = await Api.GET(`${GET_OFFER}/${uuid}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Offers fetch failed. Please try again later.",
      });
    }
  }
);

export const deleteOffers = createAsyncThunk(
    "data/deleteOffers",
  async ({uuid}, { rejectWithValue }) => {
    try {
      const response = await Api.DELETE(`${DELETE_OFFER}/${uuid}`);
      return response.data;
    } catch (error) {
      return rejectWithValue({
        message:
          error.response?.data?.message ||
          "Offers delete failed. Please try again later.",
      });
    }
  }
);

// Create a slice
const dataSlice = createSlice({
  name: "data",
  initialState: {
    roles: [],
    adminUsers : [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch Role Data
      .addCase(fetchRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })
      .addCase(fetchRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Create Role Data
      .addCase(saveRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(saveRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(saveRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Details Role Data
      .addCase(deatilsRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deatilsRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })
      .addCase(deatilsRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Role Permissions
      .addCase(fetchRolePermissions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRolePermissions.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(fetchRolePermissions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Role Data
      .addCase(updateRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })
      .addCase(updateRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Delete Role Data
      .addCase(deleteRoleData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteRoleData.fulfilled, (state, action) => {
        state.loading = false;
        state.roles = action.payload;
      })
      .addCase(deleteRoleData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Fetch Menu Permissions
      .addCase(fetchMenuPermissions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMenuPermissions.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(fetchMenuPermissions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
      // Update Role Permissions
      .addCase(updateRolePermissions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateRolePermissions.fulfilled, (state, action) => {
        state.loading = false;
        state.role = action.payload;
      })
      .addCase(updateRolePermissions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || action.error.message;
      })
  },
});

// Export the reducer
export default dataSlice.reducer;
