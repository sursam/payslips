// src/app/redux/store.js
import { configureStore } from '@reduxjs/toolkit';
import authReducer from "./features/authSlice";
import loadingReducer from "./features/loadingSlice";
import dataReducer from "./features/dataSlice";
import { createLogger } from 'redux-logger';

// Create a logger middleware
const logger = createLogger();

export const store = configureStore({
  reducer: {
    auth: authReducer,
    loading: loadingReducer,
    dataReducer: dataReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger)
});

// 1. Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;

// 2. Export the AppDispatch type
export type AppDispatch = typeof store.dispatch;