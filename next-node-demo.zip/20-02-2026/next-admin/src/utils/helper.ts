// import { useSelector } from 'react-redux';
import { jwtDecode } from 'jwt-decode';
// import { useSession } from "next-auth/react";
// export const getAccessToken = () => {
//   const accessToken = useSelector((state:any) => state.auth?.session?.accessToken);
//   return accessToken;
// };
export const can = (accessPermissions = [], accessToken = '') => {
  // const { data: session }:any = useSession();
  // const accessToken = session?.accessToken;
  // if(!accessToken){
  //   accessToken = useSelector((state:any) => state.auth?.session?.accessToken);
  // }  
  const userInfo: any = accessToken ? jwtDecode(accessToken) : null;
  // console.log('userInfo', userInfo)
  const permissions = userInfo && userInfo.permissions ? userInfo.permissions : [];

  return (userInfo?.roleSlug == "super-admin" || (permissions.length && permissions.filter(x => accessPermissions.includes(x)).length));
}