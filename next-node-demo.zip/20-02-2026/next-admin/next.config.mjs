import path from 'path';

/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["127.0.0.1", "localhost"],
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  assetPrefix: "",
  webpack: (config) => {
    config.resolve.alias['@'] = path.resolve(new URL('.', import.meta.url).pathname, 'src'); // Change 'src' if your folder is different
    return config;
  },
  turbopack: {}
};

export default nextConfig;