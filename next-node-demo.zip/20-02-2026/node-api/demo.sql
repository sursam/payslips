-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 20, 2026 at 03:58 AM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` int DEFAULT NULL COMMENT '1 = admin, 2 = mobile, 3 = front-end',
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aboutMe` text COLLATE utf8mb4_unicode_ci,
  `profileImage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resend` tinyint(1) DEFAULT '0',
  `device_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` int DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `webLogin` text COLLATE utf8mb4_unicode_ci,
  `appLogin` text COLLATE utf8mb4_unicode_ci,
  `isVerified` tinyint(1) DEFAULT '0',
  `status` int NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `roleId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roleId` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentId` int DEFAULT NULL,
  `groupId` int DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0 => in-active, 1 => active',
  `order` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `seedingCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parentId` (`parentId`),
  KEY `groupId` (`groupId`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `uuid`, `name`, `slug`, `parentId`, `groupId`, `icon`, `link`, `status`, `order`, `created_at`, `updated_at`, `deleted_at`, `seedingCode`) VALUES
(1, '932f7951-071f-45a8-bb5c-178e652742e7', 'Orders Management', 'orders-management', NULL, 3, 'shopping_cart', NULL, 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(2, '01725ed7-bfd7-4c1c-abc7-89bc45824efe', 'Inventory / Stock Control', 'inventory-stock-control', NULL, 3, 'inventory', NULL, 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(3, '5909345d-3411-4efb-992c-af94dcd31130', 'Customers', 'customers', NULL, 3, 'group', NULL, 1, 4, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(4, '0860a50a-531b-4b14-a113-8569e42d91e4', 'Marketing & Promotions', 'marketing-promotions', NULL, 3, 'shoppingmode', NULL, 1, 5, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(5, 'd1ba91bb-68a7-4243-8d84-b67e4dbfd9df', 'Payments & Transactions', 'payments-transactions', NULL, 3, 'payments', NULL, 1, 6, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(6, '9cf08216-4b38-4e75-b956-6dafb16d305d', 'Reports & Analytics', 'reports-analytics', NULL, 3, 'analytics', NULL, 1, 7, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(7, 'fdb7c679-1cd8-4700-9944-34e43d2fbbff', 'Admin Users', 'admin-users', NULL, 4, 'group', '/modules/admin-users/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(8, '57a11968-dbbd-4cd1-81a4-796ba98934de', 'Settings', 'settings', NULL, 2, 'settings', NULL, 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(9, 'ac5ee94d-9e45-4e6d-808d-6ac0391c70fc', 'Dashboard', 'dashboard', NULL, 1, 'dashboard', '/dashboard/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(10, 'fd8127de-d633-494c-bcef-d7e267f1a821', 'Products', 'products', NULL, 3, 'inventory_2', NULL, 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(11, '4243ba7b-de01-42eb-8734-9d890ccf31bf', 'Payment Gateway Settings', 'payment-gateway-settings', 5, 3, NULL, '/ecommerce/payment-settings/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(12, '7f7ac061-9f5e-4fac-86e0-33ebb58a0eb5', 'Transaction Logs', 'transaction-logs', 5, 3, NULL, '/ecommerce/transaction-logs/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(13, '5ec190a1-87b2-49e9-ba35-dca55e922297', 'Stock Levels', 'stock-levels', 2, 3, NULL, '/ecommerce/stock-levels/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(14, 'e5462b34-5fbf-420a-a8b4-30e6b0ce18fe', 'Stock Adjustment', 'stock-adjustment', 2, 3, NULL, '/ecommerce/stock-adjustment/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(15, '86688e89-ff99-4064-b9a4-1c8351c6d770', 'Warehouse / Locations', 'warehouse-locations', 2, 3, NULL, '/ecommerce/locations/', 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(16, '328755d5-3616-418b-9de6-d0e8a47200bc', 'Out-Of-Stock Alerts', 'out-of-stock-alerts', 2, 3, NULL, '/ecommerce/stock-alerts/', 1, 4, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(17, '0b1669aa-4c03-4ed9-ae24-3e76a089fcb5', 'All Customers', 'all-customers', 3, 3, NULL, '/ecommerce/customers/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(18, '99716035-4d20-413e-a1b1-d9167163425b', 'Wishlist & Saved Items Tracking', 'wishlist-saved-items-tracking', 3, 3, NULL, '/ecommerce/wishlists/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(19, '447fa141-9e1c-4bcd-a6a4-5eeb4a8c9864', 'Offers', 'offers', 4, 3, NULL, '/ecommerce/offers/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(20, '0fea0fb2-3c18-4067-a109-a5692dae3b26', 'Banners & Sliders', 'banners-sliders', 4, 3, NULL, '/ecommerce/banners/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(21, '3d7d0d90-7bcd-44d8-8f3f-755636509d15', 'Email Marketing', 'email-marketing', 4, 3, NULL, '/ecommerce/email-marketing/', 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(22, '7567d1ba-732b-45ef-97d5-79c9ae6feef8', 'All Orders', 'all-orders', 1, 3, NULL, '/ecommerce/orders/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(23, '022456e5-328b-40df-80cb-a56d1f1405fb', 'Order Invoices & Packing Slips', 'order-invoices-packing-slips', 1, 3, NULL, '/ecommerce/order-invoices/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(24, '237ab2a5-3c65-481a-a48f-3db971a356f1', 'Sales Report', 'sales-report', 6, 3, NULL, '/ecommerce/reports/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(25, 'cdf23834-d7e5-46e0-b55e-671bf19c6eac', 'Inventory Report', 'inventory-report', 6, 3, NULL, '/ecommerce/inventory-reports/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(26, 'ac7430b7-ac57-497d-a9e5-e1ec15c861f6', 'Customer Report', 'customer-report', 6, 3, NULL, '/ecommerce/customer-reports/', 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(27, 'aa848f54-8f6d-4474-9317-dfc37e45c2dd', 'Customer Orders', 'customer-orders', 6, 3, NULL, '/ecommerce/customer-orders/', 1, 4, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(28, 'df0cd908-4b59-463e-9465-8bc5941beafd', 'Products Catalog', 'products-catalog', 10, 3, NULL, '/ecommerce/products-list/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(29, 'd3ec4cab-403e-4b86-ba2c-d9d921c7807f', 'Products Categories', 'products-categories', 10, 3, NULL, '/ecommerce/categories/', 1, 2, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(30, 'ba80c50a-da90-4dfd-b970-212d487a644c', 'Brands / Manufacturers', 'brands-manufacturers', 10, 3, NULL, '/ecommerce/brands-manufacturers/', 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(31, 'eadf1745-45e7-494b-a46f-63da7f2f13f1', 'Product Attributes', 'product-attributes', 10, 3, NULL, '/ecommerce/product-attributes/', 1, 4, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(32, 'a5d2d2e4-7549-454a-97f5-c2f151eaa2a7', 'Discount Coupons', 'discount-coupons', 10, 3, NULL, '/ecommerce/coupons/', 1, 5, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(33, '374605af-c862-4a11-b644-fc638b4da04e', 'Reviews & Ratings', 'reviews-ratings', 10, 3, NULL, '/ecommerce/reviews/', 1, 6, '2026-02-18 05:27:27', '2026-02-18 06:21:23', NULL, 'Yorbx-1771395683722'),
(34, '53caedc1-c278-4f5c-ab7d-40a57aae4f9b', 'General Settings', 'general-settings', 8, 2, NULL, '/settings/account-settings/', 1, 1, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722'),
(36, '2b288e42-fe48-4ba0-b5cb-fdb969b8417a', 'Roles & Permissions', 'roles-permissions', 8, 2, NULL, '/settings/role/list/', 1, 3, '2026-02-18 05:27:27', '2026-02-18 06:21:24', NULL, 'Yorbx-1771395683722');

-- --------------------------------------------------------

--
-- Table structure for table `menu_groups`
--

DROP TABLE IF EXISTS `menu_groups`;
CREATE TABLE IF NOT EXISTS `menu_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0 => in-active, 1 => active',
  `order` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_groups`
--

INSERT INTO `menu_groups` (`id`, `uuid`, `name`, `slug`, `status`, `order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '802160be-2b13-4c08-b10f-85d0f270afc3', 'Main', 'main', 1, 1, '2026-02-13 05:14:28', '2026-02-18 04:25:08', NULL),
(2, 'f96ecffa-454b-48e2-9cc1-ed746fa17521', 'Settings', 'settings', 1, 4, '2026-02-13 05:14:28', '2026-02-13 05:14:28', NULL),
(3, 'cace1db3-c8c0-4fe4-a017-4dd774f565a4', 'Ecommerce', 'ecommerce', 1, 2, '2026-02-13 05:14:28', '2026-02-13 05:14:28', NULL),
(4, '51304700-53e7-4020-a23d-bb47d3887898', 'Modules', 'modules', 1, 3, '2026-02-13 05:14:28', '2026-02-13 05:14:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

DROP TABLE IF EXISTS `otps`;
CREATE TABLE IF NOT EXISTS `otps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` int DEFAULT NULL COMMENT '1 = admin, 2 = mobile, 3 = front-end',
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_signed_up` tinyint(1) NOT NULL DEFAULT '0',
  `expire_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `menuId` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menuId` (`menuId`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `menuId`, `name`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 7, 'Add', 'add-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(2, 7, 'Edit', 'edit-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(3, 7, 'Delete', 'delete-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(4, 7, 'Export', 'export-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(5, 7, 'Import', 'import-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(6, 9, 'View', 'view-dashboard', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(7, 11, 'View', 'view-payment-gateway-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(8, 11, 'Add', 'add-payment-gateway-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(9, 11, 'Edit', 'edit-payment-gateway-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(10, 11, 'Delete', 'delete-payment-gateway-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(11, 13, 'View', 'view-stock-levels', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(12, 7, 'View', 'view-admin-users', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(13, 13, 'Add', 'add-stock-levels', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(14, 13, 'Edit', 'edit-stock-levels', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(15, 13, 'Delete', 'delete-stock-levels', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(16, 15, 'View', 'view-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(17, 15, 'Add', 'add-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(18, 15, 'Edit', 'edit-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(19, 15, 'Delete', 'delete-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(20, 15, 'Export', 'export-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(21, 15, 'Import', 'import-warehouse-locations', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(22, 12, 'View', 'view-transaction-logs', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(23, 12, 'Add', 'add-transaction-logs', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(24, 12, 'Edit', 'edit-transaction-logs', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(25, 12, 'Delete', 'delete-transaction-logs', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(26, 12, 'Export', 'export-transaction-logs', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(27, 14, 'View', 'view-stock-adjustment', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(28, 14, 'Add', 'add-stock-adjustment', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(29, 14, 'Edit', 'edit-stock-adjustment', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(30, 14, 'Delete', 'delete-stock-adjustment', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(31, 16, 'View', 'view-out-of-stock-alerts', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(32, 16, 'Add', 'add-out-of-stock-alerts', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(33, 16, 'Edit', 'edit-out-of-stock-alerts', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(34, 16, 'Delete', 'delete-out-of-stock-alerts', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(35, 18, 'View', 'view-wishlist-saved-items-tracking', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(36, 18, 'Add', 'add-wishlist-saved-items-tracking', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(37, 18, 'Edit', 'edit-wishlist-saved-items-tracking', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(38, 18, 'Delete', 'delete-wishlist-saved-items-tracking', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(39, 20, 'View', 'view-banners-sliders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(40, 20, 'Add', 'add-banners-sliders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(41, 20, 'Edit', 'edit-banners-sliders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(42, 20, 'Delete', 'delete-banners-sliders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(43, 19, 'View', 'view-offers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(44, 19, 'Add', 'add-offers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(45, 19, 'Edit', 'edit-offers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(46, 19, 'Delete', 'delete-offers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(47, 17, 'View', 'view-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(48, 17, 'Add', 'add-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(49, 17, 'Edit', 'edit-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(50, 17, 'Delete', 'delete-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(51, 17, 'Export', 'export-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(52, 17, 'Import', 'import-all-customers', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(53, 21, 'View', 'view-email-marketing', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(54, 21, 'Add', 'add-email-marketing', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(55, 21, 'Edit', 'edit-email-marketing', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(56, 21, 'Delete', 'delete-email-marketing', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(57, 25, 'View', 'view-inventory-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(58, 25, 'Add', 'add-inventory-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(59, 25, 'Edit', 'edit-inventory-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(60, 25, 'Delete', 'delete-inventory-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(61, 25, 'Export', 'export-inventory-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(62, 23, 'View', 'view-order-invoices-packing-slips', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(63, 23, 'Add', 'add-order-invoices-packing-slips', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(64, 23, 'Edit', 'edit-order-invoices-packing-slips', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(65, 23, 'Delete', 'delete-order-invoices-packing-slips', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(66, 23, 'Export', 'export-order-invoices-packing-slips', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(67, 24, 'View', 'view-sales-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(68, 24, 'Add', 'add-sales-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(69, 24, 'Edit', 'edit-sales-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(70, 24, 'Delete', 'delete-sales-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(71, 24, 'Export', 'export-sales-report', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(72, 22, 'View', 'view-all-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(73, 22, 'Add', 'add-all-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(74, 22, 'Edit', 'edit-all-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(75, 22, 'Delete', 'delete-all-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(76, 22, 'Export', 'export-all-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:27', NULL),
(77, 26, 'View', 'view-customer-report', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(78, 26, 'Edit', 'edit-customer-report', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(79, 26, 'Delete', 'delete-customer-report', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(80, 26, 'Export', 'export-customer-report', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(81, 26, 'Add', 'add-customer-report', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(82, 27, 'View', 'view-customer-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(83, 27, 'Add', 'add-customer-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(84, 27, 'Edit', 'edit-customer-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(85, 27, 'Delete', 'delete-customer-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(86, 27, 'Export', 'export-customer-orders', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(87, 28, 'View', 'view-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(88, 28, 'Add', 'add-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(89, 28, 'Edit', 'edit-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(90, 28, 'Delete', 'delete-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(91, 28, 'Export', 'export-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(92, 28, 'Import', 'import-products-catalog', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(93, 29, 'View', 'view-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(94, 29, 'Add', 'add-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(95, 29, 'Edit', 'edit-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(96, 29, 'Delete', 'delete-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(97, 29, 'Export', 'export-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(98, 29, 'Import', 'import-products-categories', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(99, 30, 'View', 'view-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(100, 30, 'Add', 'add-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(101, 30, 'Edit', 'edit-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(102, 30, 'Delete', 'delete-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(103, 30, 'Export', 'export-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(104, 30, 'Import', 'import-brands-manufacturers', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(105, 31, 'View', 'view-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(106, 31, 'Add', 'add-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(107, 31, 'Edit', 'edit-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(108, 31, 'Delete', 'delete-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(109, 31, 'Export', 'export-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(110, 31, 'Import', 'import-product-attributes', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(111, 32, 'View', 'view-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(112, 32, 'Add', 'add-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(113, 32, 'Edit', 'edit-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(114, 32, 'Delete', 'delete-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(115, 32, 'Export', 'export-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(116, 33, 'Delete', 'delete-reviews-ratings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(117, 36, 'View', 'view-roles-permissions', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(118, 36, 'Add', 'add-roles-permissions', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(119, 36, 'Edit', 'edit-roles-permissions', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(120, 36, 'Delete', 'delete-roles-permissions', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(121, 34, 'View', 'view-general-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(122, 34, 'Add', 'add-general-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(123, 34, 'Edit', 'edit-general-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(124, 32, 'Import', 'import-discount-coupons', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(125, 33, 'View', 'view-reviews-ratings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(126, 33, 'Add', 'add-reviews-ratings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(127, 33, 'Edit', 'edit-reviews-ratings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL),
(128, 34, 'Delete', 'delete-general-settings', '2026-02-18 05:27:27', '2026-02-18 05:27:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `roleName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleSlug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0 => in-active, 1 => active',
  `order` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roleName`, `roleSlug`, `status`, `order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super Admin', 'super-admin', 1, 0, '2025-11-19 10:10:05', '2025-11-19 10:10:05', NULL),
(2, 'Admin', 'admin', 1, 0, '2026-02-13 05:32:43', '2026-02-13 05:44:23', NULL),
(3, 'Manager', 'manager', 1, 0, '2026-02-13 05:32:56', '2026-02-13 05:32:56', NULL),
(4, 'Staff', 'staff', 1, 0, '2026-02-18 06:32:29', '2026-02-18 06:32:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles_permissions`
--

DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE IF NOT EXISTS `roles_permissions` (
  `roleId` int NOT NULL,
  `permissionId` int NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`),
  UNIQUE KEY `roles_permissions_permissionId_roleId_unique` (`roleId`,`permissionId`),
  KEY `permissionId` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles_permissions`
--

INSERT INTO `roles_permissions` (`roleId`, `permissionId`) VALUES
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(3, 4),
(2, 5),
(2, 6),
(3, 6),
(4, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 11),
(3, 11),
(2, 12),
(3, 12),
(2, 13),
(3, 13),
(2, 14),
(3, 14),
(2, 15),
(3, 15),
(2, 16),
(3, 16),
(2, 17),
(3, 17),
(2, 18),
(3, 18),
(2, 19),
(3, 19),
(2, 20),
(3, 20),
(2, 21),
(3, 21),
(2, 22),
(3, 22),
(2, 23),
(2, 24),
(2, 25),
(2, 26),
(3, 26),
(2, 27),
(3, 27),
(2, 28),
(3, 28),
(2, 29),
(3, 29),
(2, 30),
(3, 30),
(2, 31),
(3, 31),
(2, 32),
(3, 32),
(2, 33),
(3, 33),
(2, 34),
(3, 34),
(2, 35),
(3, 35),
(2, 36),
(3, 36),
(2, 37),
(3, 37),
(2, 38),
(3, 38),
(2, 39),
(3, 39),
(2, 40),
(2, 41),
(2, 42),
(2, 43),
(3, 43),
(4, 43),
(2, 44),
(3, 44),
(2, 45),
(3, 45),
(2, 46),
(3, 46),
(2, 47),
(3, 47),
(4, 47),
(2, 48),
(3, 48),
(2, 49),
(3, 49),
(2, 50),
(3, 50),
(2, 51),
(3, 51),
(2, 52),
(3, 52),
(2, 53),
(3, 53),
(2, 54),
(3, 54),
(2, 55),
(3, 55),
(2, 56),
(3, 56),
(2, 57),
(3, 57),
(2, 58),
(3, 58),
(2, 59),
(3, 59),
(2, 60),
(3, 60),
(2, 61),
(3, 61),
(2, 62),
(3, 62),
(4, 62),
(2, 63),
(3, 63),
(2, 64),
(3, 64),
(2, 65),
(3, 65),
(2, 66),
(3, 66),
(2, 67),
(3, 67),
(2, 68),
(3, 68),
(2, 69),
(3, 69),
(2, 70),
(3, 70),
(2, 71),
(3, 71),
(2, 72),
(3, 72),
(4, 72),
(2, 73),
(3, 73),
(2, 74),
(3, 74),
(2, 75),
(3, 75),
(2, 76),
(3, 76),
(2, 77),
(3, 77),
(2, 78),
(3, 78),
(2, 79),
(3, 79),
(2, 80),
(3, 80),
(2, 81),
(3, 81),
(2, 82),
(3, 82),
(2, 83),
(3, 83),
(2, 84),
(3, 84),
(2, 85),
(3, 85),
(2, 86),
(3, 86),
(2, 87),
(3, 87),
(2, 88),
(2, 89),
(2, 90),
(2, 91),
(3, 91),
(2, 92),
(2, 93),
(3, 93),
(2, 94),
(2, 95),
(2, 96),
(2, 97),
(3, 97),
(2, 98),
(2, 99),
(3, 99),
(2, 100),
(2, 101),
(2, 102),
(2, 103),
(3, 103),
(2, 104),
(2, 105),
(3, 105),
(2, 106),
(2, 107),
(2, 108),
(2, 109),
(3, 109),
(2, 110),
(2, 111),
(3, 111),
(4, 111),
(2, 112),
(3, 112),
(2, 113),
(3, 113),
(2, 114),
(2, 115),
(3, 115),
(2, 116),
(2, 117),
(2, 118),
(2, 119),
(2, 120),
(2, 121),
(3, 121),
(2, 122),
(3, 122),
(2, 123),
(3, 123),
(2, 124),
(2, 125),
(3, 125),
(4, 125),
(2, 126),
(3, 126),
(4, 126),
(2, 127),
(3, 127),
(4, 127),
(2, 128);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `sid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` int DEFAULT NULL COMMENT '1 = admin, 2 = mobile, 3 = front-end',
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aboutMe` text COLLATE utf8mb4_unicode_ci,
  `profileImage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resend` tinyint(1) DEFAULT '0',
  `device_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` int DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `webLogin` text COLLATE utf8mb4_unicode_ci,
  `appLogin` text COLLATE utf8mb4_unicode_ci,
  `isVerified` tinyint(1) DEFAULT '0',
  `status` int NOT NULL DEFAULT '1',
  `needToLogout` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `roleId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roleId` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email_id`, `phone_number`, `password`, `device_type`, `country_code`, `address`, `city`, `postal_code`, `country`, `aboutMe`, `profileImage`, `resend`, `device_token`, `otp`, `uuid`, `webLogin`, `appLogin`, `isVerified`, `status`, `needToLogout`, `created_at`, `updated_at`, `deleted_at`, `roleId`) VALUES
(1, 'Super Admin', 'super.admin@eclicksoftwares.in', '9876543210', '$2a$10$L9RztYkpdJBgMycXQ6rrpulidZWQxP2e2VY7HrZVQA58j0H0dsUJ2', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', 7358, '87d03878-c539-11f0-b5b1-f80dac469d6f', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXVpZCI6Ijg3ZDAzODc4LWM1MzktMTFmMC1iNWIxLWY4MGRhYzQ2OWQ2ZiIsIm5hbWUiOiJTdXBlciBBZG1pbiIsImVtYWlsIjoic3VwZXIuYWRtaW5AZWNsaWNrc29mdHdhcmVzLmluIiwiZGV2aWNlVHlwZSI6IjEiLCJpc1ZlcmlmaWVkIjp0cnVlLCJyb2xlSWQiOjEsInJvbGVTbHVnIjoic3VwZXItYWRtaW4iLCJyb2xlTmFtZSI6IlN1cGVyIEFkbWluIiwicGVybWlzc2lvbnMiOltdLCJtZW51cyI6eyIvbW9kdWxlcy9hZG1pbi11c2Vycy8iOiJhZG1pbi11c2VycyIsIi9kYXNoYm9hcmQvIjoiZGFzaGJvYXJkIiwiL2Vjb21tZXJjZS9wYXltZW50LXNldHRpbmdzLyI6InBheW1lbnQtZ2F0ZXdheS1zZXR0aW5ncyIsIi9lY29tbWVyY2UvdHJhbnNhY3Rpb24tbG9ncy8iOiJ0cmFuc2FjdGlvbi1sb2dzIiwiL2Vjb21tZXJjZS9zdG9jay1sZXZlbHMvIjoic3RvY2stbGV2ZWxzIiwiL2Vjb21tZXJjZS9zdG9jay1hZGp1c3RtZW50LyI6InN0b2NrLWFkanVzdG1lbnQiLCIvZWNvbW1lcmNlL2xvY2F0aW9ucy8iOiJ3YXJlaG91c2UtbG9jYXRpb25zIiwiL2Vjb21tZXJjZS9zdG9jay1hbGVydHMvIjoib3V0LW9mLXN0b2NrLWFsZXJ0cyIsIi9lY29tbWVyY2UvY3VzdG9tZXJzLyI6ImFsbC1jdXN0b21lcnMiLCIvZWNvbW1lcmNlL3dpc2hsaXN0cy8iOiJ3aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsIi9lY29tbWVyY2Uvb2ZmZXJzLyI6Im9mZmVycyIsIi9lY29tbWVyY2UvYmFubmVycy8iOiJiYW5uZXJzLXNsaWRlcnMiLCIvZWNvbW1lcmNlL2VtYWlsLW1hcmtldGluZy8iOiJlbWFpbC1tYXJrZXRpbmciLCIvZWNvbW1lcmNlL29yZGVycy8iOiJhbGwtb3JkZXJzIiwiL2Vjb21tZXJjZS9vcmRlci1pbnZvaWNlcy8iOiJvcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwiL2Vjb21tZXJjZS9yZXBvcnRzLyI6InNhbGVzLXJlcG9ydCIsIi9lY29tbWVyY2UvaW52ZW50b3J5LXJlcG9ydHMvIjoiaW52ZW50b3J5LXJlcG9ydCIsIi9lY29tbWVyY2UvY3VzdG9tZXItcmVwb3J0cy8iOiJjdXN0b21lci1yZXBvcnQiLCIvZWNvbW1lcmNlL2N1c3RvbWVyLW9yZGVycy8iOiJjdXN0b21lci1vcmRlcnMiLCIvZWNvbW1lcmNlL3Byb2R1Y3RzLWxpc3QvIjoicHJvZHVjdHMtY2F0YWxvZyIsIi9lY29tbWVyY2UvY2F0ZWdvcmllcy8iOiJwcm9kdWN0cy1jYXRlZ29yaWVzIiwiL2Vjb21tZXJjZS9icmFuZHMtbWFudWZhY3R1cmVycy8iOiJicmFuZHMtbWFudWZhY3R1cmVycyIsIi9lY29tbWVyY2UvcHJvZHVjdC1hdHRyaWJ1dGVzLyI6InByb2R1Y3QtYXR0cmlidXRlcyIsIi9lY29tbWVyY2UvY291cG9ucy8iOiJkaXNjb3VudC1jb3Vwb25zIiwiL2Vjb21tZXJjZS9yZXZpZXdzLyI6InJldmlld3MtcmF0aW5ncyIsIi9zZXR0aW5ncy9hY2NvdW50LXNldHRpbmdzLyI6ImdlbmVyYWwtc2V0dGluZ3MiLCIvc2V0dGluZ3Mvcm9sZS9saXN0LyI6InJvbGVzLXBlcm1pc3Npb25zIn0sImlhdCI6MTc3MTQ4MjY2NSwiZXhwIjoxNzc0MDc0NjY1fQ.aDYxwwW6brnmb4Q8JTCYj7H634o1MC6etdLjfKlxff0', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXVpZCI6Ijg3ZDAzODc4LWM1MzktMTFmMC1iNWIxLWY4MGRhYzQ2OWQ2ZiIsIm5hbWUiOiJTdXBlciBBZG1pbiIsImVtYWlsIjoic3VwZXIuYWRtaW5AcGV0bGFuZC5jb20iLCJpc1ZlcmlmaWVkIjp0cnVlLCJpYXQiOjE3NjM1NTExNDMsImV4cCI6MTc2NjE0MzE0M30.HrBx9OLpTv33sCgsA1Z04hRzIHkV84IBTMvRfNnqbY4', 1, 1, 0, NULL, '2026-02-19 06:31:05', NULL, 1),
(2, 'Suraj Samanta', 'suraj@eclicksoftwares.in', '7319196062', '$2b$10$I28/0CtRHdKG6PLewYrGn.3yPjyRmNy8gBNdxV6PYbO/jEW14UzYG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1042, '459f7ca5-24b7-40f0-83ef-f1c12e5b66ac', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwidXVpZCI6IjQ1OWY3Y2E1LTI0YjctNDBmMC04M2VmLWYxYzEyZTViNjZhYyIsIm5hbWUiOiJTdXJhaiBTYW1hbnRhIiwiZW1haWwiOiJzdXJhakBlY2xpY2tzb2Z0d2FyZXMuaW4iLCJkZXZpY2VUeXBlIjoiMSIsImlzVmVyaWZpZWQiOmZhbHNlLCJyb2xlSWQiOjIsInJvbGVTbHVnIjoiYWRtaW4iLCJyb2xlTmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsiYWRkLWFkbWluLXVzZXJzIiwiZWRpdC1hZG1pbi11c2VycyIsImRlbGV0ZS1hZG1pbi11c2VycyIsImV4cG9ydC1hZG1pbi11c2VycyIsImltcG9ydC1hZG1pbi11c2VycyIsInZpZXctZGFzaGJvYXJkIiwidmlldy1wYXltZW50LWdhdGV3YXktc2V0dGluZ3MiLCJhZGQtcGF5bWVudC1nYXRld2F5LXNldHRpbmdzIiwiZWRpdC1wYXltZW50LWdhdGV3YXktc2V0dGluZ3MiLCJkZWxldGUtcGF5bWVudC1nYXRld2F5LXNldHRpbmdzIiwidmlldy1zdG9jay1sZXZlbHMiLCJ2aWV3LWFkbWluLXVzZXJzIiwiYWRkLXN0b2NrLWxldmVscyIsImVkaXQtc3RvY2stbGV2ZWxzIiwiZGVsZXRlLXN0b2NrLWxldmVscyIsInZpZXctd2FyZWhvdXNlLWxvY2F0aW9ucyIsImFkZC13YXJlaG91c2UtbG9jYXRpb25zIiwiZWRpdC13YXJlaG91c2UtbG9jYXRpb25zIiwiZGVsZXRlLXdhcmVob3VzZS1sb2NhdGlvbnMiLCJleHBvcnQtd2FyZWhvdXNlLWxvY2F0aW9ucyIsImltcG9ydC13YXJlaG91c2UtbG9jYXRpb25zIiwidmlldy10cmFuc2FjdGlvbi1sb2dzIiwiYWRkLXRyYW5zYWN0aW9uLWxvZ3MiLCJlZGl0LXRyYW5zYWN0aW9uLWxvZ3MiLCJkZWxldGUtdHJhbnNhY3Rpb24tbG9ncyIsImV4cG9ydC10cmFuc2FjdGlvbi1sb2dzIiwidmlldy1zdG9jay1hZGp1c3RtZW50IiwiYWRkLXN0b2NrLWFkanVzdG1lbnQiLCJlZGl0LXN0b2NrLWFkanVzdG1lbnQiLCJkZWxldGUtc3RvY2stYWRqdXN0bWVudCIsInZpZXctb3V0LW9mLXN0b2NrLWFsZXJ0cyIsImFkZC1vdXQtb2Ytc3RvY2stYWxlcnRzIiwiZWRpdC1vdXQtb2Ytc3RvY2stYWxlcnRzIiwiZGVsZXRlLW91dC1vZi1zdG9jay1hbGVydHMiLCJ2aWV3LXdpc2hsaXN0LXNhdmVkLWl0ZW1zLXRyYWNraW5nIiwiYWRkLXdpc2hsaXN0LXNhdmVkLWl0ZW1zLXRyYWNraW5nIiwiZWRpdC13aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsImRlbGV0ZS13aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsInZpZXctYmFubmVycy1zbGlkZXJzIiwiYWRkLWJhbm5lcnMtc2xpZGVycyIsImVkaXQtYmFubmVycy1zbGlkZXJzIiwiZGVsZXRlLWJhbm5lcnMtc2xpZGVycyIsInZpZXctb2ZmZXJzIiwiYWRkLW9mZmVycyIsImVkaXQtb2ZmZXJzIiwiZGVsZXRlLW9mZmVycyIsInZpZXctYWxsLWN1c3RvbWVycyIsImFkZC1hbGwtY3VzdG9tZXJzIiwiZWRpdC1hbGwtY3VzdG9tZXJzIiwiZGVsZXRlLWFsbC1jdXN0b21lcnMiLCJleHBvcnQtYWxsLWN1c3RvbWVycyIsImltcG9ydC1hbGwtY3VzdG9tZXJzIiwidmlldy1lbWFpbC1tYXJrZXRpbmciLCJhZGQtZW1haWwtbWFya2V0aW5nIiwiZWRpdC1lbWFpbC1tYXJrZXRpbmciLCJkZWxldGUtZW1haWwtbWFya2V0aW5nIiwidmlldy1pbnZlbnRvcnktcmVwb3J0IiwiYWRkLWludmVudG9yeS1yZXBvcnQiLCJlZGl0LWludmVudG9yeS1yZXBvcnQiLCJkZWxldGUtaW52ZW50b3J5LXJlcG9ydCIsImV4cG9ydC1pbnZlbnRvcnktcmVwb3J0Iiwidmlldy1vcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwiYWRkLW9yZGVyLWludm9pY2VzLXBhY2tpbmctc2xpcHMiLCJlZGl0LW9yZGVyLWludm9pY2VzLXBhY2tpbmctc2xpcHMiLCJkZWxldGUtb3JkZXItaW52b2ljZXMtcGFja2luZy1zbGlwcyIsImV4cG9ydC1vcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwidmlldy1zYWxlcy1yZXBvcnQiLCJhZGQtc2FsZXMtcmVwb3J0IiwiZWRpdC1zYWxlcy1yZXBvcnQiLCJkZWxldGUtc2FsZXMtcmVwb3J0IiwiZXhwb3J0LXNhbGVzLXJlcG9ydCIsInZpZXctYWxsLW9yZGVycyIsImFkZC1hbGwtb3JkZXJzIiwiZWRpdC1hbGwtb3JkZXJzIiwiZGVsZXRlLWFsbC1vcmRlcnMiLCJleHBvcnQtYWxsLW9yZGVycyIsInZpZXctY3VzdG9tZXItcmVwb3J0IiwiZWRpdC1jdXN0b21lci1yZXBvcnQiLCJkZWxldGUtY3VzdG9tZXItcmVwb3J0IiwiZXhwb3J0LWN1c3RvbWVyLXJlcG9ydCIsImFkZC1jdXN0b21lci1yZXBvcnQiLCJ2aWV3LWN1c3RvbWVyLW9yZGVycyIsImFkZC1jdXN0b21lci1vcmRlcnMiLCJlZGl0LWN1c3RvbWVyLW9yZGVycyIsImRlbGV0ZS1jdXN0b21lci1vcmRlcnMiLCJleHBvcnQtY3VzdG9tZXItb3JkZXJzIiwidmlldy1wcm9kdWN0cy1jYXRhbG9nIiwiYWRkLXByb2R1Y3RzLWNhdGFsb2ciLCJlZGl0LXByb2R1Y3RzLWNhdGFsb2ciLCJkZWxldGUtcHJvZHVjdHMtY2F0YWxvZyIsImV4cG9ydC1wcm9kdWN0cy1jYXRhbG9nIiwiaW1wb3J0LXByb2R1Y3RzLWNhdGFsb2ciLCJ2aWV3LXByb2R1Y3RzLWNhdGVnb3JpZXMiLCJhZGQtcHJvZHVjdHMtY2F0ZWdvcmllcyIsImVkaXQtcHJvZHVjdHMtY2F0ZWdvcmllcyIsImRlbGV0ZS1wcm9kdWN0cy1jYXRlZ29yaWVzIiwiZXhwb3J0LXByb2R1Y3RzLWNhdGVnb3JpZXMiLCJpbXBvcnQtcHJvZHVjdHMtY2F0ZWdvcmllcyIsInZpZXctYnJhbmRzLW1hbnVmYWN0dXJlcnMiLCJhZGQtYnJhbmRzLW1hbnVmYWN0dXJlcnMiLCJlZGl0LWJyYW5kcy1tYW51ZmFjdHVyZXJzIiwiZGVsZXRlLWJyYW5kcy1tYW51ZmFjdHVyZXJzIiwiZXhwb3J0LWJyYW5kcy1tYW51ZmFjdHVyZXJzIiwiaW1wb3J0LWJyYW5kcy1tYW51ZmFjdHVyZXJzIiwidmlldy1wcm9kdWN0LWF0dHJpYnV0ZXMiLCJhZGQtcHJvZHVjdC1hdHRyaWJ1dGVzIiwiZWRpdC1wcm9kdWN0LWF0dHJpYnV0ZXMiLCJkZWxldGUtcHJvZHVjdC1hdHRyaWJ1dGVzIiwiZXhwb3J0LXByb2R1Y3QtYXR0cmlidXRlcyIsImltcG9ydC1wcm9kdWN0LWF0dHJpYnV0ZXMiLCJ2aWV3LWRpc2NvdW50LWNvdXBvbnMiLCJhZGQtZGlzY291bnQtY291cG9ucyIsImVkaXQtZGlzY291bnQtY291cG9ucyIsImRlbGV0ZS1kaXNjb3VudC1jb3Vwb25zIiwiZXhwb3J0LWRpc2NvdW50LWNvdXBvbnMiLCJkZWxldGUtcmV2aWV3cy1yYXRpbmdzIiwidmlldy1yb2xlcy1wZXJtaXNzaW9ucyIsImFkZC1yb2xlcy1wZXJtaXNzaW9ucyIsImVkaXQtcm9sZXMtcGVybWlzc2lvbnMiLCJkZWxldGUtcm9sZXMtcGVybWlzc2lvbnMiLCJ2aWV3LWdlbmVyYWwtc2V0dGluZ3MiLCJhZGQtZ2VuZXJhbC1zZXR0aW5ncyIsImVkaXQtZ2VuZXJhbC1zZXR0aW5ncyIsImltcG9ydC1kaXNjb3VudC1jb3Vwb25zIiwidmlldy1yZXZpZXdzLXJhdGluZ3MiLCJhZGQtcmV2aWV3cy1yYXRpbmdzIiwiZWRpdC1yZXZpZXdzLXJhdGluZ3MiLCJkZWxldGUtZ2VuZXJhbC1zZXR0aW5ncyJdLCJtZW51cyI6eyIvbW9kdWxlcy9hZG1pbi11c2Vycy8iOiJhZG1pbi11c2VycyIsIi9kYXNoYm9hcmQvIjoiZGFzaGJvYXJkIiwiL2Vjb21tZXJjZS9wYXltZW50LXNldHRpbmdzLyI6InBheW1lbnQtZ2F0ZXdheS1zZXR0aW5ncyIsIi9lY29tbWVyY2UvdHJhbnNhY3Rpb24tbG9ncy8iOiJ0cmFuc2FjdGlvbi1sb2dzIiwiL2Vjb21tZXJjZS9zdG9jay1sZXZlbHMvIjoic3RvY2stbGV2ZWxzIiwiL2Vjb21tZXJjZS9zdG9jay1hZGp1c3RtZW50LyI6InN0b2NrLWFkanVzdG1lbnQiLCIvZWNvbW1lcmNlL2xvY2F0aW9ucy8iOiJ3YXJlaG91c2UtbG9jYXRpb25zIiwiL2Vjb21tZXJjZS9zdG9jay1hbGVydHMvIjoib3V0LW9mLXN0b2NrLWFsZXJ0cyIsIi9lY29tbWVyY2UvY3VzdG9tZXJzLyI6ImFsbC1jdXN0b21lcnMiLCIvZWNvbW1lcmNlL3dpc2hsaXN0cy8iOiJ3aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsIi9lY29tbWVyY2Uvb2ZmZXJzLyI6Im9mZmVycyIsIi9lY29tbWVyY2UvYmFubmVycy8iOiJiYW5uZXJzLXNsaWRlcnMiLCIvZWNvbW1lcmNlL2VtYWlsLW1hcmtldGluZy8iOiJlbWFpbC1tYXJrZXRpbmciLCIvZWNvbW1lcmNlL29yZGVycy8iOiJhbGwtb3JkZXJzIiwiL2Vjb21tZXJjZS9vcmRlci1pbnZvaWNlcy8iOiJvcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwiL2Vjb21tZXJjZS9yZXBvcnRzLyI6InNhbGVzLXJlcG9ydCIsIi9lY29tbWVyY2UvaW52ZW50b3J5LXJlcG9ydHMvIjoiaW52ZW50b3J5LXJlcG9ydCIsIi9lY29tbWVyY2UvY3VzdG9tZXItcmVwb3J0cy8iOiJjdXN0b21lci1yZXBvcnQiLCIvZWNvbW1lcmNlL2N1c3RvbWVyLW9yZGVycy8iOiJjdXN0b21lci1vcmRlcnMiLCIvZWNvbW1lcmNlL3Byb2R1Y3RzLWxpc3QvIjoicHJvZHVjdHMtY2F0YWxvZyIsIi9lY29tbWVyY2UvY2F0ZWdvcmllcy8iOiJwcm9kdWN0cy1jYXRlZ29yaWVzIiwiL2Vjb21tZXJjZS9icmFuZHMtbWFudWZhY3R1cmVycy8iOiJicmFuZHMtbWFudWZhY3R1cmVycyIsIi9lY29tbWVyY2UvcHJvZHVjdC1hdHRyaWJ1dGVzLyI6InByb2R1Y3QtYXR0cmlidXRlcyIsIi9lY29tbWVyY2UvY291cG9ucy8iOiJkaXNjb3VudC1jb3Vwb25zIiwiL2Vjb21tZXJjZS9yZXZpZXdzLyI6InJldmlld3MtcmF0aW5ncyIsIi9zZXR0aW5ncy9hY2NvdW50LXNldHRpbmdzLyI6ImdlbmVyYWwtc2V0dGluZ3MiLCIvc2V0dGluZ3Mvcm9sZS9saXN0LyI6InJvbGVzLXBlcm1pc3Npb25zIn0sImlhdCI6MTc3MTQ3NjkyMywiZXhwIjoxNzc0MDY4OTIzfQ.71H-sS23fdppsHyMxPkehLacfeHPbuOatbc-PxzK7PU', NULL, 0, 0, 0, '2026-02-13 05:34:38', '2026-02-19 04:55:23', NULL, NULL),
(3, 'Krishnendu Kar', 'krishnendu@eclicksoftwares.com', '1234567890', '$2b$10$1E4Z0XiWG9zSraOSz/Wge.EfIGfI1uLrBJjzsaLM7x4.bhJp9BMHy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '11271ef4-2372-4978-babe-917564e685e7', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MywidXVpZCI6IjExMjcxZWY0LTIzNzItNDk3OC1iYWJlLTkxNzU2NGU2ODVlNyIsIm5hbWUiOiJLcmlzaG5lbmR1IEthciIsImVtYWlsIjoia3Jpc2huZW5kdUBlY2xpY2tzb2Z0d2FyZXMuY29tIiwiZGV2aWNlVHlwZSI6IjEiLCJpc1ZlcmlmaWVkIjpmYWxzZSwicm9sZUlkIjozLCJyb2xlU2x1ZyI6Im1hbmFnZXIiLCJwZXJtaXNzaW9ucyI6WyJleHBvcnQtYWRtaW4tdXNlcnMiLCJ2aWV3LWRhc2hib2FyZCIsInZpZXctc3RvY2stbGV2ZWxzIiwidmlldy1hZG1pbi11c2VycyIsImFkZC1zdG9jay1sZXZlbHMiLCJlZGl0LXN0b2NrLWxldmVscyIsImRlbGV0ZS1zdG9jay1sZXZlbHMiLCJ2aWV3LXdhcmVob3VzZS1sb2NhdGlvbnMiLCJhZGQtd2FyZWhvdXNlLWxvY2F0aW9ucyIsImVkaXQtd2FyZWhvdXNlLWxvY2F0aW9ucyIsImRlbGV0ZS13YXJlaG91c2UtbG9jYXRpb25zIiwiZXhwb3J0LXdhcmVob3VzZS1sb2NhdGlvbnMiLCJpbXBvcnQtd2FyZWhvdXNlLWxvY2F0aW9ucyIsInZpZXctdHJhbnNhY3Rpb24tbG9ncyIsImV4cG9ydC10cmFuc2FjdGlvbi1sb2dzIiwidmlldy1zdG9jay1hZGp1c3RtZW50IiwiYWRkLXN0b2NrLWFkanVzdG1lbnQiLCJlZGl0LXN0b2NrLWFkanVzdG1lbnQiLCJkZWxldGUtc3RvY2stYWRqdXN0bWVudCIsInZpZXctb3V0LW9mLXN0b2NrLWFsZXJ0cyIsImFkZC1vdXQtb2Ytc3RvY2stYWxlcnRzIiwiZWRpdC1vdXQtb2Ytc3RvY2stYWxlcnRzIiwiZGVsZXRlLW91dC1vZi1zdG9jay1hbGVydHMiLCJ2aWV3LXdpc2hsaXN0LXNhdmVkLWl0ZW1zLXRyYWNraW5nIiwiYWRkLXdpc2hsaXN0LXNhdmVkLWl0ZW1zLXRyYWNraW5nIiwiZWRpdC13aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsImRlbGV0ZS13aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsInZpZXctYmFubmVycy1zbGlkZXJzIiwidmlldy1vZmZlcnMiLCJhZGQtb2ZmZXJzIiwiZWRpdC1vZmZlcnMiLCJkZWxldGUtb2ZmZXJzIiwidmlldy1hbGwtY3VzdG9tZXJzIiwiYWRkLWFsbC1jdXN0b21lcnMiLCJlZGl0LWFsbC1jdXN0b21lcnMiLCJkZWxldGUtYWxsLWN1c3RvbWVycyIsImV4cG9ydC1hbGwtY3VzdG9tZXJzIiwiaW1wb3J0LWFsbC1jdXN0b21lcnMiLCJ2aWV3LWVtYWlsLW1hcmtldGluZyIsImFkZC1lbWFpbC1tYXJrZXRpbmciLCJlZGl0LWVtYWlsLW1hcmtldGluZyIsImRlbGV0ZS1lbWFpbC1tYXJrZXRpbmciLCJ2aWV3LWludmVudG9yeS1yZXBvcnQiLCJhZGQtaW52ZW50b3J5LXJlcG9ydCIsImVkaXQtaW52ZW50b3J5LXJlcG9ydCIsImRlbGV0ZS1pbnZlbnRvcnktcmVwb3J0IiwiZXhwb3J0LWludmVudG9yeS1yZXBvcnQiLCJ2aWV3LW9yZGVyLWludm9pY2VzLXBhY2tpbmctc2xpcHMiLCJhZGQtb3JkZXItaW52b2ljZXMtcGFja2luZy1zbGlwcyIsImVkaXQtb3JkZXItaW52b2ljZXMtcGFja2luZy1zbGlwcyIsImRlbGV0ZS1vcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwiZXhwb3J0LW9yZGVyLWludm9pY2VzLXBhY2tpbmctc2xpcHMiLCJ2aWV3LXNhbGVzLXJlcG9ydCIsImFkZC1zYWxlcy1yZXBvcnQiLCJlZGl0LXNhbGVzLXJlcG9ydCIsImRlbGV0ZS1zYWxlcy1yZXBvcnQiLCJleHBvcnQtc2FsZXMtcmVwb3J0Iiwidmlldy1hbGwtb3JkZXJzIiwiYWRkLWFsbC1vcmRlcnMiLCJlZGl0LWFsbC1vcmRlcnMiLCJkZWxldGUtYWxsLW9yZGVycyIsImV4cG9ydC1hbGwtb3JkZXJzIiwidmlldy1jdXN0b21lci1yZXBvcnQiLCJlZGl0LWN1c3RvbWVyLXJlcG9ydCIsImRlbGV0ZS1jdXN0b21lci1yZXBvcnQiLCJleHBvcnQtY3VzdG9tZXItcmVwb3J0IiwiYWRkLWN1c3RvbWVyLXJlcG9ydCIsInZpZXctY3VzdG9tZXItb3JkZXJzIiwiYWRkLWN1c3RvbWVyLW9yZGVycyIsImVkaXQtY3VzdG9tZXItb3JkZXJzIiwiZGVsZXRlLWN1c3RvbWVyLW9yZGVycyIsImV4cG9ydC1jdXN0b21lci1vcmRlcnMiLCJ2aWV3LXByb2R1Y3RzLWNhdGFsb2ciLCJleHBvcnQtcHJvZHVjdHMtY2F0YWxvZyIsInZpZXctcHJvZHVjdHMtY2F0ZWdvcmllcyIsImV4cG9ydC1wcm9kdWN0cy1jYXRlZ29yaWVzIiwidmlldy1icmFuZHMtbWFudWZhY3R1cmVycyIsImV4cG9ydC1icmFuZHMtbWFudWZhY3R1cmVycyIsInZpZXctcHJvZHVjdC1hdHRyaWJ1dGVzIiwiZXhwb3J0LXByb2R1Y3QtYXR0cmlidXRlcyIsInZpZXctZGlzY291bnQtY291cG9ucyIsImFkZC1kaXNjb3VudC1jb3Vwb25zIiwiZWRpdC1kaXNjb3VudC1jb3Vwb25zIiwiZXhwb3J0LWRpc2NvdW50LWNvdXBvbnMiLCJ2aWV3LWdlbmVyYWwtc2V0dGluZ3MiLCJhZGQtZ2VuZXJhbC1zZXR0aW5ncyIsImVkaXQtZ2VuZXJhbC1zZXR0aW5ncyIsInZpZXctcmV2aWV3cy1yYXRpbmdzIiwiYWRkLXJldmlld3MtcmF0aW5ncyIsImVkaXQtcmV2aWV3cy1yYXRpbmdzIl0sImlhdCI6MTc3MTM5ODkzNiwiZXhwIjoxNzczOTkwOTM2fQ.OoGnJhhf9EjCZyvgTJJxUVs-E9aWuRpXeX98pIozOec', NULL, 0, 0, 0, '2026-02-18 06:38:14', '2026-02-18 07:15:36', NULL, NULL),
(4, 'Tanmay Khanta', 'tanmay@eclicksoftwares.in', '9876543210', '$2b$10$OtXTEEq9pUkj9EVjaSqZ..711Ptepb5Ck0nxOfB.T2Tn/GP4mL6zO', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '31ebcff6-1bfe-451b-a600-f1d259eb881b', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwidXVpZCI6IjMxZWJjZmY2LTFiZmUtNDUxYi1hNjAwLWYxZDI1OWViODgxYiIsIm5hbWUiOiJUYW5tYXkgS2hhbnRhIiwiZW1haWwiOiJ0YW5tYXlAZWNsaWNrc29mdHdhcmVzLmluIiwiZGV2aWNlVHlwZSI6IjEiLCJpc1ZlcmlmaWVkIjpmYWxzZSwicm9sZUlkIjo0LCJyb2xlU2x1ZyI6InN0YWZmIiwicm9sZU5hbWUiOiJTdGFmZiIsInBlcm1pc3Npb25zIjpbInZpZXctZGFzaGJvYXJkIiwidmlldy1vZmZlcnMiLCJ2aWV3LWFsbC1jdXN0b21lcnMiLCJ2aWV3LW9yZGVyLWludm9pY2VzLXBhY2tpbmctc2xpcHMiLCJ2aWV3LWFsbC1vcmRlcnMiLCJ2aWV3LWRpc2NvdW50LWNvdXBvbnMiLCJ2aWV3LXJldmlld3MtcmF0aW5ncyIsImFkZC1yZXZpZXdzLXJhdGluZ3MiLCJlZGl0LXJldmlld3MtcmF0aW5ncyJdLCJtZW51cyI6eyIvbW9kdWxlcy9hZG1pbi11c2Vycy8iOiJhZG1pbi11c2VycyIsIi9kYXNoYm9hcmQvIjoiZGFzaGJvYXJkIiwiL2Vjb21tZXJjZS9wYXltZW50LXNldHRpbmdzLyI6InBheW1lbnQtZ2F0ZXdheS1zZXR0aW5ncyIsIi9lY29tbWVyY2UvdHJhbnNhY3Rpb24tbG9ncy8iOiJ0cmFuc2FjdGlvbi1sb2dzIiwiL2Vjb21tZXJjZS9zdG9jay1sZXZlbHMvIjoic3RvY2stbGV2ZWxzIiwiL2Vjb21tZXJjZS9zdG9jay1hZGp1c3RtZW50LyI6InN0b2NrLWFkanVzdG1lbnQiLCIvZWNvbW1lcmNlL2xvY2F0aW9ucy8iOiJ3YXJlaG91c2UtbG9jYXRpb25zIiwiL2Vjb21tZXJjZS9zdG9jay1hbGVydHMvIjoib3V0LW9mLXN0b2NrLWFsZXJ0cyIsIi9lY29tbWVyY2UvY3VzdG9tZXJzLyI6ImFsbC1jdXN0b21lcnMiLCIvZWNvbW1lcmNlL3dpc2hsaXN0cy8iOiJ3aXNobGlzdC1zYXZlZC1pdGVtcy10cmFja2luZyIsIi9lY29tbWVyY2Uvb2ZmZXJzLyI6Im9mZmVycyIsIi9lY29tbWVyY2UvYmFubmVycy8iOiJiYW5uZXJzLXNsaWRlcnMiLCIvZWNvbW1lcmNlL2VtYWlsLW1hcmtldGluZy8iOiJlbWFpbC1tYXJrZXRpbmciLCIvZWNvbW1lcmNlL29yZGVycy8iOiJhbGwtb3JkZXJzIiwiL2Vjb21tZXJjZS9vcmRlci1pbnZvaWNlcy8iOiJvcmRlci1pbnZvaWNlcy1wYWNraW5nLXNsaXBzIiwiL2Vjb21tZXJjZS9yZXBvcnRzLyI6InNhbGVzLXJlcG9ydCIsIi9lY29tbWVyY2UvaW52ZW50b3J5LXJlcG9ydHMvIjoiaW52ZW50b3J5LXJlcG9ydCIsIi9lY29tbWVyY2UvY3VzdG9tZXItcmVwb3J0cy8iOiJjdXN0b21lci1yZXBvcnQiLCIvZWNvbW1lcmNlL2N1c3RvbWVyLW9yZGVycy8iOiJjdXN0b21lci1vcmRlcnMiLCIvZWNvbW1lcmNlL3Byb2R1Y3RzLWxpc3QvIjoicHJvZHVjdHMtY2F0YWxvZyIsIi9lY29tbWVyY2UvY2F0ZWdvcmllcy8iOiJwcm9kdWN0cy1jYXRlZ29yaWVzIiwiL2Vjb21tZXJjZS9icmFuZHMtbWFudWZhY3R1cmVycy8iOiJicmFuZHMtbWFudWZhY3R1cmVycyIsIi9lY29tbWVyY2UvcHJvZHVjdC1hdHRyaWJ1dGVzLyI6InByb2R1Y3QtYXR0cmlidXRlcyIsIi9lY29tbWVyY2UvY291cG9ucy8iOiJkaXNjb3VudC1jb3Vwb25zIiwiL2Vjb21tZXJjZS9yZXZpZXdzLyI6InJldmlld3MtcmF0aW5ncyIsIi9zZXR0aW5ncy9hY2NvdW50LXNldHRpbmdzLyI6ImdlbmVyYWwtc2V0dGluZ3MiLCIvc2V0dGluZ3Mvcm9sZS9saXN0LyI6InJvbGVzLXBlcm1pc3Npb25zIn0sImlhdCI6MTc3MTQ4Mjc2OSwiZXhwIjoxNzc0MDc0NzY5fQ.yVgUagbZMeBj0AT0uDtTDgwTOmgq9uB2ZEi8yp6zxWI', NULL, 0, 0, 0, '2026-02-18 07:19:50', '2026-02-19 06:32:49', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_permissions`
--

DROP TABLE IF EXISTS `users_permissions`;
CREATE TABLE IF NOT EXISTS `users_permissions` (
  `userId` int NOT NULL,
  `permissionId` int NOT NULL,
  PRIMARY KEY (`userId`,`permissionId`),
  UNIQUE KEY `users_permissions_permissionId_userId_unique` (`userId`,`permissionId`),
  KEY `permissionId` (`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `userId` int NOT NULL,
  `roleId` int NOT NULL,
  PRIMARY KEY (`userId`,`roleId`) USING BTREE,
  UNIQUE KEY `user_roles_roleId_userId_unique` (`userId`,`roleId`) USING BTREE,
  KEY `roleId` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`userId`, `roleId`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `menus_ibfk_231` FOREIGN KEY (`parentId`) REFERENCES `menus` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `menus_ibfk_232` FOREIGN KEY (`groupId`) REFERENCES `menu_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`menuId`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD CONSTRAINT `roles_permissions_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_permissions_ibfk_2` FOREIGN KEY (`permissionId`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `users_permissions_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_permissions_ibfk_2` FOREIGN KEY (`permissionId`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_roles_ibfk_11` FOREIGN KEY (`roleId`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
