const ErrorHandler = require("../utils/errorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const jwtConfig = require("../config").JWT;
const JWTAuth = require("../utils/jwtToken");

exports.isAuthenticated = catchAsyncErrors(async (req, res, next) => {
  let token = req.headers["authorization"];
  if (token && token.split(" ")[0] === "Bearer") {
    token = token.split(" ")[1];
  }
  if (!token || token == 'null') {
    return next(new ErrorHandler("No Token Provided!", 401));
  } else {
    // console.log('token =====> ', token)
    jwt.verify(token, jwtConfig.secret, async function (err, decoded) {
      if (err) {
        return next(new ErrorHandler("Invalid Token!", 500));
      } else {
        let validToken = await JWTAuth.findByUserToken(token, decoded);
        if (!validToken) {
          return res
            .status(401)
            .json({ status: false, message: "Invalid Token!", data: {} });
        } else {
          req.user = decoded;
          next();
        }
      }
    });
  }
});