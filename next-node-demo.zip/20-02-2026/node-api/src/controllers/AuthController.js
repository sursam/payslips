const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/errorHandler");
const RequestHandler = require("../utils/RequestHandler");
// const Mailable = require("../helpers/email");
const bcrypt = require("bcryptjs");
const JWTAuth = require("../utils/jwtToken");
const { Op } = require("sequelize");
const requestHandler = new RequestHandler();

const db = require("../models");
const permissionModel = db.Permissions;
const userModel = db.Users;
const roleModel = db.Roles;
const menuModel = db.Menus;

class AuthController extends BaseController {
  constructor() {
    super();
  }

  // ===================== Park Prime APIs WEB =====================
  static login = catchAsyncErrors(async (req, res, next) => {
    const { email_id, password, device_type } = req.body;
    let user = {};
    if(device_type != 2 &&  device_type != 3){
        user = await userModel.findOne({ 
            where: { email_id },
            include: [
                {
                    model: roleModel,
                    where: {
                        roleSlug: {
                            [Op.notIn]: ["customer"]
                        }                        
                    }, 
                    attributes: ["id", "roleName", "roleSlug"], 
                    as: 'userRole',
                    include: [
                        {
                            model: permissionModel, 
                            attributes: ["slug"],
                        },
                    ],
                },
            ] 
        });
    } else {
        user = await customerModel.findOne({
            where: { email_id }
        })
    }
    // console.log(user)
    
    if (!user) {
        return res.status(401).json({
            status: 401,
            message: "User does not found!",
            data: null,
        });
    }
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        return res.status(401).json({
            status: 401,
            message: "Password doesn't match!",
            data: null,
        });
    }
    let permissions = [];
    let roleId
    let roleSlug
    let roleName
    if(device_type != 2 && device_type != 3){
        user['userRole'].forEach((obj) => {
            permissions = [...obj.permissions.map((o) => o.slug), ...permissions];
        });
        roleId = user['userRole'][0].id;
        roleSlug = user['userRole'][0].roleSlug;
        roleName = user['userRole'][0].roleName;
    }
    let options = {
      attributes: ["link", "slug"],
      raw: true,
      where: {
        link: {
          [Op.not]: null
        }
      }
    };
    let menuData = await super.getList(req, menuModel, options);
    const menus = menuData.reduce((map, menu) => {
      map[menu.link] = menu.slug;
      return map;
    }, {});
    // console.log(menuData)
    var userData = {
        id: user?.id,
        uuid: user.uuid,
        name: user.name,
        email: email_id,
        deviceType: device_type,
        isVerified: user.isVerified,
        roleId: roleId,
        roleSlug: roleSlug,
        roleName: roleName,
        permissions: permissions,
        menus: menus
    };
    var token = JWTAuth.ClientSign(userData);
    let clientpUdateFields = {};
    if (Number(device_type) == 1 || Number(device_type) == 3) {
        clientpUdateFields.webLogin = token;
    } else {
        clientpUdateFields.appLogin = token;
    }
    userData.accessToken = token;

    if(device_type == 2 ||  device_type == 3){
        await super.updateById(customerModel, user?.id, clientpUdateFields)
    } else {
        await super.updateById(userModel, user?.id, clientpUdateFields);
    }

    // const usersData = await userModel.findOne({ where: { id: user?.id } });

    return res.status(200).json({
        status: 200,
        message: "Login successful.",
        data: {
            user: userData, 
            deviceToken: token
        },
    });
  });
  static forgotPassword = catchAsyncErrors(async (req, res, next) => {
    const { email_id, otp, uuid, password, confirm_password } = req.body;
    if (!email_id) {
      return next(new ErrorHandler("Please enter email", 400));
    }
    let condition = { email_id };
    const userExists = await userModel.findOne({where: condition});
    if (userExists) {
      if (otp && otp != "" && otp != null) {
        if (userExists.otp && userExists.otp.toString() == otp.toString()) {
          return res.status(200).json({
            status: true,
            message: "OTP verified successfully",
            uuid: userExists.uuid,
          });
          
        } else {
          return requestHandler.customError(res, 200, "OTP doesn't match");
        }
      }else if(uuid){
        if (!password) {
          return next(new ErrorHandler("Password is required", 400));
        }else if (!confirm_password) {
          return next(new ErrorHandler("Confirm password is required", 400));
        }else if(password != confirm_password){
          return requestHandler.customError(res, 200, "Password doesn't match");
        }else{
          let pass = await bcrypt.hash(password, 10);
          let updated = await super.updateByCustomOptions(
            userModel,
            {uuid: uuid},
            { 
              password: pass,
              otp: '' 
            }
          );
          console.log(updated);
          if(updated[0]){
            return res.status(200).json({
              status: true,
              message: "Password updated successfully"
            });
          }else{
            return requestHandler.customError(res, 500, "Something went wrong.");
          }
        }
      }else{
        const otpcode = Math.floor(1000 + Math.random() * 9000);
        // const currentDateTime = new Date();
        // const expirationDateTime = new Date(
        //   currentDateTime.setMinutes(currentDateTime.getMinutes() + 5)
        // );
        let updated = await super.updateById(
          userModel,
          userExists.id,
          { 
            otp: otpcode 
          }
        );
        if(updated){
          return res.status(200).json({
            status: true,
            message: "OTP sent to your email",
            otp: otpcode,
          });
        }else{
          return requestHandler.customError(res, 500, "Something went wrong.");
        } 
      }
    } else {
      return requestHandler.customError(res, 200, "User not found.");
    }
  });

}

module.exports = AuthController;
