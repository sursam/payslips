const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const RequestHandler = require("../utils/RequestHandler");
const { Op } = require("sequelize");
const ErrorHandler = require("../utils/errorHandler");

const requestHandler = new RequestHandler();
const {
  slugify,
  getMenuItems
} = require("../utils/utilities");

const db = require("../models");
const { raw } = require("express");
const roleModel = db.Roles;

const menuGroupModel = db.MenuGroups;
const menuModel = db.Menus;
const permissionModel = db.Permissions;
const rolesPermissionModel = db.RolesPermissions;

class RolePermissionController extends BaseController {
  constructor() {
    super();
  }

  static getRoleList = catchAsyncErrors(async (req, res, next) => {
    try {
        let { searchText, excludedRoleSlug } = req.body;
        let roles = [];
        let queryConditions = {};
        let excludedRoleSlugs = ["super-admin", "customer"];
        if(excludedRoleSlug){
          excludedRoleSlugs.push(excludedRoleSlug);
        }
        let whereClause = {
          deletedAt: null,
          roleSlug: {
            [Op.notIn]: excludedRoleSlugs,
          }
        };

        if(searchText){
          // let searchId = searchText.toLowerCase().replace('invoice-usr-','').replace(/^0+/, '');
          whereClause[Op.or] = [
            {
              id: 
              {
                  [Op.like]: `%${searchText}%`
              }
            }, 
            {
              roleName: 
              {
                  [Op.like]: `%${searchText}%`
              }
            }, 
            {
              roleSlug: 
              {
                  [Op.like]: `%${searchText}%`
              }
            }
          ] ;
        }

        queryConditions = {
          where: whereClause,
          order: [["order", "DESC"]],
        };

        roles = await roleModel.findAll(queryConditions);
      
        return res.status(200).json({
          status: true,
          message: "Roles retrieved successfully.",
          data: roles
        });
    } catch (error) {
        console.error("Error fetching Roles:", error);
        return res.status(500).json({
        status: false,
        message: "Oops... something went wrong!",
        data: {}
        });
    }
  });

  static saveRole = catchAsyncErrors(async (req, res, next) => {
    const { id, roleName } = req.body;
    if (!roleName) {
      return res.status(422).json({
        status: false,
        message: "Role name is required.",
        data: {},
      });
    }
    let condition = {
      deletedAt: null,
      roleName: roleName
    };
    if (id && id != "" && id != null && id != 'null') {
      condition.id = `{
            [Op.ne]: id
        }`;
    }
    let checkExist = await roleModel.findOne({
      attributes: ["id"],
      where: condition,
    });
    if (checkExist) {
      return res.status(400).json({
        status: false,
        message: "Role name already exists!",
        data: checkExist,
      });
    }
    let updated = null;
    let message = "";
    if(id && id != "" && id != null && id != 'null'){
      updated = await super.updateById(roleModel, id, {roleName: roleName, roleSlug: slugify(roleName)});
      message = "Role updated successfully";
    }else{
      updated = await super.create(res, roleModel, {roleName: roleName, roleSlug: slugify(roleName)});
      message = "Role added successfully";
    }
    if(updated){
      return res.status(200).json({
        status: true,
        message: message,
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }

  });
  static updateRoleStatus = catchAsyncErrors(async (req, res, next) => {
    const { id, roleSlug, status } = req.body;
    let queryConditions = {};
    if(id){
      queryConditions.id = id
    }
    if(roleSlug){
      queryConditions.roleSlug = roleSlug
    }
    // console.log(queryConditions)
    let updated = await super.updateByCustomOptions(roleModel, queryConditions, {status});
    if(updated){
      return res.status(200).json({
        status: true,
        message: "Role status updated successfully",
        data: {errors: {}}
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong!");
    }

  });

  static getRoleDetails = catchAsyncErrors(async (req, res, next) => {
    const { id, uuid, slug } = req.body;
    let queryConditions = {};

    if(id){
      queryConditions.id = id
    }
    if(uuid){
      queryConditions.uuid = uuid
    }
    if(slug){
      queryConditions.roleSlug = slug
    }
    
    let roleDetails = await super.getByCustomOptionsSingle(req, roleModel, {
      where: queryConditions,
    });
  
    if(roleDetails){
      return res.status(200).json({
        status: true,
        message: "Success",
        data: roleDetails
      });
    } else{
      return res.status(200).json({
        status: false,
        message: "No records found.",
        data: {}
      });
    }
  });
  static deleteRole = catchAsyncErrors(async (req, res, next) => {
    const { roleSlug } = req.body;
    if (!roleSlug) {
      return next(new ErrorHandler("Role is required", 400));
    }
    // =================== soft delete ===================
    let roleDeleted = await super.deleteByCondition(
      roleModel, 
      {
        roleSlug,
      }
    );
    // =================== soft delete ===================
    if(roleDeleted){
      return res.status(200).json({
        status: true,
        message: "Role deleted successfully"
      });
    }else{
      return requestHandler.customError(res, 500, "Something went wrong.");
    }
  });

  static rolePermissionList = catchAsyncErrors(async (req, res, next) => {
    let modules = []
    let rolePermissions = []
    const { roleId, text } = req.body;
    if(req.method == "POST"){
        const super_admin = await roleModel.findOne({ name: "Super Admin" });
        let match = {
          isActive: true,
          isDeleted: false,
          roleId: {
            $ne: super_admin._id,
          },
        //   $and:[
        //     {
        //         $or: [
        //           {
        //             moduleName: {
        //               $regex: ".*" + text + ".*",
        //               $options: "i",
        //             },
        //           },
        //         ],
        //     }
        //   ]
        };
        if (roleId != "") {
            const role = await roleModel.findOne({ _id: roleId });
            match["roleId"] = role._id;
        }
        const aggregatorOpts = [
          {
            $addFields: {
                roleId: "$roleId",
            },
          },
          {
            $match: match,
          },
        ];
        rolePermissions = await rolePermissionModel.aggregate(aggregatorOpts).exec();
        await rolePermissionModel.populate(
            rolePermissions,
            [
                {
                    path: 'roleId',
                    model: 'roleCollection',
                },
                {
                    path: 'moduleId', // array if objIds
                    model: 'moduleCollection',
                    populate: {
                        path: 'parentModuleId', 
                        model: 'moduleCollection',
                    }
                },
            ]
        );
    } else {
        // ======= for dropdown ===========
        // modules = await super.getList(req, rolePermissionModel, "");
    }

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: getPermissionDetails(rolePermissions),
    });
  });

  static rolePermissionAddUpdate = catchAsyncErrors(async (req, res, next) => {
    const { roleId, moduleId, _id } = req.body;
    let data = {
        roleId: roleId,
        moduleId: moduleId,

        updatedBy: req.user._id,
    };
    const updated =
      _id && _id != null && _id != ""
        ? await super.updateById(rolePermissionModel, _id.toString(), data)
        : await super.create(res, rolePermissionModel, data);

    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static getRolePermissionDetail = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    const rolePermissionDetail = await rolePermissionModel.findOne({ _id: id });
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: rolePermissionDetail,
    });
  });

  static deleteRolePermission = catchAsyncErrors(async (req, res, next) => {
    const { id } = req.body;
    let updated = [];
    // =================== soft delete ===================
    updated = await super.updateById(rolePermissionModel, id, {
        isDeleted: true
    });
    // =================== soft delete ===================
    return requestHandler.sendSuccess(
      res,
      "Successful"
    )({
      data: updated,
    });
  });

  static fetchMenuPermissions = catchAsyncErrors(async (req, res, next) => {
    try {
        let options = {
          attributes: ["id", "uuid", "name", "slug", "status"],
          order: [["order", "ASC"]],
          raw: true
        };

        let menuGroups = await super.getList(req, menuGroupModel, options);
        if (menuGroups.length) {
          for (let i = 0; i < menuGroups.length; i++) {
            menuGroups[i]['menus'] = await getMenuItems(menuGroups[i].id);
            // console.log(menuGroups[i]['menus']);
          }
          return res.status(200).json({
            status: true,
            message: "Data found.",
            data: menuGroups,
          });
        }
        return res.status(200).json({
          status: false,
          message: "No data found.",
          data: [],
        });
        
    } catch (error) {
        console.error("Error fetching menu groups:", error);
        return res.status(500).json({
        status: false,
        message: "Oops... something went wrong!",
        data: {}
        });
    }
  });
  static getMenuDetails = catchAsyncErrors(async (req, res, next) => {
    const { link } = req.body;
    try {
      if (!link) {
        return res.status(422).json({
          status: false,
          message: "Menu link is required.",
          data: {},
        });
      }
      const menuData = await menuModel.findOne({ 
        where: { link } 
      });
    
      if(menuData){
        return res.status(200).json({
          status: true,
          message: "Success",
          data: menuData
        });
      } else{
        return res.status(200).json({
          status: false,
          message: "No records found.",
          data: {}
        });
      }
    } catch (error) {
      console.error("Error fetching menu details:", error);
      return res.status(500).json({
      status: false,
      message: "Oops... something went wrong!",
      data: {}
      });
    }
  });
  static fetchRolePermissions = catchAsyncErrors(async (req, res, next) => {
    const { roleId } = req.body;
    try {
      let rolePermissions = [];
      if (!roleId) {
        return res.status(422).json({
          status: false,
          message: "Role id is required.",
          data: {},
        });
      }
      rolePermissions = await rolesPermissionModel.findAll({
        attributes: ["roleId", "permissionId"],
        where: {
          roleId: roleId
        }
      });
    
      if(rolePermissions){
        return res.status(200).json({
          status: true,
          message: "Success",
          data: rolePermissions
        });
      } else{
        return res.status(200).json({
          status: false,
          message: "No records found.",
          data: {}
        });
      }
    } catch (error) {
      console.error("Error fetching role permissions:", error);
      return res.status(500).json({
      status: false,
      message: "Oops... something went wrong!",
      data: {}
      });
    }
  });
  static updateRolePermissions = catchAsyncErrors(async (req, res, next) => {
    const { roleId, rolePermissions } = req.body;
    try{
      await super.deleteByCondition(
        rolesPermissionModel, 
        {
          roleId: roleId,
        }
      );
      
      let created = await rolesPermissionModel.bulkCreate(rolePermissions, {returning: true});
      
      if(created){
        return res.status(200).json({
          status: true,
          message: "Role wise permissions are updated.",
        });
      }else{
        return requestHandler.customError(res, 500, "Something went wrong.");
      }   
    } catch (error) {
      console.error("Error submitting role permissions:", error);
      return res.status(500).json({
      status: false,
      message: "Oops... something went wrong!",
      data: {}
      });
    }
  });

  // =========== App APIs ================

  // =========== App APIs ================
}

module.exports = RolePermissionController;
