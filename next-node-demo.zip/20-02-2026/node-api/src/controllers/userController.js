const BaseController = require("./BaseController");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const fileUploaderSingle = require("../utils/fileUpload").fileUploaderSingle;
const bcrypt = require("bcryptjs");
const { Op } = require("sequelize");
const crypto = require("crypto");

const {
  MSG_RECORD_FETCH_SUCCESS,
} = require("../config/constants");

const db = require("../models");
const userModel = db.Users;
const roleModel = db.Roles;
const permissionModel = db.Permissions;
const userRolesModel = db.UserRoles;

class UserController extends BaseController {
    constructor() {
        super();
    }
    static logout = catchAsyncErrors(async (req, res, next) => {
        let conditions = { userId: req.user.id, deviceId: req.user.deviceId };  
        let updateFields = {
            loginFlag: false,
        };
        
        let updated = await super.updateByCustomOptions(
            userTokensModel,
            conditions,
            updateFields
        );
        if (updated) {
            return res.status(200).json({
                status: true,
                message: "Logged out successfully",
            });
        }
    });

    // ============================ ADMIN USER METHODS START ============================ //

    static alterAdminUser = catchAsyncErrors(async (req, res, next) => {
        let {
            id,
            name,
            email_id,
            phone_number,
            password,
            status,
            roleId
        } = req.body;

        console.log(id);

        if(!id && email_id) {
            const emailExists = await userModel.findOne({
                where: { 
                    email_id
                },
            });

            if (emailExists) {
                return res.status(200).json({
                    status: false,
                    message: "Email already exists.",
                    data: {},
                });
            }
        }

        let fileName = null;
        if (req.files && req.files.profileImage) {
            const image = await fileUploaderSingle("src/public/uploads/", req.files.profileImage);
            fileName = image.newfileName;
        }

        try {
            const createAdminUsers = {
                name,
                email_id,
                phone_number,
                status,
                uuid: crypto.randomUUID(),
            };

            const updateAdminUsers = {
                name,
                email_id,
                phone_number,
                status,
            };

            if (fileName) {
                createAdminUsers.profileImage = fileName;
                updateAdminUsers.profileImage = fileName;
            }

            // Hash password if provided
            if (password) {
                const hashed = await bcrypt.hash(password, 10);
                createAdminUsers.password = hashed;
                updateAdminUsers.password = hashed;
            }

            let userData = {};
            if (id) {
                // Update user
                await super.updateById(userModel, id, updateAdminUsers);
                userData = await super.getById(res, userModel, id);
            } else {
                // Create user
                userData = await super.create(res, userModel, createAdminUsers);
            }

            if (userData?.id) {
                // Handle role assignment
                const userRoleData = await userRolesModel.findOne({ where: { userId: userData.id } });
                if (userRoleData) {
                    await super.updateByCustomOptions(
                        userRolesModel,
                        { userId: userRoleData.userId },
                        { roleId }
                    );
                } else {
                    // Create new role assignment
                    await super.create(res, userRolesModel, { roleId, userId: userData.id });
                }
            }

            return res.status(200).json({
                status: true,
                message: id ? "Admin user updated successfully." : "Admin user created successfully.",
                data: userData,
            });
        } catch (error) {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went wrong!",
                data: {},
            });
        }
    });

    static getAdminUser = catchAsyncErrors(async (req, res, next) => {
        const { id } = req.params;

        if (!id) {
            return res.status(200).json({ status: false, message: "User ID not found" });
        }

        try {
            const serviceData = await userRolesModel.findOne({
                where: { userId: id },
                include: [
                    { model: userModel},
                    { model: roleModel }
                ]
            });

            if (!serviceData) {
                return res.status(200).json({ status: false, message: "User not found" });
            }

            return res.status(200).json({
                status: true,
                message: MSG_RECORD_FETCH_SUCCESS,
                data: serviceData,
            });
        } catch (error) {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went wrong!",
                data: {},
            });
        }
    });

    static listAdminUser = catchAsyncErrors(async (req, res, next) => {
        try {
            let { searchText } = req.body;
            let whereClause = {
                deletedAt: null
            };
            if(searchText){
                whereClause[Op.or] = [
                    {
                        id: 
                        {
                            [Op.like]: `%${searchText}%`
                        }
                    }, 
                    {
                        name: 
                        {
                            [Op.like]: `%${searchText}%`
                        }
                    }, 
                    {
                        email_id: 
                        {
                            [Op.like]: `%${searchText}%`
                        }
                    }, 
                    {
                        phone_number: 
                        {
                            [Op.like]: `%${searchText}%`
                        }
                    }
                ] ;
            }
            const userList = await userModel.findAll({
                where: whereClause,
                include: [
                    {
                        model: roleModel, 
                        attributes: ["id", "roleName", "roleSlug"], 
                        as: 'userRole',
                        where: {
                            roleSlug: {
                                [Op.notIn]: ["super-admin", "customer"]
                            }
                        },
                    },
                ]
            });

            return res.status(200).json({
                status: true,
                message: MSG_RECORD_FETCH_SUCCESS,
                data: userList,
            });
        } catch (error) {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went wrong!",
                data: error,
            });
        }
    });

    static deleteAdminUser = catchAsyncErrors(async (req, res) => {
        const { id } = req.params;

        if (!id) {
            return res.status(200).json({ status: false, message: "User ID not found" });
        }

        try {
            await userRolesModel.destroy({ where: { userId: id } });

            const deletedData = await userModel.destroy({ where: { id } });

            if (!deletedData) {
                return res.status(200).json({ status: false, message: "User not found or already deleted." });
            }

            return res.status(200).json({
                status: true,
                message: "User deleted successfully.",
            });
        } catch (error) {
            return res.status(500).json({
                status: false,
                message: "Oops.. something went wrong!",
                data: {},
            });
        }
    });

    // ============================ ADMIN USER METHODS END ============================ //

}

module.exports = UserController;
