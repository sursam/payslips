module.exports = (sequelize, DataTypes) => {
  const Customer = sequelize.define("customer", {
    name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    email_id: {
      type: DataTypes.STRING,
      allowNull: false,
      // unique: true,
    },
    phone_number: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    device_type: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment : '1 = admin, 2 = mobile, 3 = front-end' 
    },
    country_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    address : {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    city : {
      type: DataTypes.STRING,
      allowNull: true,
    },
    postal_code : {
      type: DataTypes.STRING,
      allowNull: true,
    },
    country : {
      type: DataTypes.STRING,
      allowNull: true,
    },
    aboutMe : {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    profileImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    resend: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: false,
    },
    device_token: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    otp: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
      // unique: true,
    },
    webLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    appLogin: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isVerified: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: false,
    },
    status : {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
      allowNull: true,
    },
  });

  return Customer;
};
