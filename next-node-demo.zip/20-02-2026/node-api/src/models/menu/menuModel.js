module.exports = (sequelize, DataTypes) => {
  const menusSchema = sequelize.define("menus", {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false,
      // unique: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    slug: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    parentId: {
      type: DataTypes.INTEGER,
      references: {
        model: "menus",
        key: "id",
      },
      allowNull: true,
    },
    groupId: {
      type: DataTypes.INTEGER,
      references: {
        model: "menu_groups",
        key: "id",
      },
      allowNull: true,
    },
    icon: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    link : {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: '0 => in-active, 1 => active'
    },
    order: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    seedingCode: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return menusSchema;
};
