const mysqlConfig = require("../config/index.js").Mysql;
const Sequelize = require("sequelize");
const session = require('express-session');
const SequelizeStore = require('connect-session-sequelize')(session.Store);

const sequelizeConnectionInstance = new Sequelize(mysqlConfig.dbName, mysqlConfig.user, mysqlConfig.pwd, {
  host: mysqlConfig.host,
  dialect: mysqlConfig.dialect,
  logging: mysqlConfig.debug,
  // logging: console.log,
});
 
sequelizeConnectionInstance
  .authenticate()
  .then(() => {
    console.log('Mysql connection has been established successfully.')
  })
  .catch(err => {
    console.error('Unable to connect to the Mysql database:', err)
  })
 
// storing the session
const sequelizeSessionStore = new SequelizeStore({
  db: sequelizeConnectionInstance,
})
 

const db = {};
db.sequelizeConnectionInstance = sequelizeConnectionInstance;
db.Sequelize = Sequelize;

db.sequelizeSessionStore = sequelizeSessionStore;

// =======================================================================
// ======== include the Models and group the table-relations here ========
// =======================================================================

// ---- users ----
db.Users = require("./userModel")(sequelizeConnectionInstance, Sequelize);
// ---- users ----

// ---- roles ----
db.Roles = require("./roleModel")(sequelizeConnectionInstance, Sequelize);

db.UserRoles = require("./userRoleModel")(sequelizeConnectionInstance, Sequelize);

db.Users.belongsToMany(db.Roles, {
    through: db.UserRoles, // Name of the junction table
    foreignKey: 'userId',
    otherKey: 'roleId',
    as: 'userRole'
});

// ---- roles ----
db.UserRoles.belongsTo(db.Users, { foreignKey: 'userId' });
db.Users.hasMany(db.UserRoles, { foreignKey: 'userId' });

db.UserRoles.belongsTo(db.Roles, { foreignKey: 'roleId' });
db.Roles.hasMany(db.UserRoles, { foreignKey: 'roleId' });

// ---- permissions ----
db.Permissions = require("./permission/permissionModel")(sequelizeConnectionInstance, Sequelize);
// ---- permissions ----
// ---- rolesPermissions ----
db.RolesPermissions = require("./permission/rolesPermissionModel")(sequelizeConnectionInstance, Sequelize);
db.Roles.belongsToMany(db.Permissions, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'roleId',
    otherKey: 'permissionId',
});
db.Permissions.belongsToMany(db.Roles, {
    through: db.RolesPermissions, // Name of the junction table
    foreignKey: 'permissionId',
    otherKey: 'roleId',
});
// ---- rolesPermissions ----
// ---- usersPermissions ----
db.UsersPermissions = require("./permission/usersPermissionModel")(sequelizeConnectionInstance, Sequelize);
db.Users.belongsToMany(db.Permissions, {
    through: db.UsersPermissions, // Name of the junction table
    foreignKey: 'userId',
    otherKey: 'permissionId',
});
db.Permissions.belongsToMany(db.Users, {
    through: db.UsersPermissions, // Name of the junction table
    foreignKey: 'permissionId',
    otherKey: 'userId',
});
// ---- usersPermissions ----

db.Otp = require("./otpModel.js")(sequelizeConnectionInstance, Sequelize);

db.Users.belongsTo(db.Roles, { foreignKey: 'roleId' });
db.Roles.hasMany(db.Users, { foreignKey: 'roleId' });

// ---- menus ----
db.MenuGroups = require("./menu/menuGroupModel")(sequelizeConnectionInstance, Sequelize);
db.Menus = require("./menu/menuModel")(sequelizeConnectionInstance, Sequelize);
db.MenuGroups.hasMany(db.Menus, { foreignKey: 'groupId', });
db.Menus.belongsTo(db.Menus, { foreignKey: 'parentId', }); //  as: 'parentMenu'
db.Menus.hasOne(db.Menus, { foreignKey: 'parentId', });
db.Menus.hasMany(db.Permissions, { foreignKey: 'menuId', });
db.Permissions.belongsTo(db.Menus, { foreignKey: 'menuId', });
// ---- menus ----

// =======================================================================
// ======== include the Models and group the table-relations here ========
// =======================================================================

module.exports = db;