module.exports = (sequelize, DataTypes) => {
  const otpSchema = sequelize.define("otp", {
    email_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    phone_number: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    device_type : {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment : '1 = admin, 2 = mobile, 3 = front-end' 
    },
    country_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    otp: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_signed_up: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
    },
    expireAt : {
      field: "expire_at",
      type: DataTypes.DATE,
      allowNull: true,
    },
    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
    deletedAt: {
      field: "deleted_at",
      type: DataTypes.DATE,
    },
  });

  return otpSchema;
};
