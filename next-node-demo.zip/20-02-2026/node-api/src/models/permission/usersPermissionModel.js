module.exports = (sequelize, DataTypes) => {
  const usersPermissionsSchema = sequelize.define("users_permissions", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    permissionId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'permissions',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    }
  }, { timestamps: false });

  return usersPermissionsSchema;

  /* 
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  1. To get all modules for a user:
  -----------------------------------
  const userWithModules = await db.Users.findByPk(userId, {
    include: db.Modules
  });

  2. To get all users for a module:
  -----------------------------------
  const moduleWithUsers = await db.Modules.findByPk(moduleId, {
    include: db.Users
  });
  ---------------------------------------------------------------------------
  ----------------------------- Example Queries -----------------------------
  ---------------------------------------------------------------------------
  */
};
