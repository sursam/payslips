module.exports = (sequelize, DataTypes) => {
  const rolesPermissionsSchema = sequelize.define("roles_permissions", {
    roleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'roles',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    },
    permissionId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'permissions',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true, // Part of the composite primary key
    }
  }, { timestamps: false });

  return rolesPermissionsSchema;
};