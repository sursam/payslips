module.exports = (sequelize, DataTypes) => {
  const usersRolesSchema = sequelize.define("user_roles", {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'users',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true,
    },
    roleId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'roles',
        key: 'id'
      },
      allowNull: false,
      primaryKey: true,
    }
  }, { timestamps: false });

  return usersRolesSchema;
};
