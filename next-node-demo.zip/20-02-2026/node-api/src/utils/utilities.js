const crypto = require('crypto');
const axios = require('axios');
const FirebaseAdmin = require('firebase-admin');

const RequestHandler = require("../utils/RequestHandler");
const userModel = require('../models/userModel');
const requestHandler = new RequestHandler();

const fs = require('fs');
const path = require('path');
const db = require("../models");
const { group } = require('console');
const menuGroupModel = db.MenuGroups;
const menuModel = db.Menus;
const permissionModel = db.Permissions;

// var FCMServiceAccount = require('../config/serviceAccountKey.json');

// const FCM = FirebaseAdmin.initializeApp({
//     credential: FirebaseAdmin.credential.cert(FCMServiceAccount),
// });

const dateFormat = (date) => {
    return new Date(date).getFullYear()+'-'+(new Date(date).getMonth() + 1).toString().padStart(2,'0')+'-'+new Date(date).getDate().toString().padStart(2,'0')
}
const dateFormatDDMMYYYY = (dateToBeFormatted) => {
    let date =
        new Date().getDate().toString().padStart(2, "0") +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getFullYear();

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getFullYear();
    }
    return date;
};
const dateFormatYYYYMMDD = (dateToBeFormatted) => {
    let date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getFullYear() +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormat = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getFullYear() +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            " " +
            new Date(dateToBeFormatted).getHours().toString().padStart(2, "0") +
            ":" +
            new Date(dateToBeFormatted).getMinutes().toString().padStart(2, "0") +
            ":" +
            new Date(dateToBeFormatted).getSeconds().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormatYYYYMMDDHHMMSS = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date().getFullYear() +
            "-" +
            (new Date().getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date().getDate().toString().padStart(2, "0") +
            " " +
            new Date().getHours().toString().padStart(2, "0") +
            ":" +
            new Date().getMinutes().toString().padStart(2, "0") +
            ":" +
            new Date().getSeconds().toString().padStart(2, "0");
    }
    return date;
};
const fullDatetimeFormatDDMMYYYYHHIIAA = (dateToBeFormatted) => {
    var date =
        new Date().getFullYear() +
        "-" +
        (new Date().getMonth() + 1).toString().padStart(2, "0") +
        "-" +
        new Date().getDate().toString().padStart(2, "0") +
        " " +
        new Date().getHours().toString().padStart(2, "0") +
        ":" +
        new Date().getMinutes().toString().padStart(2, "0") +
        ":" +
        new Date().getSeconds().toString().padStart(2, "0");

    if (dateToBeFormatted != "") {
        date =
            new Date(dateToBeFormatted).getDate().toString().padStart(2, "0") +
            "-" +
            (new Date(dateToBeFormatted).getMonth() + 1).toString().padStart(2, "0") +
            "-" +
            new Date(dateToBeFormatted).getFullYear() +
            " " +
            convertTime24To12(
                new Date(dateToBeFormatted).getHours().toString().padStart(2, "0") +
                ":" +
                new Date(dateToBeFormatted).getMinutes().toString().padStart(2, "0") +
                ":" +
                new Date(dateToBeFormatted).getSeconds().toString().padStart(2, "0")
            );
    }
    return date;
};
const convertTime24To12 = (time) => {
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [
        time,
    ];

    if (time.length > 1) {
        // If time format correct
        time = time.slice(1); // Remove full string match value
        time[5] = +time[0] < 12 ? " AM" : " PM"; // Set AM/PM
        time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(""); // return adjusted time or original string
};
const convertTime12To24 = (time12h) => {
    var [time, modifier] = time12h.split(" ");

    var [hours, minutes] = time.split(":");

    if (hours === "12") {
        hours = "00";
    }

    if (modifier === "PM") {
        hours = parseInt(hours, 10) + 12;
    }
    return hours + ":" + minutes;
};

const convertDateToIst12Time = (dateformet) => {
    const utcTimestamp = dateformet; // Replace with your UTC timestamp

    // Create a Date object from the UTC timestamp
    const date = new Date(utcTimestamp);

    // Define options for formatting
    const options = {
        timeZone: "Asia/Kolkata", // IST timezone
        hour12: true, // Use 12-hour format
        hour: "numeric", // Display hours
        minute: "numeric", // Display minutes
    };

    // Format the date in IST 12-hour format
    const istTime = date.toLocaleString("en-IN", options);

    return istTime;
}

const generateOTP = (length) => {
    const digits = '0123456789';
    let otp = '';

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * digits.length);
        otp += digits[randomIndex];
    }

    return otp;
}

const isTimeBefore = (time1, time2) => {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    const date1 = new Date();
    date1.setHours(hours1);
    date1.setMinutes(minutes1);

    const date2 = new Date();
    date2.setHours(hours2);
    date2.setMinutes(minutes2);

    return date1.getTime() < date2.getTime();
}
/****
 * calculateDistance(pickup.lat, pickup.lng, dropOff.lat, dropOff.lng);
 * distance.toFixed(2), 'km'
 */
const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    const distance = R * c;
    return distance;
}

function calculateTimeInKilometers(distanceInKm, speedInMph) {
    // Convert speed from mph to km/h (1 mph is approximately 1.60934 km/h)
    const speedInKmh = speedInMph * 1.60934;
    // Calculate the duration in hours
    const durationHours = distanceInKm / speedInKmh;
    const durationMinutes = durationHours * 60;
    return durationMinutes;
}

// function convertMinutesToHours(minutes) {
//     const hours = minutes / 60;
//     const roundedHours = hours.toFixed(1);
//     return roundedHours;
// }

function convertMinutesToHours(minutes) {
    if (minutes < 60) {
        minutes = Math.round(minutes);
        return `${minutes} min`;

    } else {
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        if (remainingMinutes === 0) {
            return `${Math.round(hours)} hrs`;
        } else {
            return `${hours} hrs ${Math.round(remainingMinutes)} min`;
        }
    }
}

function getDateRangeForWeeks(weeksAgo) {
    const currentDate = new Date();
    const currentDayOfWeek = currentDate.getDay(); // 0 for Sunday, 1 for Monday, etc.

    // Calculate the start date of the current week (Sunday)
    const startDate = new Date(currentDate);
    startDate.setDate(currentDate.getDate() - currentDayOfWeek);

    // Calculate the end date of the current week (today)
    const endDate = new Date(currentDate);

    // Adjust the start date and end date for the specified number of weeks ago
    startDate.setDate(startDate.getDate() - (weeksAgo * 7));
    endDate.setDate(endDate.getDate() - (weeksAgo * 7));

    // Format the dates as strings in "YYYY-MM-DD" format
    const startDateString = startDate.toISOString().split('T')[0];
    const endDateString = endDate.toISOString().split('T')[0];

    return { startDate: startDateString, endDate: endDateString };
}

function getDateRangeForPreviousDays(endDate, daysAgo) {
    const startDate = new Date(endDate);
    startDate.setDate(startDate.getDate() - daysAgo);

    // Format the dates as strings in "YYYY-MM-DD" format
    const startDateString = startDate.toISOString().split('T')[0];
    const endDateString = endDate.toISOString().split('T')[0];

    return { startDate: startDateString, endDate: endDateString };
}

function calculateTimeDifferenceInMinutes(givenDateStr) {
    // The given date
    const givenDate = new Date(givenDateStr);

    // Current date and time
    const currentDate = new Date();

    // Calculate the time difference in milliseconds
    const timeDifferenceMs = currentDate - givenDate;

    // Convert milliseconds to minutes
    const timeDifferenceMinutes = Math.floor(timeDifferenceMs / (1000 * 60));

    return timeDifferenceMinutes;
}

function sumArray(arr) {
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    return sum;
}

const pointInPolygonWithRadius = (point, polygon, radius) => {
    const x = point.lat;
    const y = point.lng;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i].lat;
        const yi = polygon[i].lng;
        const xj = polygon[j].lat;
        const yj = polygon[j].lng;

        // Check if the point is within the bounding box of the polygon with a radius
        const withinBoundingBox = x >= Math.min(xi, xj) - radius &&
            x <= Math.max(xi, xj) + radius &&
            y >= Math.min(yi, yj) - radius &&
            y <= Math.max(yi, yj) + radius;

        if (withinBoundingBox) {
            // Check if the point is within the radius of any line segment of the polygon
            const distance = Math.abs(
                (yj - yi) * x - (xj - xi) * y + xj * yi - yj * xi
            ) / Math.sqrt((yj - yi) ** 2 + (xj - xi) ** 2);

            if (distance <= radius) {
                return true;
            }
        }
    }

    return false;
};

// Function to calculate the central point
function calculateCentralPoint(coordinates) {
    if (coordinates.length === 0) {
        return null; // No coordinates to calculate
    }

    // Calculate average latitude and longitude
    const avgLat = coordinates.reduce((sum, coord) => sum + coord.lat, 0) / coordinates.length;
    const avgLng = coordinates.reduce((sum, coord) => sum + coord.lng, 0) / coordinates.length;

    return { lat: avgLat, lng: avgLng };
}

function getTimeLabel(timeDifferenceHours) {
    if (timeDifferenceHours < 24) {
        return "Today";
    } else if (timeDifferenceHours < 48) {
        return "Yesterday";
    } else {
        return `${Math.ceil(timeDifferenceHours)} hours ago`;
    }
}

/****
 * Travel Pay
 */
async function getRateChartCategory(myDistance) {

    const travelPay = await TravelPayModel.find({});
    const distance = parseFloat(myDistance);

    for (const value of travelPay) {
        const fromRate = parseFloat(value.firstMile);
        const toRate = parseFloat(value.lastMile);
        const paytype = value.payType;

        if (distance >= fromRate && distance <= toRate) {
            if (paytype === 'km') {
                const kmRate = parseFloat(value.amount);
                return kmRate * distance;
            } else if (paytype === 'rs') {
                return parseFloat(value.amount);
            }
        }
    }
    return 0;
}

/****
 * Delivery incentives
 */
async function getDeliveryIncentives(deliveryCount) {
    const deliveryIncentives = await DeliveryIncentivesModel.find({});
    const totalDeliveryCount = parseFloat(deliveryCount);
    var incentive = parseFloat(0);

    for (let incentiveModel of deliveryIncentives) {
        if (
            parseInt(totalDeliveryCount) >= parseInt(incentiveModel.deliveries)
        ) {
            incentive = parseFloat(incentiveModel.incentives);
        } else {
            incentive = parseFloat(incentive);
        }
    }

    return incentive;
}

/****
 * Surge Charge -- raining/holiday/late_night
 */
async function getAmountByCondition(condition) {
    try {
        const record = await SurgeOrderModel.findOne({ slug: condition });
        if (record) {
            return record.amount;
        } else {
            return 0;
        }
    } catch (error) {
        console.error('Error fetching data from the database:', error);
        throw error;
    }
}
/*****
 * Waiting charge from Resturant -- (Reach pickup location -- Pickup complete)
 */
async function getWaitingChargeFromResturant(waitingTimeMinute) {
    try {
        const waitingPayRest = await WaitingPayRestModel.find({});
        const distance = parseFloat(waitingTimeMinute);
        for (const value of waitingPayRest) {
            const fromRate = parseFloat(value.fromMin);
            const toRate = parseFloat(value.toMin);

            if (distance >= fromRate && distance <= toRate) {
                return value.amount;
            }
        }
        return 0.00;
    } catch (error) {
        console.error(error);
        throw error;
    }
}
/*****
 * Distance Calculation using 3rd party Api
 */
async function calculateDistanceInsTentApi(origin, destination) {
    try {
        const response = await axios.get(process.env.INSTENT_API_URL, {
            params: {
                origins: origin,
                destinations: destination,
            },
            headers: {
                'x-api-key': `${process.env.INSTENT_API_KEY}`,
            }
        });
        if (response.status === 200) {
            const { distances } = response.data;
            return distances / 1000;
        } else {
            throw new Error('Error fetching distance data.');
        }
    } catch (error) {
        throw new Error(`Error: ${error.message}`);
    }
}

// Create a function to send FCM notifications
async function sendNotification(req, res) {
    // const deviceToken = req.body.fcm_token;

    // if (!deviceToken || typeof deviceToken !== 'string') {
    //     return res.status(400).json({
    //         success: false,
    //         error: 'Invalid device token'
    //     });
    // }

    const deviceTokens = req.body.fcm_tokens;

    if (!deviceTokens || !Array.isArray(deviceTokens)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid device tokens'
        });
    }

    const notification = {
        notification: {
            title: req.body.title,
            body: req.body.body,
            message_id: req.body.messageData ? req.body.messageData._id.toString() : "",
            created_by: req.body.messageData ? req.body.messageData.created_by : "",
            notify_date: req.body.messageData ? calculateTimeDifferenceInMinutes(req.body.messageData.notify_date) + "" + 'mins' : ""
        }
    };

    const responses = [];

    try {
        for (const deviceToken of deviceTokens) {
            const response = await FirebaseAdmin.messaging().sendToDevice(deviceToken, notification);
            responses.push(response);
        }

        // return requestHandler.sendSuccess(res, 'Successfully.')({
        //     responses
        // });
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: 'Failed to send notification'
        });
    }
}


// Function to calculate login time for each object and total login time
async function calculateTotalLoginTime() {
    try {
        // Retrieve all login time ranges from the collection
        // const loginTimeRanges = await LoginTimeRange.find();

        // Example usage
        const loginTimeRanges = [
            {
                startTime: '10:00',
                endTime: '10:30',
            },
            {
                startTime: '11:00',
                endTime: '12:00',
            }
        ];

        const shiftDate = '2023-01-01';

        // Calculate login time for each object and total login time
        let totalLoginTime = 0;

        for (const { startTime, endTime } of loginTimeRanges) {
            const start = new Date(`${shiftDate}T${startTime}`);
            const end = new Date(`${shiftDate}T${endTime}`);
            const loginTime = (end - start) / (1000 * 60); // in minutes

            totalLoginTime += loginTime;
        }
        return totalLoginTime;
    } catch (error) {
        console.error('Error calculating login time:', error);
    } finally {
        console.log("running");
    }
}
function slugify(str) {
    str = str.replace(/^\s+|\s+$/g, ''); // trim leading/trailing white space
    str = str.toLowerCase(); // convert string to lowercase
    str = str.replace(/[^a-z0-9 -]/g, '') // remove any non-alphanumeric characters
        .replace(/\s+/g, '-') // replace spaces with hyphens
        .replace(/-+/g, '-'); // remove consecutive hyphens
    return str;
}


async function getMenuItems(groupId = null, parentId = null) {
    queryConditions = {
        attributes: ["id", "uuid", "name", "slug", "parentId", "icon", "link", "status"],
        where: {
            groupId,
            parentId
        },
        order: [["order", "ASC"]],
        raw: true
    };
    let menuItems = await menuModel.findAll(queryConditions);
    
    // let menuItemsJson = JSON.parse(JSON.stringify(menuItems));
    if(menuItems.length){
        for (let i = 0; i < menuItems.length; i++) {
            var menuItem = menuItems[i];
            menuItem['permissions'] = await getMenuPermissions(menuItem.id);
            menuItem['menus'] = await getMenuItems(groupId, menuItem.id);
        }
    }
    return menuItems;
}
async function getMenuPermissions(menuId) {
    queryConditions = {
        attributes: ["id", "name", "slug"],
        where: {
            menuId
        }
    };
    let menuPermissions = await permissionModel.findAll(queryConditions);
    return menuPermissions;
}

module.exports = {
    dateFormat,
    dateFormatDDMMYYYY,
    fullDatetimeFormat,
    convertTime24To12,
    convertTime12To24,
    fullDatetimeFormatDDMMYYYYHHIIAA,
    fullDatetimeFormatYYYYMMDDHHMMSS,
    dateFormatYYYYMMDD,
    convertDateToIst12Time,
    generateOTP,
    getTimeLabel,
    isTimeBefore,
    calculateDistance,
    calculateTimeInKilometers,
    calculateTimeDifferenceInMinutes,
    sumArray,
    calculateCentralPoint,
    pointInPolygonWithRadius,
    getRateChartCategory,
    getAmountByCondition,
    getWaitingChargeFromResturant,
    calculateDistanceInsTentApi,
    getDateRangeForWeeks,
    getDateRangeForPreviousDays,
    getDeliveryIncentives,
    convertMinutesToHours,
    sendNotification,
    calculateTotalLoginTime,
    slugify,
    getMenuItems
};
