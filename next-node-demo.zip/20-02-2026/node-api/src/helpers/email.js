const mailer = require("nodemailer");
const mailConfig = require("../config").Mail;

var smtpTransport = mailer.createTransport({
  // host: mailConfig.host,
  // port: mailConfig.port,
  // secure: false,
  service: 'gmail',
  auth: mailConfig.auth,
});

const sendMail = async (email, subject, content, attachments=false, ccEmail=false) => {
  var mailContent = {
    from: {
      name: mailConfig.fromName,
      address: mailConfig.fromMail,
    },
    to: email,
    subject: subject,
    html: content,
  };
  if (attachments) { 
    mailContent.attachments = [ 
      { 
        filename: "invoice.pdf", 
        path: attachments, 
      }, 
    ]; 
  } 
  if (ccEmail) { 
    mailContent.cc = ccEmail; 
  }

  smtpTransport.sendMail(mailContent, function (error, response) {
    if (error) {
      console.log(error);
    } else {
      console.log("response.response ===>");
      console.log(response.response);
      console.log("---------- Mail sent. ----------");
    }
  });

};

module.exports = sendMail;
