const express = require('express');
const router = express.Router();
const rolePermissionController = require('../controllers/rolePermissionController')

const {
    isAuthenticated
} = require('../middleware/auth')

router.route('/get-role-list').post(isAuthenticated, rolePermissionController.getRoleList);
router.route('/save-role').post(isAuthenticated, rolePermissionController.saveRole);
router.route('/get-role-details').post(isAuthenticated, rolePermissionController.getRoleDetails);
router.route('/update-role-status').post(isAuthenticated, rolePermissionController.updateRoleStatus);
router.route('/role-delete').post(isAuthenticated, rolePermissionController.deleteRole);
router.route('/fetch-menu-permissions').get(isAuthenticated, rolePermissionController.fetchMenuPermissions);
router.route('/get-menu-details').post(isAuthenticated, rolePermissionController.getMenuDetails);
router.route('/fetch-role-permissions').post(isAuthenticated, rolePermissionController.fetchRolePermissions);
router.route('/update-role-permissions').get(isAuthenticated, rolePermissionController.rolePermissionList).post(isAuthenticated, rolePermissionController.updateRolePermissions);
router.route('/rolePermission-list').post(isAuthenticated, rolePermissionController.rolePermissionList);
router.route('/rolePermission-addUpdate').post(isAuthenticated, rolePermissionController.rolePermissionAddUpdate); // validateUser, 
router.route('/get-rolePermissionDetail').post(isAuthenticated, rolePermissionController.getRolePermissionDetail);
router.route('/delete-rolePermissionDetail').post(isAuthenticated, rolePermissionController.deleteRolePermission);

module.exports = router;