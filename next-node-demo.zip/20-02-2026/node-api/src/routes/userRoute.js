const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController')
const {
  isAuthenticated,
} = require('../middleware/auth')

router.route('/logout').post(isAuthenticated, userController.logout);

// ============================ ADMIN USER ROUTES START ============================ //

router.route('/alter-admin-user').post(isAuthenticated, userController.alterAdminUser);
router.route('/list-admin-user').post(isAuthenticated, userController.listAdminUser);
router.route('/get-admin-user/:id').get(isAuthenticated, userController.getAdminUser);
router.route('/delete-admin-user/:id').delete(isAuthenticated, userController.deleteAdminUser);

// ============================ ADMIN USER ROUTES END ============================ //


module.exports = router;