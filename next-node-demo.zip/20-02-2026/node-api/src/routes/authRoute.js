const express = require('express');
const router = express.Router();
const authController = require('../controllers/AuthController');

router.route('/login').post(authController.login);
router.route('/forgot-password').post(authController.forgotPassword);

module.exports = router;