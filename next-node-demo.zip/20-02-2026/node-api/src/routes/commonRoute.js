const express = require('express');
const router = express.Router();
const CommonController = require('../controllers/CommonController');

router.route('/seed-menu-data').post(CommonController.seedMenuData);

module.exports = router;