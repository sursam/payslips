const mysqldb = require('../models');

// ============== mySql Sequilize connection is being done from index of Model folder ==============
mysqldb.sequelizeConnectionInstance.sync({
    alter: true,
    force: false,
    // logging: console.log
});
// ============== mySql Sequilize connection is being done from index of Model folder ENDs ==============
