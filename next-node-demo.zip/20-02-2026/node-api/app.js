const express = require("express");
const app = express();
const morgan = require("morgan")
const cors = require("cors");
const session = require('express-session');
const errorMiddleware = require("./src/middleware/error");
const cookieParser = require("cookie-parser");
const expressFileUpload = require("express-fileupload");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const oneYear = 1000 * 60 * 60 * 24 * 365;

app.use(express.json());
// app.use(express.urlencoded({ limit: "50mb", extended: true }))
app.use(express.static(`${__dirname}/src/public`));
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.set('trust proxy', 1);
app.use(cookieParser());
app.use(expressFileUpload({ parseNested: true }));
app.use(cors());
/*************** Morgan Log Configuration ****************/
// app.use(morgan('combined'));
app.use(morgan('dev'));
app.use(session({
  secret: "53536311secrctekeyfhgfgrfrty0687564rw3234e5659884fwir764",
  saveUninitialized:true,
  cookie: { maxAge: oneYear },
  resave: false
}));
app.use(
  helmet({
    contentSecurityPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginEmbedderPolicy: true,
  })
);

// =================== express-rate-limit ===================
const limiter = rateLimit({
	windowMs: 1 * 1000, // 1 minutes
	max: 100, // limit each IP to 100 requests per windowMs
	message: "Too many requests from this IP, please try again later."
});
app.use(limiter);
// ========== error handling for rateLimit exceeded ============
app.use((err, req, res, next) => {
	if (err instanceof rateLimit.RateLimitError) {
			// Handle rate limit exceeded error
			res.status(429).send("Rate limit exceeded");
	} else {
			next(err);
	}
});
// ========== error handling for rateLimit exceeded ============
// =================== express-rate-limit ===================

// ======= use the route files here =======
app.use("/", require("./src/routes/commonRoute"));
app.use("/", require("./src/routes/authRoute"));
app.use("/", require("./src/routes/rolePermissionRoute"));
app.use("/", require("./src/routes/userRoute"));
// ======= use the route files here ======

app.use(errorMiddleware);
app.use('/uploads', express.static('src/public/uploads/'));

module.exports = app;
