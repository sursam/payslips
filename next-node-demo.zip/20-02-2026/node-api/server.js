require('dotenv').config();
require('./src/config/connect');
const app = require('./app');
const Emitter = require('events');

// Function to start the server
function startServer() {
  app.listen(process.env.PORT, () => {
    if (process.env.APP_ENV == "production") {
      console.log(`server is listening on ${process.env.APP_URL}`);
    } else {
      console.log(`server is listening on http://localhost:` + process.env.PORT + "/");
    }
  });
}

process.on("uncaughtException", (err) => {
  console.log(`Error: ${err.message}`);
  console.log(`Shutting down the server due to unhandled Uncaught Rejection`);

  server.close(() => {
    startServer();
  });
});
  
// Event emitter
const eventEmitter = new Emitter();
app.set('eventEmitter', eventEmitter);

// process.env.TZ = 'Asia/Kolkata';
process.env.TZ = (process.env.APP_ENV == "production")? process.env.PROD_TZ : process.env.DEV_TZ;

const server = app.listen(process.env.PORT, () => {
  if (process.env.APP_ENV == "production") {
    console.log(`server is working on ${process.env.APP_URL}`);
  } else {
    console.log(`server is working on http://localhost:` + process.env.PORT + "/");
  }
});

process.on("unhandledRejection", err => {
  console.log(`Error: ${err.message}`);
  console.log(`Shutting down the server due to unhandled Promise Rejection`);

  // Close the server gracefully
  server.close(() => {
    console.log('Server closed. Restarting...');

    // Restart the server after it's closed
    startServer();
  });
});