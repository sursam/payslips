'use strict';
const {
      seedMenuData
    } = require("../src/utils/utilities");
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    seedMenuData();

    /*const fs = require('fs');
    const path = require('path');
    const {
      slugify,
      seedMenuData
    } = require("../src/utils/utilities");
    const crypto = require("crypto");

    // Assuming your JSON file is named 'menuData.json' and is in a 'data' directory
    const seedFilePath = path.join(__dirname, 'data', 'menuData.json');
    const rawData = fs.readFileSync(seedFilePath);
    const menuData = JSON.parse(rawData);

    // const db = require("../src/models");
    // const menuGroupoModel = db.MenuGroups;
    // console.log(menuData);

    if(menuData.groups.length){
      menuData.groups.forEach(async (menuGroupData) => {
        const menuGroup = await queryInterface.bulkInsert('menu_groups', [{ uuid: crypto.randomUUID(), name: menuGroupData.name, slug: slugify(menuGroupData.name), created_at: new Date(), updated_at: new Date() }], { returning: true });
        console.log('menuGroup', menuGroup);      
        
        if(menuGroup && menuGroupData.menus){
          if(menuGroupData.menus.length){
            menuGroupData.menus.forEach(async (menuObj) => {
              const menu = await queryInterface.bulkInsert('menus', 
              [{ uuid: crypto.randomUUID(), name: menuObj.name, slug: slugify(menuObj.name), groupId: menuGroup[0].id, created_at: new Date(), updated_at: new Date() }], { returning: true });
              if(menu[0].menus.length){
                let menuSeedData = seedMenuData(menu[0].menus, menuGroup[0].id, menu[0].id);
                console.log(menuSeedData);
                await queryInterface.bulkInsert('menus', menuSeedData);
              }
            });
          }
        }
      });
    }*/

    // const users = await queryInterface.bulkInsert('menu_groups', [
    //   { name: 'John Doe', email: 'john@example.com', createdAt: new Date(), updatedAt: new Date() },
    //   { name: 'Jane Smith', email: 'jane@example.com', createdAt: new Date(), updatedAt: new Date() },
    // ], { returning: true }); // Use returning: true to get the inserted records with IDs

    // // Assuming users[0].id and users[1].id are the IDs of the inserted users
    // // Insert data into 'posts' table, referencing user IDs
    // await queryInterface.bulkInsert('menus', [
    //   { title: 'First Post', content: 'Content of the first post.', userId: users[0].id, createdAt: new Date(), updatedAt: new Date() },
    //   { title: 'Second Post', content: 'Content of the second post.', userId: users[1].id, createdAt: new Date(), updatedAt: new Date() },
    // ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('menu_groups', null, {});
    await queryInterface.bulkDelete('menus', null, {});
  }
};
